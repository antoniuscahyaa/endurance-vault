# Kartu "Acuan latihan": batas HR easy, HR threshold, dan pace easy otomatis

Ketiga angka ini tidak lagi diisi manual. Isiannya dihapus dari kartu Detak jantung dan diganti kartu sendiri di halaman Profil (di bawah Detak jantung, di atas Target dan Rekor pribadi), berisi tiga pill sejajar.

## Sumber angka
- Batas HR easy = batas atas Z2, dan HR threshold = rentang Z4, dari zona HR yang sedang aktif.
- Pace easy = zona Easy dari RAI (62 sampai 74 persen, sama dengan kartu "Zona pace dari RAI" di Fitness), ditampilkan sebagai rentang dengan urutan yang sama seperti di Fitness, mis. "6:51–6:12".
- Bila RAI belum bisa dihitung: rata-rata 5 lari easy terakhir ± 10 detik. Bila itu pun belum ada, kartu menampilkan nilai pace yang tersimpan.

## Simpan otomatis
- `AppRoot` menghitung ulang acuan setiap data lari, kondisi harian, atau pengaturan berubah, lalu menyimpannya ke `PlanSettings` (`hr`, `thr`, `pace`) supaya mesin rencana tetap membaca nilai yang tersimpan.
- Mesin rencana hanya butuh satu angka pace, jadi yang disimpan adalah titik tengah rentang. Rentangnya hanya untuk tampilan.
- Angka manual yang pernah disimpan akan tertimpa hasil otomatis.

Berkas berubah:
- app/src/main/java/com/endurancevault/app/domain/TrainingRefs.kt (baru, murni Kotlin)
- app/src/main/java/com/endurancevault/app/ui/screens/ProfilePage.kt (kartu `RefsCard`, isian dihapus dari Detak jantung)
- app/src/main/java/com/endurancevault/app/ui/screens/ProfileScreen.kt (parameter isian dihapus dari pemanggilan)
- app/src/main/java/com/endurancevault/app/ui/AppRoot.kt (simpan otomatis)
- `ZoneIntensityFields.kt` tidak lagi dipakai, dibiarkan di tempatnya.
