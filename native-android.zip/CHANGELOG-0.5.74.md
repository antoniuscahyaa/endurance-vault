# Dock Explore (gaya COROS)

Dock baru "Explore" di ujung kanan dock (setelah Jadwal), berisi pembuat rute dan Koleksiku.

Peta Explore
- Peta layar penuh dengan tiga mode: Default (OSM), Satelit (Esri), Topografi (OpenTopoMap). Pilihan mode diingat. Memakai `MapTiles` dan cache ubin yang sama dengan pratinjau GPX, jadi area yang pernah dibuka tetap bermap saat offline.
- Alat di rail kiri: Lari, Sepeda, Manual, Lokasi. Lari dan Sepeda menempelkan jalur ke jalan/jalur setapak (OSRM FOSSGIS, data OpenStreetMap, profil kaki dan sepeda). Manual menarik garis lurus. Bila layanan tidak terjangkau, ruas itu otomatis garis lurus dan muncul pemberitahuan.
- Ketuk peta untuk menambah titik: hijau (awal), biru (waypoint), hitam (akhir). Urungkan menghapus titik terakhir. Hapus bagian akhir: slider memilih bagian ujung rute (merah di peta) yang dibuang.
- Alat Lokasi menyimpan pin oranye (air minum, parkir, pos). Cari tempat (kota/desa/gunung) dan tombol ke lokasi saya (memakai lokasi terakhir perangkat, meminta izin bila perlu).
- Kartu bawah: jarak, naik, turun, estimasi waktu, profil elevasi. Estimasi waktu memakai tempo "Sedang" dari indeks kemampuan lari terakhir (logika yang sama dengan dialog Kirim ke jam), "–" bila belum ada data.

Elevasi
- Dari model elevasi digital Open-Meteo (Copernicus 90 m), disampel tiap ±50 m, dihaluskan, ambang naik/turun 3 m seperti `GpxRoute.stats`. Butuh internet; bila offline rute tetap bisa disimpan tanpa elevasi. Nilainya bisa berbeda dari altimeter jam.

Koleksiku
- Tab Rute dan Lokasi. Filter Jarak, Area (≤ 25 km dari pusat peta), Sumber, Aktivitas. Impor GPX menambah rute ke koleksi tanpa mengirimnya ke jam.
- Detail rute: peta (3 mode), statistik, profil elevasi, daftar titik (waypoint dan lokasi dekat rute), Sunting di peta, Ekspor GPX (lembar berbagi), Ubah nama, Hapus, dan Kirim ke jam (memakai dialog dan alur kirim ke jam yang sudah ada).
- Rute dan lokasi disimpan di tabel kv (`explore.routes`, `explore.places`), jadi otomatis masuk cadangan dan pemulihan data.

Berkas baru:
- domain/ExploreModels.kt, data/ExploreStore.kt (penyimpanan, routing, elevasi), ui/ExploreController.kt, ui/screens/ExploreMap.kt, ExploreScreen.kt, ExploreCollection.kt

Berkas berubah:
- ui/AppRoot.kt (tab Explore, rute `explore`, `explore/collection`, `explore/route/{id}`), ui/MainViewModel.kt (`explore`), res/xml/file_paths.xml (folder cache `gpx`)

Catatan: kode belum dikompilasi di lingkungan ini (tanpa Android SDK). Jalankan build untuk memastikan.
