# Video rute 3D: perluasan

Tambahan di atas 0.5.75.

Tampilan
- Garis rute berwarna menurut data: detak jantung, pace/kecepatan, atau gradien (rampa biru–hijau–kuning–merah). Panel baru "Legenda warna garis".
- Bendera yang menempel di peta 3D: per km dengan pace km itu (jarak otomatis 2/5/10 km untuk rute panjang), start, finish, puncak, dan tanjakan terberat. Muncul saat pelari melewatinya; yang bertabrakan disaring menurut prioritas.
- Medan lebih halus: hillshade dua cahaya dan kabut jarak.

Tata letak
- Preset tata letak: Minimal, Lengkap, Gaya Coros, plus tata letak buatanmu sendiri (maksimal 12, disimpan bersama pilihan warna teks, latar, mode angka, dan garis rute).
- Rasio 9:16, 4:5, 1:1, 16:9 dan kualitas HD (1080 px) atau Ringan (720 px). Ukuran panel diskalakan menurut sisi pendek bingkai.

Ghost
- Balapan dengan aktivitas lain di rute serupa, berjalan menurut waktu yang sama. Panel "Selisih ghost" menunjukkan unggul/tertinggal.

Render dan offline
- Render berjalan di latar belakang dengan notifikasi progres (foreground service `dataSync`), jadi layar boleh ditutup. Satu render per waktu; bila proses aplikasi dimatikan sistem, render harus diulang.
- Unduhan ubin kini paralel. Tombol "Peta offline" menyimpan ubin satelit dan elevasi untuk aktivitas ini atau 10 aktivitas terakhir. Belum dipicu otomatis setelah sinkronisasi.

Berkas baru: `domain/RouteVideoExtras.kt`, `ui/video/RouteVideoJobs.kt`, `ui/video/RouteVideoService.kt`. Manifest: izin `FOREGROUND_SERVICE_DATA_SYNC` dan service render. Terjemahan Inggris untuk string baru ditambahkan di `assets/i18n/en.tsv`.

Sakelar per fitur
- Bendera dipisah menjadi empat sakelar: per km, start dan finish, puncak, tanjakan terberat. Pengaturan lama (satu sakelar gabungan) otomatis dibaca sebagai ketiganya; tata letak buatanmu yang lama ikut terbaca.
- Bayangan relief dan kabut jarak bisa dimatikan masing-masing (medan jadi rata terang / tanpa pemudaran jarak).
- "Lanjut di latar belakang (notifikasi)" bisa dimatikan: tanpa service dan tanpa notifikasi, render dibatalkan bila layar ditutup.
- Fitur lain sudah punya cara mematikan: warna garis ("Satu warna"), ghost ("Hapus ghost"), tiap panel termasuk legenda dan grafik, mode angka berjalan/total.
