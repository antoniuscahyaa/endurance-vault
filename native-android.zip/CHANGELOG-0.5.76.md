# Dock bawah diganti drawer kiri

Dock bawah dihapus total. Navigasi utama pindah ke drawer kiri.

Drawer
- Dibuka hanya dengan mengetuk foto profil di header (tanpa ikon menu dan tanpa geser dari tepi layar). Saat terbuka, geser ke kiri atau ketuk area gelap menutupnya.
- Isi: kepala drawer (foto dan nama), lalu Profil, Hari ini, Progres, Minggu, Jadwal (hanya bila ada rencana latihan), Explore. Pengaturan ada di dasar drawer, dipisah garis.
- Memilih menu menutup drawer otomatis lalu pindah ke halaman itu. Pola navigasinya sama dengan dock lama (kembali ke Hari ini lewat tombol Back).
- Halaman Pengaturan tetap layar penuh seperti sebelumnya; tombol roda gigi di header dihapus.
- Back saat drawer terbuka hanya menutup drawer. Halaman utama tetap Hari ini.

Scrim
- Gelap sekitar 34% dan konten di belakang drawer dikaburkan (blur 10 dp, animasi halus). Blur memakai `Modifier.blur`, hanya aktif di Android 12 (API 31) ke atas; di versi lebih lama scrim dibuat lebih gelap (50%) sebagai pengganti.
- Konten berupa tampilan peta bawaan sistem (AndroidView) bisa tidak ikut kabur di sebagian perangkat; scrim gelap tetap tampil.

Header
- Foto profil sekarang membuka drawer (sebelumnya membuka Profil). Nama tidak lagi bisa diketuk, kecuali bila nama masih kosong (membuka Pengaturan).

Berkas berubah:
- ui/AppRoot.kt (dock dan `bottomBar` dihapus, `ModalNavigationDrawer` + `AppDrawerSheet`, header), assets/i18n/en.tsv ("Buka menu", "Pelari")

Belum dikompilasi dan diuji di perangkat: perlu build ulang APK.
