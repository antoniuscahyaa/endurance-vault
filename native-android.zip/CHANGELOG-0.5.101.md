# 0.5.101

Menu ⋮ di detail aktivitas → **Bagikan statistik**.

## Pilihan di layar
- **Periode:** Harian (aktivitas yang dibuka), Mingguan (Senin sampai Minggu), Bulanan (tanggal 1 sampai akhir bulan). Minggu/bulan diambil dari tanggal aktivitas yang dibuka.
- **Template (11):** Klasik, Poster, Cincin target, Struk, Nomor dada, Kalender, Kaca, Kurva, Banding, Ubin, Strip.
  - Cincin target hanya muncul bila ada rencana pada periode itu (jarak rencana dari plan).
  - Banding hanya muncul bila ada pembanding: minggu lalu, bulan lalu, atau rata-rata per lari 28 hari terakhir (untuk harian).
  - Kalender tidak untuk harian. Kurva untuk harian butuh minimal 2 split (pace per km).
- **Latar:** Solid (warna bawaan template, kebanyakan gelap; Poster oranye, Struk krem, Nomor dada putih), Foto (galeri, dipotong tengah, diberi lapisan gelap tipis), Transparan (PNG).
- **Ukuran:** Feed 4:5 (1080 x 1350) atau Story Instagram 9:16 (1080 x 1920). Story punya layout sendiri, bukan kartu feed yang ditaruh di tengah: judul turun ke bawah bilah profil Instagram (y ≈ 290), visual/grafik/kalender melebar mengisi zona tengah, statistik turun ke atas bilah balasan (selesai ≈ y 1700), dan latar/pita (Nomor dada, Struk, Poster) memenuhi kanvas penuh. Strip selalu 1080 x 420.
- **Judul kartu:** bawaan "EnduranceVault", bisa diganti (maks 24 karakter, kosong = bawaan, tombol Reset). **Ikon aplikasi** tampil di sebelah kiri judul. Judul dan template terakhir diingat.
- Simpan (galeri) dan Bagikan (share sheet) memakai `StickerIo`.

## Grafik pace harian per segmen
Bila aktivitas punya segmen, grafik pace memakai segmen (batang selebar jarak, setinggi kecepatan, berwarna menurut peran, legenda di bawah). Lap tanpa label dikenali lewat `IntervalAnalysis` (cepat-lambat): Repetisi, Istirahat, Pemanasan, Pendinginan. Label buatan pengguna tidak ditimpa. Tanpa segmen: pace per km.

## Teknis
- Baru: `domain/PeriodStats.kt`, `domain/ShareSegments.kt`, `ui/sticker/ShareCardRenderer.kt`, `ui/sticker/ShareTemplates.kt`, `ui/sticker/ShareBrandIo.kt`, `ui/screens/ShareStatsScreen.kt`.
- Tes: `PeriodStatsTest`, `PeriodCompareTest`, `ShareSegmentsTest`, `ShareTitleTest`.
- Diubah: `ActivityDetailScreen.kt` (parameter `onOpenShareStats` + item menu), `AppRoot.kt` (rute `sharestats/{id}`).
- Hanya lari yang dihitung (sepeda dan jarak 0 dilewati). HR rata-rata berbobot durasi.
- **Belum dijalankan di lingkungan ini:** build Gradle, uji unit, dan tampilan di perangkat. Jalankan CI lalu cek tiap template di HP (Feed/Story × Solid/Foto/Transparan × Harian/Mingguan/Bulanan), terutama: judul panjang, minggu lintas bulan, Februari, foto potret/lanskap, aktivitas tanpa rute, aktivitas tanpa rencana (Cincin hilang), dan ikon di sebelah judul.
