# EnduranceVault Native 0.5.34: detail lari dari jam kini lengkap (HR, kadens, elevasi)

## Masalah
Detail lari hasil sinkron jam tidak menampilkan HR per titik, kadens, dan elevasi (grafik kosong, D+/D− keliru atau kosong),
padahal data itu sudah ada di database jam setelah autosync.

## Penyebab
Jam menyimpan dua aliran terpisah di tabel `workout_points`:
- titik GPS: `lat`/`lon` (+ altitude GPS bila didukung), **tanpa** HR dan kadens;
- sampel data: HR, kadens, dan altitude barometer, **tanpa** `lat`/`lon`.

`MainViewModel.watchPointsToGpx()` membuang semua baris tanpa `lat`/`lon`, sehingga seluruh sampel HR, kadens, dan
altitude barometer tidak pernah sampai ke `ActBuilder`. Selain itu aktivitas yang sudah pernah diimpor tidak pernah
dibangun ulang (`similarExisting?.detailFile == null`), jadi aktivitas lama tetap kosong walau impor diperbaiki.

## Perbaikan
- `data/WatchTrackMerge.kt` (baru): menempelkan HR dan kadens sampel terdekat serta altitude barometer hasil
  interpolasi ke tiap titik GPS (selisih waktu maks 15 dtk; celah lebih panjang dibiarkan kosong). Altitude barometer
  dipakai bila ada ≥ 10 sampel, selain itu altitude GPS.
- `MainViewModel.importWatchData`: memakai penggabung di atas langsung ke `ActBuilder` (tanpa perantara GPX), menandai
  detail dengan `wv = 2`, dan **membangun ulang detail hasil impor jam yang lebih lama** dari titik yang sudah ada di
  database jam. Detail dari impor FIT/GPX manual (tanpa kunci `watch`) tidak disentuh.
- Olahraga sepeda sekarang dibangun sebagai `bike` (sebelumnya sport tidak diteruskan sehingga diperlakukan sebagai lari).
- `ProtocolBridge.readWorkouts` meneruskan `elevationGain/Loss`, `min/maxAltitude`, `avgAltitude` dari ringkasan jam.
  Dipakai sebagai cadangan D+/D− bila rute tidak punya altitude, dan untuk workout tanpa GPS.
- D+ aktivitas yang detailnya dibangun ulang diganti dengan nilai baru; avg/max HR yang kosong diisi dari rute.
- `ActStore.watchVersion()`: membaca versi detail jam tanpa memuat berkas penuh.
- Tes baru `WatchTrackMergeTest` (9 tes). Versi 0.5.34, version code 48.

## Cara memperbaiki aktivitas lama
Buka tab **Jam** lalu tekan **Sinkron**. Sinkron biasa mencakup 45 hari terakhir; untuk yang lebih lama pakai
**Ambil seluruh riwayat** (maks 100 workout). Aktivitas yang sudah ada di Activity Log diperbarui di tempat, tidak digandakan.

## Batasan
- Autosync hanya menyimpan ke database jam; impor ke Activity Log tetap terjadi lewat Sinkron.
- Workout tanpa GPS (treadmill) belum punya rute/grafik; hanya HR rata-rata/maks, D+ dari jam, dan ringkasan.
- Kode belum dikompilasi dan tes belum dijalankan di lingkungan ini (tidak ada Kotlin/Gradle); jalankan CI.
