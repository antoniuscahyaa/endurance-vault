# EnduranceVault Native 0.5.55: lap jam ikut autosync

Versi 0.5.55, version code 69.

## Temuan
Jam sebenarnya sudah mengunduh blok `sections` tiap workout (Workout 17/16) dan menyimpannya di `summary_json`, tetapi jembatan hanya meneruskan nomor, jarak, dan kadens, dan aplikasi tidak memakainya. Detail hasil autosync karena itu tidak pernah punya segmen (`sg`); segmen hanya datang dari impor FIT.

## Perubahan
- Jembatan jam kini meneruskan waktu, jarak, pace, HR, kadens, dan jenis interval tiap blok; `summary_json` ikut menyimpan jenis interval.
- **Lap jam menjadi segmen** (tanpa label) untuk aktivitas baru dari autosync. Yang dipakai hanya **jarak tiap blok** sebagai batas pada deret 1 Hz; pace, HR, kadens, dan elevasi segmen dihitung dari data per detik.
- **Blok per km otomatis dilewati** (semua blok sekitar 1 km), karena sudah ada di tabel "Per km". Editor segmen untuk lari seperti itu tetap membuka "Susun sesi".
- **Pengaman satuan**: jumlah jarak blok harus cocok dengan total sesi (selisih <= 10%); bila tidak, tidak ada segmen yang dibuat.
- **Detail lama dilengkapi** tanpa membangun ulang berkas: sekali per aktivitas (penanda `sgw`), maksimal 30 per putaran sinkron, tidak pernah menimpa `sg` yang sudah ada (lap FIT atau pembagian manual), sesi yang di-crop dilewati.

## Teknis
- `domain/WatchLaps.kt` (baru), `MainViewModel.watchLapMaps` / `backfillWatchLaps`, `LAP_BACKFILL_PER_SYNC`. `WatchTrackMerge.VERSION` tidak dinaikkan.
- Tes: `WatchLapsTest`.

## Catatan
- **Belum diverifikasi di jam asli**: satuan `distance` pada blok diasumsikan meter (dijaga oleh pengaman di atas), dan belum diketahui apakah sesi interval/lap manual benar-benar menghasilkan blok per lap atau tetap per km. Bila setelah sinkron lap tidak muncul, kirim isi `sections` dari catatan jam (kolom `summary_json`) dari satu sesi interval untuk disesuaikan.
- Belum dikompilasi dan tes belum dijalankan di lingkungan ini. Jalankan CI.

## Elevasi segmen mengikuti kalibrasi jam
- Elev. Gain/Loss tiap segmen kini dikalikan faktor kalibrasi yang sama dengan tabel per km (total jam dibagi hitungan aplikasi, dibaca dari `gain`/`gainRaw` dan `loss`/`lossRaw`), jadi jumlah segmen sejalan dengan total aktivitas. Berlaku untuk segmen dari Susun sesi, editor manual, dan lap jam. Tanpa kalibrasi atau rasio tidak masuk akal (di luar 0,2 sampai 5) faktornya 1.
- `ElevationCalibration` tidak diubah. Segmen yang sudah tersimpan sebelumnya baru ikut berubah bila disimpan ulang.
- `SegmentSplit.elevScales` (baru); tes `segmentElevationFollowsWatchCalibration`.
