# EnduranceVault Native 0.5.51: peta di dialog Kirim rute ke jam

Versi 0.5.51, version code 65.

## Perubahan
- **Indikator km** kini berupa **ikon saja** (penggaris), bukan kotak "Indikator km" + switch. Ketuk untuk menyalakan/mematikan; menyala = ikon oranye berlatar lembut.
- Peta di dialog **Preview rute GPX** kini punya **latar peta** (ubin), bukan lagi garis polos di atas warna kosong.
- **Pilihan gaya peta** berupa tiga ikon (tanpa teks): **Default** (OpenStreetMap), **Satelit** (Esri World Imagery), **Topografi** (OpenTopoMap).
- Ikon km dan ketiga ikon gaya peta dikelompokkan dalam satu pil di **kanan atas panel peta** (km | default, satelit, topografi).
- Gaya terakhir yang dipilih diingat saat dialog dibuka lagi selama aplikasi hidup (bawaan: Default).
- Atribusi sesuai gaya peta ditampilkan kecil di kiri atas peta.

## Teknis
- `RouteMap` di `GpxPreviewDialog.kt` dipindah dari proyeksi equirectangular ke **Web Mercator** (memakai `RouteGeo`), supaya jalur tepat di atas ubin. Gestur tetap: cubit (maks. 8x di atas tampilan pas-rute), geser, ketuk dua kali, tombol Reset, zoom pas ke ruas yang diketuk, penanda km, dan penanda ruas strategi.
- `MapTiles.load(context, tile, style)` dan `enum MapStyle` (URL, folder cache, zoom ubin maksimum, atribusi) di `data/MapTiles.kt`. Peta default tetap memakai folder cache lama `osm-tiles`; gaya lain memakai `tiles-satelit` dan `tiles-topo`. `DRouteMapView` (detail aktivitas) tidak berubah.
- Zoom ubin dibatasi 18 (default) dan 17 (satelit, topografi); di atasnya ubin diperbesar, bukan diminta ulang, supaya tidak muncul ubin kosong.
- Tes baru: `RouteGeoTest.urlUbinPerGayaPeta`.

## Catatan
- Memuat peta mengirim nomor ubin (kira-kira area rute) ke tile.openstreetmap.org, server.arcgisonline.com, atau tile.opentopomap.org sesuai gaya yang dipilih. Ubin di-cache 14 hari; rute yang pernah dibuka tetap bermap saat offline. Tanpa jaringan dan cache, jalur tetap tampil dengan catatan "Peta dasar offline".
- Server ubin publik ditujukan untuk pemakaian ringan; bila aplikasi dirilis luas, pindah ke penyedia ubin sendiri/berbayar (ubah `MapStyle.url`).
- Pada Esri, cakupan citra resolusi tinggi di daerah terpencil bisa bervariasi.
- Belum dikompilasi dan tes belum dijalankan di lingkungan ini (tidak ada Gradle/Kotlin). Jalankan CI. Gestur dan tata letak ikon perlu dicoba di perangkat.
