# EnduranceVault Native 0.5.61: Stiker data, ukuran, warna teks kustom, sampai 6 kolom

Version code 75.

## Baru
- **Ukuran stiker**: slider 50% sampai 300% (preset 50, 75, 100, 150, 200). Mengubah ukuran piksel PNG; gambar digambar ulang pada skala itu, jadi tetap tajam, bukan diperbesar dari bitmap kecil. Sisi terpanjang PNG dibatasi 4096 px agar memori aman. Di Pratinjau foto, lebar stiker tetap diatur lewat slider "Ukuran stiker terpilih" (persen dari bingkai); skala di sini menentukan ketajamannya.
- **Warna teks kustom**: chip **Kustom…** di samping Putih, Hitam, Lime (slider RGB atau kode hex). Warna terang otomatis diberi bayangan dan pratinjau berlatar gelap (seperti Putih); warna gelap tanpa bayangan dan berlatar terang (seperti Hitam). Memilih Putih/Hitam/Lime menghapus warna kustom.
- **Angka per baris sampai 6** (sebelumnya 4). Untuk 5 dan 6 kolom, lebar kolom, ukuran angka, dan huruf label diperkecil (label 26 px) agar muat; label panjang seperti "Elevasi naik" dapat terpotong dengan "…" pada 6 kolom.

## Teknis
- `StickerPrefs`: `inkCustom`, `scale`; `cols` kini 2..6 (`Stickers.MAX_COLS`). `StickerPalette` membawa `scale`; `Sk` membuat bitmap berukuran `lebar x skala` dan menskalakan kanvas, sehingga semua koordinat tetap satuan logis yang sama dengan sebelumnya.
- Tes: `kolomEnamUkuranDanWarnaTeksKustom`.
- Belum dikompilasi di lingkungan pembuatnya; periksa hasil CI.
