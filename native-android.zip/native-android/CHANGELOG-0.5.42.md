# EnduranceVault Native 0.5.42: dock Minggu lebih rapat

Versi 0.5.42, version code 56.

## Perubahan
- Dock Minggu dipadatkan tanpa menghapus data: font kartu rencana, statistik pekan, zona HR, dan kartu hari diperkecil 1–4 sp; padding kartu dan jarak antar kartu dirapatkan (12 → 8 dp); tab This week / History 44 → 36 dp; bar, lingkaran selesai, chip Logged, dan tombol Detail/Share diperkecil.
- Judul kartu rencana 20 → 16 sp sehingga "Performance Build · 3:1 · Threshold focus" muat lebih rapat.

## Kode
- `ui/screens/WeekDock.kt` dan `ui/screens/ScheduleScreen.kt`: hanya ukuran font, padding, dan jarak.

## Validasi
- Belum dikompilasi di lingkungan ini; cek tampilan di perangkat.
