# EnduranceVault Native 0.5.57: label segmen teks bebas, nama segmen = label, elevasi per segmen

Versi 0.5.57, version code 71.

## Perubahan
- **Dropdown label di daftar segmen dihapus.** Pill tidak bisa diketuk lagi; label diubah lewat editor ("Ubah pembagian segmen").
- **Label teks bebas** (maks. 24 karakter, boleh kosong) di **Susun sesi** dan **editor manual**, lengkap dengan chip saran (Pemanasan, Repetisi, Stride, Progresif, Istirahat, Pendinginan; untuk istirahat: Istirahat, Jogging pelan). Chip hanya mengisi kolom teks.
  - Susun sesi: tiap blok punya kolom label; blok Ulangi punya label kerja dan label istirahat terpisah. Isian awal: Pemanasan = "Pemanasan", kerja = "Repetisi", sisanya kosong.
  - Editor manual: kolom teks menggantikan tiga chip jenis.
- **Daftar segmen memakai label sebagai nama** (tanpa "Segmen 1"); tanpa label tampil "Tanpa label". Label bawaan (Repetisi, Stride, Progresif) tetap berwarna seperti sebelumnya, label buatan sendiri berwarna ungu (juga di grafik editor).
- **Elev. Gain dan Elev. Loss per segmen** tampil di bawah tiap baris segmen (nilainya sudah tersimpan di data segmen dan mengikuti kalibrasi jam).
- **GAP pace dan Effort pace per segmen** (bukan sepeda) tampil di baris berikutnya. GAP diperkirakan dari pace dan kemiringan bersih segmen (gain − loss per jarak, rumus Minetti yang sama dengan fallback tabel per km); Effort pace memakai koreksi panas sesi yang sama dengan kartu statistik. Segmen di bawah 50 m atau tanpa data elevasi tidak menampilkan keduanya. Tidak ada perubahan data tersimpan.

## Data
- Teks label disimpan di kunci baru `lb` pada objek segmen (`sg`). Kunci `ty` tetap terisi bila teks sama dengan salah satu jenis bawaan (tanpa memperhatikan huruf besar/kecil). Segmen lama yang hanya punya `ty` tetap tampil dengan nama jenisnya, dan `ty` lain dari impor FIT tetap dianggap tanpa label. Tidak perlu migrasi.

## Teknis
- `SegKind.clean/kindOf/displayLabel`, `SegmentSplit.Draft` jadi `data class` dengan `label` dan `withText`, `SegmentSplit.draft`, `Segment.label`, `SessionBuilder.Block.Plain.label`, `Block.Repeat.workLabel/restLabel`.
- Dihapus: `SegmentKindPill`, `SegmentSplit.withKind`, `MainViewModel.setSegmentKind`, parameter `onSetSegmentKind`.
- Baru: `SegmentLabelField`, `segLabelColor`, `CustomLabelColor`.
- `ActInsights.gapOfSegment`; tes `segmentGapFollowsNetGradeAndSkipsShortOrFlatUnknown`.
- Tes: `freeTextLabelsRoundTripAndKeepBuiltInKinds`, `labelCleaningAndLegacyKinds` (SegmentSplitTest), `blockLabelsReachTheDrafts` (SessionBuilderTest); tes `withKind` dihapus.

## Catatan
- Belum dikompilasi dan tes belum dijalankan di lingkungan ini (tanpa akses unduh dependensi Gradle). Jalankan CI.
