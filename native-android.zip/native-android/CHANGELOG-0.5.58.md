# EnduranceVault Native 0.5.58: Stiker data (port tahap pertama)

Versi 0.5.58, version code 72. Port fitur **Stiker data** dari web (`src/js/main/10c-stiker-data.js`, `34-stiker-data.css`).

## Cara membuka
Detail aktivitas → menu ⋮ → **Stiker data**. (Pemilih sesi dan jalan masuk dari Profil belum ada; layar selalu memakai aktivitas yang sedang dibuka.)

## Sudah diport
- **Baris angka**: jarak, pace, waktu, elevasi naik, HR rata-rata, kadens, GAP. Urutan mengikuti ketukan chip, 2/3/4 angka per baris, format *Satu kartu* atau *Satu per satu*. Data yang tidak ada tidak ditawarkan.
- **Template peta**: garis rute + titik awal (warna aksen) dan akhir, data di bawah atau di samping, tiap data bisa dimatikan. Tanpa tile peta, tetap transparan.
- **Bar dan grafik**: tabel segmen, bar segmen, **bar pace per segmen** (sorot tercepat + garis rata-rata, garis HR opsional), split per km, grafik elevasi, zona HR sesi, zona HR bar tumpuk (label berdempetan digeser + garis penuntun).
- **Pengaturan**: warna teks (putih/hitam/lime), warna aksen (7 warna), panel latar (mati/tipis/tebal), zona HR tampil sebagai (durasi dan persen / durasi / persen). Tersimpan di SharedPreferences `sticker_prefs`.
- **Paket sesi**: pilih stiker, *Simpan paket* menyimpan semua dengan nomor urut (`trainingplan-01-angka-<tanggal>.png`). *Simpan semua* dan tombol Simpan per item.
- **Pratinjau di foto**: foto dari galeri (diputar sesuai EXIF), rasio Asli / 9:16 / 4:5 / 1:1, slider geser bingkai, sampai 5 stiker (isi dan ukuran sendiri, diseret langsung di foto), *Tempel otomatis* (tepi 4% dan tengah, garis bantu), *Simpan foto dengan stiker* (PNG, sisi terpanjang maks. 2560 px) dan *Bagikan* lewat lembar berbagi.
- Nama berkas sama dengan web: `trainingplan-<item>-<tanggal>.png`.

## Penyesuaian terhadap versi native
- **Segmen**: web memakai tipe warm-up/work/tempo/rest/cool-down; native memakai label bebas. Aturannya dipetakan begini:
  - Nama baris = label segmen, tanpa label tampil "Tanpa label" (sama dengan daftar segmen 0.5.57). Baris tidak disembunyikan.
  - Warna titik/bar: Repetisi oranye Ember, Stride biru, Progresif hijau, label buatan sendiri ungu, tanpa label netral (sama dengan editor segmen).
  - Bar pace per segmen: bila ada segmen berlabel bawaan, hanya **Repetisi dan Progresif** yang penuh dan dihitung untuk sorotan/rata-rata; sisanya dipudarkan. Tanpa label bawaan, semua segmen dihitung.
- **Penyimpanan**: Android 10+ ke galeri (`Pictures/TrainingPlan`) tanpa izin. Android 9 ke bawah ke folder foto milik aplikasi (menulis ke galeri butuh izin penyimpanan yang tidak diminta aplikasi ini). Web memakai plugin MediaSaver dan cadangan Documents/TrainingPlan.
- **Huruf**: web memakai Barlow / Barlow Condensed; native memakai `sans-serif-condensed` dan `sans-serif-medium` bawaan Android, jadi lebar teks sedikit berbeda.
- **Berbagi**: berkas ditulis ke `cache/stickers/` lalu dikirim lewat `FileProvider` (`${applicationId}.fileprovider`, ditambahkan di manifest dan `res/xml/file_paths.xml`). Berkas cache lebih dari 24 jam dihapus saat berbagi berikutnya.
- Bahasa: hanya Indonesia (teks Inggris menunggu tahap 10).

## Belum diport (butuh data yang belum ada di native)
| Stiker web | Yang dibutuhkan |
|---|---|
| Angka interval (repetisi, pace interval, tercepat, fade, HR awal→akhir), **Pace per repetisi** | port `ivDetect` / `ivStats` (`08b-analisis-interval.js`) |
| Angka **TE** dan **Training load** | TE per sesi dan load per hari dari `TrainingMetrics` perlu dikaitkan per aktivitas |
| **Vs PR** | port `prCalc` / `PRDEF` untuk satu sesi dan PR sebelum hari itu |
| **Vs rute serupa** | `ProgressAnalytics.similarRoutes` ada, tetapi `mxOf`, `mxYoyPick`, `mxYoyHr` belum |
| **Angka minggu, Zona HR minggu, Target minggu, Tren pace** | ringkasan minggu rencana (`weekSummary`: km, waktu, sesi, zona, hari rencana vs aktual) |
| Warna kustom bebas (pemilih warna) untuk aksen dan warna bar mingguan | UI pemilih warna |
| Pemilih sesi di dalam layar, jalan masuk dari Profil | dropdown sesi |

## Teknis
- Baru: `domain/Stickers.kt` (model, pengaturan, ketersediaan), `ui/sticker/StickerRenderer.kt` (Canvas → Bitmap ARGB transparan, satuan piksel sama dengan web), `ui/sticker/StickerIo.kt` (galeri, berbagi, foto, penggabung, geometri bingkai, tempel otomatis), `ui/screens/StickerScreen.kt`.
- Diubah: `AppRoot` (rute `sticker/{id}`), `ActivityDetailScreen` (menu "Stiker data", parameter `onOpenSticker`), `AndroidManifest.xml` (FileProvider), `res/xml/file_paths.xml`.
- Tes: `StickerModelTest` (format angka, pembersihan pengaturan, ketersediaan grafik, label segmen, id paket, nama berkas, geometri foto, tempel otomatis, batas 5 stiker). Penggambar belum dites otomatis (butuh Robolectric atau tes instrumentasi).

## Catatan
- **Belum dikompilasi dan tes belum dijalankan** di lingkungan pembuatnya (tanpa Kotlin/Gradle dan tanpa akses unduh). Jalankan `./gradlew testDebugUnitTest` lalu bangun APK di CI dan periksa tampilan stiker di perangkat; tampilan teks (ukuran/lebar) paling mungkin perlu disetel karena memakai huruf sistem.
