# EnduranceVault Native 0.5.37: halaman Zona intensitas

Versi 0.5.37, version code 51. Melanjutkan 0.5.36 (dua tombol LTHR/HRR).

## Zona HR (Default)
- Bar Z1–Z5 berwarna di atas tabel; lebar tiap zona proporsional dengan rentang bpm dan berubah saat persen diedit.
- Kolom persen yang salah (tidak naik, kosong, kurang dari 0, melebihi batas) bergaris merah, dengan satu kalimat alasan di bawah tabel. Zona memakai nilai awal sampai diperbaiki (aturan lama tidak berubah).
- Status kirim bertahan antar sesi: "Terakhir dikirim: LTHR · 7 Nov 18.40 · berhasil/gagal". Bila zona yang akan dikirim berubah sesudahnya, muncul "Zona berubah sejak dikirim terakhir … Tahan tombol … untuk kirim ulang agar jam ikut." Perbandingan memakai batas bpm yang benar-benar dikirim, bukan sekadar edit persen.
- Petunjuk "Tahan tombol untuk kirim zona ke jam" (tanpa ikon) tampil menonjol sampai tiga kali kirim, sesudah itu mengecil.
- Aksesibilitas: label klik dan tahan pada tombol ("Pilih LTHR dan lihat zona", "Kirim zona LTHR ke jam") untuk TalkBack.

## Tab Zona HR di Profil
- Batas HR easy, Rentang HR threshold, dan Pace easy dipindah ke `ZoneIntensityFields`: validasi langsung (HR 80–220, rentang naik mis. 164–172, pace m:ss 3:00–12:00) dan keterangan "Dipakai" dibanding zona default. Batas easy yang berbeda dari batas atas Z2 punya tombol "Samakan dengan zona".
- Saran pace easy: rata-rata 5 lari easy terakhir (HR rata-rata sampai batas easy, bukan sepeda, tidak lebih dari 20 m D+ per km), dibobot jarak, dengan tombol "Pakai". Bila pace sudah sesuai, tombol tidak muncul.
- Ketiga isian tersimpan otomatis (fokus hilang, Done, Samakan, Pakai) bila semuanya valid. Sebelumnya isian ini hanya tersimpan lewat tombol di tab Rencana. Kunci state hr/thr/pace dipisah dari kunci form lain, jadi simpan otomatis tidak mereset isian tab Rencana yang belum disimpan.

## Kode
- Baru: `domain/ZoneChecks.kt`, `ui/screens/ZoneIntensityFields.kt`, `ZoneChecksTest` (pace, rentang threshold, HR easy, urutan persen, rata-rata lari easy).
- Diubah: `domain/EasyPace.kt` (`recentAverage`), `ui/screens/HrZoneSettings.kt`, `ui/screens/ProfileScreen.kt`, `app/build.gradle.kts`.

## Validasi
- Keseimbangan kurung dicek di sumber dan perhitungan tes dicek manual. Gradle Android belum dijalankan di lingkungan ini; jalankan CI (termasuk `ZoneChecksTest`) untuk memastikan kompilasi.
