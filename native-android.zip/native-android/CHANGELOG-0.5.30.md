# EnduranceVault Native 0.5.30

- Removed the duplicate Profile/Progress chips above the bottom navigation dock. The in-content Profile/Progress tabs remain.
- Replaced the large profile-header edit button with a Settings button. It opens Profile > Rencana settings. Name editing remains on the profile name row.
- Reworked Morning Condition leg-feel choices into consistent outlined/selected buttons and mood choices into five equal cards with larger emoji and numeric labels, retaining the 1–5 values and save behavior.
- Version code 44; version name 0.5.30.

Validation: source-level inspection and ZIP integrity check only. Android Gradle compilation and emulator rendering have not been run in this environment.
