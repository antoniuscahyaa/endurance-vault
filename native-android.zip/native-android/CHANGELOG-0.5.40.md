# EnduranceVault Native 0.5.40: Jadwal, minggu dibuka dengan expand

Versi 0.5.40, version code 54.

## Perubahan
- Dock Jadwal: mengetuk satu baris minggu (W1–W4 dst.) kini membuka (expand) semua jadwal minggu itu di tempat, di bawah baris tersebut. Sebelumnya membuka sheet dari bawah. Ketuk lagi untuk menutup; beberapa minggu boleh terbuka bersamaan.
- Tiap baris minggu menampilkan keterangan kecil "+N strength" di bawah rentang tanggal (jumlah sesi gym + ankle + upper minggu itu). Tidak tampil bila 0.
- Tinggi baris minggu kini minimal, bukan tetap, agar keterangan tambahan tidak terpotong. Penanda ▾/▴ di ujung kanan menunjukkan status expand.

## Kode
- `ui/screens/PlanOverviewScreen.kt`: `ModalBottomSheet` dan `sheetWeek` dihapus; `expanded` (daftar indeks minggu) disimpan lewat `rememberSaveable`. `WeekRowCompact` memuat `DayCard`/`StrengthCard` di dalam `AnimatedVisibility`.

## Validasi
- Belum dikompilasi di lingkungan ini; jalankan CI dan cek di perangkat.
