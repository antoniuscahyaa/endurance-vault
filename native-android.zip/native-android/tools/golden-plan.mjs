// Menghasilkan data acuan (golden) dari plan() versi web agar port Kotlin bisa dicocokkan.
// Jalankan dari akar proyek web (folder yang berisi src/ dan tests/):  node native-android/tools/golden-plan.mjs
import fs from 'node:fs';
import { load } from '../../tests/helpers.mjs';

const FNS = ['plan','parse','iso','addDays','diffDays','pad','r50','f10','gSum','gainTarget','gainSet','gainSpread','idn','wt','restCfg','weekRoles',
  'pbLen','pbFocusOf','pbWeights','pbPostWeeks','pbAkOf','pbAkLevel','qDetail','qParse','thrBand','ltBand','hrMaxEst','racePaces','raceKmOf','raceDetail',
  'rcOf','roadQ','roadLong','qEasyPace','qualEst','qualBalance','paceStr','parsePaceStr','parseDur','durStr','fmtKm','placeStrength','strengthFor','ankleFor',
  'DS','upperFor','q2Stage','q2Apply','q2Slot','q2Allowed','q2Pool','q2Make','methodQuality','methodEasy','tmOf','tmName','tmInfo','tmZ3',
  'tmQ2','tmStrides','tmTempo','tmHard','tmAdvice','sum5','zoneCutsFor','zcut','restHr'];
const g = { LANG: 'id', L: (a) => a, easyPaceEst: undefined, log: {}, daily: {}, TODAYD: new Date(2026, 10, 5, 12), TODAY: '2026-11-05', UNG_KM: 7, UNG_GAIN: 750,
  MON: [], DOW: [], tpEn: () => false };
const OVER = `var ZLD=[85,90,95,100], ZRD=[50,60,70,80,90]; var W={long:.34,quality:.15,medium:.15,easy:.13,short:.10}; var CW=W; var REST_OK=[6,5,3,2];
var UNG_KM=7, UNG_GAIN=750; var GAIN_STEP=.10, GAIN_CUT=.8, GAIN_PK3=.9, GAIN_LONG_MAX=.55, GAIN_W={long:.35,medium:.25,hike:.30,easy:.20}, GAIN_CEIL=1.5;`;
import { readFileSync } from 'node:fs';
const SRC05 = readFileSync(new URL('../../src/js/main/05-lomba-tema-prediksi.js', import.meta.url), 'utf8');
const RC_BLOCK = SRC05.match(/var RCFG=\{[\s\S]*?\n\};\nvar RBAND=\{[\s\S]*?\};/)[0];
const Q2_BLOCK = SRC05.match(/var Q2_TYPES=\{[^\n]*\n/)[0];
const SRC02B = readFileSync(new URL('../../src/js/main/02b-metode-latihan.js', import.meta.url), 'utf8');
const TM_BLOCK = ['var TM_KEYS=[^\\n]*\\n', 'var TM_TARGET=[^\\n]*\\n', 'var TM_HARD=[^\\n]*\\n'].map((re) => SRC02B.match(new RegExp(re))[0]).join('\n');
const Q2N_BLOCK = SRC05.match(/var Q2_NOTE=\[[\s\S]*?\n\];/)[0];
let ctx;
try { ctx = load(FNS, g, OVER + '\n' + RC_BLOCK.replace('var CW=W;','') + '\n' + Q2_BLOCK + '\n' + Q2N_BLOCK + '\n' + TM_BLOCK); } catch (e) { console.error('LOAD GAGAL:', e.message); process.exit(1); }
console.log('loaded ok', typeof ctx.plan);

const base = { name: 'Uji', raceKm: '', start: '2026-11-02', race: '', base: 40, peak: 65, days: 5, rest: 0, rest2: 4, longDay: 6, hr: 150, thr: '164–172',
  pace: '6:30', rtype: 'hm', pbCycle: '3', pbFocus: 'mix', qSess: '1', method: 'default', raceGain: '', gBase: '', goalT: '', hrmax: '', sLeg: true, sAnk: true,
  sUp: 'auto', gSmooth: false, evOn: false, evDate: '', evKm: '', evGain: '', bspd: 20 };
const SC = {
  'hm-5d': { race: '2027-02-21' },
  'hm-5d-goal': { race: '2027-02-21', goalT: '1:45:00' },
  '5k-6d': { rtype: '5k', days: 6, race: '2027-01-10', base: 30, peak: 45 },
  '10k-6d-bike': { rtype: '10k', days: 6, race: '2027-02-07', base: 35, peak: 55, goalT: '50:00' },
  'fm-5d': { rtype: 'fm', race: '2027-04-18', base: 50, peak: 85, goalT: '3:45:00' },
  'fm-6d-longsat': { rtype: 'fm', days: 6, longDay: 5, rest: 1, race: '2027-04-18', base: 50, peak: 85 },
  'none': { rtype: 'none' },
  'pb-mix': { rtype: 'pb', base: 40, peak: 60 },
  'pb-thr-c2': { rtype: 'pb', pbFocus: 'thr', pbCycle: '2', days: 6 },
  'pb-vol-c4': { rtype: 'pb', pbFocus: 'vol', pbCycle: '4' },
  'pb-vo2': { rtype: 'pb', pbFocus: 'vo2', pbCycle: '3', days: 6 },
  'pb-post2': { rtype: 'pb', pbPost: { rec: 2, lvl: 60 }, start: '2026-11-09' },
  'pb-post1': { rtype: 'pb', pbPost: { rec: 1, lvl: 50 }, start: '2026-11-09', days: 6 },
  'pb-ak': { rtype: 'pb', pbAk: { wk: '2027-01-04', km: 45 } },
  'hm-conv': { rtype: 'hm', race: '2027-04-18', pbConv: { wk: 4, b0: 30, p0: 50 } },
  'ultra-50': { rtype: 'ultra', raceKm: 50, raceGain: 2400, race: '2027-05-30', base: 55, peak: 75, days: 6 },
  'ultrar-6d': { rtype: 'ultrar', raceKm: 100, race: '2027-06-27', base: 55, peak: 80, days: 6 },
  'ultra-5d': { rtype: 'ultra', raceKm: 40, raceGain: 1800, race: '2027-04-04' },
  'hm-event': { race: '2027-02-21', evOn: true, evDate: '2026-12-13', evKm: 10, evGain: 0 },
  // tahap 1b: metode latihan
  'hm-pyr': { race: '2027-02-21', method: 'pyramidal', goalT: '1:45:00' },
  'hm-pol': { race: '2027-02-21', method: 'polarized', goalT: '1:45:00' },
  'hm-maf': { race: '2027-02-21', method: 'maf' },
  '10k-6d-pyr': { rtype: '10k', days: 6, race: '2027-02-07', base: 35, peak: 55, goalT: '50:00', method: 'pyramidal' },
  '10k-6d-pol': { rtype: '10k', days: 6, race: '2027-02-07', base: 35, peak: 55, goalT: '50:00', method: 'polarized' },
  'fm-6d-pyr-hrr': { rtype: 'fm', days: 6, race: '2027-04-18', base: 50, peak: 85, goalT: '3:45:00', method: 'pyramidal', zm: 'hrr', rhr: 52, hrmax: 188 },
  'fm-5d-pol-lthr': { rtype: 'fm', race: '2027-04-18', base: 50, peak: 85, method: 'polarized', lthr: 168 },
  'pb-maf': { rtype: 'pb', base: 40, peak: 60, method: 'maf', days: 6 },
  'pb-pyr': { rtype: 'pb', base: 40, peak: 60, method: 'pyramidal', pbFocus: 'vo2' },
  'ultra-pyr': { rtype: 'ultra', raceKm: 50, raceGain: 2400, race: '2027-05-30', base: 55, peak: 75, days: 6, method: 'pyramidal' },
  'ultra-pol': { rtype: 'ultra', raceKm: 50, raceGain: 2400, race: '2027-05-30', base: 55, peak: 75, days: 6, method: 'polarized' },
  'ultrar-pol': { rtype: 'ultrar', raceKm: 100, race: '2027-06-27', base: 55, peak: 80, days: 6, method: 'polarized' },
  // tahap 1b: sesi quality kedua
  '5k-q2': { rtype: '5k', days: 6, race: '2027-01-10', base: 30, peak: 45, qSess: '2', goalT: '22:00' },
  '10k-q2': { rtype: '10k', days: 6, race: '2027-02-07', base: 35, peak: 55, qSess: '2', goalT: '50:00' },
  'hm-q2': { rtype: 'hm', days: 6, race: '2027-02-21', base: 40, peak: 65, qSess: '2', goalT: '1:45:00' },
  'fm-q2': { rtype: 'fm', days: 6, race: '2027-04-18', base: 50, peak: 85, qSess: '2' },
  'fm-q2-5d': { rtype: 'fm', days: 5, race: '2027-04-18', base: 50, peak: 85, qSess: '2' },
  'pb-q2-vo2': { rtype: 'pb', days: 6, pbFocus: 'vo2', qSess: '2' },
  'pb-q2-thr': { rtype: 'pb', days: 6, pbFocus: 'thr', qSess: '2', pbCycle: '2' },
  'hm-q2-pyr': { rtype: 'hm', days: 6, race: '2027-02-21', base: 40, peak: 65, qSess: '2', method: 'pyramidal', goalT: '1:45:00' },
  'hm-q2-pol': { rtype: 'hm', days: 6, race: '2027-02-21', base: 40, peak: 65, qSess: '2', method: 'polarized', goalT: '1:45:00' },
  'hm-q2-conv': { rtype: 'hm', days: 6, race: '2027-04-18', pbConv: { wk: 4, b0: 30, p0: 50 }, qSess: '2' },
  // tahap 1b: strength
  'hm-no-strength': { race: '2027-02-21', sLeg: false, sAnk: false, sUp: 'off' },
  'hm-up2': { race: '2027-02-21', sUp: '2' },
  'hm-up1-6d': { race: '2027-02-21', days: 6, sUp: '1' },
  'fm-6d-up-auto': { rtype: 'fm', days: 6, race: '2027-04-18', base: 50, peak: 85 },
  'ultra-6d-strength': { rtype: 'ultra', raceKm: 50, raceGain: 2400, race: '2027-05-30', base: 55, peak: 75, days: 6, sUp: '2' },
  // penghalus D+ mingguan (gSmooth aktif)
  'ultra-50-gs': { rtype: 'ultra', raceKm: 50, raceGain: 2400, race: '2027-05-30', base: 55, peak: 75, days: 6, gSmooth: true },
  'ultra-5d-gs': { rtype: 'ultra', raceKm: 40, raceGain: 1800, race: '2027-04-04', gSmooth: true },
  'ultra-long-gs': { rtype: 'ultra', raceKm: 100, raceGain: 5000, race: '2027-09-05', base: 50, peak: 80, days: 6, gSmooth: true },
  'ultra-gbase-gs': { rtype: 'ultra', raceKm: 50, raceGain: 2400, race: '2027-05-30', base: 55, peak: 75, days: 6, gSmooth: true, gBase: 800 },
  'ultra-event-gs': { rtype: 'ultra', raceKm: 50, raceGain: 2400, race: '2027-05-30', base: 55, peak: 75, days: 6, gSmooth: true, evOn: true, evDate: '2027-01-17', evKm: 21, evGain: 900 },
  'ultra-pyr-gs': { rtype: 'ultra', raceKm: 50, raceGain: 2400, race: '2027-05-30', base: 55, peak: 75, days: 6, gSmooth: true, method: 'pyramidal' },
  'ultra-pol-gs': { rtype: 'ultra', raceKm: 50, raceGain: 2400, race: '2027-05-30', base: 55, peak: 75, days: 5, gSmooth: true, method: 'polarized' },
  'ultrar-gs': { rtype: 'ultrar', raceKm: 100, raceGain: 1500, race: '2027-06-27', base: 55, peak: 80, days: 6, gSmooth: true },
  'ultra-conv-gs': { rtype: 'ultra', raceKm: 50, raceGain: 2400, race: '2027-08-01', base: 50, peak: 75, days: 6, gSmooth: true, pbConv: { wk: 4, b0: 40, p0: 55 } },
  'hm-too-close': { race: '2026-12-06' },
  'hm-too-long': { race: '2028-06-04' },
};
const KEEP = ['date','d','kind','role','grp','title','km','detail','gain','b2b','qk','qMin','trail','sim','bench','xtra','q2','tm','mod','str','ank','up'];
const NOTES = [];
const noteIx = (n) => { let i = NOTES.indexOf(n); if (i < 0) { NOTES.push(n); i = NOTES.length - 1; } return i; };
// blok strength dipadatkan: [judul, menit, indeks catatan, baris digabung '|']
const packBlock = (b) => [b.title, b.mins, noteIx(b.note), b.lines.join('|')];
function slim(day) {
  const o = {}; KEEP.forEach((k) => { if (day[k] !== undefined) o[k] = (k === 'str' || k === 'ank' || k === 'up') ? packBlock(day[k]) : day[k]; });
  if (day.alt) { o.altMins = day.alt.mins; o.altKm = day.alt.km; }
  return o;
}
const ymd = (d) => ctx.iso(d);
const out = {};
for (const [name, over] of Object.entries(SC)) {
  const s = Object.assign({}, base, over);
  let r;
  try { r = ctx.plan(s); } catch (e) { r = { err: 'THROW ' + e.message }; }
  const res = r.err ? { err: r.err } : {
    n: r.n, start: ymd(r.start), race: ymd(r.race), noRace: !!r.noRace, build: !!r.build, pbCycle: r.pbCycle, convWk: r.convWk,
    weeks: r.weeks.map((w) => ({ i: w.i, start: ymd(w.start), phase: w.phase, cut: !!w.cut, rec: !!w.rec, race: !!w.race, km: w.km, days: w.days.map(slim) })),
  };
  out[name] = { settings: s, result: res };
}
const ADV = [];
for (const m of ['default', 'pyramidal', 'polarized', 'maf']) {
  for (const secs of [[3000, 5000, 600, 200, 100], [1000, 2000, 3000, 900, 300], [2000, 6000, 100, 500, 400], [4000, 3000, 2500, 400, 100], [6000, 100, 100, 1500, 900], [5000, 3500, 400, 600, 300]]) {
    const r = ctx.tmAdvice(secs, 150, Object.assign({}, base, { method: m }));
    ADV.push({ m, secs, hrEasy: 150, r: r ? { k: r.k, txt: r.txt } : null });
  }
}
out.__advice = ADV;
out.__notes = NOTES;
const dir = new URL('../app/src/test/resources/golden/', import.meta.url);
fs.mkdirSync(dir, { recursive: true });
fs.writeFileSync(new URL('plan-golden.json', dir), JSON.stringify(out));
for (const [k, v] of Object.entries(out)) if (!k.startsWith('__')) console.log(k.padEnd(16), v.result.err ? 'ERR ' + v.result.err : v.result.weeks.length + ' minggu');
