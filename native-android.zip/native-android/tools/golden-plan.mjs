// Menghasilkan data acuan (golden) dari plan() versi web agar port Kotlin bisa dicocokkan.
// Jalankan dari akar proyek web (folder yang berisi src/ dan tests/):  node native-android/tools/golden-plan.mjs
import fs from 'node:fs';
import { load } from '../../tests/helpers.mjs';

const FNS = ['plan','parse','iso','addDays','diffDays','pad','r50','f10','gSum','gainTarget','gainSet','gainSpread','idn','wt','restCfg','weekRoles',
  'pbLen','pbFocusOf','pbWeights','pbPostWeeks','pbAkOf','pbAkLevel','qDetail','qParse','thrBand','ltBand','hrMaxEst','racePaces','raceKmOf','raceDetail',
  'rcOf','roadQ','roadLong','qEasyPace','qualEst','qualBalance','paceStr','parsePaceStr','parseDur','durStr','fmtKm','placeStrength','strengthFor','ankleFor',
  'upperFor','q2Stage','q2Apply','q2Slot','q2Allowed','methodQuality','methodEasy','tmOf'];
const g = { LANG: 'id', L: (a) => a, easyPaceEst: undefined, log: {}, TODAYD: new Date(2026, 10, 5, 12), TODAY: '2026-11-05', UNG_KM: 7, UNG_GAIN: 750,
  MON: [], DOW: [], tpEn: () => false, DS: (x) => String(x) };
const OVER = `var W={long:.34,quality:.15,medium:.15,easy:.13,short:.10}; var CW=W; var REST_OK=[6,5,3,2];
var UNG_KM=7, UNG_GAIN=750; var GAIN_STEP=.10, GAIN_CUT=.8, GAIN_PK3=.9, GAIN_LONG_MAX=.55, GAIN_W={long:.35,medium:.25,hike:.30,easy:.20}, GAIN_CEIL=1.5;`;
import { readFileSync } from 'node:fs';
const SRC05 = readFileSync(new URL('../../src/js/main/05-lomba-tema-prediksi.js', import.meta.url), 'utf8');
const RC_BLOCK = SRC05.match(/var RCFG=\{[\s\S]*?\n\};\nvar RBAND=\{[\s\S]*?\};/)[0];
const Q2_BLOCK = SRC05.match(/var Q2_TYPES=\{[^\n]*\n/)[0];
const TM_BLOCK = "var TM_KEYS=['default','pyramidal','polarized','maf'];";
let ctx;
try { ctx = load(FNS, g, OVER + '\n' + RC_BLOCK.replace('var CW=W;','') + '\n' + Q2_BLOCK + '\n' + TM_BLOCK); } catch (e) { console.error('LOAD GAGAL:', e.message); process.exit(1); }
console.log('loaded ok', typeof ctx.plan);

const base = { name: 'Uji', raceKm: '', start: '2026-11-02', race: '', base: 40, peak: 65, days: 5, rest: 0, rest2: 4, longDay: 6, hr: 150, thr: '164–172',
  pace: '6:30', rtype: 'hm', pbCycle: '3', pbFocus: 'mix', qSess: '1', method: 'default', raceGain: '', gBase: '', goalT: '', hrmax: '', sLeg: true, sAnk: true,
  sUp: 'auto', gSmooth: false, evOn: false, evDate: '', evKm: '', evGain: '', bspd: 20 };
const SC = {
  'hm-5d': { race: '2027-02-21' },
  'hm-5d-goal': { race: '2027-02-21', goalT: '1:45:00' },
  '5k-6d': { rtype: '5k', days: 6, race: '2027-01-10', base: 30, peak: 45 },
  '10k-6d-bike': { rtype: '10k', days: 6, race: '2027-02-07', base: 35, peak: 55, goalT: '50:00' },
  'fm-5d': { rtype: 'fm', race: '2027-04-18', base: 50, peak: 85, goalT: '3:45:00' },
  'fm-6d-longsat': { rtype: 'fm', days: 6, longDay: 5, rest: 1, race: '2027-04-18', base: 50, peak: 85 },
  'none': { rtype: 'none' },
  'pb-mix': { rtype: 'pb', base: 40, peak: 60 },
  'pb-thr-c2': { rtype: 'pb', pbFocus: 'thr', pbCycle: '2', days: 6 },
  'pb-vol-c4': { rtype: 'pb', pbFocus: 'vol', pbCycle: '4' },
  'pb-vo2': { rtype: 'pb', pbFocus: 'vo2', pbCycle: '3', days: 6 },
  'pb-post2': { rtype: 'pb', pbPost: { rec: 2, lvl: 60 }, start: '2026-11-09' },
  'pb-post1': { rtype: 'pb', pbPost: { rec: 1, lvl: 50 }, start: '2026-11-09', days: 6 },
  'pb-ak': { rtype: 'pb', pbAk: { wk: '2027-01-04', km: 45 } },
  'hm-conv': { rtype: 'hm', race: '2027-04-18', pbConv: { wk: 4, b0: 30, p0: 50 } },
  'ultra-50': { rtype: 'ultra', raceKm: 50, raceGain: 2400, race: '2027-05-30', base: 55, peak: 75, days: 6 },
  'ultrar-6d': { rtype: 'ultrar', raceKm: 100, race: '2027-06-27', base: 55, peak: 80, days: 6 },
  'ultra-5d': { rtype: 'ultra', raceKm: 40, raceGain: 1800, race: '2027-04-04' },
  'hm-event': { race: '2027-02-21', evOn: true, evDate: '2026-12-13', evKm: 10, evGain: 0 },
  'hm-too-close': { race: '2026-12-06' },
  'hm-too-long': { race: '2028-06-04' },
};
const KEEP = ['date','d','kind','role','grp','title','km','detail','gain','b2b','qk','qMin','trail','sim','bench','xtra'];
function slim(day) {
  const o = {}; KEEP.forEach((k) => { if (day[k] !== undefined) o[k] = day[k]; });
  if (day.alt) { o.altMins = day.alt.mins; o.altKm = day.alt.km; }
  return o;
}
const ymd = (d) => ctx.iso(d);
const out = {};
for (const [name, over] of Object.entries(SC)) {
  const s = Object.assign({}, base, over);
  let r;
  try { r = ctx.plan(s); } catch (e) { r = { err: 'THROW ' + e.message }; }
  const res = r.err ? { err: r.err } : {
    n: r.n, start: ymd(r.start), race: ymd(r.race), noRace: !!r.noRace, build: !!r.build, pbCycle: r.pbCycle, convWk: r.convWk,
    weeks: r.weeks.map((w) => ({ i: w.i, start: ymd(w.start), phase: w.phase, cut: !!w.cut, rec: !!w.rec, race: !!w.race, km: w.km, days: w.days.map(slim) })),
  };
  out[name] = { settings: s, result: res };
}
const dir = new URL('../app/src/test/resources/golden/', import.meta.url);
fs.mkdirSync(dir, { recursive: true });
fs.writeFileSync(new URL('plan-golden.json', dir), JSON.stringify(out));
for (const [k, v] of Object.entries(out)) console.log(k.padEnd(14), v.result.err ? 'ERR ' + v.result.err : v.result.weeks.length + ' minggu');
