// Data acuan untuk ActBuilder dan FitParser: titik sintetis dan berkas FIT buatan diproses kode web asli.
// Jalankan dari akar proyek web:  TZ=UTC node native-android/tools/golden-act.mjs
import fs from 'node:fs';
import { load } from '../../tests/helpers.mjs';

const FNS = ['buildAct','parseFit','havLL','minC','gapF','eleGainTh','ezSeries','vamCalc','iso','pad','L','idn','r50','median','zoneCutsFor','zoneOf','hrMaxEst','thrBand','ltBand','parse','addDays','diffDays','zcut','restHr'];
const g = { LANG: 'id', log: {}, daily: {}, S: { thr: '164–172', hrmax: '', zm: 'lthr' }, ZLD: [85, 90, 95, 100], ZRD: [50, 60, 70, 80, 90], L: (a) => a };
const ctx = load(FNS, g, 'var ZLD=[85,90,95,100], ZRD=[50,60,70,80,90];');
console.log('loaded', typeof ctx.buildAct, typeof ctx.parseFit);

const T0 = Date.UTC(2026, 10, 3, 6, 0, 0);
// jalur sintetis: lingkaran besar dengan gelombang elevasi, langkah tiap 5 detik
function track({ n = 360, step = 5, speed = 3.0, hr = true, ele = true, cad = 80, pauses = [], d = false }) {
  const pts = []; let t = T0, dist = 0, la = -7.30, lo = 110.40;
  for (let i = 0; i < n; i++) {
    const sp = speed * (1 + 0.15 * Math.sin(i / 18));
    const pause = pauses.some(([a, b]) => i >= a && i < b);
    const dtS = pause ? 60 : step;
    t += dtS * 1000; if (!pause) dist += sp * dtS;
    const ang = dist / 700;
    la = -7.30 + 0.0063 * Math.sin(ang); lo = 110.40 + 0.0063 * (1 - Math.cos(ang));
    pts.push({ la, lo, t, e: ele ? 150 + 40 * Math.sin(dist / 400) + 3 * Math.sin(dist / 37) : NaN,
      h: hr ? Math.round(135 + 25 * Math.sin(i / 30) + (i / n) * 12) : NaN, c: cad ? cad + Math.round(4 * Math.sin(i / 7)) : NaN, d: d ? dist : NaN });
  }
  return pts;
}
const num = (x) => (Number.isFinite(x) ? x : null);
const ptsJson = (p) => p.map((q) => [q.la, q.lo, q.t, q.e, q.h, q.c, q.d].map(num));
const SCEN = {
  lari: { pts: track({}), sport: 'running', nm: 'Lari pagi' },
  lari_jeda: { pts: track({ n: 420, pauses: [[100, 112], [250, 262]] }), sport: 'Running', nm: '' },
  lari_jarak_perangkat: { pts: track({ n: 400, d: true }), sport: 'running', nm: 'Treadmill' },
  tanpa_hr_elevasi: { pts: track({ hr: false, ele: false, cad: 0 }), sport: 'running', nm: 'Polos' },
  sepeda: { pts: track({ n: 500, speed: 7.5, cad: 85 }), sport: 'biking', nm: 'Sepeda santai' },
  hiking: { pts: track({ n: 500, speed: 1.4, cad: 0 }), sport: 'hiking', nm: '' },
  pendek_200m: { pts: track({ n: 12 }), sport: 'running', nm: 'Terlalu pendek' },
};
const out = { acts: {}, fit: {} };
for (const [k, s] of Object.entries(SCEN)) {
  let exp; try { exp = ctx.buildAct(s.pts, s.sport, s.nm); } catch (e) { exp = { error: e.message }; }
  out.acts[k] = { pts: ptsJson(s.pts), sport: s.sport, nm: s.nm, expected: JSON.parse(JSON.stringify(exp)) };
  console.log(k.padEnd(22), exp.error ? 'ERR ' + exp.error : `km=${exp.km} min=${exp.min} gain=${exp.gain} sp=${exp.sp.length} rt=${exp.rt.length}`);
}

// ---- FIT buatan ----
function fitFile(points, { sport = 2, laps = [] } = {}) {
  const parts = [];
  const def = (lt, gm, fields) => { const b = [0x40 | lt, 0, 0, gm & 255, gm >> 8, fields.length]; fields.forEach(([n, s, t]) => b.push(n, s, t)); return b; };
  const u32 = (v) => [v & 255, (v >> 8) & 255, (v >> 16) & 255, (v >>> 24) & 255];
  const u16 = (v) => [v & 255, (v >> 8) & 255];
  const EP = 631065600;
  // session (18): sport field 5 (enum, tipe 0)
  parts.push(...def(1, 18, [[253, 4, 0x86], [5, 1, 0x00]]), 1, ...u32(Math.round(points[0].t / 1000) - EP), sport);
  // record (20): ts, lat, lon, hr, cad, dist, alt(78), temp(13)
  parts.push(...def(0, 20, [[253, 4, 0x86], [0, 4, 0x85], [1, 4, 0x85], [3, 1, 0x02], [4, 1, 0x02], [5, 4, 0x86], [78, 2, 0x84], [13, 1, 0x01]]));
  let dist = 0, prev = null;
  for (const p of points) {
    if (prev) dist += ctx.havLL(prev.la, prev.lo, p.la, p.lo); prev = p;
    const lat = Math.round(p.la * 2147483648 / 180), lon = Math.round(p.lo * 2147483648 / 180);
    parts.push(0, ...u32(Math.round(p.t / 1000) - EP), ...u32(lat >>> 0), ...u32(lon >>> 0), p.h, p.c, ...u32(Math.round(dist * 100)), ...u16(Math.round((p.e + 500) * 5)), 24);
  }
  // lap (19): ts, iv(23), el(7), tm(8), di(9), hr(15), cad(17)
  if (laps.length) {
    parts.push(...def(2, 19, [[253, 4, 0x86], [23, 1, 0x00], [7, 4, 0x86], [8, 4, 0x86], [9, 4, 0x86], [15, 1, 0x02], [17, 1, 0x02]]));
    laps.forEach((l) => parts.push(2, ...u32(Math.round(l.t / 1000) - EP), l.iv, ...u32(l.tm * 1000), ...u32(l.tm * 1000), ...u32(l.di * 100), l.h, l.c));
  }
  const data = Buffer.from(parts);
  const hdr = Buffer.alloc(14); hdr[0] = 14; hdr[1] = 0x20; hdr.writeUInt16LE(2000, 2); hdr.writeUInt32LE(data.length, 4); hdr.write('.FIT', 8, 'ascii'); hdr.writeUInt16LE(0, 12);
  return Buffer.concat([hdr, data, Buffer.from([0, 0])]);
}
const FIT = {
  fit_lari: { pts: track({ n: 360 }), sport: 2 === 2 ? 1 : 1 },
  fit_sepeda: { pts: track({ n: 500, speed: 7.5, cad: 85 }), sport: 2 },
};
for (const [k, s] of Object.entries(FIT)) {
  const buf = fitFile(s.pts, { sport: s.sport });
  const ab = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
  let exp; try { exp = ctx.parseFit(ab); } catch (e) { exp = { error: e.message }; }
  out.fit[k] = { b64: buf.toString('base64'), expected: JSON.parse(JSON.stringify(exp)) };
  console.log(k.padEnd(22), exp.error ? 'ERR ' + exp.error : `km=${exp.km} min=${exp.min} bike=${exp.bike} gain=${exp.gain}`);
}
const dir = new URL('../app/src/test/resources/golden/', import.meta.url);
fs.mkdirSync(dir, { recursive: true });
fs.writeFileSync(new URL('act-golden.json', dir), JSON.stringify(out));
console.log('selesai');
