# EnduranceVault Native 0.5.29

## Build fix
- Added the missing `androidx.compose.foundation.layout.fillMaxSize` import in `ProfileScreen.kt`.
- Bumped Android versionCode to 43 and versionName to 0.5.29.

## Validation
- Confirmed the import exists and the failing call at ProfileScreen.kt:137 is now resolvable by source-level inspection.
- ZIP integrity checked after packaging.
- This environment did not run the Android Gradle build; please run the repository CI/build to confirm compilation and surface any subsequent errors.
