# Injury prevention native port — 0.5.13

Ported from legacy `19b-tidur-nyeri-keseimbangan.js` and `19c-cegah-cedera-sepeda.js`.

## Pain / injury
- Structured legacy anatomy groups: lower leg, knee/thigh, hip/trunk; all 15 original body-area IDs.
- Side (left/right/both), severity 1–5, and before/during/after-run timing.
- Persistent history, delete action, 4-day recurrence alert (3 of 4 days at severity >=2 or >=4 in the last 2 days), area-specific prehab suggestions and caution copy.
- Readiness pain score uses the legacy 1..5 mapping (90/75/55/30/10) and recurrence penalty (10 per alert, max 20).
- Existing free-text area and side values from 0.5.12 are mapped to legacy IDs when possible.

## Bike substitution and return to running
- Active leg pain detection uses the latest entry for each area/side in the last 2 days and severity >=3.
- Eligible planned run sessions in the next 7 days can be individually or collectively swapped to a zone-2 bike session; original session data is persisted so it can be restored.
- Conversion uses native HR zone cuts, bike HR offset, TRIMP weighting, mode factor, quality-session load replacement, 5-minute rounding and 20–300 minute caps. Estimated bike distance uses configured bike speed.
- Optional normalization of bike Training Load by the mode factor.
- Logged replacement rides can be evaluated against target duration/TRIMP and effort feel; repeated directional mismatch suggests a +/-2 bpm bike HR-offset calibration.
- When pain has settled (two latest sub-3 entries with the legacy date-spacing rule), the three-week return guide applies 65%, 80%, and 90% plan volume; quality/long sessions are eased according to the legacy phase rules. The guide is stopped if active leg pain returns.

## Safety and verification
- Prehab suggestions are general guidance, not treatment or diagnosis. Severe, worsening, persistent, or function-limiting pain should be assessed by a qualified clinician. Bike substitution is optional and should only be used if cycling does not provoke pain.
- `InjuryPrevention.kt` was compiled with `kotlinc` against minimal model stubs. Android/Compose build and on-device schedule-flow verification could not be run because no Gradle executable/wrapper is available in this environment. Run the project CI/build and verify the schedule tab after applying a swap before release.
