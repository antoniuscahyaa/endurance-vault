# Fitness (Kebugaran) tab parity pass

Referensi: grup `fit` di `rencana-lari-apk-20.zip` (`GROUPS` di `src/js/layout-compact.js`):
`['fit','Kebugaran',['pgFit','pgPR','pgPace','pgAero','pgDrift','pgEzTrend']]`.
Basis: native 0.5.45. Tidak ada perubahan skema Room, package, signing, atau rumus beban/readiness.

## Struktur kartu (urutan sama dengan web)
1. **Kebugaran lari** (`pgFit`, hero, selalu terbuka) – Running Ability Index, Fitness RAI, Fatigue RAI, Recovery; dua meter Fitness/Fatigue dengan label; baris "RAI x · label · tren 5 minggu"; catatan perkiraan.
2. **Personal record** (`pgPR`) – kisi 1 km / 5K / 10K / Half marathon, penanda "baru" (30 hari), ketuk kartu membuka sesi. Ringkasan tertutup: empat waktu + "★ PR …" bila ≤ 14 hari.
3. **Zona pace dari RAI** (`pgPace`) – tabel Easy / Tempo / Threshold / VO2max dengan keterangan; ringkasan Easy dan Threshold.
4. **Efisiensi aerobik** (`pgAero`) – pace pada HR tetap (±4 bpm), rentang 3 bln / 6 bln (bawaan) / 1 th / Semua, HR target bawaan 140, titik per lari + rata-rata 28 hari, ringkasan "lebih cepat / lebih lambat", tombol "Pakai N bpm" bila data terbanyak di HR lain.
5. **Cardiac drift** (`pgDrift`) – hanya lari easy/long (bukan quality, sub, lomba, acara, bench) dengan ≥ 9 split; pesan tren, 8 lari terakhir, label baik (<3%) / sedang (<5%) / tinggi.
6. **Tren easy run** (`pgEzTrend`, terbuka sejak awal) – kotak saran sesi Terlalu keras berturut-turut, waktu di zona per minggu (8 minggu, berbobot waktu), skor per sesi (12 terakhir) dan tren.

Tata letak mengikuti `pack()` di web: hero, PR, dan Zona pace selebar layar; Efisiensi aerobik berpasangan dengan Cardiac drift (melebar bila salah satu dibuka); Tren easy run selebar layar.

## File
- `domain/FitnessAnalytics.kt` – logika murni (tanpa Android), diport dari `15-training-load-te-kebugaran.js` (`renderFit`, `renderPace`, `paceAtFrac`), `22-statistik-data.js` (`stAeRun`, `stAeSeries`, `stAeBest`, `stAeSmooth`, `stAeSummary`), `08-kesesuaian-rute-serupa-detail.js` (`driftOf`, `renderDrift`), `25-nilai-easy-run.js` (`ezTrRows`, `ezTrWeeks`, `ezTrStreaks`, `ezTrScores`, `ezTrScoreSum`, `ezTrStreakAdv`).
- `ui/screens/FitnessTab.kt` – UI Compose, memakai komponen kartu yang sama dengan `RecapTab`.
- `ui/screens/RecapTab.kt` – komponen kartu (`RcCard`, `RcInner`, `RcBig`, `RcStats`, `RcStatGrid`, `RcTag`, `RcInfo`, `RcMuted`, `RcMono`, `RcTableRow`, `RcSeg`, `RcPill`, `RcPair`, `RcCompare`, `RcLegend`, `RcRing`, `monoStyle`, `tickStyle`, `WARN`, `GRAD`) diubah dari `private` ke `internal`. Isi tidak berubah.
- `ui/screens/ProgressScreen.kt` – blok FITNESS lama diganti `FitnessTab(state, onOpen)`.
- `test/.../FitnessAnalyticsTest.kt` – 9 tes JVM (label, zona pace, efisiensi aerobik, drift, tren easy run).

## Dihapus dari sub-tab Fitness (tidak ada di web)
Training load (tetap di sub-tab Load), Morning signal trend, Easy-run compliance, serta kartu Running fitness / Personal record / Pace zones / Aerobic efficiency & cardiac drift versi lama (digantikan versi baru).

## Perbedaan yang disengaja / belum ada
- Label chip tetap "Fitness" (web: "Kebugaran"); `initialTab` tetap menerima "fitness" dan "kebugaran".
- HR target dan rentang pada Efisiensi aerobik disimpan selama sesi layar (rememberSaveable), belum dipersist ke penyimpanan seperti `rl:st` di web.
- Pesan recovery rinci ("pulih sekitar Sen, 9 Nov pukul 14:00") di web hanya tampil di pil Recovery header Profil, bukan di kartu Kebugaran, jadi tidak ditambahkan di sini.
- Bobot persen mingguan Tren easy run memakai `evaluatedMinutes`/`overLimitMinutes` dari `EasyRunAnalytics` (setara `cmp.total`/`cmp.off`) dan ambang `easyPass/easyOk/longPass/longOk` dari pengaturan easy-run.
- Cardiac drift memakai jenis hari dari rencana native (`PDay.kind`, `PDay.bench`) menggantikan `dayMap` web; Minetti dari `ActInsights.minettiCost`.

## Verifikasi
- Belum dikompilasi dan belum dijalankan: lingkungan ini tidak punya compiler Kotlin maupun akses jaringan untuk dependensi Gradle. Kurung/kurawal sudah dicek seimbang dan ekspektasi tes dihitung manual terhadap rumus web.
- Jalankan workflow GitHub seperti biasa dan kirim log bila ada error kompilasi.
