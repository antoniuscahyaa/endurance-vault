# Stage 6.7 — Legacy navigation restoration

- Restored the four permanent primary destinations in the legacy order: Today, Profile, Watch, Week.
- Schedule is a contextual fifth destination and is shown only when `PlanSettings.rtype != "none"`.
- If the active plan changes to No Race while Schedule is open, navigation returns to Week.
- The Week destination reuses the existing activity/progress data and import/detail actions.
- The Watch destination exposes the existing direct Huawei protocol UI and callbacks.
- Package remains `com.endurancevault.app`; version is 0.5.2 (code 16).

## Scope and verification

This stage restores the primary navigation rule and makes Watch independently reachable. It does not claim complete visual/structural parity for every legacy Profile subtab, card, chart, header, or screen. Gradle compilation/device rendering must be verified in the user's GitHub Actions/device environment; Gradle is not installed in this workspace.
