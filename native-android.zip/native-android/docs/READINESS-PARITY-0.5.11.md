# Training Readiness parity — 0.5.11

## Implemented
- Replaced the short readiness alert with a full-height native detail panel.
- Added current score/tier/advice, seven-day trend line, and factor score bars/details.
- Added persistent advice thresholds (swap/light/easy) and applies them to today's plan adjustment calculation.
- Added default, automatic, and manual factor-weight modes. Manual weights and automatic weights are persisted and applied by the native readiness engine.
- Added post-run-feel threshold suggestions and an automatic threshold toggle.
- Added weekly/monthly readiness-vs-training summaries.
- Added a persistent daily readiness snapshot store (180 days); same-day snapshots update only when a morning check is subsequently recorded.
- Added sleep-HR factor support when `shr` exists in the daily raw data.
- Added unit tests for manual weight application and threshold validation.

## Important parity notes
- Historical readiness snapshots begin accumulating after this version is installed. Earlier days are not fabricated from today's state.
- Automatic factor calibration needs enough paired morning-check + post-run-feel days; it remains unavailable until the required history exists.
- The current native data model does not yet expose the legacy pain-area log, so the legacy pain factor cannot be reconstructed in this pass.
- Sleep need currently uses the legacy default of 7.5 hours; the legacy custom sleep-need preference is not yet exposed in native settings.
- A full Android Gradle build/test was not run in this environment because a Gradle executable/wrapper is not present. Run the project's Android CI/build before publishing.

Follow-up parity items (custom sleep need and pain log) are implemented in release 0.5.12; see `READINESS-PARITY-0.5.12.md`.
