# Stage 6.5.1 — Complete External Services, No Fueling

- Release: 0.4.9 (versionCode 13)
- Weather: current conditions + 7-day forecast, rain probability, wind, US/EU AQI, PM2.5/PM10.
- Weather location: Open-Meteo city geocoding, explicit foreground GPS lookup, or manually entered coordinates.
- Huawei: configure and immediately refresh watch weather using the existing Huawei protocol controller.
- A-GPS: toggle, optional HTTPS mirror, status and manual download test.
- Notifications: registered Android NotificationListenerService, per-app switches, quiet-hour window, screen-off filter and test notification.
- AI Coach: Groq GPT-OSS 120B chat, optional browser_search tool, activity/daily condition/plan context, API key encrypted by Android Keystore and excluded from backup.
- Removed all fueling/hydration planning UI, calculation, saved preference and race-plan prompts. The previous `fueling_log` preference is cleared on app start.

## User actions required
- Provide a Groq API key in Profile > AI Coach.
- Grant location permission only if using GPS lookup.
- Grant Notification Access in Android Settings to forward phone notifications.
- Pair/connect a compatible Huawei watch before sending weather, A-GPS or notification test commands.

## Verification boundary
The source was inspected and edited, Kotlin syntax parsing produced no parser diagnostics, and Android XML files were parsed. This environment has no Gradle installation, so the APK build, unit tests, live network requests, and physical Huawei Watch Fit 4 behavior remain unverified. Run the repository GitHub Actions workflow before installing.
