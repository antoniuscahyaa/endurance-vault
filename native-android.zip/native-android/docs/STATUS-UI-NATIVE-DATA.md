# EnduranceVault — Penataan UI berdasarkan data native yang tersedia

## Prinsip putaran ini
UI hanya menampilkan dan mengatur data, perhitungan, serta workflow yang memang sudah tersedia di proyek native. Tidak menambahkan layar atau kontrol untuk fitur legacy yang belum dimigrasikan. Fitur baru akan ditambahkan sebagai bagian akhir setelah fondasi UI native yang ada tertata.

## Perubahan
- Profil: menghapus judul ganda; satu header menjelaskan halaman dan satu panel khusus untuk pemilih kelompok pengaturan.
- Minggu: menambahkan hierarki judul dan konteks minggu berjalan di atas kontrol Minggu ini/Riwayat.
- Jam: menyamakan hierarki judul halaman dan menambahkan ruang scroll atas/bawah.
- Dock utama tetap Hari ini, Profil, Jam, Minggu; Jadwal hanya muncul ketika rencana latihan aktif.
- Progres tetap menjadi subhalaman Profil.
- Isi dan tindakan domain yang sudah ada dipertahankan. Tidak ada rumus, model data, penyimpanan, API, protokol Bluetooth, package name, version, atau signing yang diubah.

## Data native yang ditata
- Hari ini: sesi terjadwal hari ini, rincian/support blocks, pencatatan aktivitas manual.
- Profil: target dan konfigurasi rencana, zona HR, kondisi dan gear, layanan yang sudah terintegrasi, impor cadangan.
- Progres: training load/readiness, ringkasan aktivitas, target pekan, volume mingguan, impor FIT/GPX/TCX, riwayat dan detail aktivitas.
- Jam: koneksi/sinkronisasi, Live HR, zona HR, workout terstruktur, rute, dan fitur perangkat yang sudah ada.
- Minggu: daftar sesi, status aktivitas tertaut, pertukaran jadwal, libur dadakan, dan riwayat penyesuaian.
- Jadwal: ringkasan seluruh pekan pada rencana aktif.

## Sengaja tidak ditambahkan
Tidak ada implementasi placeholder untuk editor rute, kartu/video share, AI tambahan, statistik PR lanjutan, atau fitur legacy lain yang belum tersedia di native. Fitur fueling/nutrisi/cairan tetap dikecualikan sesuai keputusan proyek.

## Validasi
- Pemeriksaan statis perubahan UI dilakukan.
- Build Gradle, emulator, dan perangkat fisik belum diuji pada lingkungan ini. Paket ini bukan klaim build release siap produksi.
