# Today session card layout fix — 0.5.26

Applied an actual Compose layout refactor to TodayScreen.kt:
- The session label, title and distance now form a tightly stacked left column (1dp spacing).
- The left text column is top-aligned beside the readiness gauge; it is no longer vertically centered against the taller gauge.
- HR and extra-distance metadata are grouped together on the left in a single compact row.
- The recorded badge is aligned at the right edge of that same row.
- The detail toggle and advice panel remain below in the requested order.
- Outer vertical spacing in the card is 4dp.
- Readiness data, session data, and click behavior are unchanged.

Version 0.5.26, versionCode 40.
