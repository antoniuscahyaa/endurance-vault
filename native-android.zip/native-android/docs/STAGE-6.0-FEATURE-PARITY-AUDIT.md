# Stage 6.0 — Native Feature Parity Audit

## Tujuan
Membandingkan source aplikasi lama (`src/js/main`) dengan proyek native Stage 5.8. Audit ini menjadi baseline Stage 6. Tidak ada formula readiness, CTL/ATL/TSB, Training Effect, pace, atau algoritma latihan yang diubah.

## Ringkasan hasil

Native saat ini memiliki fondasi berikut:
- Navigasi utama Hari ini, Jadwal, Progres, Profil.
- Pencatatan aktivitas manual, riwayat, detail aktivitas, impor FIT/GPX/TCX.
- Mesin rencana latihan dan beberapa modul domain: pace, zona HR, strength, race config, training method.
- Kondisi harian, gear, training load/readiness, dan Training Effect.
- Integrasi Bluetooth langsung Huawei Watch: pairing, forget/reconnect, sinkronisasi, Live HR, zona HR, structured workout, dan pengiriman rute GPX.

Source lama memiliki 80+ modul bernomor di `src/js/main`. Banyak kemampuan tersebut belum tampak sebagai layar atau workflow native khusus. Ini adalah **gap yang perlu diverifikasi/ditutup**, bukan klaim bahwa seluruh logika lama tidak ada sama sekali.

## Matriks parity awal

| Area aplikasi lama | Modul source lama | Kondisi native Stage 5.8 | Prioritas |
|---|---|---|---|
| Perencana, jadwal, metode latihan, gear | `02b`, `03`, `05`, `05b`, `24b`, `24l` | Fondasi PlanEngine, Schedule, Gear tersedia; editor/penyesuaian lanjutan perlu dibandingkan detail | P1 |
| Kondisi harian, tidur, nyeri, stres, keseimbangan | `04`, `19b`, `24f`, `24g`, `24h` | Input kondisi harian tersedia; insight dan tren lanjutan belum terpetakan | P1 |
| Zona HR, Training Load, TE, kebugaran | `06`, `15`, `20` | Zona dan ringkasan load/readiness/TE tersedia; validasi hasil terhadap source lama tetap wajib | P0 |
| Impor, riwayat, detail, potong aktivitas, interval | `06`, `06b`, `08b`, `08c`, `08d`, `08i`, `22`, `42` | Impor dan detail dasar tersedia; editor/pemotong/analisis interval belum terlihat sebagai workflow native | P1 |
| Cuaca, nutrisi, fueling, race strategy | `07`, `07c`–`07h`, `38` | Belum terlihat sebagai modul native tersendiri | P2 |
| AI Coach dan rekomendasi | `18b`, `24c`, `24j` | Belum terlihat sebagai layar native khusus | P2 |
| Analisis rute, elevasi, peta, trail | `08`, `08g`, `08h`, `17`, `18`, `21c`, `23` | Track parser dan detail dasar ada; peta/editor/elevasi lanjutan belum terlihat | P1 |
| Kartu share, template, editor foto/video | `10`, `10c`, `11`–`14`, `12`–`13b` | Belum terlihat sebagai modul native | P2 |
| Video peta, terrain, trail, HUD | `21`, `21b`, `21e`, `21f` | Belum terlihat sebagai pipeline native | P3 |
| Statistik, progres, PR, ringkasan siklus | `20`, `20b`, `22`, `24`, `24h`–`24o`, `25`, `25b` | Progress screen dasar tersedia; statistik dan ringkasan lanjutan perlu parity audit | P1 |
| Integrasi Huawei Watch | `28`–`32`, `39`, `40`, `41` | Direct Bluetooth dan beberapa fitur lanjutan sudah terhubung; AGPS, kursus, live cycling, format watch, background permission perlu diverifikasi | P0 |
| Integrasi eksternal dan backup | `26`, `27`, `34`, `35`, `37` | Backup parser dan GPX import tersedia; Intervals export, Google account, Strava, route-to-watch, demo mode perlu diperiksa | P1 |

## Keputusan teknis Stage 6

1. **Tidak mengganti algoritma lama.** Formula domain yang sudah dimigrasikan diperlakukan sebagai baseline dan hanya boleh disentuh bila ditemukan perbedaan terukur terhadap source lama.
2. **Parity berdasarkan perilaku, bukan nama tombol.** Setiap fitur harus diuji input, output, persistensi, edge case, dan format data.
3. **Prioritas P0:** validasi data dan integrasi jam, karena berpengaruh langsung pada keandalan data latihan.
4. **Prioritas P1:** workflow inti latihan, analisis aktivitas, statistik, rute, ekspor dan backup.
5. **Prioritas P2/P3:** fitur eksternal, AI, media share dan video setelah fondasi data stabil.
6. **Jangan hapus data pengguna saat migrasi.** Perubahan schema harus memakai migration Room yang eksplisit dan diuji terhadap database yang sudah terpasang.
7. **Fitur perangkat wajib diuji di Watch Fit 4 fisik.** Build sukses tidak membuktikan kompatibilitas protokol/firmware.

## Urutan kerja yang direkomendasikan

- **6.1 Data integrity & parity tests:** fixture perhitungan dari source lama, impor/watch dedup, timezone/tanggal, unit, backup/restore, database migration.
- **6.2 Core training workflows:** editor sesi/interval, penyesuaian jadwal, analisis split/effort, PR dan statistik.
- **6.3 Route & map workflows:** track detail, elevasi, editor rute, rute ke jam, validasi GPX.
- **6.4 Huawei completeness:** AGPS/kursus/izin latar/live cycling/format jam; hanya klaim didukung setelah uji perangkat.
- **6.5 External services:** cuaca, fueling/nutrisi, AI Coach, Strava/Intervals/Google account sesuai dukungan API dan izin.
- **6.6 Share & media:** template kartu, editor foto, video peta/trail/HUD.

## Batas audit

Audit ini bersifat source-to-source berdasarkan isi ZIP original dan Stage 5.8. Audit ini belum menjalankan aplikasi lama/native, belum menguji layanan API, belum menjalankan Gradle, dan belum menguji Watch Fit 4 fisik. Status “belum terlihat” harus dikonfirmasi dengan pengujian dan pencarian implementasi lanjutan sebelum dianggap penghapusan fitur.
