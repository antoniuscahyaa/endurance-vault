# EnduranceVault Native 0.5.1

- Package: `com.endurancevault.app`
- Version code: 15
- UI parity pass: reusable gunmetal panels, grouped screen sections, floating dock, activity-volume chart.
- No training formula or data model changes.
- Fueling/hydration features remain excluded.
