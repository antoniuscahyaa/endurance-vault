# Progress expand / legacy parity pass

Baseline: the latest user-provided `native-android.zip` (Claude compile fixes retained), plus the user-provided `rencana-lari-apk-20.zip` as the legacy reference.

## UI behavior
- Every `ProgressCard` in Recap, Fitness, Load, Routes & Conditions, and Body now exposes a tappable summary header and an expand/collapse affordance.
- The existing card body is revealed on demand with a vertical expand/collapse transition; headline metrics remain visible while collapsed.
- The Training Load & Readiness block has its own disclosure control and a compact readiness / CTL / ATL / TSB preview.
- No analytics formula, Room schema, package name, signing config, or navigation route was changed in this pass.

## Legacy reference areas reviewed
- `24-ringkasan-progres.js`: visual summary, weekly review, year-to-date/consistency, route overview, aerobic efficiency, weather, PR, and weekly trends.
- `15-training-load-te-kebugaran.js`: training load, readiness / recovery, training effect and related history.
- `22-statistik-data.js`: statistics and activity history.
- `24b-kepatuhan-rencana.js`: plan adherence and schedule compliance.
- `25-nilai-easy-run.js`: easy-run compliance, drift, stability, efficiency and stride detection.
- `08-kesesuaian-rute-serupa-detail.js` and `23-kartu-elevasi-ridgeline.js`: similar routes, comparisons, elevation profiles.
- `04-kondisi-pagi-ulasan-bandingkan.js`: morning condition history, comparison and recovery context.
- `20-zona-log-bulanan-pr-cadangan.js`: HR/pace zones, weekly/monthly review, PR, and supporting logs.

## Data integrity
This pass makes the native data already surfaced by the current screens easier to inspect. It does not invent legacy-only values where the native data model has no corresponding source. The detailed legacy parity work (including remaining charts, comparisons, and any missing source data) remains separate from this UI disclosure pass.
