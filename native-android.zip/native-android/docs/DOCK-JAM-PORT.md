# Port dock Jam (web `30-dock-jam.js` → native)

Sumber: `src/js/main/30-dock-jam.js` + `styles/base/21-dock-jam.css` (rencana-lari-apk-20).
Tab **Jam** di native sebelumnya hanya berisi pengaturan koneksi (`HuaweiWatchSection`). Sekarang tab itu = dock Jam web.

## Berkas baru
| Berkas | Isi |
|---|---|
| `domain/WatchDock.kt` | Logika murni (padanan `jamModel` dan helper `jam*`): ubin, 7 hari, per jam, ringkasan tidur, estimasi baterai, log baterai, sesi baterai, hipnogram, pace, cuaca watchface, sumbu grafik |
| `data/WatchDockReader.kt` | Pengganti `jamRead()`: baca `ProtocolBridge` langsung (tanpa Capacitor), simpan log baterai 60 hari dan alias nama jam; `WatchDockUi` |
| `ui/screens/WatchDockScreen.kt` | Kartu jam, indikator/panel sinkron, grid ubin + panel rinci, latihan dari jam (pager + riwayat), detail data |
| `ui/screens/WatchDockDetail.kt` | Panel rinci per ubin (langkah, HR, HR istirahat, kalori, jarak, SpO₂, tidur, baterai), slider hipnogram, daftar terbangun |
| `ui/screens/WatchDockCharts.kt` | Grafik Canvas: batang, rentang, garis, tumpuk fase tidur, hipnogram, HR harian, SpO₂ harian |
| `ui/screens/WatchDockFace.kt` | Mock-up watchface berdetik (tanggal, jam, cuaca, recovery, cincin baterai/HR/tidur, sunset) |
| `test/.../WatchDockTest.kt` | Tes unit; asersi diport dari `tests/dock-jam.test.mjs` |

## Berkas yang diubah
- `data/HuaweiSleepParity.kt`: `Night` kini punya `blocks` (padanan `hwBlocks`) untuk hipnogram. Parameter baru ber-default, jadi tes lama tidak berubah.
- `ui/MainViewModel.kt`: `watchDock`, `watchAlias`, `watchLastSyncJs`, `refreshWatchDock()`, `setWatchAlias()`, penerapan sinkron latar (`jamBgApply`/`jamApplyNative`), dan pencatatan sinkron manual.
- `ui/AppRoot.kt`: tab Jam memakai `WatchDockScreen`; `HuaweiWatchSection` dipindah ke panel roda gigi.

## Padanan fitur
Semua ada: kartu jam + nama (ketuk = ganti nama tampilan) + baterai + estimasi habis; titik sinkron (hijau/kuning/biru/merah) dengan panel info; roda gigi pengaturan; impor GPX ke jam; 8 ubin (langkah, HR, HR istirahat, kalori, jarak, SpO₂, tidur, baterai) dengan panel rinci per hari/per jam; ubin tidur dengan hipnogram + slider; latihan hari ini (pager) dan riwayat; detail data; polling 30 dtk saat tab terbuka; sinkron latar diterapkan ke Kondisi.

## Beda yang disengaja
1. **Simpan latihan.** Web punya tombol "Simpan ke Jadwal / Free Run" (GPX → `onFiles`). Native sudah mengimpor lari/trail/sepeda otomatis saat sinkron (`importWatchData`, `srcKey = watch:<start>`), jadi kartu menampilkan **Detail ›** bila sudah ada di Jadwal, atau **Impor** (menjalankan sinkron) bila belum. Hike/renang tidak diimpor otomatis, sama seperti sebelumnya.
2. **Bahasa.** Hanya Indonesia (native tidak punya `LANG`).
3. **Riwayat latihan** dibatasi 100 baris (batas `readWorkouts` di native; web meminta 200).
4. **Baterai per sesi** dihitung dari log baterai untuk latihan jam (native tidak menyimpan `acts[].bat`); hasilnya sama untuk sesi yang punya cuplikan.
5. Catatan kaki "Stres dan HRV…" dipersingkat jadi "Stres belum bisa dibaca…" karena native sudah membaca HRV malam.

## Belum diverifikasi
Kode ini ditulis tanpa Gradle/kotlinc di lingkungan penulis, jadi **belum dikompilasi dan belum dijalankan di perangkat**. Angka tes yang bergantung pada logika web (estimasi baterai, sesi baterai, hipnogram, sumbu grafik, jam watchface) sudah dicocokkan dengan menjalankan fungsi web aslinya di Node. Jalankan `./gradlew testDebugUnitTest` lalu bangun APK; bila ada galat kompilasi, kirim lognya.
