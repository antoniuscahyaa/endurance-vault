# Training Readiness parity — 0.5.12

## Completed follow-up parity
- Added configurable sleep need (5–10 hours, default 7.5) and used it in seven-day sleep-debt scoring.
- Added native pain/injury entries with body area, severity (1–5), and side.
- Ported legacy pain readiness scoring: maximum pain in today/yesterday maps to 90/75/55/30/10; recurring body-area alerts subtract 10 points each, capped at 20.
- Pain entries and sleep-need preference persist locally across app restarts.
- Readiness factor count now reflects the ten possible factors.
- Added unit tests for custom sleep need and recurring pain scoring.

## Persistence notes
Pain entries are stored in the app's readiness SharedPreferences and are retained locally. They are not yet part of the cross-device backup payload. Readiness history remains append/update-only and historical scores are not fabricated.

## Verification
Source-level changes and test cases were added. Android Gradle build/unit tests could not be executed in this environment because this project archive has no Gradle wrapper and no Gradle executable is installed. Run Android CI/build before release.
