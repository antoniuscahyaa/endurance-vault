# Migrasi EnduranceVault: Capacitor (hybrid) ke Kotlin + Jetpack Compose

Paket: `com.endurancevault.app`. Proyek ini adalah fondasi; UI web lama (`www/`, `src/`) masih jadi acuan perilaku.

## Status

Belum pernah dikompilasi di lingkungan pembuatnya (tidak ada Kotlin/Gradle di sana). Langkah pertama di Android Studio: buka folder ini, sinkronkan Gradle, lalu jalankan `./gradlew testDebugUnitTest`.

Sudah ada:
- Gradle KTS, Compose Material 3, tema gelap (Ink #0B0C0F, Ember #FF7A12), navigasi 4 tab
- **Tahap 1a: `PlanEngine`**, port plan() web. Semua jenis lomba (5K, 10K, HM, FM, Trail, Ultra road, Performance Build, No Race), konversi dan pemulihan Performance Build, mulai ulang mileage, minggu lomba, event latihan, minggu sepeda, estimasi jarak sesi kualitas, long run trail dengan loop dan D+
- **`PlanGoldenTest`**: mencocokkan keluaran Kotlin dengan 19 skenario hasil asli JS (`app/src/test/resources/golden/plan-golden.json`, dibuat oleh `tools/golden-plan.mjs`). Tiap beda menyebut skenario, minggu, hari, dan field
- Room (skema v2 dengan migrasi) untuk riwayat lari, SharedPreferences untuk pengaturan, catat lari manual
- **Tahap 2: impor cadangan web.** Profil → Impor cadangan web: pilih berkas .json dari versi web. Berkas disalin utuh ke penyimpanan aplikasi (`files/imports/`), lalu dibaca secara streaming: pengaturan rencana (`s`) dan catatan lari (`log`, termasuk Free Run dan sepeda) dipulihkan. Rute GPS (`acts`), harian (`daily`), gear, dan pengaturan lain belum dibaca tetapi tidak hilang karena berkas aslinya tersimpan. Tes: `BackupParserTest`

Belum ada di perencana (tahap 1b), sama dengan web saat `gSmooth=false`:
- penghalus D+ mingguan (`gainSpread`), sesi quality kedua (`q2*`), metode latihan (pyramidal/polarized/MAF)
- strength, ankle, dan upper body (`placeStrength`)
- teks bahasa Inggris, dan pace easy dari log (saat ini dari pengaturan pace)

Cara memperbarui data acuan: dari akar proyek web, `node native-android/tools/golden-plan.mjs`. Tambah skenario di objek `SC` pada skrip itu.

## Urutan porting yang disarankan

| Tahap | Isi | Sumber di web |
|---|---|---|
| 1 (1a selesai, 1b sisa) | Pengganti `plan(s)` yang penuh: jenis lomba (trail, ultra road, Performance Build, No Race), tanjakan D+, sesi 1 atau 2 quality, back-to-back ultra, pasca-lomba | `02-i18n-penyimpanan-perencana.js`, `03-perencana-gear-statistik.js`, `02b-metode-latihan.js`, `05b-strategi-medan.js`, `24d-transisi-pb-lomba.js` |
| 2 (selesai sebagian: pengaturan dan log) | Impor cadangan JSON lama; sisa: acts (rute), daily, gear, PR, favorit, ke Room | `20-zona-log-bulanan-pr-cadangan.js`, `06-zona-hr-impor-aktivitas-cuaca.js` |
| 3 | Impor FIT/GPX, zona HR, analisis interval, training load | `06-...`, `08b-analisis-interval.js`, `08-kesesuaian-rute-serupa-detail.js` |
| 4 | Notifikasi pengingat dan sesi (WorkManager + NotificationChannel), izin latar | `19-notifikasi-pengingat.js`, `40-izin-latar.js` |
| 5 | Widget: salin `widget-native/` (sudah Java native; paket sudah diganti ke `com.endurancevault.app.widget`) dan sambungkan ke Room | `widget-native/`, `widget-sync.js` |
| 6 | Plugin jam Huawei: jadikan modul Gradle langsung (hapus lapisan Capacitor `HuaweiWatchPlugin`) | `plugins/huawei-watch-capacitor/` |
| 7 | Cuaca, nutrisi/fueling, strength, tidur dan nyeri, ulasan mingguan | `07-*.js`, `07f-jadwal-fueling.js`, `03-strength`, `19b-*.js` |
| 8 | Peta, rute, video peta 3D, kartu bagikan, editor foto/video (paling berat; pertimbangkan MapLibre + Media3) | `17-*.js`, `21*-*.js`, `10-kartu-bagikan.js`, `14-*.js` |
| 9 | Akun Google, Drive autosync (Credential Manager + Drive API) | `27-akun-google.js`, `scripts/add-google-drive.mjs` |
| 10 | i18n: pindahkan kamus `01-i18n-kamus-inggris.js` ke `strings.xml` (id, en) | `01-i18n-kamus-inggris.js` |

Mulai dari tahap 1 dan 2: tanpa keduanya aplikasi native belum bisa menggantikan versi hybrid untuk pengguna yang sudah punya data.

## Catatan penting

- Mengganti paket berarti Android memandangnya aplikasi baru: data dan pembaruan dari `com.rencanalari.app` tidak ikut. Pakai Impor cadangan (tahap 2).
- Buat OAuth client Android baru di Google Cloud untuk `com.endurancevault.app` + SHA-1 keystore.
- Keystore lama boleh dipakai; paket baru tetap butuh instalasi baru.
- Gradle wrapper tidak disertakan: buka folder ini di Android Studio, atau jalankan `gradle wrapper --gradle-version 8.9`.
