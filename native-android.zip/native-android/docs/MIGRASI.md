# Migrasi EnduranceVault: Capacitor (hybrid) ke Kotlin + Jetpack Compose

Paket: `com.endurancevault.app`. Proyek ini adalah fondasi; UI web lama (`www/`, `src/`) masih jadi acuan perilaku.

## Status

Belum pernah dikompilasi di lingkungan pembuatnya (tidak ada Kotlin/Gradle di sana), termasuk kode tahap 1b, `GainSpread`, `EasyPace`, dan tabel baru di Room. Langkah pertama di Android Studio: buka folder ini, sinkronkan Gradle, lalu jalankan `./gradlew testDebugUnitTest`.

Sudah ada:
- Gradle KTS, Compose Material 3, tema gelap (Ink #0B0C0F, Ember #FF7A12), navigasi 4 tab
- **Tahap 1a: `PlanEngine`**, port plan() web. Semua jenis lomba (5K, 10K, HM, FM, Trail, Ultra road, Performance Build, No Race), konversi dan pemulihan Performance Build, mulai ulang mileage, minggu lomba, event latihan, minggu sepeda, estimasi jarak sesi kualitas, long run trail dengan loop dan D+
- **`PlanGoldenTest`**: mencocokkan keluaran Kotlin dengan 46 skenario hasil asli JS (19 tahap 1a, 27 tahap 1b) (`app/src/test/resources/golden/plan-golden.json`, dibuat oleh `tools/golden-plan.mjs`). Tiap beda menyebut skenario, minggu, hari, dan field
- Room (skema v2 dengan migrasi) untuk riwayat lari, SharedPreferences untuk pengaturan, catat lari manual
- **Tahap 2: impor cadangan web.** Profil → Impor cadangan web: pilih berkas .json dari versi web. Berkas disalin utuh ke penyimpanan aplikasi (`files/imports/`), lalu dibaca secara streaming: pengaturan rencana (`s`) dan catatan lari (`log`, termasuk Free Run dan sepeda) dipulihkan. Rute GPS (`acts`), harian (`daily`), gear, dan pengaturan lain belum dibaca tetapi tidak hilang karena berkas aslinya tersimpan. Tes: `BackupParserTest`

- **Tahap 3: detail aktivitas, impor rute, FIT/GPX/TCX, zona HR.**
  - Cadangan web: rute GPS, split, grafik, dan histogram HR dari `acts` disalin apa adanya per aktivitas ke `files/acts/b_<tanggal>.json` (lintasan kedua, tanpa memuat seluruh berkas ke memori) dan ditautkan ke catatan lari (`detailFile`)
  - Impor berkas: Progres → Impor FIT / GPX / TCX (bisa banyak berkas). Parser FIT biner (`FitParser`), GPX dan TCX (`XmlTrackParser`, SAX), lalu `ActBuilder` (port buildAct: jarak, waktu bergerak, D+/D− dengan ambang adaptif, HR, kadens, split per km, GAP, rute, profil elevasi, deret pace/HR/kadens). Aktivitas yang sama (tanggal, jam, jarak) dilengkapi, bukan digandakan
  - Layar detail (ketuk catatan di Progres): statistik, rute, elevasi, pace, HR, zona HR, split, segmen
  - Zona HR (`Zones`): LTHR atau cadangan HR, dari pengaturan hasil impor cadangan
  - Tes: `ActGoldenTest` (titik sintetis dan berkas FIT, GPX, TCX buatan dicocokkan dengan buildAct/parseFit web; data dari `tools/golden-act.mjs`), `ZonesTest`
  - Belum ada pada aktivitas yang baru diimpor dari berkas: segmen interval dari lap FIT (`sg`), deret padat (`tl`), zona per menit (`hz`, `vz`, `zs`), VAM. Pada aktivitas dari cadangan web, data ini tersimpan utuh di berkasnya tetapi belum ditampilkan

- **Tahap 1b (selesai, kecuali yang tercantum di bawah): metode latihan, sesi quality kedua, strength.**
  - `TrainingMethod` (port `02b-metode-latihan.js`): Pyramidal (VO2max jadi tempo, steady zona 3 di easy sedang dan long run jalan), Polarized (threshold/tempo jadi interval keras), MAF (Fondasi tanpa sesi keras), serta `advice()` untuk saran distribusi intensitas
  - `QualityTwo.kt` (port `q2Stage/q2Pool/q2Make/q2Apply`): hari short menjadi sesi quality kedua untuk 5K, 10K, HM, FM, dan Performance Build (6 hari, hari short dua hari sebelum long run), tiga tahap dosis, dibatasi sekitar 20% waktu lari
  - `Strength.kt` (port `strengthFor/ankleFor/upperFor/placeStrength`): Strength A dan B, ankle, upper 1 atau 2 kali sepekan, mengikuti fase, minggu cut, dan hari sebelum sesi keras
  - Pengaturan baru: `method`, `qSess`, `sLeg`, `sAnk`, `sUp` (disimpan di `SettingsStore`, dibaca dari cadangan web; kolom kosong di cadangan lama dianggap bawaan web). Profil → Metode latihan, Sesi quality per pekan, Strength
  - Layar Hari ini dan Jadwal menampilkan penanda metode dan blok strength (ringkas di Jadwal, lengkap saat diperluas)
  - `PlanGoldenTest` kini 48 skenario (27 baru: tiap metode, sesi kedua, strength, zona HRR dan LTHR) dan membandingkan `q2`, `tm`, `mod`, `str`, `ank`, `up`; `saranDistribusiCocokDenganVersiWeb` mencocokkan `tmAdvice`

- **Sisa tahap 1 (selesai):**
  - `GainSpread.kt` (port `gainTarget/gainSet/gainSpread`): D+ mingguan rencana trail naik bertahap (maks +10% per pekan beban penuh, pekan cut 80%, pekan ke-3 puncak 90%, taper mengikuti faktor) dan dibagi ke long run (loop Ungaran), medium, hike, dan easy. Aktif untuk trail kecuali `gSmooth=false`; `gBase` (D+ awal rantai) ikut. Disimpan di `SettingsStore` dan dibaca dari cadangan web (kosong = nyala, seperti web)
  - `PlanGoldenTest` kini 59 skenario: 9 skenario `*-gs` baru (ultra 50/100 km, 5 hari, gBase, event latihan, pyramidal, polarized, ultra road, konversi PB). 50 skenario lama dibangkitkan ulang dan tidak berubah
  - `EasyPace.kt` (port `easyWeeks/easyPaceEst`): pace easy per pekan dari lari dengan HR di bawah batas easy (tanpa sepeda, tanpa lari lebih dari 20 m D+/km), dipakai pekan terakhir sebelum pekan berjalan. `PlanEngine.plan(s, today, easyPace)` meneruskannya ke `qualBalance`, `q2Apply`, dan `methodEasy`; `MainViewModel` menghitungnya dari riwayat lari. Tes: `EasyPaceTest`
- **Sisa tahap 2 (sebagian):** impor cadangan kini juga memulihkan `daily` (tabel `daily`: HR istirahat, HRV, rasa kaki, mood, jam tidur, plus objek web utuh di `raw`), `gear` (tabel `gear`), serta `done`, `mv`, `pr`, `fav`, `sp`, `sl`, `cs` (tabel `kv`, JSON utuh). Room skema v4 (migrasi 3 ke 4). Tes baru di `BackupParserTest`. Belum ada: layar untuk mengisi dan melihat data harian dan gear, serta pemakaian `done`/`mv`/`pr` oleh Jadwal.

Belum ada di perencana:
- teks bahasa Inggris (tahap 10)
- penggunaan `TrainingMethod.advice()` di layar Progres (fungsinya sudah ada dan teruji, kartunya belum dibuat)

Cara memperbarui data acuan: dari akar proyek web, `node native-android/tools/golden-plan.mjs` (perencana) dan `TZ=UTC node native-android/tools/golden-act.mjs` (aktivitas). Tambah skenario di objek `SC` pada skrip itu.

## Urutan porting yang disarankan

| Tahap | Isi | Sumber di web |
|---|---|---|
| 1 (selesai) | Pengganti `plan(s)` yang penuh: jenis lomba (trail, ultra road, Performance Build, No Race), tanjakan D+, sesi 1 atau 2 quality, back-to-back ultra, pasca-lomba | `02-i18n-penyimpanan-perencana.js`, `03-perencana-gear-statistik.js`, `02b-metode-latihan.js`, `05b-strategi-medan.js`, `24d-transisi-pb-lomba.js` |
| 2 (selesai sebagian: pengaturan dan log) | Impor cadangan JSON lama; sisa: acts (rute), daily, gear, PR, favorit, ke Room | `20-zona-log-bulanan-pr-cadangan.js`, `06-zona-hr-impor-aktivitas-cuaca.js` |
| 3 (selesai sebagian: FIT/GPX/TCX, detail, zona) | Sisa: analisis interval (`sg`, `tl`), training load, kesesuaian rute serupa | `06-...`, `08b-analisis-interval.js`, `08-kesesuaian-rute-serupa-detail.js` |
| 4 | Notifikasi pengingat dan sesi (WorkManager + NotificationChannel), izin latar | `19-notifikasi-pengingat.js`, `40-izin-latar.js` |
| 5 | Widget: salin `widget-native/` (sudah Java native; paket sudah diganti ke `com.endurancevault.app.widget`) dan sambungkan ke Room | `widget-native/`, `widget-sync.js` |
| 6 | Plugin jam Huawei: jadikan modul Gradle langsung (hapus lapisan Capacitor `HuaweiWatchPlugin`) | `plugins/huawei-watch-capacitor/` |
| 7 | Cuaca, nutrisi/fueling, strength, tidur dan nyeri, ulasan mingguan | `07-*.js`, `07f-jadwal-fueling.js`, `03-strength`, `19b-*.js` |
| 8 | Peta, rute, video peta 3D, kartu bagikan, editor foto/video (paling berat; pertimbangkan MapLibre + Media3) | `17-*.js`, `21*-*.js`, `10-kartu-bagikan.js`, `14-*.js` |
| 9 | Akun Google, Drive autosync (Credential Manager + Drive API) | `27-akun-google.js`, `scripts/add-google-drive.mjs` |
| 10 | i18n: pindahkan kamus `01-i18n-kamus-inggris.js` ke `strings.xml` (id, en) | `01-i18n-kamus-inggris.js` |

Mulai dari tahap 1 dan 2: tanpa keduanya aplikasi native belum bisa menggantikan versi hybrid untuk pengguna yang sudah punya data.

## Catatan penting

- Mengganti paket berarti Android memandangnya aplikasi baru: data dan pembaruan dari `com.rencanalari.app` tidak ikut. Pakai Impor cadangan (tahap 2).
- Buat OAuth client Android baru di Google Cloud untuk `com.endurancevault.app` + SHA-1 keystore.
- Keystore lama boleh dipakai; paket baru tetap butuh instalasi baru.
- Gradle wrapper tidak disertakan: buka folder ini di Android Studio, atau jalankan `gradle wrapper --gradle-version 8.9`.

## Update implementasi native lanjutan (2026-11-06)

### Tahap 2b — layar data pendamping native (implementasi awal)

Sudah ditambahkan pada proyek sumber native:
- `CompanionDataSection.kt`: formulir native untuk catatan kondisi harian (tanggal, RHR, HRV, rasa kaki, mood/stres, tidur) dan daftar 5 catatan terakhir.
- Pengelolaan gear native: tambah gear, model/catatan, km awal, batas jarak, pensiun/aktif, hapus, dan ringkasan jarak pemakaian dari aktivitas yang telah memiliki `gearId`.
- `CompanionDao`: operasi simpan harian, simpan gear, dan hapus gear.
- `MainViewModel`: menggabungkan Flow pengaturan, aktivitas, data harian, dan gear ke `UiState`; menambahkan aksi simpan/hapus.
- `ProfileScreen` dan `AppRoot`: menghubungkan layar dan aksi ke ViewModel.

Batasan tahap ini:
- Belum ada UI untuk menautkan gear ke aktivitas atau memilih gear default.
- Belum ada edit seluruh metadata/raw harian hasil impor; penyimpanan formulir membuat entri native dengan field terstruktur.
- Belum ada pemakaian data daily untuk readiness/recovery, atau gear untuk rekomendasi penggantian.
- Belum ada uji instrumentasi Compose/Room untuk layar baru.

### Status validasi

Lingkungan pengerjaan ini memiliki Java 21, tetapi tidak menyediakan executable `gradle`, Gradle wrapper, Android SDK, atau Android Studio. Karena itu perubahan kode sudah ditulis dan diperiksa secara statis, tetapi belum dapat dinyatakan lolos kompilasi Android. Validasi wajib berikutnya adalah `./gradlew testDebugUnitTest` dan `assembleDebug` pada lingkungan Android dengan SDK terpasang.

## Implementasi native: Training Load, Training Effect, Recovery, Readiness

Tahap ini menambahkan `domain/TrainingMetrics.kt` sebagai port Kotlin dari modul sumber `15-training-load-te-kebugaran.js`, lalu menampilkan hasilnya pada bagian atas tab Progres melalui `TrainingLoadSection.kt`.

Cakupan saat ini:
- Beban sesi berbasis HR rata-rata dengan fallback estimasi durasi/jenis sesi.
- Beban harian dan kurva Fitness (CTL, 42 hari) serta Fatigue (ATL, 7 hari), Form (TSB), load 7 hari, rasio ATL:CTL, dan kisaran beban indikatif.
- Training Effect aerobik dan anaerobik; histogram HR FIT/TCX dibaca langsung dari berkas detail tanpa memuat rute/split penuh. Jika hanya HR rata-rata tersedia, TE anaerobik tetap kosong.
- Estimasi waktu recovery per sesi, sisa recovery, dan penyesuaian TE aerobik tinggi.
- Readiness berbobot dari recovery, beban, tidur, HRV, HR istirahat, rasa kaki, dan stres/mood.
- Unit test untuk kondisi kosong, pembentukan kurva beban, dan kesiapan harian.

Batas yang masih perlu diselesaikan pada tahap lanjutan: parsing detail tidur (terbangun, deep/REM, nap), sleep debt, data nyeri/cedera, data recovery dari Huawei Watch, kalibrasi skala load/recovery dari angka jam, serta histori dan kalibrasi bobot readiness. Nilai saat ini adalah estimasi latihan, bukan pengukuran fisiologis atau saran medis.
