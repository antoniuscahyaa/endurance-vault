# Stage 6.6.2 — Native UI parity pass

Version: 0.5.1 (versionCode 15)

## Source basis

The old application source was reviewed directly: `src/styles/ev-skin.css`, `src/styles/dock.css`, `src/js/layout-clay.js`, `src/js/layout-compact.js`, and `src/index.template.html`.
The native UI remains Jetpack Compose; no WebView was introduced.

## Applied

- Reworked the bottom navigation into a floating, rounded dock with metallic surface, thin edge, soft elevation, active-state indicator, and labels shown only for the selected destination. The primary Today destination uses the orange filled active state.
- Added reusable EnduranceVault panel, group-heading, metric-tile, and metric-row primitives to keep panels, subgroups, and statistics visually consistent.
- Applied the panel language to Today, Schedule, Progress, Activity Detail, companion and online service status cards, and supporting strength blocks.
- Added page eyebrow labels and clearer section grouping to Today, Schedule, Progress, and Profile.
- Added an eight-week activity-volume chart based only on saved run activities. Cycling and invalid dates are excluded; no synthetic values are created.
- Preserved the existing Gunmetal / orange default palette, dark and light system modes, native navigation, Huawei flows, weather, A-GPS, notification forwarding, AI Coach, and all training calculations.

## Deliberate limitations

- This pass does not claim pixel-perfect parity. The legacy app has several selectable skins and a much richer dashboard/profile/progress pager hierarchy; these need screen-by-screen reconstruction and screenshot comparison on a device.
- The legacy display font is not copied unless its actual font asset and license are bundled. Current Compose typography remains system sans-serif.
- The old dock has five destinations and a separate settings action. Native currently retains its four functional destinations to avoid exposing duplicate or dead navigation targets.
- The original web-only layout scripts are treated as visual references, not copied into the native app.

## Validation

- Source files and XML/YAML packaging checks should be run in CI.
- Gradle compilation, instrumentation, and visual verification on physical Android devices are not asserted by this artifact.
