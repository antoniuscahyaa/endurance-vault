# Stage 6.9.5 – Pengaturan Zona HR sama dengan rencana lari

- Satu komposabel `HrZoneSettings` (ui/screens/HrZoneSettings.kt) menggantikan dua editor lama (Profil dan layar Watch).
- Layout mengikuti section "Zona HR" di rencana lari: panel buka-tutup Default (metode, ringkasan zona, Kirim zona ke jam), Patokan sesi, LTHR, HRR (Karvonen), dan HR lomba per kategori.
- Tabel zona berwarna dengan sudut membulat (16dp); persen tiap zona diedit langsung di kolom tabel, bpm dihitung ulang langsung, dengan tombol "Kembalikan persen ke awal".
- Perubahan tersimpan otomatis saat kolom kehilangan fokus, Done ditekan, metode diganti, atau persen di-reset (padanan event change di web); tidak ada tombol Simpan.
- Teks info (LTHR otomatis/manual, HR istirahat dari median 14 hari, peringatan persen tidak berurutan) memakai kalimat yang sama dengan web.
- Profil: form besar tidak lagi memuat kolom zona, dan isiannya tidak ter-reset saat zona berubah.
- Belum ada: panel "Zona HR · LT test" (fitur LT test belum dimigrasi ke native).

Versi: 0.5.10 (versionCode 24). Belum dikompilasi di lingkungan ini (tidak ada akses jaringan untuk dependensi Gradle); jalankan build dan ZonesTest.
