# Stage 6.6.1 — UI Parity Foundation

## Source of truth
The original app's `src/styles/ev-skin.css`, `src/styles/soft-clay.css`, and `src/js/main/05-lomba-tema-prediksi.js` were inspected.

Important distinction: the original app's **default** skin is EnduranceVault (`data-skin="ev"`), a gunmetal/metallic interface with orange-fire accents. Soft Clay is the custom skin, not the default. This native stage therefore restores the original default EV palette and follows Android's system light/dark setting. Theme selection and the other legacy skins are left for a subsequent UI parity pass rather than silently pretending they have been migrated.

## Implemented
- Original EV dark palette: `#0B0C0F` background, gunmetal panels, orange accent.
- Original EV light palette: cool silver background and metallic surfaces with burnt-orange accent.
- System light/dark mode switching.
- Shared Compose typography scale, weights, spacing rhythm, and rounded shape tokens.
- Floating capsule bottom navigation with border and elevation, reflecting the original dock treatment.
- Matching Android window backgrounds and system-bar icon contrast for light and dark resources.
- Existing screens and business logic are retained; no training calculations or data models changed.

## Deliberately not claimed as complete
- The old app's selectable skins (Trail, Grafit, Pulse, Puncak, Custom/Soft Clay) are not yet exposed natively.
- Exact legacy font files are not bundled in the source ZIP; this stage uses the platform sans-serif family. Poppins/font preference parity remains pending.
- Dashboard content hierarchy and each detailed page still need a screen-by-screen parity pass against the old app. This is a foundation stage, not a claim that every pixel and feature layout is identical.

## Release
- applicationId: `com.endurancevault.app`
- versionCode: 14
- versionName: `0.5.0`
