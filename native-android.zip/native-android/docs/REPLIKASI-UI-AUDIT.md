# EnduranceVault — Audit Replikasi UI Legacy ke Native

## Keputusan visual

Arah yang dipilih: **A — replikasi visual dan struktur aplikasi lama sedekat mungkin**. Native Compose tetap menjadi teknologi implementasi dan palet warna mengikuti tema dasar proyek native yang sekarang. Tidak ada migrasi paksa ke Soft Clay atau Gunmetal.

## Struktur navigasi legacy yang menjadi acuan

Sumber: `src/index.template.html` pada arsip aplikasi lama.

- Dock utama: **Hari ini**, **Profil**, **Jam**, **Minggu**.
- **Jadwal** merupakan tujuan kontekstual yang tampil saat rencana latihan aktif.
- Profil memuat pengaturan sasaran/rencana, kondisi harian, gear, zona HR, impor/cadangan, layanan online, AI Coach, notifikasi, dan konfigurasi terkait.
- Halaman Minggu menampilkan daftar sesi harian dan penyesuaian minggu.
- Halaman Jam berisi kontrol perangkat dan sinkronisasi.
- Banyak fitur legacy lain berada di modul JS terpisah (analitik, route editor, share cards, video map/HUD, strength, aktivitas, integrasi eksternal). Keberadaan modul legacy tidak otomatis berarti seluruh implementasi native-nya sudah tersedia.

## Perubahan nyata dalam putaran ini

1. Menambahkan akses **Progres** sebagai subhalaman dari **Profil**, bukan menambahkannya sebagai tab dock kelima. Sub-navigasi Profil/Progres ditempatkan sebagai bar tetap tepat di atas dock utama, mengikuti struktur `pbar` legacy; tidak lagi berupa chip di dalam konten halaman.
2. Halaman Progres memakai sub-navigasi yang sama untuk berpindah kembali ke Profil; konten mencakup ringkasan performa, training load, grafik volume, impor FIT/GPX/TCX, serta riwayat aktivitas yang sudah disediakan oleh implementasi native.
3. Dock utama menggunakan label Indonesia yang selaras dengan aplikasi lama: Hari ini, Profil, Jam, Minggu. Jadwal tetap kontekstual.
4. Wiring sub-navigasi Profil/Progres dipindahkan ke dock bawah tetap dan import `ProgressScreen` ganda di `AppRoot.kt` dibersihkan.
4. Filter halaman Minggu menggunakan label **Minggu ini** dan **Riwayat**.
5. Tema, domain training, rumus, penyimpanan, pengaturan HR, serta protokol Watch tidak diubah oleh pekerjaan UI ini.

## Peta halaman native saat ini

| Area legacy | Tujuan native | Status audit |
|---|---|---|
| Hari ini | `TodayScreen.kt` | Ada; perlu validasi visual rinci terhadap seluruh panel legacy |
| Profil/pengaturan | `ProfileScreen.kt` | Ada; banyak pengaturan dan integrasi sudah ditanamkan, tetapi parity per kontrol belum dibuktikan |
| Progres/analitik | `ProgressScreen.kt` | Ada dan kini terhubung dari Profil; cakupan grafik/analitik masih lebih kecil daripada modul legacy |
| Jam/perangkat | `HuaweiWatchSection.kt` di route Jam | Ada; perlu audit alur dan tampilan per fungsi |
| Minggu | `ScheduleScreen.kt` | Ada; mencakup status sesi, expand, swap, libur dadakan, dan riwayat penyesuaian |
| Jadwal keseluruhan | `PlanOverviewScreen.kt` | Ada; perlu perbandingan visual rinci |
| Detail aktivitas | `ActivityDetailScreen.kt` | Ada; grafik/analisis perlu dibandingkan dengan legacy |

## Fitur legacy yang belum boleh dinyatakan setara

Audit nama modul JS lama menemukan area besar yang perlu ditelusuri dan dipetakan satu per satu: metode latihan, gear/statistik, kondisi pagi, lomba/prediksi, strategi medan, impor aktivitas/cuaca, rute serupa, analisis interval, segmen kustom, sesi interval kustom, strength/gerakan 3D, kartu berbagi/stiker/template/editor, training load/fitness, ikon agenda/rute otomatis, editor rute/peta, AI Coach, notifikasi, tidur/nyeri/keseimbangan, pencegahan cedera/sepeda, log bulanan/PR, video peta/terrain/trail/HUD, statistik, elevasi, ringkasan progres, easy-run score, siklus, ekspor Intervals, Google account, Huawei watch/sync/strength/AGPS, zona HR/LT test, kursus ke jam, Strava/GPX, mode demo, cuaca ke jam, live cycling, background permissions, format watch, dan riwayat lari.

Area nutrisi/fueling/cairan sengaja tidak dimasukkan karena keputusan proyek sebelumnya untuk mengecualikannya.

## Batas validasi

- Pemeriksaan sumber dan wiring navigasi dilakukan pada proyek ini. Pemeriksaan statis mengonfirmasi route Progres, callback dari Profil, aksi kembali, serta integrasi Jam tetap terhubung.
- Build Gradle dan uji perangkat belum dijalankan di lingkungan ini; tidak ada klaim kompilasi atau uji runtime.
- ZIP hasil harus diperlakukan sebagai build kerja untuk diuji. Bug kompilasi/runtime dan mismatch visual diperbaiki dari hasil pengujian berikutnya.
