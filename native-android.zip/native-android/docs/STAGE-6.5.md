# Stage 6.5 — External Services Completion

Version 0.4.9 (versionCode 13).

## Included
- Seven-day Open-Meteo forecast with current conditions, precipitation probability, wind, and separate Open-Meteo Air Quality request (US AQI, EU AQI, PM2.5, PM10). Air-quality failure does not discard weather forecast.
- Location selection by city geocoding, explicit one-shot GPS lookup after runtime permission, or manual coordinates.
- Send selected weather location to the Huawei weather protocol and request immediate refresh. Watch-side support remains firmware-dependent.
- A-GPS enable/disable, optional HTTPS mirror, status, and manual source download test through the existing protocol bridge.
- Phone notification forwarding service, Android Notification Access settings link, app filters, quiet hours, screen-off filter, test notification, and delivery status. Message content is not stored by the listener.
- Online Groq AI Coach conversation using GPT-OSS 120B with optional browser_search tool, local recent activity/daily-condition/plan context, and explicit user-triggered submission.
- Groq API key encrypted with an AES-GCM key held by Android Keystore; the encrypted preference is excluded from Android cloud backup and device transfer.
- All fueling/hydration planner UI, persistence, calculations, and training-plan fueling prompts removed as requested. No fueling/nutrition fields are sent to AI Coach.

## Important boundaries
- Weather, AQI, Groq, geocoding, and A-GPS test require internet.
- GPS is requested only after the user presses Use GPS; no background location permission is requested.
- Notification forwarding requires the user to grant Notification Access in Android Settings and a compatible connected watch.
- Huawei weather, A-GPS, and notification delivery have protocol support in source but still require physical Watch Fit 4 validation.
- AI Coach requires the user's own Groq API key. The key is not embedded in the APK. The user controls whether to include app context and whether to enable web search.

## Validation status
Manifest and backup-rule XML were parsed; Kotlin source was syntax-checked for parser errors. Gradle is not installed in this environment, so Android compilation, unit tests, live API calls, and watch hardware behavior remain to be verified by GitHub Actions and device testing.
