# Today dashboard update

- Reworked Today screen into a dashboard based on the supplied references.
- Shows today's planned session and existing session detail/support blocks.
- Shows current plan week, actual recorded run distance, and daily completion indicators.
- Shows ACWR from TrainingMetrics, a consecutive run-day streak derived from recorded runs, latest run, and CTL/ATL/TSB.
- Preserves manual run logging.
- Weather panel is not shown in this pass because Today does not currently receive structured current-weather data; no sample weather is fabricated.
- No training formulas, plan generation, database schema, or Bluetooth behavior changed.
- Build/device verification remains pending; this environment has no Gradle wrapper or system Gradle.
