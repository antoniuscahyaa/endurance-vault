# Stage 6.8 — Week cards and schedule adjustments

- Week dock now opens the This week / History schedule surface rather than Progress analytics.
- Week days use individually expandable cards; expanded cards show session detail, support blocks, and eligible actions.
- Manual day swaps are stored in app-private SharedPreferences, limited to the same generated week and exclude race/event target days. A warning is shown for heavy-to-heavy swaps; swap undo is available from the expanded card.
- Unplanned rest supports the source app's reason choices (busy, tired, sick/pain, other), records the source date and target allocation, and offers a no-spread rest when sick/pain is selected.
- Same-week targets are future eligible easy/short/medium/long sessions. Per-target caps follow the old app's 40% easy / 25% long-run rules (minimum 2 km); tired halves the cap. The source day is marked rest and allocations are shown on target days. History supports undo.
- Fueling features remain excluded.

## Important implementation boundary

The current Android plan generator still owns the base plan. This stage stores adjustment overlays separately and renders them over generated week cards. It does not yet rewrite the underlying `PlanEngine` schedule model or recalculate downstream training-load metrics from those overlays. Verify adjustment behavior against the source app before treating this stage as full parity.
