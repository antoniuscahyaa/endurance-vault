# EnduranceVault Native — UI/Layout Alignment Pass

## Scope
This pass aligns the native Compose UI across the primary destinations while retaining the current native theme and existing business logic. It does not force Soft Clay or Gunmetal styling.

## Applied
- Unified panel geometry: restrained 16dp corners, thin outline, no artificial elevation.
- Unified metric tile geometry and visual density.
- Standardized page edge spacing and vertical rhythm on Today, Profile, Progress, Activity Detail, Week, and Plan Overview.
- Standardized the bottom navigation dock spacing, height, icon scale, and safe-area handling.
- Reused the shared native panel component in Plan Overview and Huawei Watch.
- Improved Today session hierarchy with an explicit session eyebrow and clearer spacing.
- Kept contextual Schedule navigation behavior and existing screen routes.
- Kept current theme colors, typography system, HR-zone editor, watch actions, plan engine, and activity calculations unchanged.

## Source alignment reference
The legacy `src/index.template.html` organizes the app around the primary week/today view, a separate plan-wide schedule overview, profile/configuration, progress analytics, and watch-related tools. The native app retains the corresponding destinations and refines their shared layout primitives. This is a native UI alignment pass, not a claim that every legacy web-only tool has already been ported.

## Exclusions
Fueling/nutrition UI is not added as part of this pass, consistent with the migration scope.

## Validation
- Source-level changes only; no Gradle wrapper or installed Gradle executable was available in the working environment, so a Gradle build/device render could not be run here.
- Run the project's normal Android build and inspect the six destinations on-device. Any compile/runtime or visual defects should be corrected in the next iteration.
