# Training Readiness parity — 0.5.16

This update changes Huawei sleep ingestion to select one longest main sleep (>=180 minutes) per wake-up date, rather than summing every non-nap group. Stage overlap is deduplicated at minute resolution using the legacy priority (deep/REM > awake > light > unknown). Sleep HR is now sampled only inside those selected main-sleep windows; nap and secondary groups are excluded.

The reference behavior is `hwSleepNights` / `hwTrimFrags` in legacy `29-huawei-watch-sync.js`. The implementation ports the main-night grouping and selection contract. It does not yet claim full parity for every edge case in legacy fragment trimming, workout-overlap clipping, wake-gap classification, or for every recovery/training-load historical calibration path. Those require fixture-level comparisons using the same exported watch payload and activity history.

RHR continues to prefer the watch's daily average (`rhrAvg`), HRV comes from watch RMSSD readings, and existing watch ownership markers allow refreshed watch values to replace prior watch-owned values without overwriting manual entries.
