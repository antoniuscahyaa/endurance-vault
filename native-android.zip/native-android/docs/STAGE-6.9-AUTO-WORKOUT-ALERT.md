# Stage 6.9 — Automatic Workout Detection Alert

## Included
- The existing Huawei connected-device foreground service observes completed protocol sync summaries.
- When a sync summary reports one or more workouts written by that sync, a separate Android notification is posted.
- Notification is deduplicated by the summary window and workout count (`from:to:workouts`).
- Tapping the notification opens EnduranceVault. The notification text directs the user to Huawei Watch > Sinkronkan to import into the app's Activity Log.
- Existing protocol transport, pairing, Room activity import, and manual sync path are not replaced.

## Important limitation
This stage is a background **detection notification**, not a pending-import confirmation dialog. The keep-alive service syncs the watch protocol database, but it does not call the app's Room importer. The user must open the Huawei Watch screen and run Sync to copy the workout into the EnduranceVault Activity Log. This stage does not silently mark a planned Week session complete and does not auto-import into Room.

## Validation
Source-level change only. Gradle compilation and physical Huawei Watch testing have not been performed in this environment. Android notification permission and the `Aktivitas baru dari jam` notification channel must be enabled.
