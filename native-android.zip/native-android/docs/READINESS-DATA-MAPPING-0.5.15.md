# Readiness sensor mapping — 0.5.15

This update corrects the native Readiness data path to match the legacy watch-sync behavior.

## Field lineage

| Readiness factor | Source in native watch store | Normalized field | Rule |
|---|---|---|---|
| Sleep | `sleep_segments` (stage segments), `sleep_scores` | `DailyEntity.sleepH`, `raw.sleep`, `deep/rem/light`, wake fields | Group main-night segments; assign to local wake date; nap is separate and capped at 180 min for effective sleep. |
| 7-day sleep debt | Same daily sleep rows | calculated from each local date | Requires at least 3 of the last 7 nights; configurable need 5–10 h, default 7.5 h. |
| HRV | `hrv_readings` (`rmssd`) | `DailyEntity.hrv` | Latest valid nightly RMSSD per local wake date, same as legacy `hwHrvPlan`; compare against up to 14 prior daily values, needs 3 baseline days for a score. |
| Resting HR | `step_samples.resting_heart_rate` | `DailyEntity.rhr` | Daily average of valid resting-HR samples, matching legacy `rhrAvg` mapping; not the final isolated sample. |
| Sleep HR | `step_samples.heart_rate` inside main sleep window | `raw.shr` | Average only samples within the grouped main sleep interval, excluding nap segments; requires at least 10 samples. Compare with up to 14 prior nights and require 3 baseline nights. |
| Recovery | Training-load session model + morning condition adjustment | computed recovery remaining | No synthetic watch recovery value; use watch recovery when present in workout metadata, otherwise existing native estimate. |
| Training load | Imported workouts, HR histogram / average HR, plan context | ATL, CTL, ratio | Existing native TRIMP/load pipeline. |
| Pain | User-entered pain log | `ReadinessConfig.painEntries` | User-entered; no sensor inference. |
| Leg feel / mood | User morning check | `DailyEntity.leg`, `DailyEntity.mood` | User-entered only. |

## Correctness changes
- Sleep, HRV, resting HR and sleep HR each select their own latest fresh daily record. A same-day manual leg/mood entry with no sensor data no longer hides the previous night's watch measurements.
- HRV and RHR baselines are built relative to that factor's own latest measurement date, not a potentially unrelated latest manual row.
- Watch-owned RHR/HRV/Sleep-HR values carry ownership markers so future watch syncs can refresh watch values without overwriting manual values.
- Sleep-HR values are never fabricated: the protocol layer returns a value only when at least 10 valid HR samples fall inside the main sleep window.
- Missing factors remain absent from the available-factor count; no placeholder or synthetic score is introduced.

## Tests added
- A manual condition row today does not hide the previous night's sleep, HRV, RHR or sleep-HR factor.
- Sleep-HR payload import and watch-source ownership.
- Legacy-compatible daily average resting-HR mapping.

## Verification
Static source assertions pass. This environment does not have Gradle or a Gradle wrapper, so Android compilation and JUnit execution have not been run. Run the project's Android CI/build before installing this package.
