# Week strip equal-height cells — 0.5.21

Reserved a fixed 16dp distance-label row in every weekday tile. Completed days display
their activity distance in this row; missed and not-yet-passed days reserve the same
space without a label. All seven tiles therefore keep the same height regardless of
whether a distance is present.

Version: 0.5.21 (versionCode 35)
