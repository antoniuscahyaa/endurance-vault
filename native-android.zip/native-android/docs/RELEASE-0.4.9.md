# EnduranceVault Native 0.4.9

- Package: `com.endurancevault.app`
- versionCode: 13
- versionName: 0.4.9
- This is an update package; keep the existing signing keystore and GitHub `KEYSTORE_BASE64` secret.
- Do not uninstall the installed app; install the signed release APK as an update.
