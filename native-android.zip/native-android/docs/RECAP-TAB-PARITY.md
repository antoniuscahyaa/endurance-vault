# Recap (Rekap) tab parity pass

Referensi: tab **Rekap** di `rencana-lari-apk-20.zip` (`GROUPS` di `layout-compact.js`).
Basis: `EnduranceVault-Route-Analytics-Parity-Pass.zip`. Tidak ada perubahan skema Room, package, signing, atau rumus beban/readiness.

## Struktur kartu (urutan sama dengan web)
1. **Progres** – ringkasan (minggu tercatat, rata-rata km, bar target), evaluasi teks minggu terakhir vs rencana, tabel Minggu / Rencana km / Tercatat km / Pace easy / HR easy / Δ pace, prediksi lomba (indeks kemampuan + gap ke target), prediksi dari PR (Riegel dan VDOT), riwayat pace easy (grafik + tabel).
2. **Grafik mingguan** – 16 minggu, metrik Jarak / Waktu / Tanjakan / Turunan / VAM, tipe Bar / Line, ketuk minggu untuk caption dan daftar sesi (ketuk sesi membuka detail), penanda lonjakan turunan ▲/▲▲.
3. **Kepatuhan rencana** – persen minggu ini, cincin, tren 4 minggu, arah vs rata-rata sebelumnya, saran geser (teks; lihat catatan).
4. **Ulasan mingguan** – navigasi minggu (‹ › Minggu lalu), jarak/sesi/waktu/tanjakan/training load/HR/konsistensi, bar target dan vonis, PR baru, rekor lari terpanjang dan jarak mingguan, streak hari dan minggu, lencana pencapaian.
5. **Log bulanan** – pager geser per bulan (maks 24), sel hari dengan km, titik sepeda, penanda strength, cincin hari ini, ketuk hari untuk membuka sesi, tombol Bulan ini.
6. **Kalender konsistensi** – tabel bulan × (Jarak, Jam, Elev. gain, Hari) dengan delta vs tahun lalu dan baris Total; navigasi tahun dibagi dengan heatmap.
7. **Heatmap tahunan** – grid gaya GitHub, metrik Jarak / Load, navigasi tahun, ketuk sel untuk detail hari, hari terbaik, legenda.

Setiap kartu menampilkan ringkasan (angka utama, penanda tren, visual mini) saat tertutup dan detail saat kepala kartu diketuk, sama seperti `pgs-*` di web.

## File
- `domain/RecapAnalytics.kt` – logika murni (tanpa Android), diport dari `03-perencana-gear-statistik.js`, `20-zona-log-bulanan-pr-cadangan.js`, `24b-kepatuhan-rencana.js`, `04-kondisi-pagi-ulasan-bandingkan.js`, `22-statistik-data.js`, `05-lomba-tema-prediksi.js`, `14-editor-foto-latar-video.js` (spikeScan).
- `ui/screens/RecapTab.kt` – UI Compose.
- `ui/screens/ProgressScreen.kt` – blok Recap lama diganti `RecapTab(state, onOpen)`; chip diberi label "Rekap".
- `test/.../RecapAnalyticsTest.kt` – 7 tes JVM (bucket mingguan, VAM, spike, evaluasi Progres, kepatuhan, ulasan/streak/pencapaian/PR, agregat & heatmap, prediksi).

## Perbedaan yang disengaja / belum ada
- Kartu native lama **Activity Summary** dan **12-Month Volume Trend** dihapus dari Rekap karena tidak ada di tab Rekap web.
- **Saran geser rencana**: kepatuhan menampilkan alasan dan saran, tetapi tombol "Geser rencana / Batalkan geser" belum ada karena mesin rencana native belum punya skala mingguan (`S.wkScale`).
- **Ringkasan akhir siklus (loop 6,3 km)** dan **GPX jalur lomba custom** pada kartu Progres belum diport.
- **Bagikan gambar** bulanan di web diganti **Bagikan ringkasan** (teks) di native; kartu gambar dengan pilihan sepeda/hiking/strength belum ada.
- Hiking tidak dibedakan dari sepeda karena entitas native hanya punya `run | bike`; hiking tidak masuk VAM mingguan.
- Penanda "sudah selesai" memakai ada-tidaknya lari di tanggal itu (peta `done` dari web tidak dimuat di UiState). Hari libur dadakan dibaca dari `week_adjustments_v1`.
- Elevation loss hanya dari detail aktivitas yang sudah dimuat (`ActDetail.loss`).

## Verifikasi
- `RecapAnalytics.kt` + `RecapAnalyticsTest.kt` dikompilasi dengan compiler Kotlin 2.0.21 dan 7/7 tes lulus di JVM.
- `RecapTab.kt` hanya diperiksa sintaksnya; build Gradle/Compose dan uji di perangkat belum dijalankan karena lingkungan ini tidak punya akses jaringan untuk dependensi Android. Jalankan workflow GitHub seperti biasa dan kirim log bila ada error kompilasi.
