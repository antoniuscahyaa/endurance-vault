# Status pekerjaan — Replikasi UI EnduranceVault

## Basis kerja
- Source of truth tampilan dan perilaku legacy: arsip aplikasi lama (`src/index.template.html`, `src/styles`, `src/js/main`).
- Basis implementasi: proyek Android native yang diberikan (`com.endurancevault.app`), bukan proyek kosong.
- Strategi: pendekatan A — meniru struktur dan visual legacy sedekat mungkin menggunakan Compose yang sudah ada.

## Pekerjaan pada paket ini
- Navigasi utama: Hari ini, Profil, Jam, Minggu.
- Jadwal hanya muncul saat rencana latihan aktif.
- Progres menjadi subhalaman Profil, bukan tab dock terpisah. Sub-navigasi Profil/Progres tampil tetap di atas dock utama, meniru `pbar` legacy.
- Navigasi Profil ↔ Progres dan route Progres sudah diperiksa secara statis.
- Import `ProgressScreen` ganda di `AppRoot.kt` dibersihkan.
- Fitur Watch, zona HR, layanan online, impor, aktivitas, dan mesin rencana yang sudah ada dipertahankan; tidak ditulis ulang dalam putaran UI ini.

## Batas yang belum diklaim
- Belum ada bukti build Gradle sukses di lingkungan ini karena proyek tidak menyertakan Gradle Wrapper dan Gradle tidak tersedia di runtime.
- Belum ada uji emulator/perangkat fisik.
- Belum semua 102 modul JS legacy memiliki padanan native yang terverifikasi. Keberadaan layar native tidak otomatis berarti seluruh perilaku legacy sudah setara.
- Tidak ada perubahan rumus readiness, CTL/ATL/TSB, Training Effect, pace, PlanEngine, schema database, package name, versionCode/versionName, atau konfigurasi signing.

## Pengecualian fitur
- Fitur fueling/nutrisi/cairan tidak dimigrasikan sesuai keputusan proyek.
