# Today screen — reference matching pass

- Retains the dashboard ordering from the supplied reference: weather (when existing weather data is available), today's session, week strip, ACWR/streak, last run, and training load.
- Uses the existing weather service state and refresh callback; it does not invent weather values. Weather panel remains hidden until a weather result exists.
- Keeps the existing native training metrics, plan details, activity records, and manual logging.
- No user profile name/avatar was added because the native project has no corresponding profile fields/assets in this screen.
- Visual build/device verification remains pending.
