# Today session card refinement — 0.5.24

- Kept the existing Today page content and data sources unchanged.
- Reduced vertical spacing within the session card from 10dp to 6dp.
- Kept the compact content order: session label, workout title, distance, HR/extra-distance
  metadata with recorded badge, expandable session details, then readiness advice panel.
- Fixed the readiness arc clipping by increasing its layout box and insetting the Canvas
  drawing bounds so the stroked arc has room on all sides.
- Reduced the detail toggle's minimum vertical footprint slightly.
- Version 0.5.24, versionCode 38.
