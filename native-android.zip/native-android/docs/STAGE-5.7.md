# Stage 5.7 — Stabilization & Huawei Watch reconnect parity

## Perubahan pada paket ini
- Menambahkan tindakan **Lupakan jam & ikat ulang** pada setiap perangkat Huawei/Honor Bluetooth yang terdeteksi.
- Tindakan meminta konfirmasi, menghentikan keep-alive, memutus koneksi, menghapus hanya identitas autentikasi/pairing milik perangkat terpilih, lalu mencoba pairing ulang.
- Data latihan, aktivitas, dan basis data EnduranceVault tidak disentuh oleh tindakan forget.
- Jika pairing ulang gagal, aplikasi memberi pesan bahwa kunci lama sudah dihapus dan pengguna dapat mencoba Hubungkan lagi.
- Setelah pairing ulang berhasil, keep-alive diaktifkan kembali dan sinkronisasi biasa dimulai.
- Nomor versi dinaikkan ke versionCode 6 / versionName 0.4.2.
- Workflow GitHub Actions diselaraskan dengan secret tunggal `KEYSTORE_BASE64`, mendekode ke `~/.android/debug.keystore`, mengekspor lokasi/password/alias ke Gradle, membangun release, dan memverifikasi SHA-256 sertifikat APK.

## Audit parity dari aplikasi lama
Aplikasi lama menyediakan tombol `hwRebind` yang menjalankan urutan: konfirmasi pengguna → disconnect → `forgetWatch(address)` → `connectWatch(address)` → hidupkan keep-alive. Paket native kini menerapkan urutan yang sama melalui `forgetAndReconnectWatch`.

## Reconnect otomatis
Paket native sudah memiliki `WatchKeepAliveService`: foreground service dengan notifikasi ongoing, retry bertahap saat link putus, ping, sinkron berkala, dan `WatchBootReceiver` untuk memulihkan layanan setelah boot atau pembaruan aplikasi. Ini sesuai tujuan perilaku reconnect latar aplikasi lama.

## Batas verifikasi
- Source audit dilakukan terhadap paket native Stage 5.6.2 dan ZIP aplikasi lama yang tersedia.
- Build log terbaru yang disertakan masih menunjukkan workflow lama gagal karena `ANDROID_KEYSTORE_PATH belum disediakan`; log tersebut bukan bukti keberhasilan workflow yang sudah diperbarui.
- Lingkungan ini tidak memiliki Android SDK/Gradle runner untuk mengonfirmasi build APK. Jalankan GitHub Actions menggunakan workflow di `.github/workflows/android.yml`.
- Pairing ulang dan reconnect Watch Fit 4 harus diuji pada perangkat fisik; source code saja tidak membuktikan perilaku firmware.

## Checklist pengujian perangkat
1. Hubungkan Watch Fit 4 dan konfirmasi pairing di jam.
2. Pastikan sinkronisasi normal dan aktivitas tetap ada.
3. Tekan **Lupakan jam & ikat ulang**, konfirmasi dialog, lalu konfirmasi pairing pada jam bila diminta.
4. Pastikan data aktivitas/riwayat tetap ada setelah pairing ulang.
5. Matikan Bluetooth sebentar lalu hidupkan kembali; amati reconnect dan notifikasi foreground.
6. Tutup aplikasi, tunggu interval keep-alive, lalu pastikan layanan tetap menjaga koneksi.
7. Restart ponsel dan pastikan boot receiver memulihkan keep-alive jika sebelumnya diaktifkan.
