# Profile Today migration pass

- Profile opens on its own Today section; the Profile/Progress selector remains in the app dock.
- Removed duplicate scheduled workout cards and the Live ride / cycling shortcut from Profile Today.
- Profile Today shows a single strength recommendation built from existing PlanEngine strength blocks.
- Readiness uses the existing native TrainingMetrics calculation.
- Suggestions are based on legacy coach rules that can be computed with native data. Legacy actions that mutate old web-only settings are not wired.
- Morning Condition now follows the legacy watch-data workflow: watch-synced sleep/recovery metrics are displayed from the native DailyEntity fields and HuaweiWatchImport raw payload; the only manual inputs are Leg feel (1 fresh to 5 very heavy) and Mood/stress (1 relaxed to 5 very stressed).
- Saving the two manual values preserves synced RHR, HRV, sleep duration and the complete raw watch JSON. It does not replace or clear the watch data.
- The old web app likewise documents that watch-fed RHR, HRV, sleep and related fields are automatic and hidden while watch sleep import is enabled; only Leg feel and Mood remain as manual inputs. The native UI is simplified: it shows the synced summary and the two manual fields directly, without the old manual override toggle for watch fields.
- No readiness/training-load formulas or database schema were changed.
- Build/device verification remains pending.
