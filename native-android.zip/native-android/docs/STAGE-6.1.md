# Stage 6.1 — Data Integrity & Restore Safety

## Fokus
Melindungi data aktivitas dan detail GPS ketika impor cadangan, memperketat validasi nama file aktivitas dari backup, dan menambahkan tes regresi penyimpanan detail.

## Perubahan kode
- `ActStore.write()` menulis JSON ke file sementara pada direktori yang sama lalu menggantinya dengan operasi rename atomik. File detail yang sudah ada tidak ditimpa dengan JSON setengah tertulis bila proses berhenti saat serialisasi.
- Kunci aktivitas backup harus berbentuk tanggal ISO valid (`yyyy-MM-dd`) dengan suffix opsional `~...` yang dibatasi karakter aman. `backupFileName()` menolak key traversal atau tanggal yang tidak valid.
- `BackupParser.activitiesOf()` dan `extractActs()` menerapkan validasi key yang sama.
- Pemulihan backup mengekstrak detail `acts` ke direktori staging terlebih dahulu. File detail backup lama tidak lagi dihapus sebelum ekstraksi berhasil.
- Setelah data Room dipulihkan, set detail backup baru dipasang secara atomik per file; file `f_*.json` hasil impor FIT/GPX/TCX tidak disentuh.
- Version code dinaikkan ke 8 dan version name ke 0.4.4.

## Tes yang ditambahkan
- Penggantian detail aktivitas tidak meninggalkan file sementara dan hasil JSON terbaru dapat dibaca.
- Pemasangan detail backup hanya menyisakan set backup terbaru dan mempertahankan file detail impor lokal.
- Path traversal dan tanggal tidak valid ditolak.
- Ekstraksi backup melewati key berbahaya dan tetap mengambil aktivitas dengan key valid.

## Hal yang sengaja tidak diubah
- Formula readiness, CTL/ATL/TSB, Training Effect, pace, dan algoritma PlanEngine.
- Struktur Room / schema database; tidak ada migration schema pada tahap ini.
- Kunci `watch:<epoch>` dan perilaku deduplikasi workout Huawei.

## Batas validasi
Tes ditambahkan ke suite JUnit Android, tetapi perlu dijalankan di GitHub Actions. Kompilasi Gradle dan restore pada perangkat belum dijalankan di lingkungan ini. Restore tetap menggunakan dua transaksi Room terpisah (aktivitas dan data pendamping); operasi tersebut belum menjadi satu transaksi lintas DAO. Untuk itu disarankan backup sebelum pemulihan besar.
