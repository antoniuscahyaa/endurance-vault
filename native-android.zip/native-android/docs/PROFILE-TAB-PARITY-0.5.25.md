# Profile tab parity — 0.5.25

Implemented against the supplied legacy Profile screenshots and source modules (`24n-kartu-on-track.js`, `18-editor-rute-lanjut-pelatih.js`, and existing readiness/morning-condition modules).

- Added Profile / Progress subtabs inside the existing Profile dock destination. Progress reuses the native ProgressScreen and can open Recap, Fitness, Load, Routes & conditions, and Body directly from On Track signals.
- Added an On Track summary using current plan volume, completed planned sessions, 28-day fitness change, and 7:28 ACWR. Signal rows navigate to their matching Progress section.
- Reordered Profile content as On Track, Today readiness, planned Strength Session, Suggestions, Morning Condition. The legacy Live ride card is intentionally omitted.
- Added readiness 7-day sparkline and average/delta summary.
- Morning Condition shows watch-derived RHR, sleep, HRV, sleep HR, nap, SpO2 and respiratory rate, with recent averages for RHR/sleep/HRV. Added date, leg-feel and emoji mood entry controls; biometric watch fields remain read-only from sync.
- Added persistent light-week control (70% of unfinished run sessions for the selected current week), sick/injured mode (next 3 days rest, remaining current-week sessions reduced 20%), and auto-adjust toggle. Native auto-adjust currently handles a heavy/unplanned run from today/yesterday by reducing the next eligible easy/short/medium session 20%; it does not yet port the full legacy three-week carry-forward and weekly trimming algorithm.
- Live ride is intentionally not implemented, per request.

Version: 0.5.25 (versionCode 39).
