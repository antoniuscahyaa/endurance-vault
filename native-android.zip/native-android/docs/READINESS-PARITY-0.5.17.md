# Training Readiness parity — 0.5.17 (akurasi data tidur & logika readiness)

Acuan: `15-training-load-te-kebugaran.js` (readinessCalc, sleepScore, recoveryCalc), `19b-tidur-nyeri-keseimbangan.js`
(sleepDebt, awakeMin) dan `29-huawei-watch-sync.js` (hwSleepNights, hwTrimFrags, hwHrvPlan, hwApplyDaily) dari zip rencana-lari-apk.

## Penyebab data tidak akurat dan perbaikannya

| # | Masalah di native 0.5.16 | Perbaikan |
|---|---|---|
| 1 | Tidak ada `hwTrimFrags`: serpihan tidur di sore hari (mis. 20:37) ikut tersambung ke malam sehingga jam tidur terlalu awal, durasi menggelembung, dan "terbangun" palsu | Aturan menit inti (±30 menit berisi ≥42 menit tidur) dipindahkan utuh; potongan tepi ≥30 menit menjadi sesi sendiri |
| 2 | Jam latihan tidak dikeluarkan dari data tidur (fase "ringan" sepanjang lari menggeser jam bangun dan HR tidur) | Jendela workout ±2 menit dipotong dari segmen tidur, seperti `hwBusyOf`; jendela dikirim ProtocolBridge di payload `busy` |
| 3 | `ProtocolBridge` membuat zona dengan `ZoneOffset.ofTotalSeconds(off * 60)` padahal `off` sudah detik, sehingga selalu gagal dan jatuh ke UTC. Batas malam/siang (09:00–19:59) dan tanggal bangun bergeser 7 jam di WIB | `ofTotalSeconds(off)` |
| 4 | `wkN` = jumlah entri `wakeDurations` (selalu 0 atau 1) dan terbangun dihitung dari menit tanpa data | Rentang terbangun per malam (≥3 menit), jeda tanpa data ≥10 menit ditandai `g` dan tidak dihitung terbangun, terbangun di ekor malam tidak dihitung |
| 5 | Jam bangun disimpan di `wkAt` (arti legacy: mulai terjaga di tengah malam) | Disimpan di `wake`; `wkAt` lama pada baris milik jam dibersihkan |
| 6 | Tidur lagi tidak dihitung; tidur siang hanya dijumlah tanpa penggabungan/batas | `ext` (tidur lagi) ikut total tidur; tidur siang digabung bila jeda ≤15 menit, minimal 20 menit, batas 300 (readiness memakai maks. 180) |
| 7 | Menit slot memakai floor untuk awal; HRV diambil dari baris terakhir di payload, dipotong bukan dibulatkan; RHR dipotong; rentang nilai terlalu longgar | `ceil` seperti legacy; HRV dari pembacaan yang berakhir paling akhir per tanggal; pembulatan `Math.round`; rentang RHR 30–120, HR tidur 25–120, HRV 5–250 |
| 8 | Penanda `huaweiHr_*` dipasang walau nilai manual yang dipakai, sehingga sinkron berikutnya menimpa nilai manual | Penanda hanya dipasang bila nilai jam benar-benar diterapkan |
| 9 | Faktor **Recovery** di readiness memakai recovery yang sudah ditambah poin kondisi pagi (RHR, HRV, tidur), padahal ketiganya sudah menjadi faktor sendiri: dihitung dua kali | Recovery untuk readiness tanpa poin pagi (legacy: `recoveryCalc(T,{pts:0})`); pil Recovery tetap memakai poin pagi |
| 10 | Faktor **Beban latihan** muncul bila `fitness > 8`, padahal fitness sudah dikali skala (2,7) dan legacy memakai `ctl > 8 × skala` | Ambang dikali skala |
| 11 | Jeda `g` bertipe angka (1/0, format legacy) terbaca sebagai terbangun; rentang manual wkAt→reAt tidak divalidasi terhadap jam tidur–bangun; tidak ada fallback "terbangun 1×" | Mengikuti `awakeMin` / `awakeStatus` / `sleepScore` legacy |
| 12 | Utang tidur: skor dihitung dari utang tanpa pembulatan 0,1 jam | Dibulatkan dulu seperti `sleepDebt` |

## Setelah memasang
Jalankan satu kali **Sinkron riwayat penuh** di tab Jam. Baris tidur milik jam akan dihitung ulang dengan aturan baru; isian manual tidak disentuh.
Satuan jam tidur kini dibulatkan 0,1 jam (`round(menit/6)/10`) sama seperti legacy.

## Verifikasi
- Skenario sintetis (serpihan sore, lari tercatat sebagai tidur, jeda tanpa data, tidur lagi, tidur siang) dijalankan pada fungsi JS acuan di Node; angka hasilnya dipakai sebagai nilai uji di `HuaweiWatchImportTest`.
- Kode `HuaweiSleepParity`, `HuaweiWatchImport`, seluruh paket `domain/` (kecuali WeatherModel/Greeting) dan 4 kelas uji (34 tes) dikompilasi dengan Kotlin 2.0.21 dan dijalankan di JVM: semua lulus.
- Belum diverifikasi: kompilasi Android penuh (`ProtocolBridge.kt` hanya diubah, tidak dikompilasi di sini) dan uji di perangkat. Jalankan CI Android sebelum memasang.
