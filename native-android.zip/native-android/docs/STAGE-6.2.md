# Stage 6.2 — Core Training Workflows (0.4.5)

## Implemented
- Added descriptive running-history summary: run count, cumulative distance/time source, longest recorded run, fastest recorded average pace, and 28-day volume/session count.
- Added even-distance-weighted first-half vs second-half pace comparison in activity detail. Incomplete terminal splits are excluded from the comparison.
- Added unit tests for run-only aggregation, rolling 28-day window, split weighting, partial split exclusion, and insufficient split data.
- Version: `versionCode 9`, `versionName 0.4.5`.

## Deliberate boundaries
- These are descriptive statistics, not race PR predictions. The UI labels them accordingly.
- The summary uses activity-level distance and duration. It does not infer an exact 5K/10K PR from a longer activity.
- Split comparison uses complete recorded kilometer splits only; it does not alter activity data or training-load/readiness formulas.
- PlanEngine, TrainingMetrics, EasyPace and existing golden fixtures are unchanged.

## Validation still required
- Run GitHub Actions unit tests and release build.
- Verify summary with a mix of running, cycling, imported and watch-synced activities.
- Verify half-split comparison against a known activity with complete splits.
