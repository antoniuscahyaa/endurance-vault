# Riwayat aktivitas dan tukar sesi terlewat

- Tab Minggu > Riwayat kini menampilkan aktivitas yang tersimpan di database native.
- Ringkasan: jarak, jumlah aktivitas lari, durasi, dan elevation gain.
- Grafik batang harian dan pilihan rentang Minggu ini / 30 hari.
- Pengelompokan Minggu / Jenis / Jarak dengan buka-lipat grup dan buka/lipat semua.
- Kartu aktivitas membuka halaman detail native.
- Sesi terlewat yang belum selesai dalam 7 hari terakhir diberi aksi Tukar sesi terlewat.
- Tujuan pertukaran tetap dibatasi ke hari mendatang yang belum memiliki aktivitas tertaut, dalam minggu yang sama.
- Rumus latihan dan data aktivitas tidak diubah.
- Build dan pengujian perangkat belum dijalankan pada lingkungan ini.
