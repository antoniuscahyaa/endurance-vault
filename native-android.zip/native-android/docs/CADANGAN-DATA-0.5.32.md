# Cadangan data lengkap (0.5.32)

Profil > Cadangan sekarang punya **Cadangkan data** dan **Pulihkan dari cadangan**.

## Isi berkas `.zip`
| Entri | Isi |
|---|---|
| `manifest.json` | versi format, waktu, versi aplikasi, jumlah baris per tabel (ditulis terakhir) |
| `room/*.jsonl` | aktivitas (id asli), catatan harian (tidur, HR istirahat, HRV, kaki, mood), gear, data pendamping (done, mv, pr, fav, sp, sl, cs, swo) |
| `acts/*.json` | detail aktivitas: rute, split, grafik |
| `watch/*.jsonl` | database jam: tidur (segmen + skor), langkah/HR/SpO2, HRV, workout + titik, diet, siklus, dll. |
| `prefs/*.json` | pengaturan rencana, zona HR, kesiapan, penyesuaian pekan, profil, cuaca, notifikasi, AGPS, jam |
| `profile/photo.bin` | foto profil (disalin sebagai berkas, bukan URI perangkat lama) |
| `web/*.json` | salinan impor web terakhir (bagian yang tidak dipetakan ke tabel) |

## Yang sengaja tidak ikut
- API key Groq (`ev_secure`) dan kunci pairing jam (`huawei_wear_*`): berkas zip tidak terenkripsi.
- Tabel `cloud_state` dan `cloud_cursor` di database jam (pembukuan sinkron cloud).
- Setelah pindah ponsel: masukkan ulang API key dan pasangkan jam lagi.

## Pemulihan
1. Berkas diekstrak ke folder sementara dan diperiksa (manifest, versi, jumlah baris per tabel). Berkas terpotong atau rusak ditolak sebelum data apa pun berubah.
2. Dialog menampilkan ringkasan isi dan tanggal cadangan.
3. Setelah konfirmasi: salinan pengaman data saat ini dibuat otomatis (`files/backups/sebelum-pulihkan-*.zip`, 2 terakhir disimpan; gagal = pemulihan batal), lalu tabel Room diganti dalam satu transaksi, database jam dalam satu transaksi, kemudian berkas detail, foto, dan pengaturan.
4. Tombol **Muat ulang tampilan** menyegarkan semua layar.

Hanya entri dengan nama yang cocok pola ketat yang diekstrak, dan hanya SharedPreferences dalam daftar putih yang bisa dipulihkan, sehingga berkas cadangan buatan pihak lain tidak bisa menulis ke luar folder atau menimpa rahasia.

## Perubahan kode
- Baru: `data/NativeBackup.kt`, `data/BackupCodec.kt`, `test/.../BackupCodecTest.kt`
- `Db.kt`: query `all()/allDaily()/allGear()/allKv()` dan `replaceEverything()` (tanpa perubahan skema)
- `ActStore.kt`: `detailFiles()`, `installAllFiles()`, `deleteFilesExcept()`
- `SyncStore.kt`: `close()` untuk koneksi sementara
- `MainViewModel.kt`, `ProfileScreen.kt`, `AppRoot.kt`: status dan tombol
- versionCode 46, versionName 0.5.32

## Belum diverifikasi
Lingkungan ini tidak punya SDK Android, jadi build Gradle dan uji di perangkat belum dijalankan. Logika murni (`BackupCodec`) sudah dikompilasi dan dijalankan dengan stub; jalankan CI untuk memastikan seluruh proyek terkompilasi.

## Halaman Pengaturan terpisah
Tombol pengaturan di header kanan atas kini membuka halaman penuh sendiri (di luar kartu utama, tanpa header profil dan dock) dengan tombol kembali. Isinya: Rencana, Zona HR, Kondisi & gear, Nyeri & cedera, Layanan, Cadangan. Tab Profil hanya menampilkan ringkasan "Hari ini" dan Progress. Tombol kembali sistem juga menutup halaman ini. Dikerjakan lewat `ProfileHost` di `AppRoot.kt` dan parameter `settingsMode` di `ProfileScreen`.
