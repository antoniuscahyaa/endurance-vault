# Today session card — 0.5.20

Option C cleanup:
- Removed the decorative five-segment bar (it had no data meaning).
- Removed the running-person icon tile.
- Removed the “Buka sesi di Minggu” button from planned-session cards.
- Kept the readiness arc, session title/distance, HR limit, extra distance, recorded status,
  expandable session detail, and readiness advice.
- No training metrics, watch imports, or readiness calculations changed.

Version: 0.5.20 (versionCode 34)
