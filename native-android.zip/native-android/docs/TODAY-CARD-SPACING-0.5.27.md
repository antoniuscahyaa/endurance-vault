# Today card spacing refinement — 0.5.27

- Moved HR limit and extra-distance metadata into the left session-content column,
  directly below the planned distance.
- Moved the recorded badge and Detail sesi control into the same compact column.
- The readiness gauge remains aligned at the top-right, independent of the text stack.
- This avoids placing the HR row and Detail sesi below the full gauge height, which
  caused the large vertical blank area visible in the device screenshot.
- Readiness calculations, session data, and advice panel behavior are unchanged.
- Version 0.5.27, versionCode 41.
