# Stage 6.5 completion — weather, watch services, online AI

Version 0.4.9 / versionCode 13.

- Fueling UI, persistence, and calculation removed from the native app.
- Weather: current conditions, seven-day forecast, rain probability, wind, US/EU AQI, PM2.5/PM10, city geocoding, explicit GPS lookup, and manual coordinates.
- Weather-to-watch uses the existing Huawei WeatherController bridge; a physical watch and supported firmware are required.
- A-GPS settings and source test use existing protocol bridge. Optional mirror must be HTTPS; empty means built-in Broadcom source.
- Notification listener service registered in Android manifest. User must grant Notification Access in Android Settings. Quiet hours and screen-off filter are exposed; content is not stored by the listener.
- AI Coach uses Groq chat completions with GPT-OSS 120B. API key is encrypted using Android Keystore. Training context is sent only on explicit user submission. No fueling/nutrition data is sent.

Network services and watch-side support require runtime verification.
