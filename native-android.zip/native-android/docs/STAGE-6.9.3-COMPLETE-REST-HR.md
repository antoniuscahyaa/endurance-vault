# Stage 6.9.3 — Rest distribution and HR-zone completion pass

## Included
- Keeps manual per-day rest distribution and 0.5 km validation.
- Adds optional next-week Easy targets only when the following week exists and is neither race nor taper.
- Applies a combined next-week allocation ceiling of 10% of that week's planned km.
- Shows the next-week allocation budget and validates it before applying.
- HR settings now show a live BPM preview from the same `Zones.cuts` calculation used by the domain layer.
- HRR preview uses up to 14 latest daily resting-HR records, falling back to 55 bpm; LTHR remains manual or the average threshold band.

## Explicit limitations
- The current native `DailyEntity` does not expose the old application's active-pain (`bkAct`) store or its exact readiness thresholds. This pass does not invent a substitute. Pain/readiness blocking therefore still needs the native pain/readiness data model wired to the dialog before claiming exact parity.
- Next-week spread is persisted in the Week adjustment overlay and rendered on target-day cards; it does not mutate the underlying PlanEngine weekly volume or training-load calculations.
- No Gradle wrapper is present in this source package, so compilation and device behavior were not verified here.
