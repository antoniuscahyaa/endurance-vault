# EnduranceVault Native — Roadmap

- Stage 5.7: parity forget & reconnect Huawei Watch.
- Stage 5.8: release QA gate, unit-test gate, dan checksum artefak.
- Stage 6: audit dan penyelesaian feature parity native terhadap aplikasi lama, lalu optimasi performa dan lifecycle.

Catatan: fitur yang memerlukan Bluetooth/firmware harus diuji pada Huawei Watch Fit 4 fisik.

## Stage 6.2 — Core Training Workflows
- Descriptive performance summary and 28-day running volume.
- Split consistency comparison inside activity detail.
- Exact race-distance PR and plan-session editor remain follow-up work after source-data semantics and persistence are mapped; no synthetic PRs are shown.
