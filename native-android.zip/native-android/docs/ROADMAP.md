# EnduranceVault Native — Roadmap

- Stage 5.7: parity forget & reconnect Huawei Watch.
- Stage 5.8: release QA gate, unit-test gate, dan checksum artefak.
- Stage 6: audit dan penyelesaian feature parity native terhadap aplikasi lama, lalu optimasi performa dan lifecycle.

Catatan: fitur yang memerlukan Bluetooth/firmware harus diuji pada Huawei Watch Fit 4 fisik.

## Stage 6.2 — Core Training Workflows
- Descriptive performance summary and 28-day running volume.
- Split consistency comparison inside activity detail.
- Exact race-distance PR and plan-session editor remain follow-up work after source-data semantics and persistence are mapped; no synthetic PRs are shown.

## Stage 6.3 — Route & Map Workflows (0.4.6)
- Improve activity route card with explicit start/finish markers and a legend.
- Add elevation profile summary: highest/lowest elevation, vertical range, and steepest sampled uphill/downhill grade.
- Grade is computed only for adjacent valid profile points at least 20 m apart; missing/short segments are omitted.
- Keep source D+/D− values unchanged; no training-load/readiness/pace formula changes.
- Route geometry remains available offline. A street-map tile background and interactive route editor are not included in this stage because the current native activity detail model does not retain raw latitude/longitude coordinates.
- Add unit tests for elevation summary and grade edge cases.


## Stage 6.4
Huawei background keep-alive controls and protocol status refresh are now surfaced in native UI. See `STAGE-6.4.md`.

## Stage 6.5 — Weather, Fueling & Coach Foundation
- Native Open-Meteo weather lookup using manually entered coordinates.
- Fueling and hydration quantity estimator with locally persisted last plan.
- Local rule-based coach insight; remote generative AI integration remains a separate task requiring provider/API configuration.
