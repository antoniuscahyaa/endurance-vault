# EnduranceVault Native — Roadmap

- Stage 5.7: parity forget & reconnect Huawei Watch.
- Stage 5.8: release QA gate, unit-test gate, dan checksum artefak.
- Stage 6: audit dan penyelesaian feature parity native terhadap aplikasi lama, lalu optimasi performa dan lifecycle.

Catatan: fitur yang memerlukan Bluetooth/firmware harus diuji pada Huawei Watch Fit 4 fisik.
