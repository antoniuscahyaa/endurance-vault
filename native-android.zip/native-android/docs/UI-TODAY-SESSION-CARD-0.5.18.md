# Today — Session Card Option C (0.5.18)

- Reworked only the Today session card layout to match the approved Option C mockup.
- Added a runner icon tile, session title/distance, readiness open-arc score, compact HR and extra-distance metadata, recorded status chip, collapsible session details, advice surface, and primary Week navigation action.
- HR limit and additional distance are extracted from the existing planned-session detail string. No new training values are calculated or fabricated.
- The recorded chip is shown only when an activity with distance exists for the current date.
- Weather card, weekly progress, navigation, readiness calculations, watch imports, and stored data logic are unchanged.
- Android version: 0.5.18 (versionCode 32).
