# Stage 6.8.1 – Week activity linkage

- Week cards now detect a completed run from the native activity database by matching `dateIso` and `type == run`.
- Completed sessions show a check-circle marker and the recorded distance/HR; expanded cards show the logged activity and pace.
- Past uncompleted sessions within the recent 7-day window can expose schedule-swap and sudden-rest actions, subject to the existing session-kind rules.
- Swap destinations remain future days in the same plan week, exclude race/event days and dates that already have a recorded run.
- Existing adjustment persistence remains in `week_adjustments_v1` SharedPreferences.

Limitations: this does not import old web-app adjustment state automatically. It only matches activity records present in the native Room database. Gradle compilation/device testing must still be run in CI.
