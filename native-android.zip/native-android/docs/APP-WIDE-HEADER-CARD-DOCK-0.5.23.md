# App-wide shell layout — 0.5.23

- Every navigation destination now renders inside a rounded main content surface.
- An editable profile header is placed above the content surface and outside it.
- Profile name is editable and persisted in SharedPreferences.
- Profile photo is selected through Android Open Document, persisted via URI permission,
  and loaded as a downsampled bitmap.
- Header recovery status is calculated using the existing TrainingMetrics calculation,
  including imported watch recovery when present; ready time is shown as local time.
- Bottom navigation is restyled as a floating rounded dock outside the content surface.
- Existing page destinations and page-level content are retained.

Version 0.5.23 (versionCode 37).
