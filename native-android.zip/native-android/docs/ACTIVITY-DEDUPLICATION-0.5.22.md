# Activity duplicate scan and merge — 0.5.22

- Restores the legacy web matching rules: same date and sport; if both start times
  exist, their difference must be under 90 seconds (native HH:mm precision is <= 1 minute).
  If a start time is absent, distance delta must be < 0.1 km and duration delta < 120 sec.
- Only groups where at least one row has imported watch/track detail are candidates,
  mirroring the legacy `acts` requirement.
- The duplicate dialog is no longer incorrectly nested inside backup-import confirmation.
- Scan results are displayed before merge; no rows are deleted during scanning.
- Merge prioritizes the row containing watch/track detail and carries across manual notes,
  feel, gear, name, HR, elevation, source key, and start time where missing.
- Version 0.5.22, versionCode 36.
