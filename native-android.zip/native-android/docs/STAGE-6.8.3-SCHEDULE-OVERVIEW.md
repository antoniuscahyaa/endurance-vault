# Stage 6.8.3 — Separate Schedule Overview

- Week dock remains the operational This week / History view (`ScheduleScreen`).
- Conditional Jadwal dock now opens `PlanOverviewScreen`, a plan-wide overview with plan totals, current-week summary, and all planned weeks.
- The duplicated destination (`ScheduleScreen` on both routes) is removed.
- No training calculations or activity persistence rules are changed.

## Not included
The post-workout Huawei import confirmation dialog is not implemented in this stage. Current `syncWatch()` imports workout rows immediately inside `importWatchData()`; adding a true confirmation requires staging newly discovered workout payloads before writing them to Room and only committing after the user's confirmation. This must not be represented as a dialog after data has already been imported.
