# Stage 6.9.4 – Watch HR Zone Editor

- Adds an expandable HR-zone editor directly inside the Watch screen.
- Supports LTHR and HRR/Karvonen selection, manual LTHR/RHR inputs, editable percentage thresholds, and BPM preview.
- Uses the shared `Zones.cuts()` calculation for preview; export continues to use the saved `PlanSettings` through the existing `syncWatchHrZones` path.
- Saving calls `MainViewModel.saveSettings()`; after saving, use “Kirim zona HR ke jam”.
- Profile screen's existing editor remains available.

Version: 0.5.9 (versionCode 23).

Build status: source-level change only; Gradle compilation and physical Huawei Watch transmission have not been verified in this environment.
