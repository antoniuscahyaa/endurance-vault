# EnduranceVault Native 0.5.60: Stiker data, pemilih sesi, jalan masuk Profil, huruf kustom

Version code 74.

## Baru
- **Pemilih sesi** di layar Stiker data: dropdown aktivitas ber-jarak (terbaru di atas, maksimal 200). Layar tidak perlu ditutup untuk berganti sesi; foto dan susunan stiker di Pratinjau tetap dipertahankan.
- **Jalan masuk dari Profil**: Profil → Pengaturan → Tampilan → **Stiker data → Buka Stiker data**. Dibuka tanpa sesi, otomatis memilih aktivitas terbaru. Jalan masuk dari menu detail aktivitas tetap ada dan langsung memilih sesi itu.
- **Huruf kustom**: dua pilihan terpisah, *angka dan judul* dan *teks isi*. Tiap pilihan: Bawaan (huruf sistem), huruf yang sudah diimpor, atau **+ Impor huruf** (berkas .ttf atau .otf, maksimal 15 MB). Berkas disalin ke `files/sticker_fonts/` (privat untuk aplikasi) dan bisa dihapus lewat tombol *Hapus huruf*. Berlaku untuk semua stiker dan Pratinjau; pilihannya tersimpan di pengaturan stiker.

## Catatan huruf
- Karakter yang tidak ada di huruf pilihan (mis. `×`, `→`, `−`, `★`) otomatis memakai huruf sistem.
- Angka dan judul ditebalkan (fake bold) bila huruf yang dipilih hanya punya satu berat; pilih berkas versi Bold bila ingin tebal yang asli.
- Berkas ditolak bila ekstensinya bukan .ttf/.otf atau tidak bisa dimuat sebagai huruf. Perhatikan lisensi huruf yang Anda impor; stiker hasilnya berupa gambar, bukan berkas huruf.

## Teknis
- Baru: `ui/sticker/StickerFonts.kt` (`StickerFonts`, `StickerFontStore`).
- Diubah: `StickerRenderer` (palet membawa `fonts`, jadi seluruh penggambar dan pengukur teks memakai huruf yang sama), `Stickers.kt` (pengaturan `fontNum`, `fontBody`, `fontName` membersihkan nama berkas), `StickerScreen` (`SessionPicker`, `FontChoice`), `AppRoot` (rute `sticker` tanpa id; `ProfileHost` menerima `onOpenStickers`), `ProfileScreen` (kartu Stiker data di Tampilan).
- Tes: `namaHurufKustomDibersihkan`.

## Catatan
- Belum dikompilasi di lingkungan pembuatnya; periksa hasil CI. Impor huruf dan dropdown sesi belum dicoba di perangkat.
