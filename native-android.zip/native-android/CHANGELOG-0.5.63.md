# EnduranceVault Native 0.5.63: Progres jadi dock mandiri

Version code 77.

## Berubah
- **Dock baru "Progres"** (ikon grafik) di antara Profil dan Jam. Isinya ProgressScreen utuh: Rekap, Fitness, Load, Routes & conditions, Body.
- Di tab **Profil**, sub-tab "Progress" diganti **"Timeline"**. Halamannya sengaja kosong (placeholder) untuk diisi kemudian.
- Kartu "On track" dan chip tab di Profil > Hari ini kini membuka dock Progres langsung di sub-tab yang dituju.

## Teknis
- `AppRoot.kt`: `Tab.Progress` ditambahkan ke enum dan daftar dock; rute `progress` tetap; `progressInitialTab` dipegang di AppRoot dan dikirim ke `ProgressScreen(initialTab)`. Penanda terpilih khusus Profil untuk rute progress dihapus.
- `ProfileScreen.kt`: parameter baru `onOpenProgressDock`; state `progressInitialTab` dihapus.
- Belum dikompilasi di lingkungan pembuatnya; periksa hasil CI.
