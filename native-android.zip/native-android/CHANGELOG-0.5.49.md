# EnduranceVault Native 0.5.49: preview rute GPX dan strategi pacing medan

Versi 0.5.49, version code 63.

## Perubahan
- Ikon peta di kartu jam (dock Jam) dan tombol kirim GPX di pengaturan jam tidak lagi langsung mengirim. Keduanya membuka **Preview rute GPX**: sketsa jalur (mulai hijau, finis merah), jarak, naik/turun (ambang 3 m), rentang elevasi, dan jumlah titik yang akan dikirim. Tombol **Kirim ke jam** baru memulai pengiriman.
- Nama rute di jam kini diambil dari `<name>` di GPX (atau nama berkas), bukan lagi "EnduranceVault Route". Dipotong 60 byte UTF-8. GPX berisi `rtept` (tanpa `trkpt`) juga terbaca.
- **Strategi pacing (opsional)** di dialog yang sama, diport dari versi web:
  - Isi target waktu (ketik angka saja: 30000 = 3:00:00), pilih strategi (usaha rata / negative split / start hati-hati) dan permukaan turunan (padat / trail biasa / licin).
  - Profil elevasi dipecah menjadi ruas tanjakan, turunan, dan datar. Tiap ruas diberi pace dengan usaha setara (GAP Minetti), dinormalkan ke target waktu, jadi total waktu selalu sama dengan target.
  - Turunan dinilai lari-able atau tidak dari kemiringan dan permukaan; beban turunan kumulatif memperlambat turunan curam di paruh akhir; ada penanda hike, recovery, dan "hemat lutut".
  - Keluaran: grafik profil elevasi berwarna per ruas dengan batang pace, ringkasan strategi, dan kartu per ruas (pace, total waktu, tips).
  - Hanya panduan: rute yang dikirim ke jam tetap hanya jalur dan elevasi.
- Tata letak mengikuti komponen native (`EvPanel`, `EvMetricRow`, `DCaption`, warna Ember) dan dibuat ringkas: tiga ubin (jarak, naik, turun), strategi pacing tertutup secara bawaan, hanya tiga catatan teratas yang tampil (sisanya dilipat), dan tiap ruas satu baris (pace besar di kanan) yang diketuk untuk membuka arahannya.

## Kode
- `domain/CourseStrategy.kt` (baru): `courseProfile`, `terrainSegs`, `dnSplit`, `gradeCost`, `terrainStrategy`, `summary`, `tip`, `pacing`.
- `domain/GpxRoute.kt` (baru): `parsePoints`, `payload`, `stats`, `preview`, `timeFmt`. DOCTYPE ditolak (aman dari XXE).
- `ui/screens/GpxPreviewDialog.kt` (baru). `MainViewModel`: `gpxPreview`, `pushGpxRoute` (kini hanya memuat pratinjau), `confirmGpxRoute`, `dismissGpxPreview`. `AppRoot`: dialog global.
- Tes baru: `CourseStrategyTest.kt`, `GpxRouteTest.kt`.

## Belum diport dari web
- Zona HR per ruas dan kartu intensitas (Ringan/Sedang/Tinggi) serta tombol "Pakai performa saat ini" (`perfIty`, `ityZoneFor`). Butuh data zona dan model performa dari riwayat lari.
- Faktor lelah/panas: di web, preview GPX juga tidak memakainya, jadi hasilnya sama.
- Peta OSM di preview: memakai sketsa jalur offline. `RouteMapView` saat ini terikat ke `ActDetail`.
- Teks bahasa Inggris (aplikasi native hanya Indonesia).

## Validasi
- Gradle dan Kotlin tidak tersedia di lingkungan ini, jadi kode belum dikompilasi dan tes belum dijalankan. Jalankan CI, lalu coba di perangkat: pilih GPX dari ikon peta, isi target waktu, ganti strategi dan permukaan, lalu kirim.
