# Penandatanganan APK EnduranceVault

Build 5.6.1 memakai persistent release keystore. Jangan pernah commit file `.jks`, password, atau file Base64 ke repository.

Tambahkan empat GitHub Actions Secrets di Settings → Secrets and variables → Actions:

- `ANDROID_KEYSTORE_BASE64`: seluruh isi file `ANDROID_KEYSTORE_BASE64.txt` (satu baris).
- `ANDROID_KEYSTORE_PASSWORD`: isi `ANDROID_KEYSTORE_PASSWORD.txt`.
- `ANDROID_KEY_ALIAS`: isi `ANDROID_KEY_ALIAS.txt`.
- `ANDROID_KEY_PASSWORD`: isi `ANDROID_KEY_PASSWORD.txt`.

Setelah semua secrets tersimpan, jalankan workflow Build APK. Workflow menghasilkan `EnduranceVault-release-apk`. Simpan keystore dan password secara offline di tempat aman dan buat backup terenkripsi. Kehilangan keystore berarti tidak bisa menandatangani update yang kompatibel dengan instalasi dari key ini. Jangan bagikan keystore atau password.

Application ID tetap `com.endurancevault.app`; versionCode dinaikkan menjadi 5 dan versionName menjadi 0.4.1. Semua rilis berikutnya harus memakai keystore yang sama dan versionCode lebih besar.
