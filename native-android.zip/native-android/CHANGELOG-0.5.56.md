# EnduranceVault Native 0.5.56: tabel Per km dan Per segmen jadi satu

Versi 0.5.56, version code 70.

## Perubahan
- Di halaman **Per km**, tabel **Per km** dan **Per segmen** tidak lagi bertumpuk ke bawah. Keduanya kini satu blok yang **digeser ke samping** (pager), dengan dua chip **Per km** / **Per segmen** untuk berpindah dengan ketukan.
- Pilihan tabel terakhir diingat selama layar detail terbuka, jadi setelah menyimpan segmen dari editor kamu kembali ke tab yang sama.
- Kartu Perbandingan paruh dan HR drift tetap di atas pager.
- Tombol "Bagi segmen" / "Ubah pembagian segmen" dan keterangan segmen kini ada di dalam halaman Per segmen.
- Bila aktivitas hanya punya salah satunya (tanpa data per km, atau tanpa segmen dan tanpa editor), tampil satu tabel tanpa pager seperti sebelumnya.

## Teknis
- `ActivityDetailScreen.kt`: `KmPage` memakai `HorizontalPager` (foundation) dengan dua lambda `kmTable` dan `segTable`; state tab di-hoist (`kmTab`, rememberSaveable) di layar detail.

## Catatan
- Tinggi blok mengikuti halaman yang sedang terlihat, jadi layar bisa sedikit berubah tinggi saat berpindah tabel.
- Belum dikompilasi dan tes belum dijalankan di lingkungan ini. Jalankan CI.
