# aturan R8 tambahan ditaruh di sini
