package com.rencanalari.huaweiwatch;

import org.json.JSONObject;

/**
 * Pintu antara plugin Capacitor (selalu dikompilasi) dan inti protokol JoyoFit (hanya dikompilasi bila
 * protokol diaktifkan, lihat build.gradle). {@code ProtocolBridge} (Kotlin) mengimplementasikannya.
 * Tanpa protokol, {@link HuaweiWatchPlugin} tidak menemukan kelas itu dan menolak panggilan dengan pesan jelas.
 */
public interface ProtocolGateway {
    interface Callback {
        void ok(JSONObject result);

        void error(String code, String message);
    }

    /** Keadaan tautan, baterai, info jam, ringkasan sinkron terakhir. */
    JSONObject status();

    /** Baca baterai jam sekarang dari jam (bukan cache). Hasil: {battery, batteryAt}. Error ERR_NOT_CONNECTED bila tautan mati. */
    void refreshBattery(Callback callback);

    /** Baris log setelah nomor urut {@code since} (0 = semua yang masih disimpan); alamat Bluetooth disamarkan. */
    JSONObject log(int since);

    void connect(String address, Callback callback);

    void disconnect();

    void sync(boolean fullHistory, Callback callback);

    /** Simpan ID akun Huawei (17-19 angka; kosong = hapus). Dikirim ke jam saat koneksi berikutnya. Melempar IllegalArgumentException bila format salah. */
    void setHuaweiAccount(String account);

    /** Apakah ID akun tersimpan dan petunjuk 4 digit terakhirnya; ID lengkap tidak dikembalikan ke JS. */
    JSONObject huaweiAccountInfo();

    /**
     * Simpan zona HR pilihan app (JSON {method:"hrr"|"mhr", lower:[z1..z5], maxHr, restHr}; kosong = kembali ke bawaan) dan, bila jam
     * terhubung, kirim sekarang. Hasil: saved, connected, sent, branch ("extended"/"simple"/"track"/"none"), custom.
     * Error BAD_ZONES bila zona tidak valid (tidak disimpan).
     */
    void setHrZones(String json, Callback callback);

    /** Zona tersimpan (ada/tidak, metode, batas) dan jalur yang dipakai jam terhubung ("branch", null bila tidak terhubung). */
    JSONObject hrZonesInfo();

    /**
     * Kirim sesi latihan terstruktur sebagai kursus lari ke jam (P2P, EKSPERIMENTAL). JSON {courses:[{id, name, blocks:[{repeat, steps:[
     * {kind, target, value, intensity, low, high}]}]}]}. Hasil: results (per kursus: ok, status unggah, jawaban jam), sent, failed.
     * Error ERR_INVALID_ARGUMENT bila bentuknya salah; kegagalan per kursus ada di results.
     */
    void pushCourses(String json, Callback callback);

    /**
     * Kirim satu rute GPX ke jam sebagai rute yang bisa diikuti (P2P, mengikuti alur Gadgetbridge, BELUM DIUJI di jam). JSON
     * {name, points:[[lat, lon, ele|null], ...]}. Hasil: ok, name, points, bytes, maxPoints, routeV2, gate, uploadStatus, answered.
     * Error ERR_INVALID_ARGUMENT bila bentuknya salah, ERR_NOT_CONNECTED, ERR_UNSUPPORTED, ERR_TIMEOUT, ERR_PROTOCOL (jam menolak).
     */
    void pushRoute(String json, Callback callback);

    /**
     * HR live dari jam untuk layar Live sepeda: active true meminta jam mengirim HR realtime, false mematikannya dan
     * mengembalikan HR otomatis jam. Tidak menulis apa pun ke basis data.
     */
    void setLiveHeartRate(boolean active);

    /** Bacaan HR live terakhir: {active, running, supported, bpm, ageMs}; bpm 0 dan ageMs -1 bila belum ada bacaan. */
    JSONObject liveHeartRate();

    /**
     * Cuaca ke jam (modul cuaca JoyoFit: Open-Meteo, dikirim lewat layanan cuaca jam). JSON (semua kolom opsional)
     * {enabled:bool, lat, lon, name, unit:"celsius"|"fahrenheit", intervalMinutes:15..1440}. Lokasi memakai titik pilihan app (mode kota),
     * jadi tidak perlu izin lokasi. Hasil: status cuaca (lihat {@link #weatherStatus()}). Error ERR_INVALID_ARGUMENT bila nilai salah.
     */
    void setWeather(String json, Callback callback);

    /** Status cuaca ke jam: enabled, unit, intervalMinutes, city, watchSupported (null bila tidak terhubung), lastPushAt, lastError, lastTemperatureC, lastCondition, lastLocationName. */
    JSONObject weatherStatus();

    /**
     * Atur A-GPS (update satelit) ke jam: JSON {enabled, mirrorUrl}. mirrorUrl kosong = langsung ke Broadcom; selain itu harus https
     * (server sendiri, mis. Cloudflare Worker); Broadcom tetap cadangan. Hasil: {@link #agpsStatus()}. Error ERR_INVALID_ARGUMENT bila alamat salah.
     */
    void setAgps(String json, Callback callback);

    /** Status A-GPS: enabled, mirrorUrl, lastOkAt/lastBytes/lastFrom (unduhan terakhir), lastError, lastDoneAt/lastDoneResult (jam selesai menarik file). */
    JSONObject agpsStatus();

    /** Uji unduh file orbit sekarang (tanpa jam, tanpa cache). Hasil: ok, results[{source: mirror|broadcom, ok, bytes|error, ms}]. */
    void testAgps(Callback callback);

    /** Ambil cuaca baru lalu kirim ke jam sekarang. Hasil seperti {@link #weatherStatus()}. Error ERR_NOT_CONNECTED, ERR_UNSUPPORTED, ERR_WEATHER_NETWORK, ERR_WEATHER_LOCATION, ERR_WEATHER_DISABLED. */
    void refreshWeather(Callback callback);

    /** Lupakan kunci autentikasi jam ini (pasangan ulang dari awal berikutnya). */
    void forget(String address);

    /** Langkah, kalori, HR per hari dan segmen tidur sejak {@code sinceSec}; hari dihitung dengan {@code tzOffsetMin}. */
    JSONObject readDaily(long sinceSec, int tzOffsetMin) throws Exception;

    /** HR rata-rata dan terendah pada rentang waktu (detik unix), dari sampel per menit. */
    JSONObject readHrWindow(long startSec, long endSec) throws Exception;

    /** Ringkasan live: total langkah/kalori/jarak/HR/SpO2 pada rentang, sampel terbaru, dan deret per {@code bucketSec} detik. */
    JSONObject readLive(long startSec, long endSec, int bucketSec) throws Exception;

    /** Daftar workout tanpa titik lintasan. */
    JSONObject readWorkouts(long sinceSec, int limit) throws Exception;

    /** Titik lintasan satu workout (diminta saat diimpor saja, karena bisa ribuan baris). */
    JSONObject readWorkoutPoints(long startSec) throws Exception;

    /** Tandai workout luar ruang tanpa GPS sejak {@code sinceSec} sebagai belum lengkap agar GPS-nya diunduh ulang saat sinkron. Hasil: {marked:n}. */
    JSONObject markWorkoutsForGpsRedownload(long sinceSec) throws Exception;

    /**
     * Notifikasi ponsel ke jam (EKSPERIMENTAL). Status: enabled, connected, supported (null bila tidak terhubung), quietEnabled, quietStart,
     * quietEnd (menit sejak 00:00), onlyScreenOff, lastResult, lastPackage, lastAt (detik), sentCount, lastError, apps[{pkg, label, on, explicit}].
     * Hak akses notifikasi Android (accessGranted) ditambahkan oleh plugin karena hanya konteks Android yang bisa membacanya.
     */
    JSONObject notifyStatus();

    /** Atur teruskan notifikasi: JSON {enabled, quietEnabled, quietStart, quietEnd, onlyScreenOff, apps:{paket:true|false}}; semua kolom opsional. Hasil seperti notifyStatus. */
    void setNotify(String json, Callback callback);

    /** Kirim satu notifikasi uji ke jam. Hasil: result (sent, not-connected, unsupported, busy, failed) dan status. */
    void testNotify(Callback callback);

    /** Dipanggil NotificationListenerService tiap notifikasi baru yang lolos saringan awal; tidak menunggu hasil. */
    void forwardNotification(String packageName, String appLabel, String key, int id, String channelId, String title, String text, long postedAtMs, boolean screenOn);
}
