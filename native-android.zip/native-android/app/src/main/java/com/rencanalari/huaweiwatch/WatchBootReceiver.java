package com.rencanalari.huaweiwatch;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Setelah HP menyala ulang atau aplikasi diperbarui: nyalakan lagi penjagaan koneksi jam bila sebelumnya aktif. */
public class WatchBootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        if (!Intent.ACTION_BOOT_COMPLETED.equals(action)
                && !Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)
                && !"android.intent.action.LOCKED_BOOT_COMPLETED".equals(action)) {
            return;
        }
        if (KeepAliveConfig.wanted(context)) {
            KeepAliveConfig.start(context);
        }
    }
}
