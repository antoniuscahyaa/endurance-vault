package com.rencanalari.huaweiwatch;

import android.app.Notification;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.PowerManager;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

/** Forwards eligible phone notifications to the paired Huawei watch. Message text is never persisted. */
public class WatchNotificationListener extends NotificationListenerService {
    private static volatile ProtocolGateway cached;
    private static volatile boolean checked;
    static ProtocolGateway gatewayFor(android.content.Context context) {
        if (!checked) synchronized (WatchNotificationListener.class) {
            if (!checked) {
                try {
                    Class<?> cls = Class.forName("com.rencanalari.huaweiwatch.ProtocolBridge");
                    Object bridge = cls.getMethod("get", android.content.Context.class).invoke(null, context.getApplicationContext());
                    cached = (ProtocolGateway) bridge;
                } catch (Throwable ignored) { cached = null; }
                checked = true;
            }
        }
        return cached;
    }
    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            if (sbn == null || sbn.getPackageName() == null || sbn.getPackageName().equals(getPackageName())) return;
            Notification n = sbn.getNotification(); if (n == null) return;
            int f=n.flags;
            if ((f & Notification.FLAG_ONGOING_EVENT)!=0 || (f & Notification.FLAG_GROUP_SUMMARY)!=0 || (f & Notification.FLAG_FOREGROUND_SERVICE)!=0) return;
            String cat=n.category;
            if (cat!=null && (Notification.CATEGORY_PROGRESS.equals(cat)||Notification.CATEGORY_TRANSPORT.equals(cat)||Notification.CATEGORY_SERVICE.equals(cat)||Notification.CATEGORY_SYSTEM.equals(cat)||Notification.CATEGORY_STATUS.equals(cat))) return;
            ProtocolGateway gw=gatewayFor(this); if(gw==null)return;
            Bundle ex=n.extras; if(ex==null)return;
            String title=str(ex.getCharSequence(Notification.EXTRA_TITLE));
            String body=str(ex.getCharSequence(Notification.EXTRA_TEXT));
            String big=str(ex.getCharSequence(Notification.EXTRA_BIG_TEXT)); if(big.length()>body.length())body=big;
            if(title.isEmpty()&&body.isEmpty())return;
            PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE); boolean screenOn=pm!=null&&pm.isInteractive();
            String channel=android.os.Build.VERSION.SDK_INT>=26&&n.getChannelId()!=null?n.getChannelId():"";
            String pkg=sbn.getPackageName();
            gw.forwardNotification(pkg,label(pkg),sbn.getKey()==null?pkg+":"+sbn.getId():sbn.getKey(),sbn.getId(),channel,title,body,sbn.getPostTime(),screenOn);
        } catch(Throwable ignored) { }
    }
    private static String str(CharSequence s){return s==null?"":s.toString();}
    private String label(String pkg){try{return String.valueOf(getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(pkg,0)));}catch(Exception e){return pkg;}}
}
