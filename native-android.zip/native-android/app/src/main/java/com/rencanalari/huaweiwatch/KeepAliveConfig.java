package com.rencanalari.huaweiwatch;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

/**
 * Pengaturan penjagaan koneksi jam di latar belakang. Berkas Java biasa (selalu dikompilasi) supaya plugin, penerima boot,
 * dan layanan Kotlin membaca sumber yang sama tanpa JS berjalan. Layanan sendiri ada di src/protocol (butuh inti protokol).
 */
public final class KeepAliveConfig {
    public static final String SERVICE_CLASS = "com.rencanalari.huaweiwatch.WatchKeepAliveService";
    public static final int DEFAULT_INTERVAL_MIN = 5;
    public static final int MIN_INTERVAL_MIN = 2;
    public static final int MAX_INTERVAL_MIN = 60;

    private static final String PREFS = "watch_keepalive";

    private KeepAliveConfig() {}

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** True sejak jam pertama kali berhasil dihubungkan, sampai pengguna menekan Putuskan. */
    public static boolean wanted(Context c) {
        return prefs(c).getBoolean("wanted", false);
    }

    public static void setWanted(Context c, boolean on) {
        prefs(c).edit().putBoolean("wanted", on).apply();
    }

    public static int intervalMin(Context c) {
        int v = prefs(c).getInt("interval_min", DEFAULT_INTERVAL_MIN);
        return Math.max(MIN_INTERVAL_MIN, Math.min(MAX_INTERVAL_MIN, v));
    }

    public static void setIntervalMin(Context c, int minutes) {
        int v = Math.max(MIN_INTERVAL_MIN, Math.min(MAX_INTERVAL_MIN, minutes));
        prefs(c).edit().putInt("interval_min", v).apply();
    }

    /** Persen baterai jam yang memicu pengingat isi daya; 0 = mati. Bawaan 20. */
    public static final int DEFAULT_LOW_BATTERY_PCT = 20;

    public static int lowBatteryPct(Context c) {
        return Math.max(0, Math.min(50, prefs(c).getInt("low_battery_pct", DEFAULT_LOW_BATTERY_PCT)));
    }

    public static void setLowBatteryPct(Context c, int pct) {
        prefs(c).edit().putInt("low_battery_pct", Math.max(0, Math.min(50, pct))).apply();
    }

    /** "id" atau "en": bahasa teks notifikasi (dikirim JS karena bahasa aplikasi bisa berbeda dari bahasa HP). */
    public static String lang(Context c) {
        return prefs(c).getString("lang", "id");
    }

    public static void setLang(Context c, String lang) {
        prefs(c).edit().putString("lang", "en".equals(lang) ? "en" : "id").apply();
    }

    private static Intent serviceIntent(Context c) {
        return new Intent().setClassName(c.getPackageName(), SERVICE_CLASS);
    }

    /** Menyalakan layanan latar. Mengembalikan null bila berhasil, atau pesan galat (mis. dilarang sistem saat aplikasi di belakang). */
    public static String start(Context c) {
        try {
            Context app = c.getApplicationContext();
            Intent i = serviceIntent(app);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) app.startForegroundService(i);
            else app.startService(i);
            return null;
        } catch (Exception e) {
            return e.getClass().getSimpleName() + (e.getMessage() == null ? "" : ": " + e.getMessage());
        }
    }

    public static void stop(Context c) {
        try {
            c.getApplicationContext().stopService(serviceIntent(c));
        } catch (Exception ignored) {
        }
    }
}
