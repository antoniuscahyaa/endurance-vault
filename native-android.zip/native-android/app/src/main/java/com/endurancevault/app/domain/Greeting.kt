package com.endurancevault.app.domain

import java.util.Locale
import kotlin.random.Random

/**
 * Port dari 24j-sapaan-motivasi.js (greetPeriod, greetWord, greetKey, greetPick, greetScene).
 * Hanya bahasa Indonesia; aplikasi native ini belum punya pengalih bahasa.
 *
 * todayState: "todo" | "done" | "rest" | "none".
 */
data class GreetInput(
    val todayState: String = "none",
    val readiness: Int? = null,
    val acwr: Double? = null,
    val mood: Int? = null,
    val sleepDebt: Double? = null,
    val raceDays: Int? = null,
    val streak: Int = 0,
    val gap: Int? = null,
    val care: Boolean = false,
    val wxFeels: Double? = null,
    val wxCode: Int? = null,
)

enum class GreetAtmosphere { CALM, RECOVERY, CLEAR, PEAK, STREAK, REST, RACE }
enum class GreetTime { MORNING, DAY, EVENING, NIGHT }

object GreetingEngine {
    /** Satu seed per peluncuran proses: kutipan tidak loncat saat layar dirender ulang. */
    val sessionSeed: Int = Random.nextInt(0, Int.MAX_VALUE)

    fun period(hour: Int): String = when {
        hour in 4..10 -> "pagi"
        hour in 11..14 -> "siang"
        hour in 15..17 -> "sore"
        else -> "malam"
    }

    fun word(period: String): String = when (period) {
        "pagi" -> "SELAMAT PAGI"
        "siang" -> "SELAMAT SIANG"
        "sore" -> "SELAMAT SORE"
        else -> "SELAMAT MALAM"
    }

    /** Waktu hari untuk palet latar (greetScene: 5-10 pagi, 11-15 siang, 16-18 sore, sisanya malam). */
    fun timeOfDay(hour: Int): GreetTime = when {
        hour in 5..10 -> GreetTime.MORNING
        hour in 11..15 -> GreetTime.DAY
        hour in 16..18 -> GreetTime.EVENING
        else -> GreetTime.NIGHT
    }

    fun key(o: GreetInput): String {
        val st = o.todayState
        val d = o.raceDays ?: 0
        if (o.care || (o.readiness != null && o.readiness < 40)) return "care"
        if ((o.acwr ?: 0.0) >= 1.5) return "load"
        if ((o.mood ?: 0) >= 4) return "mood"
        if ((o.sleepDebt ?: 0.0) >= 4.0) return "sleep"
        if (st == "todo" && o.wxCode != null) {
            if (o.wxCode >= 95) return "storm"
            if ((o.wxFeels ?: -99.0) >= 32.0) return "heat"
        }
        if (d in 1..3) return "race3"
        if (d in 4..14 && st == "todo") return "race14"
        if (st == "todo" && (o.gap ?: 0) >= 3) return "lazy"
        if (o.streak >= 7 && st == "done") return "streak"
        return if (st == "todo" || st == "done" || st == "rest") st else "none"
    }

    private fun fmt(x: Double, dp: Int): String = String.format(Locale("id", "ID"), "%.${dp}f", x)

    fun pick(o: GreetInput, seed: Int, period: String): String {
        val k = key(o)
        val pools = GreetingPools.id
        var pool = pools[k] ?: pools.getValue("none")
        if (k == "todo" || k == "lazy") pools[period]?.let { pool = pool + it }
        val n = when (k) {
            "lazy" -> (o.gap ?: 0).toString()
            "streak" -> o.streak.toString()
            "load" -> fmt(o.acwr ?: 0.0, 2)
            "sleep" -> fmt(o.sleepDebt ?: 0.0, 1)
            "heat" -> Math.round(o.wxFeels ?: 0.0).toString()
            else -> (o.raceDays ?: 0).toString()
        }
        return pool[Math.floorMod(seed, pool.size)].replace("{n}", n)
    }

    /** Atmosfer malam (night-* di CSS web). Kunci pulih memakai aturan yang sama dengan kutipan. */
    fun atmosphere(o: GreetInput): GreetAtmosphere {
        val score = o.readiness
        return when {
            key(o) in setOf("care", "load", "mood", "sleep") -> GreetAtmosphere.RECOVERY
            o.todayState == "done" && score != null && score >= 75 -> GreetAtmosphere.PEAK
            score != null && score >= 80 -> GreetAtmosphere.CLEAR
            o.streak >= 7 -> GreetAtmosphere.STREAK
            o.todayState == "rest" -> GreetAtmosphere.REST
            o.raceDays != null && o.raceDays <= 14 && o.raceDays > 0 -> GreetAtmosphere.RACE
            else -> GreetAtmosphere.CALM
        }
    }
}
