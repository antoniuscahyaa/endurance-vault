package com.endurancevault.app.domain

import java.time.Instant
import java.time.ZoneId
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

class ActImportException(message: String) : Exception(message)

/** Satu titik lintasan. Nilai yang tidak ada bernilai NaN. t = epoch milidetik. */
class Pt(
    val la: Double = Double.NaN, val lo: Double = Double.NaN, val t: Double = Double.NaN,
    val e: Double = Double.NaN, val h: Double = Double.NaN, val c: Double = Double.NaN,
    val d: Double = Double.NaN, val tp: Double = Double.NaN,
)

/** Lap dari berkas FIT (belum dipakai membangun segmen interval). */
class FitLap(val t: Double, val iv: Int?, val el: Double?, val tm: Double?, val di: Double?, val h: Int?, val c: Int?)

class ParsedTrack(val pts: List<Pt>, val sport: String, val name: String, val laps: List<FitLap> = emptyList())

/**
 * Port buildAct() di web (06-zona-hr-impor-aktivitas-cuaca.js): dari titik lintasan menjadi objek aktivitas
 * (jarak, waktu bergerak, D+/D−, HR, kadens, split per km, rute, profil, deret pace/HR/kadens, histogram HR).
 * Belum ada: segmen dari lap FIT (sg), deret padat (tl), zona per menit (hz/vz/zs), VAM.
 */
object ActBuilder {
    private fun fin(x: Double) = !x.isNaN() && !x.isInfinite()

    fun hav(a: Double, b: Double, c: Double, d: Double): Double {
        val r = 6371000.0; val p = Math.PI / 180
        val x = (c - a) * p; val y = (d - b) * p
        val q = sin(x / 2) * sin(x / 2) + cos(a * p) * cos(c * p) * sin(y / 2) * sin(y / 2)
        return 2 * r * asin(sqrt(q))
    }

    private fun minC(g0: Double): Double {
        var g = g0
        if (g > .45) g = .45
        if (g < -.45) g = -.45
        return 155.4 * g * g * g * g * g - 30.4 * g * g * g * g - 43.3 * g * g * g + 46.3 * g * g + 19.5 * g + 3.6
    }
    private fun gapF(g: Double) = minC(g) / 3.6

    private fun eleGainTh(es: List<Double>): Double {
        val d = ArrayList<Double>()
        for (i in 1 until es.size) {
            val a = es[i - 1]; val b = es[i]
            if (fin(a) && fin(b) && abs(b - a) > 0.001) d.add(abs(b - a))
        }
        if (d.size < 100) return 1.5
        d.sort()
        return if (d[d.size / 2] <= 0.25) 0.55 else 1.5
    }

    private class Row(var d: Double, var t: Double, var h: Double, var e: Double, var g: Double, var l: Double, var c: Double, var T: Double, var q: Double = 0.0)

    private fun r3(x: Double) = Js.round(x * 1000) / 1000
    private fun r2(x: Double) = Js.round(x * 100) / 100

    fun build(
        ptsIn: List<Pt>, sportIn: String, nameIn: String, zone: ZoneId = ZoneId.systemDefault(),
    ): Map<String, Any?> {
        var nm = nameIn
        val pts = ptsIn.filter { fin(it.t) && ((fin(it.la) && fin(it.lo)) || fin(it.d)) }
        if (pts.size < 2) throw ActImportException("tidak ada titik lintasan dengan waktu")
        val xk: String? = if (Regex("hik", RegexOption.IGNORE_CASE).containsMatchIn(sportIn)) "hike"
        else if (Regex("swim", RegexOption.IGNORE_CASE).containsMatchIn(sportIn)) "swim" else null
        val bike = Regex("bik|cycl", RegexOption.IGNORE_CASE).containsMatchIn(sportIn) || xk != null
        if (xk != null && nm.isEmpty()) nm = if (xk == "hike") "Hiking" else "Renang"
        val cvals = pts.filter { fin(it.c) && it.c > 0 && it.c < 250 }.map { it.c }.sorted()
        val cmed = if (cvals.isNotEmpty()) cvals[cvals.size / 2] else 0.0
        val csc = if (!bike && cmed > 0 && cmed < 120) 2 else 1
        var cSum = 0.0; var cT = 0.0
        var cum = 0.0; var mov = 0.0; var gain = 0.0; var loss = 0.0
        var hrSum = 0.0; var hrT = 0.0; var hrMax = 0.0
        val hist = LinkedHashMap<Int, Double>()
        val rows = ArrayList<Row>()
        rows.add(Row(0.0, 0.0, pts[0].h, pts[0].e, 0.0, 0.0, pts[0].c, pts[0].t))
        var prev = pts[0]
        var ref: Double? = if (fin(prev.e)) prev.e else null
        val gTh = try { eleGainTh(pts.map { it.e }) } catch (e: Exception) { 1.5 }
        for (i in 1 until pts.size) {
            val p = pts[i]; val dt = (p.t - prev.t) / 1000
            val dd: Double = if (fin(p.d) && fin(prev.d)) max(0.0, p.d - prev.d)
            else if (fin(p.la) && fin(prev.la)) hav(prev.la, prev.lo, p.la, p.lo) else 0.0
            if (!(dt > 0)) { prev = p; continue }
            cum += dd
            if (dt <= 30 && dd / dt >= 0.4) {
                mov += dt
                if (fin(p.h) && p.h >= 40 && p.h <= 230) {
                    hrSum += p.h * dt; hrT += dt
                    val hb = Js.roundI(p.h); hist[hb] = (hist[hb] ?: 0.0) + dt
                    if (p.h > hrMax) hrMax = p.h
                }
                if (fin(p.c) && p.c > 0 && p.c < 250) { cSum += p.c * dt; cT += dt }
            }
            if (fin(p.e)) {
                val rf = ref
                if (rf == null) ref = p.e
                else if (p.e - rf >= gTh) { gain += p.e - rf; ref = p.e }
                else if (rf - p.e >= gTh) { loss += rf - p.e; ref = p.e }
            }
            rows.add(Row(cum, mov, p.h, p.e, gain, loss, p.c, p.t))
            prev = p
        }
        if (cum < 200 || mov < 60) throw ActImportException("aktivitas terlalu pendek")

        // GAP: kemiringan dihaluskan 40 m, lalu biaya energi per meter (Minetti)
        var hasQ = false
        if (!bike) {
            val ix = rows.indices.filter { fin(rows[it].e) }
            val n = ix.size
            if (n >= 10) {
                val es = DoubleArray(n); var lo = 0; var hi = 0; var sum = 0.0; var cnt = 0
                for (k in 0 until n) {
                    val dk = rows[ix[k]].d
                    while (hi < n && rows[ix[hi]].d <= dk + 20) { sum += rows[ix[hi]].e; cnt++; hi++ }
                    while (lo < n && rows[ix[lo]].d < dk - 20) { sum -= rows[ix[lo]].e; cnt--; lo++ }
                    es[k] = sum / cnt
                }
                val gr = DoubleArray(n); var a1 = 0; var a2 = 0
                for (k in 0 until n) {
                    val d0 = rows[ix[k]].d
                    while (a1 < n - 1 && rows[ix[a1]].d < d0 - 25) a1++
                    if (a2 < k) a2 = k
                    while (a2 < n - 1 && rows[ix[a2 + 1]].d <= d0 + 25) a2++
                    val dd3 = rows[ix[a2]].d - rows[ix[a1]].d
                    gr[k] = if (dd3 >= 15) (es[a2] - es[a1]) / dd3 else (if (k > 0) gr[k - 1] else 0.0)
                    if (gr[k] > .4) gr[k] = .4
                    if (gr[k] < -.4) gr[k] = -.4
                }
                val gAt = DoubleArray(rows.size) { Double.NaN }
                for (k in 0 until n) gAt[ix[k]] = gr[k]
                var last = 0.0
                for (k in rows.indices) { if (gAt[k].isNaN()) gAt[k] = last else last = gAt[k] }
                var q = 0.0
                rows[0].q = 0.0
                for (k in 1 until rows.size) {
                    val sd = rows[k].d - rows[k - 1].d
                    q += sd * gapF((gAt[k] + gAt[k - 1]) / 2); rows[k].q = q
                }
                hasQ = true
            }
        }

        // split per km
        val splits = ArrayList<Map<String, Any?>>()
        var nextK = 1000.0; var sT = 0.0; var sG = 0.0; var sL = 0.0; var sQ = 0.0
        var hw = 0.0; var ht = 0.0; var cw = 0.0; var ct = 0.0
        for (j in 1 until rows.size) {
            val a = rows[j - 1]; val b = rows[j]; val w = b.t - a.t
            if (w > 0 && fin(b.h) && b.h >= 40 && b.h <= 230) { hw += b.h * w; ht += w }
            if (w > 0 && fin(b.c) && b.c > 0 && b.c < 250) { cw += b.c * w; ct += w }
            while (b.d >= nextK) {
                val fr = (nextK - a.d) / (if (b.d - a.d != 0.0) b.d - a.d else 1.0)
                val tc = a.t + fr * (b.t - a.t); val gc = a.g + fr * (b.g - a.g); val lc = a.l + fr * (b.l - a.l)
                val qc = if (hasQ) a.q + fr * (b.q - a.q) else 0.0
                splits.add(linkedMapOf(
                    "k" to nextK / 1000, "p" to r3((tc - sT) / 60),
                    "h" to (if (ht != 0.0) Js.round(hw / ht) else null),
                    "g" to Js.round(gc - sG), "l" to Js.round(lc - sL),
                    "c" to (if (ct != 0.0) Js.round(cw / ct * csc) else null),
                    "gp" to (if (hasQ && (qc - sQ) > 0) r3((tc - sT) / 60 / ((qc - sQ) / 1000)) else null),
                ))
                sT = tc; sG = gc; sL = lc
                if (hasQ) sQ = qc
                hw = 0.0; ht = 0.0; cw = 0.0; ct = 0.0; nextK += 1000
            }
        }
        val rem = cum - (nextK - 1000); val lr = rows.last()
        if (rem >= 200) splits.add(linkedMapOf(
            "k" to Js.round(cum / 10) / 100, "p" to r3(((lr.t - sT) / 60) / (rem / 1000)),
            "h" to (if (ht != 0.0) Js.round(hw / ht) else null),
            "g" to Js.round(lr.g - sG), "l" to Js.round(lr.l - sL),
            "c" to (if (ct != 0.0) Js.round(cw / ct * csc) else null),
            "gp" to (if (hasQ && (lr.q - sQ) > 0) r3(((lr.t - sT) / 60) / ((lr.q - sQ) / 1000)) else null),
            "part" to 1,
        ))

        // rute dinormalkan 0..1000
        val rt = ArrayList<List<Int>>(); var rw = 0; var rh = 0; var ge: List<Double>? = null
        val geo = pts.filter { fin(it.la) && fin(it.lo) }
        if (geo.size >= 2) {
            val la0 = geo.sumOf { it.la } / geo.size; val cs = cos(la0 * Math.PI / 180)
            val st = max(1, geo.size / 140)
            val xs = ArrayList<Double>(); val ys = ArrayList<Double>()
            var i = 0
            while (i < geo.size) { xs.add(geo[i].lo * cs); ys.add(geo[i].la); i += st }
            xs.add(geo.last().lo * cs); ys.add(geo.last().la)
            val mnx = xs.min(); val mxx = xs.max(); val mny = ys.min(); val mxy = ys.max()
            val sc = 1000 / max(max(mxx - mnx, mxy - mny), 1e-9)
            for (k in xs.indices) rt.add(listOf(Js.roundI((xs[k] - mnx) * sc), Js.roundI((mxy - ys[k]) * sc)))
            rw = Js.roundI((mxx - mnx) * sc); rh = Js.roundI((mxy - mny) * sc)
            fun f6(x: Double) = Js.round(x * 1e6) / 1e6
            ge = listOf(f6(mnx / cs), f6(mxy), Js.round(sc * 1e4) / 1e4, f6(cs))
        }

        // deret pace / HR / kadens per ~cum/90
        val pcs = ArrayList<List<Double>>(); val hsr = ArrayList<List<Double>>(); val csr = ArrayList<List<Double>>()
        val nb = min(90, floor(cum / 100).toInt())
        if (nb >= 4) {
            val bw = cum / nb
            val bd = DoubleArray(nb); val bt = DoubleArray(nb); val bhw = DoubleArray(nb); val bht = DoubleArray(nb)
            val bcw = DoubleArray(nb); val bct = DoubleArray(nb)
            for (j in 1 until rows.size) {
                val r0 = rows[j - 1]; val r1 = rows[j]; val dd2 = r1.d - r0.d; val dt2 = r1.t - r0.t
                val bi = min(nb - 1, floor(((r0.d + r1.d) / 2) / bw).toInt())
                bd[bi] += dd2; bt[bi] += dt2
                if (dt2 > 0 && fin(r1.h) && r1.h >= 40 && r1.h <= 230) { bhw[bi] += r1.h * dt2; bht[bi] += dt2 }
                if (dt2 > 0 && fin(r1.c) && r1.c > 0 && r1.c < 250) { bcw[bi] += r1.c * dt2; bct[bi] += dt2 }
            }
            fun smooth(a: List<Double?>): List<Double?> = a.mapIndexed { i, v ->
                if (v == null) null else {
                    var s0 = 0.0; var n0 = 0
                    for (k in i - 1..i + 1) { val x = a.getOrNull(k); if (x != null) { s0 += x; n0++ } }
                    s0 / n0
                }
            }
            val pv = smooth((0 until nb).map { if (bd[it] > 20 && bt[it] > 3) (bt[it] / 60) / (bd[it] / 1000) else null })
            val hv = smooth((0 until nb).map { if (bht[it] > 0) bhw[it] / bht[it] else null })
            val cv = smooth((0 until nb).map { if (bct[it] > 0) bcw[it] / bct[it] else null })
            for (q in 0 until nb) {
                val kx = Js.round((q + .5) * bw / 10) / 100
                pv[q]?.let { if (it < 30) pcs.add(listOf(kx, r3(it))) }
                hv[q]?.let { hsr.add(listOf(kx, Js.round(it * 10) / 10)) }
                cv[q]?.let { csr.add(listOf(kx, Js.round(it * csc))) }
            }
        }
        val prof = ArrayList<List<Double>>()
        val ev = rows.filter { fin(it.e) }
        if (ev.size >= 2) {
            val ps = max(1, ev.size / 90)
            var i = 0
            while (i < ev.size) { prof.add(listOf(Js.round(ev[i].d / 100) / 10, Js.round(ev[i].e * 10) / 10)); i += ps }
        }

        val t0 = pts[0].t
        val zdt = Instant.ofEpochMilli(t0.toLong()).atZone(zone)
        val tps = pts.filter { fin(it.tp) && it.tp > -30 && it.tp < 60 }.map { it.tp }.sorted()
        val out = LinkedHashMap<String, Any?>()
        out["t0"] = t0
        geo.firstOrNull()?.let { out["sla"] = r3(it.la); out["slo"] = r3(it.lo) }
        if (tps.size >= 5) out["tmp"] = tps[tps.size / 2]
        out["date"] = zdt.toLocalDate().toString()
        out["st"] = Js.pad(zdt.hour) + ":" + Js.pad(zdt.minute)
        out["nm"] = nm.take(60)
        out["bike"] = bike
        if (xk != null) out["xk"] = xk
        out["km"] = Js.round(cum / 10) / 100
        out["min"] = r2(mov / 60)
        out["el"] = r2(max((pts.last().t - pts[0].t) / 60000, mov / 60))
        out["gain"] = if (prof.isNotEmpty()) Js.round(gain) else null
        out["loss"] = if (prof.isNotEmpty()) Js.round(loss) else null
        out["gap"] = if (hasQ && rows.last().q > 0) r3((mov / 60) / (rows.last().q / 1000)) else null
        out["hr"] = if (hrT != 0.0) Js.round(hrSum / hrT) else null
        out["hrMax"] = if (hrMax != 0.0) Js.round(hrMax) else null
        out["sp"] = splits
        out["rt"] = rt; out["rw"] = rw; out["rh"] = rh; out["ge"] = ge
        out["pf"] = prof; out["ps"] = pcs; out["hs"] = hsr; out["cs"] = csr
        out["cad"] = if (cT != 0.0) Js.round(cSum / cT * csc) else null
        out["h"] = hist.mapKeys { it.key.toString() }
        return out
    }
}
