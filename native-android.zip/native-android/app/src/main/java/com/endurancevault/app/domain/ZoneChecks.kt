package com.endurancevault.app.domain

/** Pemeriksaan isian zona dan pace untuk layar Profil dan pengaturan Zona HR. Murni Kotlin, tanpa Android. */
object ZoneChecks {
    /** Pace easy "m:ss" (menit 3–12, detik 00–59). Null bila valid, selain itu pesan singkat. */
    fun pace(t: String): String? {
        val m = Regex("^(\\d{1,2}):(\\d{2})$").matchEntire(t.trim()) ?: return "Format m:ss, mis. 6:30"
        val min = m.groupValues[1].toInt(); val sec = m.groupValues[2].toInt()
        if (sec > 59) return "Detik harus 00–59"
        val total = min * 60 + sec
        return if (total in 180..720) null else "Pace di luar 3:00–12:00 per km"
    }

    /** Rentang threshold "164–172" (dua angka 2–3 digit, naik). Null bila valid. */
    fun thrRange(t: String): String? {
        val m = Regex("^\\s*(\\d{2,3})\\D+(\\d{2,3})\\s*$").matchEntire(t) ?: return "Format 164–172"
        val a = m.groupValues[1].toInt(); val b = m.groupValues[2].toInt()
        return when {
            a >= b -> "Angka kedua harus lebih besar"
            b > 230 || a < 60 -> "Di luar 60–230 bpm"
            else -> null
        }
    }

    /** Batas HR easy (bpm). Null bila valid. */
    fun easyHr(t: String): String? {
        val v = t.trim().toIntOrNull() ?: return "Isi angka bpm"
        return if (v in 80..220) null else "Di luar 80–220 bpm"
    }

    /**
     * Persen zona: naik ketat, lebih dari 0, tidak melebihi [top] (aturan sama dengan Zones.zcut).
     * Hasil sejajar dengan [values]; null = baik, selain itu pesan untuk kolom itu.
     */
    fun pctIssues(values: List<Double?>, labels: List<String>, top: Double): List<String?> =
        values.mapIndexed { i, v ->
            when {
                v == null || !v.isFinite() -> "${labels[i]}: isi angka"
                v <= 0 -> "${labels[i]}: harus lebih dari 0"
                v > top -> "${labels[i]}: maksimal ${fmt(top)}%"
                i > 0 && values[i - 1] != null && v <= values[i - 1]!! -> "${labels[i]}: harus lebih besar dari ${labels[i - 1]} (${fmt(values[i - 1]!!)}%)"
                else -> null
            }
        }

    private fun fmt(d: Double) = if (d % 1.0 == 0.0) d.toInt().toString() else d.toString()
}
