package com.endurancevault.app.domain

class Split(
    val k: Double, val pace: Double, val hr: Int?, val gain: Int, val loss: Int,
    val cad: Int?, val gap: Double?, val partial: Boolean,
)

class Segment(
    val k: Double, val d: Double, val min: Double, val pace: Double, val hr: Int?,
    val gain: Int, val loss: Int, val cad: Int?, val name: String, val type: String?,
)

/** Detail satu aktivitas, dibaca dari objek aktivitas format web (rt, pf, sp, sg, h, dst.). */
class ActDetail(
    val date: String, val startTime: String, val name: String, val bike: Boolean, val kind: String?,
    val km: Double, val movingMin: Double, val elapsedMin: Double,
    val gain: Int?, val loss: Int?, val hr: Int?, val hrMax: Int?, val cad: Int?, val gapPace: Double?,
    val splits: List<Split>, val segments: List<Segment>,
    /** titik rute dinormalkan 0..1000 (x ke kanan, y ke bawah), lebar rw dan tinggi rh */
    val route: List<Pair<Int, Int>>, val routeW: Int, val routeH: Int,
    val profile: List<Pair<Double, Double>>,       // (km, elevasi m)
    val paceSeries: List<Pair<Double, Double>>,    // (km, menit/km)
    val hrSeries: List<Pair<Double, Double>>,
    val cadSeries: List<Pair<Double, Double>>,
    val hrHist: Map<Int, Double>,                  // bpm -> detik
) {
    val avgPace: Double? get() = if (km > 0 && movingMin > 0) movingMin / km else null
    val hasRoute: Boolean get() = route.size >= 2
}
