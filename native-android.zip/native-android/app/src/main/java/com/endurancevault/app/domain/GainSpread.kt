package com.endurancevault.app.domain

import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/** Keadaan penghalus selama satu panggilan plan(): D+ minggu beban penuh terakhir. */
class GainState(var full: Double = 0.0)

/**
 * Port penghalus tanjakan rencana trail dari versi web (02-i18n-penyimpanan-perencana.js: gainTarget, gainSet,
 * gainSpread). D+ mingguan naik bertahap dan dibagi ke long run, medium, sesi hike, dan easy.
 * Aktif bila jenis lomba trail dan `gSmooth` tidak dimatikan.
 */
internal object GainSpread {
    const val UNG_KM = 7.0
    const val UNG_GAIN = 750
    private const val GAIN_STEP = .10
    private const val GAIN_CUT = .8
    private const val GAIN_PK3 = .9
    private const val GAIN_LONG_MAX = .55
    private const val W_LONG = .35
    private const val W_MEDIUM = .25
    private const val W_HIKE = .30
    private const val W_EASY = .20
    const val GAIN_CEIL = 1.5

    fun f10(n: Double): Double = floor(n / 10 + 1e-9) * 10

    fun gSum(days: List<PDay>): Double {
        var t = 0.0
        days.forEach { d -> if (d.kind != Kinds.REST && d.kind != Kinds.RACE && (d.gain ?: 0) > 0) t += d.gain!! }
        return t
    }

    fun gainTarget(f: Double, raw: Double, phase: String, cut: Boolean, third: Boolean, tf: Double, g0: Double, ceil: Double): Double {
        if (phase == Phases.TAPER) return if (f > 0) f10(f * tf) else f10(raw)
        if (cut) return if (f > 0) f10(f * GAIN_CUT) else f10(raw)
        if (third) return if (f > 0) f10(f * GAIN_PK3) else f10(raw)
        if (!(f > 0)) return if (g0 > 0) f10(g0) else f10(raw)
        val up = max(f10(f * (1 + GAIN_STEP)), f + 50)
        return f10(min(up, max(if (g0 > 0) ceil else raw, f)))
    }

    private fun gainSet(d: PDay, g: Int) {
        val mk = d.mk
        if (mk != null) { mk(g); return }
        if (d.bd == null) d.bd = d.detail
        if (g > 0) {
            d.gain = g
            d.detail = d.bd + (if (d.role == "quality") " Sekitar +${Js.idn(g)} m." else " Pilih rute bergelombang. Sekitar +${Js.idn(g)} m.")
        } else {
            d.gain = null
            d.detail = d.bd!!
        }
    }

    private class Slot(val d: PDay, val w: Double, val cap: Double, var g: Double = 0.0)
    private class Trial(val s: List<Slot>, val lump: Int, val rem: Double, val lp: Int)

    /** @return total D+ yang terpasang pada pekan ini. */
    fun spread(days: List<PDay>, t: Double, evIdx: Int, evG: Double): Double {
        var fixed = evG
        val fl = mutableListOf<PDay>()
        days.forEachIndexed { ix, d ->
            if (d.kind == Kinds.REST || d.kind == Kinds.RACE || d.kind == Kinds.EVENT) return@forEachIndexed
            if (ix == evIdx) { d.gain = null; return@forEachIndexed }
            if (d.glock) { fixed += (d.gain ?: 0); return@forEachIndexed }
            if (d.km > 0) fl.add(d)
        }
        val r = max(0.0, t - fixed)
        val lg = fl.firstOrNull { it.role == "long" }
        val md = fl.firstOrNull { it.role == "medium" }
        val hk = fl.firstOrNull { it.role == "quality" && it.qk == "hike" }
        val easy = fl.filter { (it.role == "easy" || it.role == "short") && it.altMins == null }
        val lpMax = if (lg != null && lg.lk > 0) min(lg.lk, floor(r * GAIN_LONG_MAX / UNG_GAIN).toInt()) else 0

        fun trial(lp: Int, mul: Double): Trial {
            val s = mutableListOf<Slot>()
            val lump = lp * UNG_GAIN
            var rem = r - lump
            if (lg != null && lp == 0) s.add(Slot(lg, W_LONG, f10(min(lg.km * 100, r * GAIN_LONG_MAX))))
            if (md != null) s.add(Slot(md, W_MEDIUM, f10(md.km * 60 * mul)))
            if (hk != null && (hk.qMin ?: 0.0) > 0) s.add(Slot(hk, W_HIKE, f10(hk.qMin!! * 10 * mul)))
            easy.forEach { s.add(Slot(it, W_EASY / easy.size, f10(it.km * 20 * mul))) }
            var k = 0
            while (k < 6 && rem >= 10) {
                val free = s.filter { it.g < it.cap }
                var sw = 0.0; free.forEach { sw += it.w }
                if (free.isEmpty() || !(sw > 0)) break
                var used = 0.0
                free.forEach { x ->
                    val a = f10(min(rem * x.w / sw, x.cap - x.g)); x.g += a; used += a
                }
                rem -= used
                if (used <= 0) break
                k++
            }
            while (rem >= 10) {
                val free = s.filter { it.g + 10 <= it.cap }.sortedByDescending { it.w * (it.cap - it.g) }
                if (free.isEmpty()) break
                var kk = 0
                while (kk < free.size && rem >= 10) { free[kk].g += 10; rem -= 10; kk++ }
            }
            return Trial(s, lump, rem, lp)
        }

        var best: Trial? = null
        val mulL = doubleArrayOf(1.0, 1.5, 2.0)
        var mi = 0
        while (mi < mulL.size && !(best != null && best.rem < 10)) {
            var lp = lpMax
            while (lp >= 0) {
                val tr = trial(lp, mulL[mi])
                if (best == null || tr.rem < best.rem) best = tr
                if (tr.rem < 10) break
                lp--
            }
            mi++
        }
        val b = best!!
        var tot = fixed + b.lump
        if (lg != null && b.lp > 0) lg.mkLong?.invoke(b.lump, b.lp)
        b.s.forEach { x ->
            tot += x.g
            if (x.d.role == "long") x.d.mkLong?.invoke(x.g.toInt(), 0) else gainSet(x.d, x.g.toInt())
        }
        return tot
    }
}
