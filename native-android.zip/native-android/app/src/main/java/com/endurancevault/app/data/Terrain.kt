package com.endurancevault.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Rect
import com.endurancevault.app.domain.RouteGeo
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Medan 3D di sekitar rute: grid tinggi persegi ([sizeM] meter per sisi, pusat di titik tengah rute), citra satelit yang
 * menutupi persis grid itu, dan titik rute dalam meter relatif terhadap pusat (x ke timur, z ke selatan).
 */
class TerrainScene(
    val n: Int,
    /** Tinggi medan (m), baris demi baris dari utara; ukuran n*n. */
    val heights: FloatArray,
    val sizeM: Float,
    val satellite: Bitmap?,
    val routeX: FloatArray,
    val routeZ: FloatArray,
    /** Bagian jarak aktivitas (0..1) di tiap titik rute. */
    val routeFrac: FloatArray,
    val demOk: Boolean,
) {
    val minH: Float = heights.minOrNull() ?: 0f
    val maxH: Float = heights.maxOrNull() ?: 0f

    /** Tinggi medan (m) di (x, z) meter relatif pusat, interpolasi bilinear. */
    fun heightAt(x: Float, z: Float): Float {
        val fx = ((x / sizeM + .5f) * (n - 1)).coerceIn(0f, n - 1f)
        val fz = ((z / sizeM + .5f) * (n - 1)).coerceIn(0f, n - 1f)
        val i0 = fx.toInt().coerceAtMost(n - 2); val j0 = fz.toInt().coerceAtMost(n - 2)
        val tx = fx - i0; val tz = fz - j0
        val a = heights[j0 * n + i0]; val b = heights[j0 * n + i0 + 1]
        val c = heights[(j0 + 1) * n + i0]; val d = heights[(j0 + 1) * n + i0 + 1]
        return (a * (1 - tx) + b * tx) * (1 - tz) + (c * (1 - tx) + d * tx) * tz
    }

    val routeY: FloatArray = FloatArray(routeX.size) { heightAt(routeX[it], routeZ[it]) }
}

/** Ubin elevasi Terrarium (AWS Open Data, tanpa kunci API): tinggi (m) = R*256 + G + B/256 - 32768. */
private object TerrariumTiles {
    private const val USER_AGENT = "EnduranceVault/0.5.51 (Android; personal fitness log)"
    private const val MAX_AGE_MS = 60L * 24 * 60 * 60 * 1000

    /** Piksel ARGB 256x256, atau null bila tidak ada di cache dan unduhan gagal. */
    fun load(ctx: Context, z: Int, x: Int, y: Int): IntArray? {
        val file = File(ctx.applicationContext.cacheDir, "tiles-terrarium/$z/$x/$y.png")
        val fresh = file.isFile && System.currentTimeMillis() - file.lastModified() < MAX_AGE_MS
        if (fresh) decode(file)?.let { return it }
        val bytes = download(z, x, y)
        if (bytes != null) {
            runCatching { file.parentFile?.mkdirs(); file.writeBytes(bytes) }
            pixels(BitmapFactory.decodeByteArray(bytes, 0, bytes.size))?.let { return it }
        }
        return if (file.isFile) decode(file) else null
    }

    private fun decode(file: File): IntArray? = pixels(runCatching { BitmapFactory.decodeFile(file.absolutePath) }.getOrNull())

    private fun pixels(b: Bitmap?): IntArray? {
        if (b == null || b.width != 256 || b.height != 256) return null
        val px = IntArray(256 * 256)
        b.getPixels(px, 0, 256, 0, 0, 256, 256)
        b.recycle()
        return px
    }

    private fun download(z: Int, x: Int, y: Int): ByteArray? {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL("https://s3.amazonaws.com/elevation-tiles-prod/terrarium/$z/$x/$y.png").openConnection() as HttpURLConnection).apply {
                connectTimeout = 8_000; readTimeout = 8_000
                setRequestProperty("User-Agent", USER_AGENT)
            }
            if (conn.responseCode != 200) null else conn.inputStream.use { it.readBytes() }
        } catch (_: Exception) { null } finally { conn?.disconnect() }
    }
}

object TerrainBuilder {
    private const val GRID = 160
    private const val M_PER_DEG = 111_320.0
    private const val MAX_ROUTE_POINTS = 700

    private fun zoomFor(dLon: Double, targetPx: Double, minZ: Int, maxZ: Int): Int =
        floor(ln(targetPx * 360.0 / (256.0 * dLon)) / ln(2.0)).toInt().coerceIn(minZ, maxZ)

    /**
     * Unduh (atau baca dari cache) citra satelit dan elevasi lalu susun [TerrainScene]. Null bila rute kosong atau terjadi galat.
     * Tanpa jaringan dan tanpa cache, medan jadi datar ([TerrainScene.demOk] false) dan/atau tanpa citra.
     */
    suspend fun build(
        ctx: Context, lat: DoubleArray, lon: DoubleArray, dist: DoubleArray, onStatus: (String) -> Unit = {},
    ): TerrainScene? = withContext(Dispatchers.IO) {
        runCatching { buildInternal(ctx, lat, lon, dist, onStatus) }.getOrNull()
    }

    private suspend fun buildInternal(
        ctx: Context, lat: DoubleArray, lon: DoubleArray, dist: DoubleArray, onStatus: (String) -> Unit,
    ): TerrainScene? {
        val cnt = lat.size
        if (cnt < 2 || lon.size != cnt || dist.size != cnt) return null
        val latMin = lat.min(); val latMax = lat.max(); val lonMin = lon.min(); val lonMax = lon.max()
        val cLat = (latMin + latMax) / 2; val cLon = (lonMin + lonMax) / 2
        val cosL = cos(Math.toRadians(cLat)).coerceAtLeast(0.05)
        val wM = (lonMax - lonMin) * M_PER_DEG * cosL; val hM = (latMax - latMin) * M_PER_DEG
        val side = max(max(wM, hM) * 1.6, 1200.0).coerceAtMost(60_000.0)
        val dLat = side / 2 / M_PER_DEG; val dLon = side / 2 / (M_PER_DEG * cosL)
        val latN = cLat + dLat; val latS = cLat - dLat; val lonW = cLon - dLon; val lonE = cLon + dLon

        // ---- Citra satelit ----
        val zs = zoomFor(lonE - lonW, 1536.0, 8, 17)
        val sx0 = RouteGeo.worldX(lonW, zs); val sx1 = RouteGeo.worldX(lonE, zs)
        val sy0 = RouteGeo.worldY(latN, zs); val sy1 = RouteGeo.worldY(latS, zs)
        val tx0 = floor(sx0 / 256).toInt(); val tx1 = floor((sx1 - 1e-6) / 256).toInt()
        val ty0 = floor(sy0 / 256).toInt(); val ty1 = floor((sy1 - 1e-6) / 256).toInt()
        val mosaic = Bitmap.createBitmap((tx1 - tx0 + 1) * 256, (ty1 - ty0 + 1) * 256, Bitmap.Config.ARGB_8888)
        val mc = Canvas(mosaic); mc.drawColor(0xFF20262A.toInt())
        val total = (tx1 - tx0 + 1) * (ty1 - ty0 + 1)
        var done = 0; var okTiles = 0
        val worldTiles = 1 shl zs
        for (ty in ty0..ty1) for (tx in tx0..tx1) {
            onStatus("Mengunduh peta satelit ${++done}/$total…")
            if (ty !in 0 until worldTiles) continue
            val id = RouteGeo.TileId(zs, Math.floorMod(tx, worldTiles), ty)
            MapTiles.load(ctx, id, MapStyle.SATELLITE)?.let {
                val l = (tx - tx0) * 256; val t = (ty - ty0) * 256
                mc.drawBitmap(it, null, Rect(l, t, l + 256, t + 256), null); okTiles++
            }
        }
        var sat: Bitmap? = null
        if (okTiles > 0) {
            val cx = (sx0 - tx0 * 256).roundToInt().coerceIn(0, mosaic.width - 2)
            val cy = (sy0 - ty0 * 256).roundToInt().coerceIn(0, mosaic.height - 2)
            val cw = (sx1 - sx0).roundToInt().coerceIn(2, mosaic.width - cx)
            val ch = (sy1 - sy0).roundToInt().coerceIn(2, mosaic.height - cy)
            sat = Bitmap.createBitmap(mosaic, cx, cy, cw, ch)
        }
        if (sat !== mosaic) mosaic.recycle()

        // ---- Elevasi ----
        val zt = zoomFor(lonE - lonW, 768.0, 5, 14)
        val ex0 = RouteGeo.worldX(lonW, zt); val ex1 = RouteGeo.worldX(lonE, zt)
        val ey0 = RouteGeo.worldY(latN, zt); val ey1 = RouteGeo.worldY(latS, zt)
        val dx0 = floor(ex0 / 256).toInt(); val dx1 = floor((ex1 - 1e-6) / 256).toInt()
        val dy0 = floor(ey0 / 256).toInt(); val dy1 = floor((ey1 - 1e-6) / 256).toInt()
        val demCols = dx1 - dx0 + 1; val demRows = dy1 - dy0 + 1
        val dem = arrayOfNulls<IntArray>(demCols * demRows)
        val demWorld = 1 shl zt
        var demDone = 0; var demOkTiles = 0
        for (ty in dy0..dy1) for (tx in dx0..dx1) {
            onStatus("Mengunduh data elevasi ${++demDone}/${demCols * demRows}…")
            if (ty !in 0 until demWorld) continue
            val px = TerrariumTiles.load(ctx, zt, Math.floorMod(tx, demWorld), ty)
            dem[(ty - dy0) * demCols + (tx - dx0)] = px
            if (px != null) demOkTiles++
        }
        fun pixelH(ix: Int, iy: Int): Float {
            val col = Math.floorDiv(ix, 256) - dx0; val row = Math.floorDiv(iy, 256) - dy0
            if (col !in 0 until demCols || row !in 0 until demRows) return Float.NaN
            val t = dem[row * demCols + col] ?: return Float.NaN
            val p = t[Math.floorMod(iy, 256) * 256 + Math.floorMod(ix, 256)]
            return ((p shr 16) and 255) * 256f + ((p shr 8) and 255) + (p and 255) / 256f - 32768f
        }
        fun demAt(wx: Double, wy: Double): Float {
            val fx = wx - 0.5; val fy = wy - 0.5
            val ix = floor(fx).toInt(); val iy = floor(fy).toInt()
            val tx = (fx - ix).toFloat(); val ty = (fy - iy).toFloat()
            val h = floatArrayOf(pixelH(ix, iy), pixelH(ix + 1, iy), pixelH(ix, iy + 1), pixelH(ix + 1, iy + 1))
            val w = floatArrayOf((1 - tx) * (1 - ty), tx * (1 - ty), (1 - tx) * ty, tx * ty)
            var s = 0f; var ws = 0f
            for (q in 0..3) if (!h[q].isNaN()) { s += h[q] * w[q]; ws += w[q] }
            return if (ws <= 1e-6f) Float.NaN else s / ws
        }

        val g = GRID
        val heights = FloatArray(g * g)
        var sum = 0.0; var good = 0
        for (j in 0 until g) for (i in 0 until g) {
            val v = if (demOkTiles == 0) Float.NaN else
                demAt(ex0 + (ex1 - ex0) * i / (g - 1), ey0 + (ey1 - ey0) * j / (g - 1))
            heights[j * g + i] = v
            if (!v.isNaN()) { sum += v; good++ }
        }
        val demOk = good > 0
        val fill = if (demOk) (sum / good).toFloat() else 0f
        for (q in heights.indices) if (heights[q].isNaN()) heights[q] = fill

        // ---- Rute dalam meter relatif pusat ----
        val sideF = side.toFloat()
        val step = max(1, cnt / MAX_ROUTE_POINTS)
        val xs = ArrayList<Float>(); val zs2 = ArrayList<Float>(); val fr = ArrayList<Float>()
        val totalM = dist.last().coerceAtLeast(1.0)
        fun add(i: Int, force: Boolean) {
            val fx = (RouteGeo.worldX(lon[i], zt) - ex0) / (ex1 - ex0)
            val fy = (RouteGeo.worldY(lat[i], zt) - ey0) / (ey1 - ey0)
            val x = ((fx - .5) * side).toFloat(); val z = ((fy - .5) * side).toFloat()
            if (!force && xs.isNotEmpty()) {
                val dx = x - xs.last(); val dz = z - zs2.last()
                if (dx * dx + dz * dz < 4f) return   // titik diam: hindari arah garis yang tidak terdefinisi
            }
            xs.add(x); zs2.add(z); fr.add((dist[i] / totalM).toFloat())
        }
        var i = 0
        while (i < cnt - 1) { add(i, false); i += step }
        add(cnt - 1, true)
        if (xs.size < 2) return null

        return TerrainScene(
            g, heights, sideF, sat,
            xs.toFloatArray(), zs2.toFloatArray(), fr.toFloatArray(), demOk,
        )
    }
}
