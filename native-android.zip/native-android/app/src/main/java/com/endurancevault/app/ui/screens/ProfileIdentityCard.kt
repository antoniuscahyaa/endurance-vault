package com.endurancevault.app.ui.screens

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Memuat foto profil dari URI (di thread IO); null bila belum ada foto atau gagal dibaca. */
@Composable
internal fun rememberProfileAvatar(photoUri: String?): ImageBitmap? {
    val context = LocalContext.current
    val avatar by produceState<ImageBitmap?>(null, photoUri) {
        value = if (photoUri.isNullOrBlank()) null else withContext(Dispatchers.IO) {
            runCatching {
                context.contentResolver.openInputStream(Uri.parse(photoUri))?.use {
                    BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = 4 })?.asImageBitmap()
                }
            }.getOrNull()
        }
    }
    return avatar
}

/** Satu kartu di halaman Pengaturan untuk mengganti foto dan nama profil. */
@Composable
internal fun ProfileIdentityCard(
    name: String,
    photoUri: String?,
    onEditName: () -> Unit,
    onPickPhoto: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val avatar = rememberProfileAvatar(photoUri)
    val shape = RoundedCornerShape(16.dp)
    Row(
        modifier.fillMaxWidth().clip(shape).border(BorderStroke(0.8.dp, cs.outlineVariant), shape).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            Modifier.size(56.dp).clip(CircleShape).background(cs.surfaceVariant)
                .border(1.dp, cs.outlineVariant, CircleShape).clickable(onClick = onPickPhoto),
            contentAlignment = Alignment.Center,
        ) {
            if (avatar != null) {
                Image(bitmap = avatar, contentDescription = "Foto profil", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            } else {
                Icon(Icons.Filled.Person, contentDescription = "Pilih foto profil", tint = cs.onSurfaceVariant, modifier = Modifier.size(30.dp))
            }
            Box(
                Modifier.align(Alignment.BottomEnd).size(20.dp).clip(CircleShape).background(cs.surface)
                    .border(1.dp, cs.outlineVariant, CircleShape),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Filled.Edit, contentDescription = null, modifier = Modifier.size(12.dp), tint = cs.primary) }
        }
        Column(Modifier.weight(1f).clickable(onClick = onEditName), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("PROFIL", style = MaterialTheme.typography.labelSmall, color = cs.primary)
            Text(
                name.ifBlank { "Tambahkan nama profil" },
                style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = if (name.isBlank()) cs.onSurfaceVariant else cs.onSurface,
            )
            Text("Ketuk foto atau nama untuk mengubah", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
        Icon(Icons.Filled.Edit, contentDescription = "Edit nama", modifier = Modifier.size(18.dp).clickable(onClick = onEditName), tint = cs.onSurfaceVariant)
    }
}
