package com.endurancevault.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.ZoneId

/**
 * Normalizes direct Huawei-watch protocol records into EnduranceVault daily rows, following the legacy
 * `hwApplyDaily` / `hwHrvPlan` rules. Manual values are never overwritten; values written by the watch carry an
 * ownership marker so a later sync can refresh them.
 */
object HuaweiWatchImport {
    /** JS Math.round: halves round up. */
    private fun jsRound(v: Double): Int = Math.floor(v + 0.5).toInt()

    fun daily(payload: JSONObject, existing: List<DailyEntity>, zone: ZoneId = ZoneId.systemDefault()): List<DailyEntity> {
        val oldByDate = existing.associateBy { it.dateIso }
        val days = linkedMapOf<String, DayData>()

        val dayRows = payload.optJSONArray("days") ?: JSONArray()
        for (i in 0 until dayRows.length()) {
            val row = dayRows.optJSONObject(i) ?: continue
            val date = row.optString("day")
            if (date.length != 10) continue
            val d = days.getOrPut(date) { DayData() }
            // Legacy: the day's average of resting-HR samples (needs >= 1 sample), rounded; range 30..120.
            val avg = row.optDoubleOrNull("rhrAvg")
            val n = if (row.has("rhrN")) row.optInt("rhrN", 0) else 1
            val rhr = if (avg != null && avg > 0 && n >= 1) jsRound(avg) else row.optIntOrNull("rhrLast")
            if (rhr != null && rhr in 30..120) d.rhr = rhr
        }

        // Workout windows are cut out of the sleep records so "light sleep" logged during a run is not counted.
        val busy = HuaweiSleepParity.busyFromPayload(payload.optJSONArray("busy"))
            .ifEmpty { HuaweiSleepParity.busyOf(payload.optJSONArray("workouts")) }
        val sleepRows = payload.optJSONArray("sleep") ?: JSONArray()
        val parsed = HuaweiSleepParity.parseAll(sleepRows, zone, busy)
        parsed.nights.forEach { night -> days.getOrPut(night.date) { DayData() }.night = night }
        parsed.naps.forEach { nap -> days.getOrPut(nap.date) { DayData() }.nap = nap }

        val scores = payload.optJSONArray("sleepScores") ?: JSONArray()
        for (i in 0 until scores.length()) {
            val row = scores.optJSONObject(i) ?: continue
            val end = row.optLong("end", 0L)
            if (end <= 0) continue
            val date = Instant.ofEpochSecond(end).atZone(zone).toLocalDate().toString()
            val d = days.getOrPut(date) { DayData() }
            // One value per wake date: the sleep ending last (legacy hwVitalsPlan).
            row.optIntOrNull("score")?.let { d.sleepScore = it }
            row.optIntOrNull("efficiency")?.let { d.efficiency = it }
            val spo2 = row.optIntOrNull("avgSpo2")
            if (spo2 != null && spo2 in 50..100 && end >= d.spo2End) { d.spo2 = spo2; d.spo2End = end }
            val resp = row.optDoubleOrNull("avgResp")
            if (resp != null && resp in 4.0..60.0 && end >= d.respEnd) { d.resp = resp; d.respEnd = end }
        }

        // Average HR measured inside the selected main-sleep window (computed by ProtocolBridge, >= 10 samples).
        val sleepHrRows = payload.optJSONArray("sleepHr") ?: JSONArray()
        for (i in 0 until sleepHrRows.length()) {
            val row = sleepHrRows.optJSONObject(i) ?: continue
            val date = row.optString("day")
            val value = row.optDoubleOrNull("avg")
            val count = row.optInt("n", 0)
            if (date.length == 10 && value != null && count >= 10) {
                val v = jsRound(value)
                if (v in 25..120) days.getOrPut(date) { DayData() }.sleepHr = v
            }
        }

        // HRV: one number per wake date, from the reading that ended last (legacy hwHrvPlan), rounded, range 5..250.
        val hrvRows = payload.optJSONArray("hrv") ?: JSONArray()
        val hrvEnd = HashMap<String, Long>()
        for (i in 0 until hrvRows.length()) {
            val row = hrvRows.optJSONObject(i) ?: continue
            val start = row.optLong("start", 0L)
            val end = row.optLong("end", 0L)
            val value = row.optDouble("rmssd", 0.0)
            if (end <= 0 || value <= 0.0 || (start > 0 && end <= start)) continue
            val v = jsRound(value)
            if (v !in 5..250) continue
            val date = Instant.ofEpochSecond(end).atZone(zone).toLocalDate().toString()
            if ((hrvEnd[date] ?: 0L) <= end) { hrvEnd[date] = end; days.getOrPut(date) { DayData() }.hrv = v }
        }

        return days.toSortedMap().map { (date, watch) ->
            val old = oldByDate[date]
            val raw = runCatching { JSONObject(old?.raw ?: "{}") }.getOrElse { JSONObject() }
            val night = watch.night
            val nap = watch.nap

            val sleepWatchOwned = raw.optString("huaweiSleepSource") == "watch-sync" || raw.optString("source") == "huawei-watch"
            val manualSleep = !sleepWatchOwned && (old?.sleepH != null || raw.has("sleep"))
            var sleepH = old?.sleepH

            if (night != null && !manualSleep) {
                // Rewrite the whole night together so no stale field of a previous sync survives.
                listOf("bed", "wake", "deep", "rem", "light", "wks", "ext", "lat", "wkN", "huaweiWakeSource").forEach { raw.remove(it) }
                if (sleepWatchOwned) { raw.remove("wkAt"); raw.remove("reAt") } // older native builds stored the wake-up time in wkAt
                raw.put("bed", night.bed).put("wake", night.wake)
                if (night.hasStages) {
                    if (night.deep > 0) raw.put("deep", night.deep)
                    if (night.rem > 0) raw.put("rem", night.rem)
                    if (night.light + night.unknown > 0) raw.put("light", night.light + night.unknown)
                }
                if (night.wakes.isNotEmpty()) {
                    val rows = JSONArray()
                    night.wakes.forEach { rows.put(JSONObject().put("a", it.a).put("b", it.b).put("m", it.min).put("g", if (it.gap) 1 else 0)) }
                    raw.put("wks", rows)
                }
                if (night.extras.isNotEmpty()) {
                    val rows = JSONArray()
                    night.extras.forEach { rows.put(JSONObject().put("a", it.a).put("b", it.b).put("m", it.min).put("p", it.pos)) }
                    raw.put("ext", rows)
                }
                if (night.latencyMin > 0) raw.put("lat", night.latencyMin)
                if (night.awakeCount > 0) raw.put("wkN", minOf(night.awakeCount, 20)).put("huaweiWakeSource", "watch-sync")
                // "Asleep again" sessions count toward the night's total sleep (legacy: round((asleep + extra) / 6) / 10).
                val hours = Math.round((night.totalMinutes) / 6.0) / 10.0
                raw.put("sleep", hours)
                raw.put("source", "huawei-watch").put("huaweiSleepSource", "watch-sync")
                sleepH = hours
            }
            if (nap != null && (!raw.has("nap") || raw.optString("huaweiNapSource") == "watch-sync" || sleepWatchOwned)) {
                raw.remove("naps"); raw.remove("napAt")
                raw.put("nap", minOf(nap.minutes, 300)) // readiness counts at most 180 min of it
                val rows = JSONArray()
                nap.list.forEach { rows.put(JSONObject().put("a", it.a).put("b", it.b).put("m", it.min)) }
                if (rows.length() > 0) { raw.put("naps", rows); raw.put("napAt", nap.list.first().a) }
                raw.put("huaweiNapSource", "watch-sync")
            }

            // Sensor values: fill empty fields, refresh values the watch wrote earlier, never touch manual ones.
            fun owned(key: String) = raw.optString("huaweiHr_$key") == "watch-sync"
            var rhr = old?.rhr
            watch.rhr?.let { v -> if (rhr == null || owned("rhr")) { rhr = v; raw.put("huaweiHr_rhr", "watch-sync") } }
            var hrv = old?.hrv
            watch.hrv?.let { v -> if (hrv == null || owned("hrv")) { hrv = v; raw.put("huaweiHr_hrv", "watch-sync") } }
            watch.sleepHr?.let { v ->
                if (!raw.has("shr") || owned("shr")) { raw.put("shr", v).put("huaweiHr_shr", "watch-sync") }
            }
            watch.spo2?.let { if (!raw.has("ssp") || owned("ssp")) { raw.put("ssp", it).put("huaweiHr_ssp", "watch-sync") } }
            watch.resp?.let { if (!raw.has("srr") || owned("srr")) { raw.put("srr", it).put("huaweiHr_srr", "watch-sync") } }

            // Raw watch snapshot for the detail screens.
            raw.put("watch", JSONObject().apply {
                put("source", "huawei-watch")
                put("syncedAt", System.currentTimeMillis())
                watch.rhr?.let { put("rhr", it) }
                watch.hrv?.let { put("hrv", it) }
                watch.sleepHr?.let { put("sleepHr", it) }
                night?.let {
                    put("deep", it.deep); put("rem", it.rem); put("light", it.light); put("awake", it.awake)
                    put("asleepMin", it.sleepMinutes); put("extraMin", it.extraMinutes); put("gapMin", it.gapMinutes)
                }
                put("nap", nap?.minutes ?: 0)
                put("sleepScore", watch.sleepScore ?: JSONObject.NULL)
                put("sleepEfficiency", watch.efficiency ?: JSONObject.NULL)
                put("sleepSpo2", watch.spo2 ?: JSONObject.NULL)
                put("sleepResp", watch.resp ?: JSONObject.NULL)
            })
            DailyEntity(dateIso = date, rhr = rhr, hrv = hrv, leg = old?.leg, mood = old?.mood, sleepH = sleepH, raw = raw.toString())
        }
    }

    private class DayData {
        var rhr: Int? = null
        var hrv: Int? = null
        var sleepHr: Int? = null
        var night: HuaweiSleepParity.Night? = null
        var nap: HuaweiSleepParity.Nap? = null
        var sleepScore: Int? = null
        var efficiency: Int? = null
        var spo2: Int? = null
        var spo2End = 0L
        var resp: Double? = null
        var respEnd = 0L
    }

    private fun JSONObject.optIntOrNull(key: String): Int? =
        if (!has(key) || isNull(key)) null else runCatching { getInt(key) }.getOrNull()

    private fun JSONObject.optDoubleOrNull(key: String): Double? =
        if (!has(key) || isNull(key)) null else runCatching { getDouble(key) }.getOrNull()
}
