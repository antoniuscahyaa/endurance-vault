package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.i18n.Text
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsBike
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Satellite
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Terrain
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.endurancevault.app.data.MapStyle
import com.endurancevault.app.domain.CourseStrategy.Pt
import com.endurancevault.app.domain.ExploreGeo
import com.endurancevault.app.domain.Js
import com.endurancevault.app.domain.RouteDraft
import com.endurancevault.app.domain.RouteGeo
import com.endurancevault.app.ui.ExploreController
import com.endurancevault.app.ui.theme.Ember
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

internal fun exHm(minutes: Double): String {
    val m = minutes.roundToInt()
    return "${m / 60}:${(m % 60).toString().padStart(2, '0')}"
}

/**
 * Dock Explore (gaya COROS): peta layar penuh dengan alat Lari / Sepeda / Manual / Lokasi, penanda waypoint biru dan
 * lokasi tersimpan oranye, hapus bagian akhir, tiga mode peta (default, satelit, topografi), dan kartu ringkasan rute
 * (jarak, naik, turun, estimasi waktu dari performa lari terakhir, profil elevasi).
 */
@Composable
internal fun ExploreScreen(
    ctl: ExploreController,
    initialCenter: RouteGeo.LatLon,
    estimateMin: (List<Pt>) -> Double?,
    onOpenCollection: () -> Unit,
) {
    val draft by ctl.draft.collectAsState()
    val busy by ctl.busy.collectAsState()
    val elevBusy by ctl.elevationBusy.collectAsState()
    val message by ctl.message.collectAsState()
    val style by ctl.mapStyle.collectAsState()
    val places by ctl.places.collectAsState()
    val editingId by ctl.editingId.collectAsState()
    val routes by ctl.routes.collectAsState()
    val scope = rememberCoroutineScope()

    var view by remember { mutableStateOf(ctl.lastView ?: exViewAt(initialCenter, 14.0)) }
    SideEffect { ctl.lastView = view }
    // Rute yang baru dibuka untuk disunting: peta menyesuaikan ke rute itu sekali saat layar dibuka.
    var fit by remember {
        mutableStateOf(
            if (ctl.lastView == null && ctl.draft.value.pts.size > 1) ExFit(1, ctl.draft.value.pts.map { RouteGeo.LatLon(it.lat, it.lon) }) else null,
        )
    }

    var tool by remember { mutableStateOf("route") } // route | place
    var layersOpen by remember { mutableStateOf(false) }
    var eraseOpen by remember { mutableStateOf(false) }
    var eraseKeep by remember { mutableStateOf(1f) }
    var saveDialog by remember { mutableStateOf(false) }
    var placeDialog by remember { mutableStateOf<RouteGeo.LatLon?>(null) }
    var searchDialog by remember { mutableStateOf(false) }
    var me by remember { mutableStateOf<RouteGeo.LatLon?>(null) }

    LaunchedEffect(message) {
        if (message != null) { delay(4500); ctl.consumeMessage() }
    }
    LaunchedEffect(draft.anchors.size) { if (draft.anchors.size < 2) eraseOpen = false }

    fun goToMe() {
        val p = ctl.lastKnownLocation()
        if (p != null) { me = p; view = exViewAt(p, 16.0) } else ctl.message.value = "Lokasi belum tersedia. Aktifkan GPS lalu coba lagi."
    }
    val locationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants.values.any { it }) goToMe() else ctl.message.value = "Izin lokasi belum diberikan."
    }

    val eraseFromIdx = if (eraseOpen) ExploreGeo.indexAt(draft.pts, draft.meters * eraseKeep) else null

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Explore", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            ExRoundButton(Icons.Filled.Search, "Cari tempat", filled = true) { searchDialog = true }
            Spacer(Modifier.width(8.dp))
            Row(
                Modifier.height(44.dp).clip(RoundedCornerShape(22.dp)).background(MaterialTheme.colorScheme.surfaceVariant)
                    .clickable(role = Role.Button, onClickLabel = "Buka Koleksiku", onClick = onOpenCollection).padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Icon(Icons.Filled.BookmarkBorder, null, tint = Ember, modifier = Modifier.size(18.dp))
                Text("Koleksiku", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Medium)
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            ExploreMapCanvas(
                view = view, onView = { view = it }, style = style,
                routePts = draft.pts, anchors = draft.anchors, places = places,
                eraseFromIdx = eraseFromIdx, myLocation = me, fit = fit,
                onTap = { at ->
                    when {
                        eraseOpen -> Unit
                        tool == "place" -> placeDialog = at
                        else -> ctl.tapMap(at)
                    }
                },
            )

            // Rail alat kiri atas
            Surface(
                Modifier.align(Alignment.TopStart).padding(12.dp), shape = RoundedCornerShape(28.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.96f), border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant),
            ) {
                Column(Modifier.padding(4.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    ExTool(Icons.Filled.DirectionsRun, "Lari", tool == "route" && draft.mode == "run") { tool = "route"; ctl.setMode("run") }
                    ExTool(Icons.Filled.DirectionsBike, "Sepeda", tool == "route" && draft.mode == "ride") { tool = "route"; ctl.setMode("ride") }
                    ExTool(Icons.Filled.Edit, "Manual", tool == "route" && draft.mode == "manual") { tool = "route"; ctl.setMode("manual") }
                    ExTool(Icons.Filled.Place, "Lokasi", tool == "place") { tool = "place" }
                }
            }

            // Kanan atas: lapisan peta, lokasi saya, hapus bagian
            Column(Modifier.align(Alignment.TopEnd).padding(12.dp), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ExRoundButton(Icons.Filled.Layers, "Lapisan peta", selected = layersOpen) { layersOpen = !layersOpen }
                if (layersOpen) {
                    Surface(
                        shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.97f),
                        border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant),
                    ) {
                        Column(Modifier.padding(vertical = 4.dp)) {
                            ExLayerRow(Icons.Filled.Map, "Default", style == MapStyle.DEFAULT) { ctl.setStyle(MapStyle.DEFAULT); layersOpen = false }
                            ExLayerRow(Icons.Filled.Satellite, "Satelit", style == MapStyle.SATELLITE) { ctl.setStyle(MapStyle.SATELLITE); layersOpen = false }
                            ExLayerRow(Icons.Filled.Terrain, "Topografi", style == MapStyle.TOPO) { ctl.setStyle(MapStyle.TOPO); layersOpen = false }
                        }
                    }
                }
                ExRoundButton(Icons.Filled.MyLocation, "Ke lokasi saya") {
                    if (ctl.hasLocationPermission()) goToMe()
                    else locationLauncher.launch(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION))
                }
                if (draft.anchors.size >= 2) {
                    ExRoundButton(Icons.Filled.Delete, "Hapus bagian akhir rute", selected = eraseOpen) { eraseOpen = !eraseOpen; eraseKeep = 1f }
                }
            }

            if (busy) LinearProgressIndicator(Modifier.align(Alignment.TopCenter).fillMaxWidth().height(3.dp))

            message?.let { msg ->
                Surface(
                    Modifier.align(Alignment.TopCenter).padding(top = 12.dp, start = 80.dp, end = 80.dp), shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.inverseSurface,
                ) {
                    Text(msg, Modifier.padding(horizontal = 12.dp, vertical = 8.dp), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.inverseOnSurface)
                }
            }

            // Kartu bawah
            Surface(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(8.dp), shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surfaceVariant, border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant),
            ) {
                Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    val modeLabel = when (draft.mode) { "ride" -> "Sepeda · mengikuti jalan"; "manual" -> "Manual · garis lurus"; else -> "Lari · mengikuti jalur" }
                    val title = if (editingId != null) "Sunting rute" else "Rute baru"
                    if (draft.isEmpty) {
                        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            if (tool == "place") "Ketuk peta untuk menyimpan lokasi (misalnya titik air atau parkir)."
                            else "Ketuk peta untuk menaruh titik awal, lalu ketuk lagi untuk menambah jalur. $modeLabel.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        if (routes.isNotEmpty() || places.isNotEmpty()) {
                            Text("${routes.size} rute · ${places.size} lokasi di Koleksiku", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    } else {
                        Column {
                            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("$modeLabel · ${draft.anchors.size} titik", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        val st = draft.stats
                        val est = remember(draft) { if (draft.pts.size >= 2) estimateMin(draft.pts) else null }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ExStat("Jarak", "${Js.fmtKm(draft.meters / 1000.0)}", "km", Modifier.weight(1f))
                            ExStat("Naik", if (st.hasEle) Js.idn(st.up) else "–", "m", Modifier.weight(1f))
                            ExStat("Turun", if (st.hasEle) Js.idn(st.down) else "–", "m", Modifier.weight(1f))
                            ExStat("Est. waktu", if (est != null) exHm(est) else "–", "", Modifier.weight(1f))
                        }
                        if (st.prof.size >= 2) ExElevChart(st.prof, Modifier.fillMaxWidth().height(52.dp))
                        else Text(
                            if (elevBusy) "Mengambil elevasi…" else "Elevasi muncul setelah jalur terbentuk (butuh internet).",
                            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        if (eraseOpen) {
                            val keepKm = draft.meters * eraseKeep / 1000.0
                            Text(
                                "Hapus bagian akhir rute: sisa ${Js.fmtKm(keepKm)} km dari ${Js.fmtKm(draft.meters / 1000.0)} km (bagian merah dihapus)",
                                style = MaterialTheme.typography.labelMedium,
                            )
                            Slider(value = eraseKeep, onValueChange = { eraseKeep = it }, valueRange = 0.05f..1f)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                TextButton(onClick = { eraseOpen = false; eraseKeep = 1f }, modifier = Modifier.height(48.dp)) { Text("Batal") }
                                Button(
                                    onClick = { ctl.keepFraction(eraseKeep.toDouble()); eraseOpen = false; eraseKeep = 1f },
                                    enabled = eraseKeep < 0.995f, modifier = Modifier.weight(1f).height(48.dp),
                                ) { Text("Hapus bagian merah") }
                            }
                        } else {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                FilledTonalButton(onClick = { ctl.undo() }, modifier = Modifier.height(48.dp)) {
                                    Icon(Icons.AutoMirrored.Filled.Undo, null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Urungkan")
                                }
                                Button(onClick = { saveDialog = true }, enabled = draft.legs.isNotEmpty(), modifier = Modifier.weight(1f).height(48.dp)) {
                                    Text("Selesai & simpan", fontWeight = FontWeight.Bold)
                                }
                            }
                            TextButton(onClick = { ctl.clearDraft() }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("Bersihkan peta", style = MaterialTheme.typography.labelMedium) }
                        }
                    }
                }
            }
        }
    }

    if (saveDialog) {
        var name by remember { mutableStateOf(routes.firstOrNull { it.id == editingId }?.name ?: "Rute ${java.time.LocalDate.now()}") }
        AlertDialog(
            onDismissRequest = { saveDialog = false },
            title = { Text("Simpan rute") },
            text = { OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nama rute") }, singleLine = true) },
            confirmButton = { TextButton(onClick = { if (ctl.saveDraft(name)) saveDialog = false }) { Text("Simpan") } },
            dismissButton = { TextButton(onClick = { saveDialog = false }) { Text("Batal") } },
        )
    }
    placeDialog?.let { at ->
        var name by remember(at) { mutableStateOf("Lokasi ${places.size + 1}") }
        AlertDialog(
            onDismissRequest = { placeDialog = null },
            title = { Text("Simpan lokasi") },
            text = { OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nama lokasi") }, singleLine = true) },
            confirmButton = { TextButton(onClick = { ctl.addPlace(name, at); placeDialog = null }) { Text("Simpan") } },
            dismissButton = { TextButton(onClick = { placeDialog = null }) { Text("Batal") } },
        )
    }
    if (searchDialog) {
        var q by remember { mutableStateOf("") }
        val go = {
            val query = q
            searchDialog = false
            scope.launch {
                val r = ctl.search(query)
                if (r != null) { view = exViewAt(r.first, 13.0); ctl.message.value = r.second } else ctl.message.value = "Tempat tidak ditemukan (atau offline)."
            }
            Unit
        }
        AlertDialog(
            onDismissRequest = { searchDialog = false },
            title = { Text("Cari tempat") },
            text = { OutlinedTextField(value = q, onValueChange = { q = it }, label = { Text("Kota, desa, atau gunung") }, singleLine = true) },
            confirmButton = { TextButton(onClick = { go() }, enabled = q.isNotBlank()) { Text("Cari") } },
            dismissButton = { TextButton(onClick = { searchDialog = false }) { Text("Batal") } },
        )
    }
}

@Composable
internal fun ExStat(label: String, value: String, unit: String, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(verticalAlignment = Alignment.Bottom) {
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (unit.isNotEmpty()) Text(" $unit", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 2.dp))
        }
    }
}

@Composable
private fun ExTool(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    val fg = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
    Column(
        Modifier.width(52.dp).height(56.dp).clip(RoundedCornerShape(24.dp))
            .background(if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
    ) {
        Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(22.dp))
        Text(label, fontSize = 10.sp, color = fg, fontWeight = FontWeight.Medium)
    }
}

@Composable
internal fun ExRoundButton(icon: ImageVector, desc: String, selected: Boolean = false, filled: Boolean = false, onClick: () -> Unit) {
    val line = MaterialTheme.colorScheme.outlineVariant
    Box(
        Modifier.size(44.dp).clip(CircleShape)
            .background(if (selected) MaterialTheme.colorScheme.primaryContainer else if (filled) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface.copy(alpha = 0.96f))
            .then(if (filled) Modifier else Modifier.border(0.8.dp, line, CircleShape))
            .clickable(onClickLabel = desc, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = desc, modifier = Modifier.size(22.dp), tint = if (selected) Ember else MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun ExLayerRow(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.width(140.dp).height(44.dp).selectable(selected = selected, role = Role.RadioButton, onClick = onClick).padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Icon(icon, null, modifier = Modifier.size(20.dp), tint = if (selected) Ember else MaterialTheme.colorScheme.onSurfaceVariant)
        Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium)
    }
}

/** Profil elevasi (km, elevasi) berisi area oranye transparan dan garis. */
@Composable
internal fun ExElevChart(prof: List<DoubleArray>, modifier: Modifier = Modifier) {
    if (prof.size < 2) return
    Canvas(modifier) {
        val w = size.width; val h = size.height
        var lo = Double.MAX_VALUE; var hi = -Double.MAX_VALUE
        prof.forEach { lo = min(lo, it[1]); hi = max(hi, it[1]) }
        val rg = if (hi - lo > 1.0) hi - lo else 1.0
        val pk = prof.last()[0].let { if (it > 0) it else 1.0 }
        fun x(k: Double) = (k / pk * w).toFloat()
        fun y(e: Double) = (h - 4.dp.toPx() - (e - lo) / rg * (h - 8.dp.toPx())).toFloat()
        val fill = Path(); fill.moveTo(0f, h)
        prof.forEach { fill.lineTo(x(it[0]), y(it[1])) }
        fill.lineTo(w, h); fill.close()
        drawPath(fill, Ember.copy(alpha = 0.22f))
        val ln = Path(); prof.forEachIndexed { i, q -> if (i == 0) ln.moveTo(x(q[0]), y(q[1])) else ln.lineTo(x(q[0]), y(q[1])) }
        drawPath(ln, Ember, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}
