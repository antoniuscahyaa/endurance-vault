package com.endurancevault.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.endurancevault.app.EnduranceVaultApp
import com.endurancevault.app.data.ExploreElevation
import com.endurancevault.app.data.ExploreRouting
import com.endurancevault.app.data.ExploreStore
import com.endurancevault.app.data.KvEntity
import com.endurancevault.app.data.MapStyle
import com.endurancevault.app.domain.CourseStrategy.Pt
import com.endurancevault.app.domain.ExPlace
import com.endurancevault.app.domain.ExRoute
import com.endurancevault.app.domain.ExploreGeo
import com.endurancevault.app.domain.ExploreGpx
import com.endurancevault.app.domain.GpxRoute
import com.endurancevault.app.domain.RouteDraft
import com.endurancevault.app.domain.RouteGeo
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * Logika dock Explore: menggambar rute (tap titik, tempel ke jalur, urungkan, hapus bagian akhir), elevasi,
 * penyimpanan rute dan lokasi di Koleksiku, impor/ekspor GPX, dan pencarian tempat.
 * Hidup selama ViewModel; keadaan tampilan peta ([lastView]) dipertahankan saat pindah dock.
 */
class ExploreController(private val app: EnduranceVaultApp, private val scope: CoroutineScope) {
    private val dao get() = app.db.companion()
    private val prefs = app.getSharedPreferences("explore_prefs", Context.MODE_PRIVATE)

    val draft = MutableStateFlow(RouteDraft.empty("run"))
    val busy = MutableStateFlow(false)
    val elevationBusy = MutableStateFlow(false)
    val message = MutableStateFlow<String?>(null)

    /** Id rute di Koleksiku yang sedang disunting (null = rute baru). */
    val editingId = MutableStateFlow<String?>(null)

    val mapStyle = MutableStateFlow(runCatching { MapStyle.valueOf(prefs.getString("style", "DEFAULT") ?: "DEFAULT") }.getOrDefault(MapStyle.DEFAULT))

    /** Posisi peta terakhir (selama aplikasi hidup), agar kembali ke dock Explore tidak mereset tampilan. */
    var lastView: RouteGeo.View? = null

    val routes: StateFlow<List<ExRoute>> = dao.observeKv(ExploreStore.ROUTES_KEY)
        .map { ExploreStore.parseRoutes(it?.json) }.flowOn(Dispatchers.Default)
        .stateIn(scope, SharingStarted.Eagerly, emptyList())

    val places: StateFlow<List<ExPlace>> = dao.observeKv(ExploreStore.PLACES_KEY)
        .map { ExploreStore.parsePlaces(it?.json) }.flowOn(Dispatchers.Default)
        .stateIn(scope, SharingStarted.Eagerly, emptyList())

    private val legLock = Mutex()
    private val storeLock = Mutex()
    private var elevJob: Job? = null

    fun setStyle(s: MapStyle) { mapStyle.value = s; prefs.edit().putString("style", s.name).apply() }

    fun setMode(m: String) { draft.update { it.withMode(m) } }

    fun consumeMessage() { message.value = null }

    // ---------------------------------------------------------------- menggambar

    /** Ketuk peta saat alat rute aktif: titik pertama menaruh awal; berikutnya menambah ruas dari titik terakhir. */
    fun tapMap(at: RouteGeo.LatLon) {
        scope.launch {
            legLock.withLock {
                val d = draft.value
                if (d.isEmpty) { draft.value = d.addFirst(at); return@withLock }
                val from = d.anchors.last()
                busy.value = true
                val leg: List<Pt> = if (d.mode == "manual") {
                    ExploreGeo.straight(from, at)
                } else {
                    ExploreRouting.leg(d.mode, from, at) ?: run {
                        message.value = "Jalur tidak ditemukan atau sedang offline, ruas ini memakai garis lurus."
                        ExploreGeo.straight(from, at)
                    }
                }
                busy.value = false
                // jika pengguna menekan Urungkan/Bersihkan selama menunggu, ruas ini dibuang
                draft.update { cur -> if (cur.anchors.size == d.anchors.size) cur.addLeg(leg) else cur }
            }
            scheduleElevation()
        }
    }

    fun undo() {
        draft.update { it.undo() }
        scheduleElevation()
    }

    fun clearDraft() { draft.value = RouteDraft.empty(draft.value.mode); editingId.value = null }

    /** Hapus bagian akhir rute: pertahankan [keepFraction] (0..1) jarak pertama. */
    fun keepFraction(keepFraction: Double) {
        draft.update { it.keepFirst(it.meters * keepFraction.coerceIn(0.0, 1.0)) }
        scheduleElevation()
    }

    private fun scheduleElevation() {
        elevJob?.cancel()
        elevJob = scope.launch {
            delay(700)
            val d = draft.value
            if (d.pts.size < 2) return@launch
            elevationBusy.value = true
            val ele = ExploreElevation.fetch(d.pts)
            elevationBusy.value = false
            if (ele == null) { message.value = "Elevasi belum tersedia (offline). Jalur tetap bisa disimpan."; return@launch }
            draft.update { cur -> if (cur.pts.size == d.pts.size) cur.withElevations(ele) else cur }
        }
    }

    // ---------------------------------------------------------------- Koleksiku

    private suspend fun updateRoutes(f: (List<ExRoute>) -> List<ExRoute>) = withContext(Dispatchers.IO) {
        storeLock.withLock {
            val cur = ExploreStore.parseRoutes(dao.kv(ExploreStore.ROUTES_KEY))
            dao.putKv(listOf(KvEntity(ExploreStore.ROUTES_KEY, ExploreStore.routesToJson(f(cur)))))
        }
    }

    private suspend fun updatePlaces(f: (List<ExPlace>) -> List<ExPlace>) = withContext(Dispatchers.IO) {
        storeLock.withLock {
            val cur = ExploreStore.parsePlaces(dao.kv(ExploreStore.PLACES_KEY))
            dao.putKv(listOf(KvEntity(ExploreStore.PLACES_KEY, ExploreStore.placesToJson(f(cur)))))
        }
    }

    private fun newId() = java.lang.Long.toString(System.currentTimeMillis(), 36) + java.lang.Integer.toString((Math.random() * 1296).toInt(), 36)

    /** Simpan rute yang sedang digambar. Bila sedang menyunting rute lama, rute itu diganti (id dan tanggal dibuat dipertahankan). */
    fun saveDraft(name: String): Boolean {
        val d = draft.value
        val old = editingId.value?.let { id -> routes.value.firstOrNull { it.id == id } }
        val cleanName = name.trim().ifEmpty { "Rute baru" }
        val r = d.toRoute(old?.id ?: newId(), cleanName, old?.source ?: "app", old?.createdMs ?: System.currentTimeMillis()) ?: return false
        scope.launch { updateRoutes { cur -> listOf(r) + cur.filter { it.id != r.id } } }
        draft.value = RouteDraft.empty(d.mode)
        editingId.value = null
        message.value = "\"$cleanName\" tersimpan di Koleksiku."
        return true
    }

    fun loadForEdit(id: String): Boolean {
        val r = routes.value.firstOrNull { it.id == id } ?: return false
        draft.value = r.toDraft()
        editingId.value = r.id
        lastView = null
        return true
    }

    fun deleteRoute(id: String) { scope.launch { updateRoutes { cur -> cur.filter { it.id != id } } } }

    fun renameRoute(id: String, name: String) {
        val n = name.trim().ifEmpty { return }
        scope.launch { updateRoutes { cur -> cur.map { if (it.id == id) ExRoute(it.id, n, it.mode, it.source, it.createdMs, it.pts, it.anchorIdx) else it } } }
    }

    fun addPlace(name: String, at: RouteGeo.LatLon) {
        val p = ExPlace(newId(), name.trim().ifEmpty { "Lokasi" }, at.lat, at.lon)
        scope.launch { updatePlaces { cur -> cur + p } }
        message.value = "Lokasi \"${p.name}\" disimpan."
    }

    fun deletePlace(id: String) { scope.launch { updatePlaces { cur -> cur.filter { it.id != id } } } }

    fun renamePlace(id: String, name: String) {
        val n = name.trim().ifEmpty { return }
        scope.launch { updatePlaces { cur -> cur.map { if (it.id == id) it.copy(name = n) else it } } }
    }

    /** Impor berkas GPX ke Koleksiku (tanpa mengirim ke jam). */
    fun importGpx(uri: Uri) {
        scope.launch {
            try {
                val r = withContext(Dispatchers.IO) {
                    val xml = app.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: throw IllegalStateException("Berkas tidak dapat dibuka")
                    val fileName = app.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                        if (c.moveToFirst()) c.getString(0) else null
                    } ?: uri.lastPathSegment ?: "Rute"
                    val (pts, gname) = GpxRoute.parsePoints(xml)
                    if (pts.size < 2) throw IllegalStateException("GPX tidak berisi jalur (minimal 2 titik)")
                    val thin = if (pts.size <= 4000) pts else {
                        val stride = pts.size / 4000 + 1
                        pts.filterIndexed { i, _ -> i % stride == 0 || i == pts.lastIndex }
                    }
                    val name = gname.ifEmpty { fileName.replace(Regex("\\.[^.]+$"), "").ifEmpty { "Rute" } }
                    ExRoute(newId(), name, "run", "gpx", System.currentTimeMillis(), thin, listOf(0, thin.lastIndex))
                }
                updateRoutes { cur -> listOf(r) + cur }
                message.value = "\"${r.name}\" diimpor ke Koleksiku."
            } catch (e: Exception) {
                message.value = "Impor GPX gagal: ${e.message ?: e.javaClass.simpleName}"
            }
        }
    }

    /** Bagikan rute sebagai berkas GPX lewat lembar berbagi sistem. */
    fun shareGpx(route: ExRoute) {
        scope.launch {
            try {
                val uri = withContext(Dispatchers.IO) {
                    val dir = File(app.cacheDir, "gpx").apply { mkdirs() }
                    dir.listFiles()?.filter { it.lastModified() < System.currentTimeMillis() - 24 * 3600_000L }?.forEach { it.delete() }
                    val f = File(dir, ExploreGpx.fileName(route.name))
                    f.writeText(ExploreGpx.build(route, places.value.filter { nearRoute(it, route) }))
                    FileProvider.getUriForFile(app, "${app.packageName}.fileprovider", f)
                }
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "application/gpx+xml"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                app.startActivity(Intent.createChooser(send, "Ekspor GPX").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                message.value = "Ekspor GPX gagal: ${e.message ?: e.javaClass.simpleName}"
            }
        }
    }

    /** Lokasi tersimpan ikut diekspor bila berada dalam ±150 m dari rute. */
    private fun nearRoute(p: ExPlace, r: ExRoute): Boolean {
        val q = Pt(p.lat, p.lon, null)
        return r.pts.any { ExploreGeo.dist(it, q) < 150.0 }
    }

    // ---------------------------------------------------------------- lokasi dan pencarian

    fun hasLocationPermission(): Boolean =
        ContextCompat.checkSelfPermission(app, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(app, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** Lokasi terakhir yang diketahui perangkat (tanpa memicu GPS baru); null bila izin/lokasi tidak tersedia. */
    @Suppress("MissingPermission")
    fun lastKnownLocation(): RouteGeo.LatLon? {
        if (!hasLocationPermission()) return null
        return try {
            val lm = app.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val loc = lm.getProviders(true).mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }.maxByOrNull { it.time }
            loc?.let { RouteGeo.LatLon(it.latitude, it.longitude) }
        } catch (_: Exception) { null }
    }

    /** Cari tempat (kota, desa, gunung) lewat geocoding Open-Meteo; null bila tidak ketemu atau offline. */
    suspend fun search(query: String): Pair<RouteGeo.LatLon, String>? = withContext(Dispatchers.IO) {
        val q = query.trim()
        if (q.isEmpty()) return@withContext null
        var c: HttpURLConnection? = null
        try {
            c = URL("https://geocoding-api.open-meteo.com/v1/search?count=1&language=id&name=" + java.net.URLEncoder.encode(q, "UTF-8")).openConnection() as HttpURLConnection
            c.connectTimeout = 8000; c.readTimeout = 10000
            val x = JSONObject(c.inputStream.bufferedReader().use { it.readText() }).optJSONArray("results")?.optJSONObject(0) ?: return@withContext null
            val label = listOf(x.optString("name"), x.optString("admin1")).filter { it.isNotBlank() }.joinToString(", ")
            RouteGeo.LatLon(x.getDouble("latitude"), x.getDouble("longitude")) to label
        } catch (_: Exception) { null } finally { c?.disconnect() }
    }
}
