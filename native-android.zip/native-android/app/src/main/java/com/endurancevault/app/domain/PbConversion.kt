package com.endurancevault.app.domain

import java.time.LocalDate
import kotlin.math.max
import kotlin.math.min

/**
 * Port 24d-transisi-pb-lomba.js: tombol "Ada lomba?" (Got a race?) mengubah rencana Performance Build menjadi rencana lomba
 * tanpa mulai dari nol. Minggu PB yang sudah berjalan (pbConv.wk) dihitung sebagai base; Km awal diambil dari minggu PB berjalan.
 */
object PbConversion {
    /** Jenis lomba yang boleh dipilih dari PB. */
    val RACE_TYPES = listOf("5k", "10k", "hm", "fm", "ultra", "ultrar")

    /** Km puncak bawaan per jenis lomba (RCFG.peak di web). */
    fun defaultPeak(rt: String): Int = when (rt) {
        "5k" -> 45; "10k" -> 55; "hm" -> 65; "fm" -> 85; "ultra", "ultrar" -> 75; else -> 60
    }

    fun defaultKm(rt: String): Double = RCFG[rt]?.km ?: 0.0

    /** Jumlah minggu PB yang sudah berjalan sejak tanggal mulai (pbConvWk). */
    fun weeksRun(start: LocalDate, today: LocalDate): Int =
        max(0, Math.floorDiv(Js.diffDays(Js.mondayOf(today), Js.mondayOf(start)), 7))

    /** Km awal rencana lomba dari minggu PB ke-wk; minggu pemulihan dinaikkan kembali ke 100% (pbConvBase). */
    fun baseKm(weeks: List<PWeek>?, wk: Int, fallback: Double): Int {
        val w = weeks?.getOrNull(wk)
        val b = if (w != null && w.km > 0) (if (w.cut) w.km / .8 else w.km) else fallback
        val r = if (b.isNaN()) 0 else Js.roundI(b)
        return min(200, max(10, if (r == 0) 10 else r))
    }

    class State(val wk: Int, val base: Int)

    /** pbConvState: memakai plan mentah (bukan yang sudah disesuaikan) sebagai patokan volume. */
    fun state(s: PlanSettings, today: LocalDate = LocalDate.now()): State {
        val wk = weeksRun(s.start, today)
        val raw = runCatching { PlanEngine.plan(s, today) }.getOrNull() as? PlanOutcome.Ok
        return State(wk, baseKm(raw?.weeks, wk, s.base))
    }

    class Result(val settings: PlanSettings?, val plan: PlanOutcome.Ok?, val error: String?)

    fun build(
        s: PlanSettings, rtype: String, race: String, goalT: String, name: String,
        raceKm: String, raceGain: String, peak: String, wk: Int, base: Int, today: LocalDate = LocalDate.now(),
    ): Result {
        fun err(m: String) = Result(null, null, m)
        val rc = RCFG[rtype]
        if (rc == null || rtype == "pb" || rtype == "none") return err("Pilih jenis lomba.")
        val raceDate = runCatching { LocalDate.parse(race.trim()) }.getOrNull() ?: return err("Isi tanggal lomba.")
        val goal = goalT.trim()
        if (goal.isNotEmpty() && !(Js.parseDur(goal) > 0)) return err("Target waktu harus berformat j:mm:dd, misalnya 3:45:00.")
        val km = if (rc.trail) raceKm.replace(',', '.').toDoubleOrNull() ?: Double.NaN else rc.km
        if (rc.trail && !(km >= 5 && km <= 200)) return err("Isi jarak lomba antara 5 dan 200 km.")
        val pk = peak.replace(',', '.').toDoubleOrNull()?.let { Js.roundI(it) } ?: 0
        if (!(pk in 10..200)) return err("Km mingguan puncak harus antara 10 dan 200.")
        var n = s.copy(
            rtype = rtype, race = raceDate, goalT = goal, name = name.trim(), raceKm = km,
            base = base.toDouble(), peak = max(pk, base).toDouble(), pbConv = PbConv(wk, s.base, s.peak),
        )
        if (rc.trail) raceGain.replace(',', '.').toDoubleOrNull()?.let { n = n.copy(raceGain = it) }
        return when (val p = PlanEngine.plan(n, today)) {
            is PlanOutcome.Err -> err(p.message)
            is PlanOutcome.Ok -> Result(n, p, null)
        }
    }

    /** pbConvUndo: kembali ke Performance Build dengan Km awal/puncak PB semula. */
    fun undo(s: PlanSettings): PlanSettings? {
        val c = s.pbConv ?: return null
        return s.copy(rtype = "pb", race = null, goalT = "", name = "", base = c.b0, peak = c.p0, pbConv = null)
    }
}
