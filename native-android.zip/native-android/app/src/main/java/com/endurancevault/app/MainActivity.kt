package com.endurancevault.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.endurancevault.app.ui.AppRoot
import com.endurancevault.app.ui.theme.EnduranceVaultTheme
import com.endurancevault.app.ui.theme.ThemePrefs

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemePrefs.load(applicationContext)
        enableEdgeToEdge()
        setContent { EnduranceVaultTheme { AppRoot() } }
    }
}
