package com.endurancevault.app.domain

import java.time.LocalDate
import kotlin.math.*

data class EasyRunResult(
    val activityId: Long, val date: LocalDate, val kind: String, val compliancePct: Double?,
    val score: Int?, val verdict: String, val driftPct: Double?, val stabilityCv: Double?,
    val efficiency: Double?, val efficiencyVsBaselinePct: Double?, val evaluatedMinutes: Double,
    val overLimitMinutes: Double, val legacyHistogramOnly: Boolean,
)

object EasyRunAnalytics {
    private const val BUCKET = 5
    private data class Profile(val tolerance: Int, val band: Int, val pass: Int, val ok: Int)
    private val easy = Profile(4,6,95,85)
    private val long = Profile(8,8,85,80)

    private fun band(hr: Int, limit: Int, p: Profile): Int {
        val excess = hr - (limit + p.tolerance)
        return if (excess <= 0) 0 else 1 + (excess - 1) / p.band
    }
    private fun multiplier(k: Int) = if (k <= 0) 1.0 else min(3.0, 1.0 + .5*k)
    private fun rounded(v: Double) = floor(v + .5 + 1e-9).toInt()
    private fun mean(v: List<Double>) = if (v.isEmpty()) 0.0 else v.average()

    private fun strideStart(d: ActDetail): Int {
        d.easyRun?.let { ez ->
            if (ez.strideDisabled) return 0
            ez.strideStartSec?.takeIf { it > 0 }?.let { return it }
        }
        d.segments.forEach { /* Segment.time is minutes; interval marker 'w' is retained in type. */ }
        return d.strideStartSec?.takeIf { it > 0 } ?: 0
    }

    private fun complyBuckets(hz: List<Int>, limit: Int, p: Profile, from: Int, to: Int, bucketSec: Int): Triple<Double,Double,Double>? {
        var total=0.0; var penalty=0.0; var over=0.0
        var currentBand=0; var currentCount=0
        fun close() { if (currentBand > 0 && currentCount > 0) penalty += rounded(currentCount*bucketSec*multiplier(currentBand)); currentBand=0; currentCount=0 }
        for (i in from.coerceAtLeast(0) until to.coerceAtMost(hz.size)) {
            val hr=hz[i]
            if (hr <= 0) { close(); continue }
            total += bucketSec
            val b=band(hr,limit,p)
            if (b>0) {
                over += bucketSec
                if (currentBand==b) currentCount++ else { close(); currentBand=b; currentCount=1 }
            } else close()
        }
        close()
        return if(total>0) Triple(max(0.0,(total-penalty)/total*100),total,over) else null
    }

    private fun histogram(hist: Map<Int,Double>, limit: Int, p: Profile): Triple<Double,Double,Double>? {
        var total=0.0; var penalty=0.0; var over=0.0
        hist.forEach { (hr,sec) -> if(hr>0&&sec>0) {
            total+=sec; val b=band(hr,limit,p)
            if(b>0){ over+=sec; penalty+=rounded(sec*multiplier(b)) }
        } }
        return if(total>0) Triple(max(0.0,(total-penalty)/total*100),total,over) else null
    }

    private fun drift(hz: List<Int>, vz: List<Int>, from: Int, to: Int, bucketSec: Int): Double? {
        val n=to-from
        if(vz.isEmpty()||n*bucketSec<900) return null
        val start=from+max(1,round(n*.1).toInt()); val mid=start+(to-start)/2
        val a=mutableListOf<Double>(); val b=mutableListOf<Double>()
        for(i in start until to.coerceAtMost(min(hz.size,vz.size))) if(hz[i]>0&&vz[i]>0) {
            (if(i<mid) a else b).add(vz[i].toDouble()/hz[i])
        }
        val minSamples = if (bucketSec == 1) 60 else 12
        if(a.size<minSamples||b.size<minSamples) return null
        val e1=mean(a); return if(e1>0) (e1-mean(b))/e1*100 else null
    }
    private fun stability(vz: List<Int>, from: Int, to: Int, bucketSec: Int): Double? {
        val window = if (bucketSec == 1) 60 else 12
        val minimum = if (bucketSec == 1) 40 else 8
        val chunks=mutableListOf<Double>()
        var i=from
        while(i+window<=to.coerceAtMost(vz.size)) {
            val values=vz.subList(i,i+window).filter { it>0 }
            if(values.size>=minimum) chunks += values.average()
            i+=window
        }
        if(chunks.size<8) return null
        val m=mean(chunks); if(m<=0) return null
        return sqrt(chunks.sumOf { (it-m).pow(2) }/chunks.size)/m*100
    }
    private fun efficiency(hz: List<Int>, vz: List<Int>, from: Int, to: Int, bucketSec: Int): Double? {
        var speed=0.0; var hr=0.0; var n=0
        for(i in from.coerceAtLeast(0) until to.coerceAtMost(min(hz.size,vz.size))) if(hz[i]>0&&vz[i]>0) {
            speed+=vz[i]; hr+=hz[i]; n++
        }
        if(n*bucketSec<600||hr<=0) return null
        return (speed/n/100.0)/(hr/n)*1000
    }
    private fun score(pct: Double?, p: Profile, drift: Double?, cv: Double?, ratio: Double?): Int? {
        val parts=mutableListOf<Pair<Double,Double>>()
        pct?.let { parts += 45.0 to ((it-50)/(p.pass-50)*100).coerceIn(0.0,100.0) }
        drift?.let { d -> parts += 22.0 to when { d<=3 -> 100.0; d<=5 -> 100-(d-3)/2*30; d<=8 -> 70-(d-5)/3*40; else -> (30-(d-8)*10).coerceIn(0.0,100.0) } }
        cv?.let { c -> parts += 17.0 to when { c<=6 -> 100.0; c>=15 -> 0.0; else -> 100-(c-6)/9*100 } }
        ratio?.let { parts += 16.0 to (70+it*6).coerceIn(0.0,100.0) }
        if(parts.isEmpty()) return null
        val raw=round(parts.sumOf { it.first*it.second }/parts.sumOf { it.first }).toInt()
        val verdict=verdict(pct,p)
        return min(raw,when(verdict){"good"->100;"ok"->89;"hard"->69;else->100})
    }
    private fun verdict(pct: Double?, p: Profile) = when { pct==null -> "na"; pct>=p.pass -> "good"; pct>=p.ok -> "ok"; else -> "hard" }

    fun calculate(details: Map<Long,ActDetail>, lthr: Int, config: EasyRunConfig = EasyRunConfig(), baselineDays: Int = 28): List<EasyRunResult> {
        val rows=details.mapNotNull { (id,d) ->
            val mark=d.easyRun ?: return@mapNotNull null
            if(!mark.enabled||d.bike) return@mapNotNull null
            val date=runCatching { LocalDate.parse(d.date) }.getOrNull() ?: return@mapNotNull null
            val kind=if(mark.kind=="long") "long" else "easy"
            val profile=if(kind=="long") Profile(config.longTolerance,config.longBand,config.longPass,config.longOk)
                else Profile(config.easyTolerance,config.easyBand,config.easyPass,config.easyOk)
            val temp=d.weatherTempC
            val heatCut=if(config.heatEnabled && temp!=null && temp>=config.heatThreshold) {
                config.heatCut + floor((temp-config.heatThreshold)/4.0).toInt()
            } else 0
            val limit=lthr-heatCut
            val start=mark.strideStartSec?.takeIf { it>0 } ?: d.strideStartSec ?: 0
            val oneSecond = d.timeSeries != null
            val hz = d.timeSeries?.heartRateBpm ?: d.easyHrBuckets
            val vz = d.timeSeries?.gapSpeedCmPerSec ?: d.easySpeedBuckets
            val bucketSec = if (oneSecond) 1 else BUCKET
            val from=min(hz.size, (config.warm*60/bucketSec))
            val to=if(start>0) min(hz.size,start/bucketSec) else hz.size
            val series=if(hz.size>=24) complyBuckets(hz,limit,profile,from,to,bucketSec) else null
            val legacy=series==null
            val data=series ?: histogram(d.hrHist,limit,profile) ?: return@mapNotNull null
            val pct=data.first
            val drift=if(!legacy) drift(hz,vz,from,to,bucketSec) else null
            val cv=if(!legacy) stability(vz,from,to,bucketSec) else null
            val eff=if(!legacy) efficiency(hz,vz,from,to,bucketSec) else null
            EasyRunResult(id,date,kind,pct,score(pct,profile,drift,cv,null),verdict(pct,profile),drift,cv,eff,null,data.second/60.0,data.third/60.0,legacy)
        }.sortedBy { it.date }
        return rows.mapIndexed { index, row ->
            val baseline=rows.filter { it.kind=="easy" && it.date.isBefore(row.date) && !it.date.isBefore(row.date.minusDays(baselineDays.toLong())) }
                .mapNotNull { it.efficiency }.takeIf { it.size>=3 }?.average()
            val ratio=if(row.efficiency!=null&&baseline!=null&&baseline>0) (row.efficiency/baseline-1)*100 else null
            val profile=if(row.kind=="long") Profile(config.longTolerance,config.longBand,config.longPass,config.longOk)
                else Profile(config.easyTolerance,config.easyBand,config.easyPass,config.easyOk)
            row.copy(efficiencyVsBaselinePct=ratio,score=score(row.compliancePct,profile,row.driftPct,row.stabilityCv,ratio))
        }
    }
}
