package com.endurancevault.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.data.DailyEntity
import com.endurancevault.app.data.GearEntity
import java.time.LocalDate
import java.util.UUID

@Composable
fun CompanionDataSection(
    daily: List<DailyEntity>,
    gear: List<GearEntity>,
    activities: List<ActivityEntity>,
    onSaveDaily: (DailyEntity) -> Unit,
    onSaveGear: (GearEntity) -> Unit,
    onDeleteGear: (String) -> Unit,
) {
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var rhr by remember { mutableStateOf("") }
    var hrv by remember { mutableStateOf("") }
    var leg by remember { mutableStateOf("3") }
    var mood by remember { mutableStateOf("3") }
    var sleep by remember { mutableStateOf("") }
    var dailyError by remember { mutableStateOf<String?>(null) }

    var gearName by remember { mutableStateOf("") }
    var gearModel by remember { mutableStateOf("") }
    var gearStartKm by remember { mutableStateOf("0") }
    var gearLimitKm by remember { mutableStateOf("800") }
    var gearError by remember { mutableStateOf<String?>(null) }

    val full = Modifier.fillMaxWidth()
    val numeric = KeyboardOptions(keyboardType = KeyboardType.Decimal)
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Kondisi harian", style = MaterialTheme.typography.titleLarge)
        Text("Catat tidur, denyut istirahat, HRV, rasa kaki, dan mood. Data ini tersimpan lokal dan ikut dipertahankan saat pemulihan cadangan.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedTextField(date, { date = it }, label = { Text("Tanggal (yyyy-MM-dd)") }, singleLine = true, modifier = full)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(rhr, { rhr = it }, label = { Text("HR istirahat") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
            OutlinedTextField(hrv, { hrv = it }, label = { Text("HRV (ms)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(leg, { leg = it }, label = { Text("Rasa kaki 1–5") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
            OutlinedTextField(mood, { mood = it }, label = { Text("Stres 1–5") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
        }
        OutlinedTextField(sleep, { sleep = it }, label = { Text("Tidur (jam)") }, keyboardOptions = numeric, singleLine = true, modifier = full)
        dailyError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(onClick = {
            val parsedDate = runCatching { LocalDate.parse(date) }.getOrNull()
            val l = leg.toIntOrNull(); val m = mood.toIntOrNull(); val sl = sleep.replace(',', '.').toDoubleOrNull()
            if (parsedDate == null || (rhr.isNotBlank() && rhr.toIntOrNull() == null) || (hrv.isNotBlank() && hrv.toIntOrNull() == null) || l == null || l !in 1..5 || m == null || m !in 1..5 || (sleep.isNotBlank() && (sl == null || sl !in 0.0..24.0))) {
                dailyError = "Periksa tanggal, angka, dan rentang nilai kondisi harian."
            } else {
                dailyError = null
                onSaveDaily(DailyEntity(date, rhr.toIntOrNull(), hrv.toIntOrNull(), l, m, sl))
            }
        }, modifier = full) { Text("Simpan kondisi harian") }
        Text("Riwayat kondisi", style = MaterialTheme.typography.titleMedium)
        daily.take(5).forEach { d ->
            Text("${d.dateIso}  ·  tidur ${d.sleepH?.let { "%.1f jam".format(it) } ?: "—"}  ·  RHR ${d.rhr ?: "—"}  ·  HRV ${d.hrv ?: "—"}", style = MaterialTheme.typography.bodySmall)
        }

        Text("Gear", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 12.dp))
        Text("Kelola sepatu atau perlengkapan. Jarak pemakaian dihitung dari aktivitas yang ditautkan ke gear tersebut.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedTextField(gearName, { gearName = it }, label = { Text("Nama gear") }, singleLine = true, modifier = full)
        OutlinedTextField(gearModel, { gearModel = it }, label = { Text("Model / catatan") }, singleLine = true, modifier = full)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(gearStartKm, { gearStartKm = it }, label = { Text("Km awal") }, keyboardOptions = numeric, singleLine = true, modifier = Modifier.weight(1f))
            OutlinedTextField(gearLimitKm, { gearLimitKm = it }, label = { Text("Batas km (0=tanpa)") }, keyboardOptions = numeric, singleLine = true, modifier = Modifier.weight(1f))
        }
        gearError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(onClick = {
            val initial = gearStartKm.replace(',', '.').toDoubleOrNull()
            val limit = gearLimitKm.replace(',', '.').toDoubleOrNull()
            if (gearName.isBlank() || initial == null || limit == null || initial < 0 || limit < 0) gearError = "Isi nama gear dan angka jarak yang valid."
            else {
                gearError = null
                onSaveGear(GearEntity(UUID.randomUUID().toString(), gearName.trim(), gearModel.trim(), initial, limit))
                gearName = ""; gearModel = ""; gearStartKm = "0"; gearLimitKm = "800"
            }
        }, modifier = full) { Text("Tambah gear") }
        gear.forEach { g ->
            val used = g.km0 + activities.filter { it.gearId == g.id }.sumOf { it.km }
            Card(modifier = full) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(g.name, style = MaterialTheme.typography.titleMedium)
                            if (g.model.isNotBlank()) Text(g.model, style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(checked = g.retired, onCheckedChange = { onSaveGear(g.copy(retired = it)) })
                    }
                    Text("${"%.1f".format(used)} km${if (g.limitKm > 0) " / ${"%.0f".format(g.limitKm)} km" else ""}${if (g.isDefault) " · Default" else ""}", style = MaterialTheme.typography.bodyMedium)
                    Text(if (g.retired) "Dipensiunkan" else "Aktif", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.End, modifier = full) {
                        OutlinedButton(onClick = { onDeleteGear(g.id) }) { Text("Hapus") }
                    }
                }
            }
        }
    }
}
