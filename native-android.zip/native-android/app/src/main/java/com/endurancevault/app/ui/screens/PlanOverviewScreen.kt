package com.endurancevault.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.graphics.SolidColor
import com.endurancevault.app.ui.theme.cardTint
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.domain.Kinds
import com.endurancevault.app.domain.PDay
import com.endurancevault.app.domain.PWeek
import com.endurancevault.app.domain.Phases
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.SessionAdjust
import com.endurancevault.app.domain.StrengthBlock
import com.endurancevault.app.ui.UiState
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

// ---------- model tampilan ----------

private enum class Metric(val label: String, val title: String, val unit: String) {
    KM("Km", "KM PER WEEK", "km"),
    HOURS("Hours", "HOURS PER WEEK", "h"),
    CLIMB("Climb", "CLIMB PER WEEK", "m"),
    DESCENT("Descent", "DESCENT PER WEEK", "m"),
}

private class WeekStat(val idx: Int, val w: PWeek, val plan: Double, val done: Double, val spike: Int?)
private class Block(val phase: String, val n: Int, val of: Int, val stats: List<WeekStat>)


private val DATE_FMT = DateTimeFormatter.ofPattern("d MMM", Locale.ENGLISH)
private val MONO = FontFamily.Monospace

private val PhaseBase = Color(0xFF7B8190)
private val PhaseBuild = Color(0xFFFA7A0C)
private val PhasePeak = Color(0xFFD9480F)
private val PhaseTaper = Color(0xFFF2B48A)

private fun phaseColor(p: String) = when (p) {
    Phases.BASE -> PhaseBase
    Phases.BUILD -> PhaseBuild
    Phases.PEAK -> PhasePeak
    else -> PhaseTaper
}

// Warna batang kartu hero kini dari planBarColor() (PlanSettingsPanel.kt), sama dengan grafik di pengaturan plan.

private fun phaseName(p: String) = when (p) {
    Phases.BASE -> "BASE"; Phases.BUILD -> "BUILD"; Phases.PEAK -> "PEAK"; else -> "TAPER"
}

private val PHASE_ORDER = listOf(Phases.BASE, Phases.BUILD, Phases.PEAK, Phases.TAPER)

private fun fmt(v: Double): String =
    if (abs(v - v.roundToInt()) < 0.05) v.roundToInt().toString() else String.format(Locale.US, "%.1f", v)

private fun paceMinPerKm(s: String): Double {
    val p = s.trim().split(":")
    val m = p.getOrNull(0)?.toDoubleOrNull() ?: return 6.5
    val sec = p.getOrNull(1)?.toDoubleOrNull() ?: 0.0
    return m + sec / 60.0
}

private fun planned(w: PWeek, m: Metric, pace: Double): Double = when (m) {
    Metric.KM -> w.km
    Metric.HOURS -> w.days.filter { it.kind != Kinds.REST }.sumOf { it.km } * pace / 60.0
    // Rencana hanya menyimpan D+; turunan dianggap sama (rute loop).
    Metric.CLIMB, Metric.DESCENT -> w.days.sumOf { (it.gain ?: 0).toDouble() }
}

private fun doneOf(w: PWeek, m: Metric, acts: List<ActivityEntity>): Double {
    val a = w.start.toString(); val b = w.end.toString()
    val runs = acts.filter { it.type.equals("run", ignoreCase = true) && it.dateIso >= a && it.dateIso <= b }
    return when (m) {
        Metric.KM -> runs.sumOf { it.km }
        Metric.HOURS -> runs.sumOf { it.durationSec.toDouble() } / 3600.0
        Metric.CLIMB, Metric.DESCENT -> runs.sumOf { (it.gain ?: 0).toDouble() }
    }
}

private fun buildStats(weeks: List<PWeek>, m: Metric, pace: Double, acts: List<ActivityEntity>): List<WeekStat> {
    var prev = 0.0
    return weeks.mapIndexed { i, w ->
        val p = planned(w, m, pace)
        val pct = if (i > 0 && prev > 0.0) ((p / prev - 1.0) * 100).roundToInt() else 0
        prev = p
        WeekStat(i, w, p, doneOf(w, m, acts), if (pct > 10) pct else null)
    }
}

private fun buildBlocks(stats: List<WeekStat>): List<Block> {
    val out = mutableListOf<Block>()
    var i = 0
    while (i < stats.size) {
        val ph = stats[i].w.phase
        var j = i
        while (j < stats.size && stats[j].w.phase == ph) j++
        val chunks = stats.subList(i, j).chunked(4)
        chunks.forEachIndexed { k, c -> out += Block(ph, k + 1, chunks.size, c) }
        i = j
    }
    return out
}

private fun rangeLabel(a: LocalDate, b: LocalDate): String =
    if (a.month == b.month) "${a.dayOfMonth}–${b.dayOfMonth} ${b.month.getDisplayName(TextStyle.SHORT, Locale.ENGLISH)}"
    else "${a.format(DATE_FMT)} – ${b.format(DATE_FMT)}"

// ---------- layar ----------

/**
 * Ringkasan seluruh rencana dalam satu kartu: hero padat, daftar minggu per blok 4 minggu yang digeser horizontal,
 * dan dock fase. Rincian hari satu minggu dibuka dengan expand di tempat (bukan halaman/sheet baru). Tab Minggu tetap pelacak operasional.
 */
@Composable
fun PlanOverviewScreen(state: UiState, onOpenActivity: (Long) -> Unit = {}) {
    val plan = state.plan
    if (plan !is PlanOutcome.Ok || plan.weeks.isEmpty()) {
        Text((plan as? PlanOutcome.Err)?.message ?: "Rencana belum tersedia", Modifier.padding(20.dp))
        return
    }
    val weeks = plan.weeks
    val today = LocalDate.now()
    val pace = remember(state.settings.pace) { paceMinPerKm(state.settings.pace) }
    var metric by rememberSaveable { mutableStateOf(Metric.KM) }
    val curIdx = remember(weeks) {
        weeks.indexOfFirst { !today.isBefore(it.start) && !today.isAfter(it.end) }.takeIf { it >= 0 }
            ?: weeks.indexOfFirst { !it.end.isBefore(today) }.takeIf { it >= 0 } ?: (weeks.size - 1).coerceAtLeast(0)
    }
    var sel by rememberSaveable { mutableStateOf(curIdx) }
    var expanded by rememberSaveable { mutableStateOf<List<Int>>(emptyList()) }

    val stats = remember(weeks, metric, pace, state.activities) { buildStats(weeks, metric, pace, state.activities) }
    val blocks = remember(stats) { buildBlocks(stats) }
    val curBlock = remember(blocks, curIdx) { blocks.indexOfFirst { b -> b.stats.any { it.idx == curIdx } }.coerceAtLeast(0) }
    val pager = rememberPagerState(initialPage = curBlock) { blocks.size }
    val scope = rememberCoroutineScope()
    val curPhase = weeks.getOrNull(curIdx)?.phase ?: Phases.BASE
    val shownPhase = blocks.getOrNull(pager.currentPage)?.phase ?: curPhase
    val present = remember(blocks) { blocks.map { it.phase }.toSet() }

    Column(Modifier.fillMaxSize()) {
        Hero(
            state = state, plan = plan, stats = stats, metric = metric, sel = sel,
            onMetric = { metric = it },
            onSelect = { i ->
                sel = i
                val bi = blocks.indexOfFirst { b -> b.stats.any { it.idx == i } }
                if (bi >= 0) scope.launch { pager.animateScrollToPage(bi) }
            },
            modifier = Modifier.padding(start = 8.dp, end = 8.dp, top = 8.dp),
        )
        HorizontalPager(pager, Modifier.weight(1f).fillMaxWidth(), verticalAlignment = Alignment.Top) { page ->
            val b = blocks[page]
            BoxWithConstraints(Modifier.fillMaxSize()) {
                val rowH: Dp = ((maxHeight - 56.dp) / b.stats.size.coerceAtLeast(1)).coerceIn(46.dp, 54.dp)
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(start = 8.dp, end = 8.dp, top = 8.dp)) {
                    BlockHeader(b, metric, current = b.stats.any { it.idx == curIdx })
                    b.stats.forEachIndexed { i, s ->
                        val open = s.idx in expanded
                        WeekRowCompact(
                            s, metric, rowH, last = i == b.stats.lastIndex, selected = s.idx == sel, open = open,
                            state = state, today = today, onOpenActivity = onOpenActivity,
                        ) {
                            sel = s.idx
                            expanded = if (open) expanded - s.idx else expanded + s.idx
                        }
                    }
                }
            }
        }
        PageDots(count = blocks.size, current = pager.currentPage)
        PhaseDock(
            selected = shownPhase, current = curPhase, present = present,
            onTap = { p -> blocks.indexOfFirst { it.phase == p }.takeIf { it >= 0 }?.let { scope.launch { pager.animateScrollToPage(it) } } },
        )
    }
}

// ---------- kartu hero (padat) ----------

@Composable
private fun Hero(
    state: UiState, plan: PlanOutcome.Ok, stats: List<WeekStat>, metric: Metric, sel: Int,
    onMetric: (Metric) -> Unit, onSelect: (Int) -> Unit, modifier: Modifier = Modifier,
) {
    val white = MaterialTheme.colorScheme.onSurface
    val dim = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f)
    val total = stats.sumOf { it.plan }
    val spikes = stats.filter { it.spike != null }
    val first = plan.weeks.firstOrNull()?.km ?: 0.0
    val peak = plan.weeks.maxOfOrNull { it.km } ?: 0.0
    val maxV = (stats.maxOfOrNull { maxOf(it.plan, it.done) } ?: 1.0).coerceAtLeast(0.1)
    val chosen = stats.getOrNull(sel) ?: stats.firstOrNull()

    Box(
        modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.cardTint),
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 9.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                Box(Modifier.clip(CircleShape).background(white.copy(alpha = .14f)).padding(horizontal = 9.dp, vertical = 4.dp)) {
                    Text(if (plan.build) "PERFORMANCE BUILD" else "TRAINING PLAN", fontFamily = MONO, fontSize = 10.sp, letterSpacing = 1.sp, color = white, maxLines = 1)
                }
                Box(Modifier.clip(CircleShape).border(1.dp, white.copy(alpha = .5f), CircleShape).padding(horizontal = 8.dp, vertical = 3.dp)) {
                    Text("${state.settings.days} D/MGG", fontFamily = MONO, fontSize = 10.sp, color = white, maxLines = 1)
                }
                Spacer(Modifier.weight(1f))
                Text("${first.roundToInt()}→${peak.roundToInt()}", fontFamily = MONO, fontSize = 10.sp, color = dim, maxLines = 1)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                HeroStat("PLAN LENGTH", plan.weeks.size.toString(), "weeks")
                HeroStat("TOTAL VOLUME", fmt(total), metric.unit)
            }
            Row(Modifier.fillMaxWidth().clip(CircleShape).background(white.copy(alpha = .09f)).padding(2.dp)) {
                Metric.values().forEach { m ->
                    val on = m == metric
                    Box(
                        Modifier.weight(1f).clip(CircleShape).background(if (on) MaterialTheme.colorScheme.primary else Color.Transparent)
                            .clickable { onMetric(m) }.padding(vertical = 5.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(m.label, fontFamily = MONO, fontSize = 11.sp, maxLines = 1, color = if (on) MaterialTheme.colorScheme.onPrimary else white.copy(alpha = .85f))
                    }
                }
            }
            if (chosen != null) {
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(white.copy(alpha = .08f)).padding(horizontal = 8.dp, vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(
                        "W${chosen.idx + 1} · ${phaseName(chosen.w.phase).lowercase().replaceFirstChar { it.uppercase() }} · ${rangeLabel(chosen.w.start, chosen.w.end)}",
                        Modifier.weight(1f), fontFamily = MONO, fontSize = 10.sp, color = white, maxLines = 1,
                    )
                    Text("${fmt(chosen.done)} / ${fmt(chosen.plan)} ${metric.unit}", fontFamily = MONO, fontSize = 10.sp, color = white, maxLines = 1)
                }
            }
            Row(Modifier.fillMaxWidth().height(74.dp), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.Bottom) {
                stats.forEach { s ->
                    val frac = (s.plan / maxV).toFloat().coerceIn(0.05f, 1f)
                    val doneFrac = if (s.plan > 0) (s.done / s.plan).toFloat().coerceIn(0f, 1f) else 0f
                    val isSel = s.idx == sel
                    val c = planBarColor(s.w, MaterialTheme.colorScheme)
                    Column(
                        Modifier.weight(1f).fillMaxHeight().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onSelect(s.idx) },
                        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom,
                    ) {
                        if (s.spike != null) Text("▲", fontSize = 8.sp, color = white, lineHeight = 8.sp)
                        Box(
                            Modifier.fillMaxWidth().height(52.dp * frac).clip(RoundedCornerShape(3.dp)).background(c.copy(alpha = .42f))
                                .then(if (isSel) Modifier.border(2.dp, white, RoundedCornerShape(3.dp)) else Modifier),
                        ) {
                            Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().fillMaxHeight(doneFrac).background(c))
                        }
                        Box(Modifier.padding(top = 3.dp).size(5.dp).clip(CircleShape).background(if (isSel) white else Color.Transparent))
                    }
                }
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(
                    if (spikes.isEmpty()) "No week >10%" else "▲ ${spikes.size} wk >10%",
                    fontFamily = MONO, fontSize = 10.sp, color = white, maxLines = 1,
                )
                spikes.forEach { s ->
                    Box(Modifier.clip(CircleShape).border(1.dp, white, CircleShape).clickable { onSelect(s.idx) }.padding(horizontal = 6.dp, vertical = 2.dp)) {
                        Text("W${s.idx + 1} +${s.spike}%", fontFamily = MONO, fontSize = 10.sp, color = white, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
private fun HeroStat(label: String, value: String, unit: String) {
    Column {
        Text(label, fontFamily = MONO, fontSize = 10.sp, letterSpacing = 1.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            Text(unit, Modifier.padding(start = 3.dp, bottom = 2.dp), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

// ---------- satu halaman blok ----------

@Composable
private fun BlockHeader(b: Block, metric: Metric, current: Boolean) {
    val cs = MaterialTheme.colorScheme
    val first = b.stats.first(); val last = b.stats.last()
    val range = if (first.idx == last.idx) "W${first.idx + 1}" else "W${first.idx + 1}–W${last.idx + 1}"
    val rec = b.stats.filter { it.w.rec }.joinToString(" ") { "W${it.idx + 1}" }
    Row(Modifier.fillMaxWidth().height(40.dp).clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp))) {
        Box(Modifier.width(6.dp).fillMaxHeight().background(phaseColor(b.phase)))
        Row(
            Modifier.weight(1f).fillMaxHeight().background(if (current) cs.primary.copy(alpha = .14f) else cs.surfaceVariant).padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(phaseName(b.phase), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text(" ${b.n}/${b.of}", fontFamily = MONO, fontSize = 11.sp, color = cs.onSurfaceVariant)
            }
            Text(
                "$range · ${rangeLabel(first.w.start, last.w.end)}" + if (rec.isNotEmpty()) " · rec $rec" else "",
                Modifier.weight(1f), fontSize = 12.sp, color = cs.onSurfaceVariant, maxLines = 1,
            )
            Text("${fmt(b.stats.sumOf { it.plan })} ${metric.unit}", fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

/** Jumlah sesi kekuatan (gym + ankle + upper) dalam satu minggu. */
private fun strengthSessions(w: PWeek): Int =
    w.days.sumOf { d -> listOf(d.str, d.ank, d.up).count { it != null } }

@Composable
private fun WeekRowCompact(
    s: WeekStat, metric: Metric, h: Dp, last: Boolean, selected: Boolean, open: Boolean,
    state: UiState, today: LocalDate, onOpenActivity: (Long) -> Unit, onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val w = s.w
    val str = strengthSessions(w)
    val shape = if (last) RoundedCornerShape(bottomStart = 14.dp, bottomEnd = 14.dp) else RectangleShape
    Column(Modifier.fillMaxWidth().clip(shape)) {
        HorizontalDivider(color = cs.outlineVariant.copy(alpha = .6f))
        Row(Modifier.fillMaxWidth().heightIn(min = h).height(IntrinsicSize.Min).clickable(onClick = onClick)) {
            Box(Modifier.width(6.dp).fillMaxHeight().background(phaseColor(w.phase).copy(alpha = .55f)))
            Row(
                Modifier.weight(1f).fillMaxHeight().background(if (selected || open) cs.primary.copy(alpha = .08f) else cs.surface)
                    .padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Box(Modifier.clip(CircleShape).background(cs.surfaceVariant).padding(horizontal = 8.dp, vertical = 2.dp)) {
                    Text("W${s.idx + 1}", fontFamily = MONO, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(rangeLabel(w.start, w.end), fontSize = 13.sp, maxLines = 1)
                        if (s.spike != null) Text("▲${s.spike}%", fontFamily = MONO, fontSize = 11.sp, color = cs.primary, maxLines = 1)
                    }
                    if (str > 0) Text("+$str strength", fontSize = 10.sp, color = cs.onSurfaceVariant, maxLines = 1)
                }
                Box(Modifier.clip(CircleShape).background(phaseColor(w.phase)).padding(horizontal = 7.dp, vertical = 2.dp)) {
                    Text(phaseName(w.phase), fontFamily = MONO, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1)
                }
                Text("${fmt(s.plan)} ${metric.unit}", Modifier.width(60.dp), fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, textAlign = androidx.compose.ui.text.style.TextAlign.End)
                Text(if (open) "▴" else "▾", fontSize = 11.sp, color = cs.onSurfaceVariant)
            }
        }
        AnimatedVisibility(
            visible = open,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut(),
        ) {
            Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
                Box(Modifier.width(6.dp).fillMaxHeight().background(phaseColor(w.phase).copy(alpha = .55f)))
                Column(
                    Modifier.weight(1f).background(cs.surfaceVariant.copy(alpha = .35f)).padding(horizontal = 8.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    w.days.forEach { d ->
                        DayCard(d, state, today, onOpenActivity)
                        listOf(Triple(d.str, "s", "GYM"), Triple(d.ank, "a", "ANKLE"), Triple(d.up, "u", "UPPER")).forEach { (blk, suffix, tag) ->
                            if (blk != null) StrengthCard(d, blk, "${d.date}:$suffix", tag, state, today)
                        }
                    }
                }
            }
        }
    }
}

// ---------- kartu hari (hanya baca) ----------

@Composable
private fun DayCard(d: PDay, state: UiState, today: LocalDate, onOpenActivity: (Long) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val key = d.date.toString()
    val rest = d.kind == Kinds.REST
    val logged = if (rest) null else SessionAdjust.primaryRun(state.activities, key)
    val completed = !rest && (logged != null || key in state.done)
    val adj = d.adj
    val missed = !rest && !completed && (adj?.type == "miss" || (adj == null && d.date.isBefore(today)))
    val hard = d.kind == Kinds.QUALITY || d.kind == Kinds.LONG || d.kind == Kinds.RACE || d.kind == Kinds.EVENT
    val accent = if (hard) SolidColor(PhaseBuild) else SolidColor(PhaseBase)
    val dow = d.date.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.ENGLISH).uppercase()

    val status: Pair<String, Boolean>? = when {
        completed && logged != null -> {
            val ok = d.km <= 0.0 || logged.km / d.km in 0.85..1.15
            (if (ok) "✓ On plan" else "! Needs attention") to ok
        }
        completed -> "✓ Marked done" to true
        missed -> "Missed" to false
        else -> null
    }

    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min).clip(RoundedCornerShape(16.dp)).background(cs.surface)) {
        Box(Modifier.width(5.dp).fillMaxHeight().background(accent))
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.width(40.dp)) {
                Text(dow, fontFamily = MONO, fontSize = 10.sp, color = cs.onSurfaceVariant)
                Text(d.date.dayOfMonth.toString(), fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(if (rest) "Rest" else d.title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                if (rest) Text("Complete rest.", fontSize = 12.sp, color = cs.onSurfaceVariant)
                else if (d.detail.isNotBlank()) Text(d.detail, fontSize = 12.sp, color = cs.onSurfaceVariant, maxLines = 2)
                if (logged != null) {
                    val pace = if (logged.km > 0 && logged.durationSec > 0) {
                        val sec = (logged.durationSec / logged.km).roundToInt()
                        " · ${sec / 60}:${"%02d".format(sec % 60)}/km"
                    } else ""
                    Box(Modifier.clip(RoundedCornerShape(18.dp)).background(cs.surfaceVariant).padding(horizontal = 14.dp, vertical = 8.dp)) {
                        Text("Logged · ${fmt(logged.km)} km$pace" + (logged.avgHr?.let { " · HR $it" } ?: ""), fontSize = 12.sp)
                    }
                    Box(Modifier.clip(CircleShape).background(cs.surfaceVariant).clickable { onOpenActivity(logged.id) }.padding(horizontal = 14.dp, vertical = 7.dp)) {
                        Text("Detail", fontSize = 12.sp)
                    }
                }
                if (adj != null && adj.type != "miss") Text(adj.text, fontSize = 11.sp, color = cs.tertiary)
                status?.let { (t, _) -> Text(t, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = cs.primary) }
            }
            if (!rest) Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (d.km > 0) Row(verticalAlignment = Alignment.Bottom) {
                    Text(fmt(d.km), fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text(" km", fontSize = 11.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(bottom = 2.dp))
                }
                DoneDot(completed)
            }
        }
    }
}

@Composable
private fun StrengthCard(d: PDay, b: StrengthBlock, key: String, tag: String, state: UiState, today: LocalDate) {
    val cs = MaterialTheme.colorScheme
    val completed = key in state.done || state.strengthWorkouts.any { it.linkedKey == key }
    val missed = !completed && d.date.isBefore(today)
    var open by rememberSaveable(key) { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min).clip(RoundedCornerShape(16.dp)).background(cs.surface).clickable { open = !open }) {
        Box(Modifier.width(5.dp).fillMaxHeight().background(SolidColor(PhaseBuild)))
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(tag, Modifier.width(40.dp), fontFamily = MONO, fontSize = 10.sp, color = cs.primary)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(b.title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                if (completed) Text("✓ Done", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = cs.primary)
                else if (missed) Text("Missed", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = cs.primary)
                Text((if (open) "Hide sets" else "See sets") + " · ${b.lines.size} exercises", fontSize = 12.sp, color = cs.primary)
                if (open) {
                    if (b.note.isNotBlank()) Text(b.note, fontSize = 12.sp, color = cs.onSurfaceVariant)
                    b.lines.forEach { Text("• $it", fontSize = 13.sp) }
                }
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("${b.mins}", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(" min", fontSize = 11.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(bottom = 2.dp))
                }
                DoneDot(completed)
            }
        }
    }
}

@Composable
private fun DoneDot(done: Boolean) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.size(24.dp).clip(CircleShape)
            .background(if (done) PhaseBuild else Color.Transparent)
            .border(2.dp, if (done) PhaseBuild else cs.outline, CircleShape),
    )
}

// ---------- titik halaman dan dock fase ----------

@Composable
private fun PageDots(count: Int, current: Int) {
    if (count <= 1) { Spacer(Modifier.height(6.dp)); return }
    Row(Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 8.dp), horizontalArrangement = Arrangement.Center) {
        repeat(count) { i ->
            Box(
                Modifier.padding(horizontal = 2.5.dp).size(6.dp).clip(CircleShape)
                    .background(if (i == current) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline),
            )
        }
    }
}

@Composable
private fun PhaseDock(selected: String, current: String, present: Set<String>, onTap: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth().background(cs.surface)) {
        HorizontalDivider(color = cs.outlineVariant)
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PHASE_ORDER.forEach { p ->
                val exists = p in present
                val on = p == selected && exists
                Box(
                    Modifier.weight(1f).height(38.dp).clip(CircleShape)
                        .background(if (on) cs.primary else Color.Transparent)
                        .then(if (on) Modifier else Modifier.border(BorderStroke(1.dp, cs.outlineVariant.copy(alpha = if (exists) 1f else .5f)), CircleShape))
                        .then(if (exists) Modifier.clickable { onTap(p) } else Modifier),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        phaseName(p).lowercase().replaceFirstChar { it.uppercase() } + if (p == current) " •" else "",
                        fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
                        color = when {
                            on -> cs.onPrimary
                            exists -> cs.onSurface
                            else -> cs.onSurfaceVariant.copy(alpha = .45f)
                        },
                    )
                }
            }
        }
    }
}
