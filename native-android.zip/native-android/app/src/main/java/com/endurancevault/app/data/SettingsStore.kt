package com.endurancevault.app.data

import android.content.Context
import com.endurancevault.app.domain.PbAk
import com.endurancevault.app.domain.PbConv
import com.endurancevault.app.domain.PbPost
import com.endurancevault.app.domain.PlanSettings
import java.time.LocalDate

/** Penyimpanan pengaturan rencana (SharedPreferences). */
class SettingsStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("plan_settings", Context.MODE_PRIVATE)

    fun load(): PlanSettings {
        val d = PlanSettings(start = LocalDate.now())
        fun dbl(k: String): Double? = if (sp.contains(k)) sp.getFloat(k, 0f).toDouble() else null
        return PlanSettings(
            name = sp.getString("name", "") ?: "",
            rtype = sp.getString("rtype", d.rtype) ?: d.rtype,
            start = date("start") ?: d.start,
            race = date("race"),
            raceKm = dbl("raceKm"),
            raceGain = dbl("raceGain"),
            goalT = sp.getString("goalT", "") ?: "",
            base = sp.getFloat("base", d.base.toFloat()).toDouble(),
            peak = sp.getFloat("peak", d.peak.toFloat()).toDouble(),
            days = sp.getInt("days", d.days),
            rest = sp.getInt("rest", d.rest),
            rest2 = sp.getInt("rest2", d.rest2),
            longDay = sp.getInt("longDay", d.longDay),
            hr = sp.getInt("hr", d.hr),
            thr = sp.getString("thr", d.thr) ?: d.thr,
            pace = sp.getString("pace", d.pace) ?: d.pace,
            hrMax = if (sp.contains("hrMax")) sp.getInt("hrMax", 0) else null,
            bspd = sp.getFloat("bspd", d.bspd.toFloat()).toDouble(),
            pbCycle = sp.getString("pbCycle", d.pbCycle) ?: d.pbCycle,
            pbFocus = sp.getString("pbFocus", d.pbFocus) ?: d.pbFocus,
            pbPost = if (sp.contains("pbPostRec")) PbPost(sp.getFloat("pbPostRec", 0f).toDouble(), sp.getFloat("pbPostLvl", 0f).toDouble()) else null,
            pbConv = if (sp.contains("pbConvWk")) PbConv(sp.getInt("pbConvWk", 0), sp.getFloat("pbConvB0", 0f).toDouble(), sp.getFloat("pbConvP0", 0f).toDouble()) else null,
            pbAk = date("pbAkWk")?.let { PbAk(it, sp.getFloat("pbAkKm", 0f).toDouble()) },
            evOn = sp.getBoolean("evOn", false),
            evDate = date("evDate"),
            evKm = sp.getFloat("evKm", 0f).toDouble(),
            evGain = sp.getFloat("evGain", 0f).toDouble(),
        )
    }

    fun save(s: PlanSettings) {
        val e = sp.edit().clear()
            .putString("name", s.name).putString("rtype", s.rtype).putString("start", s.start.toString())
            .putString("goalT", s.goalT)
            .putFloat("base", s.base.toFloat()).putFloat("peak", s.peak.toFloat())
            .putInt("days", s.days).putInt("rest", s.rest).putInt("rest2", s.rest2).putInt("longDay", s.longDay)
            .putInt("hr", s.hr).putString("thr", s.thr).putString("pace", s.pace).putFloat("bspd", s.bspd.toFloat())
            .putString("pbCycle", s.pbCycle).putString("pbFocus", s.pbFocus)
            .putBoolean("evOn", s.evOn).putFloat("evKm", s.evKm.toFloat()).putFloat("evGain", s.evGain.toFloat())
        s.race?.let { e.putString("race", it.toString()) }
        s.raceKm?.let { e.putFloat("raceKm", it.toFloat()) }
        s.raceGain?.let { e.putFloat("raceGain", it.toFloat()) }
        s.hrMax?.let { e.putInt("hrMax", it) }
        s.pbPost?.let { e.putFloat("pbPostRec", it.rec.toFloat()).putFloat("pbPostLvl", it.lvl.toFloat()) }
        s.pbConv?.let { e.putInt("pbConvWk", it.wk).putFloat("pbConvB0", it.b0.toFloat()).putFloat("pbConvP0", it.p0.toFloat()) }
        s.pbAk?.let { e.putString("pbAkWk", it.wk.toString()).putFloat("pbAkKm", it.km.toFloat()) }
        s.evDate?.let { e.putString("evDate", it.toString()) }
        e.apply()
    }

    private fun date(key: String): LocalDate? =
        sp.getString(key, null)?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
}
