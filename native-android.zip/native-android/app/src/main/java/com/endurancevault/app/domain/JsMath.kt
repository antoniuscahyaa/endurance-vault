package com.endurancevault.app.domain

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.floor

/** Helper yang meniru perilaku JavaScript agar hasil identik dengan versi web. */
internal object Js {
    /** Math.round JS: setengah dibulatkan ke atas (bukan ke genap). */
    fun round(x: Double): Double = floor(x + 0.5)
    fun roundI(x: Double): Int = round(x).toInt()

    /** Angka ke teks seperti JS: bilangan bulat tanpa ".0". */
    fun n(x: Double): String =
        if (x == floor(x) && !x.isInfinite() && kotlin.math.abs(x) < 1e15) x.toLong().toString() else x.toString()
    fun n(x: Int): String = x.toString()

    fun pad(n: Int) = if (n < 10) "0$n" else "$n"

    /** idn(): toLocaleString('id-ID') untuk bilangan bulat, ribuan dipisah titik. */
    fun idn(x: Int): String {
        val neg = x < 0
        val s = kotlin.math.abs(x).toString()
        val sb = StringBuilder()
        s.forEachIndexed { i, c -> if (i > 0 && (s.length - i) % 3 == 0) sb.append('.'); sb.append(c) }
        return (if (neg) "-" else "") + sb
    }

    fun r50(x: Double): Int = (round(x / 50.0) * 50).toInt()

    fun diffDays(a: LocalDate, b: LocalDate): Int = ChronoUnit.DAYS.between(b, a).toInt()
    fun mondayOf(d: LocalDate): LocalDate = d.minusDays((d.dayOfWeek.value - 1).toLong())

    /** paceStr(): menit desimal ke m:ss */
    fun paceStr(m: Double): String {
        if (m.isNaN() || m.isInfinite() || m <= 0) return "–"
        val s = roundI(m * 60)
        return "${s / 60}:${pad(s % 60)}"
    }

    /** parseDur(): "h:mm:ss", "mm:ss" atau "mm" ke menit; NaN bila tidak valid. */
    fun parseDur(t: String): Double {
        val p = t.trim().split(":").map { it.toDoubleOrNull() ?: return Double.NaN }
        return when (p.size) {
            1 -> p[0]
            2 -> p[0] + p[1] / 60
            3 -> p[0] * 60 + p[1] + p[2] / 60
            else -> Double.NaN
        }
    }

    fun durStr(m: Double): String {
        val s = roundI(m * 60); val h = s / 3600; val mm = (s % 3600) / 60; val ss = s % 60
        return (if (h > 0) "$h:${pad(mm)}" else "$mm") + ":" + pad(ss)
    }

    /** parsePaceStr(): "6:30" ke menit desimal, bawaan 6.5 */
    fun parsePaceStr(t: String): Double {
        val p = t.split(":").map { it.toDoubleOrNull() ?: return 6.5 }
        return if (p.size == 2 && p[0] > 0) p[0] + p[1] / 60 else 6.5
    }

    /** fmtKm() untuk bahasa Indonesia: satu desimal, koma desimal. */
    fun fmtKm(x: Double): String = n(round(x * 10) / 10).replace('.', ',')
}
