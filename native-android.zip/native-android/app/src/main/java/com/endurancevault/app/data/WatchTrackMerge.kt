package com.endurancevault.app.data

import com.endurancevault.app.domain.Pt
import org.json.JSONArray
import org.json.JSONObject

/**
 * Menggabungkan titik workout dari jam (`readWorkoutPoints`) menjadi lintasan [Pt] yang utuh.
 *
 * Jam mengirim dua aliran terpisah yang disimpan sebagai baris `workout_points`:
 *  - titik GPS: lat/lon (+ altitude GPS bila didukung), tanpa HR dan kadens;
 *  - sampel data: HR, kadens, dan altitude barometer, tanpa lat/lon.
 *
 * Versi lama membuang semua baris tanpa lat/lon sehingga HR, kadens, dan elevasi barometer hilang dari detail lari.
 * Di sini setiap titik GPS diberi nilai sampel terdekat (HR, kadens) atau hasil interpolasi (altitude) selama
 * jaraknya tidak melebihi [MAX_GAP_SEC]; celah yang lebih panjang dibiarkan kosong, bukan diisi data palsu.
 */
object WatchTrackMerge {
    /** Versi format detail hasil impor jam. Berkas dengan versi lebih rendah dibangun ulang pada sinkron berikutnya. */
    const val VERSION = 3

    /** Sampel dianggap masih berlaku untuk titik GPS yang berjarak sampai sekian detik. */
    const val MAX_GAP_SEC = 15L

    /** Altitude barometer dipakai bila jumlah sampelnya cukup; kalau tidak, altitude GPS. */
    private const val MIN_BARO_SAMPLES = 10

    private class Series(ts: List<Long>, vs: List<Double>) {
        val t = ts.toLongArray()
        val v = vs.toDoubleArray()
        val size get() = t.size

        /** Indeks pertama dengan t[i] >= x (size bila tidak ada). */
        private fun lowerBound(x: Long): Int {
            var lo = 0; var hi = t.size
            while (lo < hi) { val mid = (lo + hi) ushr 1; if (t[mid] < x) lo = mid + 1 else hi = mid }
            return lo
        }

        fun nearest(x: Long, maxGap: Long): Double? {
            if (t.isEmpty()) return null
            val i = lowerBound(x)
            var best: Int? = null; var bestGap = Long.MAX_VALUE
            for (k in intArrayOf(i - 1, i)) {
                if (k < 0 || k >= t.size) continue
                val gap = kotlin.math.abs(t[k] - x)
                if (gap < bestGap) { bestGap = gap; best = k }
            }
            return if (best != null && bestGap <= maxGap) v[best] else null
        }

        fun interpolate(x: Long, maxGap: Long): Double? {
            if (t.isEmpty()) return null
            val i = lowerBound(x)
            if (i < t.size && t[i] == x) return v[i]
            val before = i - 1; val after = i
            if (before >= 0 && after < t.size && x - t[before] <= maxGap && t[after] - x <= maxGap) {
                val span = (t[after] - t[before]).toDouble()
                if (span <= 0.0) return v[before]
                return v[before] + (v[after] - v[before]) * ((x - t[before]) / span)
            }
            return nearest(x, maxGap)
        }
    }

    private class Raw(val ts: Long, val lat: Double?, val lon: Double?, val alt: Double?, val hr: Int?, val cad: Int?) {
        val hasGps get() = lat != null && lon != null
    }

    private fun JSONObject.numOrNull(key: String): Double? {
        if (!has(key) || isNull(key)) return null
        val d = optDouble(key, Double.NaN)
        return if (d.isNaN() || d.isInfinite()) null else d
    }

    private fun parse(points: JSONArray): List<Raw> {
        val out = ArrayList<Raw>(points.length())
        for (i in 0 until points.length()) {
            val p = points.optJSONObject(i) ?: continue
            val ts = p.optLong("ts", 0L)
            if (ts <= 0L) continue
            var lat = p.numOrNull("lat"); var lon = p.numOrNull("lon")
            if (lat == null || lon == null || lat !in -90.0..90.0 || lon !in -180.0..180.0) { lat = null; lon = null }
            val alt = p.numOrNull("alt")
            val hr = p.numOrNull("hr")?.toInt()?.takeIf { it in 1..254 }
            val cad = p.numOrNull("cad")?.toInt()?.takeIf { it in 1..250 }
            out.add(Raw(ts, lat, lon, alt, hr, cad))
        }
        return out.sortedBy { it.ts }
    }

    /**
     * Lintasan gabungan, diurutkan menurut waktu. Kosong bila titik GPS kurang dari dua (tidak ada rute yang bisa
     * dibangun). `t` dalam epoch milidetik sesuai kontrak [com.endurancevault.app.domain.ActBuilder].
     */
    fun merge(points: JSONArray): List<Pt> {
        val raw = parse(points)
        val gps = raw.filter { it.hasGps }
        if (gps.size < 2) return emptyList()

        val hrSrc = raw.filter { it.hr != null }
        val hr = Series(hrSrc.map { it.ts }, hrSrc.map { it.hr!!.toDouble() })
        val cadSrc = raw.filter { it.cad != null }
        val cad = Series(cadSrc.map { it.ts }, cadSrc.map { it.cad!!.toDouble() })
        // Altitude barometer = sampel tanpa GPS; lebih halus daripada altitude GPS sehingga D+/D− lebih akurat.
        val baroSrc = raw.filter { !it.hasGps && it.alt != null }
        val useBaro = baroSrc.size >= MIN_BARO_SAMPLES
        val baro = Series(baroSrc.map { it.ts }, baroSrc.map { it.alt!! })

        return gps.map { p ->
            val alt = if (useBaro) baro.interpolate(p.ts, MAX_GAP_SEC) else p.alt
            Pt(
                la = p.lat!!, lo = p.lon!!, t = p.ts * 1000.0,
                e = alt ?: Double.NaN,
                h = (p.hr?.toDouble() ?: hr.nearest(p.ts, MAX_GAP_SEC)) ?: Double.NaN,
                c = (p.cad?.toDouble() ?: cad.nearest(p.ts, MAX_GAP_SEC)) ?: Double.NaN,
            )
        }
    }
}
