package com.endurancevault.app.data

import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteStatement
import android.net.Uri
import android.util.Base64
import androidx.room.withTransaction
import com.endurancevault.app.EnduranceVaultApp
import com.joyodigitama.huaweiwear.SyncStore
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedWriter
import java.io.File
import java.io.FilterOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Ringkasan isi cadangan, untuk ditampilkan sebelum dipulihkan atau setelah dibuat. */
class BackupSummary(
    val createdAt: Long,
    val appVersion: String,
    /** activity, daily, gear, kv, acts, dan `watch.<tabel>`. */
    val counts: Map<String, Int>,
    val hasPhoto: Boolean,
    val hasWebImport: Boolean,
    val sizeBytes: Long = 0,
) {
    val activities get() = counts["activity"] ?: 0
    val activityDetails get() = counts["acts"] ?: 0
    val daily get() = counts["daily"] ?: 0
    val gear get() = counts["gear"] ?: 0
    val sleepSegments get() = counts["watch.sleep_segments"] ?: 0
    val stepSamples get() = counts["watch.step_samples"] ?: 0
    val watchWorkouts get() = counts["watch.workouts"] ?: 0
}

/**
 * Cadangan lengkap native: satu berkas `.zip` berisi seluruh data aplikasi.
 *
 * Isi zip: `manifest.json`, `room/` (*.jsonl) (aktivitas, catatan harian, gear, data pendamping),
 * `acts/` (*.json) (rute, split, grafik), `watch/` (*.jsonl) (database jam: tidur, langkah, HR, HRV, workout),
 * `prefs/` (*.json) (pengaturan), `profile/photo.bin` (foto profil) dan `web/` (*.json) (salinan impor web terakhir).
 * Rahasia (API key AI, kunci pairing jam) sengaja tidak ikut karena berkas tidak terenkripsi.
 */
object NativeBackup {
    private const val MAX_ENTRY_BYTES = 1L shl 30        // 1 GB per entri
    private const val MAX_TOTAL_BYTES = 3L shl 30        // 3 GB seluruhnya (pelindung zip bomb)
    private const val MAX_PHOTO_BYTES = 20 * 1024 * 1024
    private const val KEEP_SAFETY_COPIES = 2

    fun fileName(now: Date = Date()): String =
        "EnduranceVault-cadangan-" + SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(now) + ".zip"

    /* ====================================================================== */
    /* Ekspor                                                                  */
    /* ====================================================================== */

    private class RoomRows(
        val activities: List<ActivityEntity>, val daily: List<DailyEntity>,
        val gear: List<GearEntity>, val kv: List<KvEntity>,
    )

    private class CountingOutputStream(out: OutputStream) : FilterOutputStream(out) {
        var count = 0L
        override fun write(b: Int) { out.write(b); count++ }
        override fun write(b: ByteArray, off: Int, len: Int) { out.write(b, off, len); count += len }
    }

    private fun ZipOutputStream.entry(name: String, block: (BufferedWriter) -> Unit) {
        putNextEntry(ZipEntry(name))
        val w = BufferedWriter(OutputStreamWriter(this, Charsets.UTF_8))
        block(w)
        w.flush()                  // jangan ditutup: menutup penulis akan menutup seluruh zip
        closeEntry()
    }

    private fun ZipOutputStream.jsonl(name: String, rows: List<JSONObject>) = entry(name) { w ->
        for (r in rows) { w.write(r.toString()); w.write("\n") }
    }

    private fun versionName(ctx: Context): String =
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: ""

    /** Tulis cadangan lengkap ke [sink]. Dipanggil dari thread IO. */
    suspend fun export(app: EnduranceVaultApp, sink: OutputStream): BackupSummary {
        val counter = CountingOutputStream(sink.buffered(64 * 1024))
        val counts = LinkedHashMap<String, Int>()
        val created = System.currentTimeMillis()
        // Satu transaksi agar keempat tabel berasal dari saat yang sama.
        val rows = app.db.withTransaction {
            RoomRows(app.db.activities().all(), app.db.companion().allDaily(), app.db.companion().allGear(), app.db.companion().allKv())
        }
        var photo = false
        var webName: String? = null
        ZipOutputStream(counter).use { zip ->
            zip.jsonl("room/activity.jsonl", rows.activities.map(BackupCodec::activityToJson)); counts["activity"] = rows.activities.size
            zip.jsonl("room/daily.jsonl", rows.daily.map(BackupCodec::dailyToJson)); counts["daily"] = rows.daily.size
            zip.jsonl("room/gear.jsonl", rows.gear.map(BackupCodec::gearToJson)); counts["gear"] = rows.gear.size
            zip.jsonl("room/kv.jsonl", rows.kv.map(BackupCodec::kvToJson)); counts["kv"] = rows.kv.size

            var actFiles = 0
            for (f in app.acts.detailFiles()) {
                zip.putNextEntry(ZipEntry("acts/${f.name}"))
                f.inputStream().use { it.copyTo(zip) }
                zip.closeEntry(); actFiles++
            }
            counts["acts"] = actFiles

            exportWatch(app, zip, counts)

            for (name in BackupCodec.PREF_ALLOWLIST) {
                val all = app.getSharedPreferences(name, Context.MODE_PRIVATE).all
                val skip = if (name == BackupCodec.PHOTO_PREF) setOf(BackupCodec.PHOTO_KEY) else emptySet()
                val json = BackupCodec.prefsToJson(all, skip)
                if (json.length() == 0) continue
                zip.entry("prefs/$name.json") { it.write(json.toString()) }
            }

            readPhoto(app)?.let { bytes ->
                zip.putNextEntry(ZipEntry("profile/photo.bin")); zip.write(bytes); zip.closeEntry(); photo = true
            }

            File(app.filesDir, "imports").listFiles { f -> f.isFile && f.name.matches(Regex("cadangan-web-[0-9-]{1,32}\\.json")) }
                ?.maxByOrNull { it.name }?.let { f ->
                    zip.putNextEntry(ZipEntry("web/${f.name}"))
                    f.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry(); webName = f.name
                }

            // Manifest ditulis terakhir: zip yang terpotong tidak punya manifest sehingga ditolak saat dipulihkan.
            val manifest = JSONObject()
                .put("format", BackupCodec.FORMAT).put("version", BackupCodec.VERSION)
                .put("createdAt", created).put("appVersion", versionName(app))
                .put("counts", JSONObject().also { c -> counts.forEach { (k, v) -> c.put(k, v) } })
                .put("photo", photo).putOpt("web", webName)
            zip.entry("manifest.json") { it.write(manifest.toString(2)) }
        }
        return BackupSummary(created, versionName(app), counts, photo, webName != null, counter.count)
    }

    private fun readPhoto(app: Context): ByteArray? {
        val uriText = app.getSharedPreferences(BackupCodec.PHOTO_PREF, Context.MODE_PRIVATE).getString(BackupCodec.PHOTO_KEY, null)
        if (uriText.isNullOrBlank()) return null
        return runCatching {
            app.contentResolver.openInputStream(Uri.parse(uriText))?.use { ins ->
                val out = java.io.ByteArrayOutputStream()
                val buf = ByteArray(16 * 1024)
                while (true) {
                    val n = ins.read(buf); if (n < 0) break
                    out.write(buf, 0, n)
                    if (out.size() > MAX_PHOTO_BYTES) return@runCatching null
                }
                out.toByteArray().takeIf { it.isNotEmpty() }
            }
        }.getOrNull()
    }

    private fun watchDbFile(app: Context) = File(File(app.filesDir, "SQLite"), "joyofit.db")  // sama dengan SyncStore.DATABASE_NAME (privat)

    private fun watchTables(db: SQLiteDatabase): List<String> =
        db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT LIKE 'android_%' ORDER BY name", null)
            .use { c -> buildList { while (c.moveToNext()) add(c.getString(0)) } }

    /** Database jam (tidur, langkah, HR, HRV, workout, dll.) dibuang per tabel sebagai JSON baris-demi-baris. */
    private fun exportWatch(app: Context, zip: ZipOutputStream, counts: MutableMap<String, Int>) {
        if (!watchDbFile(app).exists()) return
        val store = SyncStore(app)
        try {
            store.read { db ->
                for (t in watchTables(db)) {
                    if (t in BackupCodec.WATCH_EXCLUDED || !t.matches(Regex("[a-z0-9_]{1,64}"))) continue
                    var n = 0
                    zip.entry("watch/$t.jsonl") { w ->
                        db.rawQuery("SELECT * FROM \"$t\"", null).use { c ->
                            w.write(JSONArray(c.columnNames.toList()).toString()); w.write("\n")
                            while (c.moveToNext()) { w.write(cursorRow(c).toString()); w.write("\n"); n++ }
                        }
                    }
                    counts["watch.$t"] = n
                }
            }
        } finally { store.close() }
    }

    private fun cursorRow(c: Cursor): JSONArray {
        val row = JSONArray()
        for (i in 0 until c.columnCount) {
            when (c.getType(i)) {
                Cursor.FIELD_TYPE_INTEGER -> row.put(c.getLong(i))
                Cursor.FIELD_TYPE_FLOAT -> c.getDouble(i).let { if (it.isFinite()) row.put(it) else row.put(JSONObject.NULL) }
                Cursor.FIELD_TYPE_STRING -> row.put(c.getString(i))
                Cursor.FIELD_TYPE_BLOB -> row.put(JSONObject().put("b", Base64.encodeToString(c.getBlob(i), Base64.NO_WRAP)))
                else -> row.put(JSONObject.NULL)
            }
        }
        return row
    }

    /* ====================================================================== */
    /* Membaca cadangan ke folder staging                                      */
    /* ====================================================================== */

    /**
     * Ekstrak zip ke [staging] (hanya entri yang dikenal, nama berkas dari pola ketat), periksa manifest dan
     * kelengkapan isi. Belum mengubah data aplikasi sama sekali.
     */
    fun stage(input: InputStream, staging: File): BackupSummary {
        staging.deleteRecursively()
        staging.mkdirs()
        try {
            var total = 0L
            ZipInputStream(input.buffered(64 * 1024)).use { zin ->
                while (true) {
                    val e = zin.nextEntry ?: break
                    if (e.isDirectory) continue
                    val ref = BackupCodec.classify(e.name) ?: continue
                    val dir = if (ref.dir.isEmpty()) staging else File(staging, ref.dir).apply { mkdirs() }
                    var size = 0L
                    File(dir, ref.file).outputStream().buffered().use { out ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = zin.read(buf); if (n < 0) break
                            size += n; total += n
                            if (size > MAX_ENTRY_BYTES || total > MAX_TOTAL_BYTES) throw BackupException("Isi cadangan terlalu besar.")
                            out.write(buf, 0, n)
                        }
                    }
                }
            }
            val manifestFile = File(staging, "manifest.json")
            if (!manifestFile.exists()) throw BackupException(
                "Berkas ini bukan cadangan .zip EnduranceVault, atau berkasnya terpotong. Untuk cadangan versi web (.json) pakai \"Impor cadangan web\".",
            )
            val m = try { JSONObject(manifestFile.readText(Charsets.UTF_8)) } catch (e: Exception) { throw BackupException("Manifest cadangan rusak.") }
            if (m.optString("format") != BackupCodec.FORMAT) throw BackupException("Berkas ini bukan cadangan EnduranceVault.")
            if (m.optInt("version", 0) > BackupCodec.VERSION) throw BackupException("Cadangan dibuat oleh aplikasi yang lebih baru. Perbarui aplikasi dulu.")
            val countsJson = m.optJSONObject("counts") ?: JSONObject()
            val counts = LinkedHashMap<String, Int>()
            for (k in countsJson.keys()) counts[k] = countsJson.optInt(k)
            verifyComplete(staging, counts)
            return BackupSummary(
                createdAt = m.optLong("createdAt"), appVersion = m.optString("appVersion"), counts = counts,
                hasPhoto = File(staging, "profile/photo.bin").exists(), hasWebImport = File(staging, "web").list()?.isNotEmpty() == true,
            )
        } catch (e: BackupException) {
            staging.deleteRecursively(); throw e
        } catch (e: Exception) {
            staging.deleteRecursively()
            throw BackupException("Cadangan tidak bisa dibaca: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun lineCount(f: File): Int = f.bufferedReader(Charsets.UTF_8).useLines { seq -> seq.count { it.isNotBlank() } }

    private fun verifyComplete(staging: File, counts: Map<String, Int>) {
        fun bad(what: String): Nothing = throw BackupException("Cadangan tidak lengkap ($what). Buat cadangan baru lalu coba lagi.")
        for (t in listOf("activity", "daily", "gear", "kv")) {
            val f = File(staging, "room/$t.jsonl")
            if (!f.exists() || lineCount(f) != (counts[t] ?: 0)) bad("data $t")
        }
        val actFiles = File(staging, "acts").list()?.size ?: 0
        if (actFiles != (counts["acts"] ?: 0)) bad("rute dan grafik")
        for ((k, n) in counts) {
            if (!k.startsWith("watch.")) continue
            val f = File(staging, "watch/${k.removePrefix("watch.")}.jsonl")
            if (!f.exists() || lineCount(f) - 1 != n) bad("data jam ${k.removePrefix("watch.")}")
        }
    }

    /* ====================================================================== */
    /* Pemulihan                                                               */
    /* ====================================================================== */

    private fun readJsonl(f: File): List<JSONObject> =
        f.bufferedReader(Charsets.UTF_8).useLines { seq -> seq.filter { it.isNotBlank() }.map { JSONObject(it) }.toList() }

    /**
     * Pulihkan dari [staging] (hasil [stage]). Semua baris didekode lebih dulu supaya berkas rusak gagal sebelum
     * data apa pun diubah, lalu salinan pengaman dibuat otomatis, kemudian data diganti. Tabel Room dan database jam
     * masing-masing dipulihkan dalam satu transaksi.
     * @return ringkasan satu kalimat untuk ditampilkan
     */
    suspend fun restore(app: EnduranceVaultApp, staging: File): String {
        // 1. Dekode & validasi penuh sebelum menyentuh data.
        val activities = readJsonl(File(staging, "room/activity.jsonl")).map(BackupCodec::activityFromJson)
        val daily = readJsonl(File(staging, "room/daily.jsonl")).map(BackupCodec::dailyFromJson)
        val gear = readJsonl(File(staging, "room/gear.jsonl")).map(BackupCodec::gearFromJson)
        val kv = readJsonl(File(staging, "room/kv.jsonl")).map(BackupCodec::kvFromJson)
        val prefs = File(staging, "prefs").listFiles { f -> f.isFile && f.name.endsWith(".json") }.orEmpty()
            .associate { f -> f.name.removeSuffix(".json") to BackupCodec.prefsFromJson(JSONObject(f.readText(Charsets.UTF_8))) }
            .filterKeys { it in BackupCodec.PREF_ALLOWLIST }

        // 2. Salinan pengaman data saat ini. Gagal = pemulihan dibatalkan.
        val safety = writeSafetyCopy(app)

        // 3. Berkas detail (tambah dulu, hapus yang usang sesudah database berhasil diganti).
        val actsDir = File(staging, "acts")
        app.acts.installAllFiles(actsDir)

        // 4. Room dalam satu transaksi.
        app.db.withTransaction {
            app.db.activities().replaceEverything(activities)
            app.db.companion().replaceAll(daily, gear, kv)
        }
        app.acts.deleteFilesExcept(actsDir.list()?.toSet().orEmpty())

        // 5. Database jam.
        val watchRows = restoreWatch(app, File(staging, "watch"))

        // 6. Foto dan pengaturan. Kelompok pengaturan yang tidak ada di cadangan dikosongkan agar hasilnya sama persis dengan saat cadangan dibuat.
        val photoFile = File(staging, "profile/photo.bin")
        val photoTarget = File(app.filesDir, "profile_photo.bin")
        if (photoFile.exists()) photoFile.copyTo(photoTarget, overwrite = true) else photoTarget.delete()
        for (name in BackupCodec.PREF_ALLOWLIST) {
            val e = app.getSharedPreferences(name, Context.MODE_PRIVATE).edit().clear()
            for ((k, v) in prefs[name].orEmpty()) when (v) {
                is String -> e.putString(k, v)
                is Int -> e.putInt(k, v)
                is Long -> e.putLong(k, v)
                is Float -> e.putFloat(k, v)
                is Boolean -> e.putBoolean(k, v)
                is Set<*> -> e.putStringSet(k, v.filterIsInstance<String>().toSet())
            }
            if (name == BackupCodec.PHOTO_PREF && photoFile.exists()) {
                e.putString(BackupCodec.PHOTO_KEY, Uri.fromFile(photoTarget).toString())
            }
            e.commit()
        }

        // 7. Salinan impor web terakhir (berisi bagian cadangan web yang tidak dipetakan ke tabel).
        File(staging, "web").listFiles()?.forEach { f ->
            val dir = File(app.filesDir, "imports").apply { mkdirs() }
            f.copyTo(File(dir, f.name), overwrite = true)
        }

        return "${activities.size} aktivitas (${activities.count { it.detailFile != null }} dengan rute dan grafik), " +
            "${daily.size} catatan harian, ${gear.size} gear, $watchRows baris data jam, dan ${prefs.size} kelompok pengaturan dipulihkan. " +
            "Salinan pengaman data sebelumnya: ${safety.name}."
    }

    /** Simpan salinan pengaman di penyimpanan aplikasi; hanya [KEEP_SAFETY_COPIES] terbaru yang disimpan. */
    private suspend fun writeSafetyCopy(app: EnduranceVaultApp): File {
        val dir = File(app.filesDir, "backups").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        val f = File(dir, "sebelum-pulihkan-$stamp.zip")
        try {
            f.outputStream().use { export(app, it) }
        } catch (e: Exception) {
            f.delete()
            throw BackupException("Salinan pengaman gagal dibuat, pemulihan dibatalkan: ${e.message ?: e.javaClass.simpleName}")
        }
        dir.listFiles { x -> x.name.startsWith("sebelum-pulihkan-") }?.sortedByDescending { it.name }
            ?.drop(KEEP_SAFETY_COPIES)?.forEach { it.delete() }
        return f
    }

    private fun restoreWatch(app: Context, dir: File): Int {
        val files = dir.listFiles { f -> f.isFile && f.name.endsWith(".jsonl") }.orEmpty()
        if (files.isEmpty()) return 0
        var rows = 0
        val store = SyncStore(app)
        try {
            store.read { db ->
                val existing = watchTables(db).toSet()
                db.beginTransaction()
                try {
                    for (f in files) {
                        val t = f.name.removeSuffix(".jsonl")
                        if (t !in existing || t in BackupCodec.WATCH_EXCLUDED) continue
                        rows += restoreTable(db, t, f)
                    }
                    db.setTransactionSuccessful()
                } finally { db.endTransaction() }
            }
        } finally { store.close() }
        return rows
    }

    /** Ganti isi tabel [t]; kolom yang tidak ada lagi di skema aplikasi saat ini dilewati. */
    private fun restoreTable(db: SQLiteDatabase, t: String, f: File): Int {
        val cols = db.rawQuery("PRAGMA table_info(\"$t\")", null).use { c ->
            val i = c.getColumnIndexOrThrow("name")
            buildSet { while (c.moveToNext()) add(c.getString(i)) }
        }
        var n = 0
        f.bufferedReader(Charsets.UTF_8).use { r ->
            val headerLine = r.readLine() ?: return 0
            val header = JSONArray(headerLine)
            val names = List(header.length()) { header.getString(it) }
            val idx = names.indices.filter { names[it] in cols }
            db.execSQL("DELETE FROM \"$t\"")
            if (idx.isEmpty()) return 0
            val sql = "INSERT OR REPLACE INTO \"$t\" (" + idx.joinToString(",") { "\"${names[it]}\"" } +
                ") VALUES (" + idx.joinToString(",") { "?" } + ")"
            db.compileStatement(sql).use { st ->
                while (true) {
                    val line = r.readLine() ?: break
                    if (line.isBlank()) continue
                    val row = JSONArray(line)
                    st.clearBindings()
                    idx.forEachIndexed { pos, i -> bind(st, pos + 1, row.opt(i)) }
                    st.executeInsert(); n++
                }
            }
        }
        return n
    }

    private fun bind(st: SQLiteStatement, i: Int, v: Any?) {
        when {
            v == null || v == JSONObject.NULL -> st.bindNull(i)
            v is Int -> st.bindLong(i, v.toLong())
            v is Long -> st.bindLong(i, v)
            v is Double -> st.bindDouble(i, v)
            v is Boolean -> st.bindLong(i, if (v) 1 else 0)
            v is String -> st.bindString(i, v)
            v is JSONObject -> st.bindBlob(i, Base64.decode(v.optString("b"), Base64.NO_WRAP))
            else -> st.bindString(i, v.toString())
        }
    }
}
