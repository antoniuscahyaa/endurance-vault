package com.endurancevault.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.domain.ActivityAnalytics
import com.endurancevault.app.domain.RouteAnalytics
import com.endurancevault.app.domain.ActDetail
import com.endurancevault.app.domain.Js
import com.endurancevault.app.domain.Zones
import com.endurancevault.app.ui.UiState
import com.endurancevault.app.ui.theme.Ember
import kotlin.math.max
import kotlin.math.min

private val ZoneColors = listOf(Color(0xFF7F9CD6), Color(0xFF3F9E86), Color(0xFFD8B04A), Color(0xFFE8844F), Color(0xFFC84B3B))

@Composable
fun ActivityDetailScreen(
    state: UiState, id: Long, load: suspend (ActivityEntity) -> ActDetail?, onBack: () -> Unit,
) {
    val e = state.activities.firstOrNull { it.id == id }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TextButton(onClick = onBack) { Text("‹ Kembali") }
        if (e == null) { Text("Aktivitas tidak ditemukan."); return@Column }
        val loaded by produceState<Pair<Boolean, ActDetail?>>(false to null, e.id) { value = true to load(e) }
        val d = loaded.second

        Text(
            e.name.ifBlank { if (e.type == "bike") "Sepeda" else "Lari" },
            style = MaterialTheme.typography.headlineSmall,
        )
        Text(
            e.dateIso + (e.startTime?.let { " · $it" } ?: ""),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        // Statistik utama: pakai detail bila ada, jika tidak pakai catatan
        val km = d?.km ?: e.km
        val min = d?.movingMin ?: (e.durationSec / 60.0)
        val pace = if (km > 0 && min > 0) min / km else null
        val gain = d?.gain ?: e.gain
        val hr = d?.hr ?: e.avgHr
        val hrMax = d?.hrMax ?: e.maxHr
        EvPanel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth()) {
                    Stat("Jarak", "${fmtKmUi(Math.round(km * 100) / 100.0)} km", Modifier.weight(1f))
                    Stat("Waktu", Js.durStr(min), Modifier.weight(1f))
                    Stat("Pace", pace?.let { Js.paceStr(it) + "/km" } ?: "–", Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth()) {
                    Stat("HR rata-rata", hr?.toString() ?: "–", Modifier.weight(1f))
                    Stat("HR maks", hrMax?.toString() ?: "–", Modifier.weight(1f))
                    Stat("Kadens", (d?.cad)?.toString() ?: "–", Modifier.weight(1f))
                }
                if (gain != null || d?.loss != null) Row(Modifier.fillMaxWidth()) {
                    Stat("D+", gain?.let { "$it m" } ?: "–", Modifier.weight(1f))
                    Stat("D−", d?.loss?.let { "$it m" } ?: "–", Modifier.weight(1f))
                    Stat("Pace GAP", d?.gapPace?.let { Js.paceStr(it) + "/km" } ?: "–", Modifier.weight(1f))
                }
            }
        }
        val watchMeta = runCatching { org.json.JSONObject(e.note).takeIf { it.optString("source") == "huawei-watch" } }.getOrNull()
        if (watchMeta != null) {
            Text("Data tersinkron langsung dari Huawei Watch", color = MaterialTheme.colorScheme.onSurfaceVariant)
            val teA = watchMeta.optDouble("aerobicEffect", 0.0)
            val teN = watchMeta.optDouble("anaerobicEffect", 0.0)
            val recovery = watchMeta.optDouble("recoveryHours", 0.0)
            val load = watchMeta.optInt("workoutLoad", 0)
            if (teA > 0 || teN > 0 || recovery > 0 || load > 0) {
                Text(
                    buildString {
                        if (teA > 0) append("TE aerobik %.1f/5".format(teA))
                        if (teN > 0) append(if (isNotEmpty()) " · " else "").append("TE anaerobik %.1f/5".format(teN))
                        if (recovery > 0) append(if (isNotEmpty()) " · " else "").append("Recovery %.1f jam".format(recovery))
                        if (load > 0) append(if (isNotEmpty()) " · " else "").append("Load jam $load")
                    },
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            watchMeta.optString("userNote").takeIf { it.isNotBlank() }?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        } else if (e.note.isNotBlank()) Text(e.note, color = MaterialTheme.colorScheme.onSurfaceVariant)

        if (e.detailFile == null) {
            Text(
                "Aktivitas ini belum punya rute dan grafik. Impor berkas FIT, GPX, atau TCX dari tab Progres untuk menambahkannya.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            return@Column
        }
        if (!loaded.first) { Text("Memuat detail…"); return@Column }
        if (d == null) { Text("Detail aktivitas tidak bisa dibaca.", color = MaterialTheme.colorScheme.error); return@Column }

        if (d.hasRoute) {
            Section("Rute")
            RouteView(d)
        }
        if (d.profile.size >= 2) {
            Section("Elevasi")
            LineChart(d.profile, Color(0xFF8FA3B8), invert = false)
            RouteAnalytics.summarize(d.profile)?.let { summary ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stat("Tertinggi", "${Math.round(summary.maxMeters)} m", Modifier.weight(1f))
                    Stat("Terendah", "${Math.round(summary.minMeters)} m", Modifier.weight(1f))
                    Stat("Rentang", "${Math.round(summary.rangeMeters)} m", Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stat("Tanjakan tercuram", summary.steepestUpPercent?.let { "+%.1f%%".format(it) } ?: "–", Modifier.weight(1f))
                    Stat("Turunan tercuram", summary.steepestDownPercent?.let { "%.1f%%".format(it) } ?: "–", Modifier.weight(1f))
                }
            }
            Caption("Profil berdasarkan data elevasi aktivitas. Kemiringan dihitung antar titik profil berjarak minimal 20 m.")
        }
        if (d.paceSeries.size >= 2) {
            Section("Pace")
            LineChart(d.paceSeries, Ember, invert = true)
            Caption("${Js.paceStr(d.paceSeries.minOf { it.second })} (tercepat) – ${Js.paceStr(d.paceSeries.maxOf { it.second })} /km")
        }
        if (d.hrSeries.size >= 2) {
            Section("Detak jantung")
            LineChart(d.hrSeries, Color(0xFFC84B3B), invert = false)
            Caption("${Math.round(d.hrSeries.minOf { it.second })}–${Math.round(d.hrSeries.maxOf { it.second })} bpm")
        }
        if (d.hrHist.isNotEmpty() && d.hrHist.values.sum() > 60) {
            Section("Zona HR")
            ZoneBlock(state, d)
        }
        if (d.segments.isNotEmpty()) {
            Section("Segmen")
            d.segments.forEach { s ->
                Row(Modifier.fillMaxWidth()) {
                    Text(s.name, Modifier.weight(1.2f))
                    Text("${fmtKmUi(s.d)} km", Modifier.weight(1f))
                    Text(Js.paceStr(s.pace), Modifier.weight(1f))
                    Text(s.hr?.toString() ?: "–", Modifier.weight(.8f))
                }
            }
        }
        if (d.splits.isNotEmpty()) {
            Section("Split per km")
            Row(Modifier.fillMaxWidth()) {
                listOf("km", "Pace", "HR", "D+/D−").forEachIndexed { i, h ->
                    Text(h, Modifier.weight(if (i == 3) 1.3f else 1f), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
                }
            }
            val fastest = d.splits.filter { !it.partial }.minByOrNull { it.pace }
            ActivityAnalytics.compareHalves(d.splits)?.let { halves ->
                val delta = if (halves.changePercent >= 0) "+%.1f%%".format(halves.changePercent) else "%.1f%%".format(halves.changePercent)
                EvPanel(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Perbandingan paruh", style = MaterialTheme.typography.titleSmall)
                        Text("Awal ${Js.paceStr(halves.firstPace)} · akhir ${Js.paceStr(halves.secondPace)}")
                        Text(if (halves.changePercent > 1.0) "Paruh kedua melambat $delta" else if (halves.changePercent < -1.0) "Paruh kedua lebih cepat $delta" else "Pace kedua paruh relatif stabil ($delta)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            d.splits.forEach { sp ->
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                    Text(if (sp.partial) fmtKmUi(sp.k) else sp.k.toInt().toString(), Modifier.weight(1f))
                    Text(
                        Js.paceStr(sp.pace), Modifier.weight(1f),
                        color = if (sp === fastest) Ember else MaterialTheme.colorScheme.onSurface,
                    )
                    Text(sp.hr?.toString() ?: "–", Modifier.weight(1f))
                    Text("+${sp.gain}/−${sp.loss}", Modifier.weight(1.3f), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable private fun Section(t: String) = EvGroupTitle(t)
@Composable private fun Caption(t: String) = Text(t, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

@Composable
private fun Stat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
private fun RouteView(d: ActDetail) {
    val w = max(1, d.routeW); val h = max(1, d.routeH)
    val ratio = (w.toFloat() / h).coerceIn(0.6f, 2.2f)
    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.fillMaxWidth().aspectRatio(ratio)) {
            Canvas(Modifier.fillMaxWidth().aspectRatio(ratio)) {
                val sc = min(size.width / w, size.height / h)
                val ox = (size.width - w * sc) / 2; val oy = (size.height - h * sc) / 2
                fun pt(p: Pair<Int, Int>) = Offset(ox + p.first * sc, oy + p.second * sc)
                val path = Path()
                d.route.forEachIndexed { i, p -> val o = pt(p); if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y) }
                drawPath(path, Ember, style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                drawCircle(Color(0xFF3F9E86), 6.dp.toPx(), pt(d.route.first()))
                drawCircle(Color(0xFFC84B3B), 6.dp.toPx(), pt(d.route.last()))
            }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Box(Modifier.size(9.dp).background(Color(0xFF3F9E86), androidx.compose.foundation.shape.CircleShape))
                    Text("Mulai", style = MaterialTheme.typography.labelSmall)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Box(Modifier.size(9.dp).background(Color(0xFFC84B3B), androidx.compose.foundation.shape.CircleShape))
                    Text("Selesai", style = MaterialTheme.typography.labelSmall)
                }
            }
            Text("Garis menunjukkan jejak GPS yang tersimpan; peta dasar tidak tersedia pada tampilan offline ini.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/** Grafik garis sederhana. [invert]: nilai kecil di atas (untuk pace, makin cepat makin tinggi). */
@Composable
private fun LineChart(pts: List<Pair<Double, Double>>, color: Color, invert: Boolean) {
    EvPanel(Modifier.fillMaxWidth()) {
        Canvas(Modifier.fillMaxWidth().height(110.dp).padding(12.dp)) {
            val x0 = pts.first().first; val x1 = pts.last().first
            val lo = pts.minOf { it.second }; val hi = pts.maxOf { it.second }
            val dx = max(1e-9, x1 - x0); val dy = max(1e-9, hi - lo)
            fun pt(p: Pair<Double, Double>): Offset {
                val fx = ((p.first - x0) / dx).toFloat()
                val fy = ((p.second - lo) / dy).toFloat()
                return Offset(fx * size.width, (if (invert) fy else 1f - fy) * size.height)
            }
            val path = Path()
            pts.forEachIndexed { i, p -> val o = pt(p); if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y) }
            drawPath(path, color, style = Stroke(width = 2.dp.toPx(), join = StrokeJoin.Round))
        }
    }
}

@Composable
private fun ZoneBlock(state: UiState, d: ActDetail) {
    val zc = Zones.cuts(state.settings)
    val secs = Zones.secs(d.hrHist, zc)
    val total = max(1.0, secs.sum())
    Row(Modifier.fillMaxWidth().height(14.dp)) {
        secs.forEachIndexed { i, v ->
            if (v > 0) Box(Modifier.weight((v / total).toFloat()).height(14.dp).background(ZoneColors[i]))
        }
    }
    val bands = zc.bands()
    secs.forEachIndexed { i, v ->
        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).background(ZoneColors[i]))
            Text("  Z${i + 1}  ${bands[i]} bpm", Modifier.weight(2f))
            Text(if (v > 0) Js.durStr(v / 60) else "–", Modifier.weight(1f))
            Text("${Math.round(v / total * 100)}%", Modifier.weight(.6f), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    Caption("Batas zona: ${if (zc.mode == "hrr") "cadangan HR (HRR)" else "LTHR ${zc.lthr} bpm"}, HR maks ${zc.maxHr} bpm.")
}
