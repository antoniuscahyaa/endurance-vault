package com.endurancevault.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import com.endurancevault.app.domain.WatchDock
import com.endurancevault.app.domain.WatchModel
import com.endurancevault.app.domain.WatchWx
import kotlinx.coroutines.delay

/**
 * Mock-up jam (gambar polos, tanpa merek) berproporsi seperti Huawei Watch Fit 4, meniru watchface pilihan: tanggal, jam berdetik,
 * kartu cuaca, kartu waktu pemulihan, tiga cincin (baterai, HR, tidur), dan jam terbenam. Semua angka adaptif; tanpa data tampil "–".
 * Port dari jamWatchSvg + jamWatchTick di versi web. Kanvas virtual 104 x 150.
 */
private const val FW = 104f
private const val FH = 150f

private const val HEART = "M12 21.2l-1.4-1.3C5.4 15.2 2 12.1 2 8.3 2 5.2 4.4 3 7.4 3c1.7 0 3.4.8 4.6 2.1C13.2 3.8 14.9 3 16.6 3 19.6 3 22 5.2 22 8.3c0 3.8-3.4 6.9-8.6 11.6z"
private const val MOON = "M20.5 14.6A8.8 8.8 0 019.4 3.5a.6.6 0 00-.8-.7A9.5 9.5 0 1021.2 15.4a.6.6 0 00-.7-.8z"
private const val CLOUD = "M7 15a4 4 0 010-8 5 5 0 019.6 1A3.5 3.5 0 0116.5 15z"
private const val DROPS = "M9 18l-1 2M13 18l-1 2M17 18l-1 2"

@Composable
fun WatchFace(m: WatchModel, wx: WatchWx?, modifier: Modifier = Modifier) {
    // Jam di mock-up berdetik: dihitung dari jam ponsel menurut zona waktu jam.
    val tick by produceState(System.currentTimeMillis() / 1000) { while (true) { delay(1000); value = System.currentTimeMillis() / 1000 } }
    val face = WatchDock.faceClock(tick, m.tzMin)
    val tm = rememberTextMeasurer()
    val cs = MaterialTheme.colorScheme
    val strap = lerpInk(cs.onSurface, cs.surface, 0.18f); val body = lerpInk(cs.onSurface, cs.surface, 0.36f); val btn = lerpInk(cs.onSurface, cs.surface, 0.46f)
    val hr = m.tile["hr"]?.value?.takeIf { it.contains("bpm") }?.substringBefore(" ")?.toIntOrNull()
    val bat = m.battery
    val slH = m.sleep?.let { it.asleep / 60.0 }
    val rec = if (m.recH > 0.05) Math.ceil(m.recH).toInt() else 0
    val hmax = m.hrMax
    Canvas(modifier.width(104.dp).height((104f * FH / FW).dp).clearAndSetSemantics { }) {
        val sc = size.width / FW
        fun rr(c: Color, x: Float, y: Float, w: Float, h: Float, r: Float, a: Float = 1f) =
            drawRoundRect(c.copy(alpha = c.alpha * a), Offset(x * sc, y * sc), Size(w * sc, h * sc), CornerRadius(r * sc))
        fun t(s: String, x: Float, y: Float, anchor: Int, size: Float, weight: FontWeight, color: Color = Color.White, a: Float = 1f) =
            ftext(tm, s, x, y, anchor, size, weight, color.copy(alpha = a), sc)
        rr(strap, 31f, 0f, 42f, 34f, 8f); rr(strap, 31f, 116f, 42f, 34f, 8f)
        rr(body, 8f, 22f, 88f, 106f, 26f); rr(btn, 96f, 58f, 4f, 22f, 2f)
        rr(Color.Black, 13f, 27f, 78f, 96f, 22f)
        t(face.second, 52f, 37.9f, 1, 6.2f, FontWeight.Medium)
        t(face.first, 52f, 50.4f, 1, 13.5f, FontWeight.SemiBold)
        // kartu cuaca
        rr(Color(0xFF3F5A8F), 18.2f, 56.1f, 31.2f, 30.7f, 5.2f)
        t(if (wx != null) "${wx.t}°" else "–", 33.8f, 64.3f, 1, 7.8f, FontWeight.Bold)
        t(wx?.hi?.let { "$it°" } ?: "–", 20.3f, 68.6f, 0, 3.6f, FontWeight.Normal)
        t(wx?.lo?.let { "$it°" } ?: "–", 47.3f, 68.6f, 2, 3.6f, FontWeight.Normal)
        for (i in 0 until 3) {
            val h = wx?.hours?.getOrNull(i); val cx = 24.8f + 9 * i
            t(h?.h ?: "–", cx, 72.6f, 1, 2.9f, FontWeight.Normal, a = 0.8f)
            if (h != null) wxIcon(cx, 73.4f, h.kind, sc)
            t(h?.let { "${it.t}°" } ?: "–", cx, 83.2f, 1, 3.4f, FontWeight.Normal)
        }
        // kartu waktu pemulihan
        rr(Color(0xFFF08A4B), 54.6f, 56.1f, 31.2f, 30.7f, 5.2f)
        t("Recovery time", 70.2f, 61.6f, 1, 3.3f, FontWeight.Normal, a = 0.85f)
        t("$rec", 70.2f, 72.4f, 1, 9.9f, FontWeight.Bold)
        t("h", 70.2f + 5.2f, 72.4f, 0, 4.4f, FontWeight.Medium)
        rr(Color.White, 58.2f, 75.2f, 24f, 7.2f, 3.6f, 0.88f)
        t("▶ Work out", 70.2f, 80.3f, 1, 3.9f, FontWeight.SemiBold, Color(0xFFF08A4B))
        // tiga cincin
        ring(29.8f, if (bat != null && bat <= 20) Color(0xFFE5534B) else Color(0xFF1FA34A), if (bat != null) bat / 100f else 0f, "bat", if (bat != null) "$bat%" else "–", tm, sc)
        ring(52f, Color(0xFFE8325A), if (hr != null) ((hr - 40f) / (hmax - 40f)) else 0f, "heart", hr?.toString() ?: "–", tm, sc)
        ring(74.2f, Color(0xFFB79CFF), if (slH != null) (slH / 8).toFloat() else 0f, "moon", if (slH != null) WatchDock.dec(slH, 1) else "–", tm, sc)
        t("Sunset " + (wx?.sun?.takeIf { it.isNotEmpty() } ?: "–"), 52f, 116.8f, 1, 5.5f, FontWeight.Medium)
    }
}

private fun lerpInk(ink: Color, surface: Color, f: Float): Color =
    Color(ink.red * f + surface.red * (1 - f), ink.green * f + surface.green * (1 - f), ink.blue * f + surface.blue * (1 - f), 1f)

private fun DrawScope.ftext(tm: TextMeasurer, s: String, x: Float, y: Float, anchor: Int, size: Float, weight: FontWeight, color: Color, sc: Float) {
    val r = tm.measure(s, TextStyle(color = color, fontSize = (size * sc).toSp(), fontWeight = weight))
    val w = r.size.width.toFloat()
    val left = when (anchor) { 1 -> x * sc - w / 2f; 2 -> x * sc - w; else -> x * sc }
    drawText(r, topLeft = Offset(left, y * sc - r.firstBaseline))
}

private fun DrawScope.svgPath(d: String, color: Color, tx: Float, ty: Float, s: Float, sc: Float, center: Float = 12f) {
    val path = PathParser().parsePathString(d).toPath()
    withTransform({ scale(sc, sc, Offset.Zero); translate(tx, ty); scale(s, s, Offset.Zero); translate(-center, -center) }) { drawPath(path, color) }
}

private fun DrawScope.wxIcon(cx: Float, y: Float, kind: String, sc: Float) {
    if (kind == "sun") { drawCircle(Color(0xFFFFD45E), 1.9f * sc, Offset(cx * sc, (y + 2.4f) * sc)); return }
    val cloud = PathParser().parsePathString(CLOUD).toPath()
    withTransform({ scale(sc, sc, Offset.Zero); translate(cx - 2.4f, y); scale(0.2f, 0.2f, Offset.Zero) }) {
        drawPath(cloud, Color(0xFFE9EDF6))
        if (kind == "rain") drawPath(PathParser().parsePathString(DROPS).toPath(), Color(0xFF8FC2FF), style = Stroke(1.8f, cap = StrokeCap.Round))
    }
}

/** Cincin kemajuan: ikon (jantung, bulan, atau baterai) di tengah atas dan nilai di bawahnya. */
private fun DrawScope.ring(cx: Float, col: Color, p: Float, kind: String, value: String, tm: TextMeasurer, sc: Float) {
    val pc = p.coerceIn(0f, 1f); val rad = 8.2f * 1.05f; val stroke = 1.8f * 1.05f
    val c = Offset(cx * sc, 100f * sc)
    drawCircle(col.copy(alpha = 0.28f), rad * sc, c, style = Stroke(stroke * sc))
    drawArc(col, -90f, 360f * pc, false, topLeft = Offset(c.x - rad * sc, c.y - rad * sc), size = Size(rad * 2 * sc, rad * 2 * sc), style = Stroke(stroke * sc, cap = StrokeCap.Round))
    val ix = cx; val iy = 100f - 3.7f * 1.05f
    when (kind) {
        "heart" -> svgPath(HEART, col, ix, iy, 0.17f * 1.05f, sc)
        "moon" -> svgPath(MOON, col, ix, iy, 0.17f * 1.05f, sc)
        else -> {
            val s = 0.85f * 1.05f
            drawRoundRect(col, Offset((ix - 3f * s) * sc, (iy - 1.9f * s) * sc), Size(5.7f * s * sc, 3.8f * s * sc), CornerRadius(1f * s * sc), style = Stroke(0.55f * s * sc))
            drawRoundRect(col, Offset((ix + 2.95f * s) * sc, (iy - 0.75f * s) * sc), Size(0.75f * s * sc, 1.5f * s * sc), CornerRadius(0.3f * s * sc))
        }
    }
    ftext(tm, value, cx, 100f + 3.9f * 1.05f, 1, 5.6f * 1.05f, FontWeight.Medium, Color.White, sc)
}
