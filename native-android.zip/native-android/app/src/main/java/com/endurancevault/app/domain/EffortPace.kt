package com.endurancevault.app.domain

import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max

/**
 * Effort pace: pace yang setara dengan usaha sesi ini bila dilari datar, pada suhu netral (15 °C).
 *
 *   effort = GAP × (1 − k × max(0, T − 15))
 *
 * - GAP sudah membuang pengaruh tanjakan dan turunan (Minetti).
 * - T adalah suhu "terasa" saat lari (jika tidak ada, suhu udara).
 * - k adalah sensitivitas panasmu sendiri, per °C di atas 15 °C. Dihitung dari riwayat lari yang punya cuaca
 *   dan HR: indeks efisiensi = (kecepatan GAP) ÷ (HR rata-rata ÷ LTHR), lalu regresi ln(indeks) terhadap suhu.
 *   Bila riwayat belum cukup (kurang dari 8 lari atau rentang suhu kurang dari 4 °C), dipakai k bawaan.
 */
object EffortPace {
    const val NEUTRAL_C = 15.0
    const val DEFAULT_K = 0.0013          // 0,13% lebih lambat per °C di atas 15 °C
    private const val MIN_K = 0.0004
    private const val MAX_K = 0.0040
    private const val MIN_RUNS = 8
    private const val MIN_SPREAD_C = 4.0

    data class Heat(val k: Double, val personal: Boolean, val runs: Int)
    data class Result(val pace: Double, val heatPct: Double, val tempC: Double?, val heat: Heat)

    private fun effTemp(w: ActWeather?, fallback: Double?): Double? = w?.feelsLikeC ?: w?.tempC ?: fallback

    /** Sensitivitas panas pribadi dari riwayat; [lthr] dipakai menormalkan HR antar sesi. */
    fun calibrate(details: Collection<ActDetail>, lthr: Int, skip: ActDetail? = null): Heat {
        if (lthr < 100) return Heat(DEFAULT_K, false, 0)
        val xs = ArrayList<Double>(); val ys = ArrayList<Double>()
        for (d in details) {
            if (d === skip || d.bike || d.km < 3.0) continue
            val hr = d.hr?.takeIf { it in 90..220 } ?: continue
            val pace = d.gapPace?.takeIf { it > 0 } ?: d.avgPace ?: continue
            val t = effTemp(d.weather, d.weatherFeelsLikeC ?: d.weatherTempC) ?: continue
            // hanya sesi aerobik (HR ≤ LTHR) agar sesi interval/tempo tidak merusak regresi
            if (hr > lthr) continue
            val idx = (1.0 / pace) / (hr.toDouble() / lthr)
            if (idx.isFinite() && idx > 0) { xs += t; ys += ln(idx) }
        }
        if (xs.size < MIN_RUNS || (xs.max() - xs.min()) < MIN_SPREAD_C) return Heat(DEFAULT_K, false, xs.size)
        val mx = xs.average(); val my = ys.average()
        var sxy = 0.0; var sxx = 0.0
        for (i in xs.indices) { sxy += (xs[i] - mx) * (ys[i] - my); sxx += (xs[i] - mx) * (xs[i] - mx) }
        if (sxx <= 1e-9) return Heat(DEFAULT_K, false, xs.size)
        val k = (-sxy / sxx).coerceIn(MIN_K, MAX_K)
        return Heat(k, true, xs.size)
    }

    /** [gap] menit/km. Mengembalikan null bila GAP tidak ada. */
    fun compute(gap: Double?, weather: ActWeather?, fallbackTempC: Double?, heat: Heat): Result? {
        if (gap == null || gap <= 0) return null
        val t = effTemp(weather, fallbackTempC)
        val excess = max(0.0, (t ?: NEUTRAL_C) - NEUTRAL_C)
        val factor = (1.0 - heat.k * excess).coerceIn(0.85, 1.0)
        return Result(gap * factor, abs(1.0 - factor) * 100.0, t, heat)
    }
}
