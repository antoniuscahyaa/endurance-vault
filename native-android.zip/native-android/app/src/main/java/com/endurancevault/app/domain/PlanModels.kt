package com.endurancevault.app.domain

import java.time.LocalDate

/** Padanan objek pengaturan `S` di versi web (hanya bagian yang dipakai perencana). */
data class PbPost(val rec: Double, val lvl: Double)
data class PbConv(val wk: Int, val b0: Double, val p0: Double)
data class PbAk(val wk: LocalDate, val km: Double)

data class PlanSettings(
    val name: String = "",
    val rtype: String = "none",          // 5k,10k,hm,fm,none,pb,ultra,ultrar
    val start: LocalDate = LocalDate.now(),
    val race: LocalDate? = null,
    val raceKm: Double? = null,          // hanya untuk trail/ultra
    val raceGain: Double? = null,
    val goalT: String = "",              // h:mm:ss atau mm:ss
    val base: Double = 40.0,
    val peak: Double = 65.0,
    val days: Int = 5,                   // 5 atau 6 hari lari
    val rest: Int = 0,                   // hari libur utama (0=Senin..6=Minggu)
    val rest2: Int = 4,                  // libur kedua (hanya bila 5 hari)
    val longDay: Int = 6,                // hari long run (0=Senin..6=Minggu)
    val hr: Int = 150,
    val thr: String = "164–172",
    val pace: String = "6:30",
    val hrMax: Int? = null,
    val bspd: Double = 20.0,             // kecepatan sepeda km/jam (minggu 6 hari)
    val pbCycle: String = "3",
    val pbFocus: String = "mix",         // mix, thr, vo2, vol
    val pbPost: PbPost? = null,
    val pbConv: PbConv? = null,
    val pbAk: PbAk? = null,
    val evOn: Boolean = false,
    val evDate: LocalDate? = null,
    val evKm: Double = 0.0,
    val evGain: Double = 0.0,
)

object Kinds {
    const val REST = "rest"; const val EASY = "easy"; const val QUALITY = "quality"
    const val MEDIUM = "medium"; const val LONG = "long"; const val RACE = "race"; const val EVENT = "event"
}

object Phases { const val BASE = "base"; const val BUILD = "build"; const val PEAK = "peak"; const val TAPER = "taper" }

class QEst(val min: Int, val km: Int, val old: Double, val ep: Double, val wp: Double)

/** Satu hari rencana. Field opsional sama dengan properti hari di versi web. */
class PDay(
    var date: LocalDate, var d: Int, var kind: String, var grp: String,
    var title: String, var km: Double, var detail: String,
) {
    var role: String? = null
    var gain: Int? = null
    var b2b: Int? = null
    var qk: String? = null
    var qMin: Double? = null
    var qBand: List<Int>? = null
    var trail: Int? = null
    var sim: Boolean = false
    var bench: Boolean = false
    var xtra: Int? = null
    var altMins: Int? = null
    var altKm: Double? = null
    var est: QEst? = null
    internal var mk: ((Int) -> Unit)? = null
    internal var glock: Boolean = false
}

class PWeek(
    var i: Int, val start: LocalDate, val end: LocalDate, val phase: String, val cut: Boolean,
    val rec: Boolean, val race: Boolean, val days: MutableList<PDay>, val km: Double,
)

sealed interface PlanOutcome {
    class Ok(
        val weeks: List<PWeek>, val start: LocalDate, val race: LocalDate, val n: Int,
        val noRace: Boolean, val none: Boolean, val build: Boolean, val pbCycle: Int, val convWk: Int,
    ) : PlanOutcome
    class Err(val message: String) : PlanOutcome
}
