package com.endurancevault.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Language
import androidx.compose.material3.AssistChip
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.endurancevault.app.ui.i18n.Lang
import com.endurancevault.app.ui.i18n.Text
import com.endurancevault.app.ui.theme.cardTint
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private val FabSize = 56.dp
private val FabMargin = 10.dp
private val SuggestionChips = listOf("Ringkas minggu ini", "Boleh naikkan jarak?", "Ganti sesi hari ini")

/**
 * Tombol chat melayang di halaman Beranda. Bisa diseret; saat dilepas meluncur ke tepi kiri/kanan terdekat dan, bila
 * tidak disentuh sekitar 2,5 detik, menyelip setengah lingkaran ke tepi dan memudar. Ketukan membuka halaman chat melayang.
 * Letakkan sebagai saudara konten Beranda di dalam Box yang sama (modifier = fillMaxSize()).
 */
@Composable
fun AiChatFab(
    messages: List<Pair<String, String>>,
    busy: Boolean,
    keySet: Boolean,
    keyHint: String,
    error: String?,
    onSend: (question: String, webSearch: Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    BoxWithConstraints(modifier) {
        val density = LocalDensity.current
        val scope = rememberCoroutineScope()
        val fabPx = with(density) { FabSize.toPx() }
        val marginPx = with(density) { FabMargin.toPx() }
        val tuckPx = with(density) { (FabSize / 2).toPx() }
        val widthPx = with(density) { maxWidth.toPx() }
        val heightPx = with(density) { maxHeight.toPx() }
        val maxX = widthPx - fabPx
        val minY = marginPx
        val maxY = heightPx - fabPx - marginPx

        var open by rememberSaveable { mutableStateOf(false) }
        var onRight by rememberSaveable { mutableStateOf(true) }
        var yFrac by rememberSaveable { mutableFloatStateOf(0.68f) }
        var draft by rememberSaveable { mutableStateOf("") }
        var webSearch by rememberSaveable { mutableStateOf(true) }
        var origin by remember { mutableStateOf(TransformOrigin.Center) }
        var dragging by remember { mutableStateOf(false) }
        var tucked by remember { mutableStateOf(false) }
        var touch by remember { mutableIntStateOf(0) }
        var ready by remember { mutableStateOf(false) }
        val x = remember { Animatable(0f) }
        val y = remember { Animatable(0f) }

        LaunchedEffect(maxX, maxY) {
            if (maxX <= 0f || maxY <= minY) return@LaunchedEffect
            x.snapTo(if (onRight) maxX - marginPx else marginPx)
            y.snapTo((yFrac * maxY).coerceIn(minY, maxY))
            ready = true
        }
        // Menyelip ke tepi setelah 2,5 detik tanpa sentuhan; sentuhan, drag, atau buka/tutup chat mengulang hitungan.
        LaunchedEffect(touch, open) {
            tucked = false
            if (!open) { delay(2500); tucked = true }
        }

        val faded = tucked && !dragging
        val tuckShift by animateFloatAsState(if (faded) (if (onRight) tuckPx else -tuckPx) else 0f, label = "fabTuck")
        val fabAlpha by animateFloatAsState(if (faded) 0.7f else 1f, label = "fabAlpha")
        val fabScale by animateFloatAsState(if (dragging) 1.1f else 1f, label = "fabScale")

        // Petunjuk tepi saat drag: sisi terdekat menyala dengan warna tint kartu.
        val nearLeft by remember(maxX) { derivedStateOf { x.value + fabPx / 2f < (maxX + fabPx) / 2f } }
        val edgeL by animateFloatAsState(if (dragging && nearLeft) 1f else 0f, label = "edgeL")
        val edgeR by animateFloatAsState(if (dragging && !nearLeft) 1f else 0f, label = "edgeR")
        val tint = MaterialTheme.colorScheme.cardTint
        Box(
            Modifier.align(Alignment.CenterStart).fillMaxHeight().width(44.dp)
                .graphicsLayer { alpha = edgeL }
                .background(Brush.horizontalGradient(listOf(tint, Color.Transparent))),
        )
        Box(
            Modifier.align(Alignment.CenterEnd).fillMaxHeight().width(44.dp)
                .graphicsLayer { alpha = edgeR }
                .background(Brush.horizontalGradient(listOf(Color.Transparent, tint))),
        )

        AnimatedVisibility(
            visible = ready && !open,
            modifier = Modifier.offset { IntOffset((x.value + tuckShift).roundToInt(), y.value.roundToInt()) },
            enter = scaleIn(spring(dampingRatio = 0.6f)) + fadeIn(),
            exit = scaleOut() + fadeOut(),
        ) {
            Surface(
                modifier = Modifier
                    .size(FabSize)
                    .graphicsLayer { alpha = fabAlpha; scaleX = fabScale; scaleY = fabScale }
                    .pointerInput(maxX, maxY) {
                        detectTapGestures(onTap = {
                            origin = TransformOrigin(
                                ((x.value + fabPx / 2f) / widthPx).coerceIn(0f, 1f),
                                ((y.value + fabPx / 2f) / heightPx).coerceIn(0f, 1f),
                            )
                            open = true; touch++
                        })
                    }
                    .pointerInput(maxX, maxY) {
                        detectDragGestures(
                            onDragStart = { dragging = true; touch++ },
                            onDragEnd = {
                                val toRight = x.value + fabPx / 2f > (maxX + fabPx) / 2f
                                onRight = toRight
                                yFrac = (y.value / maxY).coerceIn(0f, 1f)
                                dragging = false; touch++
                                scope.launch {
                                    x.animateTo(
                                        if (toRight) maxX - marginPx else marginPx,
                                        spring(dampingRatio = 0.65f, stiffness = Spring.StiffnessMediumLow),
                                    )
                                }
                            },
                            onDragCancel = { dragging = false; touch++ },
                            onDrag = { change, amount ->
                                change.consume()
                                scope.launch {
                                    x.snapTo((x.value + amount.x).coerceIn(0f, maxX))
                                    y.snapTo((y.value + amount.y).coerceIn(minY, maxY))
                                }
                            },
                        )
                    },
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                shadowElevation = 0.dp, // desain flat: tanpa bayangan
            ) {
                ChatBubbleGlyph(
                    bubble = MaterialTheme.colorScheme.onPrimary,
                    dots = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.fillMaxSize().semantics { contentDescription = Lang.tr("Buka chat") },
                )
            }
        }

        BackHandler(enabled = open) { open = false; touch++ }

        AnimatedVisibility(visible = open, enter = fadeIn(tween(200)), exit = fadeOut(tween(200))) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.38f)).clickable(
                    interactionSource = remember { MutableInteractionSource() }, indication = null,
                ) { open = false; touch++ },
            )
        }
        AnimatedVisibility(
            visible = open,
            modifier = Modifier.fillMaxSize().padding(start = 10.dp, end = 10.dp, top = 12.dp, bottom = 12.dp).imePadding(),
            enter = scaleIn(tween(300), initialScale = 0.2f, transformOrigin = origin) + fadeIn(tween(180)),
            exit = scaleOut(tween(220), targetScale = 0.2f, transformOrigin = origin) + fadeOut(tween(160)),
        ) {
            AiChatPanel(
                messages = messages, busy = busy, keySet = keySet, keyHint = keyHint, error = error,
                draft = draft, onDraft = { draft = it }, webSearch = webSearch, onWebSearch = { webSearch = it },
                onSend = { q -> onSend(q, webSearch); draft = "" },
                onClose = { open = false; touch++ },
            )
        }
    }
}

/**
 * Ikon FAB: gelembung chat putih dengan tiga titik (Opsi 1), flat tanpa bayangan. Digambar relatif terhadap ukuran
 * lingkaran sehingga proporsinya tetap saat FabSize diubah. Warna mengikuti tema: gelembung = onPrimary, titik = primary.
 */
@Composable
private fun ChatBubbleGlyph(bubble: Color, dots: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val left = w * 0.209f
        val top = h * 0.246f
        val bw = w * 0.586f
        val bh = h * 0.443f
        val r = bh * 0.46f
        // Badan gelembung
        drawRoundRect(bubble, Offset(left, top), Size(bw, bh), CornerRadius(r, r), style = Fill)
        // Ekor di kiri bawah (segitiga; stroke bundar melembutkan ujungnya)
        val tail = Path().apply {
            moveTo(w * 0.250f, h * 0.610f)
            lineTo(w * 0.268f, h * 0.755f)
            lineTo(w * 0.420f, h * 0.675f)
            close()
        }
        drawPath(tail, bubble, style = Fill)
        drawPath(tail, bubble, style = Stroke(width = w * 0.022f, join = StrokeJoin.Round))
        // Tiga titik
        val cy = top + bh / 2f
        val cx = left + bw / 2f
        val gap = w * 0.123f
        val dr = w * 0.034f
        listOf(-gap, 0f, gap).forEach { dx -> drawCircle(dots, dr, Offset(cx + dx, cy)) }
    }
}

@Composable
private fun AiChatPanel(
    messages: List<Pair<String, String>>,
    busy: Boolean,
    keySet: Boolean,
    keyHint: String,
    error: String?,
    draft: String,
    onDraft: (String) -> Unit,
    webSearch: Boolean,
    onWebSearch: (Boolean) -> Unit,
    onSend: (String) -> Unit,
    onClose: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val imeUp = WindowInsets.ime.getBottom(LocalDensity.current) > 0
    Surface(
        modifier = Modifier.fillMaxSize(),
        shape = RoundedCornerShape(26.dp),
        color = cs.surface,
        border = BorderStroke(1.dp, cs.outline),
    ) {
        Column(Modifier.fillMaxSize()) {
            // Header: hanya judul dan tombol tutup. Tanpa label model AI dan tanpa tombol pengaturan.
            Row(
                Modifier.fillMaxWidth().padding(start = 14.dp, end = 6.dp, top = 10.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(34.dp).clip(RoundedCornerShape(12.dp)).background(cs.primary), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Chat, contentDescription = null, tint = cs.onPrimary, modifier = Modifier.size(19.dp))
                }
                Spacer(Modifier.width(10.dp))
                androidx.compose.material3.Text(
                    "Ask Anything?", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = onClose) { Icon(Icons.Filled.Close, contentDescription = Lang.tr("Tutup chat")) }
            }
            HorizontalDivider(color = cs.outlineVariant)

            if (!keySet) {
                // Satu-satunya teks saat API key belum diisi.
                Box(Modifier.weight(1f).fillMaxWidth().padding(28.dp), contentAlignment = Alignment.Center) {
                    Text(keyHint, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                }
            } else {
                val listState = rememberLazyListState()
                val total = messages.size + if (busy) 1 else 0
                LaunchedEffect(total) { if (total > 0) listState.animateScrollToItem(total - 1) }
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    state = listState,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    if (messages.isEmpty() && !busy) {
                        item {
                            Box(Modifier.fillParentMaxSize(), contentAlignment = Alignment.Center) {
                                Text("Tanyakan apa saja soal latihanmu.", textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                            }
                        }
                    }
                    itemsIndexed(messages) { _, m -> Pop { ChatBubble(role = m.first, text = m.second) } }
                    if (busy) item { Pop { TypingBubble() } }
                }

                if (error != null) {
                    Text(error, style = MaterialTheme.typography.bodySmall, color = cs.error, modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp))
                }
                if (!imeUp) {
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        FilterChip(
                            selected = webSearch, onClick = { onWebSearch(!webSearch) },
                            label = { Text("Cari di web") },
                            leadingIcon = { Icon(Icons.Filled.Language, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        )
                        SuggestionChips.forEach { s ->
                            AssistChip(onClick = { onSend(Lang.tr(s)) }, enabled = !busy, label = { Text(s) })
                        }
                    }
                }
                val submit = { val q = draft.trim(); if (q.isNotEmpty() && !busy) onSend(q) }
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    OutlinedTextField(
                        value = draft, onValueChange = onDraft, modifier = Modifier.weight(1f),
                        placeholder = { Text("Tanyakan tentang latihanmu…") },
                        shape = RoundedCornerShape(24.dp), maxLines = 3,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { submit() }),
                    )
                    FilledIconButton(onClick = submit, enabled = !busy && draft.isNotBlank(), modifier = Modifier.padding(bottom = 4.dp).size(48.dp)) {
                        Icon(Icons.Filled.ArrowUpward, contentDescription = Lang.tr("Kirim ke AI Coach"))
                    }
                }
                if (!imeUp) {
                    Text(
                        "Ringkasan latihan dikirim ke Groq hanya saat kamu menekan Kirim.",
                        style = MaterialTheme.typography.bodySmall, fontSize = 11.sp, color = cs.onSurfaceVariant,
                        textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 10.dp),
                    )
                } else Spacer(Modifier.height(6.dp))
            }
        }
    }
}

/** Pesan baru muncul dengan fade + sedikit membesar. */
@Composable
private fun Pop(content: @Composable () -> Unit) {
    val state = remember { MutableTransitionState(false).apply { targetState = true } }
    AnimatedVisibility(visibleState = state, enter = fadeIn(tween(200)) + scaleIn(tween(260), initialScale = 0.94f)) { content() }
}

@Composable
private fun CoachAvatar() {
    val cs = MaterialTheme.colorScheme
    Box(Modifier.size(26.dp).clip(RoundedCornerShape(10.dp)).background(cs.primary), contentAlignment = Alignment.Center) {
        Icon(Icons.Rounded.Chat, contentDescription = null, tint = cs.onPrimary, modifier = Modifier.size(15.dp))
    }
}

@Composable
private fun ChatBubble(role: String, text: String) {
    val cs = MaterialTheme.colorScheme
    val mine = role == "user"
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Bottom,
    ) {
        if (!mine) { CoachAvatar(); Spacer(Modifier.width(8.dp)) }
        Surface(
            modifier = Modifier.widthIn(max = 280.dp),
            shape = RoundedCornerShape(
                topStart = 16.dp, topEnd = 16.dp,
                bottomStart = if (mine) 16.dp else 5.dp, bottomEnd = if (mine) 5.dp else 16.dp,
            ),
            color = if (mine) cs.primary else cs.surfaceVariant,
            contentColor = if (mine) cs.onPrimary else cs.onSurface,
        ) {
            SelectionContainer {
                // Isi chat bukan teks UI: tidak lewat penerjemah kamus.
                androidx.compose.material3.Text(text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp))
            }
        }
    }
}

@Composable
private fun TypingBubble() {
    val cs = MaterialTheme.colorScheme
    val transition = rememberInfiniteTransition(label = "typing")
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
        CoachAvatar(); Spacer(Modifier.width(8.dp))
        Surface(shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 5.dp, bottomEnd = 16.dp), color = cs.surfaceVariant) {
            Row(Modifier.padding(horizontal = 14.dp, vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                repeat(3) { i ->
                    val a by transition.animateFloat(
                        initialValue = 0.3f, targetValue = 1f,
                        animationSpec = infiniteRepeatable(tween(600), RepeatMode.Reverse, initialStartOffset = StartOffset(i * 150)),
                        label = "dot$i",
                    )
                    Box(Modifier.size(6.dp).graphicsLayer { alpha = a }.clip(CircleShape).background(cs.onSurfaceVariant))
                }
            }
        }
    }
}
