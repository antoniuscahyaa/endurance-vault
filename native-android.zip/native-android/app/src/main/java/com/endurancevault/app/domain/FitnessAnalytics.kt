package com.endurancevault.app.domain

import java.time.DayOfWeek
import java.time.LocalDate
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Port logika tab "Kebugaran" dari rencana lari (web). Grup web: ['fit','Kebugaran',['pgFit','pgPR','pgPace','pgAero','pgDrift','pgEzTrend']].
 * Sumber: 15-training-load-te-kebugaran.js (renderFit, renderPace, paceZoneTable), 20-zona-log-bulanan-pr-cadangan.js (renderPR),
 * 22-statistik-data.js (renderAeroEff), 08-kesesuaian-rute-serupa-detail.js (driftOf, renderDrift), 25-nilai-easy-run.js (renderEzTrend).
 * Murni Kotlin tanpa Android agar bisa diuji di JVM. Tidak mengubah rumus beban/readiness yang sudah ada.
 */
object FitnessAnalytics {

    // ===================== Kebugaran lari (pgFit) =====================

    fun raiLabel(v: Double): String = when {
        v >= 60 -> "Elit"; v >= 52 -> "Sangat baik"; v >= 44 -> "Baik"; v >= 36 -> "Cukup"; else -> "Berkembang"
    }

    fun fitLabel(s: Int): String = when {
        s >= 80 -> "Sangat tinggi"; s >= 60 -> "Tinggi"; s >= 40 -> "Sedang"; s >= 20 -> "Rendah"; else -> "Sangat rendah"
    }

    fun fatLabel(s: Int): String = when {
        s >= 80 -> "Sangat lelah"; s >= 60 -> "Lelah"; s >= 35 -> "Sedang"; s >= 15 -> "Ringan"; else -> "Segar"
    }

    /** "Pulih", "N jam", atau "N,N hari" (>= 48 jam), seperti recTxt di renderFit. */
    fun recoveryText(hours: Int): String = when {
        hours < 2 -> "Pulih"
        hours >= 48 -> "${(hours / 24.0 * 10).roundToInt() / 10.0} hari".replace('.', ',')
        else -> "$hours jam"
    }

    data class Hero(
        val rai: Double?, val raiRuns: Int?, val fitness: Int, val fatigue: Int, val recoveryHours: Int,
        /** "stabil", "▲ 1,2", "▼ 0,8", atau null bila kurang dari 2 minggu data. */
        val trend: String?,
    )

    /**
     * Kebugaran lari: Fitness RAI = 0,7 x indeks kemampuan + 0,3 x CTL; Fatigue RAI dari rasio ATL:CTL ditambah poin kondisi pagi.
     * Null bila belum ada beban latihan maupun indeks kemampuan (web menampilkan "Belum ada data").
     */
    fun hero(ability: RunningAbility?, m: TrainingMetricsResult): Hero? {
        if (m.latest == null && ability == null) return null
        val abS = ability?.let { ((it.value - 20) / 45 * 100).coerceIn(0.0, 100.0) }
        val ctS = m.fitness.toDouble().coerceIn(0.0, 100.0)
        val fit = if (abS != null) (.7 * abS + .3 * ctS).roundToInt() else ctS.roundToInt()
        val fatBase = if (m.fitness > 8 * m.scale) (10 + (m.ratio - .6) * 90).coerceIn(0.0, 100.0) else m.fatigue.toDouble().coerceIn(0.0, 100.0)
        val fat = (fatBase + m.morningPts).coerceIn(0.0, 100.0).roundToInt()
        var trend: String? = null
        val series = ability?.weekly.orEmpty()
        if (series.size >= 2) {
            val f = series[max(0, series.size - 5)].second
            val l = series.last().second
            val dv = (l - f) * 10
            val dvr = Math.floor(dv + .5) / 10.0
            trend = if (abs(dvr) < .3) "stabil" else if (dvr > 0) "▲ ${fmt1(dvr)}" else "▼ ${fmt1(abs(dvr))}"
        }
        return Hero(ability?.value, ability?.runs, fit, fat, m.recoveryRemainingHours, trend)
    }

    private fun fmt1(x: Double): String = String.format(java.util.Locale.US, "%.1f", x).replace('.', ',')

    // ===================== Zona pace dari RAI (pgPace) =====================

    /** Pace (menit/km) pada pecahan [f] dari kemampuan [vd] (VO2). Persamaan sama dengan paceAtFrac di web. */
    fun paceAtFrac(vd: Double, f: Double): Double {
        val tg = vd * f + 4.6
        val a = .000104; val b = .182258
        val v = (-b + sqrt(b * b + 4 * a * tg)) / (2 * a)
        return 1000 / v
    }

    data class PaceZone(val name: String, val lo: Double, val hi: Double, val note: String)

    /** Easy .62-.74, Tempo .80-.87, Threshold .88-.92, VO2max .95-1.0 (PACE_ZF di web). */
    val PACE_ZONES: List<PaceZone> = listOf(
        PaceZone("Easy", .62, .74, "Lari santai, long run, pemulihan"),
        PaceZone("Tempo", .80, .87, "Pace maraton sampai tempo"),
        PaceZone("Threshold", .88, .92, "Interval threshold, tempo keras"),
        PaceZone("VO2max", .95, 1.0, "Interval 3–5 menit"),
    )

    // ===================== Efisiensi aerobik (pgAero) =====================

    const val AE_DEFAULT_HR = 140
    const val AE_DEFAULT_RANGE = 6
    const val AE_TOL = 4

    data class AePoint(val date: LocalDate, val pace: Double, val km: Double, val hr: Double)

    /** Pace rata-rata (berbobot km) pada kilometer dengan HR di [target] ± [tol]. Minimal 1,5 km, seperti stAeRun. */
    fun aeRun(d: ActDetail, target: Int, tol: Int): AePoint? {
        if (d.bike || d.splits.isEmpty()) return null
        val date = runCatching { LocalDate.parse(d.date.take(10)) }.getOrNull() ?: return null
        var prev = 0.0; var sum = 0.0; var len = 0.0; var hrW = 0.0
        for (s in d.splits) {
            val dk = s.k - prev; prev = s.k
            val h = s.hr
            if (!(dk >= .5) || h == null || !(s.pace > 2 && s.pace < 15)) continue
            if (abs(h - target) > tol) continue
            val gp = s.gap
            val p = if (gp != null && gp > 0 && gp < 15) gp else if ((s.gain + s.loss) <= 25) s.pace else 0.0
            if (!(p > 0)) continue
            sum += p * dk; len += dk; hrW += h * dk
        }
        return if (len >= 1.5) AePoint(date, sum / len, len, hrW / len) else null
    }

    /** Seri titik per lari; [rangeMonths] 0 = semua. */
    fun aeSeries(details: Collection<ActDetail>, target: Int, tol: Int, rangeMonths: Int, today: LocalDate): List<AePoint> {
        val from = if (rangeMonths > 0) today.minusMonths(rangeMonths.toLong()) else null
        return details.mapNotNull { aeRun(it, target, tol) }
            .filter { from == null || !it.date.isBefore(from) }
            .sortedBy { it.date }
    }

    data class AeBest(val hr: Int, val count: Int)

    /** HR dengan data terbanyak (jendela ±4 bpm, 100..185); null bila kurang dari 4 kilometer. */
    fun aeBest(details: Collection<ActDetail>): AeBest? {
        val cnt = HashMap<Int, Int>()
        details.forEach { d ->
            if (d.bike) return@forEach
            d.splits.forEach { s ->
                val h = s.hr
                if (h != null && s.pace > 2 && s.pace < 15) cnt[h] = (cnt[h] ?: 0) + 1
            }
        }
        var best: AeBest? = null
        for (b in 100..185) {
            var c = 0
            for (j in -4..4) c += cnt[b + j] ?: 0
            if (best == null || c > best.count) best = AeBest(b, c)
        }
        return best?.takeIf { it.count >= 4 }
    }

    /** Rata-rata bergerak 28 hari untuk garis tren. */
    fun aeSmooth(pts: List<AePoint>): List<Double> = pts.map { x ->
        var s = 0.0; var n = 0
        pts.forEach { y ->
            val dt = java.time.temporal.ChronoUnit.DAYS.between(y.date, x.date)
            if (dt >= 0L && dt <= 28L) { s += y.pace; n++ }
        }
        if (n > 0) s / n else x.pace
    }

    data class AeSummary(val firstPace: Double, val lastPace: Double, val deltaSec: Int, val deltaPct: Double)

    fun aeSummary(pts: List<AePoint>): AeSummary? {
        if (pts.size < 2) return null
        val k = min(3, pts.size / 2)
        val a0 = pts.take(k).map { it.pace }.average()
        val a1 = pts.takeLast(k).map { it.pace }.average()
        val df = Math.floor((a0 - a1) * 60 + .5).toInt()
        val pc = Math.floor((a0 - a1) / a0 * 1000 + .5) / 10.0
        return AeSummary(a0, a1, df, pc)
    }

    fun aeSummaryText(s: AeSummary, targetHr: Int): String {
        val txt = "Pace pada HR $targetHr: ${Js.paceStr(s.firstPace)} → ${Js.paceStr(s.lastPace)}/km. "
        if (abs(s.deltaSec) < 3) return txt + "Praktis stabil."
        return txt + if (s.deltaSec > 0) "Lebih cepat ${s.deltaSec} dtk/km (${fmt1(s.deltaPct)}%). Kebugaran aerobik membaik."
        else "Lebih lambat ${abs(s.deltaSec)} dtk/km. Bisa karena lelah, panas, atau kebugaran turun; lihat tren beberapa minggu."
    }

    // ===================== Cardiac drift (pgDrift) =====================

    data class DriftRun(val date: LocalDate, val pct: Double, val km: Double)

    /**
     * Penurunan efisiensi (kecepatan setara datar per detak) dari paruh pertama ke paruh kedua lari, setelah pemanasan.
     * Hanya lari easy/long (hari kualitas, sub, lomba, acara, dan bench dilewati) dengan minimal 9 split dan 8 km data.
     */
    fun driftOf(d: ActDetail, dayKind: String?, bench: Boolean): DriftRun? {
        if (d.bike || d.splits.size < 9) return null
        if (dayKind == "quality" || dayKind == "sub" || dayKind == "race" || dayKind == "event" || bench) return null
        val date = runCatching { LocalDate.parse(d.date.take(10)) }.getOrNull() ?: return null
        val sp = d.splits.toMutableList()
        if (sp.size > 1 && sp[sp.size - 1].k - sp[sp.size - 2].k < .9) sp.removeAt(sp.size - 1)
        val n = sp.size
        if (n < 8) return null
        val ef: List<Double?> = sp.map { x ->
            val h = x.hr
            if (!(x.pace > 0) || h == null || !(h > 60)) return@map null
            val v = 1 / x.pace
            val gr = (x.gain - x.loss) / 1000.0
            val c = ActInsights.minettiCost(gr)
            if (!(c > 0)) return@map null
            (v * c / 3.6) / h * 1000
        }
        val st = max(1, Math.floor(n * .1 + .5).toInt())
        val mid = st + (n - st) / 2
        val a = ArrayList<Double>(); val b = ArrayList<Double>()
        for (i in st until n) {
            val e = ef[i] ?: continue
            if (i < mid) a.add(e) else b.add(e)
        }
        if (a.size < 3 || b.size < 3) return null
        val e1 = a.average(); val e2 = b.average()
        val pct = Math.floor((e1 - e2) / e1 * 1000 + .5) / 10.0
        return DriftRun(date, pct, if (d.km > 0) d.km else sp[n - 1].k)
    }

    fun driftLabel(v: Double): String = if (v < 3) "baik" else if (v < 5) "sedang" else "tinggi"

    /** Pesan tren: 3 lari terakhir vs 3 sebelumnya (min. 4 lari). */
    fun driftMessage(pcts: List<Double>): String? {
        if (pcts.size < 4) return null
        val rc = pcts.takeLast(3)
        val pv = pcts.subList(max(0, pcts.size - 6), pcts.size - 3)
        val a1 = pv.average(); val a2 = rc.average()
        val df = Math.floor((a2 - a1) * 10 + .5) / 10.0
        fun r1(x: Double) = fmt1(Math.floor(x * 10 + .5) / 10.0)
        return if (abs(df) < .8) "Drift stabil di sekitar ${r1(a2)}%."
        else if (df < 0) "Drift membaik: ${r1(a1)}% turun ke ${r1(a2)}%. Basis aerobik menguat."
        else "Drift naik: ${r1(a1)}% ke ${r1(a2)}%. Cek tidur, panas, hidrasi, dan beban minggu ini."
    }

    // ===================== Tren easy run (pgEzTrend) =====================

    const val EZT_WEEKS = 8
    const val EZT_SESS = 12

    class EzRow(val id: Long, val date: LocalDate, val week: LocalDate, val r: EasyRunResult)

    /** Semua sesi bernilai (verdict bukan na, ada persen), urut tanggal lama ke baru. */
    fun ezRows(results: List<EasyRunResult>): List<EzRow> = results
        .filter { it.verdict != "na" && it.compliancePct != null }
        .sortedBy { it.date }
        .map { EzRow(it.activityId, it.date, it.date.with(DayOfWeek.MONDAY), it) }

    class EzWeek(val start: LocalDate, val n: Int, val pct: Double?, val pass: Double?, val ok: Double?)

    /** Persen waktu di zona per minggu (berbobot waktu dinilai). Terbaru di akhir. */
    fun ezWeeks(rows: List<EzRow>, nw: Int, today: LocalDate, cfg: EasyRunConfig): List<EzWeek> {
        class Acc { var tot = 0.0; var good = 0.0; var pass = 0.0; var ok = 0.0; var n = 0 }
        val map = HashMap<LocalDate, Acc>()
        rows.forEach { x ->
            val total = x.r.evaluatedMinutes
            if (!(total > 0)) return@forEach
            val o = map.getOrPut(x.week) { Acc() }
            val pass = if (x.r.kind == "long") cfg.longPass else cfg.easyPass
            val ok = if (x.r.kind == "long") cfg.longOk else cfg.easyOk
            o.tot += total; o.good += max(0.0, total - x.r.overLimitMinutes); o.pass += total * pass; o.ok += total * ok; o.n++
        }
        val cur = today.with(DayOfWeek.MONDAY)
        return (nw - 1 downTo 0).map { i ->
            val d = cur.minusWeeks(i.toLong()); val o = map[d]
            if (o != null) EzWeek(d, o.n, o.good / o.tot * 100, o.pass / o.tot, o.ok / o.tot) else EzWeek(d, 0, null, null, null)
        }
    }

    fun ezWeekVerdict(w: EzWeek): String {
        val p = w.pct ?: return "na"
        return if (p >= (w.pass ?: 100.0)) "good" else if (p >= (w.ok ?: 100.0)) "ok" else "hard"
    }

    data class EzStreak(val cur: Int, val max: Int)

    /** Sesi "Terlalu keras" berturut-turut: cur = yang berjalan sampai sesi terbaru, max = terpanjang. */
    fun ezStreaks(rows: List<EzRow>): EzStreak {
        var run = 0; var mx = 0
        rows.forEach { x -> if (x.r.verdict == "hard") { run++; if (run > mx) mx = run } else run = 0 }
        return EzStreak(run, mx)
    }

    data class EzScore(val date: LocalDate, val score: Int, val verdict: String)

    fun ezScores(rows: List<EzRow>, n: Int): List<EzScore> =
        rows.filter { it.r.score != null }.map { EzScore(it.date, it.r.score!!, it.r.verdict) }.takeLast(n)

    data class EzScoreSum(val last: Int, val n: Int, val dir: String?, val from: Int?, val to: Int?, val k: Int)

    /** Skor terakhir dan tren (rata-rata k sesi awal vs k sesi akhir; selisih >= 5 poin dianggap berubah). */
    fun ezScoreSum(sc: List<EzScore>): EzScoreSum? {
        if (sc.isEmpty()) return null
        val k = min(3, sc.size / 2)
        if (k < 1) return EzScoreSum(sc.last().score, sc.size, null, null, null, 0)
        val from = Math.floor(sc.take(k).map { it.score }.average() + .5).toInt()
        val to = Math.floor(sc.takeLast(k).map { it.score }.average() + .5).toInt()
        val df = to - from
        return EzScoreSum(sc.last().score, sc.size, if (df >= 5) "up" else if (df <= -5) "down" else "flat", from, to, k)
    }

    /** Kunci "w" = peringatan, "gray" = netral, "ok" = baik. */
    data class EzAdvice(val key: String, val text: String)

    fun ezStreakAdvice(st: EzStreak, lastVerdict: String): EzAdvice = when {
        st.cur >= 3 -> EzAdvice("w", "${st.cur} sesi berturut-turut Terlalu keras. Perlambat dulu: HR yang menentukan, bukan pace.")
        st.cur == 2 -> EzAdvice("gray", "2 sesi berturut-turut Terlalu keras. Satu lagi memunculkan peringatan perlambat; easy berikutnya tahan HR di bawah batas sejak menit pertama.")
        st.cur == 1 -> EzAdvice("gray", "Sesi terakhir Terlalu keras. Easy berikutnya tahan HR di bawah batas sejak menit pertama.")
        else -> EzAdvice("ok", if (lastVerdict == "ok") "Tidak ada sesi Terlalu keras berturut-turut. Sesi terakhir Cukup, jaga HR tetap di bawah batas." else "Tidak ada sesi Terlalu keras berturut-turut.")
    }
}
