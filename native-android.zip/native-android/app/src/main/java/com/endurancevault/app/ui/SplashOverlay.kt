package com.endurancevault.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/**
 * Tahap 2 splash: menyambung splash sistem Android (latar aksen + logo di tengah)
 * dengan siluet grafik yang naik dari dasar layar, lalu memudar.
 * Logo di sini harus sama persis posisi/ukurannya dengan res/drawable/ic_splash_logo.xml
 * (lebar 150dp, pusat layar) supaya tidak ada lompatan saat berganti tahap.
 *
 * Penyesuaian cepat:
 *  - SIL_HEIGHT_SCALE : tinggi siluet (1f = proporsi asli logo, 0.8f = default, makin kecil makin pendek)
 *  - HOLD_MS          : lama siluet bertahan setelah selesai naik
 */
private const val SYM_W = 860f
private const val SYM_H = 590f
private const val SIL_BASE = 583f
private const val SIL_HEIGHT_SCALE = 0.8f
private const val RISE_MS = 450
private const val FADE_MS = 250
private const val HOLD_MS = 600L

private val SplashBg = Color(0xFFEA5F0A)
private val SplashInk = Color(0xFF0B0C0F)

// Logo (warna sama dengan ic_splash_logo.xml)
private val LG_MTN_RIGHT = floatArrayOf(340f, 455f, 360f, 442f, 411f, 465f, 434f, 438f, 512f, 583f, 415f, 583f)
private val LG_MTN_MID = floatArrayOf(98f, 583f, 146f, 534f, 224f, 579f, 315f, 482f, 378f, 577f)
private val LG_BAR = floatArrayOf(562f, 583f, 655f, 583f, 852f, 245f, 803f, 182f)
private val LG_TRI = floatArrayOf(160f, 431f, 248f, 437f, 210f, 470f)
private val LG_E = floatArrayOf(0f, 18f, 390f, 18f, 443f, 130f, 113f, 130f, 113f, 225f, 310f, 225f, 365f, 332f, 113f, 332f, 113f, 429f, 127f, 435f, 0f, 549f)
private val LG_TREND = floatArrayOf(7f, 583f, 140f, 453f, 218f, 500f, 337f, 372f, 418f, 415f, 402f, 442f, 347f, 420f, 219f, 547f, 143f, 503f, 60f, 583f)
private val LG_V = floatArrayOf(352f, 218f, 472f, 218f, 557f, 362f, 737f, 75f, 710f, 48f, 860f, 0f, 838f, 165f, 795f, 130f, 558f, 528f, 540f, 548f)
private val LgTint = Color(0xFFF6B791)
private val LgDeep = Color(0xFFB24A09)

// Siluet dasar: bentuk yang sama dengan logo, titik dasar dirapatkan ke garis dasar
private val SL_MTN_RIGHT = floatArrayOf(340f, 455f, 360f, 442f, 411f, 465f, 434f, 438f, 512f, 583f, 415f, 583f)
private val SL_MTN_MID = floatArrayOf(98f, 583f, 146f, 534f, 224f, 583f, 315f, 482f, 378f, 583f)
private val SL_BAR = floatArrayOf(562f, 583f, 655f, 583f, 852f, 245f, 803f, 182f)
private val SL_TREND = floatArrayOf(7f, 583f, 140f, 453f, 218f, 500f, 337f, 372f, 418f, 415f, 402f, 442f, 347f, 420f, 219f, 547f, 143f, 503f, 60f, 583f)
private const val SIL_TOP_ALL = 182f // puncak tertinggi (ujung bar kanan)

private fun DrawScope.poly(p: FloatArray, color: Color, kx: Float, ky: Float, ox: Float, oy: Float) {
    val path = Path()
    path.moveTo(ox + p[0] * kx, oy + p[1] * ky)
    var i = 2
    while (i < p.size) {
        path.lineTo(ox + p[i] * kx, oy + p[i + 1] * ky)
        i += 2
    }
    path.close()
    drawPath(path, color)
}

@Composable
fun SplashOverlay() {
    // rememberSaveable: tidak diputar ulang saat rotasi layar
    var visible by rememberSaveable { mutableStateOf(true) }
    if (!visible) return
    val rise = remember { Animatable(0f) }
    val fade = remember { Animatable(1f) }
    LaunchedEffect(Unit) {
        rise.animateTo(1f, tween(RISE_MS, easing = FastOutSlowInEasing))
        delay(HOLD_MS)
        fade.animateTo(0f, tween(FADE_MS))
        visible = false
    }
    Canvas(
        Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = fade.value }
            // selama tampil, sentuhan tidak diteruskan ke layar di bawahnya
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) awaitPointerEvent().changes.forEach { it.consume() }
                }
            }
    ) {
        val w = size.width
        val h = size.height
        drawRect(SplashBg)

        // Logo: lebar 150dp di pusat layar (sama dengan ikon splash sistem)
        val logoW = 150.dp.toPx()
        val s = logoW / SYM_W
        val lx = (w - logoW) / 2f
        val ly = (h - SYM_H * s) / 2f
        poly(LG_MTN_RIGHT, LgTint, s, s, lx, ly)
        poly(LG_MTN_MID, LgDeep, s, s, lx, ly)
        poly(LG_BAR, LgTint, s, s, lx, ly)
        poly(LG_TRI, LgTint, s, s, lx, ly)
        poly(LG_E, Color.White, s, s, lx, ly)
        poly(LG_TREND, SplashInk, s, s, lx, ly)
        poly(LG_V, SplashInk, s, s, lx, ly)

        // Siluet grafik di dasar: lebar penuh, naik dari bawah layar
        val kx = w / SYM_W
        val ky = kx * SIL_HEIGHT_SCALE
        val footer = 28.dp.toPx()
        val baseY = h - footer
        val offset = (1f - rise.value) * ((SIL_BASE - SIL_TOP_ALL) * ky + footer)
        val oy = baseY - SIL_BASE * ky + offset
        poly(SL_MTN_RIGHT, SplashInk, kx, ky, 0f, oy)
        poly(SL_MTN_MID, SplashInk, kx, ky, 0f, oy)
        poly(SL_BAR, SplashInk, kx, ky, 0f, oy)
        poly(SL_TREND, SplashInk, kx, ky, 0f, oy)
        drawRect(SplashInk, topLeft = Offset(0f, baseY + offset), size = Size(w, footer + 1f))
    }
}
