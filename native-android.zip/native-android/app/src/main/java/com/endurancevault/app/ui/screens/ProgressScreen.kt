package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.i18n.Text
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.ui.UiState

private enum class ProgressTab(val label: String, val count: Int) {
    RECAP("Rekap", 7), FITNESS("Fitness", 6), LOAD("Load", 4), ROUTES("Routes & conditions", 5), BODY("Body", 3)
}

/**
 * Progres: Rekap, Fitness, Load, Routes & conditions, Body. Kelima sub-tab memakai sistem kartu yang sama
 * (RcCard di RecapTab.kt): ringkasan saat tertutup, detail saat dibuka, pasangan setengah lebar via RcPair.
 */
@Composable
fun ProgressScreen(
    state: UiState, onDelete: (Long) -> Unit, onOpen: (Long) -> Unit,
    onImportTracks: (List<Uri>) -> Unit, trackMsg: String?, initialTab: String = "Rekap",
    onSaveSettings: (PlanSettings) -> Unit = {},
    /** Naik tiap kali sub-tab dipilih dari sidebar, supaya memilih sub-tab yang sama tetap memicu perpindahan. */
    initialTabNonce: Int = 0,
) {
    var selected by remember(initialTab, initialTabNonce) { mutableStateOf(when (initialTab.lowercase()) {
        "fitness", "kebugaran" -> ProgressTab.FITNESS
        "load", "beban" -> ProgressTab.LOAD
        "routes", "routes & conditions", "rute & kondisi" -> ProgressTab.ROUTES
        "body", "tubuh" -> ProgressTab.BODY
        else -> ProgressTab.RECAP
    }) }
    val recapWarn = remember(state.plan, state.activities, state.mv) { recapNeedsAttention(state) }

    Column(Modifier.fillMaxSize()) {
        when (selected) {
            ProgressTab.RECAP -> TabScroll { RecapTab(state, onOpen) }
            ProgressTab.FITNESS -> TabScroll { FitnessTab(state, onOpen) }
            ProgressTab.LOAD -> TabScroll { LoadTab(state, onSaveSettings) }
            ProgressTab.ROUTES -> TabScroll { RoutesTab(state, onOpen) }
            ProgressTab.BODY -> TabScroll { BodyTab(state) }
        }
        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(26.dp), color = MaterialTheme.colorScheme.surface,
            border = androidx.compose.foundation.BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ProgressTab.values().forEach { tab ->
                    val on = selected == tab
                    val shape = androidx.compose.foundation.shape.RoundedCornerShape(99.dp)
                    androidx.compose.foundation.layout.Box(
                        Modifier.clip(shape)
                            .then(if (on) Modifier.background(androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.primary))
                                  else Modifier.border(0.8.dp, MaterialTheme.colorScheme.outlineVariant, shape))
                            .clickable { selected = tab }.padding(horizontal = 18.dp, vertical = 10.dp),
                    ) {
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(tab.label, style = MaterialTheme.typography.titleSmall,
                                color = if (on) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface)
                            val badgeShape = androidx.compose.foundation.shape.CircleShape
                            androidx.compose.foundation.layout.Box(
                                Modifier.size(22.dp).clip(badgeShape).background(if (on) androidx.compose.ui.graphics.Color.White.copy(alpha = .28f) else MaterialTheme.colorScheme.surfaceVariant),
                                contentAlignment = androidx.compose.ui.Alignment.Center,
                            ) { Text(tab.count.toString(), style = MaterialTheme.typography.labelSmall,
                                color = if (on) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant) }
                            val warn = tab == ProgressTab.RECAP && recapWarn
                            val dot = if (warn) androidx.compose.ui.graphics.Color(0xFFB9822B) else androidx.compose.ui.graphics.Color(0xFF3C8A64)
                            androidx.compose.foundation.layout.Box(
                                Modifier.size(11.dp).clip(badgeShape).then(if (warn) Modifier.border(2.dp, dot, badgeShape) else Modifier.background(dot)),
                            )
                        }
                    }
                }
            }
        }
    }
}

/** Area isi satu sub-tab: bergulir vertikal, jarak antarkartu 12 dp (sama untuk kelima sub-tab). */
@Composable
private fun ColumnScope.TabScroll(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        content = content,
    )
}
