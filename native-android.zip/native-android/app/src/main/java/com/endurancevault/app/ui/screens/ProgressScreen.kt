package com.endurancevault.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.ui.UiState
import java.time.LocalDate

@Composable
fun ProgressScreen(state: UiState, onDelete: (Long) -> Unit) {
    val weeks = (state.plan as? PlanOutcome.Ok)?.weeks.orEmpty()
    val thisWeek = weeks.firstOrNull { !LocalDate.now().isBefore(it.start) && LocalDate.now().isBefore(it.start.plusDays(7)) }
    val done = thisWeek?.let { w ->
        state.activities.filter {
            if (it.type == "bike") return@filter false
            val d = LocalDate.parse(it.dateIso); !d.isBefore(w.start) && d.isBefore(w.start.plusDays(7))
        }.sumOf { it.km }
    } ?: 0.0

    LazyColumn(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Progres", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(top = 16.dp)) }
        if (thisWeek != null) item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Minggu ini", style = MaterialTheme.typography.titleMedium)
                    Text("%.1f dari %s km".format(done, fmtKmUi(thisWeek.km)))
                    LinearProgressIndicator(
                        progress = { if (thisWeek.km > 0) (done / thisWeek.km).toFloat().coerceIn(0f, 1f) else 0f },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }
        item { Text("Riwayat lari", style = MaterialTheme.typography.titleMedium) }
        items(state.activities, key = { it.id }) { a ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(14.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("${a.dateIso} · %.1f km".format(a.km) + (if (a.type == "bike") " · sepeda" else "") + (if (a.name.isNotBlank()) " · ${a.name}" else ""))
                        Text(
                            "${a.durationSec / 60} menit" + (a.avgHr?.let { " · HR $it" } ?: ""),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    TextButton(onClick = { onDelete(a.id) }) { Text("Hapus") }
                }
            }
        }
    }
}
