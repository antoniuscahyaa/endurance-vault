package com.endurancevault.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ExpandLess
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.clickable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.size
import com.endurancevault.app.domain.TrainingMetrics
import com.endurancevault.app.ui.UiState
import java.time.LocalDate
import kotlin.math.max

@Composable
fun TrainingLoadSection(state: UiState) {
    val m = TrainingMetrics.calculate(state.settings, state.activities, state.daily, state.plan, hrHistByActivity = state.hrHistByActivity)
    var expanded by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Training load & readiness", style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.weight(1f).clickable { expanded = !expanded })
            IconButton(onClick = { expanded = !expanded }) {
                Icon(if (expanded) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore,
                    contentDescription = if (expanded) "Tutup detail training load" else "Buka detail training load")
            }
        }
        Text(
            "Readiness ${m.readiness?.score?.toString() ?: "—"} · CTL ${m.fitness} · ATL ${m.fatigue} · TSB ${m.form}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        AnimatedVisibility(visible = expanded, enter = expandVertically(), exit = shrinkVertically()) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Training readiness", style = MaterialTheme.typography.titleMedium)
                val r = m.readiness
                if (r == null) {
                    Text("Belum cukup data kondisi harian. Isi tidur, HRV, HR istirahat, rasa kaki atau mood untuk menghitung readiness.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("${r.score}", style = MaterialTheme.typography.displayMedium, color = when { r.score >= 60 -> MaterialTheme.colorScheme.primary; r.score >= 40 -> MaterialTheme.colorScheme.tertiary; else -> MaterialTheme.colorScheme.error })
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(r.tier, style = MaterialTheme.typography.titleLarge)
                            Text(r.advice, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    r.parts.forEach { p ->
                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(p.label, style = MaterialTheme.typography.bodyMedium)
                                Text(p.score?.let { "$it/100" } ?: "—", style = MaterialTheme.typography.labelLarge)
                            }
                            if (p.score != null) LinearProgressIndicator({ p.score / 100f }, Modifier.fillMaxWidth())
                            Text(p.detail, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Text("Berdasarkan ${r.dataDays} hari data. Estimasi kebugaran, bukan penilaian medis.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        m.planAdjustment?.let { a ->
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Penyesuaian sesi hari ini", style = MaterialTheme.typography.titleMedium)
                    Text(a.plannedTitle, style = MaterialTheme.typography.bodyMedium)
                    Text(
                        if (a.action == "swap") "Saran: ganti dengan easy %.1f km".format(a.suggestedKm)
                        else "Saran: kurangi target menjadi %.1f km".format(a.suggestedKm),
                        style = MaterialTheme.typography.titleLarge,
                    )
                    Text(a.reason, style = MaterialTheme.typography.bodySmall)
                    Text("Berdasarkan readiness ${a.readinessScore}/100. Ini rekomendasi, bukan perubahan otomatis pada jadwal.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        if (m.days.isEmpty()) {
            EvPanel(Modifier.fillMaxWidth()) { Text(m.statusDetail, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
        } else {
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Training load", style = MaterialTheme.typography.titleMedium)
                Text(m.status, style = MaterialTheme.typography.titleLarge)
                Text(m.statusDetail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MetricValue("Load 7 hari", m.weeklyLoad.toString())
                    MetricValue("Fitness · CTL", m.fitness.toString())
                    MetricValue("Fatigue · ATL", m.fatigue.toString())
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MetricValue("Form · TSB", (if (m.form > 0) "+" else "") + m.form)
                    MetricValue("ATL : CTL", if (m.ratio > 0) "%.2f".format(m.ratio) else "—")
                    MetricValue("Recovery", "${m.recoveryRemainingHours} jam")
                }
                LoadChart(m.days.takeLast(56))
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    LegendDot("Load", MaterialTheme.colorScheme.tertiary)
                    LegendDot("Fitness", MaterialTheme.colorScheme.primary)
                    LegendDot("Fatigue", MaterialTheme.colorScheme.error)
                }
                Text("Kisaran beban mingguan indikatif: ${m.optimalRange.first}–${m.optimalRange.last}. LTHR ${m.lthr} bpm · HRmax estimasi ${m.hrMax} bpm · skala ×${"%.2f".format(m.scale)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Training effect · sesi terakhir", style = MaterialTheme.typography.titleMedium)
                m.sessions.take(7).forEach { s ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(s.date.toString(), style = MaterialTheme.typography.bodyMedium)
                            Text("${s.source} · recovery ${"%.1f".format(s.recoveryHours)} jam", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Column {
                            Text("Load ${s.load.toInt()}", style = MaterialTheme.typography.labelLarge)
                            s.watchLoad?.let { Text("Load jam $it", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                            Text("Aerobik ${"%.1f".format(s.aerobicEffect)} / 5", style = MaterialTheme.typography.bodySmall)
                            Text("Anaerobik ${s.anaerobicEffect?.let { "%.1f".format(it) + " / 5" } ?: "—"}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                Text("TE aerobik, TE anaerobik, recovery, dan watch load memakai angka jam bila tersedia. Load CTL/ATL EnduranceVault tetap dihitung dengan skala internal agar satuan beban jam tidak tercampur tanpa kalibrasi.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        }
        }
        }
    }
}

@Composable private fun MetricValue(label: String, value: String) {
    Column { Text(value, style = MaterialTheme.typography.titleLarge); Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
}

@Composable private fun LoadChart(days: List<com.endurancevault.app.domain.LoadDay>) {
    if (days.size < 2) return
    val primary = MaterialTheme.colorScheme.primary
    val tertiary = MaterialTheme.colorScheme.tertiary
    val error = MaterialTheme.colorScheme.error
    Canvas(Modifier.fillMaxWidth().height(150.dp)) {
        val maxY = max(1.0, days.maxOf { max(it.load, max(it.fitness, it.fatigue)) } * 1.12).toFloat()
        val xStep = size.width / (days.size - 1).coerceAtLeast(1)
        fun y(v: Double) = size.height - (v.toFloat() / maxY * size.height)
        fun plotLine(values: (com.endurancevault.app.domain.LoadDay) -> Double, color: androidx.compose.ui.graphics.Color) {
            val path = Path()
            days.forEachIndexed { i, d -> val pt = Offset(i * xStep, y(values(d))); if (i == 0) path.moveTo(pt.x, pt.y) else path.lineTo(pt.x, pt.y) }
            drawPath(path, color, style = Stroke(width = 3.dp.toPx()))
        }
        days.forEachIndexed { i, d ->
            if (d.load > 0) {
                drawLine(
                    color = tertiary.copy(alpha = .35f),
                    start = Offset(i * xStep, size.height),
                    end = Offset(i * xStep, y(d.load)),
                    strokeWidth = 2.dp.toPx(),
                )
            }
        }
        plotLine({ it.fitness }, primary); plotLine({ it.fatigue }, error)
    }
}

@Composable private fun LegendDot(label: String, color: androidx.compose.ui.graphics.Color) {
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Canvas(Modifier.padding(top = 4.dp).size(8.dp)) { drawCircle(color) }
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}
