package com.endurancevault.app.ui.video

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix as GMatrix
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES20
import android.opengl.GLUtils
import android.opengl.Matrix
import android.view.Surface
import com.endurancevault.app.data.TerrainScene
import com.endurancevault.app.domain.CameraPose
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * EGL ES 2.0. Dengan [surface] (masukan MediaCodec) menggambar ke jendela dan bisa memberi cap waktu; tanpa [surface]
 * memakai pbuffer [width] x [height] untuk pratinjau. Semua pemanggilan harus dari satu thread.
 */
class EglCore(surface: Surface?, val width: Int, val height: Int) {
    private var display: EGLDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
    private var context: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE

    init {
        check(display != EGL14.EGL_NO_DISPLAY) { "EGL tidak tersedia di perangkat ini." }
        val ver = IntArray(2)
        check(EGL14.eglInitialize(display, ver, 0, ver, 1)) { "EGL gagal diinisialisasi." }
        val windowed = surface != null
        val attrs = ArrayList<Int>().apply {
            addAll(listOf(
                EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
                EGL14.EGL_DEPTH_SIZE, 16,
                EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                EGL14.EGL_SURFACE_TYPE, if (windowed) EGL14.EGL_WINDOW_BIT else EGL14.EGL_PBUFFER_BIT,
            ))
            if (windowed) addAll(listOf(EGL_RECORDABLE_ANDROID, 1))
            add(EGL14.EGL_NONE)
        }.toIntArray()
        val configs = arrayOfNulls<EGLConfig>(1)
        val num = IntArray(1)
        check(EGL14.eglChooseConfig(display, attrs, 0, configs, 0, 1, num, 0) && num[0] > 0) { "Konfigurasi EGL tidak cocok." }
        val cfg = configs[0]
        context = EGL14.eglCreateContext(display, cfg, EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
        check(context != EGL14.EGL_NO_CONTEXT) { "Konteks OpenGL ES 2.0 gagal dibuat." }
        eglSurface = if (windowed) EGL14.eglCreateWindowSurface(display, cfg, surface, intArrayOf(EGL14.EGL_NONE), 0)
        else EGL14.eglCreatePbufferSurface(display, cfg, intArrayOf(EGL14.EGL_WIDTH, width, EGL14.EGL_HEIGHT, height, EGL14.EGL_NONE), 0)
        check(eglSurface != EGL14.EGL_NO_SURFACE) { "Permukaan EGL gagal dibuat." }
    }

    fun makeCurrent() { check(EGL14.eglMakeCurrent(display, eglSurface, eglSurface, context)) { "eglMakeCurrent gagal." } }
    fun swap(): Boolean = EGL14.eglSwapBuffers(display, eglSurface)
    fun setPresentationTime(nanos: Long) { EGLExt.eglPresentationTimeANDROID(display, eglSurface, nanos) }

    fun release() {
        if (display != EGL14.EGL_NO_DISPLAY) {
            EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            if (eglSurface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(display, eglSurface)
            if (context != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(display, context)
            EGL14.eglReleaseThread()
            EGL14.eglTerminate(display)
        }
        display = EGL14.EGL_NO_DISPLAY; context = EGL14.EGL_NO_CONTEXT; eglSurface = EGL14.EGL_NO_SURFACE
    }

    private companion object { const val EGL_RECORDABLE_ANDROID = 0x3142 }
}

private fun floatBuf(n: Int): FloatBuffer = ByteBuffer.allocateDirect(n * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
private fun floatBuf(a: FloatArray): FloatBuffer = floatBuf(a.size).also { it.put(a); it.position(0) }

private fun compile(type: Int, src: String): Int {
    val s = GLES20.glCreateShader(type)
    GLES20.glShaderSource(s, src); GLES20.glCompileShader(s)
    val ok = IntArray(1); GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
    check(ok[0] != 0) { "Shader gagal dikompilasi: ${GLES20.glGetShaderInfoLog(s)}" }
    return s
}

private fun program(vs: String, fs: String): Int {
    val p = GLES20.glCreateProgram()
    GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, vs)); GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, fs))
    GLES20.glLinkProgram(p)
    val ok = IntArray(1); GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
    check(ok[0] != 0) { "Program GL gagal ditautkan: ${GLES20.glGetProgramInfoLog(p)}" }
    return p
}

/**
 * Penggambar medan 3D: mesh dari grid elevasi bertekstur citra satelit, garis rute (jejak tertempuh terang, sisanya redup),
 * dan penanda posisi, lalu lapisan 2D (panel data) di atasnya. Posisi kamera datang dari [CameraPose].
 */
class TerrainGl(private val w: Int, private val h: Int) {
    private var pTerrain = 0; private var pRibbon = 0; private var pMarker = 0; private var pOverlay = 0
    private var texSat = 0; private var texOverlay = 0
    private var overlayReady = false

    private var scene: TerrainScene? = null
    private var ex = 1f
    private var pos: FloatBuffer? = null; private var uv: FloatBuffer? = null; private var nrm: FloatBuffer? = null
    private var idx: ShortBuffer? = null; private var idxCount = 0
    private var ribOutline: FloatBuffer? = null; private var ribMain: FloatBuffer? = null; private var ribCount = 0
    private val quad = floatBuf(floatArrayOf(-1f, 1f, 0f, 0f, -1f, -1f, 0f, 1f, 1f, 1f, 1f, 0f, 1f, -1f, 1f, 1f))
    private val bg = floatArrayOf(0.063f, 0.086f, 0.102f)

    /** Warna garis dan penanda rute. */
    var accent: Int = 0xFFC6F432.toInt()

    fun init() {
        pTerrain = program(
            """
            uniform mat4 uMvp; uniform float uHalf;
            attribute vec3 aPos; attribute vec2 aUv; attribute vec3 aNrm;
            varying vec2 vUv; varying float vShade; varying float vEdge;
            void main() {
              vUv = aUv;
              vec3 L = normalize(vec3(-0.55, 0.75, -0.35));
              vShade = 0.66 + 0.5 * max(dot(normalize(aNrm), L), 0.0);
              vEdge = max(abs(aPos.x), abs(aPos.z)) / uHalf;
              gl_Position = uMvp * vec4(aPos, 1.0);
            }
            """.trimIndent(),
            """
            precision mediump float;
            uniform sampler2D uTex; uniform vec3 uBg; uniform float uHasTex;
            varying vec2 vUv; varying float vShade; varying float vEdge;
            void main() {
              vec3 base = uHasTex > 0.5 ? texture2D(uTex, vUv).rgb : vec3(0.28, 0.33, 0.30);
              vec3 c = base * vShade;
              float f = smoothstep(0.80, 1.0, vEdge);
              gl_FragColor = vec4(mix(c, uBg, f), 1.0);
            }
            """.trimIndent(),
        )
        pRibbon = program(
            "uniform mat4 uMvp; attribute vec3 aPos; void main() { gl_Position = uMvp * vec4(aPos, 1.0); }",
            "precision mediump float; uniform vec4 uColor; void main() { gl_FragColor = vec4(uColor.rgb * uColor.a, uColor.a); }",
        )
        pMarker = program(
            "uniform mat4 uMvp; uniform float uSize; attribute vec3 aPos; void main() { gl_Position = uMvp * vec4(aPos, 1.0); gl_PointSize = uSize; }",
            """
            precision mediump float; uniform vec4 uColor;
            void main() {
              float d = length(gl_PointCoord - vec2(0.5)) * 2.0;
              if (d > 1.0) discard;
              vec3 col = d > 0.66 ? vec3(1.0) : uColor.rgb;
              float a = 1.0 - smoothstep(0.92, 1.0, d);
              gl_FragColor = vec4(col * a, a);
            }
            """.trimIndent(),
        )
        pOverlay = program(
            "attribute vec2 aPos; attribute vec2 aUv; varying vec2 vUv; void main() { vUv = aUv; gl_Position = vec4(aPos, 0.0, 1.0); }",
            "precision mediump float; uniform sampler2D uTex; varying vec2 vUv; void main() { gl_FragColor = texture2D(uTex, vUv); }",
        )
        val t = IntArray(2); GLES20.glGenTextures(2, t, 0); texSat = t[0]; texOverlay = t[1]
    }

    private fun texParams() {
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
    }

    /** Pasang medan; dipanggil lagi bila [exaggeration] berubah (menghitung ulang mesh, normal, dan garis). */
    fun setScene(s: TerrainScene, exaggeration: Float, reuseTexture: Boolean) {
        scene = s; ex = exaggeration
        val n = s.n; val size = s.sizeM
        val p = FloatArray(n * n * 3); val u = FloatArray(n * n * 2); val nr = FloatArray(n * n * 3)
        val dx = size / (n - 1)
        fun hAt(i: Int, j: Int) = s.heights[j.coerceIn(0, n - 1) * n + i.coerceIn(0, n - 1)]
        for (j in 0 until n) for (i in 0 until n) {
            val q = j * n + i
            p[q * 3] = (i.toFloat() / (n - 1) - .5f) * size
            p[q * 3 + 1] = (s.heights[q] - s.minH) * ex
            p[q * 3 + 2] = (j.toFloat() / (n - 1) - .5f) * size
            u[q * 2] = i.toFloat() / (n - 1); u[q * 2 + 1] = j.toFloat() / (n - 1)
            val nx = (hAt(i - 1, j) - hAt(i + 1, j)) * ex
            val ny = 2f * dx
            val nz = (hAt(i, j - 1) - hAt(i, j + 1)) * ex
            val len = sqrt(nx * nx + ny * ny + nz * nz)
            nr[q * 3] = nx / len; nr[q * 3 + 1] = ny / len; nr[q * 3 + 2] = nz / len
        }
        pos = floatBuf(p); uv = floatBuf(u); nrm = floatBuf(nr)
        val ind = ShortArray((n - 1) * (n - 1) * 6)
        var k = 0
        for (j in 0 until n - 1) for (i in 0 until n - 1) {
            val a = (j * n + i).toShort(); val b = (j * n + i + 1).toShort()
            val c = ((j + 1) * n + i).toShort(); val d = ((j + 1) * n + i + 1).toShort()
            ind[k++] = a; ind[k++] = c; ind[k++] = b
            ind[k++] = b; ind[k++] = c; ind[k++] = d
        }
        idx = ByteBuffer.allocateDirect(ind.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer().also { it.put(ind); it.position(0) }
        idxCount = ind.size

        if (!reuseTexture) {
            val bmp = s.satellite
            if (bmp != null) {
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texSat)
                val big = max(bmp.width, bmp.height)
                if (big > 2048) {
                    val f = 2048f / big
                    val small = Bitmap.createScaledBitmap(bmp, (bmp.width * f).toInt().coerceAtLeast(2), (bmp.height * f).toInt().coerceAtLeast(2), true)
                    GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, small, 0); small.recycle()
                } else GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
                texParams()
            }
        }
        buildRibbons(s)
    }

    private fun buildRibbons(s: TerrainScene) {
        val m = s.routeX.size
        ribCount = m
        val half = s.sizeM * 0.0055f; val lift = s.sizeM * 0.0035f
        fun ribbon(wf: Float): FloatBuffer {
            val a = FloatArray(m * 6)
            for (i in 0 until m) {
                val i0 = (i - 1).coerceAtLeast(0); val i1 = (i + 1).coerceAtMost(m - 1)
                var tx = s.routeX[i1] - s.routeX[i0]; var tz = s.routeZ[i1] - s.routeZ[i0]
                val l = sqrt(tx * tx + tz * tz).coerceAtLeast(1e-3f); tx /= l; tz /= l
                val px = -tz * half * wf; val pz = tx * half * wf
                val y = (s.routeY[i] - s.minH) * ex + lift
                a[i * 6] = s.routeX[i] + px; a[i * 6 + 1] = y; a[i * 6 + 2] = s.routeZ[i] + pz
                a[i * 6 + 3] = s.routeX[i] - px; a[i * 6 + 4] = y; a[i * 6 + 5] = s.routeZ[i] - pz
            }
            return floatBuf(a)
        }
        ribOutline = ribbon(1.7f); ribMain = ribbon(1f)
    }

    private fun rgb(c: Int) = floatArrayOf(Color.red(c) / 255f, Color.green(c) / 255f, Color.blue(c) / 255f)

    /** Gambar satu frame. [overlay] (ukuran sama dengan bingkai) digambar paling atas bila tidak null. */
    fun render(cam: CameraPose, overlay: Bitmap?) {
        val s = scene ?: return
        val size = s.sizeM
        val yOf = { hh: Float -> (hh - s.minH) * ex }

        // Posisi pelari: interpolasi antar titik rute menurut bagian jarak.
        val m = s.routeX.size
        val r = cam.routeFrac.toFloat().coerceIn(0f, 1f)
        var k = 0
        var lo = 0; var hi = m - 1
        while (lo < hi) { val mid = (lo + hi) ushr 1; if (s.routeFrac[mid] >= r) hi = mid else lo = mid + 1 }
        k = lo
        val cx: Float; val cz: Float; val cy: Float
        if (k == 0) { cx = s.routeX[0]; cz = s.routeZ[0]; cy = s.routeY[0] } else {
            val a = s.routeFrac[k - 1]; val b = s.routeFrac[k]
            val f = if (b > a) ((r - a) / (b - a)).coerceIn(0f, 1f) else 0f
            cx = s.routeX[k - 1] + (s.routeX[k] - s.routeX[k - 1]) * f
            cz = s.routeZ[k - 1] + (s.routeZ[k] - s.routeZ[k - 1]) * f
            cy = s.routeY[k - 1] + (s.routeY[k] - s.routeY[k - 1]) * f
        }
        val doneCount = if (r <= 0f) 0 else if (r >= 1f) m else k   // titik rute yang sudah dilewati

        val fo = cam.follow.toFloat()
        val tx = cx * fo; val tz = cz * fo
        val ty = yOf(s.heightAt(tx, tz))
        val d = size * 0.95f * cam.distMul.toFloat()
        val az = Math.toRadians(cam.azimuthDeg).toFloat(); val pt = Math.toRadians(cam.pitchDeg).toFloat()
        val ex0 = tx + d * cos(pt) * sin(az)
        val ey0 = max(ty + d * sin(pt), yOf(s.maxH) + size * 0.05f)
        val ez0 = tz + d * cos(pt) * cos(az)

        val proj = FloatArray(16); val view = FloatArray(16); val mvp = FloatArray(16)
        Matrix.perspectiveM(proj, 0, 45f, w.toFloat() / h, d * 0.05f, d * 5f)
        Matrix.setLookAtM(view, 0, ex0, ey0, ez0, tx, ty, tz, 0f, 1f, 0f)
        Matrix.multiplyMM(mvp, 0, proj, 0, view, 0)

        GLES20.glViewport(0, 0, w, h)
        GLES20.glClearColor(bg[0], bg[1], bg[2], 1f)
        GLES20.glDepthMask(true)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDisable(GLES20.GL_BLEND)

        // Medan
        GLES20.glUseProgram(pTerrain)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(pTerrain, "uMvp"), 1, false, mvp, 0)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(pTerrain, "uHalf"), size / 2)
        GLES20.glUniform3f(GLES20.glGetUniformLocation(pTerrain, "uBg"), bg[0], bg[1], bg[2])
        GLES20.glUniform1f(GLES20.glGetUniformLocation(pTerrain, "uHasTex"), if (s.satellite != null) 1f else 0f)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texSat)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(pTerrain, "uTex"), 0)
        val aPos = GLES20.glGetAttribLocation(pTerrain, "aPos"); val aUv = GLES20.glGetAttribLocation(pTerrain, "aUv"); val aNrm = GLES20.glGetAttribLocation(pTerrain, "aNrm")
        pos!!.position(0); uv!!.position(0); nrm!!.position(0); idx!!.position(0)
        GLES20.glEnableVertexAttribArray(aPos); GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 0, pos)
        GLES20.glEnableVertexAttribArray(aUv); GLES20.glVertexAttribPointer(aUv, 2, GLES20.GL_FLOAT, false, 0, uv)
        GLES20.glEnableVertexAttribArray(aNrm); GLES20.glVertexAttribPointer(aNrm, 3, GLES20.GL_FLOAT, false, 0, nrm)
        GLES20.glDrawElements(GLES20.GL_TRIANGLES, idxCount, GLES20.GL_UNSIGNED_SHORT, idx)
        GLES20.glDisableVertexAttribArray(aPos); GLES20.glDisableVertexAttribArray(aUv); GLES20.glDisableVertexAttribArray(aNrm)

        // Garis rute (tanpa menulis kedalaman, supaya lapisannya tidak saling berebut)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glDepthMask(false)
        GLES20.glUseProgram(pRibbon)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(pRibbon, "uMvp"), 1, false, mvp, 0)
        val rPos = GLES20.glGetAttribLocation(pRibbon, "aPos"); val rCol = GLES20.glGetUniformLocation(pRibbon, "uColor")
        GLES20.glEnableVertexAttribArray(rPos)
        fun strip(buf: FloatBuffer, firstPt: Int, pts: Int, c: FloatArray) {
            if (pts < 2) return
            buf.position(firstPt * 6)
            GLES20.glVertexAttribPointer(rPos, 3, GLES20.GL_FLOAT, false, 0, buf)
            GLES20.glUniform4f(rCol, c[0], c[1], c[2], c[3])
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, pts * 2)
        }
        val outline = ribOutline!!; val main = ribMain!!
        strip(outline, 0, ribCount, floatArrayOf(0f, 0f, 0f, 0.5f))
        val rest = (doneCount - 1).coerceAtLeast(0)
        strip(main, rest, ribCount - rest, floatArrayOf(1f, 1f, 1f, 0.55f))
        val ac = rgb(accent)
        strip(main, 0, doneCount, floatArrayOf(ac[0], ac[1], ac[2], 1f))
        GLES20.glDisableVertexAttribArray(rPos)

        // Penanda posisi
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glUseProgram(pMarker)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(pMarker, "uMvp"), 1, false, mvp, 0)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(pMarker, "uSize"), 38f * w / 1080f)
        GLES20.glUniform4f(GLES20.glGetUniformLocation(pMarker, "uColor"), ac[0], ac[1], ac[2], 1f)
        val mPos = GLES20.glGetAttribLocation(pMarker, "aPos")
        val mk = floatBuf(floatArrayOf(cx, yOf(cy) + size * 0.006f, cz))
        GLES20.glEnableVertexAttribArray(mPos); GLES20.glVertexAttribPointer(mPos, 3, GLES20.GL_FLOAT, false, 0, mk)
        GLES20.glDrawArrays(GLES20.GL_POINTS, 0, 1)
        GLES20.glDisableVertexAttribArray(mPos)

        // Lapisan 2D
        if (overlay != null) {
            GLES20.glUseProgram(pOverlay)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texOverlay)
            if (!overlayReady) { GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, overlay, 0); texParams(); overlayReady = true }
            else GLUtils.texSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0, 0, overlay)
            GLES20.glUniform1i(GLES20.glGetUniformLocation(pOverlay, "uTex"), 0)
            val oPos = GLES20.glGetAttribLocation(pOverlay, "aPos"); val oUv = GLES20.glGetAttribLocation(pOverlay, "aUv")
            quad.position(0)
            GLES20.glEnableVertexAttribArray(oPos); GLES20.glVertexAttribPointer(oPos, 2, GLES20.GL_FLOAT, false, 16, quad)
            quad.position(2)
            GLES20.glEnableVertexAttribArray(oUv); GLES20.glVertexAttribPointer(oUv, 2, GLES20.GL_FLOAT, false, 16, quad)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GLES20.glDisableVertexAttribArray(oPos); GLES20.glDisableVertexAttribArray(oUv)
            quad.position(0)
        }
        GLES20.glDepthMask(true)
    }

    /** Baca piksel bingkai saat ini (untuk pratinjau). */
    fun readFrame(): Bitmap {
        val buf = ByteBuffer.allocateDirect(w * h * 4).order(ByteOrder.nativeOrder())
        GLES20.glReadPixels(0, 0, w, h, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf)
        val raw = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        raw.copyPixelsFromBuffer(buf)
        val flipped = Bitmap.createBitmap(raw, 0, 0, w, h, GMatrix().apply { postScale(1f, -1f) }, false)
        raw.recycle()
        return flipped
    }

    fun release() {
        runCatching {
            GLES20.glDeleteTextures(2, intArrayOf(texSat, texOverlay), 0)
            for (p in intArrayOf(pTerrain, pRibbon, pMarker, pOverlay)) if (p != 0) GLES20.glDeleteProgram(p)
        }
    }
}

/**
 * Pratinjau: satu konteks pbuffer 540x960 yang dipakai ulang. Semua pemanggilan harus dari thread GL yang sama.
 */
class PreviewGl {
    companion object { const val W = 540; const val H = 960 }
    private var egl: EglCore? = null
    private var gl: TerrainGl? = null
    private var sceneKey: TerrainScene? = null
    private var exKey = -1f

    /** Bingkai medan tanpa panel data. */
    fun frame(scene: TerrainScene, exaggeration: Float, cam: CameraPose, accent: Int): Bitmap {
        // Render video memakai konteks EGL sendiri di thread yang sama dan melepasnya saat selesai, jadi pasang ulang tiap bingkai.
        if (egl != null && runCatching { egl!!.makeCurrent() }.isFailure) release()
        if (egl == null) {
            egl = EglCore(null, W, H).also { it.makeCurrent() }
            gl = TerrainGl(W, H).also { it.init() }
        }
        val g = gl!!
        if (scene !== sceneKey || exaggeration != exKey) {
            g.setScene(scene, exaggeration, reuseTexture = scene === sceneKey)
            sceneKey = scene; exKey = exaggeration
        }
        g.accent = accent
        g.render(cam, null)
        return g.readFrame()
    }

    fun release() {
        runCatching { gl?.release() }
        runCatching { egl?.release() }
        gl = null; egl = null; sceneKey = null
    }
}
