package com.endurancevault.app.ui.sticker

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.endurancevault.app.domain.StickerPrefs
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Penyimpanan pengaturan stiker (padanan `rl:stk`). */
class StickerPrefsStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("sticker_prefs", Context.MODE_PRIVATE)
    fun load(): StickerPrefs = StickerPrefs.fromJson(sp.getString("json", null))
    fun save(p: StickerPrefs) { sp.edit().putString("json", p.sanitized().toJson()).apply() }
}

/** Satu stiker di atas foto; [x], [y], [s] dalam persen bingkai hasil (bukan foto utuh), seperti di web. */
data class PhotoSticker(val u: Int, val id: String, val x: Double, val y: Double, val s: Double)

/** Susunan foto dan stiker (padanan `STK.pv`). [ar] = asli | 9:16 | 4:5 | 1:1, [co] = 0..1 posisi bingkai pada sumbu yang terpotong. */
data class PhotoPlan(
    val nw: Int, val nh: Int, val ar: String = "asli", val co: Double = .5,
    val items: List<PhotoSticker> = emptyList(), val sel: Int = 0, val nu: Int = 0,
)

/** Bagian foto yang masuk bingkai, dalam piksel sumber. */
class PhotoGeom(val r: Double, val free: Boolean, val sx: Double, val sy: Double, val sw: Double, val sh: Double)

object StickerIo {
    private val POS = listOf(6.0 to 58.0, 6.0 to 8.0, 48.0 to 58.0, 48.0 to 8.0, 27.0 to 33.0)

    fun ratio(q: PhotoPlan): Double = when (q.ar) { "9:16" -> 9.0 / 16; "4:5" -> .8; "1:1" -> 1.0; else -> q.nw.toDouble() / q.nh }

    /** Foto lebih lebar dari bingkai dipotong di kiri-kanan, lebih tinggi dipotong di atas-bawah (padanan `stkPvGeom`). */
    fun geom(q: PhotoPlan): PhotoGeom {
        val bigR = q.nw.toDouble() / q.nh; val r = ratio(q); val co = if (q.co in 0.0..1.0) q.co else .5
        var sw = q.nw.toDouble(); var sh = q.nh.toDouble(); var sx = 0.0; var sy = 0.0
        if (r < bigR - 1e-6) { sw = sh * r; sx = (q.nw - sw) * co } else if (r > bigR + 1e-6) { sh = sw / r; sy = (q.nh - sh) * co }
        return PhotoGeom(r, kotlin.math.abs(r - bigR) > 1e-6, sx, sy, sw, sh)
    }

    /** Tambah satu stiker (id belum terpakai didahulukan), posisi dari daftar bawaan. */
    fun addSticker(q: PhotoPlan, ids: List<String>): PhotoPlan {
        if (q.items.size >= 5 || ids.isEmpty()) return q
        val used = q.items.map { it.id }.toSet()
        val id = ids.firstOrNull { it !in used } ?: ids.first()
        val n = q.items.size; val ps = POS[n % POS.size]; val u = q.nu + 1
        return q.copy(items = q.items + PhotoSticker(u, id, ps.first, ps.second, if (n > 0) 44.0 else 60.0), sel = u, nu = u)
    }

    /**
     * Tempel otomatis: tepi bingkai (jarak 4%) dan garis tengah, dalam jarak 10 px layar. Semua angka dalam persen bingkai.
     * Mengembalikan posisi baru dan garis bantu (null = tidak menempel).
     */
    fun snap(x: Double, y: Double, w: Double, h: Double, rw: Double, rh: Double): Snap {
        val mx = 4.0; val my = 4 * rw / rh
        fun pick(v: Double, c: List<Pair<Double, Double>>, th: Double): Pair<Double, Double>? {
            var b = th; var r: Pair<Double, Double>? = null
            c.forEach { q -> val d = kotlin.math.abs(v - q.first); if (d <= b) { b = d; r = q } }
            return r
        }
        val cx = pick(x, listOf(mx to mx, (100 - mx - w) to (100 - mx), (50 - w / 2) to 50.0), 10 / rw * 100)
        val cy = pick(y, listOf(my to my, (100 - my - h) to (100 - my), (50 - h / 2) to 50.0), 10 / rh * 100)
        return Snap(cx?.first ?: x, cy?.first ?: y, cx?.second, cy?.second)
    }

    class Snap(val x: Double, val y: Double, val gx: Double?, val gy: Double?)

    /** Gabungkan bingkai foto dan semua stiker; sisi terpanjang dibatasi 2560 px. Null bila ada stiker yang belum siap. */
    fun compose(photo: Bitmap, q: PhotoPlan, stickers: Map<String, Bitmap>): Bitmap? {
        if (q.items.isEmpty() || q.items.any { stickers[it.id] == null }) return null
        val g = geom(PhotoPlan(photo.width, photo.height, q.ar, q.co))
        val k = min(1.0, 2560 / max(g.sw, g.sh))
        val w = (g.sw * k).roundToInt(); val h = (g.sh * k).roundToInt()
        val out = Bitmap.createBitmap(max(2, w), max(2, h), Bitmap.Config.ARGB_8888)
        val c = Canvas(out); val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        c.drawBitmap(photo, Rect(g.sx.roundToInt(), g.sy.roundToInt(), (g.sx + g.sw).roundToInt(), (g.sy + g.sh).roundToInt()), Rect(0, 0, w, h), p)
        q.items.forEach { it ->
            val cv = stickers.getValue(it.id)
            val dw = it.s / 100 * w; val dh = dw * cv.height / cv.width
            val dx = it.x / 100 * w; val dy = it.y / 100 * h
            c.drawBitmap(cv, null, android.graphics.RectF(dx.toFloat(), dy.toFloat(), (dx + dw).toFloat(), (dy + dh).toFloat()), p)
        }
        return out
    }

    /** Baca foto dari galeri, diperkecil bila terlalu besar (sisi terpanjang <= ~3000 px) dan diputar sesuai EXIF. */
    fun decodePhoto(ctx: Context, uri: Uri): Bitmap? = runCatching {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > 3000) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return@runCatching null
        val orient = cr.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) }
            ?: ExifInterface.ORIENTATION_NORMAL
        val m = Matrix()
        when (orient) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            else -> return@runCatching bmp
        }
        Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }.getOrNull()

    /**
     * Simpan PNG ke galeri, album TrainingPlan (Android 10+ tanpa izin). Android 9 ke bawah: folder foto milik aplikasi,
     * karena menulis ke galeri butuh izin penyimpanan yang tidak diminta aplikasi ini.
     * Mengembalikan teks lokasi untuk pesan ke pengguna.
     */
    fun saveToGallery(ctx: Context, name: String, bmp: Bitmap): Result<String> = runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/TrainingPlan")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val cr = ctx.contentResolver
            val uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: error("galeri menolak berkas")
            try {
                cr.openOutputStream(uri)!!.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                cr.update(uri, ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }, null, null)
            } catch (e: Exception) { cr.delete(uri, null, null); throw e }
            "galeri, album TrainingPlan"
        } else {
            val dir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_PICTURES), "TrainingPlan").apply { mkdirs() }
            FileOutputStream(File(dir, name)).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            "folder aplikasi (${dir.absolutePath})"
        }
    }

    /** Bagikan PNG lewat lembar berbagi sistem: tulis ke cache lalu kirim lewat FileProvider. */
    fun share(ctx: Context, name: String, bmp: Bitmap, title: String = "Bagikan foto"): Result<Unit> = runCatching {
        val dir = File(ctx.cacheDir, "stickers").apply { mkdirs() }
        dir.listFiles()?.filter { it.lastModified() < System.currentTimeMillis() - 24 * 3600_000L }?.forEach { it.delete() }
        val f = File(dir, name)
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
