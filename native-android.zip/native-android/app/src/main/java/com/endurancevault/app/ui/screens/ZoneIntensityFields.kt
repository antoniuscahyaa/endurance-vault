package com.endurancevault.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.domain.EasyPace
import com.endurancevault.app.domain.Js
import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.domain.ZoneChecks
import com.endurancevault.app.domain.Zones

private fun shortDate(iso: String): String =
    java.time.LocalDate.parse(iso).format(java.time.format.DateTimeFormatter.ofPattern("d MMM", java.util.Locale("id", "ID")))

/**
 * Tiga isian di tab Zona HR Profil: Batas HR easy, Rentang HR threshold, Pace easy.
 * Divalidasi langsung, menampilkan angka yang dipakai dibanding zona default, dan tersimpan otomatis
 * (saat kolom kehilangan fokus, Done ditekan, atau tombol Samakan/Pakai) bila ketiganya valid.
 * Saran pace easy = rata-rata [RECENT_EASY_RUNS] lari easy terakhir.
 */
@Composable
internal fun ZoneIntensityFields(
    s: PlanSettings,
    hr: String, onHr: (String) -> Unit,
    thr: String, onThr: (String) -> Unit,
    pace: String, onPace: (String) -> Unit,
    activities: List<ActivityEntity>,
    restDefault: Int,
    onSave: (PlanSettings) -> Unit,
) {
    val zc = Zones.cuts(s, restDefault)
    val (easyZ, thrZ) = Zones.sessionRefs(zc)
    val hrErr = ZoneChecks.easyHr(hr)
    val thrErr = ZoneChecks.thrRange(thr)
    val paceErr = ZoneChecks.pace(pace)

    fun commit(h: String = hr, t: String = thr, p: String = pace) {
        if (ZoneChecks.easyHr(h) != null || ZoneChecks.thrRange(t) != null || ZoneChecks.pace(p) != null) return
        val n = s.copy(hr = h.trim().toInt(), thr = t.trim(), pace = p.trim())
        if (n != s) onSave(n)
    }

    val sub = MaterialTheme.typography.bodySmall
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val done = KeyboardActions(onDone = { commit() })

    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        // Batas HR easy
        OutlinedTextField(
            hr, { onHr(it.filter(Char::isDigit).take(3)) }, label = { Text("Batas HR easy") }, singleLine = true,
            isError = hrErr != null,
            supportingText = {
                val h = hr.trim().toIntOrNull()
                Text(
                    hrErr ?: if (h == easyZ) "Dipakai: $h bpm, sama dengan batas atas Z2 zona default."
                    else "Dipakai: $h bpm. Zona default: batas atas Z2 = $easyZ bpm.",
                    style = sub,
                )
            },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done), keyboardActions = done,
            modifier = Modifier.fillMaxWidth().commitOnBlur { commit() },
        )
        if (hrErr == null && hr.trim().toIntOrNull() != easyZ) {
            TextButton(onClick = { onHr(easyZ.toString()); commit(h = easyZ.toString()) }) { Text("Samakan dengan zona ($easyZ bpm)") }
        }

        // Rentang threshold
        OutlinedTextField(
            thr, onThr, label = { Text("Rentang HR threshold (mis. 164–172)") }, singleLine = true,
            isError = thrErr != null,
            supportingText = {
                Text(thrErr ?: "Dipakai untuk sesi threshold: ${thr.trim()} bpm. Zona default Z4: ${thrZ.first}–${thrZ.last} bpm.", style = sub)
            },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done), keyboardActions = done,
            modifier = Modifier.fillMaxWidth().commitOnBlur { commit() },
        )

        // Pace easy + saran dari lari easy terakhir
        OutlinedTextField(
            pace, onPace, label = { Text("Pace easy (m:ss)") }, singleLine = true,
            isError = paceErr != null,
            supportingText = { Text(paceErr ?: "Dipakai untuk target pace sesi easy: ${pace.trim()}/km.", style = sub) },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done), keyboardActions = done,
            modifier = Modifier.fillMaxWidth().commitOnBlur { commit() },
        )
        val limit = hr.trim().toIntOrNull()?.takeIf { hrErr == null } ?: easyZ
        val recent = EasyPace.recentAverage(
            activities.map { EasyPace.Run(it.dateIso, it.km, it.durationSec / 60.0, it.avgHr, it.type, it.gain) }, limit, RECENT_EASY_RUNS,
        )
        if (recent == null) {
            Text("Belum ada lari easy (HR rata-rata sampai $limit bpm) untuk saran pace.", style = sub, color = muted, modifier = Modifier.padding(horizontal = 16.dp))
        } else {
            val sug = Js.paceStr(recent.pace)
            val range = if (recent.firstDate == recent.lastDate) shortDate(recent.lastDate) else "${shortDate(recent.firstDate)} – ${shortDate(recent.lastDate)}"
            val same = paceErr == null && kotlin.math.abs(Js.parsePaceStr(pace) - recent.pace) < 5.0 / 60
            Text(
                (if (same) "Sudah sesuai rata-rata " else "Saran: $sug/km, rata-rata ") + "${recent.n} lari easy terakhir (${fmtKmShort(recent.km)} km, $range)" + if (same) ": $sug/km." else ".",
                style = sub, color = muted, modifier = Modifier.padding(horizontal = 16.dp),
            )
            if (!same) TextButton(onClick = { onPace(sug); commit(p = sug) }) { Text("Pakai $sug/km") }
        }
    }
}

internal const val RECENT_EASY_RUNS = 5

private fun fmtKmShort(km: Double): String = Js.fmtKm(km)
