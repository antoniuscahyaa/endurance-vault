package com.endurancevault.app.domain

/**
 * Penyusun sesi: pengguna menyusun urutan blok (segmen biasa dan blok ulangi kerja + istirahat) lalu diubah menjadi
 * batas segmen untuk [SegmentSplit]. Murni, tanpa Android.
 *
 * Tiap blok boleh membawa label teks bebas (opsional) yang diteruskan ke segmen hasilnya; label kosong berarti tanpa label.
 * Selisih antara susunan dan sesi sebenarnya (mis. jam berjalan 12 dtk lebih panjang) masuk ke segmen terakhir.
 */
object SessionBuilder {
    const val MAX_REPEAT = 99

    /** Panjang satu segmen: [value] detik bila waktu, meter bila [byDistance]. */
    class Amount(val value: Double, val byDistance: Boolean)

    sealed class Block {
        /** Segmen biasa. [amount] null = isian belum valid. [label] = label segmen (opsional). */
        class Plain(val title: String, val amount: Amount?, val label: String? = null) : Block()

        /**
         * Blok ulangi: [count] putaran kerja + istirahat. Istirahat bernilai 0 berarti tanpa istirahat.
         * [restAfterLast] menentukan apakah putaran terakhir ditutup istirahat. Properti null = isian belum valid.
         * [workLabel] dan [restLabel] = label segmen kerja dan istirahat (opsional).
         */
        class Repeat(
            val title: String, val count: Int?, val work: Amount?, val rest: Amount?, val restAfterLast: Boolean,
            val workLabel: String? = null, val restLabel: String? = null,
        ) : Block()
    }

    /**
     * Hasil penyusunan. [error] null bila [drafts] siap dipakai. [segments] berisi rentang nomor segmen (mulai 1) tiap blok,
     * [blockSec] lama tiap blok (blok terakhir sudah memuat selisih), [isWork] menandai segmen kerja pada blok ulangi.
     * Ketiganya kosong bila isian belum valid.
     */
    class Plan(
        val drafts: List<SegmentSplit.Draft>,
        val segments: List<IntRange?>,
        val blockSec: List<Int>,
        val isWork: List<Boolean>,
        val composedSec: Int,
        val extraSec: Int,
        val error: String?,
    )

    private class Piece(val block: Int, val amount: Amount, val work: Boolean, val label: String?)

    private fun invalid(msg: String) = Plan(emptyList(), emptyList(), emptyList(), emptyList(), 0, 0, msg)

    fun resolve(ts: ActivityTimeSeries, blocks: List<Block>): Plan {
        if (blocks.isEmpty()) return invalid("Tambahkan minimal satu segmen")
        val total = SegmentSplit.totalSec(ts)
        val totalM = ts.distanceMeters.last() - ts.distanceMeters.first()

        val pieces = ArrayList<Piece>()
        for ((bi, b) in blocks.withIndex()) when (b) {
            is Block.Plain -> pieces += Piece(bi, b.amount ?: return invalid("Lengkapi isian yang berwarna merah"), false, b.label)
            is Block.Repeat -> {
                val n = b.count ?: return invalid("Lengkapi isian yang berwarna merah")
                if (n < 1 || n > MAX_REPEAT) return invalid("Jumlah putaran 1 sampai $MAX_REPEAT")
                val work = b.work ?: return invalid("Lengkapi isian yang berwarna merah")
                val rest = b.rest ?: return invalid("Lengkapi isian yang berwarna merah")
                for (r in 1..n) {
                    pieces += Piece(bi, work, true, b.workLabel)
                    if (rest.value > 0 && (r < n || b.restAfterLast)) pieces += Piece(bi, rest, false, b.restLabel)
                }
            }
        }

        // Batas tiap potongan, berurutan. Jarak diubah ke detik lewat deret 1 Hz.
        val ends = ArrayList<Int>()
        var cur = 0
        var over = false
        for (p in pieces) {
            val end = if (p.amount.byDistance) {
                val m = SegmentSplit.metersAt(ts, cur) + p.amount.value
                if (m > totalM + 0.5) over = true
                SegmentSplit.secAtMeters(ts, m)
            } else {
                val e = cur + Math.round(p.amount.value).toInt()
                if (e > total) over = true
                e
            }
            ends += end
            cur = end
        }

        val spans = ArrayList<IntRange?>(blocks.indices.map { null })
        pieces.forEachIndexed { i, p ->
            val old = spans[p.block]
            spans[p.block] = if (old == null) (i + 1)..(i + 1) else old.first..(i + 1)
        }
        val blockSec = IntArray(blocks.size)
        var prev = 0
        pieces.forEachIndexed { i, p ->
            val e = if (i == pieces.lastIndex) maxOf(total, ends[i]) else ends[i]
            blockSec[p.block] += e - prev
            prev = e
        }
        val work = pieces.map { it.work }

        if (over) {
            return Plan(
                emptyList(), spans, blockSec.toList(), work, ends.last(), 0,
                "Susunan lebih panjang dari sesi (${SegmentSplit.fmtSeconds(total)}). Kurangi panjang atau jumlah putaran.",
            )
        }
        val composed = ends.last()
        val finalEnds = ends.toMutableList().also { it[it.lastIndex] = total }
        val drafts = pieces.mapIndexed { i, p -> SegmentSplit.draft(finalEnds[i], p.amount.byDistance, p.label) }
        val problem = SegmentSplit.validate(ts, drafts)
        return Plan(if (problem == null) drafts else emptyList(), spans, blockSec.toList(), work, composed, total - composed, problem)
    }
}
