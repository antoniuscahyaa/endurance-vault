package com.endurancevault.app.domain

/**
 * Cocokkan rasa (1..10) dengan zona HR rata-rata. Rasa 1–2 = Z1, 3–4 = Z2, 5–6 = Z3, 7–8 = Z4, 9–10 = Z5 dari zona pribadi (Zones.cuts).
 * [pct] = HR rata-rata sebagai persen batas atas zona yang sesuai dengan rasa; ≤ 100 berarti masih di dalam batas rasa itu.
 */
object FeelCheck {
    data class Result(val level: String, val text: String, val zone: Int, val pct: Double)

    fun zoneOfFeel(feel10: Int): Int = (feel10 + 1) / 2

    fun evaluate(feel10: Int?, avgHr: Int?, cuts: ZoneCuts): Result? {
        if (feel10 == null || feel10 !in 1..10 || avgHr == null || avgHr <= 0) return null
        val fz = zoneOfFeel(feel10)
        val zone = Zones.zoneOf(avgHr, cuts.lo) + 1
        val top = if (fz < 5) cuts.lo[fz] - 1 else cuts.maxHr
        val pct = if (top > 0) avgHr * 100.0 / top else 0.0
        val p = String.format(java.util.Locale.ROOT, "%.1f", pct)
        return when {
            fz == zone -> Result("ok", "HR: Efficient ($p%). A feel of $feel10 matches HR.", zone, pct)
            fz > zone -> Result("warn", "HR: Zone $zone only ($p%), yet it felt $feel10. Check heat, sleep or fatigue.", zone, pct)
            else -> Result("info", "HR: Zone $zone ($p%), higher than a feel of $feel10 suggests. Fitness may be ahead of the effort.", zone, pct)
        }
    }
}
