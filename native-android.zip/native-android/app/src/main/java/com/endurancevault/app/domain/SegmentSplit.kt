package com.endurancevault.app.domain

/**
 * Jenis dan label segmen pada sesi lari. Label adalah teks bebas (maks. [MAX_LABEL] karakter) di kunci `lb` objek segmen
 * (`sg`) pada berkas detail. Kunci `ty` menyimpan jenis bawaan (repetisi, stride, progresif) dan hanya terisi bila teks label
 * sama dengan salah satunya (tanpa memperhatikan huruf besar/kecil), supaya warna dan data lama tetap berlaku.
 * Segmen lama yang hanya punya `ty` tetap tampil dengan nama jenisnya. Nilai `ty` lain dari impor FIT (mis. penanda lap)
 * dianggap "tanpa label".
 */
object SegKind {
    const val REPETITION = "repetition"
    const val STRIDE = "stride"
    const val PROGRESSIVE = "progressive"
    val ALL = listOf(REPETITION, STRIDE, PROGRESSIVE)

    /** Panjang label terbanyak. */
    const val MAX_LABEL = 24

    /** Saran label di editor (hanya jalan pintas, teks tetap bebas). */
    val SUGGESTIONS = listOf("Pemanasan", "Repetisi", "Stride", "Progresif", "Istirahat", "Pendinginan")
    val REST_SUGGESTIONS = listOf("Istirahat", "Jogging pelan")

    /** Teks label bersih untuk disimpan: spasi dirapikan, dipotong ke [MAX_LABEL]; null bila kosong. */
    fun clean(text: String?): String? =
        text?.trim()?.replace(Regex("\\s+"), " ")?.take(MAX_LABEL)?.trim()?.ifEmpty { null }

    /** Jenis bawaan yang cocok dengan teks (tanpa memperhatikan huruf besar/kecil), atau null untuk label buatan sendiri. */
    fun kindOf(text: String?): String? {
        val t = clean(text) ?: return null
        return ALL.firstOrNull { label(it).equals(t, ignoreCase = true) }
    }

    /** Teks yang ditampilkan: label buatan sendiri, kalau tidak ada nama jenis lama, kalau tidak ada null. */
    fun displayLabel(custom: String?, kind: String?): String? = clean(custom) ?: normalize(kind)?.let { label(it) }

    fun normalize(raw: String?): String? = raw?.takeIf { it in ALL }

    fun label(kind: String?): String = when (kind) {
        REPETITION -> "Repetisi"
        STRIDE -> "Stride"
        PROGRESSIVE -> "Progresif"
        else -> "Tanpa label"
    }
}

/**
 * Pembagian sesi menjadi segmen secara manual, berdasarkan waktu atau jarak. Murni, tanpa Android.
 *
 * Sumbu kerjanya detik bergerak pada deret 1 Hz (`tl`), sama dengan crop. Batas segmen disimpan sebagai detik;
 * input jarak diubah ke detik lewat [secAtMeters], jadi satu model menampung dua cara input.
 */
object SegmentSplit {
    /** Segmen terpendek yang boleh dibuat. Stride 10-20 dtk tetap muat. */
    const val MIN_SEG_SEC = 5

    /**
     * Satu segmen: berakhir di [endSec] (detik bergerak sejak awal), jenisnya [kind] (null = tanpa label).
     * [byDistance] hanya memilih cara editor menampilkan dan menerima panjang segmen (meter atau waktu); batasnya tetap detik,
     * jadi tiap segmen boleh memakai satuan sendiri (repetisi per jarak, jeda per waktu).
     */
    data class Draft(val endSec: Int, val kind: String?, val byDistance: Boolean = false, val label: String? = null) {
        /** Teks label untuk editor (mentah, belum dirapikan, supaya spasi saat mengetik tidak hilang). */
        val text: String? get() = label ?: SegKind.normalize(kind)?.let { SegKind.label(it) }

        /** Salinan dengan label diganti [raw]; jenis bawaan mengikuti teks, kosong berarti tanpa label. */
        fun withText(raw: String): Draft {
            val t = raw.take(SegKind.MAX_LABEL)
            return copy(label = t.ifEmpty { null }, kind = SegKind.kindOf(t))
        }
    }

    /** Draft dari panjang yang sudah jadi dan teks label (null/kosong = tanpa label). */
    fun draft(endSec: Int, byDistance: Boolean, text: String?): Draft {
        val t = SegKind.clean(text)
        return Draft(endSec, SegKind.kindOf(t), byDistance, t)
    }

    class Stats(
        val startSec: Int, val endSec: Int, val meters: Double, val seconds: Int,
        val avgHr: Int?, val avgCad: Int?, val gain: Int, val loss: Int,
    ) {
        val km: Double get() = meters / 1000.0
        /** Pace menit per km, null bila jarak atau waktu nol. */
        val pace: Double? get() = if (meters > 0 && seconds > 0) seconds / 60.0 / km else null
    }

    fun totalSec(ts: ActivityTimeSeries): Int = ts.seconds.last() - ts.seconds.first()

    private fun idxAtOrAfter(ts: ActivityTimeSeries, sec: Int): Int {
        val target = ts.seconds.first() + sec
        var lo = 0; var hi = ts.seconds.size - 1
        while (lo < hi) { val mid = (lo + hi) ushr 1; if (ts.seconds[mid] < target) lo = mid + 1 else hi = mid }
        return lo
    }

    /** Jarak (m) yang sudah ditempuh pada detik [sec]. */
    fun metersAt(ts: ActivityTimeSeries, sec: Int): Double =
        ts.distanceMeters[idxAtOrAfter(ts, sec)] - ts.distanceMeters.first()

    /** Detik pertama yang jarak tempuhnya sudah mencapai [meters]; ujung sesi bila melebihi total. */
    fun secAtMeters(ts: ActivityTimeSeries, meters: Double): Int {
        val base = ts.distanceMeters.first()
        var lo = 0; var hi = ts.distanceMeters.size - 1
        while (lo < hi) { val mid = (lo + hi) ushr 1; if (ts.distanceMeters[mid] - base < meters) lo = mid + 1 else hi = mid }
        return ts.seconds[lo] - ts.seconds.first()
    }

    /** Galat validasi berbahasa Indonesia, atau null bila pembagian sah. Daftar kosong dianggap sah (tanpa segmen). */
    fun validate(ts: ActivityTimeSeries, drafts: List<Draft>): String? {
        if (drafts.isEmpty()) return null
        val total = totalSec(ts)
        var prev = 0
        drafts.forEachIndexed { i, d ->
            if (d.endSec - prev < MIN_SEG_SEC) return "Segmen ${i + 1} minimal $MIN_SEG_SEC detik"
            prev = d.endSec
        }
        if (drafts.last().endSec != total) return "Segmen terakhir harus berakhir di akhir sesi"
        return null
    }

    private fun gainLoss(elev: List<Double>, threshold: Double = 0.5): Pair<Int, Int> {
        if (elev.size < 2) return 0 to 0
        var ref = elev[0]; var gain = 0.0; var loss = 0.0
        for (e in elev) {
            if (e - ref >= threshold) { gain += e - ref; ref = e }
            else if (ref - e >= threshold) { loss += ref - e; ref = e }
        }
        return Math.round(gain).toInt() to Math.round(loss).toInt()
    }

    /** Statistik tiap segmen dari deret 1 Hz. [drafts] harus lolos [validate]. */
    fun stats(ts: ActivityTimeSeries, drafts: List<Draft>): List<Stats> {
        var startSec = 0
        return drafts.map { d ->
            val i0 = idxAtOrAfter(ts, startSec)
            val i1 = idxAtOrAfter(ts, d.endSec).coerceAtLeast(i0)
            val range = (i0 + 1)..i1
            val hr = range.map { ts.heartRateBpm[it] }.filter { it > 0 }
            val cad = range.map { ts.cadenceSpm[it] }.filter { it > 0 }
            val elev = (i0..i1).mapNotNull { ts.elevationMeters[it] }
            val (gain, loss) = gainLoss(elev)
            val s = Stats(
                startSec, d.endSec, ts.distanceMeters[i1] - ts.distanceMeters[i0], ts.seconds[i1] - ts.seconds[i0],
                hr.takeIf { it.isNotEmpty() }?.average()?.let { Math.round(it).toInt() },
                cad.takeIf { it.isNotEmpty() }?.average()?.let { Math.round(it).toInt() },
                gain, loss,
            )
            startSec = d.endSec
            s
        }
    }

    /**
     * Faktor kalibrasi elevasi aktivitas (gain, loss): total terkalibrasi jam dibagi hitungan aplikasi (`gain`/`gainRaw`,
     * `loss`/`lossRaw`; lihat ElevationCalibration). 1.0 bila aktivitas tidak dikalibrasi atau rasionya tidak masuk akal.
     * Dipakai agar elevasi segmen sejalan dengan tabel per km dan total aktivitas.
     */
    fun elevScales(act: Map<String, Any?>): Pair<Double, Double> {
        fun scale(cal: Any?, raw: Any?): Double {
            val c = (cal as? Number)?.toDouble() ?: return 1.0
            val r = (raw as? Number)?.toDouble() ?: return 1.0
            if (r <= 0 || c < 0) return 1.0
            return (c / r).takeIf { it.isFinite() && it in 0.2..5.0 } ?: 1.0
        }
        return scale(act["gain"], act["gainRaw"]) to scale(act["loss"], act["lossRaw"])
    }

    /**
     * Segmen siap pakai di layar detail. Nama berupa nomor urut; yang ditampilkan di daftar adalah labelnya.
     * [gainScale]/[lossScale] mengalikan elevasi segmen dengan faktor kalibrasi jam (lihat [elevScales]).
     */
    fun toSegments(ts: ActivityTimeSeries, drafts: List<Draft>, gainScale: Double = 1.0, lossScale: Double = 1.0): List<Segment> {
        var cumM = 0.0
        return stats(ts, drafts).mapIndexed { i, s ->
            cumM += s.meters
            Segment(
                k = cumM / 1000.0, d = s.km, min = s.seconds / 60.0, pace = s.pace ?: 0.0, hr = s.avgHr,
                gain = Math.round(s.gain * gainScale).toInt(), loss = Math.round(s.loss * lossScale).toInt(),
                cad = s.avgCad, name = (i + 1).toString(), type = drafts[i].kind, label = SegKind.clean(drafts[i].text),
            )
        }
    }

    private fun r3(x: Double) = Math.round(x * 1000) / 1000.0

    /** Bentuk tersimpan untuk kunci `sg` (sama dengan yang dibaca ActStore.fromMap). */
    fun toMaps(segments: List<Segment>): List<Map<String, Any?>> = segments.map { s ->
        val m = LinkedHashMap<String, Any?>()
        m["k"] = r3(s.k); m["d"] = r3(s.d); m["tm"] = r3(s.min); m["p"] = r3(s.pace)
        s.hr?.let { m["h"] = it }
        m["g"] = s.gain; m["l"] = s.loss
        s.cad?.let { m["c"] = it }
        m["n"] = s.name
        s.type?.let { m["ty"] = it }
        s.label?.let { m["lb"] = it }
        m
    }

    /**
     * Titik awal editor dari segmen yang sudah ada (mis. lap FIT): batas dipetakan lewat jarak kumulatif ke detik.
     * Null bila total jarak segmen tidak cocok dengan deret (selisih > 10%), supaya batas tidak bergeser diam-diam.
     */
    fun draftsFromSegments(ts: ActivityTimeSeries, segments: List<Segment>): List<Draft>? {
        if (segments.isEmpty()) return null
        val totalM = ts.distanceMeters.last() - ts.distanceMeters.first()
        val segM = segments.sumOf { it.d } * 1000.0
        if (totalM <= 0 || kotlin.math.abs(segM - totalM) > totalM * 0.10) return null
        val total = totalSec(ts)
        val out = ArrayList<Draft>()
        var cum = 0.0; var prev = 0
        segments.forEachIndexed { i, s ->
            cum += s.d * 1000.0
            val end = if (i == segments.lastIndex) total else secAtMeters(ts, cum)
            if (end - prev >= MIN_SEG_SEC) { out += Draft(end, SegKind.normalize(s.type), false, SegKind.clean(s.label)); prev = end }
            else if (out.isNotEmpty() && i == segments.lastIndex) out[out.lastIndex] = out.last().copy(endSec = total)
        }
        return out.takeIf { it.isNotEmpty() && it.last().endSec == total }
    }

    /** "m:ss", "h:mm:ss" atau detik polos ke detik; null bila tidak valid. */
    fun parseSeconds(text: String): Int? {
        val t = text.trim()
        if (t.isEmpty()) return null
        if (!t.contains(':')) return t.toIntOrNull()?.takeIf { it >= 0 }
        val parts = t.split(':').map { it.trim().toIntOrNull() ?: return null }
        if (parts.any { it < 0 } || parts.size !in 2..3) return null
        if (parts.drop(1).any { it >= 60 }) return null
        return if (parts.size == 2) parts[0] * 60 + parts[1] else parts[0] * 3600 + parts[1] * 60 + parts[2]
    }

    /** Panjang segmen dalam meter (bilangan bulat atau desimal, titik atau koma); null bila tidak valid atau nol. */
    fun parseMeters(text: String): Double? = text.trim().replace(',', '.').toDoubleOrNull()?.takeIf { it > 0 && it.isFinite() }

    /** Kilometer dengan titik atau koma desimal; null bila tidak valid. */
    fun parseKm(text: String): Double? = text.trim().replace(',', '.').toDoubleOrNull()?.takeIf { it >= 0 && it.isFinite() }

    fun fmtSeconds(sec: Int): String {
        val h = sec / 3600; val m = (sec % 3600) / 60; val s = sec % 60
        return if (h > 0) String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, s) else String.format(java.util.Locale.US, "%d:%02d", m, s)
    }
}
