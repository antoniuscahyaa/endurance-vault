package com.endurancevault.app.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.sp
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.domain.Js
import com.endurancevault.app.domain.Kinds
import com.endurancevault.app.domain.PWeek
import com.endurancevault.app.domain.Phases
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.domain.TrainingMetrics
import com.endurancevault.app.domain.TrainingMetricsResult
import com.endurancevault.app.domain.ZoneCuts
import com.endurancevault.app.domain.Zones
import com.endurancevault.app.ui.UiState
import com.endurancevault.app.ui.theme.Ember
import com.endurancevault.app.ui.theme.Fire
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

// Komponen dock Minggu: kartu rencana, kartu statistik pekan, tombol pil, kartu hari. Tata letak mengikuti dock Week di rencana-lari.

internal val WkMono = FontFamily.Monospace
internal val WkGray = Color(0xFF7B8190)
private val WkOrange: Brush @Composable get() = SolidColor(MaterialTheme.colorScheme.primary)
private val WK_DATE = DateTimeFormatter.ofPattern("d MMM", Locale.ENGLISH)

internal fun wkRange(a: LocalDate, b: LocalDate): String =
    if (a.month == b.month) "${a.dayOfMonth}–${b.dayOfMonth} ${b.month.getDisplayName(TextStyle.SHORT, Locale.ENGLISH)}"
    else "${a.format(WK_DATE)} – ${b.format(WK_DATE)}"

internal fun wkNum(v: Double): String =
    if (abs(v - v.roundToInt()) < 0.05) v.roundToInt().toString() else String.format(Locale.US, "%.1f", v)

internal fun wkPhase(p: String) = when (p) {
    Phases.BASE -> "BASE"; Phases.BUILD -> "BUILD"; Phases.PEAK -> "PEAK"; else -> "TAPER"
}

internal fun wkPhaseColor(p: String) = when (p) {
    Phases.BASE -> WkGray
    Phases.BUILD -> Ember
    Phases.PEAK -> Fire
    else -> Color(0xFFF2B48A)
}

internal fun wkShare(ctx: Context, title: String, text: String) {
    val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
    ctx.startActivity(Intent.createChooser(i, title))
}

// ---------- blok dasar ----------

/** Kartu lunak: permukaan sedikit lebih gelap dari latar, sudut besar, bayangan tipis. */
/** Bentuk kartu dalam satu grup: hanya kartu paling atas yang melengkung di atas, hanya paling bawah yang melengkung di bawah. */
internal fun wkGroupShape(first: Boolean, last: Boolean, r: Dp = 16.dp): Shape =
    RoundedCornerShape(
        topStart = if (first) r else 0.dp, topEnd = if (first) r else 0.dp,
        bottomStart = if (last) r else 0.dp, bottomEnd = if (last) r else 0.dp,
    )

@Composable
internal fun WkCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    shape: Shape = RoundedCornerShape(16.dp),
    content: @Composable ColumnScope.() -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = shape,
        color = cs.surfaceVariant,
        border = BorderStroke(0.8.dp, cs.outlineVariant),
    ) {
        Column(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier, content = content)
    }
}

@Composable
internal fun WkTabs(history: Boolean, onChange: (Boolean) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        listOf(false to "This week", true to "History").forEach { (h, label) ->
            val on = history == h
            Box(
                Modifier.weight(1f).height(36.dp)
                    .clip(CircleShape)
                    .then(if (on) Modifier.background(WkOrange) else Modifier.background(cs.surfaceVariant))
                    .clickable { onChange(h) },
                contentAlignment = Alignment.Center,
            ) {
                Text(label, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = if (on) cs.onPrimary else cs.onSurfaceVariant)
            }
        }
    }
}

@Composable
internal fun WkPill(label: String, icon: ImageVector?, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(modifier, shape = CircleShape, color = cs.surfaceVariant, border = BorderStroke(0.6.dp, cs.outlineVariant)) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically,
        ) {
            if (icon != null) { Icon(icon, null, Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)) }
            Text(label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}

@Composable
internal fun WkSmallPill(label: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(shape = CircleShape, color = cs.surface, border = BorderStroke(0.6.dp, cs.outlineVariant)) {
        Text(label, Modifier.clickable(onClick = onClick).padding(horizontal = 11.dp, vertical = 4.dp), fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
internal fun WkChip(text: String) {
    Box(Modifier.clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surface).padding(horizontal = 10.dp, vertical = 5.dp)) {
        Text(text, fontSize = 11.sp)
    }
}

@Composable
internal fun WkDoneCircle(done: Boolean, locked: Boolean, desc: String, onToggle: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.size(34.dp).clip(CircleShape).clickable(enabled = !locked, onClick = onToggle).semantics { contentDescription = desc },
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier.size(20.dp).clip(CircleShape).background(if (done) Ember else Color.Transparent)
                .border(2.dp, if (done) Ember else cs.outline, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            if (done) Icon(Icons.Filled.Check, null, Modifier.size(12.dp), tint = Color.White)
        }
    }
}

@Composable
private fun WkDashed() {
    val c = MaterialTheme.colorScheme.outline
    Canvas(Modifier.fillMaxWidth().height(1.dp)) {
        drawLine(c, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = 1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f)))
    }
}

// ---------- kartu rencana ----------

private fun focusLabel(f: String) = when (f) { "thr" -> "Threshold"; "vo2" -> "VO2max"; "vol" -> "Volume"; else -> "Mixed" }

internal fun wkPlanTitle(plan: PlanOutcome.Ok, s: PlanSettings): String = when {
    plan.build -> "Performance Build · ${s.pbCycle}:1 · ${focusLabel(s.pbFocus)} focus"
    plan.none -> "No Race"
    else -> s.name.ifBlank { "Training plan" }
}

@Composable
internal fun WkPlanCard(plan: PlanOutcome.Ok, week: PWeek, state: UiState, open: Boolean, onToggle: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val n = plan.weeks.size.coerceAtLeast(1)
    val pct = ((week.i + 1) * 100.0 / n).roundToInt().coerceIn(0, 100)
    val total = plan.weeks.sumOf { it.km }
    val peak = plan.weeks.maxOfOrNull { it.km } ?: 0.0
    val a = plan.weeks.first().start.toString(); val b = plan.weeks.last().end.toString()
    val done = state.activities.filter { it.type.equals("run", true) && it.dateIso >= a && it.dateIso <= b }.sumOf { it.km }
    WkCard(onClick = onToggle) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(wkPlanTitle(plan, state.settings), fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.clip(CircleShape).background(wkPhaseColor(week.phase)).padding(horizontal = 10.dp, vertical = 2.dp)) {
                    Text(wkPhase(week.phase) + if (week.rec) " · REC" else "", fontFamily = WkMono, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1)
                }
                Text("Week ${week.i + 1} of $n · ${wkRange(week.start, week.end)}", fontSize = 13.sp, color = cs.onSurfaceVariant, maxLines = 1)
            }
            AnimatedVisibility(open, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    HorizontalDivider(color = cs.outlineVariant)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        WkKv("Total", "${wkNum(total)} km")
                        WkKv("Peak", "${wkNum(peak)} km/week")
                        WkKv("Done", "${wkNum(done)} km")
                    }
                }
            }
            Box(Modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(cs.outline.copy(alpha = .45f))) {
                Box(Modifier.fillMaxHeight().fillMaxWidth(pct / 100f).clip(CircleShape).background(WkOrange))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("$pct% of plan", fontFamily = WkMono, fontSize = 11.sp, color = cs.onSurfaceVariant)
                Text("Week ${week.i + 1} / $n", fontFamily = WkMono, fontSize = 11.sp, color = cs.onSurfaceVariant)
            }
            if (week.adj80) Text("Minggu ini dikurangi 20% karena minggu sebelumnya banyak terlewat.", fontSize = 12.sp, color = cs.tertiary)
        }
    }
}

@Composable
private fun WkKv(k: String, v: String) {
    Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(k, fontFamily = WkMono, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(v, fontFamily = WkMono, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

// ---------- angka pekan ----------

internal class WeekFigures(
    val targetKm: Double, val actualKm: Double, val lastKm: Double,
    val targetLoad: Int, val actualLoad: Int, val lastLoad: Int,
    val targetGain: Int, val actualGain: Int,
    val zoneSecs: DoubleArray, val zoneBands: List<String>,
    val hasPrev: Boolean,
)

internal fun wkFigures(state: UiState, week: PWeek, weeks: List<PWeek>, m: TrainingMetricsResult): WeekFigures {
    val idx = weeks.indexOf(week)
    val prev = if (idx > 0) weeks[idx - 1] else null
    fun inWeek(a: ActivityEntity, w: PWeek) = a.dateIso >= w.start.toString() && a.dateIso <= w.end.toString()
    fun runs(w: PWeek?): List<ActivityEntity> =
        if (w == null) emptyList() else state.activities.filter { it.type.equals("run", true) && inWeek(it, w) }
    fun load(w: PWeek?): Int =
        if (w == null) 0 else m.days.filter { !it.date.isBefore(w.start) && !it.date.isAfter(w.end) }.sumOf { it.load }.roundToInt()
    val zc: ZoneCuts = Zones.cuts(state.settings)
    val secs = DoubleArray(5)
    state.activities.filter { inWeek(it, week) }.forEach { a ->
        state.hrHistByActivity[a.id]?.let { h -> Zones.secs(h, zc).forEachIndexed { i, v -> secs[i] += v } }
    }
    val cur = runs(week)
    return WeekFigures(
        targetKm = week.km, actualKm = cur.sumOf { it.km }, lastKm = runs(prev).sumOf { it.km },
        targetLoad = TrainingMetrics.plannedWeekLoad(week, state.settings), actualLoad = load(week), lastLoad = load(prev),
        targetGain = week.days.sumOf { it.gain ?: 0 }, actualGain = cur.sumOf { it.gain ?: 0 },
        zoneSecs = secs, zoneBands = zc.bands(), hasPrev = prev != null,
    )
}

/** Target pekan ini dibanding capaian nyata pekan lalu (sama dengan web). */
private fun deltaText(target: Double, last: Double, hasPrev: Boolean): String {
    if (!hasPrev || last <= 0.0) return "No data from last week."
    val pct = ((target / last - 1.0) * 100).roundToInt()
    return when {
        pct == 0 -> "Same as last week"
        pct < 0 -> "Down ${-pct}% from last week"
        else -> "Up $pct% from last week"
    }
}

private fun loadDelta(f: WeekFigures): String {
    val base = deltaText(f.targetLoad.toDouble(), f.lastLoad.toDouble(), f.hasPrev)
    if (!f.hasPrev || f.lastLoad <= 0) return base
    val pct = ((f.targetLoad.toDouble() / f.lastLoad - 1.0) * 100).roundToInt()
    val tag = when { pct <= -15 -> " Easy week."; pct >= 15 -> " Hard week."; else -> " Steady week." }
    return "$base (actual load ${f.lastLoad}).$tag"
}

// ---------- kartu statistik pekan ----------

internal val WK_METRICS = listOf("distance", "load", "elev", "zones")

@Composable
internal fun WkStatsCard(f: WeekFigures, main: String, onSetMain: (String) -> Unit, open: Boolean, onToggle: () -> Unit) {
    val first = if (main in WK_METRICS) main else "distance"
    val order = listOf(first) + WK_METRICS.filter { it != first }
    WkCard {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            order.forEachIndexed { i, k ->
                if (i == 0) WkMetricSection(k, f, isMain = true, open = open, onToggle = onToggle, onSetMain = {})
                else AnimatedVisibility(open, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        WkDashed()
                        WkMetricSection(k, f, isMain = false, open = open, onToggle = onToggle, onSetMain = { onSetMain(k) })
                    }
                }
            }
        }
    }
}

@Composable
private fun WkMetricSection(k: String, f: WeekFigures, isMain: Boolean, open: Boolean, onToggle: () -> Unit, onSetMain: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val title = when (k) {
        "distance" -> "THIS WEEK'S DISTANCE"; "load" -> "THIS WEEK'S TRAINING LOAD"
        "elev" -> "THIS WEEK'S ELEVATION GAIN"; else -> "HR ZONE DISTRIBUTION"
    }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
            Modifier.fillMaxWidth().height(28.dp).then(if (isMain) Modifier.clickable(onClick = onToggle) else Modifier),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(title, fontFamily = WkMono, fontSize = 10.sp, letterSpacing = .8.sp, color = cs.onSurfaceVariant, maxLines = 1, modifier = Modifier.weight(1f))
            if (isMain) Icon(
                if (open) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                contentDescription = if (open) "Collapse" else "Expand", tint = cs.onSurfaceVariant,
            ) else Box(
                Modifier.clip(CircleShape).border(1.dp, cs.outlineVariant, CircleShape).clickable(onClick = onSetMain).padding(horizontal = 10.dp, vertical = 3.dp),
            ) { Text("Set as main", fontSize = 11.sp, fontWeight = FontWeight.Medium, color = cs.primary) }
        }
        when (k) {
            "distance" -> {
                WkBarRow("Target", wkNum(f.targetKm), "km", 1f, hot = true)
                WkBarRow("Actual", wkNum(f.actualKm), "km", frac(f.actualKm, f.targetKm), hot = false)
                WkNote(deltaText(f.targetKm, f.lastKm, f.hasPrev), Ember)
            }
            "load" -> {
                WkBarRow("Target", f.targetLoad.toString(), "", 1f, hot = true)
                WkBarRow("Actual", f.actualLoad.toString(), "", frac(f.actualLoad.toDouble(), f.targetLoad.toDouble()), hot = false)
                WkNote(loadDelta(f), cs.onSurface)
            }
            "elev" -> {
                WkBarRow("Target", f.targetGain.toString(), "m", if (f.targetGain > 0) 1f else 0f, hot = true)
                WkBarRow("Actual", f.actualGain.toString(), "m", if (f.targetGain > 0) frac(f.actualGain.toDouble(), f.targetGain.toDouble()) else if (f.actualGain > 0) 1f else 0f, hot = false)
                WkNote(if (f.targetGain > 0) "${(f.actualGain * 100.0 / f.targetGain).roundToInt()}% of this week's climb target." else "This week's plan has no climb target.", Ember)
            }
            else -> WkZones(f)
        }
    }
}

private fun frac(a: Double, b: Double): Float = if (b > 0) (a / b).toFloat().coerceIn(0f, 1f) else 0f

@Composable
private fun WkBarRow(label: String, value: String, unit: String, frac: Float, hot: Boolean) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.width(52.dp), fontSize = 13.sp)
        Box(Modifier.weight(1f).height(6.dp).clip(CircleShape).background(cs.outline.copy(alpha = .45f))) {
            if (frac > 0f) Box(
                Modifier.fillMaxHeight().fillMaxWidth(frac).clip(CircleShape)
                    .then(if (hot) Modifier.background(WkOrange) else Modifier.background(WkGray)),
            )
        }
        Row(Modifier.width(76.dp), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.Bottom) {
            Text(value, fontFamily = WkMono, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            if (unit.isNotEmpty()) Text(" $unit", fontFamily = WkMono, fontSize = 11.sp, maxLines = 1)
        }
    }
}

@Composable
private fun WkNote(text: String, dot: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(dot))
        Text(text, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun WkZones(f: WeekFigures) {
    val total = f.zoneSecs.sum().coerceAtLeast(1.0)
    f.zoneSecs.forEachIndexed { i, v ->
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(20.dp).clip(RoundedCornerShape(6.dp)).background(DetailZoneColors[i]))
            Text("Z${i + 1}", Modifier.padding(start = 8.dp), fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(" ${f.zoneBands[i]} bpm", Modifier.weight(1f), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            Text(if (v > 0) Js.durStr(v / 60) else "–", fontFamily = WkMono, fontSize = 13.sp, maxLines = 1)
            Text("${(v / total * 100).roundToInt()}%", Modifier.width(40.dp), fontFamily = WkMono, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, textAlign = androidx.compose.ui.text.style.TextAlign.End)
        }
    }
}

// ---------- teks bagikan ----------

internal fun wkWeekShareText(week: PWeek, plan: PlanOutcome.Ok, settings: PlanSettings, f: WeekFigures): String = buildString {
    appendLine("${wkPlanTitle(plan, settings)} · Week ${week.i + 1} of ${plan.weeks.size} · ${wkRange(week.start, week.end)}")
    appendLine("Target ${wkNum(f.targetKm)} km · Actual ${wkNum(f.actualKm)} km")
    week.days.forEach { d ->
        val dow = d.date.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.ENGLISH)
        val what = if (d.kind == Kinds.REST) "Rest" else d.title + if (d.km > 0) " · ${wkNum(d.km)} km" else ""
        appendLine("$dow ${d.date.dayOfMonth}: $what")
        listOfNotNull(d.str, d.ank, d.up).forEach { appendLine("   + ${it.title} · ${it.mins} min") }
    }
}.trim()

internal fun wkLoggedLine(a: ActivityEntity): String {
    val bike = a.type.equals("bike", true)
    val speedOrPace = if (a.km > 0 && a.durationSec > 0) {
        if (bike) " · ${(a.km / (a.durationSec / 3600.0)).roundToInt()} km/h"
        else { val sec = (a.durationSec / a.km).roundToInt(); " · ${sec / 60}:${"%02d".format(sec % 60)}/km" }
    } else ""
    return "Logged · " + (if (bike) "Bike · " else "") + "${wkNum(a.km)} km$speedOrPace" + (a.avgHr?.let { " · HR $it" } ?: "")
}
