package com.endurancevault.app.domain

import com.endurancevault.app.domain.CourseStrategy.Pt
import org.json.JSONArray
import org.json.JSONObject
import org.w3c.dom.Element

/**
 * Berkas GPX rute untuk dikirim ke jam (port rjFromGpx / rjPayload / rjStats / rjName dari 35-rute-ke-jam.js).
 * Murni (tanpa Android), diuji di GpxRouteTest.
 */
object GpxRoute {
    /** Statistik untuk pratinjau. [prof] = (km, elevasi) dijarangkan ke <= 120 titik. */
    class Stats(val km: Double, val up: Int, val down: Int, val min: Double?, val max: Double?, val hasEle: Boolean, val prof: List<DoubleArray>)

    class Preview(
        val fileName: String, val name: String, val pts: List<Pt>, val km: Double, val total: Int, val sent: Int,
        val payload: String, val stats: Stats,
    )

    /** Titik dari teks GPX: trkpt, atau rtept bila tidak ada trkpt. Lintang/bujur tak valid dibuang. */
    fun parsePoints(xml: String): Pair<List<Pt>, String> {
        val f = javax.xml.parsers.DocumentBuilderFactory.newInstance()
        // GPX dari luar tidak dipercaya: matikan DTD/entitas eksternal
        try { f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) } catch (_: Exception) { }
        val doc = f.newDocumentBuilder().parse(xml.byteInputStream())
        var nodes = doc.getElementsByTagName("trkpt")
        if (nodes.length == 0) nodes = doc.getElementsByTagName("rtept")
        val pts = ArrayList<Pt>()
        for (i in 0 until nodes.length) {
            val n = nodes.item(i) as Element
            val la = n.getAttribute("lat").toDoubleOrNull() ?: continue
            val lo = n.getAttribute("lon").toDoubleOrNull() ?: continue
            if (!la.isFinite() || !lo.isFinite()) continue
            val e = n.getElementsByTagName("ele")
            val ele = if (e.length > 0) e.item(0).textContent.trim().toDoubleOrNull()?.takeIf { it.isFinite() } else null
            pts.add(Pt(Js.round(la * 1e5) / 1e5, Js.round(lo * 1e5) / 1e5, ele?.let { Js.round(it * 10) / 10 }))
        }
        // nama: <name> pertama yang bukan milik <wpt>
        var name = ""
        val nn = doc.getElementsByTagName("name")
        for (i in 0 until nn.length) {
            if (nn.item(i).parentNode?.nodeName != "wpt") { name = nn.item(i).textContent.trim().take(60); break }
        }
        return pts to name
    }

    private fun utf8Len(s: String) = s.toByteArray(Charsets.UTF_8).size

    /** Nama rute di jam: dipotong sampai muat 60 byte UTF-8 (batas plugin). */
    fun routeName(name: String): String {
        val s = name.replace(Regex("\\s+"), " ").trim().ifEmpty { "Rute" }
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val cp = s.codePointAt(i); val ch = String(Character.toChars(cp))
            if (utf8Len(sb.toString() + ch) > 60) break
            sb.append(ch); i += Character.charCount(cp)
        }
        return sb.toString().trimEnd().ifEmpty { "Rute" }
    }

    private fun thin(p: List<Pt>, n: Int): List<Pt> {
        if (p.size <= n) return p
        val k = (p.size - 1).toDouble() / (n - 1)
        return List(n) { p[Js.roundI(it * k).coerceIn(0, p.size - 1)] }
    }

    /** Titik app → JSON plugin {name,points:[[lat,lon,ele|null]]}; titik kembar berurutan digabung, dijarangkan <= 1000 titik. Null bila < 2 titik. */
    fun payload(name: String, pts: List<Pt>): Pair<String, Int>? {
        val clean = ArrayList<Pt>()
        for (p in pts) {
            if (!p.lat.isFinite() || !p.lon.isFinite() || kotlin.math.abs(p.lat) > 90 || kotlin.math.abs(p.lon) > 180) continue
            val q = Pt(Js.round(p.lat * 1e6) / 1e6, Js.round(p.lon * 1e6) / 1e6, p.ele?.takeIf { it.isFinite() }?.let { Js.round(it * 10) / 10 })
            val last = clean.lastOrNull()
            if (last != null && last.lat == q.lat && last.lon == q.lon) continue
            clean.add(q)
        }
        if (clean.size < 2) return null
        val th = thin(clean, 1000)
        val arr = JSONArray()
        th.forEach { arr.put(JSONArray().put(it.lat).put(it.lon).put(it.ele ?: JSONObject.NULL)) }
        return JSONObject().put("name", routeName(name)).put("points", arr).toString() to th.size
    }

    /** Jarak, naik/turun kumulatif (ambang 3 m agar derau GPS tidak dihitung), elevasi min/maks, profil. */
    fun stats(pts: List<Pt>): Stats {
        var km = 0.0; var up = 0.0; var down = 0.0
        var mn: Double? = null; var mx: Double? = null; var ref: Double? = null
        val prof = ArrayList<DoubleArray>(); var has = false
        for (i in pts.indices) {
            val p = pts[i]
            if (i > 0) km += ActBuilder.hav(pts[i - 1].lat, pts[i - 1].lon, p.lat, p.lon) / 1000
            val e = p.ele
            if (e != null && e.isFinite()) {
                has = true
                if (mn == null || e < mn) mn = e
                if (mx == null || e > mx) mx = e
                if (ref == null) ref = e
                val d = e - ref
                if (d >= 3) { up += d; ref = e } else if (d <= -3) { down -= d; ref = e }
                prof.add(doubleArrayOf(km, e))
            }
        }
        val th = if (prof.size <= 120) prof else {
            val k = (prof.size - 1).toDouble() / 119
            List(120) { prof[Js.roundI(it * k).coerceIn(0, prof.size - 1)] }
        }
        return Stats(Js.round(km * 100) / 100, Js.roundI(up), Js.roundI(down), mn, mx, has, th)
    }

    /** Teks GPX → pratinjau, atau [Err] dengan pesan. */
    class Err(message: String) : Exception(message)

    fun preview(xml: String, fileName: String): Preview {
        val (pts, gname) = try { parsePoints(xml) } catch (e: Exception) { throw Err("Berkas tidak bisa dibaca sebagai GPX.") }
        if (pts.size < 2) throw Err("Berkas GPX tidak berisi jalur yang bisa dibaca (minimal 2 titik).")
        val name = gname.ifEmpty { fileName.replace(Regex("\\.[^.]+$"), "").ifEmpty { "Rute" } }
        val (json, sent) = payload(name, pts) ?: throw Err("Rute ini tidak punya cukup titik untuk dikirim.")
        val st = stats(pts)
        return Preview(fileName, routeName(name), pts, st.km, pts.size, sent, json, st)
    }


    /** Satu langkah sesi di jam: jarak (m) dan total menit. */
    private class PStep(var distM: Int, var minutes: Double)

    /** Toleransi rentang pace di jam (+/- dari pace ruas). */
    const val PACE_TOL = 0.05

    /** Batas langkah sesi di jam (CourseProtobuf.MAX_ACTIONS = 100). */
    const val MAX_COURSE_STEPS = 100

    /** Ruas lebih pendek dari ini (m) digabung ke tetangganya agar jam tidak berganti langkah tiap beberapa meter. */
    const val MIN_STEP_M = 150

    /**
     * Strategi pace -> JSON sesi lari untuk `pushCourses`: satu langkah "run" per ruas, target jarak, rentang pace (detik/km, yang cepat dulu).
     * Ruas pendek digabung (pace dihitung ulang dari total waktu), maksimum [MAX_COURSE_STEPS] langkah. Null bila tidak ada langkah.
     */
    fun paceCourse(name: String, r: CourseStrategy.Result, id: String): String? {
        val steps = ArrayList<PStep>()
        for (s in r.segs) {
            val m = Js.roundI(s.len * 1000)
            if (m <= 0 || !(s.min > 0)) continue
            steps.add(PStep(m, s.min))
        }
        if (steps.isEmpty()) return null
        fun mergeAt(i: Int) { // gabung langkah i dengan tetangga terpendek
            val j = when {
                i == 0 -> 1
                i == steps.size - 1 -> i - 1
                steps[i - 1].distM <= steps[i + 1].distM -> i - 1
                else -> i + 1
            }
            val a = minOf(i, j); val b = maxOf(i, j)
            steps[a].distM += steps[b].distM; steps[a].minutes += steps[b].minutes
            steps.removeAt(b)
        }
        while (steps.size > 1) {
            val i = steps.indices.minByOrNull { steps[it].distM }!!
            if (steps[i].distM < MIN_STEP_M || steps.size > MAX_COURSE_STEPS) mergeAt(i) else break
        }
        val arr = JSONArray()
        for (st in steps) {
            val pace = st.minutes * 60.0 / (st.distM / 1000.0) // detik per km
            var lo = Js.roundI(pace * (1 - PACE_TOL)).coerceIn(60, 900)
            var hi = Js.roundI(pace * (1 + PACE_TOL)).coerceIn(60, 900)
            if (lo > hi) { val t = lo; lo = hi; hi = t }
            arr.put(
                JSONObject().put("kind", "run").put("target", "distance").put("value", st.distM.coerceIn(1, 100_000))
                    .put("intensity", "pace").put("low", lo).put("high", hi),
            )
        }
        val block = JSONObject().put("repeat", 1).put("steps", arr)
        val course = JSONObject().put("id", id.take(40)).put("name", routeName("Pace " + name).take(60))
            .put("blocks", JSONArray().put(block))
        return JSONObject().put("courses", JSONArray().put(course)).toString()
    }

    /** Input waktu gaya stopwatch: hanya angka, diisi dari kanan (30000 → 3:00:00, 3000 → 30:00). Maks 6 angka. */
    fun timeFmt(raw: String): String {
        val d = raw.filter { it.isDigit() }.trimStart('0').takeLast(6)
        if (d.length <= 2) return d
        val ss = d.takeLast(2); val mm = d.dropLast(2).takeLast(2); val h = d.dropLast(4)
        return if (h.isNotEmpty()) "$h:$mm:$ss" else mm.replace(Regex("^0(?=\\d)"), "") + ":" + ss
    }
}
