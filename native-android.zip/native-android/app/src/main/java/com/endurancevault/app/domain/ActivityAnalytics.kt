package com.endurancevault.app.domain

import com.endurancevault.app.data.ActivityEntity
import java.time.LocalDate

/** Ringkasan performa deskriptif. Tidak mengubah skor beban atau prediksi latihan. */
data class ActivitySummary(
    val runCount: Int,
    val totalKm: Double,
    val totalMinutes: Double,
    val longestKm: Double?,
    val fastestAvgPace: Double?,
    val last28Km: Double,
    val last28Runs: Int,
)

data class HalfSplitComparison(
    val firstPace: Double,
    val secondPace: Double,
    /** positif = paruh kedua lebih lambat, negatif = lebih cepat */
    val changePercent: Double,
)

object ActivityAnalytics {
    fun summarize(activities: List<ActivityEntity>, today: LocalDate = LocalDate.now()): ActivitySummary {
        val runs = activities.filter { it.type != "bike" && it.km > 0 && it.durationSec > 0 }
        val recent = runs.filter {
            val date = runCatching { LocalDate.parse(it.dateIso) }.getOrNull()
            date != null && !date.isAfter(today) && !date.isBefore(today.minusDays(27))
        }
        return ActivitySummary(
            runCount = runs.size,
            totalKm = runs.sumOf { it.km },
            totalMinutes = runs.sumOf { it.durationSec / 60.0 },
            longestKm = runs.maxOfOrNull { it.km },
            fastestAvgPace = runs.map { it.durationSec / 60.0 / it.km }.filter { it > 0 }.minOrNull(),
            last28Km = recent.sumOf { it.km },
            last28Runs = recent.size,
        )
    }

    /** Split harus utuh; split parsial di ujung tidak ikut agar perbandingan adil. */
    fun compareHalves(splits: List<Split>): HalfSplitComparison? {
        val full = splits.filter { !it.partial && it.k > 0 && it.pace > 0 }
        if (full.size < 2) return null
        val totalDistance = full.sumOf { it.k }
        if (totalDistance <= 0) return null
        val halfway = totalDistance / 2.0
        var covered = 0.0
        var firstTime = 0.0
        var secondTime = 0.0
        var firstDistance = 0.0
        var secondDistance = 0.0
        full.forEach { split ->
            var remaining = split.k
            val firstPart = minOf(remaining, (halfway - covered).coerceAtLeast(0.0))
            if (firstPart > 0) {
                firstTime += firstPart * split.pace
                firstDistance += firstPart
                remaining -= firstPart
                covered += firstPart
            }
            if (remaining > 0) {
                secondTime += remaining * split.pace
                secondDistance += remaining
                covered += remaining
            }
        }
        if (firstDistance <= 0 || secondDistance <= 0) return null
        val p1 = firstTime / firstDistance
        val p2 = secondTime / secondDistance
        if (p1 <= 0) return null
        return HalfSplitComparison(p1, p2, (p2 / p1 - 1.0) * 100.0)
    }
}
