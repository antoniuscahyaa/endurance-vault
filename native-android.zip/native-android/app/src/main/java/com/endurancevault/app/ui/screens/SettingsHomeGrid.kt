package com.endurancevault.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Backup
import androidx.compose.material.icons.outlined.Cloud
import androidx.compose.material.icons.outlined.Healing
import androidx.compose.material.icons.outlined.Hiking
import androidx.compose.material.icons.outlined.MonitorHeart
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.TrackChanges
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.endurancevault.app.ui.theme.cardTint
import com.endurancevault.app.ui.theme.onCardTint

/** Kunci "beranda" pengaturan: grid kartu bagian. Selain ini = bagian yang sedang dibuka. */
internal const val SETTINGS_HOME = "Menu"

internal data class SettingsTile(
    val key: String,        // sama dengan kunci profileSection ("Rencana", "Kondisi", dst)
    val icon: ImageVector,
    val summary: String,
)

internal fun settingsIcon(key: String): ImageVector = when (key) {
    "Rencana" -> Icons.Outlined.TrackChanges
    "Kondisi" -> Icons.Outlined.Hiking
    "Nyeri & cedera" -> Icons.Outlined.Healing
    "Layanan" -> Icons.Outlined.Cloud
    "Cadangan" -> Icons.Outlined.Backup
    else -> Icons.Outlined.Palette // Tampilan
}

/** Grid 2 kolom; tiap kartu: ikon bulat, nama bagian, ringkasan nilai saat ini. */
@Composable
internal fun SettingsHomeGrid(tiles: List<SettingsTile>, onOpen: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        tiles.chunked(2).forEach { pair ->
            Row(
                Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                pair.forEach { t ->
                    SettingsTileCard(t, Modifier.weight(1f).fillMaxHeight()) { onOpen(t.key) }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun SettingsTileCard(t: SettingsTile, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier
            .clip(shape)
            .border(BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant), shape)
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(
            Modifier.size(34.dp).clip(CircleShape).background(MaterialTheme.colorScheme.cardTint),
            contentAlignment = Alignment.Center,
        ) {
            Icon(t.icon, contentDescription = null, tint = MaterialTheme.colorScheme.onCardTint, modifier = Modifier.size(20.dp))
        }
        Text(t.key, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Text(
            t.summary,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
