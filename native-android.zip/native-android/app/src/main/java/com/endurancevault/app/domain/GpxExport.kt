package com.endurancevault.app.domain

import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Ekspor aktivitas ke GPX 1.1 untuk diunggah ke Strava.
 *
 * Jalur akurat: aktivitas yang diimpor/disinkron dengan versi ini menyimpan jejak GPS asli per detik beserta jam dinding
 * ([GpsTrack], kunci `gt`). GPX ditulis langsung dari koordinat itu: tikungan kecil tetap ada, jarak dari koordinat
 * hampir sama dengan di aplikasi, dan jeda (elapsed > waktu gerak) terbawa lewat stempel waktu.
 *
 * Jalur cadangan (data lama tanpa `gt`): aplikasi hanya punya rute yang disederhanakan (`rt` + bingkai `ge`) dan deret
 * per detik tanpa koordinat. GPX dibangun ulang dengan memetakan jarak kumulatif ke polyline rute, dan hasilnya diberi
 * peringatan. Impor ulang dari berkas FIT/GPX atau sinkron dari jam untuk mendapatkan jalur akurat.
 */
object GpxExport {
    class Result(
        val xml: String,
        val fileName: String,
        val points: Int,
        val gpxKm: Double,
        val appKm: Double,
        val warnings: List<String>,
        /** True bila ditulis dari jejak GPS asli per detik, false bila dari rute sederhana (data lama). */
        val exact: Boolean = false,
    )

    private val TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'").withZone(ZoneOffset.UTC)

    private fun hav(a: RouteGeo.LatLon, b: RouteGeo.LatLon): Double {
        val r = 6371008.8
        val p1 = Math.toRadians(a.lat); val p2 = Math.toRadians(b.lat)
        val dp = p2 - p1; val dl = Math.toRadians(b.lon - a.lon)
        val q = sin(dp / 2) * sin(dp / 2) + cos(p1) * cos(p2) * sin(dl / 2) * sin(dl / 2)
        return 2 * r * asin(sqrt(q.coerceIn(0.0, 1.0)))
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun f(v: Double, digits: Int) = String.format(Locale.ROOT, "%.${digits}f", v)

    private fun clock(totalSec: Double): String {
        val s = totalSec.roundToInt().coerceAtLeast(0)
        return if (s >= 3600) String.format(Locale.ROOT, "%d:%02d:%02d", s / 3600, s % 3600 / 60, s % 60)
        else String.format(Locale.ROOT, "%d:%02d", s / 60, s % 60)
    }

    fun safeFileName(s: String): String =
        s.trim().replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').take(60).ifEmpty { "aktivitas" }

    private fun startMs(d: ActDetail): Long? = d.startEpochMs
        ?: runCatching {
            LocalDateTime.parse("${d.date}T${d.startTime}:00").atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        }.getOrNull()

    private fun description(d: ActDetail): String = buildString {
        append("EnduranceVault")
        append(" · ").append(f(d.km, 2)).append(" km")
        append(" · moving ").append(clock(d.movingMin * 60))
        if (d.elapsedMin > d.movingMin + 0.5) append(" · elapsed ").append(clock(d.elapsedMin * 60))
        d.hr?.let { append(" · avg HR ").append(it) }
        d.hrMax?.let { append(" · max HR ").append(it) }
        d.cad?.let { append(" · cadence ").append(it).append(if (d.bike) " rpm" else " spm") }
        if (d.gain != null || d.loss != null) append(" · gain ").append(d.gain ?: 0).append(" m / loss ").append(d.loss ?: 0).append(" m")
        d.weather?.let { w ->
            append(" · ").append(f(w.tempC, 0)).append("°C")
            w.humidityPct?.let { append(", RH ").append(it).append("%") }
            w.windKmh?.let { append(", wind ").append(f(it, 0)).append(" km/h") }
        }
    }

    private fun header(sb: StringBuilder, name: String, desc: String, firstMs: Long, bike: Boolean) {
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
        sb.append("<gpx version=\"1.1\" creator=\"EnduranceVault\" ")
        sb.append("xmlns=\"http://www.topografix.com/GPX/1/1\" ")
        sb.append("xmlns:gpxtpx=\"http://www.garmin.com/xmlschemas/TrackPointExtension/v1\" ")
        sb.append("xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" ")
        sb.append("xsi:schemaLocation=\"http://www.topografix.com/GPX/1/1 http://www.topografix.com/GPX/1/1/gpx.xsd ")
        sb.append("http://www.garmin.com/xmlschemas/TrackPointExtension/v1 http://www.garmin.com/xmlschemas/TrackPointExtensionv1.xsd\">\n")
        sb.append(" <metadata>\n  <name>").append(esc(name)).append("</name>\n")
        sb.append("  <desc>").append(esc(desc)).append("</desc>\n")
        sb.append("  <time>").append(TIME.format(Instant.ofEpochMilli(firstMs))).append("</time>\n </metadata>\n")
        sb.append(" <trk>\n  <name>").append(esc(name)).append("</name>\n")
        sb.append("  <desc>").append(esc(desc)).append("</desc>\n")
        sb.append("  <type>").append(if (bike) "cycling" else "running").append("</type>\n")
        sb.append("  <trkseg>\n")
    }

    private fun trkpt(sb: StringBuilder, lat: Double, lon: Double, timeMs: Long, ele: Double?, hr: Int?, cad: Int?) {
        sb.append("   <trkpt lat=\"").append(f(lat, 6)).append("\" lon=\"").append(f(lon, 6)).append("\">")
        if (ele != null && ele.isFinite()) sb.append("<ele>").append(f(ele, 1)).append("</ele>")
        sb.append("<time>").append(TIME.format(Instant.ofEpochMilli(timeMs))).append("</time>")
        if (hr != null || cad != null) {
            sb.append("<extensions><gpxtpx:TrackPointExtension>")
            if (hr != null) sb.append("<gpxtpx:hr>").append(hr).append("</gpxtpx:hr>")
            if (cad != null) sb.append("<gpxtpx:cad>").append(cad).append("</gpxtpx:cad>")
            sb.append("</gpxtpx:TrackPointExtension></extensions>")
        }
        sb.append("</trkpt>\n")
    }

    private fun footer(sb: StringBuilder) { sb.append("  </trkseg>\n </trk>\n</gpx>\n") }

    private fun fileName(d: ActDetail, name: String): String =
        "${d.date}${d.startTime.takeIf { it.isNotBlank() }?.let { "_" + it.replace(":", "") } ?: ""}_${safeFileName(name)}.gpx"

    private fun distanceWarning(d: ActDetail, gpxKm: Double, warnings: MutableList<String>) {
        if (d.km > 0 && abs(gpxKm - d.km) / d.km > 0.02) {
            warnings += "Jarak dari koordinat GPX ${f(gpxKm, 2)} km, di aplikasi ${f(d.km, 2)} km. " +
                "Strava menghitung jarak dari koordinat, jadi angkanya bisa sedikit berbeda."
        }
    }

    /** Null bila aktivitas tidak punya rute GPS atau waktu mulai tidak dapat ditentukan. */
    fun build(d: ActDetail, title: String): Result? {
        val ts = d.timeSeries?.takeIf { it.seconds.size >= 2 && it.distanceMeters.size == it.seconds.size }
        val gt = d.gpsTrack?.takeIf { ts != null && it.size == ts.seconds.size }
        val name = title.ifBlank { d.name }.ifBlank { if (d.bike) "Cycling" else "Running" }
        return if (gt != null && ts != null) buildExact(d, name, ts, gt) else buildApproximate(d, name, ts)
    }

    /** Jalur akurat: koordinat dan jam dinding asli per detik dari [GpsTrack]. */
    private fun buildExact(d: ActDetail, name: String, ts: ActivityTimeSeries, gt: GpsTrack): Result? {
        val t0ms = startMs(d) ?: return null
        val sb = StringBuilder(gt.size * 190 + 2048)
        val warnings = ArrayList<String>()
        header(sb, name, description(d), t0ms + gt.wallSec[0] * 1000L, d.bike)
        var km = 0.0
        for (i in 0 until gt.size) {
            if (i > 0) km += hav(RouteGeo.LatLon(gt.lat[i - 1], gt.lon[i - 1]), RouteGeo.LatLon(gt.lat[i], gt.lon[i]))
            val hr = ts.heartRateBpm.getOrNull(i)?.takeIf { it in 30..250 }
            // Kadens lari tersimpan sebagai langkah/menit (dua kaki). GPX Garmin memakai satu kaki, jadi dibagi dua.
            val cadRaw = ts.cadenceSpm.getOrNull(i)?.takeIf { it > 0 }
            val cad = cadRaw?.let { if (d.bike) it else (it / 2.0).roundToInt() }
            trkpt(sb, gt.lat[i], gt.lon[i], t0ms + gt.wallSec[i] * 1000L, ts.elevationMeters.getOrNull(i), hr, cad)
        }
        footer(sb)
        val gpxKm = km / 1000.0
        distanceWarning(d, gpxKm, warnings)
        return Result(sb.toString(), fileName(d, name), gt.size, gpxKm, d.km, warnings, exact = true)
    }

    /** Jalur cadangan untuk data lama: posisi per detik ditaksir dari rute sederhana (±140 titik). */
    private fun buildApproximate(d: ActDetail, name: String, ts: ActivityTimeSeries?): Result? {
        val frame = d.geo ?: return null
        if (d.route.size < 2) return null
        val poly = RouteGeo.toLatLon(frame, d.route)
        val cum = DoubleArray(poly.size)
        for (i in 1 until poly.size) cum[i] = cum[i - 1] + hav(poly[i - 1], poly[i])
        val total = cum.last()
        if (total <= 0.0) return null
        val t0ms = startMs(d) ?: return null

        val sb = StringBuilder(if (ts != null) ts.seconds.size * 190 + 2048 else 16384)
        val warnings = ArrayList<String>()
        header(sb, name, description(d), t0ms, d.bike)
        var count = 0
        if (ts != null) {
            val dEnd = ts.distanceMeters.last()
            var j = 0
            for (i in ts.seconds.indices) {
                val target = if (dEnd > 0.0) (ts.distanceMeters[i] / dEnd).coerceIn(0.0, 1.0) * total else 0.0
                while (j < poly.size - 2 && cum[j + 1] < target) j++
                val seg = cum[j + 1] - cum[j]
                val fr = if (seg > 0.0) ((target - cum[j]) / seg).coerceIn(0.0, 1.0) else 0.0
                val a = poly[j]; val b = poly[j + 1]
                val hr = ts.heartRateBpm.getOrNull(i)?.takeIf { it in 30..250 }
                val cadRaw = ts.cadenceSpm.getOrNull(i)?.takeIf { it > 0 }
                val cad = cadRaw?.let { if (d.bike) it else (it / 2.0).roundToInt() }
                trkpt(sb, a.lat + (b.lat - a.lat) * fr, a.lon + (b.lon - a.lon) * fr, t0ms + ts.seconds[i] * 1000L, ts.elevationMeters.getOrNull(i), hr, cad)
                count++
            }
        } else {
            warnings += "Data per detik tidak tersedia; GPX hanya berisi titik rute yang disederhanakan tanpa HR dan kadens."
            val totalSec = d.movingMin * 60.0
            for (i in poly.indices) {
                trkpt(sb, poly[i].lat, poly[i].lon, t0ms + (cum[i] / total * totalSec * 1000).toLong(), null, null, null)
                count++
            }
        }
        footer(sb)

        warnings += "Aktivitas ini tersimpan sebelum jejak GPS asli disimpan, jadi posisi per detik ditaksir dari rute yang disederhanakan: " +
            "bentuk rute benar tetapi tikungan kecil hilang. Sinkron ulang dari jam atau impor ulang berkas FIT/GPX untuk GPX akurat."
        val gpxKm = total / 1000.0
        distanceWarning(d, gpxKm, warnings)
        if (d.elapsedMin > d.movingMin + 0.5) {
            warnings += "Waktu jeda tidak ikut: GPX hanya berisi waktu bergerak (${clock(d.movingMin * 60)}), bukan elapsed (${clock(d.elapsedMin * 60)})."
        }
        return Result(sb.toString(), fileName(d, name), count, gpxKm, d.km, warnings, exact = false)
    }
}
