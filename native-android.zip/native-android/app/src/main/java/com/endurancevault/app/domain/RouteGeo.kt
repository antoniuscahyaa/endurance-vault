package com.endurancevault.app.domain

import kotlin.math.PI
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sinh
import kotlin.math.tan

/**
 * Pemulihan koordinat asli dari rute ternormalisasi (`rt`, 0..1000) memakai bingkai `ge` yang disimpan ActBuilder:
 * `ge = [lonMin, latMax, skala, cosLintangRata2]`. Tidak perlu impor ulang berkas lama.
 */
object RouteGeo {
    class Frame(val lonMin: Double, val latMax: Double, val scale: Double, val cosLat: Double) {
        fun lon(x: Double) = lonMin + x / (scale * cosLat)
        fun lat(y: Double) = latMax - y / scale
    }

    data class LatLon(val lat: Double, val lon: Double)

    /** Bingkai dari daftar `ge` JSON; null bila tidak lengkap atau tidak masuk akal. */
    fun frameOf(raw: List<Any?>?): Frame? {
        if (raw == null || raw.size < 4) return null
        val v = (0..3).map { (raw[it] as? Number)?.toDouble() ?: return null }
        if (v.any { !it.isFinite() } || v[2] <= 0.0 || v[3] <= 0.0 || v[3] > 1.0) return null
        if (v[0] !in -180.0..180.0 || v[1] !in -85.0..85.0) return null
        return Frame(v[0], v[1], v[2], v[3])
    }

    fun toLatLon(frame: Frame, route: List<Pair<Int, Int>>): List<LatLon> =
        route.map { (x, y) -> LatLon(frame.lat(y.toDouble()), frame.lon(x.toDouble())) }

    // ---- Web Mercator (ubin 256 px, skema XYZ seperti OpenStreetMap) ----
    const val TILE = 256

    fun worldSize(zoom: Int): Double = TILE * 2.0.pow(zoom)

    /** Piksel dunia pada [zoom] untuk koordinat geografis. */
    fun worldX(lon: Double, zoom: Int): Double = (lon + 180.0) / 360.0 * worldSize(zoom)

    fun worldY(lat: Double, zoom: Int): Double {
        val r = Math.toRadians(lat.coerceIn(-85.05112878, 85.05112878))
        return (1.0 - ln(tan(r) + 1.0 / cos(r)) / PI) / 2.0 * worldSize(zoom)
    }

    fun lonOfWorldX(px: Double, zoom: Int): Double = px / worldSize(zoom) * 360.0 - 180.0

    fun latOfWorldY(py: Double, zoom: Int): Double {
        val n = PI - 2.0 * PI * py / worldSize(zoom)
        return Math.toDegrees(atan(sinh(n)))
    }

    /** Kamera: [zoom] bulat untuk ubin, [scale] 1..2 pembesaran tambahan, pusat dalam piksel dunia pada [zoom]. */
    class Camera(val zoom: Int, val scale: Double, val centerX: Double, val centerY: Double)

    /** Keadaan tampilan: zoom pecahan [zoomF] dan pusat dalam piksel dunia zoom 0 (0..256), agar tak bergantung ubin. */
    class View(val zoomF: Double, val cx0: Double, val cy0: Double)

    const val MAX_ZOOM = 18.99

    /**
     * Tampilan yang memuat seluruh [points] di kanvas [widthPx] x [heightPx] dengan ruang kosong [padFraction] di tiap sisi.
     * Titik tunggal atau rute sangat pendek dibatasi ke zoom 17 agar peta tetap terbaca.
     */
    fun fitView(points: List<LatLon>, widthPx: Double, heightPx: Double, padFraction: Double = 0.10): View? {
        if (points.isEmpty() || widthPx <= 0 || heightPx <= 0) return null
        val xs = points.map { worldX(it.lon, 0) }
        val ys = points.map { worldY(it.lat, 0) }
        val dx0 = xs.max() - xs.min()
        val dy0 = ys.max() - ys.min()
        val availW = widthPx * (1 - 2 * padFraction)
        val availH = heightPx * (1 - 2 * padFraction)
        val fitW = if (dx0 > 1e-9) availW / dx0 else Double.MAX_VALUE
        val fitH = if (dy0 > 1e-9) availH / dy0 else Double.MAX_VALUE
        val ratio = min(fitW, fitH)
        val zFit = if (ratio == Double.MAX_VALUE) 17.0 else (ln(ratio) / ln(2.0)).coerceIn(0.0, 17.99)
        return View(zFit, (xs.max() + xs.min()) / 2, (ys.max() + ys.min()) / 2)
    }

    /** Kamera ubin untuk [v]: zoom bulat ubin, [Camera.scale] 1..2 sisanya. */
    fun cameraOf(v: View): Camera {
        val zoom = floor(v.zoomF).toInt().coerceIn(0, 18)
        val k = 2.0.pow(zoom)
        return Camera(zoom, 2.0.pow(v.zoomF - zoom), v.cx0 * k, v.cy0 * k)
    }

    fun fit(points: List<LatLon>, widthPx: Double, heightPx: Double, padFraction: Double = 0.10): Camera? =
        fitView(points, widthPx, heightPx, padFraction)?.let { cameraOf(it) }

    /**
     * Terapkan gestur cubit/geser: titik peta di bawah jari ([focusX], [focusY]) mengikuti jari yang bergerak ([panX], [panY]),
     * dengan zoom dikalikan [zoomChange] dan dibatasi [minZoom]..[MAX_ZOOM]. Ukuran kanvas [w] x [h] dalam piksel.
     */
    fun transform(v: View, w: Double, h: Double, focusX: Double, focusY: Double, panX: Double, panY: Double, zoomChange: Double, minZoom: Double): View {
        val k0 = 2.0.pow(v.zoomF)
        val z1 = (v.zoomF + ln(zoomChange.coerceIn(0.1, 10.0)) / ln(2.0)).coerceIn(min(minZoom, MAX_ZOOM), MAX_ZOOM)
        val k1 = 2.0.pow(z1)
        val px = v.cx0 + (focusX - w / 2) / k0
        val py = v.cy0 + (focusY - h / 2) / k0
        val nx = px - (focusX + panX - w / 2) / k1
        val ny = py - (focusY + panY - h / 2) / k1
        return View(z1, nx.coerceIn(0.0, TILE.toDouble()), ny.coerceIn(0.0, TILE.toDouble()))
    }

    data class TileId(val z: Int, val x: Int, val y: Int)

    /** Ubin [id] (x sudah dibungkus) yang digambar pada kolom [ux] tanpa pembungkusan, agar posisi layar tetap benar. */
    class Placed(val id: TileId, val ux: Int)

    /** Ubin yang menutup kanvas untuk [cam]; y dibatasi, x dibungkus pada [Placed.id] tetapi [Placed.ux] tidak. */
    fun tilesFor(cam: Camera, widthPx: Double, heightPx: Double): List<Placed> {
        val n = 1 shl cam.zoom
        val halfW = widthPx / 2 / cam.scale
        val halfH = heightPx / 2 / cam.scale
        val x0 = floor((cam.centerX - halfW) / TILE).toInt()
        val x1 = floor((cam.centerX + halfW) / TILE).toInt()
        val y0 = max(0, floor((cam.centerY - halfH) / TILE).toInt())
        val y1 = min(n - 1, floor((cam.centerY + halfH) / TILE).toInt())
        val out = ArrayList<Placed>()
        for (ty in y0..y1) for (tx in x0..x1) out.add(Placed(TileId(cam.zoom, Math.floorMod(tx, n), ty), tx))
        return out
    }
}
