package com.endurancevault.app.domain

import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.data.DailyEntity
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.temporal.ChronoUnit
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt

data class LoadDay(val date: LocalDate, val load: Double, val fitness: Double, val fatigue: Double, val form: Double, val sessionCount: Int)
data class TrainingSessionMetric(
    val activityId: Long, val date: LocalDate, val load: Double, val aerobicEffect: Double,
    val anaerobicEffect: Double?, val recoveryHours: Double, val recoveryRemainingHours: Double,
    val source: String, val watchLoad: Int? = null, val fromWatch: Boolean = false,
)
data class ReadinessPart(val key: String, val label: String, val score: Int?, val detail: String, val weight: Double)
data class ReadinessMetric(val score: Int, val tier: String, val advice: String, val parts: List<ReadinessPart>, val dataDays: Int)
data class PlanAdjustment(
    val plannedTitle: String,
    val plannedKind: String,
    val plannedKm: Double,
    val action: String,
    val suggestedKm: Double,
    val reason: String,
    val readinessScore: Int,
)
data class TrainingMetricsResult(
    val days: List<LoadDay>, val sessions: List<TrainingSessionMetric>, val weeklyLoad: Int,
    val fitness: Int, val fatigue: Int, val form: Int, val ratio: Double, val optimalRange: IntRange,
    val status: String, val statusDetail: String, val readiness: ReadinessMetric?,
    val recoveryRemainingHours: Int, val scale: Double, val lthr: Int, val hrMax: Int,
) { val latest: LoadDay? get() = days.lastOrNull() }

/** Native port dari 15-training-load-te-kebugaran.js. Jika histogram HR belum tersedia,
 * load memakai HR rata-rata; anaerobic TE sengaja tidak ditebak tanpa distribusi HR. */
object TrainingMetrics {
    private const val DEFAULT_SCALE = 2.7
    private val kindFactors = mapOf("easy" to 45.0, "short" to 40.0, "medium" to 58.0, "long" to 55.0, "quality" to 75.0, "sub" to 85.0, "race" to 95.0, "event" to 55.0)

    fun calculate(settings: PlanSettings, activities: List<ActivityEntity>, daily: List<DailyEntity>, plan: PlanOutcome,
                  today: LocalDate = LocalDate.now(), loadScale: Double = DEFAULT_SCALE,
                  hrHistByActivity: Map<Long, Map<Int, Double>> = emptyMap()): TrainingMetricsResult {
        val scale = loadScale.takeIf { it in .5..6.0 } ?: DEFAULT_SCALE
        val valid = activities.filter { it.km > 0 || it.durationSec > 0 }
        val restValues = daily.filter { it.dateIso < today.toString() && it.rhr != null }.sortedBy { it.dateIso }.takeLast(14).mapNotNull { it.rhr }
        val rest: Double = settings.rhr?.takeIf { it >= 30 } ?: restValues.sorted().let { if (it.isEmpty()) 55.0 else it[it.size / 2].toDouble() }
        val lthr = settings.lthr?.takeIf { it >= 100 }?.roundToInt() ?: (thrBand(settings)?.let { (it[0] + it[1]) / 2 } ?: 168)
        val hrMax = max(hrMaxEst(settings, valid.mapNotNull { it.maxHr }.maxOrNull() ?: 0), lthr + 8)
        val safeRest: Double = if (rest > lthr - 25) max(30.0, (lthr - 60).toDouble()) else rest
        val reserve = (lthr - safeRest).toDouble() / (hrMax - safeRest).coerceAtLeast(1.0)
        val reference = reserve * exp(1.92 * reserve)
        val planKinds = mutableMapOf<LocalDate, String>()
        (plan as? PlanOutcome.Ok)?.weeks?.forEach { w -> w.days.forEach { planKinds[it.date] = it.kind } }
        val grouped = valid.mapNotNull { a -> runCatching { LocalDate.parse(a.dateIso.take(10)) to a }.getOrNull() }.groupBy({ it.first }, { it.second })
        val rawLoads = mutableMapOf<LocalDate, Double>()
        val sessionRaw = mutableListOf<Triple<ActivityEntity, Double, Map<Int, Double>?>>()
        grouped.forEach { (date, list) ->
            var sum = 0.0
            list.forEach { a ->
                val minutes = if (a.durationSec > 0) a.durationSec / 60.0 else a.km * Js.parsePaceStr(settings.pace)
                val hist = hrHistByActivity[a.id]?.takeIf { it.values.sum() > 60.0 }
                val raw = if (hist != null) {
                    hist.entries.sumOf { (bpm, seconds) ->
                        val r = ((bpm - safeRest).toDouble() / (hrMax - safeRest).coerceAtLeast(1.0)).let { if (it <= 0) 0.0 else it.coerceAtMost(1.05) }
                        seconds * (r * exp(1.92 * r))
                    } / 3600.0 / reference.coerceAtLeast(.0001) * 100.0
                } else if (a.avgHr != null && a.avgHr > 0) {
                    val r = ((a.avgHr - safeRest).toDouble() / (hrMax - safeRest).coerceAtLeast(1.0)).coerceIn(0.0, 1.05)
                    minutes / 60.0 * (r * exp(1.92 * r)) / reference.coerceAtLeast(.0001) * 100.0
                } else minutes / 60.0 * (kindFactors[planKinds[date]] ?: 50.0) * if (a.type == "bike") .85 else 1.0
                val adjusted = if (a.type == "bike" && (hist != null || a.avgHr != null)) raw / 1.25 else raw
                sum += adjusted; sessionRaw += Triple(a, adjusted, hist)
            }
            rawLoads[date] = sum
        }
        if (rawLoads.isEmpty()) {
            val readiness = readiness(null, daily, today)
            val adjustment = readiness?.let { recommendTodayPlan(plan, today, it.score) }
            return TrainingMetricsResult(emptyList(), emptyList(), 0, 0, 0, 0, 0.0, 0..0,
                "Belum ada data", "Catat atau impor aktivitas untuk mulai menghitung training load.",
                readiness, 0, scale, lthr, hrMax, adjustment)
        }
        val first = rawLoads.keys.minOrNull()!!; val end = maxOf(today, rawLoads.keys.maxOrNull()!!)
        val af = 1.0 - exp(-1.0 / 42.0); val at = 1.0 - exp(-1.0 / 7.0)
        var ctl = 0.0; var atl = 0.0; val days = mutableListOf<LoadDay>(); var date = first
        while (!date.isAfter(end) && days.size < 3000) {
            val load = (rawLoads[date] ?: 0.0) * scale
            ctl += (load - ctl) * af; atl += (load - atl) * at
            days += LoadDay(date, load, ctl, atl, ctl - atl, grouped[date]?.size ?: 0); date = date.plusDays(1)
        }
        val cur = days.firstOrNull { it.date == today } ?: days.last()
        val weekly = days.filter { !it.date.isBefore(today.minusDays(6)) && !it.date.isAfter(today) }.sumOf { it.load }.roundToInt()
        val ratio = if (cur.fitness > 0) cur.fatigue / cur.fitness else 0.0
        val status = when {
            ChronoUnit.DAYS.between(first, today) + 1 < 28 || cur.fitness / scale < 8 -> "Data belum cukup" to "Dibutuhkan sekitar 4 minggu aktivitas tercatat agar status beban lebih stabil."
            ratio < .8 -> "Beban turun" to "Beban 7 hari berada di bawah kebiasaan 6 minggu. Ini dapat mendukung pemulihan."
            ratio <= 1.3 -> "Beban optimal" to "Beban jangka pendek relatif seimbang dengan kebiasaan latihan."
            ratio <= 1.5 -> "Beban tinggi" to "Beban meningkat cepat. Pertahankan sesi easy tetap ringan dan sisipkan pemulihan."
            else -> "Beban sangat tinggi" to "Lonjakan beban cukup besar. Pertimbangkan mengurangi volume dan prioritaskan pemulihan."
        }
        val sessionMetrics = sessionRaw.map { (a, raw, hist) ->
            val d = LocalDate.parse(a.dateIso.take(10)); val dayIndex = days.indexOfFirst { it.date == d }
            val ctlBefore = if (dayIndex > 0) days[dayIndex - 1].fitness / scale else 0.0
            val ff = (1.3 - ctlBefore / 150.0).coerceIn(.7, 1.3)
            val watch = runCatching { org.json.JSONObject(a.note) }.getOrNull()
            val watchRecovery = watch?.optDouble("recoveryHours", 0.0)?.takeIf { it > 0.0 }
            val watchAerobic = watch?.optDouble("aerobicEffect", 0.0)?.takeIf { it in 0.1..5.0 }
            val watchAnaerobic = watch?.optDouble("anaerobicEffect", 0.0)?.takeIf { it in 0.1..5.0 }
            val watchLoad = watch?.optInt("workoutLoad", 0)?.takeIf { it > 0 }
            val watchData = watch?.optString("source") == "huawei-watch"
            val recovery = watchRecovery ?: (24.0 * raw.coerceAtLeast(0.0).div(100.0).pow(.9) * ff)
            val endTime = runCatching { LocalDateTime.of(d, a.startTime?.let { LocalTime.parse(it) } ?: LocalTime.NOON).plusSeconds(a.durationSec.toLong()) }.getOrNull()
            val elapsed = endTime?.let { ChronoUnit.SECONDS.between(it, LocalDateTime.now()).coerceAtLeast(0) / 3600.0 } ?: 0.0
            val ctlP = ctlBefore
            val factor = (1.0 + ctlP / 50.0).coerceIn(1.0, 1.6)
            val te = watchAerobic ?: (5.0 * (1.0 - exp(-raw / (58.0 * factor)))).coerceIn(0.0, 5.0)
            var anaerobic: Double? = null
            if (hist != null) {
                val high = lthr + .35 * (hrMax - lthr)
                val minutesHigh = hist.entries.sumOf { (bpm, seconds) ->
                    when { bpm >= high -> seconds / 60.0; bpm >= lthr -> seconds / 60.0 * .15; else -> 0.0 }
                }
                anaerobic = (5.0 * (1.0 - exp(-minutesHigh / 14.0))).let { (it * 10).roundToInt() / 10.0 }
            }
            val teBonus = te >= 4.0
            val adjustedRecovery = if (watchRecovery != null) recovery else recovery * if (teBonus) 1.25 else 1.0
            val rem = (adjustedRecovery - elapsed).coerceAtLeast(0.0)
            TrainingSessionMetric(
                a.id, d, raw * scale, (te * 10).roundToInt() / 10.0,
                watchAnaerobic ?: anaerobic, adjustedRecovery, rem,
                if (watchData) "Huawei Watch" else if (hist != null) "Histogram HR" else if (a.avgHr != null) "HR rata-rata" else "Estimasi durasi",
                watchLoad, watchData,
            )
        }.sortedByDescending { it.date }
        val recoveryRemaining = sessionMetrics.filter { !it.date.isAfter(today) && ChronoUnit.DAYS.between(it.date, today) <= 5 }
            .map { it.recoveryRemainingHours }.sortedDescending().foldIndexed(0.0) { i, acc, h -> acc + h * if (i == 0) 1.0 else .5 }
            .roundToInt().coerceIn(0, 96)
        val readiness = readiness(cur, daily, today, recoveryRemaining, ratio)
        val adjustment = readiness?.let { recommendTodayPlan(plan, today, it.score) }
        return TrainingMetricsResult(days, sessionMetrics, weekly, cur.fitness.roundToInt(), cur.fatigue.roundToInt(), cur.form.roundToInt(), ratio,
            (cur.fitness * 7 * .8).roundToInt()..(cur.fitness * 7 * 1.3).roundToInt(), status.first, status.second,
            readiness, recoveryRemaining, scale, lthr, hrMax, adjustment)
    }

    private fun recommendTodayPlan(plan: PlanOutcome, today: LocalDate, score: Int): PlanAdjustment? {
        val day = (plan as? PlanOutcome.Ok)?.weeks?.asSequence()?.flatMap { it.days.asSequence() }
            ?.firstOrNull { it.date == today } ?: return null
        if (day.kind == Kinds.REST || day.kind == Kinds.RACE || day.kind == Kinds.EVENT) return null
        val action = when {
            day.kind in setOf(Kinds.QUALITY, Kinds.LONG, Kinds.MEDIUM) && score < 50 -> "swap"
            day.kind in setOf(Kinds.QUALITY, Kinds.LONG, Kinds.MEDIUM) && score < 65 -> "light"
            day.kind in setOf(Kinds.EASY, "short") && score < 35 -> "light"
            else -> return null
        }
        val km = if (action == "swap") min(6.0, max(3.0, day.km * .5)) else day.km * .8
        val reason = when (action) {
            "swap" -> "Readiness di bawah 50. Pertimbangkan mengganti sesi utama dengan lari easy pendek 3–6 km, sepeda ringan, atau istirahat."
            else -> "Readiness belum mencapai ambang sesi penuh. Pertimbangkan mengurangi jarak sekitar 20% dan menjaga intensitas tetap ringan."
        }
        return PlanAdjustment(day.title, day.kind, day.km, action, km, reason, score)
    }

    private data class SleepFactors(
        val effectiveHours: Double,
        val score: Int,
        val awakeCount: Int,
        val awakeMinutes: Int,
        val stageAdjustment: Int,
    )

    private fun rawNumber(raw: String, key: String): Double? = runCatching {
        val obj = com.google.gson.JsonParser.parseString(raw).asJsonObject
        obj.get(key)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asDouble
    }.getOrNull()

    private fun sleepFactors(day: DailyEntity): SleepFactors? {
        val night = day.sleepH?.takeIf { it > 0 } ?: rawNumber(day.raw, "sleep")?.takeIf { it > 0 } ?: return null
        val nap = (rawNumber(day.raw, "nap") ?: 0.0).coerceIn(0.0, 180.0)
        val effective = (night + nap / 60.0).let { (it * 10).roundToInt() / 10.0 }
        val awakeCount = (rawNumber(day.raw, "wkN") ?: 0.0).roundToInt().coerceIn(0, 20)
        var awakeMinutes = 0
        runCatching {
            val root = com.google.gson.JsonParser.parseString(day.raw).asJsonObject
            val ranges = root.getAsJsonArray("wks")
            if (ranges != null) {
                ranges.forEach { e ->
                    val o = e.asJsonObject
                    if (o.get("g")?.asBoolean != true) awakeMinutes += o.get("m")?.asInt ?: 0
                }
            } else {
                val bed = parseClock(root.get("bed")?.asString)
                val wake = parseClock(root.get("wkAt")?.asString)
                val back = parseClock(root.get("reAt")?.asString)
                if (bed != null && wake != null && back != null) {
                    val total = (back - bed + 1440) % 1440
                    val before = (wake - bed + 1440) % 1440
                    awakeMinutes = (total - before).coerceAtLeast(0)
                }
            }
        }
        val deep = rawNumber(day.raw, "deep") ?: 0.0
        val rem = rawNumber(day.raw, "rem") ?: 0.0
        val light = rawNumber(day.raw, "light") ?: 0.0
        val totalStages = deep + rem + light
        val stageAdj = if (totalStages > 0 && deep + rem > 0)
            (((deep + rem) / totalStages - .35) * 50).roundToInt().coerceIn(-8, 8) else 0
        val penalty = min(awakeCount * 6, 30) + min(awakeMinutes / 10, 10)
        val score = (((effective - 4.0) / 3.5 * 100).roundToInt() - penalty + stageAdj).coerceIn(0, 100)
        return SleepFactors(effective, score, awakeCount, awakeMinutes, stageAdj)
    }

    private fun parseClock(value: String?): Int? {
        if (value == null) return null
        val parts = value.split(":")
        if (parts.size != 2) return null
        val h = parts[0].toIntOrNull() ?: return null
        val m = parts[1].toIntOrNull() ?: return null
        return if (h in 0..23 && m in 0..59) h * 60 + m else null
    }

    private fun readiness(current: LoadDay?, daily: List<DailyEntity>, today: LocalDate, recovery: Int = 0, ratio: Double = 0.0): ReadinessMetric? {
        val ordered = daily.sortedBy { it.dateIso }
        val latest = ordered.lastOrNull {
            runCatching { !LocalDate.parse(it.dateIso).isBefore(today.minusDays(1)) }.getOrDefault(false)
        }
        val baseline = ordered.filter { it.dateIso < (latest?.dateIso ?: today.toString()) }.takeLast(14)
        val parts = mutableListOf<ReadinessPart>()
        if (current != null) {
            parts += ReadinessPart("rec", "Recovery", (100 - recovery * 100.0 / 72).roundToInt().coerceIn(0, 100),
                if (recovery < 2) "Pulih" else "Sisa sekitar $recovery jam", 30.0)
            if (current.fitness > 8) parts += ReadinessPart("load", "Beban latihan",
                (100 - max(0.0, ratio - 1) * 140).roundToInt().coerceIn(10, 100), "ATL:CTL %.2f".format(ratio), 20.0)
        }
        val sleep = latest?.let { sleepFactors(it) }
        if (sleep != null) {
            parts += ReadinessPart("sl", "Tidur", sleep.score,
                "%.1f jam efektif".format(sleep.effectiveHours) +
                    (if (sleep.awakeCount > 0) " · ${sleep.awakeCount}× terbangun" else "") +
                    (if (sleep.awakeMinutes > 0) " · ${sleep.awakeMinutes} menit terjaga" else "") +
                    (if (sleep.stageAdjustment != 0) " · fase ${if (sleep.stageAdjustment > 0) "+" else ""}${sleep.stageAdjustment}" else ""),
                20.0)
        }
        val sleepDays = (0..6).mapNotNull { offset ->
            val d = today.minusDays(offset.toLong()).toString()
            ordered.lastOrNull { it.dateIso == d }?.let { sleepFactors(it)?.effectiveHours }
        }
        if (sleepDays.size >= 3) {
            val debt = max(0.0, sleepDays.sumOf { max(7.5 - it, -1.0) })
            val score = (100 - debt * 14).roundToInt().coerceIn(0, 100)
            parts += ReadinessPart("debt", "Utang tidur 7 hari", score,
                "%.1f jam · %d/7 malam".format(debt, sleepDays.size), 15.0)
        }
        latest?.hrv?.takeIf { it > 0 }?.let { v ->
            val b = baseline.mapNotNull { it.hrv }.filter { it > 0 }
            val score = if (b.size >= 3) (100 - max(0.0, 1 - v / b.average()) * 200).roundToInt().coerceIn(0, 100) else null
            parts += ReadinessPart("hrv", "HRV", score,
                "$v ms" + if (score == null) " · butuh ≥3 hari data" else " · baseline %.0f ms".format(b.average()),
                if (score == null) 0.0 else 20.0)
        }
        latest?.rhr?.takeIf { it > 0 }?.let { v ->
            val b = baseline.mapNotNull { it.rhr }.filter { it > 0 }
            val delta = if (b.isNotEmpty()) v - b.average() else 0.0
            val score = if (b.size >= 3) (100 - max(0.0, delta) * 7).roundToInt().coerceIn(0, 100) else null
            parts += ReadinessPart("rhr", "HR istirahat", score,
                "$v bpm" + if (score == null) " · butuh ≥3 hari data" else " · ${if (delta >= 0) "+" else ""}${delta.roundToInt()} bpm",
                if (score == null) 0.0 else 10.0)
        }
        latest?.leg?.takeIf { it in 1..5 }?.let {
            val score = listOf(100, 80, 55, 30, 10)[it - 1]
            parts += ReadinessPart("leg", "Rasa kaki", score, "$it/5", 15.0)
        }
        latest?.mood?.takeIf { it in 1..5 }?.let {
            val score = listOf(100, 80, 55, 30, 10)[it - 1]
            parts += ReadinessPart("mood", "Stres / mood", score, "$it/5", 10.0)
        }
        val usable = parts.filter { it.score != null && it.weight > 0 }
        val totalWeight = usable.sumOf { it.weight }
        if (totalWeight <= 0) return null
        val score = (usable.sumOf { it.score!! * it.weight } / totalWeight).roundToInt().coerceIn(0, 100)
        val tier = when {
            score >= 80 -> "Siap penuh"
            score >= 60 -> "Baik"
            score >= 40 -> "Sedang"
            score >= 20 -> "Rendah"
            else -> "Perlu istirahat"
        }
        val weakest = usable.minByOrNull { it.score!! }
        val advice = when {
            score >= 80 -> "Siap untuk sesi kualitas atau long run."
            score >= 60 -> "Sesi kualitas masih memungkinkan; tetap dengarkan tubuh."
            score >= 40 -> "Pilih lari easy atau sesi yang lebih pendek."
            score >= 20 -> "Sebaiknya easy, sepeda ringan, atau istirahat."
            else -> "Prioritaskan istirahat hari ini."
        } + (if (weakest != null && weakest.score!! < 70 && score < 80) " Faktor terendah: ${weakest.label} (${weakest.detail})." else "")
        return ReadinessMetric(score, tier, advice, parts, baseline.size + if (latest != null) 1 else 0)
    }


}
