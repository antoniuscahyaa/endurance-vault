package com.endurancevault.app.domain

import kotlin.math.max

/**
 * Strength, ankle, dan upper body (padanan strengthFor, ankleFor, upperFor, placeStrength di web:
 * 02-i18n-penyimpanan-perencana.js dan 05-lomba-tema-prediksi.js). Teks Indonesia saja; terjemahan masuk tahap 10.
 */

internal fun ankleFor(phase: String): StrengthBlock {
    var l = listOf(
        "Calf raise lutut tekuk 3×12 per kaki, turun 3 dtk",
        "Eversi dan inversi dengan band 2×15 per kaki",
        "Dorsifleksi dengan band 2×15 per kaki",
        if (phase == Phases.BASE) "Keseimbangan satu kaki di atas bantal 3×30 dtk per kaki"
        else "Keseimbangan satu kaki di atas bantal, mata tertutup 3×30 dtk per kaki",
    )
    if (phase == Phases.BUILD || phase == Phases.PEAK) l = l + "Pogo hop ringan 2×10 per kaki"
    if (phase == Phases.TAPER) l = listOf(l[0], l[1], l[3])
    return StrengthBlock(
        "Strength ankle · stabilitas", 12,
        "Pelan dan terkendali, tanpa nyeri. Lakukan sebelum lari sebagai aktivasi atau sesudahnya.", l,
    )
}

/** @param t "A" (kaki dan kekuatan) atau "B" (panggul dan stabilitas) */
internal fun strengthFor(t: String, phase: String, cut: Boolean): StrengthBlock {
    var n = when (phase) { Phases.BASE -> 3; Phases.BUILD -> 4; Phases.PEAK -> 3; else -> 2 }
    if (cut && phase != Phases.TAPER) n = max(2, n - 1)
    val rp = when (phase) { Phases.BASE -> "10"; Phases.BUILD -> "6–8"; Phases.PEAK -> "5–6"; else -> "8" }
    val a = listOf(
        "Goblet / front squat $n×$rp",
        "Romanian deadlift $n×$rp",
        "Bulgarian split squat $n×${if (phase == Phases.BASE) "8" else rp} per kaki",
        if (phase == Phases.BASE) "Step-up 3×10 per kaki" else "Step-down eksentrik 3×8 per kaki, turun 3 dtk",
        "Calf raise berdiri dan lutut tekuk 3×" + (if (phase == Phases.BASE) "12–15" else "10, turun 3 dtk"),
        "Plank 3×40 dtk",
    )
    val b = listOf(
        "Hip thrust $n×$rp",
        "Single-leg RDL $n×8 per kaki",
        "Lateral band walk 3×12 per sisi",
        "Side plank 3×30 dtk per sisi",
        "Tibialis raise 3×15",
        "Pallof press 3×10 per sisi",
    )
    var l = if (t == "A") a else b
    if (phase == Phases.PEAK) l = l.take(4)
    if (phase == Phases.TAPER) l = listOf(l[0], l[1], l[l.size - 1])
    val mins = when (phase) { Phases.BASE -> 35; Phases.BUILD -> 40; Phases.PEAK -> 30; else -> 20 }
    return StrengthBlock(
        "Strength $t · " + (if (t == "A") "kaki dan kekuatan" else "panggul dan stabilitas"), mins,
        (if (phase == Phases.TAPER) "Ringan, jangan sampai pegal. " else "Beban sisakan 2 repetisi (RPE 7–8). Istirahat 90 dtk antar set. ") +
            "Lakukan setelah lari easy atau beda jam.",
        l,
    )
}

internal fun upperFor(n: Int, phase: String, cut: Boolean): StrengthBlock {
    var sets = when (phase) { Phases.BASE -> 3; Phases.BUILD -> 3; Phases.PEAK -> 3; Phases.TAPER -> 2; else -> 3 }
    if (cut) sets = max(2, sets - 1)
    val a = listOf(
        "Push-up atau dumbbell press $sets×10",
        "Dumbbell row satu sisi $sets×10 per sisi",
        "Pull-up atau lat pulldown $sets×8",
        "Overhead press ringan $sets×10",
        "Face pull atau reverse fly dengan band 3×15",
        "Dead bug 3×10 per sisi",
    )
    val b = listOf(
        "Push-up 2×12", "Band row 2×15", "Farmer carry 3×30 m",
        "Plank dengan sentuh bahu 2×10 per sisi", "Face pull dengan band 2×15", "Side plank 2×30 dtk per sisi",
    )
    if (n == 1) {
        return StrengthBlock(
            "Strength upper 1 · dada, punggung, bahu", 30,
            "Lakukan setelah lari. Sisakan 2 repetisi (RPE 7–8). Melatih postur dan tenaga untuk lengan dan tongkat.", a,
        )
    }
    return StrengthBlock(
        "Strength upper 2 · ringan", 20,
        "Ringan dan jangan sampai pegal. Aman dilakukan sebelum hari kualitas atau long run.", b,
    )
}

/**
 * Menempelkan strength ke hari-hari minggu ini. Dipanggil setelah teks hari final dan sebelum event latihan
 * menggantikan satu hari (urutan sama dengan web).
 */
internal fun placeStrength(days: List<PDay>, phase: String, i: Int, q: Int, cut: Boolean, s: PlanSettings) {
    val legOn = s.sLeg; val ankOn = s.sAnk; val up = s.sUp.ifEmpty { "auto" }; val d6 = s.days == 6
    val easy = days.filter { it.role == "easy" }
    val shortD = days.filter { it.role == "short" }
    val qd = days.firstOrNull { it.role == "quality" && it.q2 == null }
    val md = days.firstOrNull { it.role == "medium" }
    fun nextHard(d: PDay): Boolean {
        val x = days.getOrNull(days.indexOf(d) + 1) ?: return false
        return x.role == "quality" || x.role == "long" || x.kind == Kinds.EVENT
    }
    if (legOn && (phase != Phases.TAPER || i == q)) {
        var ca = easy.filter { !nextHard(it) }
        if (ca.isEmpty()) ca = shortD.filter { !nextHard(it) }
        // minggu 2 sesi quality: tak ada easy yang aman, kaki A menempel di sesi kedua (beda jam)
        val a = ca.lastOrNull() ?: days.firstOrNull { it.q2 != null }
        if (a != null) a.str = strengthFor("A", phase, cut)
        if (phase == Phases.BASE || phase == Phases.BUILD) {
            val b = easy.firstOrNull { it !== a } ?: shortD.firstOrNull { it !== a }
            if (b != null) b.str = strengthFor("B", phase, cut)
        }
    }
    if (ankOn) {
        qd?.ank = ankleFor(phase)
        val sec = shortD.firstOrNull() ?: md
        if (sec != null) sec.ank = ankleFor(phase)
    }
    val n = if (up == "off" || phase == Phases.TAPER) 0
    else if (up == "1") 1
    else if (up == "2") 2
    else if (phase == Phases.PEAK || !d6) 1 else 2
    if (n >= 1 && qd != null) qd.up = upperFor(1, phase, cut)
    if (n >= 2) {
        val t2 = shortD.firstOrNull { it !== qd } ?: easy.firstOrNull { it.up == null }
        if (t2 != null) t2.up = upperFor(2, phase, cut)
    }
}
