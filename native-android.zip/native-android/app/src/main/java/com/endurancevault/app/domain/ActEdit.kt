package com.endurancevault.app.domain

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import org.json.JSONArray
import org.json.JSONObject

/** Penyuntingan aktivitas ala Strava: nama, deskripsi, tipe, tanggal, jam. Murni, tanpa Android. */
object ActEdit {
    /** Angka dari jam yang hanya berlaku untuk sesi utuh; dibuang dari catatan setelah crop. */
    val WATCH_METRIC_KEYS = listOf("recoveryHours", "elevationGain", "elevationLoss", "workoutLoad", "aerobicEffect", "anaerobicEffect", "recoveryHr")

    private fun obj(note: String): JSONObject? = runCatching { JSONObject(note) }.getOrNull()

    fun isWatchNote(note: String): Boolean = obj(note)?.optString("source") == "huawei-watch"

    fun isCropped(note: String): Boolean = obj(note)?.optBoolean("cropped", false) == true

    /** Deskripsi yang tampil ke pengguna: `userNote` pada catatan jam, atau catatan biasa. */
    fun userNote(note: String): String =
        if (isWatchNote(note)) obj(note)?.optString("userNote").orEmpty() else note

    /** Catatan baru dengan deskripsi [text]; catatan jam tetap JSON (metrik jam tidak hilang). */
    fun withUserNote(note: String, text: String): String {
        val trimmed = text.trim()
        if (!isWatchNote(note)) return trimmed
        val o = obj(note) ?: return trimmed
        if (trimmed.isEmpty()) o.remove("userNote") else o.put("userNote", trimmed)
        return o.toString()
    }

    /**
     * Tandai catatan jam sebagai hasil crop: training effect, load, recovery, dan D+/D− resmi jam dibuang karena
     * dihitung jam untuk sesi utuh. Catatan biasa dibiarkan. Sinkron jam berikutnya tidak memasangnya kembali ([isCropped]).
     */
    fun markCropped(note: String): String {
        if (!isWatchNote(note)) return note
        val o = obj(note) ?: return note
        WATCH_METRIC_KEYS.forEach { o.remove(it) }
        o.put("cropped", true)
        return o.toString()
    }

    /** `watchStart` yang tersimpan pada catatan jam, atau 0. */
    fun watchStartOfNote(note: String): Long = obj(note)?.optLong("watchStart", 0L) ?: 0L

    /** Awal workout jam (detik epoch) dari objek detail hasil sinkron jam (kunci `watch`, teks JSON), atau 0. */
    fun watchStartOf(detail: Map<String, Any?>?): Long {
        val json = detail?.get("watch") as? String ?: return 0L
        return runCatching { JSONObject(json).optLong("start", 0L) }.getOrDefault(0L)
    }

    /**
     * Pastikan catatan jam memuat `watchStart`, agar sinkron jam mengenali baris ini walau jarak, tanggal, jam, atau
     * tipenya sudah berubah karena crop atau edit. Catatan biasa dan catatan yang sudah memuatnya dibiarkan.
     */
    fun withWatchStart(note: String, detail: Map<String, Any?>?): String {
        val o = obj(note)
        if (o == null || o.optString("source") != "huawei-watch" || o.optLong("watchStart", 0L) > 0L) return note
        val start = watchStartOf(detail)
        if (start <= 0L) return note
        return o.put("watchStart", start).toString()
    }

    class Fields(val name: String, val note: String, val type: String, val dateIso: String, val startTime: String?)

    /** Galat validasi dalam bahasa Indonesia, atau null bila isian sah. */
    fun validate(dateIso: String, startTime: String, type: String): String? {
        if (type != "run" && type != "bike") return "Tipe harus lari atau sepeda"
        if (runCatching { LocalDate.parse(dateIso) }.isFailure) return "Tanggal harus berformat yyyy-MM-dd"
        if (startTime.isNotBlank() && !startTime.matches(Regex("\\d{2}:\\d{2}")) ) return "Jam harus berformat HH:mm"
        if (startTime.isNotBlank() && runCatching { LocalTime.parse(startTime) }.isFailure) return "Jam tidak valid"
        return null
    }

    /**
     * Terapkan suntingan ke objek detail (berkas). Kunci `bike` hanya diubah untuk lari/sepeda biasa (bukan hiking/renang).
     * Bila tanggal atau jam berubah, `t0` (epoch ms) dihitung ulang agar tetap sejalan dengan `date` dan `st`.
     */
    fun applyToDetail(act: Map<String, Any?>, f: Fields, zone: ZoneId = ZoneId.systemDefault()): Map<String, Any?> {
        val out = LinkedHashMap<String, Any?>(act)
        out["nm"] = f.name.take(60)
        if (act["xk"] == null) out["bike"] = f.type == "bike"
        val oldDate = act["date"] as? String
        val oldTime = act["st"] as? String
        val newTime = f.startTime ?: oldTime
        if (oldDate != f.dateIso || oldTime != newTime) {
            out["date"] = f.dateIso
            if (newTime != null) out["st"] = newTime
            val t = newTime?.let { runCatching { LocalTime.parse(it) }.getOrNull() }
            if (t != null && act["t0"] != null) {
                out["t0"] = LocalDateTime.of(LocalDate.parse(f.dateIso), t).atZone(zone).toInstant().toEpochMilli()
            }
        }
        return out
    }
}

/**
 * Daftar "sudah dihapus" supaya sinkron jam tidak memunculkan lagi aktivitas yang dihapus pengguna.
 * Disimpan sebagai kv `deleted` (JSON array teks), ikut cadangan lengkap.
 */
object ActTombstones {
    const val KV_KEY = "deleted"

    fun slot(dateIso: String, startTime: String?, type: String) = "slot:$dateIso ${startTime.orEmpty()} $type"

    /**
     * Kunci yang perlu dicatat saat aktivitas dihapus. Hanya aktivitas yang berasal dari jam yang dicatat; aktivitas manual
     * atau impor berkas tidak diblokir, supaya workout jam di slot yang sama tetap bisa masuk.
     */
    fun keysFor(srcKey: String, type: String, dateIso: String, startTime: String?, note: String, detail: Map<String, Any?>?): Set<String> {
        val keys = LinkedHashSet<String>()
        var fromWatch = ActEdit.isWatchNote(note)
        if (srcKey.startsWith("watch:")) { keys += srcKey; fromWatch = true }
        for (start in listOf(ActEdit.watchStartOf(detail), ActEdit.watchStartOfNote(note))) {
            if (start > 0) { keys += "watch:$start"; fromWatch = true }
        }
        if (fromWatch && !startTime.isNullOrBlank()) keys += slot(dateIso, startTime, type)
        return keys
    }

    fun parse(json: String?): Set<String> {
        if (json.isNullOrBlank()) return emptySet()
        return runCatching {
            val arr = JSONArray(json)
            (0 until arr.length()).mapNotNull { arr.optString(it).takeIf { s -> s.isNotBlank() } }.toSet()
        }.getOrDefault(emptySet())
    }

    fun toJson(keys: Set<String>): String = JSONArray(keys.toList()).toString()

    /** Apakah workout jam ini (kunci `watch:<start>` atau slot tanggal/jam/tipe) sudah pernah dihapus pengguna. */
    fun blocked(tombstones: Set<String>, watchKey: String, dateIso: String, startTime: String, type: String): Boolean =
        tombstones.isNotEmpty() && (watchKey in tombstones || slot(dateIso, startTime, type) in tombstones)
}
