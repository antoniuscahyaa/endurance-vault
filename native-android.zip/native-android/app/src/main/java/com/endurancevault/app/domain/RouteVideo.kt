package com.endurancevault.app.domain

import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Video rute 3D (peta satelit + medan sesuai elevasi) dengan panel data yang bisa diatur posisi dan ukurannya.
 * File ini murni Kotlin (tanpa Android) supaya bisa dites JUnit biasa. Penggambaran ada di `ui/video/`.
 */

/** Satu panel di atas video. [x], [y] = pojok kiri atas dalam persen bingkai (0..100); [size] = skala persen (40..250). */
data class VideoPanel(val key: String, val x: Double, val y: Double, val size: Int)

object RouteVideoKeys {
    val STAT = listOf("jarak", "waktu", "pace", "hr", "grad", "elev", "gain", "cad")
    val ALL = listOf("judul") + STAT + listOf("profil")
    val DEFAULT_ON = listOf("judul", "profil", "jarak", "waktu", "pace", "hr")
    const val MIN_SIZE = 40
    const val MAX_SIZE = 250

    fun name(k: String): String = when (k) {
        "judul" -> "Judul"; "jarak" -> "Jarak"; "waktu" -> "Waktu"; "pace" -> "Pace / kecepatan"
        "hr" -> "Detak jantung"; "grad" -> "Gradien"; "elev" -> "Elevasi"; "gain" -> "Total naik"
        "cad" -> "Cadence"; "profil" -> "Grafik elevasi"; else -> k
    }

    fun defaultPanel(k: String): VideoPanel = when (k) {
        "judul" -> VideoPanel(k, 6.0, 4.5, 100)
        "profil" -> VideoPanel(k, 6.0, 55.0, 100)
        "jarak" -> VideoPanel(k, 6.0, 69.0, 100)
        "waktu" -> VideoPanel(k, 52.0, 69.0, 100)
        "pace" -> VideoPanel(k, 6.0, 77.5, 100)
        "hr" -> VideoPanel(k, 52.0, 77.5, 100)
        "grad" -> VideoPanel(k, 6.0, 86.0, 100)
        "elev" -> VideoPanel(k, 52.0, 86.0, 100)
        "gain" -> VideoPanel(k, 6.0, 33.0, 100)
        "cad" -> VideoPanel(k, 52.0, 33.0, 100)
        else -> VideoPanel(k, 6.0, 50.0, 100)
    }

    fun defaultLayout(): List<VideoPanel> = DEFAULT_ON.map { defaultPanel(it) }
}

/** Pengaturan video rute 3D. Nilai tak valid dibersihkan oleh [sanitized]. */
data class RouteVideoPrefs(
    val panels: List<VideoPanel> = RouteVideoKeys.defaultLayout(),
    /** true = angka berjalan mengikuti posisi pelari; false = ringkasan total. */
    val live: Boolean = true,
    val durationSec: Int = 15,
    /** Sudut kamera dari bidang datar, derajat (20..80). */
    val tilt: Int = 52,
    /** Pengali tinggi medan (1..4). */
    val exaggeration: Double = 1.5,
    /** Total putaran kamera sepanjang video, derajat (0..180). */
    val orbit: Int = 50,
    /** w = putih, k = hitam, l = lime. */
    val ink: String = "w",
    val lineColor: String = "#C6F432",
    /** off, soft, strong. */
    val panelBg: String = "off",
) {
    fun sanitized(): RouteVideoPrefs = copy(
        panels = panels.filter { it.key in RouteVideoKeys.ALL }.distinctBy { it.key }.map {
            VideoPanel(it.key, it.x.coerceIn(0.0, 100.0), it.y.coerceIn(0.0, 100.0), it.size.coerceIn(RouteVideoKeys.MIN_SIZE, RouteVideoKeys.MAX_SIZE))
        },
        durationSec = durationSec.coerceIn(6, 40),
        tilt = tilt.coerceIn(20, 80),
        exaggeration = if (exaggeration.isFinite()) exaggeration.coerceIn(1.0, 4.0) else 1.5,
        orbit = orbit.coerceIn(0, 180),
        ink = if (ink in setOf("w", "k", "l")) ink else "w",
        lineColor = if (HEX.matches(lineColor)) lineColor else "#C6F432",
        panelBg = if (panelBg == "soft" || panelBg == "strong") panelBg else "off",
    )

    fun toJson(): String {
        val o = JsonObject()
        o.add("panels", JsonArray().also { a ->
            panels.forEach { p ->
                a.add(JsonObject().apply { addProperty("k", p.key); addProperty("x", p.x); addProperty("y", p.y); addProperty("s", p.size) })
            }
        })
        o.addProperty("live", live); o.addProperty("dur", durationSec); o.addProperty("tilt", tilt)
        o.addProperty("ex", exaggeration); o.addProperty("orbit", orbit); o.addProperty("ink", ink)
        o.addProperty("lc", lineColor); o.addProperty("bg", panelBg)
        return o.toString()
    }

    companion object {
        private val HEX = Regex("#[0-9a-fA-F]{6}")

        /** Membaca JSON hasil [toJson]; JSON rusak atau kosong menghasilkan pengaturan bawaan. */
        fun fromJson(json: String?): RouteVideoPrefs {
            val d = RouteVideoPrefs()
            val o = runCatching { JsonParser.parseString(json ?: "").asJsonObject }.getOrNull() ?: return d
            fun num(k: String): Double? = o.get(k)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asDouble
            fun str(k: String, def: String) = o.get(k)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isString }?.asString ?: def
            val panels = o.get("panels")?.takeIf { it.isJsonArray }?.asJsonArray?.mapNotNull { e ->
                val p = e.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null
                val k = p.get("k")?.takeIf { it.isJsonPrimitive }?.asString ?: return@mapNotNull null
                val x = p.get("x")?.takeIf { it.isJsonPrimitive }?.asDouble ?: return@mapNotNull null
                val y = p.get("y")?.takeIf { it.isJsonPrimitive }?.asDouble ?: return@mapNotNull null
                val s = p.get("s")?.takeIf { it.isJsonPrimitive }?.asInt ?: 100
                VideoPanel(k, x, y, s)
            }
            return RouteVideoPrefs(
                panels = panels ?: d.panels,
                live = o.get("live")?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isBoolean }?.asBoolean ?: d.live,
                durationSec = num("dur")?.toInt() ?: d.durationSec,
                tilt = num("tilt")?.toInt() ?: d.tilt,
                exaggeration = num("ex") ?: d.exaggeration,
                orbit = num("orbit")?.toInt() ?: d.orbit,
                ink = str("ink", d.ink), lineColor = str("lc", d.lineColor), panelBg = str("bg", d.panelBg),
            ).sanitized()
        }
    }
}

/** Data satu frame. [pace] menit/km (null = berhenti/tak ada data), [grade] persen. */
class FrameStats(
    val idx: Int, val frac: Double, val distM: Double, val sec: Int,
    val pace: Double?, val hr: Int?, val grade: Double?, val ele: Double?, val gain: Double, val cad: Int?,
)

/**
 * Jejak aktivitas per sampel (1 Hz): posisi, jarak, waktu gerak, HR, cadence, elevasi, dan gradien.
 * Elevasi dihaluskan; gradien dan total naik diturunkan darinya bila tidak tersedia.
 * [gradeRaw] dan [ele] berisi NaN untuk nilai yang tidak diketahui.
 */
class RouteVideoTrack(
    val lat: DoubleArray, val lon: DoubleArray, val dist: DoubleArray, val sec: IntArray,
    val hr: IntArray, val cad: IntArray, ele: DoubleArray, gradeRaw: DoubleArray,
    val title: String, val dateText: String, val bike: Boolean = false, officialGain: Int? = null,
) {
    val n: Int = dist.size
    val totalM: Double = dist.last()
    val totalSec: Int = sec.last()
    val eleS: DoubleArray = smooth(fillForward(ele), 7)
    val hasEle: Boolean = eleS.any { it.isFinite() }
    val gradeS: DoubleArray
    val gainCum: DoubleArray

    init {
        require(n >= 2 && lat.size == n && lon.size == n && sec.size == n && hr.size == n && cad.size == n && ele.size == n && gradeRaw.size == n)
        val finite = gradeRaw.count { it.isFinite() }
        gradeS = if (finite * 2 >= n) smooth(gradeRaw, 10).map { if (it.isFinite()) it.coerceIn(-45.0, 45.0) else it }.toDoubleArray()
        else computeGrade()
        val cum = DoubleArray(n)
        for (i in 1 until n) {
            val a = eleS[i - 1]; val b = eleS[i]
            cum[i] = cum[i - 1] + if (a.isFinite() && b.isFinite() && b > a) b - a else 0.0
        }
        // Total naik mengikuti angka resmi aktivitas bila ada, supaya sama dengan yang tampil di aplikasi.
        val k = if (officialGain != null && officialGain > 0 && cum.last() > 0.5) officialGain / cum.last() else 1.0
        gainCum = DoubleArray(n) { cum[it] * k }
    }

    private fun computeGrade(): DoubleArray {
        val g = DoubleArray(n) { Double.NaN }
        if (!hasEle) return g
        var k = 0; var j = 0
        for (i in 0 until n) {
            while (k < i && dist[k] < dist[i] - 20.0) k++
            if (j < i) j = i
            while (j < n - 1 && dist[j + 1] <= dist[i] + 20.0) j++
            val dd = dist[j] - dist[k]
            if (dd >= 10.0) g[i] = ((eleS[j] - eleS[k]) / dd * 100.0).coerceIn(-45.0, 45.0)
        }
        return g
    }

    /** Indeks pertama dengan jarak >= [m] (dibatasi ke indeks terakhir). */
    fun indexAtDist(m: Double): Int {
        var lo = 0; var hi = n - 1
        while (lo < hi) { val mid = (lo + hi) ushr 1; if (dist[mid] >= m) hi = mid else lo = mid + 1 }
        return lo
    }

    /** Elevasi tersampel merata sepanjang jarak, untuk grafik profil. NaN bila tidak ada data elevasi. */
    fun profileSamples(count: Int): DoubleArray {
        if (!hasEle) return DoubleArray(count) { Double.NaN }
        return DoubleArray(count) { eleS[indexAtDist(totalM * it / (count - 1).coerceAtLeast(1))] }
    }

    fun statsAt(r: Double, live: Boolean): FrameStats {
        if (!live) {
            val hrs = hr.filter { it >= 30 }; val cads = cad.filter { it > 0 }
            val avgPace = if (totalM > 0 && totalSec > 0) totalSec / 60.0 / (totalM / 1000.0) else null
            return FrameStats(
                n - 1, 1.0, totalM, totalSec, avgPace,
                if (hrs.isEmpty()) null else hrs.average().roundToInt(),
                gradeS.filter { it.isFinite() }.maxOrNull(),
                eleS.filter { it.isFinite() }.maxOrNull(), gainCum.last(),
                if (cads.isEmpty()) null else cads.average().roundToInt(),
            )
        }
        val frac = r.coerceIn(0.0, 1.0)
        val i = indexAtDist(frac * totalM)
        val k = max(0, i - 10); val j = min(n - 1, i + 10)
        val dd = dist[j] - dist[k]; val dt = (sec[j] - sec[k]).toDouble()
        val pace = if (dd >= 8.0 && dt > 0) (dt / 60.0 / (dd / 1000.0)).takeIf { it in 1.0..25.0 } else null
        fun avgPos(a: IntArray, thr: Int): Int? {
            var s = 0; var c = 0
            for (q in max(0, i - 2)..min(n - 1, i + 2)) if (a[q] >= thr) { s += a[q]; c++ }
            return if (c == 0) null else (s.toDouble() / c).roundToInt()
        }
        return FrameStats(
            i, frac, dist[i], sec[i], pace, avgPos(hr, 30),
            gradeS[i].takeIf { it.isFinite() }, eleS[i].takeIf { it.isFinite() }, gainCum[i], avgPos(cad, 1),
        )
    }

    companion object {
        /** Isi NaN dengan nilai valid sebelumnya (dan nilai valid pertama untuk awal deret). */
        internal fun fillForward(a: DoubleArray): DoubleArray {
            val out = a.copyOf()
            val first = out.indexOfFirst { it.isFinite() }
            if (first < 0) return out
            for (i in 0 until first) out[i] = out[first]
            for (i in first + 1 until out.size) if (!out[i].isFinite()) out[i] = out[i - 1]
            return out
        }

        /** Rata-rata bergerak ±[half] sampel yang mengabaikan NaN. */
        internal fun smooth(a: DoubleArray, half: Int): DoubleArray {
            val n = a.size
            val pre = DoubleArray(n + 1); val cnt = IntArray(n + 1)
            for (i in 0 until n) {
                val ok = a[i].isFinite()
                pre[i + 1] = pre[i] + if (ok) a[i] else 0.0
                cnt[i + 1] = cnt[i] + if (ok) 1 else 0
            }
            return DoubleArray(n) { i ->
                val lo = max(0, i - half); val hi = min(n - 1, i + half)
                val c = cnt[hi + 1] - cnt[lo]
                if (c == 0) Double.NaN else (pre[hi + 1] - pre[lo]) / c
            }
        }

        private fun haversine(a: RouteGeo.LatLon, b: RouteGeo.LatLon): Double {
            val r = 6_371_000.0
            val p1 = Math.toRadians(a.lat); val p2 = Math.toRadians(b.lat)
            val dp = p2 - p1; val dl = Math.toRadians(b.lon - a.lon)
            val h = sin(dp / 2) * sin(dp / 2) + cos(p1) * cos(p2) * sin(dl / 2) * sin(dl / 2)
            return 2 * r * atan2(sqrt(h), sqrt(1 - h))
        }

        /**
         * Bangun dari detail aktivitas. Null bila tidak ada deret per detik atau rute GPS.
         * Jejak GPS per detik dipakai bila ada; aktivitas lama jatuh ke rute sederhana (±140 titik) yang diinterpolasi menurut jarak.
         */
        fun from(d: ActDetail, title: String, dateText: String): RouteVideoTrack? {
            val ts = d.timeSeries?.takeIf { it.seconds.size >= 20 && it.distanceMeters.size == it.seconds.size } ?: return null
            val n = ts.seconds.size
            val dist = DoubleArray(n)
            for (i in 0 until n) dist[i] = max(if (i == 0) 0.0 else dist[i - 1], ts.distanceMeters[i].takeIf { it.isFinite() } ?: 0.0)
            if (dist.last() < 100.0) return null
            val lat = DoubleArray(n); val lon = DoubleArray(n)
            val gt = d.gpsTrack?.takeIf { it.size == n }
            if (gt != null) {
                for (i in 0 until n) { lat[i] = gt.lat[i]; lon[i] = gt.lon[i] }
            } else {
                val frame = d.geo ?: return null
                if (!d.hasRoute) return null
                val pts = RouteGeo.toLatLon(frame, d.route)
                val cum = DoubleArray(pts.size)
                for (i in 1 until pts.size) cum[i] = cum[i - 1] + haversine(pts[i - 1], pts[i])
                val total = cum.last()
                if (total <= 0.0) return null
                var k = 0
                for (i in 0 until n) {
                    val target = dist[i] / dist.last() * total
                    while (k < pts.size - 2 && cum[k + 1] < target) k++
                    val seg = cum[k + 1] - cum[k]
                    val f = if (seg > 0) ((target - cum[k]) / seg).coerceIn(0.0, 1.0) else 0.0
                    lat[i] = pts[k].lat + (pts[k + 1].lat - pts[k].lat) * f
                    lon[i] = pts[k].lon + (pts[k + 1].lon - pts[k].lon) * f
                }
            }
            val ele = DoubleArray(n) { ts.elevationMeters.getOrNull(it) ?: Double.NaN }
            if (ele.none { it.isFinite() } && d.profile.size >= 2) {
                // Tanpa elevasi per detik: interpolasi dari profil (km, m) menurut jarak.
                var k = 0
                for (i in 0 until n) {
                    val km = dist[i] / 1000.0
                    while (k < d.profile.size - 2 && d.profile[k + 1].first < km) k++
                    val a = d.profile[k]; val b = d.profile[k + 1]
                    val f = if (b.first > a.first) ((km - a.first) / (b.first - a.first)).coerceIn(0.0, 1.0) else 0.0
                    ele[i] = a.second + (b.second - a.second) * f
                }
            }
            val sec = IntArray(n) { ts.seconds[it] }
            for (i in 1 until n) if (sec[i] < sec[i - 1]) sec[i] = sec[i - 1]
            return RouteVideoTrack(
                lat, lon, dist, sec,
                IntArray(n) { ts.heartRateBpm.getOrElse(it) { 0 } },
                IntArray(n) { ts.cadenceSpm.getOrElse(it) { 0 } },
                ele, DoubleArray(n) { ts.grade.getOrNull(it) ?: Double.NaN },
                title, dateText, d.bike, d.gain,
            )
        }
    }
}

/** Teks panel: label, nilai, satuan (bahasa Indonesia, koma desimal). */
object RouteVideoText {
    class Cell(val label: String, val value: String, val unit: String)

    private fun f(x: Double, dp: Int): String = String.format(Locale.US, "%.${dp}f", x).replace('.', ',')

    fun cell(key: String, st: FrameStats, live: Boolean, bike: Boolean): Cell? = when (key) {
        "jarak" -> Cell("JARAK", f(st.distM / 1000.0, 2), "km")
        "waktu" -> Cell("WAKTU", Js.durStr(st.sec / 60.0), "")
        "pace" ->
            if (bike) Cell(if (live) "KECEPATAN" else "KECEPATAN RATA2", st.pace?.let { f(60.0 / it, 1) } ?: "–", "km/j")
            else Cell(if (live) "PACE" else "PACE RATA2", st.pace?.let { Js.paceStr(it) } ?: "–", "/km")
        "hr" -> Cell(if (live) "DETAK JANTUNG" else "HR RATA2", st.hr?.toString() ?: "–", "bpm")
        "grad" -> Cell(
            if (live) "GRADIEN" else "GRADIEN MAKS",
            st.grade?.let { String.format(Locale.US, "%+.1f", it).replace('.', ',') } ?: "–", "%",
        )
        "elev" -> Cell(if (live) "ELEVASI" else "ELEVASI MAKS", st.ele?.let { it.roundToInt().toString() } ?: "–", "m")
        "gain" -> Cell("TOTAL NAIK", st.gain.roundToInt().toString(), "m")
        "cad" -> Cell(if (live) "CADENCE" else "CADENCE RATA2", st.cad?.toString() ?: "–", "spm")
        else -> null
    }

    private val MONTHS = listOf("Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des")

    /** "2026-11-10" menjadi "10 Nov 2026"; teks lain dikembalikan apa adanya. */
    fun dateId(iso: String): String {
        val p = iso.take(10).split("-")
        if (p.size != 3) return iso
        val y = p[0].toIntOrNull(); val m = p[1].toIntOrNull(); val d = p[2].toIntOrNull()
        if (y == null || m == null || d == null || m !in 1..12) return iso
        return "$d ${MONTHS[m - 1]} $y"
    }
}

/** Pose kamera pada posisi video [p] (0..1). Murni fungsi supaya pratinjau dan hasil render identik. */
class CameraPose(val azimuthDeg: Double, val pitchDeg: Double, val distMul: Double, val follow: Double, val routeFrac: Double)

object RouteVideoCamera {
    /** Bagian awal (pengantar) dan akhir (kamera menjauh) video; di antaranya pelari menempuh rute. */
    const val T_IN = 0.07
    const val T_OUT = 0.90

    private fun smooth(x: Double): Double { val t = x.coerceIn(0.0, 1.0); return t * t * (3 - 2 * t) }

    fun at(p: Double, prefs: RouteVideoPrefs): CameraPose {
        val q = p.coerceIn(0.0, 1.0)
        val r = ((q - T_IN) / (T_OUT - T_IN)).coerceIn(0.0, 1.0)
        val intro = 1.0 - smooth(q / 0.14)
        val outro = smooth((q - 0.88) / 0.12)
        val follow = 0.6 * smooth(q / 0.2) * (1.0 - outro)
        return CameraPose(
            azimuthDeg = prefs.orbit * (q - 0.3),
            pitchDeg = (prefs.tilt + 22.0 * intro - 6.0 * outro).coerceIn(15.0, 85.0),
            distMul = 1.0 + 0.5 * intro + 0.4 * outro,
            follow = follow,
            routeFrac = r,
        )
    }
}
