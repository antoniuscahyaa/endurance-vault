package com.endurancevault.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material.icons.filled.Watch
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import com.endurancevault.app.ui.i18n.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.data.MapStyle
import com.endurancevault.app.data.label
import com.endurancevault.app.data.next
import com.endurancevault.app.domain.ActDetail
import com.endurancevault.app.domain.ExSession
import com.endurancevault.app.domain.ExploreGrade
import com.endurancevault.app.ui.ExMatch
import com.endurancevault.app.domain.CourseStrategy.Pt
import com.endurancevault.app.domain.ExPlace
import com.endurancevault.app.domain.ExRoute
import com.endurancevault.app.domain.ExploreGeo
import com.endurancevault.app.domain.ExploreHike
import com.endurancevault.app.data.ExploreSun
import com.endurancevault.app.data.ExploreWeather
import com.endurancevault.app.domain.Js
import com.endurancevault.app.domain.RouteGeo
import com.endurancevault.app.ui.ExploreController
import com.endurancevault.app.ui.theme.Ember
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private val ExDateFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("d MMM yyyy", com.endurancevault.app.ui.i18n.Lang.locale)
private fun exDate(ms: Long): String = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).format(ExDateFmt)

private fun exSourceLabel(r: ExRoute) = when (r.source) { "gpx" -> "Impor GPX"; "act" -> "Dari aktivitas"; else -> "Dibuat di app" }
private fun exModeLabel(r: ExRoute) = when (r.mode) { "ride" -> "Sepeda"; "manual" -> "Manual"; else -> "Lari" }

/** Gambar kecil bentuk rute (tanpa peta), dengan titik awal hijau. */
@Composable
internal fun ExRouteThumb(pts: List<Pt>, modifier: Modifier = Modifier) {
    Canvas(modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xFFE9EDE4))) {
        if (pts.size < 2) return@Canvas
        val step = max(1, pts.size / 200)
        val sample = pts.filterIndexed { i, _ -> i % step == 0 || i == pts.lastIndex }
        val k = cos(Math.toRadians(sample.sumOf { it.lat } / sample.size))
        val xs = sample.map { it.lon * k }
        val ys = sample.map { -it.lat }
        val minX = xs.min(); val minY = ys.min()
        val dx = max(xs.max() - minX, 1e-9); val dy = max(ys.max() - minY, 1e-9)
        val pad = 10.dp.toPx()
        val s = min((size.width - 2 * pad) / dx, (size.height - 2 * pad) / dy)
        val ox = (size.width - dx * s) / 2; val oy = (size.height - dy * s) / 2
        fun px(i: Int) = androidx.compose.ui.geometry.Offset((ox + (xs[i] - minX) * s).toFloat(), (oy + (ys[i] - minY) * s).toFloat())
        val path = Path()
        for (i in sample.indices) { val o = px(i); if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y) }
        drawPath(path, Ember, style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawCircle(ExStartGreen, 3.5.dp.toPx(), px(0))
    }
}

@Composable
private fun ExFilterChip(label: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        Row(
            Modifier.height(44.dp).clip(RoundedCornerShape(22.dp))
                .background(if (selected > 0) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)
                .clickable(role = Role.Button, onClickLabel = "Filter $label") { open = true }.padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Text(
                if (selected > 0) options[selected] else label, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Medium,
                color = if (selected > 0) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface, maxLines = 1,
            )
            Icon(Icons.Filled.KeyboardArrowDown, null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEachIndexed { i, o -> DropdownMenuItem(text = { Text(if (i == 0) "Semua" else o) }, onClick = { onSelect(i); open = false }) }
        }
    }
}

/**
 * Koleksiku: daftar rute dan lokasi tersimpan, dengan filter jarak, area (dekat pusat peta), sumber, dan aktivitas.
 * Tombol Impor GPX menambah rute ke koleksi tanpa mengirimnya ke jam.
 */
@Composable
internal fun ExploreCollectionScreen(
    ctl: ExploreController,
    mapCenter: RouteGeo.LatLon?,
    onBack: () -> Unit,
    onOpenRoute: (String) -> Unit,
    onShowPlace: (ExPlace) -> Unit,
) {
    val routes by ctl.routes.collectAsState()
    val places by ctl.places.collectAsState()
    val message by ctl.message.collectAsState()
    var tab by remember { mutableStateOf(0) }
    var fDist by remember { mutableStateOf(0) }
    var fArea by remember { mutableStateOf(0) }
    var fSrc by remember { mutableStateOf(0) }
    var fAct by remember { mutableStateOf(0) }
    var renamePlace by remember { mutableStateOf<ExPlace?>(null) }
    var deletePlace by remember { mutableStateOf<ExPlace?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) ctl.importGpx(uri) }
    LaunchedEffect(message) { if (message != null) { kotlinx.coroutines.delay(4500); ctl.consumeMessage() } }

    val distOpts = listOf("Semua", "< 5 km", "5–10 km", "10–21 km", "> 21 km")
    val areaOpts = listOf("Semua", "≤ 25 km dari peta")
    val srcOpts = listOf("Semua", "Dibuat di app", "Impor GPX")
    val actOpts = listOf("Semua", "Lari", "Sepeda")

    val filtered = remember(routes, fDist, fArea, fSrc, fAct, mapCenter) {
        routes.filter { r ->
            val km = r.stats.km
            val okDist = when (fDist) { 1 -> km < 5; 2 -> km in 5.0..10.0; 3 -> km > 10.0 && km <= 21.1; 4 -> km > 21.1; else -> true }
            val okArea = fArea == 0 || mapCenter == null || ExploreGeo.dist(r.pts.first(), Pt(mapCenter.lat, mapCenter.lon, null)) <= 25_000.0
            val okSrc = when (fSrc) { 1 -> r.source == "app"; 2 -> r.source == "gpx"; else -> true }
            val okAct = when (fAct) { 1 -> r.mode != "ride"; 2 -> r.mode == "ride"; else -> true }
            okDist && okArea && okSrc && okAct
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 12.dp, top = 6.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = com.endurancevault.app.ui.i18n.Lang.tr("Kembali ke peta")) }
            Text("Koleksiku", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Row(
                Modifier.height(44.dp).clip(RoundedCornerShape(22.dp)).background(MaterialTheme.colorScheme.surfaceVariant)
                    .clickable(role = Role.Button, onClickLabel = "Impor berkas GPX") { picker.launch(arrayOf("*/*")) }.padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Icon(Icons.Filled.Download, null, tint = Ember, modifier = Modifier.size(18.dp))
                Text("Impor GPX", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Medium)
            }
        }

        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(24.dp)) {
            listOf("Rute ${routes.size}", "Lokasi ${places.size}").forEachIndexed { i, label ->
                Column(
                    Modifier.height(44.dp).clickable(role = Role.Tab, onClickLabel = label) { tab = i },
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
                ) {
                    Text(label, style = MaterialTheme.typography.titleSmall, fontWeight = if (tab == i) FontWeight.Bold else FontWeight.Medium,
                        color = if (tab == i) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(6.dp))
                    Box(Modifier.height(3.dp).width(32.dp).background(if (tab == i) Ember else Color.Transparent))
                }
            }
        }
        Box(Modifier.fillMaxWidth().height(0.8.dp).background(MaterialTheme.colorScheme.outlineVariant))

        if (tab == 0) {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ExFilterChip("Jarak", distOpts, fDist) { fDist = it }
                ExFilterChip("Area", areaOpts, fArea) { fArea = it }
                ExFilterChip("Sumber", srcOpts, fSrc) { fSrc = it }
                ExFilterChip("Aktivitas", actOpts, fAct) { fAct = it }
            }
            if (filtered.isEmpty()) {
                Text(
                    if (routes.isEmpty()) "Belum ada rute. Gambar rute di peta Explore lalu simpan, atau impor berkas GPX." else "Tidak ada rute yang cocok dengan filter.",
                    modifier = Modifier.padding(24.dp), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(filtered, key = { it.id }) { r ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surfaceVariant)
                            .clickable(role = Role.Button, onClickLabel = "Buka ${r.name}") { onOpenRoute(r.id) }.padding(10.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        ExRouteThumb(r.pts, Modifier.size(76.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterVertically)) {
                            Text(r.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            val st = r.stats
                            Text(
                                "${Js.fmtKm(st.km)} km" + (if (st.hasEle) " · naik ${Js.idn(st.up)} m" else "") + " · ${exModeLabel(r)}",
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.surface) {
                                    Text(exSourceLabel(r), Modifier.padding(horizontal = 8.dp, vertical = 3.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text(exDate(r.createdMs), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        } else {
            if (places.isEmpty()) {
                Text(
                    "Belum ada lokasi. Pilih alat Lokasi di peta Explore lalu ketuk peta untuk menyimpan titik (air minum, parkir, pos).",
                    modifier = Modifier.padding(24.dp), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(places, key = { it.id }) { p ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surfaceVariant)
                            .clickable(role = Role.Button, onClickLabel = "Lihat ${p.name} di peta") { onShowPlace(p) }.padding(start = 16.dp, top = 6.dp, bottom = 6.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                String.format(java.util.Locale.ROOT, "%.5f, %.5f", p.lat, p.lon),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        IconButton(onClick = { renamePlace = p }) { Icon(Icons.Filled.Edit, contentDescription = com.endurancevault.app.ui.i18n.Lang.tr("Ubah nama ${p.name}")) }
                        IconButton(onClick = { deletePlace = p }) { Icon(Icons.Filled.Delete, contentDescription = com.endurancevault.app.ui.i18n.Lang.tr("Hapus ${p.name}")) }
                    }
                }
            }
        }
    }

    renamePlace?.let { p ->
        var name by remember(p) { mutableStateOf(p.name) }
        AlertDialog(
            onDismissRequest = { renamePlace = null }, title = { Text("Ubah nama lokasi") },
            text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true) },
            confirmButton = { TextButton(onClick = { ctl.renamePlace(p.id, name); renamePlace = null }) { Text("Simpan") } },
            dismissButton = { TextButton(onClick = { renamePlace = null }) { Text("Batal") } },
        )
    }
    deletePlace?.let { p ->
        AlertDialog(
            onDismissRequest = { deletePlace = null }, title = { Text("Hapus lokasi?") }, text = { Text("\"${p.name}\" akan dihapus dari Koleksiku.") },
            confirmButton = { TextButton(onClick = { ctl.deletePlace(p.id); deletePlace = null }) { Text("Hapus") } },
            dismissButton = { TextButton(onClick = { deletePlace = null }) { Text("Batal") } },
        )
    }
}

private fun exPace(durationSec: Int, km: Double): String {
    if (km <= 0 || durationSec <= 0) return "–"
    val spk = (durationSec / km).toInt()
    return "${spk / 60}:${(spk % 60).toString().padStart(2, '0')}/km"
}

private fun exDateIso(iso: String): String = runCatching { java.time.LocalDate.parse(iso).format(ExDateFmt) }.getOrDefault(iso)

/**
 * Detail rute: peta (3 mode, tanjakan ≥ 10% merah tua, jejak lari serupa), statistik (dengan penyesuaian elevasi dari lari serupa),
 * profil elevasi yang bisa ditelusuri, tanjakan utama, titik di rute, lari serupa, pasang ke sesi, peta offline, kartu bagikan,
 * dan aksi Kirim ke jam / Sunting / Ekspor GPX.
 */
@Composable
internal fun ExploreRouteDetailScreen(
    ctl: ExploreController,
    routeId: String,
    estimateMin: (List<Pt>) -> Double?,
    activities: List<ActivityEntity>,
    detailOf: suspend (ActivityEntity) -> ActDetail?,
    sessions: List<ExSession>,
    onBack: () -> Unit,
    onEdit: () -> Unit,
    onSendToWatch: (ExRoute) -> Unit,
    onOpenActivity: (Long) -> Unit = {},
) {
    val routes by ctl.routes.collectAsState()
    val places by ctl.places.collectAsState()
    val style by ctl.mapStyle.collectAsState()
    val message by ctl.message.collectAsState()
    val sent by ctl.sent.collectAsState()
    val links by ctl.links.collectAsState()
    val offline by ctl.offlineProgress.collectAsState()
    val trailsOn by ctl.trailsOn.collectAsState()
    val poisOn by ctl.poisOn.collectAsState()
    val allPois by ctl.pois.collectAsState()
    val context = androidx.compose.ui.platform.LocalContext.current
    val route = routes.firstOrNull { it.id == routeId }
    LaunchedEffect(message) { if (message != null) { kotlinx.coroutines.delay(4500); ctl.consumeMessage() } }
    if (route == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    var menu by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var shareDialog by remember { mutableStateOf(false) }
    var sessionDialog by remember { mutableStateOf(false) }
    var probeKm by remember(route.id) { mutableStateOf<Double?>(null) }
    var selMatch by remember(route.id) { mutableStateOf<Long?>(null) }
    var view by remember(route.id) { mutableStateOf(exViewAt(RouteGeo.LatLon(route.pts[0].lat, route.pts[0].lon), 14.0)) }
    val fit = remember(route.id) { ExFit(1, route.pts.map { RouteGeo.LatLon(it.lat, it.lon) }) }
    val st = route.stats
    val est = remember(route) { estimateMin(route.pts) }
    val hikeCum = remember(route) { if (route.stats.hasEle && route.stats.up >= 150) com.endurancevault.app.domain.ExploreHike.cumulative(route.pts) else null }
    val hike = hikeCum?.last()
    var startMin by remember(route.id) { mutableStateOf(300) }
    var weatherText by remember(route.id) { mutableStateOf<String?>(null) }
    var weatherBusy by remember(route.id) { mutableStateOf(false) }
    val uiScope = androidx.compose.runtime.rememberCoroutineScope()
    // Penanda OSM (puncak, air, pondok) di sekitar rute: dimuat sekali per rute, dari cache bila ada.
    LaunchedEffect(route.id) {
        val pad = 0.02
        ctl.loadPois(route.pts.minOf { it.lat } - pad, route.pts.minOf { it.lon } - pad, route.pts.maxOf { it.lat } + pad, route.pts.maxOf { it.lon } + pad)
    }
    val nearPois = remember(route, allPois) {
        allPois.mapNotNull { poi ->
            val q = Pt(poi.lat, poi.lon, null)
            var best = Double.MAX_VALUE; var bi = 0
            route.pts.forEachIndexed { i, p -> val d = ExploreGeo.dist(p, q); if (d < best) { best = d; bi = i } }
            if (best <= 150.0) Triple(poi, cum[bi] / 1000.0, bi) else null
        }.sortedBy { it.second }
    }
    val cum = remember(route) { ExploreGeo.cumulative(route.pts) }
    val steep = remember(route) { if (st.hasEle) ExploreGrade.steepRanges(route.pts, cum) else emptyList() }
    val climbs = remember(route) { ExploreGrade.climbs(route.pts) }
    val probe = probeKm?.let { ExploreGrade.probe(route.pts, cum, it) }
    val nearPlaces = remember(route, places) {
        places.mapNotNull { pl ->
            val q = Pt(pl.lat, pl.lon, null)
            var best = Double.MAX_VALUE; var bi = 0
            route.pts.forEachIndexed { i, p -> val d = ExploreGeo.dist(p, q); if (d < best) { best = d; bi = i } }
            if (best <= 150.0) pl to cum[bi] / 1000.0 else null
        }.sortedBy { it.second }
    }
    val matchesState = androidx.compose.runtime.produceState<List<ExMatch>?>(null, route.id, activities.size) {
        value = runCatching { ctl.similarActivities(route, activities, detailOf) }.getOrDefault(emptyList())
    }
    val matches = matchesState.value
    val calib = remember(route, matches) { matches?.let { ctl.calibration(route, it) } }
    val trace = remember(selMatch, matches) { matches?.firstOrNull { it.act.id == selMatch }?.track.orEmpty() }
    val sentAt = sent[route.id]
    val linkedDates = remember(links, route.id) { links.filterValues { it == route.id }.keys.sorted() }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = com.endurancevault.app.ui.i18n.Lang.tr("Kembali ke Koleksiku")) }
            Text(route.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, contentDescription = com.endurancevault.app.ui.i18n.Lang.tr("Menu lainnya")) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Ubah nama") }, onClick = { menu = false; rename = true })
                    DropdownMenuItem(text = { Text("Hapus rute") }, onClick = { menu = false; confirmDelete = true })
                }
            }
        }
        message?.let { msg ->
            Surface(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.inverseSurface) {
                Text(msg, Modifier.padding(horizontal = 12.dp, vertical = 8.dp), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.inverseOnSurface)
            }
        }

        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
            Box(Modifier.fillMaxWidth().height(240.dp)) {
                ExploreMapCanvas(
                    view = view, onView = { view = it }, style = style, routePts = route.pts, anchors = route.anchors(),
                    places = nearPlaces.map { it.first }, fit = fit, steep = steep, trace = trace, marker = probe?.at, trails = trailsOn, pois = if (poisOn) allPois else emptyList(), pois = if (poisOn) allPois else emptyList(),
                )
                Column(Modifier.align(Alignment.TopEnd).padding(12.dp), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ExRoundButton(Icons.Filled.Route, "Jalur pendakian", selected = trailsOn) { ctl.setTrails(!trailsOn) }
                    ExRoundButton(Icons.Filled.Place, "Puncak dan sumber air", selected = poisOn) { ctl.setPois(!poisOn) }
                    ExRoundButton(Icons.Filled.Layers, "Ganti mode peta (sekarang ${style.label})") {
                        ctl.setStyle(style.next())
                    }
                }
            }
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    "${exModeLabel(route)} · ${exSourceLabel(route)} · ${exDate(route.createdMs)}" + if (sentAt != null) " · dikirim ke jam ${exDate(sentAt)}" else "",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ExStat("Jarak", Js.fmtKm(st.km), "km", Modifier.weight(1f))
                            ExStat("Naik", if (st.hasEle) Js.idn(st.up) else "–", "m", Modifier.weight(1f))
                            ExStat("Turun", if (st.hasEle) Js.idn(st.down) else "–", "m", Modifier.weight(1f))
                            ExStat("Est. waktu", if (est != null) exHm(est) else "–", "", Modifier.weight(1f))
                        }
                        hike?.let {
                            Text("Estimasi mendaki (rumus Tobler): ${exHm(it)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (calib != null) {
                            Text(
                                "Menurut jam: naik ≈ ${Js.idn(calib.up)} m, turun ≈ ${Js.idn(calib.down)} m (dari ${calib.runs} lari serupa; model elevasi ${(calib.ratio * 100).roundToInt()}% dari jam)",
                                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
                Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                    Column(Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 8.dp)) {
                        Text("Profil elevasi", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        if (st.prof.size >= 2) {
                            Text(
                                if (probe != null) "km ${Js.fmtKm(probe.km)}" + (probe.ele?.let { " · ${Js.idn(it.roundToInt())} m" } ?: "") +
                                    (probe.gradePct?.let { " · " + (if (it >= 0) "+" else "") + Js.fmtKm(it) + "%" } ?: "")
                                else "Ketuk atau tekan lama lalu geser untuk membaca kemiringan di titik itu",
                                style = MaterialTheme.typography.labelMedium, color = if (probe != null) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Spacer(Modifier.height(4.dp))
                            ExElevScrub(st.prof, probeKm, { probeKm = it }, Modifier.fillMaxWidth().height(64.dp))
                            Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("0 km", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("${Js.fmtKm(st.km / 2)} km", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("${Js.fmtKm(st.km)} km", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(
                                "Elevasi dari model digital 90 m, dihaluskan; bisa berbeda dari altimeter jam. Tanjakan ≥ 10% ditandai merah tua di peta.",
                                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp),
                            )
                        } else Text("Rute ini tidak punya data elevasi.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                if (climbs.isNotEmpty()) {
                    Text("Tanjakan utama", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    climbs.forEach { c ->
                        Row(Modifier.fillMaxWidth().height(40.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("km ${Js.fmtKm(c.fromKm)}", Modifier.width(72.dp), style = MaterialTheme.typography.bodyMedium)
                            Text("${Js.fmtKm(c.lenKm)} km", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                            Text("+${Js.idn(c.gain)} m", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                            Text("${Js.fmtKm(c.gradePct)}%", Modifier.width(52.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                val ai = route.anchorIdx
                fun eta(idx: Int): String? = hikeCum?.let { exClock(startMin + it[idx.coerceIn(0, it.lastIndex)]) }
                if (ai.size >= 2 || nearPlaces.isNotEmpty() || nearPois.isNotEmpty()) {
                    Text("Titik di rute", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    ai.forEachIndexed { n, idx ->
                        val label = when (n) { 0 -> "Titik awal"; ai.lastIndex -> "Titik akhir"; else -> "Waypoint $n" }
                        ExPointRow(label, cum[idx.coerceIn(0, cum.lastIndex)] / 1000.0, if (n == 0) ExStartGreen else if (n == ai.lastIndex) Color(0xFF1C1C1E) else ExBlue, false, eta(idx))
                    }
                    nearPlaces.forEach { (pl, km) -> ExPointRow(pl.name, km, ExPinFill, true) }
                    nearPois.forEach { (poi, km, idx) ->
                        val kindLabel = when (poi.kind) { "peak" -> "Puncak"; "water" -> "Air"; else -> "Pondok" }
                        ExPointRow("$kindLabel ${poi.name}" + (poi.ele?.let { " · ${Js.idn(it.roundToInt())} m" } ?: ""), km, when (poi.kind) { "peak" -> Color(0xFF7A4A1E); "water" -> Color(0xFF2B7FD0); else -> Color(0xFF2E7D4F) }, true, eta(idx))
                    }
                }

                if (hike != null && hikeCum != null) {
                    val startDate = remember(startMin) {
                        val now = java.time.LocalTime.now()
                        java.time.LocalDate.now().let { if (now.hour * 60 + now.minute > startMin) it.plusDays(1) else it }
                    }
                    val sun = remember(route.id, startDate) { ExploreSun.riseSet(route.pts[0].lat, route.pts[0].lon, startDate) }
                    fun minOfDay(ms: Long): Int = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalTime().let { it.hour * 60 + it.minute }
                    val endMin = startMin + hike
                    val riseMin = sun?.let { minOfDay(it.first) }
                    val setMin = sun?.let { minOfDay(it.second) }
                    Text("Rencana mendaki", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("Mulai ${exClock(startMin.toDouble())} (${if (startDate == java.time.LocalDate.now()) "hari ini" else "besok"})", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                                TextButton(onClick = { startMin = (startMin - 30).coerceAtLeast(0) }) { Text("−30 mnt") }
                                TextButton(onClick = { startMin = (startMin + 30).coerceAtMost(23 * 60) }) { Text("+30 mnt") }
                            }
                            Text("Tiba di akhir rute ${exClock(endMin)} · lama ${exHm(hike)}", style = MaterialTheme.typography.bodyMedium)
                            if (riseMin != null && setMin != null) {
                                Text("Matahari terbit ${exClock(riseMin.toDouble())} · terbenam ${exClock(setMin.toDouble())}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                if (startMin < riseMin - 10) Text("Mulai sebelum matahari terbit: bawa headlamp.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.tertiary)
                                if (endMin > setMin - 30) Text("Tiba mendekati atau setelah matahari terbenam: bawa headlamp, atau mulai lebih awal.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                            }
                            val topIdx = route.pts.indices.maxByOrNull { route.pts[it].ele ?: Double.NEGATIVE_INFINITY } ?: 0
                            val top = route.pts[topIdx]
                            OutlinedButton(
                                enabled = !weatherBusy,
                                onClick = {
                                    weatherBusy = true
                                    uiScope.launch {
                                        val hrs = ExploreWeather.fetch(top.lat, top.lon, top.ele ?: 0.0)
                                        val day = startDate.toString()
                                        val h0 = startMin / 60; val h1 = ((endMin + 59) / 60).toInt().coerceAtMost(23)
                                        val win = hrs?.filter { it.time.startsWith(day) && it.time.substring(11, 13).toInt() in h0..h1 }.orEmpty()
                                        weatherText = if (win.isEmpty()) "Prakiraan tidak tersedia (offline?)." else
                                            "Cuaca di puncak (${Js.idn((top.ele ?: 0.0).roundToInt())} m), ${h0.toString().padStart(2, '0')}:00–${h1.toString().padStart(2, '0')}:00: " +
                                                "suhu ${Js.fmtKm(win.minOf { it.tempC })}–${Js.fmtKm(win.maxOf { it.tempC })} °C, peluang hujan maks ${win.maxOf { it.popPct }}%, " +
                                                "angin maks ${win.maxOf { it.windKmh }.roundToInt()} km/j (hembusan ${win.maxOf { it.gustKmh }.roundToInt()})."
                                        weatherBusy = false
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().height(44.dp),
                            ) { Text(if (weatherBusy) "Mengambil prakiraan…" else "Cek cuaca di puncak") }
                            weatherText?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                }

                Text("Lari di rute ini", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                when {
                    matches == null -> Text("Mencari lari serupa…", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    matches.isEmpty() -> Text(
                        "Belum ada aktivitas yang mengikuti rute ini (mulai dekat ujung rute, jarak mirip, ≥ 70% jejak berada ≤ 60 m dari rute).",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    else -> {
                        Text("Ketuk untuk menampilkan jejaknya di peta (ungu).", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        matches.forEach { m ->
                            val on = selMatch == m.act.id
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                                    .background(if (on) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)
                                    .clickable(role = Role.Button, onClickLabel = "Tampilkan jejak lari ${exDateIso(m.act.dateIso)}") { selMatch = if (on) null else m.act.id }
                                    .padding(start = 14.dp, top = 6.dp, bottom = 6.dp, end = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(exDateIso(m.act.dateIso), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                    Text(
                                        "${Js.fmtKm(m.act.km)} km · ${exPace(m.act.durationSec, m.act.km)} · mengikuti rute ${m.followPct}%" + (m.gain?.let { " · naik ${Js.idn(it)} m" } ?: ""),
                                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                TextButton(onClick = { onOpenActivity(m.act.id) }) { Text("Buka") }
                            }
                        }
                    }
                }

                Text("Sesi latihan", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                Text(
                    if (linkedDates.isEmpty()) "Belum dipasang ke sesi. Rute yang dipasang tampil di kartu Hari ini pada tanggal sesinya."
                    else "Dipasang ke: " + linkedDates.joinToString(", ") { exDateIso(it) },
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedButton(onClick = { sessionDialog = true }, enabled = sessions.isNotEmpty(), modifier = Modifier.fillMaxWidth().height(48.dp)) {
                    Text(if (sessions.isEmpty()) "Tidak ada sesi terjadwal" else "Pasang ke sesi")
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { ctl.downloadOffline(route) }, enabled = offline == null, modifier = Modifier.weight(1f).height(48.dp)) {
                        Text(offline?.let { "Mengunduh ${it.first}/${it.second}" } ?: "Peta offline")
                    }
                    OutlinedButton(onClick = { shareDialog = true }, modifier = Modifier.weight(1f).height(48.dp)) { Text("Bagikan kartu") }
                }
                OutlinedButton(onClick = { ctl.downloadOfflineArea(route) }, enabled = offline == null, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                    Text("Peta offline seluruh area (±3 km)")
                }
                Text(
                    "Peta offline mengunduh ubin di sepanjang rute (±1 ubin, zoom 12–16) untuk mode peta yang sedang dipilih.",
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        Surface(color = MaterialTheme.colorScheme.background, border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                ExRoundButton(Icons.Filled.Edit, "Sunting rute di peta", filled = true) { if (ctl.loadForEdit(route.id)) onEdit() }
                ExRoundButton(Icons.Filled.Upload, "Ekspor GPX", filled = true) { ctl.shareGpx(route) }
                Button(onClick = { onSendToWatch(route) }, modifier = Modifier.weight(1f).height(48.dp)) {
                    Icon(Icons.Filled.Watch, null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(if (sentAt != null) "Kirim ulang ke jam" else "Kirim ke jam", fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (rename) {
        var name by remember { mutableStateOf(route.name) }
        AlertDialog(
            onDismissRequest = { rename = false }, title = { Text("Ubah nama rute") },
            text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true) },
            confirmButton = { TextButton(onClick = { ctl.renameRoute(route.id, name); rename = false }) { Text("Simpan") } },
            dismissButton = { TextButton(onClick = { rename = false }) { Text("Batal") } },
        )
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false }, title = { Text("Hapus rute?") }, text = { Text("\"${route.name}\" akan dihapus dari Koleksiku.") },
            confirmButton = { TextButton(onClick = { confirmDelete = false; ctl.deleteRoute(route.id) }) { Text("Hapus") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Batal") } },
        )
    }
    if (sessionDialog) {
        AlertDialog(
            onDismissRequest = { sessionDialog = false }, title = { Text("Pasang ke sesi") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    sessions.forEach { se ->
                        val mine = links[se.dateIso] == route.id
                        val other = links[se.dateIso]?.let { id -> if (id != route.id) routes.firstOrNull { it.id == id }?.name else null }
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                .background(if (mine) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                                .clickable(role = Role.Button) { ctl.linkRoute(se.dateIso, if (mine) null else route.id) }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(exDateIso(se.dateIso) + " · " + se.label, style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    (if (se.km > 0) "target ${Js.fmtKm(se.km)} km · rute ${Js.fmtKm(st.km)} km" else "rute ${Js.fmtKm(st.km)} km") + (other?.let { " · ganti \"$it\"" } ?: ""),
                                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            if (mine) Text("Dipasang", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { sessionDialog = false }) { Text("Selesai") } },
        )
    }
    if (shareDialog) {
        AlertDialog(
            onDismissRequest = { shareDialog = false }, title = { Text("Bagikan kartu rute") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    ExploreShare.Skin.values().forEach { sk ->
                        TextButton(
                            onClick = {
                                shareDialog = false
                                val bmp = ExploreShare.render(route, sk, calib)
                                val r = com.endurancevault.app.ui.sticker.StickerIo.share(context, "rute-${route.id}.png", bmp, "Bagikan rute")
                                if (r.isFailure) ctl.message.value = "Gagal membagikan: ${r.exceptionOrNull()?.message ?: "tidak diketahui"}"
                            },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                        ) { Text(sk.label, Modifier.fillMaxWidth()) }
                    }
                    Text("Kartu 4:5 berisi bentuk rute, statistik, dan profil elevasi.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { shareDialog = false }) { Text("Batal") } },
        )
    }
}

@Composable
private fun ExPointRow(label: String, km: Double, color: Color, pin: Boolean, eta: String? = null) {
    Row(Modifier.fillMaxWidth().height(44.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.size(14.dp).background(color, if (pin) RoundedCornerShape(4.dp) else androidx.compose.foundation.shape.CircleShape))
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("km ${Js.fmtKm(km)}" + (eta?.let { " · $it" } ?: ""), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Jam dinding "HH:mm" dari menit sejak tengah malam (melewati 24 jam berputar). */
private fun exClock(min: Double): String {
    val m = Math.floorMod(min.roundToInt(), 1440)
    return "%02d:%02d".format(java.util.Locale.ROOT, m / 60, m % 60)
}
