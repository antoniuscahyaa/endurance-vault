package com.endurancevault.app.data

import com.endurancevault.app.domain.PbAk
import com.endurancevault.app.domain.PbConv
import com.endurancevault.app.domain.PbPost
import com.endurancevault.app.domain.PlanSettings
import com.google.gson.stream.JsonReader
import com.google.gson.stream.JsonToken
import java.io.InputStream
import java.io.InputStreamReader
import java.time.LocalDate
import kotlin.math.floor

class BackupException(message: String) : Exception(message)

/** Hasil membaca cadangan web (berkas JSON `app: "rencana-lari"`). */
class ParsedBackup(
    val settings: PlanSettings,
    val activities: List<ActivityEntity>,
    val doneDays: Int,
    /** Jumlah detail aktivitas (rute GPS, split) di cadangan. Dibaca pada tahap impor FIT/GPX. */
    val detailCount: Int,
    /** Jumlah kunci pengaturan lain (profil, foto, tampilan, dll.). Berkas aslinya disimpan utuh. */
    val extraKeys: Int,
    val exportedAt: Long?,
)

/**
 * Membaca cadangan versi web secara streaming (aman untuk berkas puluhan MB yang berisi rute dan foto).
 * Hanya bagian `s` (pengaturan), `log` (catatan lari) dan `done` yang dimuat ke memori; sisanya dilewati atau dihitung.
 */
object BackupParser {
    fun parse(input: InputStream): ParsedBackup {
        val r = JsonReader(InputStreamReader(input, Charsets.UTF_8))
        var app: String? = null
        var ver = -1
        var s: Map<String, Any?>? = null
        var log: Map<String, Any?> = emptyMap()
        var done = 0; var details = 0; var extra = 0
        var at: Long? = null
        try {
            if (r.peek() != JsonToken.BEGIN_OBJECT) throw BackupException("Berkas ini bukan cadangan EnduranceVault.")
            r.beginObject()
            while (r.hasNext()) {
                when (r.nextName()) {
                    "app" -> app = readAny(r) as? String
                    "v" -> ver = (readAny(r) as? Double)?.toInt() ?: -1
                    "at" -> at = (readAny(r) as? Double)?.toLong()
                    "s" -> s = asMap(readAny(r))
                    "log" -> log = asMap(readAny(r)) ?: emptyMap()
                    "done" -> done = countKeys(r)
                    "acts" -> details = countKeys(r)
                    "x" -> extra = countKeys(r)
                    else -> r.skipValue()
                }
            }
            r.endObject()
        } catch (e: BackupException) {
            throw e
        } catch (e: Exception) {
            throw BackupException("Berkas rusak atau terpotong, cadangan tidak bisa dibaca.")
        }
        if (app != "rencana-lari" || ver != 1) throw BackupException("Berkas ini bukan cadangan EnduranceVault (versi web).")
        return ParsedBackup(settingsOf(s ?: emptyMap()), activitiesOf(log), done, details, extra, at)
    }

    private fun readAny(r: JsonReader): Any? = JsonUtil.readAny(r)
    private fun asMap(v: Any?): Map<String, Any?>? = JsonUtil.asMap(v)

    private fun countKeys(r: JsonReader): Int {
        if (r.peek() != JsonToken.BEGIN_OBJECT) { r.skipValue(); return 0 }
        var n = 0
        r.beginObject()
        while (r.hasNext()) { r.nextName(); r.skipValue(); n++ }
        r.endObject()
        return n
    }

    /* ---------- pemetaan ke model aplikasi ---------- */

    private fun Map<String, Any?>.str(k: String): String = when (val v = this[k]) {
        null -> ""
        is Double -> if (v == floor(v) && !v.isInfinite()) v.toLong().toString() else v.toString()
        else -> v.toString()
    }

    private fun Map<String, Any?>.num(k: String): Double? = when (val v = this[k]) {
        is Double -> v
        is String -> v.trim().replace(',', '.').toDoubleOrNull()
        else -> null
    }

    private fun date(t: String): LocalDate? = runCatching { LocalDate.parse(t.take(10)) }.getOrNull()

    internal fun settingsOf(s: Map<String, Any?>): PlanSettings {
        val d = PlanSettings()
        val pp = asMap(s["pbPost"]); val pc = asMap(s["pbConv"]); val pa = asMap(s["pbAk"])
        return PlanSettings(
            name = s.str("name"),
            rtype = s.str("rtype").ifEmpty { d.rtype },
            start = date(s.str("start")) ?: LocalDate.now(),
            race = date(s.str("race")),
            raceKm = s.num("raceKm"),
            raceGain = s.num("raceGain"),
            goalT = s.str("goalT"),
            base = s.num("base") ?: d.base,
            peak = s.num("peak") ?: d.peak,
            days = s.num("days")?.toInt() ?: d.days,
            rest = s.num("rest")?.toInt() ?: d.rest,
            rest2 = s.num("rest2")?.toInt() ?: d.rest2,
            longDay = s.num("longDay")?.toInt() ?: d.longDay,
            hr = s.num("hr")?.toInt() ?: d.hr,
            thr = s.str("thr").ifEmpty { d.thr },
            pace = s.str("pace").ifEmpty { d.pace },
            hrMax = s.num("hrmax")?.toInt(),
            bspd = s.num("bspd") ?: d.bspd,
            pbCycle = s.str("pbCycle").ifEmpty { d.pbCycle },
            pbFocus = s.str("pbFocus").ifEmpty { d.pbFocus },
            pbPost = pp?.let { p -> p.num("rec")?.let { PbPost(it, p.num("lvl") ?: 0.0) } },
            pbConv = pc?.let { p -> p.num("wk")?.let { PbConv(it.toInt(), p.num("b0") ?: 0.0, p.num("p0") ?: 0.0) } },
            pbAk = pa?.let { p -> date(p.str("wk"))?.let { w -> p.num("km")?.let { PbAk(w, it) } } },
            evOn = s["evOn"] == true,
            evDate = date(s.str("evDate")),
            evKm = s.num("evKm") ?: 0.0,
            evGain = s.num("evGain") ?: 0.0,
            zm = if (s.str("zm") == "hrr") "hrr" else "lthr",
            lthr = s.num("lthr")?.takeIf { it > 0 },
            rhr = s.num("rhr")?.takeIf { it > 0 },
            zl = listOf("zl2", "zl3", "zl4", "zl5").mapIndexed { i, k -> s.num(k) ?: d.zl[i] },
            zr = listOf("zr1", "zr2", "zr3", "zr4", "zr5").mapIndexed { i, k -> s.num(k) ?: d.zr[i] },
        )
    }

    internal fun activitiesOf(log: Map<String, Any?>): List<ActivityEntity> {
        val out = ArrayList<ActivityEntity>(log.size)
        for ((key, v) in log) {
            val rec = asMap(v) ?: continue
            val day = date(key)?.toString() ?: continue
            out.add(
                ActivityEntity(
                    dateIso = day,
                    km = rec.num("km") ?: 0.0,
                    durationSec = Math.round((rec.num("min") ?: 0.0) * 60).toInt(),
                    avgHr = rec.num("hr")?.toInt(),
                    feel = rec.num("feel")?.toInt(),
                    note = rec.str("note"),
                    srcKey = key,
                    name = rec.str("name"),
                    gain = rec.num("gain")?.toInt(),
                    startTime = rec.str("st").ifEmpty { null },
                    maxHr = rec.num("hrMax")?.toInt(),
                    type = if (rec.str("type") == "bike") "bike" else "run",
                    gearId = rec.str("gear").ifEmpty { null },
                ),
            )
        }
        return out
    }

    /**
     * Lintasan kedua: salin tiap entri `acts` (rute GPS, split, grafik) apa adanya ke berkas terpisah di [outDir],
     * satu berkas per aktivitas bernama [ActStore.backupFileName]. Memori yang dipakai hanya satu token pada satu waktu.
     * @return kunci aktivitas yang tersalin
     */
    fun extractActs(input: InputStream, outDir: java.io.File): List<String> {
        outDir.mkdirs()
        val keys = ArrayList<String>()
        val r = JsonReader(InputStreamReader(input, Charsets.UTF_8))
        try {
            if (r.peek() != JsonToken.BEGIN_OBJECT) throw BackupException("Berkas ini bukan cadangan EnduranceVault.")
            r.beginObject()
            while (r.hasNext()) {
                if (r.nextName() != "acts" || r.peek() != JsonToken.BEGIN_OBJECT) { r.skipValue(); continue }
                r.beginObject()
                while (r.hasNext()) {
                    val key = r.nextName()
                    if (r.peek() != JsonToken.BEGIN_OBJECT) { r.skipValue(); continue }
                    val f = java.io.File(outDir, ActStore.backupFileName(key))
                    com.google.gson.stream.JsonWriter(f.writer(Charsets.UTF_8).buffered()).use { w -> JsonUtil.copyValue(r, w) }
                    keys.add(key)
                }
                r.endObject()
            }
            r.endObject()
        } catch (e: BackupException) {
            throw e
        } catch (e: Exception) {
            throw BackupException("Gagal membaca rute dari cadangan: ${e.message ?: e.javaClass.simpleName}")
        }
        return keys
    }
}
