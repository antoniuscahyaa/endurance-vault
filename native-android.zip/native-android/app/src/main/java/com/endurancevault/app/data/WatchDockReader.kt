package com.endurancevault.app.data

import android.content.Context
import com.endurancevault.app.domain.BatPoint
import com.endurancevault.app.domain.WatchDock
import com.endurancevault.app.domain.WatchModel
import com.endurancevault.app.domain.WatchRaw
import com.rencanalari.huaweiwatch.ProtocolBridge
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.ZoneId

/** Hasil satu kali pembacaan dock Jam. */
sealed interface WatchDockUi {
    data object Loading : WatchDockUi
    /** Inti protokol jam tidak ikut dikompilasi pada build ini. */
    data object Unsupported : WatchDockUi
    class Ready(val model: WatchModel, val readAtMs: Long) : WatchDockUi
    class Failed(val message: String) : WatchDockUi
}

/**
 * Padanan jamRead() di web: membaca status, live, harian, dan latihan dari basis data sinkron lokal jam lewat ProtocolBridge
 * (tanpa lapisan Capacitor), lalu merakit WatchModel. Data terakhir tetap terbaca walau jam sedang tidak terhubung.
 * Juga menyimpan riwayat baterai (jam tidak menyimpannya) dan nama tampilan jam buatan pengguna.
 */
class WatchDockReader(private val context: Context) {
    private val prefs = context.getSharedPreferences("watch_dock", Context.MODE_PRIVATE)

    // ---- alias nama jam (kosmetik; disimpan lokal, tidak dikirim ke jam) ----

    fun alias(): String = clean(prefs.getString(KEY_ALIAS, "") ?: "")
    fun setAlias(v: String) { prefs.edit().putString(KEY_ALIAS, clean(v)).apply() }
    private fun clean(v: String) = v.replace(Regex("[\\u0000-\\u001f\\u007f]"), " ").replace(Regex("\\s+"), " ").trim().take(ALIAS_MAX)

    // ---- log baterai ----

    @Synchronized fun batLog(): List<BatPoint> = runCatching {
        val a = JSONArray(prefs.getString(KEY_BAT, "[]") ?: "[]")
        (0 until a.length()).mapNotNull { i -> a.optJSONObject(i)?.let { BatPoint(it.optLong("t"), it.optInt("p")) } }
    }.getOrDefault(emptyList())

    /** Catat level dari status plugin memakai waktu baca sebenarnya (batteryAt), bukan "sekarang"; bacaan lebih tua dari 15 menit dilewati. */
    @Synchronized fun noteBattery(status: JSONObject, nowSec: Long) {
        if (!status.has("battery") || status.isNull("battery")) return
        val p = status.optInt("battery", -1); if (p < 0) return
        val t = status.optLong("batteryAt", 0L).takeIf { it > 0 } ?: nowSec
        if (nowSec - t > 900) return
        val next = WatchDock.batAdd(batLog(), p, t)
        val arr = JSONArray(); next.forEach { arr.put(JSONObject().put("t", it.t).put("p", it.p)) }
        prefs.edit().putString(KEY_BAT, arr.toString()).apply()
    }

    // ---- baca ----

    /** Jalankan di Dispatchers.IO. Mengembalikan Unsupported bila inti protokol tidak ada. */
    fun read(hrMaxEst: Int?, nowMs: Long = System.currentTimeMillis()): WatchDockUi {
        val bridge = try { ProtocolBridge.get(context) } catch (e: Throwable) { return WatchDockUi.Unsupported }
        val now = nowMs / 1000L
        val zone = ZoneId.systemDefault()
        val tzMin = zone.rules.getOffset(Instant.ofEpochSecond(now)).totalSeconds / 60
        val mid = Instant.ofEpochSecond(now).atZone(zone).toLocalDate().atStartOfDay(zone).toEpochSecond()

        val status = runCatching { bridge.status() }.getOrElse { JSONObject().put("state", "disconnected") }
        if (status.has("protocolReady") && !status.optBoolean("protocolReady", true)) return WatchDockUi.Unsupported
        runCatching { noteBattery(status, now) }

        return try {
            val live = bridge.readLive(mid, mid + 86400, WatchDock.BUCKET)
            val daily = bridge.readDaily(mid - 8 * 86400, tzMin)
            val busy = HuaweiSleepParity.busyFromPayload(daily.optJSONArray("busy"))
            val parsed = HuaweiSleepParity.parseAll(daily.optJSONArray("sleep") ?: JSONArray(), zone, busy)
            val last = parsed.nights.lastOrNull()
            var sleepHr = 0.0
            if (last != null && now - last.end <= 36 * 3600) {
                runCatching { bridge.readHrWindow(last.start, last.end) }.getOrNull()?.let { h ->
                    if (h.optInt("n", 0) >= 10 && h.optDouble("avg", 0.0) > 0) sleepHr = h.optDouble("avg", 0.0)
                }
            }
            val workouts = runCatching { WatchDock.parseWorkouts(bridge.readWorkouts(now - 365L * 86400, 100).optJSONArray("workouts")) }.getOrDefault(emptyList())
            val raw = WatchRaw(status, live, daily, parsed.nights, parsed.naps, sleepHr, workouts, batLog(), alias())
            WatchDockUi.Ready(WatchDock.model(raw, now, tzMin, hrMaxEst), nowMs)
        } catch (e: Throwable) {
            WatchDockUi.Failed(e.message ?: e.javaClass.simpleName)
        }
    }

    companion object {
        private const val KEY_ALIAS = "alias"
        private const val KEY_BAT = "batlog"
        const val ALIAS_MAX = 30
    }
}
