package com.endurancevault.app.ui.sticker

import android.content.Context
import android.graphics.Typeface
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File

/** Huruf kustom untuk stiker: [num] untuk angka dan judul, [body] untuk teks isi. Null = huruf bawaan sistem. */
class StickerFonts(val num: Typeface?, val body: Typeface?) {
    companion object { val NONE = StickerFonts(null, null) }
}

/**
 * Berkas huruf (.ttf/.otf) yang diimpor pengguna, disimpan di `files/sticker_fonts/` (privat untuk aplikasi).
 * Huruf hanya dipakai untuk menggambar stiker; berkasnya tidak dibagikan ke mana pun.
 */
class StickerFontStore(ctx: Context) {
    private val app = ctx.applicationContext
    private val dir = File(app.filesDir, "sticker_fonts")

    fun list(): List<String> = dir.listFiles()?.filter { it.isFile }?.map { it.name }?.sortedBy { it.lowercase() }.orEmpty()

    /** Nama untuk tampilan: tanpa ekstensi. */
    fun label(name: String): String = name.substringBeforeLast('.')

    fun typeface(name: String): Typeface? {
        if (name.isEmpty() || !SAFE.matches(name)) return null
        val f = File(dir, name)
        if (!f.isFile) return null
        return runCatching { Typeface.createFromFile(f) }.getOrNull()
    }

    fun delete(name: String) { if (SAFE.matches(name)) File(dir, name).delete() }

    /** Salin berkas huruf pilihan pengguna; mengembalikan nama berkas tersimpan. Ditolak bila bukan huruf yang valid atau lebih dari 15 MB. */
    fun import(uri: Uri): Result<String> = runCatching {
        val cr = app.contentResolver
        val shown = cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        } ?: uri.lastPathSegment ?: "huruf.ttf"
        val ext = shown.substringAfterLast('.', "").lowercase()
        require(ext == "ttf" || ext == "otf") { "Pilih berkas huruf berekstensi .ttf atau .otf." }
        val base = shown.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9_-]"), "_").take(60).ifEmpty { "huruf" }
        dir.mkdirs()
        val tmp = File(dir, ".impor.tmp")
        try {
            var total = 0L
            cr.openInputStream(uri)!!.use { input ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf); if (n < 0) break
                        total += n
                        require(total <= MAX_BYTES) { "Berkas huruf terlalu besar (maksimal 15 MB)." }
                        out.write(buf, 0, n)
                    }
                }
            }
            val ok = runCatching { Typeface.createFromFile(tmp) }.getOrNull()
            require(ok != null && total > 0) { "Berkas itu bukan huruf yang valid." }
            val name = "$base.$ext"
            val dest = File(dir, name)
            if (dest.exists()) dest.delete()
            require(tmp.renameTo(dest)) { "Tidak bisa menyimpan berkas huruf." }
            name
        } finally { tmp.delete() }
    }

    companion object {
        private const val MAX_BYTES = 15L * 1024 * 1024
        /** Nama berkas yang diperbolehkan (dipakai juga untuk membersihkan pengaturan). */
        val SAFE = Regex("[A-Za-z0-9_-]{1,60}\\.(ttf|otf)")
    }
}
