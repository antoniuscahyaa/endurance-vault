package com.endurancevault.app.domain

import kotlin.math.roundToInt

/**
 * Jejak GPS asli per detik, sejajar indeks demi indeks dengan deret 1 Hz (`tl`).
 *
 * Disimpan saat impor (berkas FIT/GPX/TCX) dan saat autosync dari jam, supaya ekspor GPX tidak perlu lagi
 * menebak posisi dari rute sederhana (`rt`, ±140 titik).
 *  - [lat], [lon]: derajat, resolusi 1e-6 (±0,11 m).
 *  - [wallSec]: detik jam dinding sejak waktu mulai aktivitas (`t0`). Berbeda dengan `tl.s` (detik gerak), deret ini
 *    memuat jeda, sehingga waktu berhenti (elapsed) ikut terbawa ke GPX.
 */
class GpsTrack(val lat: DoubleArray, val lon: DoubleArray, val wallSec: IntArray) {
    val size: Int get() = wallSec.size
}

/** Format JSON `gt`: `{"r":1,"la":[...],"lo":[...],"w":[...]}`, tiap larik berisi nilai pertama mutlak lalu selisih. */
object GpsTrackCodec {
    private const val SCALE = 1e6

    /** Titik tanpa posisi diisi dari titik terdekat; null bila tak ada satu pun posisi valid atau panjang tak sama. */
    fun encode(lat: List<Double>, lon: List<Double>, wallSec: List<Double>): Map<String, Any?>? {
        val n = lat.size
        if (n < 2 || lon.size != n || wallSec.size != n) return null
        val la = DoubleArray(n) { lat[it] }
        val lo = DoubleArray(n) { lon[it] }
        fun ok(i: Int) = la[i].isFinite() && lo[i].isFinite()
        val first = (0 until n).firstOrNull { ok(it) } ?: return null
        for (i in 0 until first) { la[i] = la[first]; lo[i] = lo[first] }
        for (i in first + 1 until n) if (!ok(i)) { la[i] = la[i - 1]; lo[i] = lo[i - 1] }

        val w = IntArray(n)
        for (i in 0 until n) {
            val raw = if (wallSec[i].isFinite()) wallSec[i].roundToInt().coerceAtLeast(0) else 0
            w[i] = if (i == 0) raw else maxOf(raw, w[i - 1] + 1) // waktu GPX harus naik tegas
        }
        fun delta(v: IntArray) = List(v.size) { if (it == 0) v[0] else v[it] - v[it - 1] }
        val laI = IntArray(n) { Math.round(la[it] * SCALE).toInt() }
        val loI = IntArray(n) { Math.round(lo[it] * SCALE).toInt() }
        return linkedMapOf("r" to 1, "la" to delta(laI), "lo" to delta(loI), "w" to delta(w))
    }

    fun decode(raw: Any?): GpsTrack? {
        val m = raw as? Map<*, *> ?: return null
        if ((m["r"] as? Number)?.toInt() != 1) return null
        fun ints(key: String): IntArray? {
            val l = m[key] as? List<*> ?: return null
            val out = IntArray(l.size)
            var acc = 0
            for (i in l.indices) {
                val v = (l[i] as? Number)?.toLong() ?: return null
                acc += v.toInt()
                out[i] = acc
            }
            return out
        }
        val la = ints("la") ?: return null
        val lo = ints("lo") ?: return null
        val w = ints("w") ?: return null
        if (la.size < 2 || la.size != lo.size || la.size != w.size) return null
        val lat = DoubleArray(la.size) { la[it] / SCALE }
        val lon = DoubleArray(lo.size) { lo[it] / SCALE }
        if (lat.any { it !in -90.0..90.0 } || lon.any { it !in -180.0..180.0 }) return null
        return GpsTrack(lat, lon, w)
    }

    fun toMap(t: GpsTrack): Map<String, Any?>? =
        encode(t.lat.toList(), t.lon.toList(), t.wallSec.map { it.toDouble() })

    /** Potongan indeks [i0]..[i1] (inklusif); waktu tetap relatif terhadap `t0` asli. Null bila hasilnya kurang dari dua titik. */
    fun slice(t: GpsTrack, i0: Int, i1: Int): GpsTrack? {
        if (i0 < 0 || i1 >= t.size || i1 <= i0) return null
        return GpsTrack(t.lat.copyOfRange(i0, i1 + 1), t.lon.copyOfRange(i0, i1 + 1), t.wallSec.copyOfRange(i0, i1 + 1))
    }

    /**
     * True bila deret 1 Hz [existingTl] dan [freshTl] (objek `tl` mentah) berasal dari lintasan yang sama: jumlah detik
     * sama dan jarak akhir selisih paling banyak [toleranceM]. Dipakai sebelum jejak baru ditempelkan ke berkas lama,
     * agar indeks `gt` tidak bergeser terhadap `tl`.
     */
    fun alignedWith(existingTl: Any?, freshTl: Any?, toleranceM: Double = 1.0): Boolean {
        fun size(tl: Any?) = ((tl as? Map<*, *>)?.get("s") as? List<*>)?.size ?: -1
        fun lastDist(tl: Any?) = (((tl as? Map<*, *>)?.get("d") as? List<*>)?.lastOrNull() as? Number)?.toDouble()
        val n = size(existingTl)
        if (n < 2 || n != size(freshTl)) return false
        val a = lastDist(existingTl) ?: return false
        val b = lastDist(freshTl) ?: return false
        return kotlin.math.abs(a - b) <= toleranceM
    }
}
