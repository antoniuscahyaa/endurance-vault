package com.endurancevault.app.domain

import org.json.JSONObject
import java.time.LocalDateTime
import java.time.ZoneOffset
import kotlin.math.floor

/**
 * Port dari kartu cuaca di web (07h-weather-dashboard.js + WX_TXT/fcKind di 06/07-*.js).
 * Murni (tanpa Android/Compose) supaya mudah diuji. Waktu dari Open-Meteo dengan timezone=auto
 * berupa teks lokal lokasi, mis. "2026-11-07T14:00", jadi tidak perlu konversi zona.
 */
enum class WxKind { CLEAR, PARTLY, CLOUD, FOG, RAIN, STORM, SNOW, NONE }

/** Kelas latar kartu sapaan (setara weather-* di CSS web). */
enum class WxScene { CLEAR, PARTLY, CLOUDY, FOG, RAIN, STORM, SNOW }

data class WxHour(val time: String, val temp: Double, val code: Int, val pop: Int?)
data class WxDay(val date: String, val hi: Double, val lo: Double, val code: Int, val pop: Int?)

data class WxSnapshot(
    val lat: Double, val lon: Double, val place: String,
    val temp: Double, val feels: Double, val code: Int,
    val humidity: Int?, val wind: Double?,
    val usAqi: Int?, val pm25: Double?,
    val sunrise: String?, val sunset: String?,
    val currentTime: String?,
    val hours: List<WxHour>, val days: List<WxDay>,
    val fetchedAtMs: Long,
)

object Wx {
    const val FORECAST_PARAMS_CURRENT = "temperature_2m,apparent_temperature,relative_humidity_2m,precipitation,weather_code,wind_speed_10m"
    const val FORECAST_PARAMS_HOURLY = "temperature_2m,weather_code,precipitation_probability"
    const val FORECAST_PARAMS_DAILY = "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_speed_10m_max,sunrise,sunset"
    const val AIR_PARAMS_CURRENT = "us_aqi,european_aqi,pm2_5,pm10"

    fun kind(c: Int): WxKind = when {
        c == 0 || c == 1 -> WxKind.CLEAR
        c == 2 -> WxKind.PARTLY
        c == 3 -> WxKind.CLOUD
        c == 45 || c == 48 -> WxKind.FOG
        c >= 95 -> WxKind.STORM
        c in 71..77 || c == 85 || c == 86 -> WxKind.SNOW
        c >= 51 -> WxKind.RAIN
        else -> WxKind.NONE
    }

    /** Sama dengan gmCurrentWeatherClass() di web. */
    fun scene(c: Int): WxScene? = when {
        c == 0 -> WxScene.CLEAR
        c == 1 || c == 2 -> WxScene.PARTLY
        c == 3 -> WxScene.CLOUDY
        c == 45 || c == 48 -> WxScene.FOG
        c >= 95 -> WxScene.STORM
        c in 71..77 || c == 85 || c == 86 -> WxScene.SNOW
        c >= 51 -> WxScene.RAIN
        else -> null
    }

    private val labels = mapOf(
        0 to "Cerah", 1 to "Cerah berawan", 2 to "Berawan sebagian", 3 to "Mendung",
        45 to "Berkabut", 48 to "Berkabut",
        51 to "Gerimis ringan", 53 to "Gerimis", 55 to "Gerimis lebat", 56 to "Gerimis beku", 57 to "Gerimis beku",
        61 to "Hujan ringan", 63 to "Hujan", 65 to "Hujan lebat", 66 to "Hujan beku", 67 to "Hujan beku",
        71 to "Salju ringan", 73 to "Salju", 75 to "Salju lebat", 77 to "Butiran salju",
        80 to "Hujan sesaat", 81 to "Hujan sesaat", 82 to "Hujan sesaat lebat", 85 to "Salju sesaat", 86 to "Salju sesaat",
        95 to "Badai petir", 96 to "Badai petir, es", 99 to "Badai petir, es",
    )

    fun label(c: Int): String = labels[c] ?: "–"

    /** "2026-11-07T05:41" -> "05:41"; tidak valid -> "—". */
    fun clock(t: String?): String {
        if (t.isNullOrBlank()) return "—"
        val i = t.indexOf('T')
        return if (i in 0..(t.length - 6)) t.substring(i + 1, i + 6) else "—"
    }

    fun minutesOfDay(t: String?): Int? {
        val c = clock(t)
        if (c == "—") return null
        val h = c.substring(0, 2).toIntOrNull() ?: return null
        val m = c.substring(3, 5).toIntOrNull() ?: return null
        return h * 60 + m
    }

    /** Apakah jam [time] jatuh sebelum terbit atau sesudah terbenam (untuk ikon bulan). */
    fun isNight(time: String?, sunrise: String?, sunset: String?): Boolean {
        val t = minutesOfDay(time) ?: return false
        val sr = minutesOfDay(sunrise) ?: 6 * 60
        val ss = minutesOfDay(sunset) ?: 18 * 60
        return t < sr || t >= ss
    }

    private val MOON_KNOWN_MS = LocalDateTime.of(2000, 1, 6, 18, 14).toInstant(ZoneOffset.UTC).toEpochMilli()
    private val MOON_ICONS = listOf("🌑", "🌒", "🌓", "🌔", "🌕", "🌖", "🌗", "🌘")
    private val MOON_NAMES = listOf("Bulan baru", "Sabit muda", "Perbani awal", "Cembung membesar", "Purnama", "Cembung mengecil", "Perbani akhir", "Sabit tua")

    /** Fase bulan (ikon, nama), rumus sama dengan wxNowMoon() di web. */
    fun moon(epochMs: Long): Pair<String, String> {
        val syn = 29.530588853
        val age = (((epochMs - MOON_KNOWN_MS) / 86_400_000.0) % syn + syn) % syn
        val phase = age / syn
        val ix = floor((phase * 8 + .5) % 8).toInt().coerceIn(0, 7)
        return MOON_ICONS[ix] to MOON_NAMES[ix]
    }

    /**
     * Susun snapshot dari respons forecast (+ air quality, boleh null).
     * Prakiraan per jam dimulai dari jam sekarang (maks 24 entri), harian maks 7 hari (wxFcHours/wxFcDays di web).
     */
    fun parse(forecast: JSONObject, air: JSONObject?, lat: Double, lon: Double, place: String, nowMs: Long): WxSnapshot {
        val cur = forecast.optJSONObject("current") ?: throw IllegalStateException("Data cuaca kosong")
        if (!cur.has("temperature_2m")) throw IllegalStateException("Data cuaca kosong")
        val curTime = cur.optString("time", "")

        val hours = ArrayList<WxHour>()
        forecast.optJSONObject("hourly")?.let { h ->
            val t = h.optJSONArray("time"); val tp = h.optJSONArray("temperature_2m"); val cd = h.optJSONArray("weather_code")
            val pp = h.optJSONArray("precipitation_probability")
            if (t != null && tp != null && cd != null) {
                val from = curTime.take(13)
                var i = 0
                if (from.isNotEmpty()) while (i < t.length() && t.optString(i).take(13) < from) i++
                while (i < t.length() && hours.size < 24) {
                    val temp = tp.optDouble(i, Double.NaN)
                    if (temp.isFinite()) {
                        val pop = if (pp != null && !pp.isNull(i)) pp.optInt(i, -1).takeIf { it >= 0 } else null
                        hours += WxHour(t.optString(i), temp, cd.optInt(i, -1), pop)
                    }
                    i++
                }
            }
        }

        val days = ArrayList<WxDay>()
        var sunrise: String? = null; var sunset: String? = null
        forecast.optJSONObject("daily")?.let { d ->
            val t = d.optJSONArray("time"); val hi = d.optJSONArray("temperature_2m_max"); val lo = d.optJSONArray("temperature_2m_min")
            val cd = d.optJSONArray("weather_code"); val pp = d.optJSONArray("precipitation_probability_max")
            sunrise = d.optJSONArray("sunrise")?.optString(0)?.takeIf { it.isNotBlank() }
            sunset = d.optJSONArray("sunset")?.optString(0)?.takeIf { it.isNotBlank() }
            if (t != null && hi != null && lo != null && cd != null) {
                var i = 0
                while (i < t.length() && days.size < 7) {
                    val h = hi.optDouble(i, Double.NaN); val l = lo.optDouble(i, Double.NaN)
                    if (h.isFinite() && l.isFinite()) {
                        val pop = if (pp != null && !pp.isNull(i)) pp.optInt(i, -1).takeIf { it >= 0 } else null
                        days += WxDay(t.optString(i), h, l, cd.optInt(i, -1), pop)
                    }
                    i++
                }
            }
        }

        val aq = air
        val usAqi = if (aq != null && aq.has("us_aqi") && !aq.isNull("us_aqi")) aq.optDouble("us_aqi", Double.NaN).takeIf { it.isFinite() }?.let { Math.round(it).toInt() } else null
        val pm25 = if (aq != null && aq.has("pm2_5") && !aq.isNull("pm2_5")) aq.optDouble("pm2_5", Double.NaN).takeIf { it.isFinite() } else null

        return WxSnapshot(
            lat = lat, lon = lon, place = place,
            temp = cur.optDouble("temperature_2m", 0.0),
            feels = cur.optDouble("apparent_temperature", cur.optDouble("temperature_2m", 0.0)),
            code = cur.optInt("weather_code", -1),
            humidity = if (cur.has("relative_humidity_2m") && !cur.isNull("relative_humidity_2m")) cur.optInt("relative_humidity_2m") else null,
            wind = if (cur.has("wind_speed_10m") && !cur.isNull("wind_speed_10m")) cur.optDouble("wind_speed_10m") else null,
            usAqi = usAqi, pm25 = pm25,
            sunrise = sunrise, sunset = sunset, currentTime = curTime.takeIf { it.isNotBlank() },
            hours = hours, days = days, fetchedAtMs = nowMs,
        )
    }
}
