package com.endurancevault.app.domain

import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.sqrt

/** Satu repetisi: jarak [d] km, waktu [tm] menit, pace [p] menit/km, HR rata-rata [h], indeks item awal-akhir [from]..[to]. */
class IvRep(val d: Double, val tm: Double, val p: Double, val h: Int?, val from: Int, val to: Int)

/** Statistik konsistensi dan fade (padanan `ivStats`). Pace menit/km, selisih detik/km. */
class IvStats(
    val n: Int, val avg: Double, val best: Double, val worst: Double, val bestI: Int, val worstI: Int,
    val spread: Double, val sd: Double, val cv: Double, val fade: Double, val first: Double, val last: Double,
    val firstLast: Double, val half: Double?, val hrFirst: Int?, val hrLast: Int?,
)

/** Hasil deteksi: [src] = tipe | lap | kurva, ditambah [reps] dan [stats]. */
class IvResult(val src: String, val reps: List<IvRep>, val stats: IvStats)

/**
 * Deteksi repetisi interval otomatis (port `08b-analisis-interval.js`, mode auto). Sumber, berurutan:
 * 1) segmen berlabel Repetisi (padanan tipe Interval 'w' di web);
 * 2) lap tanpa label bawaan: dipisah jadi kelompok cepat dan lambat lalu dicari pola cepat-lambat-cepat;
 * 3) kurva pace bila aktivitas tidak punya lap yang berguna (perkiraan kasar).
 * Hanya membaca data aktivitas. Mode "Lap FIT" dan "Manual" di web belum ada di native.
 *
 * Pemetaan tipe: web melewati lap bertipe warm-up, cool-down, dan tempo; native melewati Stride dan Progresif.
 */
object IntervalAnalysis {
    const val MIN_REPS = 3

    private class Otsu(val sc: Double, val i: Int, val mf: Double, val ms: Double, val maxF: Double, val minS: Double)
    private class Item(val d: Double, val tm: Double, val h: Double?, val p: Double, val idx: Int, var fast: Boolean = false)

    /** Pemisah dua kelompok (Otsu 1D) pada pace: pace kecil = cepat. Null bila data kurang dari 4. */
    private fun split(vals: List<Double>): Otsu? {
        val s = vals.sorted(); val n = s.size
        if (n < 4) return null
        var best: Otsu? = null
        for (i in 1 until n) {
            if (s[i] - s[i - 1] < 1e-9) continue
            var m1 = 0.0; var m2 = 0.0
            for (j in 0 until i) m1 += s[j]
            m1 /= i
            for (j in i until n) m2 += s[j]
            m2 /= (n - i)
            val sc = i.toDouble() * (n - i) * (m2 - m1) * (m2 - m1)
            if (best == null || sc > best.sc) best = Otsu(sc, i, m1, m2, s[i - 1], s[i])
        }
        return best
    }

    /** Gabungkan item cepat yang berurutan menjadi satu repetisi. */
    private fun runs(items: List<Item>): List<IvRep> {
        class Cur(var d: Double = 0.0, var tm: Double = 0.0, var hw: Double = 0.0, var ht: Double = 0.0, val from: Int, var to: Int = 0)
        val out = ArrayList<Cur>(); var cur: Cur? = null
        items.forEachIndexed { i, x ->
            if (x.fast) {
                if (cur == null) { cur = Cur(from = i); out.add(cur!!) }
                val c = cur!!
                c.d += x.d; c.tm += x.tm; c.to = i
                if ((x.h ?: 0.0) > 0) { c.hw += x.h!! * x.tm; c.ht += x.tm }
            } else cur = null
        }
        return out.map { r -> IvRep(r.d, r.tm, r.tm / r.d, if (r.ht > 0) Js.round(r.hw / r.ht).toInt() else null, r.from, r.to) }
    }

    /** Buang repetisi yang jaraknya jauh beda dari jarak umum (median), minimal tersisa [MIN_REPS]. */
    private fun similar(reps: List<IvRep>, tol: Double): List<IvRep>? {
        if (reps.isEmpty()) return null
        val ds = reps.map { it.d }.sorted(); val n = ds.size
        val md = if (n % 2 == 1) ds[(n - 1) / 2] else (ds[n / 2 - 1] + ds[n / 2]) / 2
        val ok = reps.filter { abs(it.d - md) <= md * tol }
        return if (ok.size >= MIN_REPS) ok else null
    }

    private fun fromTyped(sg: List<Segment>): List<IvRep>? {
        val reps = ArrayList<IvRep>()
        sg.forEachIndexed { i, s ->
            if (SegKind.normalize(s.type) == SegKind.REPETITION && s.d > 0 && s.min > 0)
                reps.add(IvRep(s.d, s.min, s.min / s.d, s.hr?.takeIf { it > 0 }, i, i))
        }
        return if (reps.size >= 2) reps else null
    }

    /** Satu percobaan: gabungkan lap cepat jadi repetisi, cek kemiripan jarak dan adanya jeda di antaranya. */
    private fun lapRuns(items: List<Item>): List<IvRep>? {
        val r = similar(runs(items), .35) ?: return null
        if (r.size < MIN_REPS) return null
        var gaps = 0
        for (i in 1 until r.size) if (r[i].from > r[i - 1].to + 1) gaps++
        if (gaps < r.size - 1) return null
        return r
    }

    private fun fromLaps(sg: List<Segment>): List<IvRep>? {
        val items = ArrayList<Item>()
        sg.forEachIndexed { i, s ->
            val k = SegKind.normalize(s.type)
            if (k == SegKind.STRIDE || k == SegKind.PROGRESSIVE) return@forEachIndexed
            if (!(s.d >= 0.1 && s.min > 0)) return@forEachIndexed
            items.add(Item(s.d, s.min, s.hr?.toDouble(), s.min / s.d, i))
        }
        if (items.size < 5) return null
        val o = split(items.map { it.p })
        // pace cepat dan lambat harus terpisah jelas: lari steady berbukit tidak terdeteksi
        if (o == null || o.ms - o.mf < 0.4 || o.minS - o.maxF < 0.15) return null
        val thr = (o.maxF + o.minS) / 2
        items.forEach { it.fast = it.p <= thr }
        val fastIt = items.filter { it.fast }
        val o2 = if (fastIt.size >= 4) split(fastIt.map { it.p }) else null
        var found: List<IvRep>? = null
        // warm-up dan cool-down yang menempel di ujung: bila lap cepat terbagi dua kelompok jelas, lap kelompok lambat di ujung bukan repetisi
        if (o2 != null && o2.ms - o2.mf >= .5 && o2.minS - o2.maxF >= .3) {
            val thr2 = (o2.maxF + o2.minS) / 2
            val alt = items.map { Item(it.d, it.tm, it.h, it.p, it.idx, it.fast) }
            for (i in alt.indices) { if (alt[i].fast && alt[i].p <= thr2) break; alt[i].fast = false }
            for (i in alt.indices.reversed()) { if (alt[i].fast && alt[i].p <= thr2) break; alt[i].fast = false }
            found = lapRuns(alt)
        }
        if (found == null) found = lapRuns(items)
        val r = found ?: return null
        return r.map { IvRep(it.d, it.tm, it.p, it.h, items[it.from].idx, items[it.to].idx) }
    }

    private fun hrAt(hs: List<Pair<Double, Double>>, k: Double): Double? {
        if (hs.size < 2) return null
        var best: Double? = null; var bd = 1e9
        for (q in hs) { val dd = abs(q.first - k); if (dd < bd) { bd = dd; best = q.second } }
        return best?.takeIf { it > 0 }
    }

    private fun fromCurve(d: ActDetail): List<IvRep>? {
        val ps = d.paceSeries
        if (ps.size < 30) return null
        val bw = ps[1].first - ps[0].first
        if (!(bw > 0)) return null
        val o = split(ps.map { it.second })
        if (o == null || o.ms - o.mf < 0.6) return null
        val thr = (o.maxF + o.minS) / 2
        val items = ps.mapIndexed { i, x -> Item(bw, bw * x.second, hrAt(d.hrSeries, x.first), x.second, i, x.second <= thr) }
        // bin cepat tunggal di antara bin lambat dianggap derau
        for (i in 1 until items.size - 1) if (items[i].fast && !items[i - 1].fast && !items[i + 1].fast) items[i].fast = false
        val r = similar(runs(items).filter { it.to - it.from >= 1 }, .4) ?: return null
        return if (r.size >= MIN_REPS) r else null
    }

    /** Deteksi repetisi untuk satu aktivitas; null bila sepeda atau tidak ada pola. */
    fun detect(d: ActDetail?): Pair<String, List<IvRep>>? {
        if (d == null || d.bike) return null
        val sg = d.segments
        if (sg.size > 1) {
            fromTyped(sg)?.let { return "tipe" to it }
            fromLaps(sg)?.let { return "lap" to it }
            return null
        }
        fromCurve(d)?.let { return "kurva" to it }
        return null
    }

    /** Statistik konsistensi dan fade; null bila kurang dari dua repetisi. */
    fun stats(reps: List<IvRep>): IvStats? {
        val n = reps.size
        if (n < 2) return null
        var td = 0.0; var tt = 0.0
        reps.forEach { td += it.d; tt += it.tm }
        val ps = reps.map { it.p }
        val avg = tt / td; val mn = ps.min(); val mx = ps.max()
        val mean = ps.sum() / n
        val v = ps.sumOf { (it - mean) * (it - mean) }
        val sd = sqrt(v / n); val cv = if (mean > 0) sd / mean * 100 else 0.0
        // tren linear pace terhadap nomor repetisi: fade = kemiringan x (n-1), dalam detik/km
        var sx = 0.0; var sy = 0.0; var sxx = 0.0; var sxy = 0.0
        for (i in 0 until n) { sx += i; sy += ps[i]; sxx += i.toDouble() * i; sxy += i * ps[i] }
        val den = n * sxx - sx * sx
        val slope = if (den != 0.0) (n * sxy - sx * sy) / den else 0.0
        val fade = slope * (n - 1) * 60
        val hf = reps.firstOrNull { (it.h ?: 0) > 0 }?.h
        val hl = reps.lastOrNull { (it.h ?: 0) > 0 }?.h
        val h2 = if (n >= 4) floor(n / 2.0).toInt() else 0
        var half: Double? = null
        if (h2 > 0) {
            var a1 = 0.0; var a2 = 0.0
            for (i in 0 until h2) a1 += ps[i]
            for (i in n - h2 until n) a2 += ps[i]
            half = (a2 / h2 - a1 / h2) * 60
        }
        return IvStats(
            n, avg, mn, mx, ps.indexOf(mn), ps.indexOf(mx), (mx - mn) * 60, sd * 60, cv, fade, ps[0], ps[n - 1],
            (ps[n - 1] - ps[0]) * 60, half, hf, hl,
        )
    }

    /** Deteksi + statistik; null bila tidak ada pola dengan minimal dua repetisi (aturan `stkModel` di web). */
    fun analyze(d: ActDetail?): IvResult? {
        val (src, reps) = detect(d) ?: return null
        if (reps.size < 2) return null
        return IvResult(src, reps, stats(reps) ?: return null)
    }

}
