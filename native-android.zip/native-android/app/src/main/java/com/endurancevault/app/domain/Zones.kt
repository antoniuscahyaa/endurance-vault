package com.endurancevault.app.domain

/** Zona HR (padanan zcut / zoneCutsFor / zoneOf / zoneSecs di web). */
class ZoneCuts(val mode: String, val lo: List<Int>, val maxHr: Int, val lthr: Int? = null, val rest: Int? = null) {
    /** Teks rentang bpm tiap zona. */
    fun bands(): List<String> = (0 until 5).map { i ->
        when {
            i == 4 -> "≥ ${lo[4]}"
            i == 0 && mode == "lthr" -> "< ${lo[1]}"
            else -> "${lo[i]}–${lo[i + 1] - 1}"
        }
    }
}

object Zones {
    private val ZLD = listOf(85.0, 90.0, 95.0, 100.0)
    private val ZRD = listOf(50.0, 60.0, 70.0, 80.0, 90.0)

    /** Nilai harus naik ketat, 0 < x <= top; bila tidak, kembali ke bawaan. */
    internal fun zcut(v: List<Double>, d: List<Double>, top: Double): List<Double> {
        var ok = v.all { it.isFinite() && it > 0 && it <= top }
        for (i in 1 until v.size) if (ok && !(v[i] > v[i - 1])) ok = false
        return if (ok) v else d
    }

    /** @param restDefault HR istirahat bila tidak diisi (web: median catatan harian 14 hari, bawaan 55). */
    fun cuts(s: PlanSettings, restDefault: Int = 55): ZoneCuts {
        val mx = hrMaxEst(s)
        if (s.zm == "hrr") {
            val rest = s.rhr?.takeIf { it >= 30 }?.let { Js.roundI(it) } ?: restDefault
            val r = zcut(s.zr, ZRD, 100.0)
            return ZoneCuts("hrr", r.map { Js.roundI(rest + it / 100 * (mx - rest)) }, mx, rest = rest)
        }
        val b = thrBand(s) ?: listOf(164, 172)
        val lt = s.lthr?.takeIf { it >= 100 }?.let { Js.roundI(it) } ?: Js.roundI((b[0] + b[1]) / 2.0)
        val l = zcut(s.zl, ZLD, 150.0)
        return ZoneCuts("lthr", listOf(0) + l.map { Js.roundI(it * lt / 100) }, mx, lthr = lt)
    }

    fun zoneOf(bpm: Int, lo: List<Int>): Int {
        for (i in 4 downTo 1) if (bpm >= lo[i]) return i
        return 0
    }

    /** Detik di tiap zona dari histogram HR {bpm: detik}. */
    fun secs(hist: Map<Int, Double>, zc: ZoneCuts): DoubleArray {
        val r = DoubleArray(5)
        hist.forEach { (bpm, sec) -> r[zoneOf(bpm, zc.lo)] += sec }
        return r
    }
}
