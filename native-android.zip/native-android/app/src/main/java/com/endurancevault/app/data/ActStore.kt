package com.endurancevault.app.data

import com.endurancevault.app.data.JsonUtil.dbl
import com.endurancevault.app.data.JsonUtil.int
import com.endurancevault.app.data.JsonUtil.text
import com.endurancevault.app.domain.ActDetail
import com.endurancevault.app.domain.Segment
import com.endurancevault.app.domain.Split
import com.google.gson.stream.JsonReader
import com.google.gson.stream.JsonWriter
import java.io.File
import java.io.InputStream
import java.io.InputStreamReader

/** Penyimpanan detail aktivitas: satu berkas JSON per aktivitas (format objek aktivitas versi web). */
class ActStore(val dir: File) {
    init { dir.mkdirs() }

    fun file(name: String) = File(dir, name)

    fun write(name: String, act: Map<String, Any?>) {
        JsonWriter(file(name).writer(Charsets.UTF_8).buffered()).use { JsonUtil.writeAny(it, act) }
    }

    fun read(name: String): ActDetail? {
        val f = file(name)
        if (!f.exists()) return null
        return runCatching { f.inputStream().use { parse(it) } }.getOrNull()
    }

    fun delete(name: String) { file(name).delete() }

    /** Hapus semua detail hasil impor cadangan (sebelum cadangan baru diekstrak). */
    fun clearBackupFiles() { dir.listFiles { x -> x.name.startsWith("b_") }?.forEach { it.delete() } }

    companion object {
        fun backupFileName(key: String) = "b_" + key.replace('~', '_') + ".json"
        fun importFileName(id: Long) = "f_$id.json"

        fun parse(input: InputStream): ActDetail {
            val r = JsonReader(InputStreamReader(input, Charsets.UTF_8))
            val m = JsonUtil.asMap(JsonUtil.readAny(r)) ?: throw IllegalArgumentException("bukan objek aktivitas")
            return fromMap(m)
        }

        private fun pairs(v: Any?): List<Pair<Double, Double>> =
            JsonUtil.asList(v).orEmpty().mapNotNull { e ->
                val l = JsonUtil.asList(e)
                val a = (l?.getOrNull(0) as? Double); val b = (l?.getOrNull(1) as? Double)
                if (a != null && b != null) a to b else null
            }

        fun fromMap(m: Map<String, Any?>): ActDetail {
            val splits = JsonUtil.asList(m["sp"]).orEmpty().mapNotNull { e ->
                val s = JsonUtil.asMap(e) ?: return@mapNotNull null
                Split(
                    s.dbl("k") ?: return@mapNotNull null, s.dbl("p") ?: return@mapNotNull null, s.int("h"),
                    s.int("g") ?: 0, s.int("l") ?: 0, s.int("c"), s.dbl("gp"), s.dbl("part") != null,
                )
            }
            val segs = JsonUtil.asList(m["sg"]).orEmpty().mapNotNull { e ->
                val s = JsonUtil.asMap(e) ?: return@mapNotNull null
                Segment(
                    s.dbl("k") ?: 0.0, s.dbl("d") ?: return@mapNotNull null, s.dbl("tm") ?: 0.0, s.dbl("p") ?: return@mapNotNull null,
                    s.int("h"), s.int("g") ?: 0, s.int("l") ?: 0, s.int("c"), s.text("n"), s.text("ty").ifEmpty { null },
                )
            }
            val route = JsonUtil.asList(m["rt"]).orEmpty().mapNotNull { e ->
                val l = JsonUtil.asList(e)
                val x = (l?.getOrNull(0) as? Double)?.toInt(); val y = (l?.getOrNull(1) as? Double)?.toInt()
                if (x != null && y != null) x to y else null
            }
            val hist = LinkedHashMap<Int, Double>()
            JsonUtil.asMap(m["h"])?.forEach { (k, v) -> val b = k.toIntOrNull(); val s = v as? Double; if (b != null && s != null) hist[b] = s }
            return ActDetail(
                date = m.text("date"), startTime = m.text("st"), name = m.text("nm"), bike = m["bike"] == true,
                kind = m.text("xk").ifEmpty { null },
                km = m.dbl("km") ?: 0.0, movingMin = m.dbl("min") ?: 0.0, elapsedMin = m.dbl("el") ?: 0.0,
                gain = m.int("gain"), loss = m.int("loss"), hr = m.int("hr"), hrMax = m.int("hrMax"), cad = m.int("cad"),
                gapPace = m.dbl("gap"), splits = splits, segments = segs,
                route = route, routeW = m.int("rw") ?: 0, routeH = m.int("rh") ?: 0,
                profile = pairs(m["pf"]), paceSeries = pairs(m["ps"]), hrSeries = pairs(m["hs"]), cadSeries = pairs(m["cs"]),
                hrHist = hist,
            )
        }
    }
}
