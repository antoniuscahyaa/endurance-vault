package com.endurancevault.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.ui.ImportUi
import com.endurancevault.app.ui.UiState
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.TextButton
import java.time.LocalDate

private val TYPES = listOf(
    "5k" to "5K", "10k" to "10K", "hm" to "Half marathon", "fm" to "Marathon",
    "ultra" to "Trail", "ultrar" to "Ultra road", "pb" to "Performance Build", "none" to "No Race",
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileScreen(
    state: UiState,
    onSave: (PlanSettings) -> Unit,
    importUi: ImportUi,
    onImport: (Uri) -> Unit,
    onConfirmImport: () -> Unit,
    onDismissImport: () -> Unit,
) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) onImport(uri) }
    val s = state.settings
    var rtype by remember(s) { mutableStateOf(s.rtype) }
    var name by remember(s) { mutableStateOf(s.name) }
    var start by remember(s) { mutableStateOf(s.start.toString()) }
    var race by remember(s) { mutableStateOf(s.race?.toString() ?: "") }
    var raceKm by remember(s) { mutableStateOf(s.raceKm?.let { fmtKmUi(it) } ?: "") }
    var raceGain by remember(s) { mutableStateOf(s.raceGain?.let { fmtKmUi(it) } ?: "") }
    var goal by remember(s) { mutableStateOf(s.goalT) }
    var base by remember(s) { mutableStateOf(fmtKmUi(s.base)) }
    var peak by remember(s) { mutableStateOf(fmtKmUi(s.peak)) }
    var days by remember(s) { mutableStateOf(s.days) }
    var longDay by remember(s) { mutableStateOf(s.longDay.toString()) }
    var hr by remember(s) { mutableStateOf(s.hr.toString()) }
    var thr by remember(s) { mutableStateOf(s.thr) }
    var pace by remember(s) { mutableStateOf(s.pace) }
    var err by remember { mutableStateOf<String?>(null) }
    val num = KeyboardOptions(keyboardType = KeyboardType.Number)
    val full = Modifier.fillMaxWidth()

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("Profil dan rencana", style = MaterialTheme.typography.headlineMedium)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TYPES.forEach { (k, label) -> FilterChip(selected = rtype == k, onClick = { rtype = k }, label = { Text(label) }) }
        }
        OutlinedTextField(name, { name = it }, label = { Text("Nama lomba") }, singleLine = true, modifier = full)
        OutlinedTextField(start, { start = it }, label = { Text("Mulai (yyyy-MM-dd)") }, singleLine = true, modifier = full)
        if (rtype != "pb" && rtype != "none") {
            OutlinedTextField(race, { race = it }, label = { Text("Tanggal lomba (yyyy-MM-dd)") }, singleLine = true, modifier = full)
            OutlinedTextField(goal, { goal = it }, label = { Text("Target waktu (h:mm:ss, opsional)") }, singleLine = true, modifier = full)
        }
        if (rtype == "ultra" || rtype == "ultrar") {
            OutlinedTextField(raceKm, { raceKm = it }, label = { Text("Jarak lomba (km)") }, keyboardOptions = num, singleLine = true, modifier = full)
            OutlinedTextField(raceGain, { raceGain = it }, label = { Text("Elevasi lomba D+ (m)") }, keyboardOptions = num, singleLine = true, modifier = full)
        }
        OutlinedTextField(base, { base = it }, label = { Text("Km mingguan awal") }, keyboardOptions = num, singleLine = true, modifier = full)
        OutlinedTextField(peak, { peak = it }, label = { Text("Km mingguan puncak") }, keyboardOptions = num, singleLine = true, modifier = full)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = days == 5, onClick = { days = 5 }, label = { Text("5 hari lari") })
            FilterChip(selected = days == 6, onClick = { days = 6 }, label = { Text("6 hari lari") })
        }
        OutlinedTextField(longDay, { longDay = it }, label = { Text("Hari long run (0=Sen … 6=Min)") }, keyboardOptions = num, singleLine = true, modifier = full)
        OutlinedTextField(hr, { hr = it }, label = { Text("Batas HR easy") }, keyboardOptions = num, singleLine = true, modifier = full)
        OutlinedTextField(thr, { thr = it }, label = { Text("Rentang HR threshold (mis. 164–172)") }, singleLine = true, modifier = full)
        OutlinedTextField(pace, { pace = it }, label = { Text("Pace easy (m:ss)") }, singleLine = true, modifier = full)
        err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(modifier = full, onClick = {
            fun d(t: String) = runCatching { LocalDate.parse(t) }.getOrNull()
            fun n(t: String) = t.replace(',', '.').toDoubleOrNull()
            val st = d(start)
            val rc = if (race.isBlank()) null else d(race)
            val b = n(base); val p = n(peak); val h = hr.toIntOrNull(); val ld = longDay.toIntOrNull()
            if (st == null || (race.isNotBlank() && rc == null) || b == null || p == null || h == null || ld == null) {
                err = "Periksa format tanggal dan angka."
            } else {
                err = null
                onSave(
                    s.copy(
                        name = name.trim(), rtype = rtype, start = st, race = if (rtype == "pb" || rtype == "none") null else rc,
                        raceKm = n(raceKm), raceGain = n(raceGain), goalT = goal.trim(),
                        base = b, peak = p, days = days, longDay = ld, hr = h, thr = thr.trim(), pace = pace.trim(),
                    ),
                )
            }
        }) { Text("Simpan dan hitung ulang rencana") }

        Text("Cadangan", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 16.dp))
        Text(
            "Impor berkas cadangan dari versi web (.json) untuk memulihkan pengaturan rencana dan catatan lari.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        OutlinedButton(
            modifier = full,
            enabled = importUi !is ImportUi.Working,
            onClick = { picker.launch(arrayOf("application/json", "text/plain", "application/octet-stream")) },
        ) { Text(if (importUi is ImportUi.Working) "Membaca berkas…" else "Impor cadangan web") }
        when (importUi) {
            is ImportUi.Done -> Text(importUi.message, color = MaterialTheme.colorScheme.primary)
            is ImportUi.Failed -> Text(importUi.message, color = MaterialTheme.colorScheme.error)
            else -> {}
        }
    }

    if (importUi is ImportUi.Confirm) {
        val b = importUi.backup
        AlertDialog(
            onDismissRequest = onDismissImport,
            title = { Text("Pulihkan cadangan?") },
            text = {
                Text(
                    "Ditemukan ${b.activities.size} catatan lari, ${b.doneDays} hari selesai, dan pengaturan rencana" +
                        (if (b.settings.name.isNotBlank()) " \"${b.settings.name}\"" else "") + ".\n\n" +
                        "Pengaturan rencana saat ini akan ditimpa, begitu juga catatan hasil impor sebelumnya. " +
                        "Catatan yang Anda buat di aplikasi ini tidak diubah." +
                        (if (b.detailCount > 0) "\n\n${b.detailCount} detail aktivitas (rute GPS) ikut tersimpan di berkas dan akan dibaca pada tahap berikutnya." else ""),
                )
            },
            confirmButton = { TextButton(onClick = onConfirmImport) { Text("Pulihkan") } },
            dismissButton = { TextButton(onClick = onDismissImport) { Text("Batal") } },
        )
    }
}
