package com.endurancevault.app.data

import com.google.gson.stream.JsonReader
import com.google.gson.stream.JsonToken
import com.google.gson.stream.JsonWriter
import kotlin.math.floor

/** Pembaca/penulis JSON generik (streaming, Gson) dan pembantu tipe longgar seperti data dari versi web. */
internal object JsonUtil {
    fun readAny(r: JsonReader): Any? = when (r.peek()) {
        JsonToken.BEGIN_OBJECT -> {
            val m = LinkedHashMap<String, Any?>()
            r.beginObject()
            while (r.hasNext()) { val k = r.nextName(); m[k] = readAny(r) }
            r.endObject(); m
        }
        JsonToken.BEGIN_ARRAY -> {
            val l = ArrayList<Any?>()
            r.beginArray()
            while (r.hasNext()) l.add(readAny(r))
            r.endArray(); l
        }
        JsonToken.STRING -> r.nextString()
        JsonToken.NUMBER -> r.nextDouble()
        JsonToken.BOOLEAN -> r.nextBoolean()
        JsonToken.NULL -> { r.nextNull(); null }
        else -> { r.skipValue(); null }
    }

    @Suppress("UNCHECKED_CAST")
    fun asMap(v: Any?): Map<String, Any?>? = v as? Map<String, Any?>

    @Suppress("UNCHECKED_CAST")
    fun asList(v: Any?): List<Any?>? = v as? List<Any?>

    /** Salin satu nilai JSON dari pembaca ke penulis tanpa memuatnya ke memori. */
    fun copyValue(r: JsonReader, w: JsonWriter) {
        when (r.peek()) {
            JsonToken.BEGIN_OBJECT -> {
                r.beginObject(); w.beginObject()
                while (r.hasNext()) { w.name(r.nextName()); copyValue(r, w) }
                r.endObject(); w.endObject()
            }
            JsonToken.BEGIN_ARRAY -> {
                r.beginArray(); w.beginArray()
                while (r.hasNext()) copyValue(r, w)
                r.endArray(); w.endArray()
            }
            JsonToken.STRING -> w.value(r.nextString())
            JsonToken.NUMBER -> w.value(r.nextDouble().let { d -> if (d == floor(d) && kotlin.math.abs(d) < 1e15) d.toLong() as Number else d as Number })
            JsonToken.BOOLEAN -> w.value(r.nextBoolean())
            JsonToken.NULL -> { r.nextNull(); w.nullValue() }
            else -> r.skipValue()
        }
    }

    /** Tulis Map/List/angka/teks apa adanya (untuk objek aktivitas hasil impor berkas). */
    fun writeAny(w: JsonWriter, v: Any?) {
        when (v) {
            null -> w.nullValue()
            is Map<*, *> -> { w.beginObject(); v.forEach { (k, x) -> if (x != null) { w.name(k.toString()); writeAny(w, x) } }; w.endObject() }
            is List<*> -> { w.beginArray(); v.forEach { writeAny(w, it) }; w.endArray() }
            is String -> w.value(v)
            is Boolean -> w.value(v)
            is Int -> w.value(v.toLong())
            is Long -> w.value(v)
            is Double -> if (v.isNaN() || v.isInfinite()) w.nullValue() else if (v == floor(v) && kotlin.math.abs(v) < 1e15) w.value(v.toLong()) else w.value(v)
            is Number -> w.value(v)
            else -> w.value(v.toString())
        }
    }

    fun Map<String, Any?>.dbl(k: String): Double? = when (val v = this[k]) {
        is Double -> v
        is Number -> v.toDouble()
        is String -> v.trim().replace(',', '.').toDoubleOrNull()
        else -> null
    }
    fun Map<String, Any?>.int(k: String): Int? = dbl(k)?.let { Math.round(it).toInt() }
    fun Map<String, Any?>.text(k: String): String = when (val v = this[k]) {
        null -> ""
        is Double -> if (v == floor(v)) v.toLong().toString() else v.toString()
        else -> v.toString()
    }
}
