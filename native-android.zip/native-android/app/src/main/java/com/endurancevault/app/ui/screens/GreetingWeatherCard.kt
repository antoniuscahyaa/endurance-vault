package com.endurancevault.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import com.endurancevault.app.ui.theme.cardTint
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.endurancevault.app.R
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.data.DailyEntity
import com.endurancevault.app.domain.GreetAtmosphere
import com.endurancevault.app.domain.GreetInput
import com.endurancevault.app.domain.GreetTime
import com.endurancevault.app.domain.ReadinessMetric
import com.endurancevault.app.domain.Wx
import com.endurancevault.app.domain.WxKind
import com.endurancevault.app.domain.WxScene
import com.endurancevault.app.domain.WxSnapshot
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.time.temporal.ChronoUnit
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Kartu sapaan + cuaca di tab Hari ini. Port dari #pfGreetSec di web (skin default EV: gunmetal + oranye):
 * sapaan waktu, suhu besar, kondisi + lokasi, tombol Perbarui, kutipan, lalu "Detail cuaca"
 * (AQI, terbit/terbenam, fase bulan, prakiraan 24 jam / 7 hari).
 */
private val EvLight: Color @Composable get() = MaterialTheme.colorScheme.onSurface

private fun wxIcon(code: Int, night: Boolean): Int? = when (Wx.kind(code)) {
    WxKind.CLEAR -> if (night) R.drawable.ic_wx_moon else R.drawable.ic_wx_clear
    WxKind.PARTLY -> R.drawable.ic_wx_partly
    WxKind.CLOUD -> R.drawable.ic_wx_cloud
    WxKind.FOG -> R.drawable.ic_wx_fog
    WxKind.RAIN -> R.drawable.ic_wx_rain
    WxKind.STORM -> R.drawable.ic_wx_storm
    WxKind.SNOW -> R.drawable.ic_wx_snow
    WxKind.NONE -> null
}

@Composable
private fun WxGlyph(code: Int, night: Boolean, modifier: Modifier = Modifier.size(18.dp)) {
    val res = wxIcon(code, night)
    if (res != null) Icon(painterResource(res), contentDescription = Wx.label(code), tint = EvLight, modifier = modifier)
    else Text("–", color = EvLight.copy(alpha = .8f), fontSize = 14.sp)
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
@Composable
internal fun GreetingWeatherCard(
    greeting: String,
    quote: String,
    time: GreetTime,
    atmosphere: GreetAtmosphere,
    weather: WxSnapshot?,
    placeLabel: String,
    busy: Boolean,
    error: String?,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("weather_loc", android.content.Context.MODE_PRIVATE) }
    var detailOpen by rememberSaveable { mutableStateOf(false) }
    var weekMode by remember { mutableStateOf(prefs.getString("fcMode", "hour") == "week") }
    var peek by remember { mutableStateOf(false) }
    LaunchedEffect(peek) { if (peek) { delay(4000); peek = false } }

    val shape = RoundedCornerShape(22.dp)

    Box(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(MaterialTheme.colorScheme.cardTint),
    ) {
        Column(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 14.dp)) {
            Text(
                greeting, color = EvLight.copy(alpha = .9f), fontSize = 12.sp, fontWeight = FontWeight.Bold,
                letterSpacing = 1.9.sp, modifier = Modifier.padding(end = 44.dp),
            )
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth().padding(end = 44.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    if (weather != null) "${weather.temp.roundToInt()}°C" else "—°",
                    color = EvLight, fontSize = 42.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-1.5).sp, maxLines = 1,
                )
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        if (weather != null) "${Wx.label(weather.code)} · Terasa ${weather.feels.roundToInt()}°C"
                        else if (busy) "Memuat cuaca…" else "Cuaca belum tersedia",
                        color = EvLight, fontSize = 13.sp, lineHeight = 17.sp,
                    )
                    Text(
                        if (weather != null) placeLabel.ifBlank { "Lokasi saya" } else "Cuaca saat ini",
                        color = EvLight.copy(alpha = .8f), fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                    )
                }
            }
            if (peek || error != null) {
                val stamp = weather?.let { Instant.ofEpochMilli(it.fetchedAtMs).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("HH:mm")) }
                Text(
                    if (error != null) "Data belum bisa diambil. Periksa koneksi dan coba lagi." + (stamp?.let { " Terakhir berhasil $it." } ?: "")
                    else if (stamp != null) "Sumber: Open-Meteo · diperbarui $stamp."
                    else "Cuaca belum dimuat.",
                    color = EvLight.copy(alpha = .75f), fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp),
                )
            }
            HorizontalDivider(Modifier.padding(top = 12.dp), color = EvLight.copy(alpha = .15f))
            Text(quote, color = EvLight, fontSize = 15.2.sp, lineHeight = 22.sp, modifier = Modifier.padding(top = 12.dp))

            Text(
                if (detailOpen) "▴ Detail cuaca" else "▾ Detail cuaca",
                color = EvLight.copy(alpha = .85f), fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 8.dp).clickable { detailOpen = !detailOpen }.padding(vertical = 4.dp),
            )
            AnimatedVisibility(detailOpen) {
                Column(Modifier.fillMaxWidth().padding(top = 4.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (weather == null) {
                        Text("Data cuaca belum dimuat. Atur lokasi cuaca di Profil → Layanan.", color = EvLight.copy(alpha = .8f), fontSize = 12.sp)
                    } else {
                        val moon = remember(weather.fetchedAtMs) { Wx.moon(System.currentTimeMillis()) }
                        val aqiShort = weather.usAqi?.let { "AQI $it" } ?: weather.pm25?.let { "PM2.5 ${it.roundToInt()}" } ?: "—"
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            WxChip(null, aqiShort)
                            WxChip("↑", Wx.clock(weather.sunrise))
                            WxChip("↓", Wx.clock(weather.sunset))
                            WxChip(null, moon.first)
                        }
                        val aqiLong = weather.usAqi?.let { a -> "$a US AQI" + (weather.pm25?.let { " · PM2.5 ${it.roundToInt()} µg/m³" } ?: "") }
                            ?: weather.pm25?.let { "PM2.5 ${it.roundToInt()} µg/m³" } ?: "—"
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            WxBox("Kualitas udara", aqiLong, Modifier.weight(1f))
                            WxBox("Fase bulan", "${moon.first} ${moon.second}", Modifier.weight(1f))
                        }
                        if (weather.hours.isNotEmpty() || weather.days.isNotEmpty()) {
                            HorizontalDivider(color = EvLight.copy(alpha = .15f))
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(if (weekMode) "7 hari ke depan" else "24 jam ke depan", color = EvLight.copy(alpha = .85f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Row(Modifier.border(1.dp, EvLight.copy(alpha = .15f), CircleShape).padding(2.dp)) {
                                    ModeButton("Per jam", !weekMode) { weekMode = false; prefs.edit().putString("fcMode", "hour").apply() }
                                    ModeButton("Mingguan", weekMode) { weekMode = true; prefs.edit().putString("fcMode", "week").apply() }
                                }
                            }
                            if (!weekMode) HourlyStrip(weather) else DailyList(weather)
                        }
                    }
                }
            }
        }

        // Tombol Perbarui: ketuk = muat ulang, tekan lama = tampilkan info "diperbarui jam sekian".
        Box(
            Modifier.align(Alignment.TopEnd).padding(top = 12.dp, end = 12.dp).size(34.dp).clip(CircleShape)
                .background(EvLight.copy(alpha = if (busy) .14f else .2f))
                .combinedClickable(onClick = { if (!busy) onRefresh() }, onLongClick = { peek = true }),
            contentAlignment = Alignment.Center,
        ) { RefreshIcon(busy) }
    }
}

/** Ikon berputar hanya saat memuat; animasi tidak berjalan (dan tidak merekomposisi kartu) saat diam. */
@Composable
private fun RefreshIcon(busy: Boolean) {
    if (busy) {
        val spin by rememberInfiniteTransition(label = "wxSpin").animateFloat(
            0f, 360f, infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Restart), label = "wxSpinAngle",
        )
        Icon(Icons.Filled.Refresh, contentDescription = "Memuat cuaca", tint = EvLight, modifier = Modifier.size(18.dp).rotate(spin))
    } else {
        Icon(Icons.Filled.Refresh, contentDescription = "Perbarui cuaca", tint = EvLight, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun WxChip(prefix: String?, value: String) {
    Row(
        Modifier.clip(CircleShape).background(EvLight.copy(alpha = .16f)).padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        if (prefix != null) Text(prefix, color = EvLight.copy(alpha = .8f), fontSize = 10.5.sp)
        Text(value, color = EvLight, fontSize = 12.5.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun WxBox(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.border(1.dp, EvLight.copy(alpha = .25f), RoundedCornerShape(12.dp)).padding(horizontal = 10.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(label, color = EvLight.copy(alpha = .8f), fontSize = 11.sp)
        Text(value, color = EvLight, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ModeButton(label: String, active: Boolean, onClick: () -> Unit) {
    Text(
        label, color = if (active) MaterialTheme.colorScheme.onPrimary else EvLight.copy(alpha = .8f), fontSize = 12.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.clip(CircleShape).background(if (active) MaterialTheme.colorScheme.primary else Color.Transparent)
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 4.dp),
    )
}

@Composable
private fun HourlyStrip(w: WxSnapshot) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        w.hours.forEachIndexed { n, h ->
            Column(
                Modifier.width(56.dp).clip(RoundedCornerShape(14.dp)).background(EvLight.copy(alpha = .14f)).padding(horizontal = 4.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(if (n == 0) "Sekarang" else Wx.clock(h.time), color = EvLight.copy(alpha = .8f), fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Box(Modifier.heightIn(min = 20.dp), contentAlignment = Alignment.Center) { WxGlyph(h.code, Wx.isNight(h.time, w.sunrise, w.sunset)) }
                Text("${h.temp.roundToInt()}°", color = EvLight, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                Text(if ((h.pop ?: 0) >= 10) "${h.pop}%" else "", color = Color(0xFF4C8FE0), fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.heightIn(min = 13.dp))
            }
        }
    }
}

@Composable
private fun DailyList(w: WxSnapshot) {
    val fmtLocale = Locale("id", "ID")
    Column(Modifier.fillMaxWidth()) {
        w.days.forEachIndexed { n, d ->
            if (n > 0) HorizontalDivider(color = EvLight.copy(alpha = .2f))
            val label = if (n == 0) "Hari ini" else runCatching { LocalDate.parse(d.date.take(10)).dayOfWeek.getDisplayName(TextStyle.SHORT, fmtLocale) }.getOrDefault(d.date)
            Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(label, color = EvLight, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(64.dp), maxLines = 1)
                Box(Modifier.width(28.dp), contentAlignment = Alignment.Center) { WxGlyph(d.code, false) }
                Text(if ((d.pop ?: 0) >= 10) "${d.pop}%" else "", color = Color(0xFF4C8FE0), fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End, modifier = Modifier.width(38.dp))
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.End), verticalAlignment = Alignment.CenterVertically) {
                    Text("${d.lo.roundToInt()}°", color = EvLight.copy(alpha = .8f), fontSize = 13.sp)
                    Box(Modifier.width(40.dp).height(4.dp).clip(CircleShape).background(SolidColor(MaterialTheme.colorScheme.primary)))
                    Text("${d.hi.roundToInt()}°", color = EvLight, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/**
 * Susun masukan sapaan dari data native (setara glanceData() di web).
 * Catatan: log nyeri (painReadiness) belum ada di native, jadi `care` hanya dari kesiapan < 40.
 */
internal fun buildGreetInput(
    todayState: String,
    readiness: ReadinessMetric?,
    acwr: Double,
    daily: List<DailyEntity>,
    activities: List<ActivityEntity>,
    raceDate: LocalDate?,
    streak: Int,
    today: LocalDate,
    weather: WxSnapshot?,
): GreetInput {
    val mood = daily.firstOrNull { it.dateIso == today.toString() }?.mood?.takeIf { it in 1..5 }
    val runDates = activities.filter { it.type != "bike" && it.km > 0 }.mapNotNull { runCatching { LocalDate.parse(it.dateIso.take(10)) }.getOrNull() }.toSet()
    var gap: Int? = null
    for (i in 1..30) if (today.minusDays(i.toLong()) in runDates) { gap = i - 1; break }
    val raceDays = raceDate?.let { ChronoUnit.DAYS.between(today, it).toInt() }?.takeIf { it > 0 }
    val stormAhead = weather?.hours?.take(6)?.any { it.code >= 95 } == true
    return GreetInput(
        todayState = todayState,
        readiness = readiness?.score,
        acwr = acwr.takeIf { it > 0 },
        mood = mood,
        sleepDebt = readiness?.sleepDebtHours,
        raceDays = raceDays,
        streak = streak,
        gap = gap,
        care = false,
        wxFeels = weather?.feels,
        wxCode = weather?.let { if (stormAhead) 95 else it.code },
    )
}
