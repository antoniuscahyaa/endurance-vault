package com.endurancevault.app.domain

import com.endurancevault.app.domain.CourseStrategy.Pt
import java.util.Locale
import kotlin.math.abs

/** Lokasi tersimpan (pin oranye di peta Explore). */
data class ExPlace(val id: String, val name: String, val lat: Double, val lon: Double)

/**
 * Rute tersimpan di Koleksiku. [anchorIdx] = indeks titik di [pts] untuk tiap titik pegangan (waypoint),
 * dipakai saat rute dibuka lagi untuk disunting. [mode]: run | ride | manual. [source]: app | gpx.
 */
class ExRoute(
    val id: String,
    val name: String,
    val mode: String,
    val source: String,
    val createdMs: Long,
    val pts: List<Pt>,
    val anchorIdx: List<Int>,
) {
    val stats: GpxRoute.Stats by lazy { GpxRoute.stats(pts) }
    val isBike: Boolean get() = mode == "ride"

    fun anchors(): List<RouteGeo.LatLon> = anchorIdx.mapNotNull { pts.getOrNull(it)?.let { p -> RouteGeo.LatLon(p.lat, p.lon) } }

    fun toDraft(): RouteDraft {
        if (anchorIdx.size < 2) return RouteDraft(mode, anchors(), emptyList())
        val legs = (0 until anchorIdx.size - 1).map { i -> pts.subList(anchorIdx[i], anchorIdx[i + 1] + 1).toList() }
        return RouteDraft(mode, anchors(), legs)
    }

    /** Pratinjau untuk dialog Kirim ke jam yang sudah ada; null bila rute terlalu pendek. */
    fun toWatchPreview(): GpxRoute.Preview? {
        val (json, sent) = GpxRoute.payload(name, pts) ?: return null
        val st = stats
        return GpxRoute.Preview(ExploreGpx.fileName(name), GpxRoute.routeName(name), pts, st.km, pts.size, sent, json, st)
    }
}

/**
 * Rute yang sedang digambar: titik pegangan ([anchors]) dan satu ruas ([legs]) di antara tiap pasangan titik berurutan.
 * Tidak dapat diubah; setiap operasi mengembalikan salinan baru, jadi Urungkan cukup membuang titik terakhir.
 * Ruas berbagi titik ujung: ujung ruas ke-i adalah awal ruas ke-(i+1).
 */
class RouteDraft(val mode: String, val anchors: List<RouteGeo.LatLon>, val legs: List<List<Pt>>) {
    val isEmpty: Boolean get() = anchors.isEmpty()

    /** Semua titik rute berurutan (titik sambungan antar ruas tidak ganda). */
    val pts: List<Pt> by lazy {
        val out = ArrayList<Pt>()
        legs.forEachIndexed { i, leg -> if (i == 0) out.addAll(leg) else out.addAll(leg.drop(1)) }
        out
    }

    val stats: GpxRoute.Stats by lazy { GpxRoute.stats(pts) }

    val meters: Double by lazy { ExploreGeo.length(pts) }

    fun withMode(m: String) = RouteDraft(m, anchors, legs)

    /** Titik pertama. Ruas pertama menentukan posisi tersnap titik awal. */
    fun addFirst(at: RouteGeo.LatLon) = RouteDraft(mode, listOf(at), emptyList())

    /** Tambah titik pegangan di ujung [leg] (ruas dari titik pegangan terakhir ke titik baru). */
    fun addLeg(leg: List<Pt>): RouteDraft {
        if (leg.size < 2) return this
        val end = RouteGeo.LatLon(leg.last().lat, leg.last().lon)
        return if (anchors.size <= 1) {
            RouteDraft(mode, listOf(RouteGeo.LatLon(leg.first().lat, leg.first().lon), end), listOf(leg))
        } else RouteDraft(mode, anchors + end, legs + listOf(leg))
    }

    fun undo(): RouteDraft = when {
        anchors.size <= 1 -> RouteDraft(mode, emptyList(), emptyList())
        else -> RouteDraft(mode, anchors.dropLast(1), legs.dropLast(1))
    }

    /** Pertahankan [keepM] meter pertama; sisanya dibuang. Titik potong menjadi titik pegangan terakhir. */
    fun keepFirst(keepM: Double): RouteDraft {
        if (legs.isEmpty()) return this
        if (keepM <= 0.0) return RouteDraft(mode, emptyList(), emptyList())
        var acc = 0.0
        val newLegs = ArrayList<List<Pt>>()
        val newAnchors = ArrayList<RouteGeo.LatLon>()
        newAnchors.add(anchors[0])
        for ((i, leg) in legs.withIndex()) {
            val len = ExploreGeo.length(leg)
            if (acc + len <= keepM + 0.5) {
                newLegs.add(leg); newAnchors.add(anchors[i + 1]); acc += len
                continue
            }
            val cut = ExploreGeo.cutAt(leg, keepM - acc)
            if (cut.size >= 2) { newLegs.add(cut); newAnchors.add(RouteGeo.LatLon(cut.last().lat, cut.last().lon)) }
            break
        }
        if (newLegs.isEmpty()) return RouteDraft(mode, listOf(anchors[0]), emptyList())
        return RouteDraft(mode, newAnchors, newLegs)
    }

    /** Isi elevasi ([flat] sejajar dengan [pts]); titik tanpa data tetap null. */
    fun withElevations(flat: List<Double?>): RouteDraft {
        if (flat.size != pts.size) return this
        var base = 0
        val newLegs = legs.mapIndexed { i, leg ->
            if (i > 0) base += legs[i - 1].size - 1
            val b = base
            leg.mapIndexed { j, p -> Pt(p.lat, p.lon, flat.getOrNull(b + j)) }
        }
        return RouteDraft(mode, anchors, newLegs)
    }

    fun toRoute(id: String, name: String, source: String, createdMs: Long): ExRoute? {
        if (legs.isEmpty() || pts.size < 2) return null
        val idx = ArrayList<Int>()
        idx.add(0)
        legs.forEach { idx.add(idx.last() + it.size - 1) }
        return ExRoute(id, name, mode, source, createdMs, pts, idx)
    }

    /** Bagian rute mulai dari [startM] meter sampai akhir (titik potong menjadi titik pegangan pertama). */
    fun tailFrom(startM: Double): RouteDraft {
        if (legs.isEmpty() || startM <= 0.0) return this
        var acc = 0.0
        for ((i, leg) in legs.withIndex()) {
            val len = ExploreGeo.length(leg)
            if (acc + len <= startM + 0.5) { acc += len; continue }
            val rest = ExploreGeo.cutFrom(leg, startM - acc)
            if (rest.size < 2) {
                val nextLegs = legs.drop(i + 1)
                return if (nextLegs.isEmpty()) empty(mode) else RouteDraft(mode, anchors.drop(i + 1), nextLegs)
            }
            val newAnchors = listOf(RouteGeo.LatLon(rest.first().lat, rest.first().lon)) + anchors.drop(i + 1)
            return RouteDraft(mode, newAnchors, listOf(rest) + legs.drop(i + 1))
        }
        return empty(mode)
    }

    /** Pulang-pergi: rute yang sama dilalui balik ke titik awal. */
    fun outAndBack(): RouteDraft {
        if (legs.isEmpty()) return this
        val back = legs.reversed().map { it.reversed() }
        return RouteDraft(mode, anchors + anchors.reversed().drop(1), legs + back)
    }

    companion object {
        fun empty(mode: String) = RouteDraft(mode, emptyList(), emptyList())

        /** Gabung [head] + ruas [bridge] + [tail] (tail/head kosong = sisi itu tidak ada). */
        fun splice(head: RouteDraft, bridge: List<Pt>, tail: RouteDraft): RouteDraft = when {
            head.legs.isEmpty() -> if (tail.legs.isNotEmpty()) tail else head
            tail.legs.isEmpty() -> head
            else -> RouteDraft(head.mode, head.anchors + tail.anchors, head.legs + listOf(bridge) + tail.legs)
        }
    }
}

object ExploreGeo {
    fun dist(a: Pt, b: Pt): Double = ActBuilder.hav(a.lat, a.lon, b.lat, b.lon)

    fun length(pts: List<Pt>): Double {
        var d = 0.0
        for (i in 1 until pts.size) d += dist(pts[i - 1], pts[i])
        return d
    }

    /** Titik-titik dari awal sampai jarak [m]; titik potong disisipkan (elevasi diinterpolasi bila ada). */
    fun cutAt(pts: List<Pt>, m: Double): List<Pt> {
        val out = ArrayList<Pt>()
        var acc = 0.0
        if (pts.isEmpty()) return out
        out.add(pts[0])
        for (i in 1 until pts.size) {
            val seg = dist(pts[i - 1], pts[i])
            if (acc + seg >= m) {
                val f = if (seg > 0) ((m - acc) / seg).coerceIn(0.0, 1.0) else 0.0
                val a = pts[i - 1]; val b = pts[i]
                val e1 = a.ele; val e2 = b.ele
                val ele = if (e1 != null && e2 != null) e1 + (e2 - e1) * f else null
                if (f > 0.0) out.add(Pt(a.lat + (b.lat - a.lat) * f, a.lon + (b.lon - a.lon) * f, ele))
                return out
            }
            acc += seg
            out.add(pts[i])
        }
        return out
    }

    /** Titik-titik dari jarak [m] sampai akhir; titik potong disisipkan di depan. */
    fun cutFrom(pts: List<Pt>, m: Double): List<Pt> {
        var acc = 0.0
        for (i in 1 until pts.size) {
            val seg = dist(pts[i - 1], pts[i])
            if (acc + seg > m) {
                val f = if (seg > 0) ((m - acc) / seg).coerceIn(0.0, 1.0) else 0.0
                val a = pts[i - 1]; val b = pts[i]
                val e1 = a.ele; val e2 = b.ele
                val ele = if (e1 != null && e2 != null) e1 + (e2 - e1) * f else null
                return listOf(Pt(a.lat + (b.lat - a.lat) * f, a.lon + (b.lon - a.lon) * f, ele)) + pts.subList(i, pts.size)
            }
            acc += seg
        }
        return emptyList()
    }

    /** Jarak terdekat (m) titik [p] ke garis [line] (proyeksi ke ruas, pendekatan bidang lokal). */
    fun distToPolyline(p: Pt, line: List<Pt>): Double {
        if (line.isEmpty()) return Double.MAX_VALUE
        if (line.size == 1) return dist(p, line[0])
        val kx = Math.cos(Math.toRadians(p.lat)) * 111_320.0
        val ky = 110_540.0
        var best = Double.MAX_VALUE
        for (i in 1 until line.size) {
            val ax = (line[i - 1].lon - p.lon) * kx; val ay = (line[i - 1].lat - p.lat) * ky
            val bx = (line[i].lon - p.lon) * kx; val by = (line[i].lat - p.lat) * ky
            val dx = bx - ax; val dy = by - ay
            val l2 = dx * dx + dy * dy
            val t = if (l2 > 0) (-(ax * dx + ay * dy) / l2).coerceIn(0.0, 1.0) else 0.0
            val px = ax + dx * t; val py = ay + dy * t
            val d = Math.sqrt(px * px + py * py)
            if (d < best) best = d
        }
        return best
    }

    fun cumulative(pts: List<Pt>): DoubleArray {
        val a = DoubleArray(pts.size)
        for (i in 1 until pts.size) a[i] = a[i - 1] + dist(pts[i - 1], pts[i])
        return a
    }

    /** Garis lurus a→b dengan titik tiap ±[stepM] meter (dibutuhkan agar elevasi bisa disampel di sepanjang garis manual). */
    fun straight(a: RouteGeo.LatLon, b: RouteGeo.LatLon, stepM: Double = 40.0): List<Pt> {
        val d = ActBuilder.hav(a.lat, a.lon, b.lat, b.lon)
        val n = (d / stepM).toInt().coerceIn(1, 400)
        return (0..n).map { i ->
            val f = i.toDouble() / n
            Pt(a.lat + (b.lat - a.lat) * f, a.lon + (b.lon - a.lon) * f, null)
        }
    }

    /** Indeks titik pada [pts] yang jarak kumulatifnya paling dekat dengan [m]. */
    fun indexAt(pts: List<Pt>, m: Double): Int {
        var acc = 0.0
        for (i in 1 until pts.size) {
            acc += dist(pts[i - 1], pts[i])
            if (acc >= m) return if (abs(acc - m) < abs(acc - dist(pts[i - 1], pts[i]) - m)) i else i - 1
        }
        return (pts.size - 1).coerceAtLeast(0)
    }
}

object ExploreGpx {
    fun fileName(name: String): String = name.replace(Regex("[^A-Za-z0-9 _.-]"), "").trim().replace(' ', '_').ifEmpty { "rute" } + ".gpx"

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    /** GPX 1.1: satu trk, ditambah wpt untuk lokasi tersimpan yang dekat rute (bila ada). */
    fun build(route: ExRoute, places: List<ExPlace> = emptyList()): String = buildString {
        append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
        append("<gpx version=\"1.1\" creator=\"EnduranceVault\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n")
        append(" <metadata><name>").append(esc(route.name)).append("</name></metadata>\n")
        places.forEach {
            append(" <wpt lat=\"").append(String.format(Locale.ROOT, "%.6f", it.lat)).append("\" lon=\"")
                .append(String.format(Locale.ROOT, "%.6f", it.lon)).append("\"><name>").append(esc(it.name)).append("</name></wpt>\n")
        }
        append(" <trk><name>").append(esc(route.name)).append("</name><type>").append(if (route.isBike) "cycling" else "running").append("</type>\n  <trkseg>\n")
        route.pts.forEach { p ->
            append("   <trkpt lat=\"").append(String.format(Locale.ROOT, "%.6f", p.lat)).append("\" lon=\"").append(String.format(Locale.ROOT, "%.6f", p.lon)).append("\"")
            val e = p.ele
            if (e != null && e.isFinite()) append("><ele>").append(String.format(Locale.ROOT, "%.1f", e)).append("</ele></trkpt>\n") else append("/>\n")
        }
        append("  </trkseg>\n </trk>\n</gpx>\n")
    }
}

/** Titik di rute untuk penelusuran profil: jarak, elevasi, kemiringan (±50 m), dan posisi. */
class ExProbe(val km: Double, val ele: Double?, val gradePct: Double?, val at: RouteGeo.LatLon)

/** Sesi terjadwal yang bisa dipasangi rute (dari plan latihan). */
data class ExSession(val dateIso: String, val label: String, val km: Double)

class ExClimb(val fromKm: Double, val lenKm: Double, val gain: Int, val gradePct: Double)

/** Kemiringan dan tanjakan dari titik rute berelevasi. */
object ExploreGrade {
    private class Interp(val lat: Double, val lon: Double, val ele: Double?)

    private fun interp(pts: List<Pt>, cum: DoubleArray, m: Double): Interp {
        val mm = m.coerceIn(0.0, cum.last())
        var lo = 0; var hi = pts.size - 1
        while (hi - lo > 1) { val mid = (lo + hi) / 2; if (cum[mid] <= mm) lo = mid else hi = mid }
        val seg = cum[hi] - cum[lo]
        val f = if (seg > 0) ((mm - cum[lo]) / seg).coerceIn(0.0, 1.0) else 0.0
        val a = pts[lo]; val b = pts[hi]
        val e1 = a.ele; val e2 = b.ele
        return Interp(a.lat + (b.lat - a.lat) * f, a.lon + (b.lon - a.lon) * f, if (e1 != null && e2 != null) e1 + (e2 - e1) * f else null)
    }

    fun probe(pts: List<Pt>, cum: DoubleArray, km: Double): ExProbe? {
        if (pts.size < 2 || cum.size != pts.size) return null
        val m = (km * 1000.0).coerceIn(0.0, cum.last())
        val here = interp(pts, cum, m)
        val m0 = (m - 50.0).coerceAtLeast(0.0); val m1 = (m + 50.0).coerceAtMost(cum.last())
        val e0 = interp(pts, cum, m0).ele; val e1 = interp(pts, cum, m1).ele
        val g = if (e0 != null && e1 != null && m1 - m0 >= 20.0) (e1 - e0) / (m1 - m0) * 100.0 else null
        return ExProbe(m / 1000.0, here.ele, g, RouteGeo.LatLon(here.lat, here.lon))
    }

    /** Rentang indeks titik yang tanjakannya ≥ [thrPct]% (jendela 100 m), sepanjang minimal [minLenM]. */
    fun steepRanges(pts: List<Pt>, cum: DoubleArray, thrPct: Double = 10.0, minLenM: Double = 60.0): List<IntRange> {
        val n = pts.size
        if (n < 3 || cum.size != n) return emptyList()
        val mark = BooleanArray(n)
        var j = 0
        for (i in 0 until n - 1) {
            if (j < i) j = i
            while (j < n - 1 && cum[j] - cum[i] < 100.0) j++
            if (cum[j] - cum[i] < 60.0) break
            val e1 = pts[i].ele; val e2 = pts[j].ele
            if (e1 == null || e2 == null) continue
            if ((e2 - e1) / (cum[j] - cum[i]) * 100.0 >= thrPct) for (k in i..j) mark[k] = true
        }
        val out = ArrayList<IntRange>()
        var i = 0
        while (i < n) {
            if (!mark[i]) { i++; continue }
            var k = i
            while (k + 1 < n && mark[k + 1]) k++
            if (cum[k] - cum[i] >= minLenM) out.add(i..k)
            i = k + 1
        }
        return out
    }

    /** Tanjakan utama (dari profil strategi rute), diurutkan menurut tambahan elevasi. */
    fun climbs(pts: List<Pt>): List<ExClimb> {
        val prof = CourseStrategy.courseProfile(pts) ?: return emptyList()
        if (prof.noEle) return emptyList()
        return CourseStrategy.terrainSegs(prof.ep).mapNotNull { s ->
            val len = s.to - s.from
            if (len <= 0.0 || s.dz < 15.0) return@mapNotNull null
            val g = s.dz / (len * 1000.0) * 100.0
            if (g < 3.0) null else ExClimb(s.from, len, Math.round(s.dz).toInt(), g)
        }.sortedByDescending { it.gain }.take(6)
    }
}

/** Titik rute dari aktivitas tersinkron (jejak GPS atau rute ternormalisasi) untuk "Simpan jejak sebagai rute" dan pencocokan lari serupa. */
object ExploreActivity {
    fun latLon(d: ActDetail): List<RouteGeo.LatLon> {
        val g = d.gpsTrack
        if (g != null && g.size >= 2) {
            val out = ArrayList<RouteGeo.LatLon>(g.size)
            for (i in 0 until g.size) {
                val la = g.lat[i]; val lo = g.lon[i]
                if (la.isFinite() && lo.isFinite() && (la != 0.0 || lo != 0.0)) out.add(RouteGeo.LatLon(la, lo))
            }
            if (out.size >= 2) return out
        }
        val f = d.geo
        return if (f != null && d.route.size >= 2) RouteGeo.toLatLon(f, d.route) else emptyList()
    }

    /** Titik jarang (≥ [minStepM] antar titik) dengan elevasi dari profil aktivitas (diskalakan ke panjang jejak). */
    fun toPts(d: ActDetail, minStepM: Double = 12.0): List<Pt> {
        val ll = latLon(d)
        if (ll.size < 2) return emptyList()
        val thin = ArrayList<Pt>()
        thin.add(Pt(ll[0].lat, ll[0].lon, null))
        for (i in 1 until ll.size) {
            val q = Pt(ll[i].lat, ll[i].lon, null)
            if (ExploreGeo.dist(thin.last(), q) >= minStepM || i == ll.lastIndex) thin.add(q)
        }
        if (thin.size < 2) return emptyList()
        val prof = d.profile
        if (prof.size < 2) return thin
        val cum = ExploreGeo.cumulative(thin)
        val total = cum.last() / 1000.0
        val pk = prof.last().first
        val scale = if (total > 0 && pk > 0) pk / total else 1.0
        var j = 0
        return thin.mapIndexed { i, p ->
            val km = cum[i] / 1000.0 * scale
            while (j < prof.size - 2 && prof[j + 1].first < km) j++
            val a = prof[j]; val b = prof[j + 1]
            val f = if (b.first > a.first) ((km - a.first) / (b.first - a.first)).coerceIn(0.0, 1.0) else 0.0
            Pt(p.lat, p.lon, a.second + (b.second - a.second) * f)
        }
    }
}
