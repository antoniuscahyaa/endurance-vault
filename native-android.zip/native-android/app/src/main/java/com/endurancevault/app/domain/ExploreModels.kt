package com.endurancevault.app.domain

import com.endurancevault.app.domain.CourseStrategy.Pt
import java.util.Locale
import kotlin.math.abs

/** Lokasi tersimpan (pin oranye di peta Explore). */
data class ExPlace(val id: String, val name: String, val lat: Double, val lon: Double)

/**
 * Rute tersimpan di Koleksiku. [anchorIdx] = indeks titik di [pts] untuk tiap titik pegangan (waypoint),
 * dipakai saat rute dibuka lagi untuk disunting. [mode]: run | ride | manual. [source]: app | gpx.
 */
class ExRoute(
    val id: String,
    val name: String,
    val mode: String,
    val source: String,
    val createdMs: Long,
    val pts: List<Pt>,
    val anchorIdx: List<Int>,
) {
    val stats: GpxRoute.Stats by lazy { GpxRoute.stats(pts) }
    val isBike: Boolean get() = mode == "ride"

    fun anchors(): List<RouteGeo.LatLon> = anchorIdx.mapNotNull { pts.getOrNull(it)?.let { p -> RouteGeo.LatLon(p.lat, p.lon) } }

    fun toDraft(): RouteDraft {
        if (anchorIdx.size < 2) return RouteDraft(mode, anchors(), emptyList())
        val legs = (0 until anchorIdx.size - 1).map { i -> pts.subList(anchorIdx[i], anchorIdx[i + 1] + 1).toList() }
        return RouteDraft(mode, anchors(), legs)
    }

    /** Pratinjau untuk dialog Kirim ke jam yang sudah ada; null bila rute terlalu pendek. */
    fun toWatchPreview(): GpxRoute.Preview? {
        val (json, sent) = GpxRoute.payload(name, pts) ?: return null
        val st = stats
        return GpxRoute.Preview(ExploreGpx.fileName(name), GpxRoute.routeName(name), pts, st.km, pts.size, sent, json, st)
    }
}

/**
 * Rute yang sedang digambar: titik pegangan ([anchors]) dan satu ruas ([legs]) di antara tiap pasangan titik berurutan.
 * Tidak dapat diubah; setiap operasi mengembalikan salinan baru, jadi Urungkan cukup membuang titik terakhir.
 * Ruas berbagi titik ujung: ujung ruas ke-i adalah awal ruas ke-(i+1).
 */
class RouteDraft(val mode: String, val anchors: List<RouteGeo.LatLon>, val legs: List<List<Pt>>) {
    val isEmpty: Boolean get() = anchors.isEmpty()

    /** Semua titik rute berurutan (titik sambungan antar ruas tidak ganda). */
    val pts: List<Pt> by lazy {
        val out = ArrayList<Pt>()
        legs.forEachIndexed { i, leg -> if (i == 0) out.addAll(leg) else out.addAll(leg.drop(1)) }
        out
    }

    val stats: GpxRoute.Stats by lazy { GpxRoute.stats(pts) }

    val meters: Double by lazy { ExploreGeo.length(pts) }

    fun withMode(m: String) = RouteDraft(m, anchors, legs)

    /** Titik pertama. Ruas pertama menentukan posisi tersnap titik awal. */
    fun addFirst(at: RouteGeo.LatLon) = RouteDraft(mode, listOf(at), emptyList())

    /** Tambah titik pegangan di ujung [leg] (ruas dari titik pegangan terakhir ke titik baru). */
    fun addLeg(leg: List<Pt>): RouteDraft {
        if (leg.size < 2) return this
        val end = RouteGeo.LatLon(leg.last().lat, leg.last().lon)
        return if (anchors.size <= 1) {
            RouteDraft(mode, listOf(RouteGeo.LatLon(leg.first().lat, leg.first().lon), end), listOf(leg))
        } else RouteDraft(mode, anchors + end, legs + listOf(leg))
    }

    fun undo(): RouteDraft = when {
        anchors.size <= 1 -> RouteDraft(mode, emptyList(), emptyList())
        else -> RouteDraft(mode, anchors.dropLast(1), legs.dropLast(1))
    }

    /** Pertahankan [keepM] meter pertama; sisanya dibuang. Titik potong menjadi titik pegangan terakhir. */
    fun keepFirst(keepM: Double): RouteDraft {
        if (legs.isEmpty()) return this
        if (keepM <= 0.0) return RouteDraft(mode, emptyList(), emptyList())
        var acc = 0.0
        val newLegs = ArrayList<List<Pt>>()
        val newAnchors = ArrayList<RouteGeo.LatLon>()
        newAnchors.add(anchors[0])
        for ((i, leg) in legs.withIndex()) {
            val len = ExploreGeo.length(leg)
            if (acc + len <= keepM + 0.5) {
                newLegs.add(leg); newAnchors.add(anchors[i + 1]); acc += len
                continue
            }
            val cut = ExploreGeo.cutAt(leg, keepM - acc)
            if (cut.size >= 2) { newLegs.add(cut); newAnchors.add(RouteGeo.LatLon(cut.last().lat, cut.last().lon)) }
            break
        }
        if (newLegs.isEmpty()) return RouteDraft(mode, listOf(anchors[0]), emptyList())
        return RouteDraft(mode, newAnchors, newLegs)
    }

    /** Isi elevasi ([flat] sejajar dengan [pts]); titik tanpa data tetap null. */
    fun withElevations(flat: List<Double?>): RouteDraft {
        if (flat.size != pts.size) return this
        var base = 0
        val newLegs = legs.mapIndexed { i, leg ->
            if (i > 0) base += legs[i - 1].size - 1
            val b = base
            leg.mapIndexed { j, p -> Pt(p.lat, p.lon, flat.getOrNull(b + j)) }
        }
        return RouteDraft(mode, anchors, newLegs)
    }

    fun toRoute(id: String, name: String, source: String, createdMs: Long): ExRoute? {
        if (legs.isEmpty() || pts.size < 2) return null
        val idx = ArrayList<Int>()
        idx.add(0)
        legs.forEach { idx.add(idx.last() + it.size - 1) }
        return ExRoute(id, name, mode, source, createdMs, pts, idx)
    }

    companion object {
        fun empty(mode: String) = RouteDraft(mode, emptyList(), emptyList())
    }
}

object ExploreGeo {
    fun dist(a: Pt, b: Pt): Double = ActBuilder.hav(a.lat, a.lon, b.lat, b.lon)

    fun length(pts: List<Pt>): Double {
        var d = 0.0
        for (i in 1 until pts.size) d += dist(pts[i - 1], pts[i])
        return d
    }

    /** Titik-titik dari awal sampai jarak [m]; titik potong disisipkan (elevasi diinterpolasi bila ada). */
    fun cutAt(pts: List<Pt>, m: Double): List<Pt> {
        val out = ArrayList<Pt>()
        var acc = 0.0
        if (pts.isEmpty()) return out
        out.add(pts[0])
        for (i in 1 until pts.size) {
            val seg = dist(pts[i - 1], pts[i])
            if (acc + seg >= m) {
                val f = if (seg > 0) ((m - acc) / seg).coerceIn(0.0, 1.0) else 0.0
                val a = pts[i - 1]; val b = pts[i]
                val e1 = a.ele; val e2 = b.ele
                val ele = if (e1 != null && e2 != null) e1 + (e2 - e1) * f else null
                if (f > 0.0) out.add(Pt(a.lat + (b.lat - a.lat) * f, a.lon + (b.lon - a.lon) * f, ele))
                return out
            }
            acc += seg
            out.add(pts[i])
        }
        return out
    }

    /** Garis lurus a→b dengan titik tiap ±[stepM] meter (dibutuhkan agar elevasi bisa disampel di sepanjang garis manual). */
    fun straight(a: RouteGeo.LatLon, b: RouteGeo.LatLon, stepM: Double = 40.0): List<Pt> {
        val d = ActBuilder.hav(a.lat, a.lon, b.lat, b.lon)
        val n = (d / stepM).toInt().coerceIn(1, 400)
        return (0..n).map { i ->
            val f = i.toDouble() / n
            Pt(a.lat + (b.lat - a.lat) * f, a.lon + (b.lon - a.lon) * f, null)
        }
    }

    /** Indeks titik pada [pts] yang jarak kumulatifnya paling dekat dengan [m]. */
    fun indexAt(pts: List<Pt>, m: Double): Int {
        var acc = 0.0
        for (i in 1 until pts.size) {
            acc += dist(pts[i - 1], pts[i])
            if (acc >= m) return if (abs(acc - m) < abs(acc - dist(pts[i - 1], pts[i]) - m)) i else i - 1
        }
        return (pts.size - 1).coerceAtLeast(0)
    }
}

object ExploreGpx {
    fun fileName(name: String): String = name.replace(Regex("[^A-Za-z0-9 _.-]"), "").trim().replace(' ', '_').ifEmpty { "rute" } + ".gpx"

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    /** GPX 1.1: satu trk, ditambah wpt untuk lokasi tersimpan yang dekat rute (bila ada). */
    fun build(route: ExRoute, places: List<ExPlace> = emptyList()): String = buildString {
        append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
        append("<gpx version=\"1.1\" creator=\"EnduranceVault\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n")
        append(" <metadata><name>").append(esc(route.name)).append("</name></metadata>\n")
        places.forEach {
            append(" <wpt lat=\"").append(String.format(Locale.ROOT, "%.6f", it.lat)).append("\" lon=\"")
                .append(String.format(Locale.ROOT, "%.6f", it.lon)).append("\"><name>").append(esc(it.name)).append("</name></wpt>\n")
        }
        append(" <trk><name>").append(esc(route.name)).append("</name><type>").append(if (route.isBike) "cycling" else "running").append("</type>\n  <trkseg>\n")
        route.pts.forEach { p ->
            append("   <trkpt lat=\"").append(String.format(Locale.ROOT, "%.6f", p.lat)).append("\" lon=\"").append(String.format(Locale.ROOT, "%.6f", p.lon)).append("\"")
            val e = p.ele
            if (e != null && e.isFinite()) append("><ele>").append(String.format(Locale.ROOT, "%.1f", e)).append("</ele></trkpt>\n") else append("/>\n")
        }
        append("  </trkseg>\n </trk>\n</gpx>\n")
    }
}
