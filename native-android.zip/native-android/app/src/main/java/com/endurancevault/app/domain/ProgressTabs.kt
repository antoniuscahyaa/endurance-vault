package com.endurancevault.app.domain

import kotlin.math.sqrt

/**
 * Logika murni (tanpa Android) untuk sub-tab Load, Routes & conditions, dan Body di Progres.
 * Dipisah dari UI supaya bisa diuji di JVM. Tidak mengubah rumus beban/readiness yang sudah ada.
 */
object ProgressTabs {
    /** Zona ACWR indikatif (Gabbett): <0,8 rendah, 0,8-1,3 optimal, 1,3-1,5 waspada, >1,5 tinggi. */
    fun acwrZone(ratio: Double): String = when {
        ratio < 0.8 -> "Rendah"
        ratio <= 1.3 -> "Optimal"
        ratio <= 1.5 -> "Waspada"
        else -> "Tinggi"
    }

    fun acwrOk(ratio: Double): Boolean = ratio >= 0.8 && ratio <= 1.3

    /** Pita suhu untuk dampak cuaca: 0 = <24°C, 1 = 24–28°C, 2 = ≥28°C. */
    fun tempBand(temp: Double): Int = if (temp < 24.0) 0 else if (temp < 28.0) 1 else 2

    val BAND_LABELS = listOf("<24°C", "24–28°C", "≥28°C")

    /**
     * Saran distribusi intensitas 80/20. Hanya rekomendasi; tidak mengubah rencana.
     * Kembalian: (nada, teks); nada 0 = sesuai, 1 = perlu perhatian.
     */
    fun intensityAdvice(z1z2: Double, z3: Double): Pair<Int, String> = when {
        z3 > 15.0 -> 1 to "Porsi Z3 cukup besar. Zona ini terlalu berat untuk easy dan terlalu ringan untuk quality; " +
            "pertimbangkan menjaga easy lebih santai supaya sesi keras tetap berkualitas."
        z1z2 < 75.0 -> 1 to "Porsi Z1–2 di bawah sekitar 80%. Tambah waktu di easy bila kondisi pulih memungkinkan."
        else -> 0 to "Distribusi mendekati pola 80/20."
    }

    /**
     * Resampel profil (km, nilai) menjadi [n] titik berjarak sama sepanjang jarak, dengan interpolasi linear.
     * Kosong bila titik kurang dari dua atau jarak nol.
     */
    fun resample(profile: List<Pair<Double, Double>>, n: Int = 40): List<Float> {
        if (profile.size < 2 || n < 2) return emptyList()
        val p = profile.sortedBy { it.first }
        val maxKm = p.last().first
        if (!(maxKm > 0.0)) return emptyList()
        var j = 0
        return List(n) { i ->
            val x = maxKm * i / (n - 1)
            while (j < p.size - 1 && p[j + 1].first <= x) j++
            val a = p[j]
            val b = p[minOf(j + 1, p.size - 1)]
            val t = if (b.first > a.first) ((x - a.first) / (b.first - a.first)).coerceIn(0.0, 1.0) else 0.0
            (a.second + (b.second - a.second) * t).toFloat()
        }
    }

    class Trend(val slope: Double, val intercept: Double, val r: Double?)

    /** Regresi linear kuadrat terkecil y = intercept + slope·x; null bila < 3 titik atau x tidak bervariasi. */
    fun trend(points: List<Pair<Double, Double>>): Trend? {
        if (points.size < 3) return null
        val mx = points.map { it.first }.average()
        val my = points.map { it.second }.average()
        val sxx = points.sumOf { (it.first - mx) * (it.first - mx) }
        if (sxx <= 1e-9) return null
        val sxy = points.sumOf { (it.first - mx) * (it.second - my) }
        val syy = points.sumOf { (it.second - my) * (it.second - my) }
        val slope = sxy / sxx
        val r = if (syy <= 1e-9) null else sxy / sqrt(sxx * syy)
        return Trend(slope, my - slope * mx, r)
    }
}
