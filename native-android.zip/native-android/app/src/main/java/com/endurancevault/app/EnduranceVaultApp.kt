package com.endurancevault.app

import android.app.Application
import com.endurancevault.app.data.AppDb
import com.endurancevault.app.data.SettingsStore

class EnduranceVaultApp : Application() {
    val db: AppDb by lazy { AppDb.create(this) }
    val settings: SettingsStore by lazy { SettingsStore(this) }
}
