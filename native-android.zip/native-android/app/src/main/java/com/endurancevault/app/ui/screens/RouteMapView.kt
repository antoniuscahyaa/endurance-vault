package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.i18n.Text
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.changedToUp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.endurancevault.app.data.MapTiles
import com.endurancevault.app.domain.ActDetail
import com.endurancevault.app.domain.RouteGeo
import com.endurancevault.app.ui.theme.Ember
import kotlin.math.roundToInt
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

/**
 * Rute lari di atas peta OpenStreetMap. Garis rute selalu digambar; ubin peta dimuat di belakangnya
 * (cache disk, jadi rute yang pernah dibuka tetap bermap saat offline). Tanpa koordinat (`ge`) atau tanpa
 * jaringan dan cache, tampilannya setara tampilan offline lama.
 */
@Composable
internal fun DRouteMapView(d: ActDetail) {
    val frame = d.geo
    if (frame == null || !d.hasRoute) { DRouteView(d); return }
    val context = LocalContext.current
    val density = LocalDensity.current
    val points = remember(d) { RouteGeo.toLatLon(frame, d.route) }

    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            var failed by remember(d) { mutableStateOf(false) }
            val bitmaps = remember(d) { mutableStateMapOf<RouteGeo.TileId, ImageBitmap>() }

            BoxWithConstraints(Modifier.fillMaxWidth().aspectRatio(1.2f).clip(RoundedCornerShape(12.dp))) {
                val wPx = with(density) { maxWidth.toPx() }.toDouble()
                val hPx = with(density) { maxHeight.toPx() }.toDouble()
                val base = remember(points, wPx, hPx) { RouteGeo.fitView(points, wPx, hPx) }
                var view by remember(base) { mutableStateOf(base) }
                val cam = remember(view) { view?.let { RouteGeo.cameraOf(it) } }
                val placed = remember(cam, wPx, hPx) { cam?.let { RouteGeo.tilesFor(it, wPx, hPx) }.orEmpty() }
                val latestBase by rememberUpdatedState(base)
                val latestView by rememberUpdatedState(view)
                val changed = base != null && view != null && (kotlin.math.abs(view!!.zoomF - base.zoomF) > 0.01 ||
                    kotlin.math.abs(view!!.cx0 - base.cx0) > 1e-6 || kotlin.math.abs(view!!.cy0 - base.cy0) > 1e-6)

                LaunchedEffect(placed) {
                    if (bitmaps.size > 160) bitmaps.clear()
                    coroutineScope {
                        placed.map { it.id }.distinct().forEach { id ->
                            launch {
                                val bmp = MapTiles.load(context, id)
                                if (bmp != null) bitmaps[id] = bmp.asImageBitmap() else failed = true
                            }
                        }
                    }
                }

                // Cubit selalu memperbesar/memperkecil; geser satu jari hanya saat peta sudah diperbesar,
                // supaya halaman detail tetap bisa di-scroll dengan menyentuh peta.
                val gestures = Modifier.pointerInput(Unit) {
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false)
                        do {
                            val event = awaitPointerEvent()
                            val b = latestBase
                            val v = latestView
                            if (b != null && v != null) {
                                val multi = event.changes.count { it.pressed } >= 2
                                val zoomedIn = v.zoomF > b.zoomF + 0.05
                                if (multi || zoomedIn) {
                                    val zoom = event.calculateZoom()
                                    val pan = event.calculatePan()
                                    val c = event.calculateCentroid(useCurrent = false)
                                    if ((zoom != 1f || pan != Offset.Zero) && c != Offset.Unspecified) {
                                        view = RouteGeo.transform(
                                            v, size.width.toDouble(), size.height.toDouble(),
                                            c.x.toDouble(), c.y.toDouble(), pan.x.toDouble(), pan.y.toDouble(),
                                            zoom.toDouble(), minZoom = maxOf(0.0, b.zoomF - 1.5),
                                        )
                                        event.changes.forEach { if (it.positionChanged()) it.consume() }
                                    }
                                }
                            }
                        } while (event.changes.any { it.pressed && !it.changedToUp() })
                    }
                }

                Canvas(Modifier.fillMaxSize().then(gestures)) {
                    drawRect(Color(0xFFE9E6DF))
                    if (cam == null) return@Canvas
                    val s = cam.scale
                    val cx = size.width / 2.0
                    val cy = size.height / 2.0
                    fun sx(wx: Double) = (cx + (wx - cam.centerX) * s).toFloat()
                    fun sy(wy: Double) = (cy + (wy - cam.centerY) * s).toFloat()

                    val tile = RouteGeo.TILE.toDouble()
                    placed.forEach { p ->
                        val bmp = bitmaps[p.id] ?: return@forEach
                        val left = sx(p.ux * tile).roundToInt()
                        val top = sy(p.id.y * tile).roundToInt()
                        val right = sx((p.ux + 1) * tile).roundToInt()
                        val bottom = sy((p.id.y + 1) * tile).roundToInt()
                        drawImage(bmp, dstOffset = IntOffset(left, top), dstSize = IntSize(right - left, bottom - top))
                    }

                    fun pos(i: Int) = Offset(
                        sx(RouteGeo.worldX(points[i].lon, cam.zoom)),
                        sy(RouteGeo.worldY(points[i].lat, cam.zoom)),
                    )
                    val path = Path()
                    for (i in points.indices) { val o = pos(i); if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y) }
                    val round = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                    drawPath(path, Color.White.copy(alpha = 0.9f), style = Stroke(width = 7.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                    drawPath(path, Ember, style = round)
                    drawCircle(Color.White, 8.dp.toPx(), pos(0))
                    drawCircle(DetailGreen, 6.dp.toPx(), pos(0))
                    drawCircle(Color.White, 8.dp.toPx(), pos(points.lastIndex))
                    drawCircle(DetailRed, 6.dp.toPx(), pos(points.lastIndex))
                }

                Text(
                    "© OpenStreetMap",
                    modifier = Modifier.align(Alignment.BottomEnd).background(Color.White.copy(alpha = 0.6f)).padding(horizontal = 3.dp),
                    color = Color(0xFF333333), fontSize = 7.sp, lineHeight = 9.sp,
                )
                if (changed) {
                    Text(
                        "Reset",
                        modifier = Modifier.align(Alignment.TopEnd).padding(6.dp)
                            .background(Color.White.copy(alpha = 0.85f), RoundedCornerShape(8.dp))
                            .clickable { view = latestBase }
                            .padding(horizontal = 8.dp, vertical = 3.dp),
                        color = Color.Black, fontSize = 11.sp,
                    )
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(9.dp).background(DetailGreen, CircleShape))
                    Text("Mulai", style = MaterialTheme.typography.labelSmall)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(9.dp).background(DetailRed, CircleShape))
                    Text("Selesai", style = MaterialTheme.typography.labelSmall)
                }
            }
            if (failed && bitmaps.isEmpty()) {
                Text(
                    "Peta dasar tidak termuat (mungkin offline). Garis rute tetap ditampilkan; peta muncul saat tersambung internet.",
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
