package com.endurancevault.app.data

import com.endurancevault.app.domain.MvEntry
import org.json.JSONArray
import org.json.JSONObject

/**
 * Baca/tulis data `mv` dan `done` dalam format yang sama dengan versi web (rencana-lari), tersimpan di tabel kv sehingga
 * ikut cadangan dan pemulihan web. mv: {"sw:2026-11-04":{t:"sw",to:"2026-11-05"}, "2026-11-03":{t:"spread",to:[{date,x}],why,km,f}, ...}
 * done: {"2026-11-04":true, "2026-11-04:s":true}.
 */
object MvStore {
    fun parse(json: String?): Map<String, MvEntry> {
        val o = runCatching { JSONObject(json ?: "{}") }.getOrNull() ?: return emptyMap()
        val out = LinkedHashMap<String, MvEntry>()
        for (k in o.keys()) {
            val e = o.optJSONObject(k) ?: continue
            val t = e.optString("t")
            out[k] = when (t) {
                "sw", "mv" -> MvEntry(t, to = e.optString("to").ifBlank { null })
                "skip" -> MvEntry(t)
                "spread" -> {
                    val arr = e.optJSONArray("to") ?: JSONArray()
                    val to = (0 until arr.length()).mapNotNull { i ->
                        val q = arr.optJSONObject(i) ?: return@mapNotNull null
                        val d = q.optString("date")
                        if (d.isBlank()) null else d to q.optDouble("x", 0.0)
                    }
                    MvEntry(t, why = e.optString("why").ifBlank { null }, km = e.optDouble("km", 0.0), f = e.optDouble("f", 1.0), spread = to)
                }
                else -> MvEntry(t, raw = e.toString())
            }
        }
        return out
    }

    fun toJson(map: Map<String, MvEntry>): String {
        val o = JSONObject()
        for ((k, e) in map) {
            if (e.raw != null) { runCatching { o.put(k, JSONObject(e.raw)) }; continue }
            val j = JSONObject().put("t", e.t)
            when (e.t) {
                "sw", "mv" -> e.to?.let { j.put("to", it) }
                "spread" -> {
                    val arr = JSONArray()
                    e.spread.forEach { (d, x) -> arr.put(JSONObject().put("date", d).put("x", x)) }
                    j.put("to", arr).put("km", e.km).put("f", e.f)
                    e.why?.let { j.put("why", it) }
                }
            }
            o.put(k, j)
        }
        return o.toString()
    }

    fun parseDone(json: String?): Set<String> {
        val o = runCatching { JSONObject(json ?: "{}") }.getOrNull() ?: return emptySet()
        val out = HashSet<String>()
        for (k in o.keys()) {
            val v = o.opt(k)
            if (v == null || v == JSONObject.NULL || v == false || (v is Number && v.toDouble() == 0.0)) continue
            out.add(k)
        }
        return out
    }

    /** Menambah/menghapus satu kunci tanpa menghilangkan nilai asli (mis. cap waktu dari web) pada kunci lain. */
    fun doneJson(current: String?, key: String, value: Boolean): String {
        val o = runCatching { JSONObject(current ?: "{}") }.getOrDefault(JSONObject())
        if (value) o.put(key, true) else o.remove(key)
        return o.toString()
    }

    /** Pindahan sekali jalan dari penyimpanan lama native (SharedPreferences week_adjustments_v1: swaps dan spreads) ke format mv. */
    fun fromLegacy(legacy: String?): Map<String, MvEntry> {
        val root = runCatching { JSONObject(legacy ?: "{}") }.getOrNull() ?: return emptyMap()
        val out = LinkedHashMap<String, MvEntry>()
        root.optJSONArray("swaps")?.let { arr ->
            for (i in 0 until arr.length()) {
                val s = arr.optJSONObject(i) ?: continue
                val a = s.optString("a"); val b = s.optString("b")
                if (a.isNotBlank() && b.isNotBlank()) out["sw:$a"] = MvEntry("sw", to = b)
            }
        }
        root.optJSONArray("spreads")?.let { arr ->
            for (i in 0 until arr.length()) {
                val s = arr.optJSONObject(i) ?: continue
                val date = s.optString("date"); if (date.isBlank()) continue
                val to = s.optJSONArray("to") ?: JSONArray()
                val list = (0 until to.length()).mapNotNull { j ->
                    val q = to.optJSONObject(j) ?: return@mapNotNull null
                    val d = q.optString("date")
                    if (d.isBlank()) null else d to q.optDouble("km", 0.0)
                }
                out[date] = MvEntry("spread", why = s.optString("reason").ifBlank { null }, km = s.optDouble("km", 0.0), f = 1.0, spread = list)
            }
        }
        return out
    }
}
