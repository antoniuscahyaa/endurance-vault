package com.endurancevault.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.RectF
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.data.TerrainBuilder
import com.endurancevault.app.data.TerrainScene
import com.endurancevault.app.domain.ActDetail
import com.endurancevault.app.domain.GhostInfo
import com.endurancevault.app.domain.Js
import com.endurancevault.app.domain.RouteVideoCamera
import com.endurancevault.app.domain.RouteVideoColors
import com.endurancevault.app.domain.RouteVideoFormat
import com.endurancevault.app.domain.RouteVideoKeys
import com.endurancevault.app.domain.RouteVideoPresets
import com.endurancevault.app.domain.RouteVideoPrefs
import com.endurancevault.app.domain.RouteVideoRace
import com.endurancevault.app.domain.RouteVideoText
import com.endurancevault.app.domain.RouteVideoTrack
import com.endurancevault.app.domain.asPreset
import com.endurancevault.app.domain.withPreset
import com.endurancevault.app.ui.UiState
import com.endurancevault.app.ui.i18n.Text
import com.endurancevault.app.ui.sticker.StickerFontStore
import com.endurancevault.app.ui.sticker.StickerFonts
import com.endurancevault.app.ui.sticker.StickerPrefsStore
import com.endurancevault.app.ui.video.PreviewFrame
import com.endurancevault.app.ui.video.PreviewHost
import com.endurancevault.app.ui.video.RenderState
import com.endurancevault.app.ui.video.RouteVideoIo
import com.endurancevault.app.ui.video.RouteVideoJobs
import com.endurancevault.app.ui.video.RouteVideoOverlay
import com.endurancevault.app.ui.video.RouteVideoPrefsStore
import java.io.File
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.roundToInt

private val LINE_COLORS = listOf("Lime" to "#C6F432", "Oranye" to "#FF7A1A", "Cyan" to "#27D3FF", "Merah" to "#FF3B4E", "Putih" to "#FFFFFF")

/**
 * Video rute 3D: peta satelit berelief sesuai elevasi, rute tergambar bertahap (bisa berwarna menurut HR, pace, atau
 * gradien), bendera km/start/finish/puncak, dan panel data yang posisi dan ukurannya bisa diatur dengan menggeser di
 * pratinjau. Bisa membalap aktivitas lain (ghost). Render berjalan di latar belakang dengan notifikasi progres.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RouteVideoScreen(state: UiState, id: Long, load: suspend (ActivityEntity) -> ActDetail?, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val appCtx = ctx.applicationContext
    val scope = rememberCoroutineScope()
    val store = remember { RouteVideoPrefsStore(appCtx) }
    var prefs by remember { mutableStateOf(store.load()) }
    var selected by remember { mutableStateOf<String?>(null) }
    fun update(p: RouteVideoPrefs, persist: Boolean = true) { prefs = p.sanitized(); if (persist) store.save(prefs) }

    // Pratinjau memakai thread GL sendiri; render video punya thread dan konteks sendiri di RouteVideoJobs.
    val host = remember { PreviewHost() }
    DisposableEffect(Unit) { onDispose { host.close() } }

    val stk = remember { StickerPrefsStore(appCtx).load() }
    val fontStore = remember { StickerFontStore(appCtx) }
    val fonts = remember(stk.fontNum, stk.fontBody) { StickerFonts(fontStore.typeface(stk.fontNum), fontStore.typeface(stk.fontBody)) }

    var pos by remember { mutableStateOf(0.5f) }
    var status by remember { mutableStateOf("Menyiapkan peta…") }
    var ghostId by remember { mutableStateOf<Long?>(null) }
    var ghostMsg by remember { mutableStateOf("") }
    var showGhostPicker by remember { mutableStateOf(false) }
    var showSave by remember { mutableStateOf(false) }
    var showManage by remember { mutableStateOf(false) }
    var presetName by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var prefetchMsg by remember { mutableStateOf("") }
    var prefetching by remember { mutableStateOf(false) }
    var askedPerm by remember { mutableStateOf(false) }

    val e = state.activities.firstOrNull { it.id == id }
    fun nameOf(a: ActivityEntity) = a.name.ifBlank { if (a.type == "bike") "Gowes" else "Lari" }

    val loaded by produceState<Pair<Boolean, ActDetail?>>(false to null, e?.id, e?.detailFile, e?.km, e?.durationSec, e?.type) {
        value = true to e?.let { load(it) }
    }
    val track = remember(loaded.second, e?.name) {
        val d = loaded.second
        if (e != null && d != null) RouteVideoTrack.from(d, nameOf(e), RouteVideoText.dateId(e.dateIso)) else null
    }

    // Ghost: pasangan (id yang selesai dimuat, jejaknya).
    val ghostEntity = state.activities.firstOrNull { it.id == ghostId }
    val ghostRes by produceState<Pair<Long?, RouteVideoTrack?>>(null to null, ghostId) {
        val ge = ghostEntity
        value = if (ge == null) null to null
        else ge.id to load(ge)?.let { RouteVideoTrack.from(it, nameOf(ge), RouteVideoText.dateId(ge.dateIso)) }
    }
    val ghostTrack = if (ghostId != null && ghostRes.first == ghostId) ghostRes.second else null
    LaunchedEffect(ghostRes, ghostId) {
        if (ghostId != null && ghostRes.first == ghostId && ghostRes.second == null) {
            ghostMsg = "Aktivitas itu tidak punya rute GPS dan data per detik, jadi tidak bisa jadi ghost."
            ghostId = null
        }
    }

    // Medan 3D: dibangun ulang bila jejak atau ghost berubah; pasangan (jejak, medan) menandai medan milik jejak yang mana.
    val sceneRes by produceState<Pair<RouteVideoTrack?, TerrainScene?>>(null to null, track, ghostTrack) {
        val t = track
        value = if (t == null) null to null else t to TerrainBuilder.build(appCtx, t, ghostTrack) { status = it }
    }
    val scene = if (track != null && sceneRes.first === track) sceneRes.second else null
    val sceneLoading = track != null && sceneRes.first !== track
    val race = remember(track, ghostTrack, scene) {
        if (track != null && ghostTrack != null && scene?.ghostX != null) RouteVideoRace(track, ghostTrack) else null
    }

    val accent = remember(prefs.lineColor) { RouteVideoOverlay.accentOf(prefs) }
    val colors = remember(scene, track, prefs.lineMode, accent) {
        if (scene != null && track != null) RouteVideoColors.colors(track, prefs.lineMode, accent, scene.routeFrac) else IntArray(0)
    }
    val (pw, ph) = RouteVideoFormat.previewSize(prefs.aspect)
    val frameRes by produceState<Pair<PreviewFrame?, String?>>(
        null to null, scene, prefs.tilt, prefs.exaggeration, prefs.orbit, pos, accent, prefs.lineMode, prefs.aspect, race, colors,
        prefs.hillshade, prefs.fog,
    ) {
        val sc = scene
        if (sc == null) value = null to null
        else {
            val cam = RouteVideoCamera.at(pos.toDouble(), prefs, race)
            val key = "${prefs.lineMode}/$accent"
            val ex = prefs.exaggeration.toFloat()
            val shade = prefs.hillshade; val fogOn = prefs.fog
            value = withContext(host.dispatcher) {
                val r = runCatching { host.frame(pw, ph, sc, ex, cam, colors, key, accent, shade, fogOn) }
                if (r.isSuccess) Pair<PreviewFrame?, String?>(r.getOrNull(), null)
                else Pair<PreviewFrame?, String?>(null, r.exceptionOrNull()?.message ?: "OpenGL gagal")
            }
        }
    }
    val composed = remember(frameRes.first, prefs, pos, selected, fonts, track, race, ghostTrack, scene) {
        val fr = frameRes.first; val t = track; val sc = scene
        if (fr == null || t == null || sc == null) null
        else fr.bitmap.copy(Bitmap.Config.ARGB_8888, true)?.let { bmp ->
            val cam = RouteVideoCamera.at(pos.toDouble(), prefs, race)
            val st = t.statsAt(cam.routeFrac, prefs.live)
            val marks = RouteVideoOverlay.marksFor(sc, fr.points, t, prefs, cam.routeFrac)
            val gi = if (race != null && ghostTrack != null) GhostInfo(ghostTrack.title, race.gapSeconds(cam.routeFrac)) else null
            val bounds = RouteVideoOverlay.draw(AndroidCanvas(bmp), bmp.width, bmp.height, prefs, t, st, cam.routeFrac, fonts, selected, marks, gi)
            bmp to bounds
        }
    }
    val boundsNow by rememberUpdatedState(composed?.second ?: emptyMap<String, RectF>())
    val prefsNow by rememberUpdatedState(prefs)
    val selNow by rememberUpdatedState(selected)
    val pwNow by rememberUpdatedState(pw)
    fun hit(o: Offset, size: IntSize): String? {
        val k = pwNow / size.width.toFloat()
        return boundsNow.entries.reversed().firstOrNull { it.value.contains(o.x * k, o.y * k) }?.key
    }

    // Render latar belakang
    val job by RouteVideoJobs.state.collectAsState()
    val myKey = id.toString()
    val bgRef = rememberUpdatedState(prefs.bgRender)
    DisposableEffect(Unit) { onDispose { if (!bgRef.value) RouteVideoJobs.cancelFor(myKey) } }
    val startRender = {
        val a = e; val t = track; val sc = scene
        if (a != null && t != null && sc != null) {
            RouteVideoJobs.clearResult()
            val out = File(RouteVideoIo.cacheDir(appCtx), "rute-${a.dateIso.take(10)}-${a.id}.mp4")
            val started = RouteVideoJobs.start(appCtx, myKey, nameOf(a), sc, t, ghostTrack.takeIf { sc.ghostX != null }, prefs, fonts, out, prefs.bgRender)
            msg = if (started) "" else "Masih ada render lain yang berjalan."
        }
    }
    val startRef = rememberUpdatedState(startRender)
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { startRef.value() }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        TextButton(onClick = onBack) { Text("‹ Kembali") }
        Text("Video rute 3D", style = MaterialTheme.typography.titleLarge)
        if (e == null) { Text("Aktivitas tidak ditemukan."); return@Column }
        if (!loaded.first) { CircularProgressIndicator(Modifier.size(24.dp)); return@Column }
        if (track == null) {
            Text("Video 3D butuh rute GPS dan data per detik. Aktivitas ini tidak punya keduanya (mis. latihan indoor atau data lama).")
            return@Column
        }
        if (scene == null) {
            if (sceneLoading) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(22.dp)); Text(status)
                }
            } else Text("Peta 3D gagal disiapkan. Coba lagi saat tersambung internet.")
            return@Column
        }
        if (!scene.demOk) RvNote("Data elevasi belum terunduh (offline?), jadi medan tampil datar. Buka lagi saat online.")
        if (scene.satellite == null) RvNote("Citra satelit belum terunduh (offline?), jadi medan tampil polos. Buka lagi saat online.")
        if (ghostId != null && ghostTrack == null) RvNote("Memuat ghost…")
        if (ghostTrack != null && scene.ghostX == null) RvNote("Memuat ulang peta untuk ghost…")
        frameRes.second?.let { RvNote("Pratinjau 3D gagal: $it") }

        val widthFrac = when (prefs.aspect) { "16:9" -> 1f; "1:1" -> 0.85f; "4:5" -> 0.8f; else -> 0.74f }
        Box(
            Modifier.fillMaxWidth(widthFrac).align(Alignment.CenterHorizontally).aspectRatio(RouteVideoFormat.ratio(prefs.aspect))
                .clip(RoundedCornerShape(12.dp)).background(Color.Black)
                .pointerInput(Unit) { detectTapGestures { o -> selected = hit(o, size) } }
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { o -> selected = hit(o, size) },
                        onDragEnd = { store.save(prefsNow.sanitized()) },
                        onDragCancel = { store.save(prefsNow.sanitized()) },
                    ) { change, amt ->
                        change.consume()
                        val s = selNow
                        if (s != null) {
                            val dx = amt.x / size.width * 100.0; val dy = amt.y / size.height * 100.0
                            update(prefsNow.copy(panels = prefsNow.panels.map { if (it.key == s) it.copy(x = it.x + dx, y = it.y + dy) else it }), persist = false)
                        }
                    }
                },
            contentAlignment = Alignment.Center,
        ) {
            val c = composed
            if (c == null) { if (frameRes.second == null) CircularProgressIndicator(Modifier.size(28.dp)) }
            else Image(c.first.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
        }
        RvSlider("Posisi pratinjau (waktu video)", pos, 0f..1f, "${(pos * prefs.durationSec).roundToInt()} dtk") { pos = it }

        // ---- Render ----
        val running = job as? RenderState.Running
        val done = (job as? RenderState.Done)?.takeIf { it.key == myKey }
        val failed = (job as? RenderState.Failed)?.takeIf { it.key == myKey }
        if (running != null) {
            LinearProgressIndicator(progress = { running.progress }, modifier = Modifier.fillMaxWidth())
            Text(
                if (running.key == myKey) "Membuat video… ${(running.progress * 100).roundToInt()}%. Boleh tutup layar ini; render lanjut di latar belakang."
                else "Masih membuat video “${running.label}” (${(running.progress * 100).roundToInt()}%).",
                style = MaterialTheme.typography.bodyMedium,
            )
            if (running.key == myKey) OutlinedButton(onClick = { RouteVideoJobs.cancel() }) { Text("Batal") }
        } else {
            val (vw, vh) = RouteVideoFormat.size(prefs.aspect, prefs.quality)
            Button(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    if (prefs.bgRender && Build.VERSION.SDK_INT >= 33 && !askedPerm &&
                        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                    ) { askedPerm = true; permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
                    else startRender()
                },
            ) { Text("Buat video ($vw×$vh)") }
            if (failed != null) Text("Gagal membuat video: ${failed.message}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            if (done != null) {
                Text("Video siap.", style = MaterialTheme.typography.bodyMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        RouteVideoIo.saveToGallery(appCtx, done.file, done.file.name)
                            .onSuccess { msg = "Tersimpan di $it." }.onFailure { msg = "Gagal menyimpan: ${it.message}" }
                    }) { Text("Simpan ke galeri") }
                    OutlinedButton(onClick = { RouteVideoIo.share(ctx, done.file).onFailure { msg = "Gagal membagikan: ${it.message}" } }) { Text("Bagikan") }
                }
            }
        }
        if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        FilterChip(
            selected = prefs.bgRender, onClick = { update(prefs.copy(bgRender = !prefs.bgRender)) },
            label = { Text("Lanjut di latar belakang (notifikasi)") },
        )
        if (!prefs.bgRender) {
            Text("Mati: render berhenti bila layar ini ditutup dan tidak ada notifikasi progres.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        // ---- Tata letak (preset) ----
        RvSection("Tata letak", "Pilih susunan siap pakai atau simpan susunanmu sendiri.") {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                (RouteVideoPresets.BUILT_IN + prefs.presets).forEach { pr ->
                    FilterChip(
                        selected = prefs.asPreset(pr.name) == pr,
                        onClick = { update(prefs.withPreset(pr)); selected = null },
                        label = { Text(pr.name) },
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { presetName = ""; showSave = true }) { Text("Simpan tata letak ini") }
                if (prefs.presets.isNotEmpty()) OutlinedButton(onClick = { showManage = true }) { Text("Hapus…") }
            }
        }

        // ---- Data di video ----
        RvSection("Data di video", "Ketuk panel di pratinjau untuk memilih, lalu geser untuk memindahkan.") {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                RouteVideoKeys.ALL.filter { it != "ghost" || ghostTrack != null }.forEach { k ->
                    val on = prefs.panels.any { it.key == k }
                    FilterChip(
                        selected = on,
                        onClick = {
                            if (on) { update(prefs.copy(panels = prefs.panels.filter { it.key != k })); if (selected == k) selected = null }
                            else { update(prefs.copy(panels = prefs.panels + RouteVideoKeys.defaultPanel(k))); selected = k }
                        },
                        label = { Text(RouteVideoKeys.name(k)) },
                    )
                }
            }
            if (prefs.lineMode == "solid" && prefs.panels.any { it.key == "legenda" }) {
                Text("Legenda hanya tampil bila warna garis memakai data (HR, pace, atau gradien).", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            val sp = prefs.panels.firstOrNull { it.key == selected }
            if (sp == null) {
                Text("Belum ada panel dipilih.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                Text("Panel dipilih: ${RouteVideoKeys.name(sp.key)}", style = MaterialTheme.typography.titleSmall)
                RvSlider("Ukuran", sp.size.toFloat(), RouteVideoKeys.MIN_SIZE.toFloat()..RouteVideoKeys.MAX_SIZE.toFloat(), "${sp.size}%") { v ->
                    update(prefs.copy(panels = prefs.panels.map { if (it.key == sp.key) it.copy(size = v.roundToInt()) else it }))
                }
                fun nudge(dx: Double, dy: Double) =
                    update(prefs.copy(panels = prefs.panels.map { if (it.key == sp.key) it.copy(x = it.x + dx, y = it.y + dy) else it }))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Geser halus", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    OutlinedButton(onClick = { nudge(-0.5, 0.0) }) { Text("←") }
                    OutlinedButton(onClick = { nudge(0.0, -0.5) }) { Text("↑") }
                    OutlinedButton(onClick = { nudge(0.0, 0.5) }) { Text("↓") }
                    OutlinedButton(onClick = { nudge(0.5, 0.0) }) { Text("→") }
                }
                OutlinedButton(onClick = {
                    val d = RouteVideoKeys.defaultPanel(sp.key)
                    update(prefs.copy(panels = prefs.panels.map { if (it.key == sp.key) d else it }))
                }) { Text("Kembalikan panel ini ke bawaan") }
            }
            OutlinedButton(onClick = { update(prefs.copy(panels = RouteVideoKeys.defaultLayout())); selected = null }) { Text("Reset semua tata letak") }
        }

        // ---- Format ----
        RvSection("Format", "Rasio 9:16 untuk Story/Reels, 4:5 dan 1:1 untuk feed, 16:9 untuk layar lebar.") {
            RvChips(RouteVideoFormat.ASPECTS.map { it to it }, prefs.aspect) { update(prefs.copy(aspect = it)) }
            RvChips(listOf("hd" to "HD (1080 px)", "sd" to "Ringan (720 px)"), prefs.quality) { update(prefs.copy(quality = it)) }
        }

        // ---- Garis rute ----
        RvSection("Garis rute", null) {
            RvLabel("Warna menurut")
            RvChips(RouteVideoColors.MODES.map { it to RouteVideoColors.modeName(it) }, prefs.lineMode) { update(prefs.copy(lineMode = it)) }
            RvLabel(if (prefs.lineMode == "solid") "Warna garis" else "Warna penanda posisi")
            RvChips(LINE_COLORS.map { it.second to it.first }, LINE_COLORS.firstOrNull { it.second.equals(prefs.lineColor, true) }?.second ?: "") { update(prefs.copy(lineColor = it)) }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = prefs.kmMarkers, onClick = { update(prefs.copy(kmMarkers = !prefs.kmMarkers)) }, label = { Text("Bendera per km") })
                FilterChip(selected = prefs.flagEnds, onClick = { update(prefs.copy(flagEnds = !prefs.flagEnds)) }, label = { Text("Start dan finish") })
                FilterChip(selected = prefs.flagPeak, onClick = { update(prefs.copy(flagPeak = !prefs.flagPeak)) }, label = { Text("Puncak") })
                FilterChip(selected = prefs.flagSteep, onClick = { update(prefs.copy(flagSteep = !prefs.flagSteep)) }, label = { Text("Tanjakan terberat") })
            }
        }

        // ---- Ghost ----
        RvSection("Balapan dengan ghost", "Bandingkan dengan aktivitas lain di rute serupa. Keduanya berjalan menurut waktu yang sama.") {
            if (ghostTrack != null) {
                Text(
                    "Ghost: ${ghostTrack.title} · ${RouteVideoText.dateId(ghostEntity?.dateIso ?: "")} · ${Js.fmtKm(ghostTrack.totalM / 1000.0)} km · ${Js.durStr(ghostTrack.totalSec / 60.0)}",
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { ghostMsg = ""; showGhostPicker = true }) { Text(if (ghostTrack != null) "Ganti ghost" else "Pilih ghost") }
                if (ghostId != null) OutlinedButton(onClick = { ghostId = null; ghostMsg = "" }) { Text("Hapus ghost") }
            }
            if (ghostMsg.isNotEmpty()) RvNote(ghostMsg)
        }

        // ---- Peta 3D ----
        RvSection("Peta 3D", null) {
            RvSlider("Kemiringan kamera", prefs.tilt.toFloat(), 20f..80f, "${prefs.tilt}°") { update(prefs.copy(tilt = it.roundToInt())) }
            RvSlider("Skala elevasi (1× = sesuai aslinya)", prefs.exaggeration.toFloat(), 1f..4f, String.format(java.util.Locale.US, "%.1f×", prefs.exaggeration)) {
                update(prefs.copy(exaggeration = (it * 10).roundToInt() / 10.0))
            }
            RvSlider("Putaran kamera", prefs.orbit.toFloat(), 0f..180f, "${prefs.orbit}°") { update(prefs.copy(orbit = it.roundToInt())) }
            RvSlider("Durasi video", prefs.durationSec.toFloat(), 6f..40f, "${prefs.durationSec} dtk") { update(prefs.copy(durationSec = it.roundToInt())) }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = prefs.hillshade, onClick = { update(prefs.copy(hillshade = !prefs.hillshade)) }, label = { Text("Bayangan relief") })
                FilterChip(selected = prefs.fog, onClick = { update(prefs.copy(fog = !prefs.fog)) }, label = { Text("Kabut jarak") })
            }
        }

        // ---- Tampilan ----
        RvSection("Tampilan", null) {
            RvLabel("Angka")
            RvChips(listOf("live" to "Berjalan", "total" to "Total / rata-rata"), if (prefs.live) "live" else "total") { update(prefs.copy(live = it == "live")) }
            RvLabel("Warna teks")
            RvChips(listOf("w" to "Putih", "k" to "Hitam", "l" to "Lime"), prefs.ink) { update(prefs.copy(ink = it)) }
            RvLabel("Latar panel")
            RvChips(listOf("off" to "Mati", "soft" to "Lembut", "strong" to "Tebal"), prefs.panelBg) { update(prefs.copy(panelBg = it)) }
        }

        // ---- Offline ----
        RvSection("Peta offline", "Unduh ubin satelit dan elevasi sekarang supaya video bisa dibuat tanpa internet. Tersimpan di cache aplikasi (sistem bisa membersihkannya saat penyimpanan penuh).") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(enabled = !prefetching, onClick = {
                    scope.launch {
                        prefetching = true
                        try {
                            val failedTiles = TerrainBuilder.prefetch(appCtx, listOfNotNull(track, ghostTrack)) { prefetchMsg = it }
                            prefetchMsg = if (failedTiles == 0) "Peta aktivitas ini tersimpan untuk offline." else "$failedTiles ubin gagal diunduh. Coba lagi saat sinyal baik."
                        } finally { prefetching = false }
                    }
                }) { Text("Aktivitas ini") }
                OutlinedButton(enabled = !prefetching, onClick = {
                    scope.launch {
                        prefetching = true
                        try {
                            val recent = state.activities.filter { it.detailFile != null && it.km > 0 }.sortedByDescending { it.dateIso }.take(10)
                            val tracks = ArrayList<RouteVideoTrack>()
                            recent.forEachIndexed { i, a ->
                                prefetchMsg = "Membaca aktivitas ${i + 1}/${recent.size}…"
                                load(a)?.let { d -> RouteVideoTrack.from(d, nameOf(a), "")?.let { tracks.add(it) } }
                            }
                            val failedTiles = TerrainBuilder.prefetch(appCtx, tracks) { prefetchMsg = it }
                            prefetchMsg = if (failedTiles == 0) "Peta ${tracks.size} aktivitas terakhir tersimpan untuk offline." else "$failedTiles ubin gagal diunduh. Coba lagi saat sinyal baik."
                        } finally { prefetching = false }
                    }
                }) { Text("10 aktivitas terakhir") }
            }
            if (prefetching) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            if (prefetchMsg.isNotEmpty()) Text(prefetchMsg, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Text(
            "Peta satelit © Esri, Maxar, Earthstar Geographics · elevasi dari AWS Terrain Tiles (Mapzen, SRTM, dll.).",
            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        // ---- Dialog ----
        if (showSave) {
            val clash = RouteVideoPresets.isBuiltIn(presetName.trim())
            AlertDialog(
                onDismissRequest = { showSave = false },
                title = { Text("Simpan tata letak") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = presetName, onValueChange = { presetName = it.take(24) }, label = { Text("Nama") }, singleLine = true)
                        if (clash) RvNote("Nama itu dipakai tata letak bawaan.")
                        Text("Menyimpan posisi dan ukuran panel, warna teks, latar panel, mode angka, dan pilihan garis rute.", style = MaterialTheme.typography.bodySmall)
                    }
                },
                confirmButton = {
                    TextButton(enabled = presetName.isNotBlank() && !clash, onClick = {
                        val pr = prefs.asPreset(presetName.trim())
                        update(prefs.copy(presets = (prefs.presets.filter { it.name != pr.name } + pr).takeLast(12)))
                        showSave = false
                    }) { Text("Simpan") }
                },
                dismissButton = { TextButton(onClick = { showSave = false }) { Text("Batal") } },
            )
        }
        if (showManage) {
            AlertDialog(
                onDismissRequest = { showManage = false },
                title = { Text("Hapus tata letak") },
                text = {
                    Column(Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        if (prefs.presets.isEmpty()) Text("Tidak ada tata letak buatanmu.")
                        prefs.presets.forEach { pr ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text(pr.name, Modifier.weight(1f))
                                TextButton(onClick = { update(prefs.copy(presets = prefs.presets.filter { it.name != pr.name })) }) { Text("Hapus") }
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showManage = false }) { Text("Selesai") } },
            )
        }
        if (showGhostPicker) {
            val candidates = state.activities
                .filter { it.id != e.id && it.type == e.type && it.detailFile != null && it.km > 0 && abs(it.km - e.km) <= e.km * 0.3 }
                .sortedByDescending { it.dateIso }.take(30)
            AlertDialog(
                onDismissRequest = { showGhostPicker = false },
                title = { Text("Pilih ghost") },
                text = {
                    Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("Aktivitas sejenis dengan jarak serupa (±30%). Pilih yang rutenya sama agar balapannya berarti.", style = MaterialTheme.typography.bodySmall)
                        if (candidates.isEmpty()) Text("Belum ada aktivitas yang cocok.", style = MaterialTheme.typography.bodyMedium)
                        candidates.forEach { a ->
                            Text(
                                "${RouteVideoText.dateId(a.dateIso)} · ${nameOf(a)} · ${Js.fmtKm(a.km)} km · ${Js.durStr(a.durationSec / 60.0)}",
                                Modifier.fillMaxWidth().clickable { ghostId = a.id; ghostMsg = ""; showGhostPicker = false }.padding(vertical = 10.dp),
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showGhostPicker = false }) { Text("Batal") } },
            )
        }
    }
}

@Composable
private fun RvLabel(t: String) = Text(t, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

@Composable
private fun RvNote(t: String) = Text(t, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RvChips(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (k, n) -> FilterChip(selected = selected == k, onClick = { onSelect(k) }, label = { Text(n) }) }
    }
}

@Composable
private fun RvSection(title: String, sub: String?, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        content()
    }
}

@Composable
private fun RvSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, valueText: String, onChange: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            RvLabel(label); RvLabel(valueText)
        }
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range)
    }
}
