package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.i18n.Text
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.RectF
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.data.TerrainBuilder
import com.endurancevault.app.data.TerrainScene
import com.endurancevault.app.domain.ActDetail
import com.endurancevault.app.domain.RouteVideoCamera
import com.endurancevault.app.domain.RouteVideoKeys
import com.endurancevault.app.domain.RouteVideoPrefs
import com.endurancevault.app.domain.RouteVideoText
import com.endurancevault.app.domain.RouteVideoTrack
import com.endurancevault.app.ui.UiState
import com.endurancevault.app.ui.sticker.StickerFontStore
import com.endurancevault.app.ui.sticker.StickerFonts
import com.endurancevault.app.ui.sticker.StickerPrefsStore
import com.endurancevault.app.ui.video.PreviewGl
import com.endurancevault.app.ui.video.RouteVideoEncoder
import com.endurancevault.app.ui.video.RouteVideoIo
import com.endurancevault.app.ui.video.RouteVideoOverlay
import com.endurancevault.app.ui.video.RouteVideoPrefsStore
import java.io.File
import java.util.concurrent.CancellationException
import java.util.concurrent.Executors
import kotlinx.coroutines.Job
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

private val LINE_COLORS = listOf("Lime" to "#C6F432", "Oranye" to "#FF7A1A", "Cyan" to "#27D3FF", "Merah" to "#FF3B4E", "Putih" to "#FFFFFF")

/**
 * Video rute 3D: peta satelit berelief sesuai elevasi, rute tergambar bertahap, dan panel data
 * (jarak, waktu, pace, HR, gradien, elevasi, dst.) yang posisi dan ukurannya bisa diatur dengan menggeser di pratinjau.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RouteVideoScreen(state: UiState, id: Long, load: suspend (ActivityEntity) -> ActDetail?, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val appCtx = ctx.applicationContext
    val scope = rememberCoroutineScope()
    val store = remember { RouteVideoPrefsStore(appCtx) }
    var prefs by remember { mutableStateOf(store.load()) }
    var selected by remember { mutableStateOf<String?>(null) }
    fun update(p: RouteVideoPrefs, persist: Boolean = true) { prefs = p.sanitized(); if (persist) store.save(prefs) }

    // Semua pekerjaan OpenGL (pratinjau dan render) berjalan di satu thread khusus.
    val executor = remember { Executors.newSingleThreadExecutor() }
    val glDispatcher = remember { executor.asCoroutineDispatcher() }
    val preview = remember { PreviewGl() }
    DisposableEffect(Unit) { onDispose { executor.execute { preview.release() }; executor.shutdown() } }

    val stk = remember { StickerPrefsStore(appCtx).load() }
    val fontStore = remember { StickerFontStore(appCtx) }
    val fonts = remember(stk.fontNum, stk.fontBody) { StickerFonts(fontStore.typeface(stk.fontNum), fontStore.typeface(stk.fontBody)) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        TextButton(onClick = onBack) { Text("‹ Kembali") }
        Text("Video rute 3D", style = MaterialTheme.typography.titleLarge)
        val e = state.activities.firstOrNull { it.id == id }
        if (e == null) { Text("Aktivitas tidak ditemukan."); return@Column }
        val loaded by produceState<Pair<Boolean, ActDetail?>>(false to null, e.id, e.detailFile, e.km, e.durationSec, e.type) { value = true to load(e) }
        if (!loaded.first) { CircularProgressIndicator(Modifier.size(24.dp)); return@Column }
        val track = remember(loaded.second) {
            loaded.second?.let { RouteVideoTrack.from(it, e.name.ifBlank { if (e.type == "bike") "Gowes" else "Lari" }, RouteVideoText.dateId(e.dateIso)) }
        }
        if (track == null) {
            Text("Video 3D butuh rute GPS dan data per detik. Aktivitas ini tidak punya keduanya (mis. latihan indoor atau data lama).")
            return@Column
        }

        var status by remember { mutableStateOf("Menyiapkan peta…") }
        val sceneRes by produceState<Pair<Boolean, TerrainScene?>>(false to null, track) {
            value = true to TerrainBuilder.build(appCtx, track.lat, track.lon, track.dist) { status = it }
        }
        if (!sceneRes.first) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(22.dp)); Text(status)
            }
            return@Column
        }
        val scene = sceneRes.second
        if (scene == null) { Text("Peta 3D gagal disiapkan. Coba lagi saat tersambung internet."); return@Column }
        if (!scene.demOk) RvNote("Data elevasi belum terunduh (offline?), jadi medan tampil datar. Buka lagi saat online.")
        if (scene.satellite == null) RvNote("Citra satelit belum terunduh (offline?), jadi medan tampil polos. Buka lagi saat online.")

        var pos by remember { mutableStateOf(0.5f) }
        val accent = remember(prefs.lineColor) { RouteVideoOverlay.accentOf(prefs) }
        val bg by produceState<Pair<Bitmap?, String?>>(null to null, scene, prefs.tilt, prefs.exaggeration, prefs.orbit, pos, accent) {
            val cam = RouteVideoCamera.at(pos.toDouble(), prefs)
            val ex = prefs.exaggeration.toFloat()
            value = withContext(glDispatcher) {
                val r = runCatching { preview.frame(scene, ex, cam, accent) }
                if (r.isSuccess) Pair<Bitmap?, String?>(r.getOrNull(), null)
                else Pair<Bitmap?, String?>(null, r.exceptionOrNull()?.message ?: "OpenGL gagal")
            }
        }
        val composed = remember(bg.first, prefs, pos, selected, fonts, track) {
            bg.first?.copy(Bitmap.Config.ARGB_8888, true)?.let { bmp ->
                val cam = RouteVideoCamera.at(pos.toDouble(), prefs)
                val st = track.statsAt(cam.routeFrac, prefs.live)
                val bounds = RouteVideoOverlay.draw(AndroidCanvas(bmp), bmp.width, bmp.height, prefs, track, st, cam.routeFrac, fonts, selected)
                bmp to bounds
            }
        }
        val boundsNow by rememberUpdatedState(composed?.second ?: emptyMap<String, RectF>())
        val prefsNow by rememberUpdatedState(prefs)
        val selNow by rememberUpdatedState(selected)
        fun hit(o: Offset, size: IntSize): String? {
            val k = PreviewGl.W / size.width.toFloat()
            return boundsNow.entries.reversed().firstOrNull { it.value.contains(o.x * k, o.y * k) }?.key
        }

        bg.second?.let { RvNote("Pratinjau 3D gagal: $it") }
        Box(
            Modifier.fillMaxWidth(0.74f).align(Alignment.CenterHorizontally).aspectRatio(9f / 16f)
                .clip(RoundedCornerShape(12.dp)).background(Color.Black)
                .pointerInput(Unit) { detectTapGestures { o -> selected = hit(o, size) } }
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { o -> selected = hit(o, size) },
                        onDragEnd = { store.save(prefsNow.sanitized()) },
                        onDragCancel = { store.save(prefsNow.sanitized()) },
                    ) { change, amt ->
                        change.consume()
                        val s = selNow
                        if (s != null) {
                            val dx = amt.x / size.width * 100.0; val dy = amt.y / size.height * 100.0
                            update(prefsNow.copy(panels = prefsNow.panels.map { if (it.key == s) it.copy(x = it.x + dx, y = it.y + dy) else it }), persist = false)
                        }
                    }
                },
            contentAlignment = Alignment.Center,
        ) {
            val c = composed
            if (c == null) { if (bg.second == null) CircularProgressIndicator(Modifier.size(28.dp)) }
            else Image(c.first.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
        }
        RvSlider("Posisi pratinjau (waktu video)", pos, 0f..1f, "${(pos * prefs.durationSec).roundToInt()} dtk") { pos = it }

        // ---- Data di video ----
        RvSection("Data di video", "Ketuk panel di pratinjau untuk memilih, lalu geser untuk memindahkan.") {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                RouteVideoKeys.ALL.forEach { k ->
                    val on = prefs.panels.any { it.key == k }
                    FilterChip(
                        selected = on,
                        onClick = {
                            if (on) { update(prefs.copy(panels = prefs.panels.filter { it.key != k })); if (selected == k) selected = null }
                            else { update(prefs.copy(panels = prefs.panels + RouteVideoKeys.defaultPanel(k))); selected = k }
                        },
                        label = { Text(RouteVideoKeys.name(k)) },
                    )
                }
            }
            val sp = prefs.panels.firstOrNull { it.key == selected }
            if (sp == null) {
                Text("Belum ada panel dipilih.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                Text("Panel dipilih: ${RouteVideoKeys.name(sp.key)}", style = MaterialTheme.typography.titleSmall)
                RvSlider("Ukuran", sp.size.toFloat(), RouteVideoKeys.MIN_SIZE.toFloat()..RouteVideoKeys.MAX_SIZE.toFloat(), "${sp.size}%") { v ->
                    update(prefs.copy(panels = prefs.panels.map { if (it.key == sp.key) it.copy(size = v.roundToInt()) else it }))
                }
                fun nudge(dx: Double, dy: Double) =
                    update(prefs.copy(panels = prefs.panels.map { if (it.key == sp.key) it.copy(x = it.x + dx, y = it.y + dy) else it }))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Geser halus", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    OutlinedButton(onClick = { nudge(-0.5, 0.0) }) { Text("←") }
                    OutlinedButton(onClick = { nudge(0.0, -0.5) }) { Text("↑") }
                    OutlinedButton(onClick = { nudge(0.0, 0.5) }) { Text("↓") }
                    OutlinedButton(onClick = { nudge(0.5, 0.0) }) { Text("→") }
                }
                OutlinedButton(onClick = {
                    val d = RouteVideoKeys.defaultPanel(sp.key)
                    update(prefs.copy(panels = prefs.panels.map { if (it.key == sp.key) d else it }))
                }) { Text("Kembalikan panel ini ke bawaan") }
            }
            OutlinedButton(onClick = { update(prefs.copy(panels = RouteVideoKeys.defaultLayout())); selected = null }) { Text("Reset semua tata letak") }
        }

        // ---- Peta 3D ----
        RvSection("Peta 3D", null) {
            RvSlider("Kemiringan kamera", prefs.tilt.toFloat(), 20f..80f, "${prefs.tilt}°") { update(prefs.copy(tilt = it.roundToInt())) }
            RvSlider("Skala elevasi (1× = sesuai aslinya)", prefs.exaggeration.toFloat(), 1f..4f, String.format(java.util.Locale.US, "%.1f×", prefs.exaggeration)) {
                update(prefs.copy(exaggeration = (it * 10).roundToInt() / 10.0))
            }
            RvSlider("Putaran kamera", prefs.orbit.toFloat(), 0f..180f, "${prefs.orbit}°") { update(prefs.copy(orbit = it.roundToInt())) }
            RvSlider("Durasi video", prefs.durationSec.toFloat(), 6f..40f, "${prefs.durationSec} dtk") { update(prefs.copy(durationSec = it.roundToInt())) }
        }

        // ---- Tampilan ----
        RvSection("Tampilan", null) {
            RvLabel("Angka")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = prefs.live, onClick = { update(prefs.copy(live = true)) }, label = { Text("Berjalan") })
                FilterChip(selected = !prefs.live, onClick = { update(prefs.copy(live = false)) }, label = { Text("Total / rata-rata") })
            }
            RvLabel("Warna teks")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("w" to "Putih", "k" to "Hitam", "l" to "Lime").forEach { (k, n) ->
                    FilterChip(selected = prefs.ink == k, onClick = { update(prefs.copy(ink = k)) }, label = { Text(n) })
                }
            }
            RvLabel("Latar panel")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("off" to "Mati", "soft" to "Lembut", "strong" to "Tebal").forEach { (k, n) ->
                    FilterChip(selected = prefs.panelBg == k, onClick = { update(prefs.copy(panelBg = k)) }, label = { Text(n) })
                }
            }
            RvLabel("Warna garis rute")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LINE_COLORS.forEach { (n, hex) ->
                    FilterChip(selected = prefs.lineColor.equals(hex, ignoreCase = true), onClick = { update(prefs.copy(lineColor = hex)) }, label = { Text(n) })
                }
            }
        }

        // ---- Render ----
        var rendering by remember { mutableStateOf(false) }
        var progress by remember { mutableStateOf(0f) }
        var outFile by remember { mutableStateOf<File?>(null) }
        var msg by remember { mutableStateOf("") }
        var renderJob by remember { mutableStateOf<Job?>(null) }

        if (rendering) {
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
            Text("Membuat video… ${(progress * 100).roundToInt()}%", style = MaterialTheme.typography.bodyMedium)
            OutlinedButton(onClick = { renderJob?.cancel(); msg = "Dibatalkan." }) { Text("Batal") }
        } else {
            Button(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    val snapshot = prefs
                    renderJob = scope.launch {
                        val self = this
                        rendering = true; progress = 0f; msg = ""; outFile = null
                        try {
                            val out = File(RouteVideoIo.cacheDir(appCtx), "rute-${e.dateIso.take(10)}-${e.id}.mp4")
                            val r = withContext(glDispatcher) {
                                RouteVideoEncoder.encode(scene, track, snapshot, fonts, out, { self.isActive }, { progress = it })
                            }
                            r.onSuccess { outFile = out; msg = "Video siap (${snapshot.durationSec} dtk, 1080×1920)." }
                                .onFailure { msg = if (it is CancellationException) "Dibatalkan." else "Gagal membuat video: ${it.message}" }
                        } finally { rendering = false }
                    }
                },
            ) { Text("Buat video") }
            val f = outFile
            if (f != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        RouteVideoIo.saveToGallery(appCtx, f, f.name)
                            .onSuccess { msg = "Tersimpan di $it." }.onFailure { msg = "Gagal menyimpan: ${it.message}" }
                    }) { Text("Simpan ke galeri") }
                    OutlinedButton(onClick = { RouteVideoIo.share(ctx, f).onFailure { msg = "Gagal membagikan: ${it.message}" } }) { Text("Bagikan") }
                }
            }
        }
        if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            "Peta satelit © Esri, Maxar, Earthstar Geographics · elevasi dari AWS Terrain Tiles (Mapzen, SRTM, dll.).",
            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun RvLabel(t: String) = Text(t, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

@Composable
private fun RvNote(t: String) = Text(t, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)

@Composable
private fun RvSection(title: String, sub: String?, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        content()
    }
}

@Composable
private fun RvSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, valueText: String, onChange: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            RvLabel(label); RvLabel(valueText)
        }
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range)
    }
}
