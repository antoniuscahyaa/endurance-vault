package com.endurancevault.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.clickable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.endurancevault.app.domain.Kinds
import com.endurancevault.app.domain.Phases
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.ui.UiState
import java.time.format.TextStyle
import java.util.Locale

private val ID = Locale("id", "ID")

private fun phaseLabel(p: String, rec: Boolean) = when {
    rec -> "Pemulihan"
    p == Phases.BASE -> "Fondasi"
    p == Phases.BUILD -> "Bangun"
    p == Phases.PEAK -> "Puncak"
    else -> "Taper"
}

@Composable
fun ScheduleScreen(state: UiState) {
    when (val p = state.plan) {
        is PlanOutcome.Err -> Text(p.message, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.error)
        is PlanOutcome.Ok -> LazyColumn(
            Modifier.padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item { Text("Jadwal", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(top = 16.dp)) }
            items(p.weeks, key = { it.i }) { w ->
                var open by remember { mutableStateOf(false) }
                Card(Modifier.fillMaxWidth().clickable { open = !open }) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(
                                "Minggu ${w.i + 1} · ${phaseLabel(w.phase, w.rec)}" + (if (w.cut) " · cut" else ""),
                                style = MaterialTheme.typography.titleMedium,
                            )
                            Text("${fmtKmUi(w.km)} km", color = MaterialTheme.colorScheme.primary)
                        }
                        w.days.forEach { d ->
                            val dow = d.date.dayOfWeek.getDisplayName(TextStyle.SHORT, ID)
                            val label = if (d.kind == Kinds.REST) "Libur" else "${d.title} · ${fmtKmUi(d.km)} km"
                            Text("$dow ${d.date.dayOfMonth}  $label", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            if (open && d.detail.isNotBlank()) {
                                Text(d.detail, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(bottom = 6.dp))
                            }
                            SupportBlocks(d, expanded = open)
                        }
                    }
                }
            }
        }
    }
}
