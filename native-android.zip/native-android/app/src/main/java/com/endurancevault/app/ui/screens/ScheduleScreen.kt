package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.i18n.Text
import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FileDownload
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.sp
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.ui.theme.Ember
import com.endurancevault.app.ui.theme.Fire
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.endurancevault.app.data.ReadinessHistoryStore
import com.endurancevault.app.domain.*
import com.endurancevault.app.ui.UiState
import org.json.JSONArray
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale


/**
 * Tab Minggu native. Logika tukar hari, libur dadakan (bagi km), geser/lewati sesi terlewat dan penanda selesai
 * disamakan dengan rencana-lari (web); perhitungannya ada di domain/SessionAdjust.kt, penyimpanannya di kv `mv` dan `done`
 * (format yang sama dengan cadangan web).
 */
@OptIn(ExperimentalLayoutApi::class, ExperimentalFoundationApi::class)
@Composable
fun ScheduleScreen(
    state: UiState,
    onOpenActivity: (Long) -> Unit = {},
    onSetMv: (String, MvEntry?) -> Unit = { _, _ -> },
    onSetDone: (String, Boolean) -> Unit = { _, _ -> },
    onImportTracks: (List<Uri>) -> Unit = {},
    trackMsg: String? = null,
    initialHistory: Boolean = false,
    initialTabNonce: Int = 0,
) {
    val today = LocalDate.now()
    val ctx = LocalContext.current
    var history by remember(initialTabNonce) { mutableStateOf(initialHistory) }
    var expanded by remember { mutableStateOf<Set<String>>(emptySet()) }
    var planOpen by rememberSaveable { mutableStateOf(false) }
    var statsOpen by rememberSaveable { mutableStateOf(false) }
    var mainMetric by remember { mutableStateOf(ctx.getSharedPreferences("week_dock", Context.MODE_PRIVATE).getString("main_metric", "distance") ?: "distance") }
    var pendingSwap by remember { mutableStateOf<Pair<PDay, DayOption>?>(null) }
    var spreadFor by remember { mutableStateOf<LocalDate?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> if (uris.isNotEmpty()) onImportTracks(uris) }
    val inp = remember(state.mv, state.done, state.activities, state.settings.hr) {
        AdjInput(today, state.mv, state.done, SessionAdjust.loggedKm(state.activities), state.settings.hr)
    }
    val metrics = remember(state.settings, state.activities, state.daily, state.plan, state.hrHistByActivity) {
        TrainingMetrics.calculate(state.settings, state.activities, state.daily, state.plan, hrHistByActivity = state.hrHistByActivity)
    }

    when (val plan = state.plan) {
        is PlanOutcome.Err -> Text(plan.message, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.error)
        is PlanOutcome.Ok -> {
            val week = plan.weeks.firstOrNull { !today.isBefore(it.start) && !today.isAfter(it.end) }
                ?: plan.weeks.firstOrNull { !it.end.isBefore(today) } ?: plan.weeks.lastOrNull()
            val fig = remember(week, plan, metrics, state.activities, state.hrHistByActivity, state.settings) {
                week?.let { wkFigures(state, it, plan.weeks, metrics) }
            }
            LazyColumn(
                Modifier.fillMaxSize().padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 16.dp),
            ) {
                stickyHeader {
                    Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface)) {
                        Spacer(Modifier.height(8.dp))
                        WkTabs(history) { history = it }
                        Spacer(Modifier.height(8.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    }
                }
                if (!history) {
                    if (week == null || fig == null) item { Text("Belum ada pekan latihan.") }
                    else {
                        item { WkPlanCard(plan, week, state, planOpen) { planOpen = !planOpen } }
                        item {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                WkPill("Import", Icons.Outlined.FileDownload, Modifier.weight(1f)) { picker.launch(arrayOf("*/*")) }
                                WkPill("Share", Icons.Outlined.Share, Modifier.weight(1f)) {
                                    wkShare(ctx, "Share week", wkWeekShareText(week, plan, state.settings, fig))
                                }
                            }
                        }
                        if (!trackMsg.isNullOrBlank()) item { Text(trackMsg, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        item {
                            WkStatsCard(
                                fig, mainMetric,
                                onSetMain = { k ->
                                    mainMetric = k
                                    ctx.getSharedPreferences("week_dock", Context.MODE_PRIVATE).edit().putString("main_metric", k).apply()
                                },
                                open = statsOpen, onToggle = { statsOpen = !statsOpen },
                            )
                        }
                    }
                    val days = week?.days.orEmpty()
                    if (days.isEmpty()) item { Text("Belum ada jadwal minggu ini.") }
                    if (days.isNotEmpty()) item {
                        // semua kartu hari digabung jadi satu blok dengan jarak sangat tipis
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            days.forEachIndexed { i, d ->
                                key(d.date.toString()) {
                                    DayBlock(
                                        d = d, state = state, today = today, open = d.date.toString() in expanded,
                                        isFirstDay = i == 0, isLastDay = i == days.lastIndex,
                                        onToggle = { val k = d.date.toString(); expanded = if (k in expanded) expanded - k else expanded + k },
                                        expandedKeys = expanded,
                                        onToggleKey = { k -> expanded = if (k in expanded) expanded - k else expanded + k },
                                        onOpenActivity = onOpenActivity, onSetMv = onSetMv, onSetDone = onSetDone,
                                        askSwap = { opt ->
                                            if (opt.warn) { pendingSwap = d to opt }
                                            else { onSetMv("sw:${d.date}", MvEntry("sw", to = opt.date.toString())) }
                                        },
                                        openSpread = { spreadFor = d.date },
                                    )
                                }
                            }
                        }
                    }
                } else {
                    item { ActivityHistoryContent(state, onOpenActivity) }
                    item { Text("RIWAYAT PENYESUAIAN", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary) }
                    val entries = state.mv.filterValues { it.raw == null }.toList().sortedByDescending { it.first.removePrefix("sw:") }
                    items(entries, key = { it.first }) { (key, e) -> AdjustmentRow(key, e) { onSetMv(key, null) } }
                    if (entries.isEmpty()) item { Text("Belum ada penyesuaian jadwal.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            }

            pendingSwap?.let { (src, opt) ->
                AlertDialog(
                    onDismissRequest = { pendingSwap = null },
                    title = { Text("Tukar ${SessionAdjust.dlabel(src)} dengan ${opt.label}?") },
                    text = { Text("Peringatan: pertukaran ini membuat dua sesi berat berurutan. Pastikan pemulihan mencukupi.", color = MaterialTheme.colorScheme.error) },
                    confirmButton = { TextButton(onClick = { onSetMv("sw:${src.date}", MvEntry("sw", to = opt.date.toString())); pendingSwap = null }) { Text("Tetap tukar") } },
                    dismissButton = { TextButton(onClick = { pendingSwap = null }) { Text("Batal") } },
                )
            }
            spreadFor?.let { date ->
                SpreadDialog(plan, inp, state.mv, date, onDismiss = { spreadFor = null }) { entry -> onSetMv(date.toString(), entry); spreadFor = null }
            }
        }
    }
}

// ---------- kartu hari ----------

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DayBlock(
    d: PDay, state: UiState, today: LocalDate, open: Boolean, onToggle: () -> Unit,
    isFirstDay: Boolean, isLastDay: Boolean,
    expandedKeys: Set<String>, onToggleKey: (String) -> Unit,
    onOpenActivity: (Long) -> Unit, onSetMv: (String, MvEntry?) -> Unit, onSetDone: (String, Boolean) -> Unit,
    askSwap: (DayOption) -> Unit, openSpread: () -> Unit,
) {
    val ctx = LocalContext.current
    val key = d.date.toString()
    val rest = d.kind == Kinds.REST
    val logged = if (rest) null else SessionAdjust.primaryRun(state.activities, key)
    val manual = key in state.done
    val completed = !rest && (logged != null || manual)
    val adj = d.adj
    val cancelled = adj?.type == "skip" || adj?.type == "out" || adj?.type == "spread"
    val missed = !rest && !completed && adj?.type == "miss"
    val cs = MaterialTheme.colorScheme
    val hard = d.kind == Kinds.QUALITY || d.kind == Kinds.LONG || d.kind == Kinds.RACE || d.kind == Kinds.EVENT
    val accent = if (hard) SolidColor(Ember) else SolidColor(WkGray)
    val dow = d.date.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.ENGLISH).uppercase()
    val status: String? = when {
        completed && logged != null -> if (d.km <= 0.0 || logged.km / d.km in 0.85..1.15) "✓ On plan" else "! Needs attention"
        completed -> "✓ Marked done"
        else -> null
    }
    val extras = state.activities.filter { it.dateIso == key && it.id != logged?.id && (it.km > 0.0 || it.durationSec > 0) }
    val hasActions = d.mvUndo || (!rest && (d.spOpt || d.swList.isNotEmpty() || (adj?.type == "miss" && !completed) || (logged == null && adj?.type != "skip")))

    val blocks = listOf(d.str, d.ank, d.up).filterNotNull()
    // total kartu dalam hari ini: kartu utama + blok gym/ankle/upper + aktivitas di luar jadwal
    val cardCount = 1 + blocks.size + extras.size
    fun shapeAt(i: Int) = wkGroupShape(first = isFirstDay && i == 0, last = isLastDay && i == cardCount - 1)
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        WkCard(shape = shapeAt(0), onClick = if (hasActions || (!rest && d.detail.isNotBlank())) onToggle else null) {
            Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
                Box(Modifier.width(4.dp).fillMaxHeight().background(accent))
                Row(Modifier.weight(1f).padding(horizontal = 10.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(Modifier.width(34.dp)) {
                        Text(dow, fontFamily = WkMono, fontSize = 9.sp, color = cs.onSurfaceVariant)
                        Text(d.date.dayOfMonth.toString(), fontSize = 18.sp, fontWeight = FontWeight.Bold, lineHeight = 20.sp)
                    }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(
                            if (rest) "Rest" else d.title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                            color = if (cancelled) cs.onSurfaceVariant else cs.onSurface,
                            textDecoration = if (cancelled) TextDecoration.LineThrough else null,
                        )
                        if (rest) Text("Complete rest.", fontSize = 11.sp, color = cs.onSurfaceVariant)
                        else if (d.detail.isNotBlank()) Text(
                            d.detail, fontSize = 11.sp, color = cs.onSurfaceVariant, lineHeight = 14.sp,
                            maxLines = if (open) Int.MAX_VALUE else 2, overflow = TextOverflow.Ellipsis,
                        )
                        if (logged != null) {
                            WkChip(wkLoggedLine(logged))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                WkSmallPill("Detail") { onOpenActivity(logged.id) }
                                WkSmallPill("Share") { wkShare(ctx, "Share session", "${dow.lowercase().replaceFirstChar { it.uppercase() }} ${d.date.dayOfMonth} · ${d.title}\n${wkLoggedLine(logged)}") }
                            }
                        }
                        if (adj != null && !(missed && adj.type == "miss")) AdjText(adj)
                        if (missed) Text("Missed · belum ada aktivitas lari tercatat", color = cs.error, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        status?.let { Text(it, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = cs.primary) }
                        methodTag(d.tm)?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = cs.tertiary) }
                        if (open && hasActions) {
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (d.mvUndo) TextButton(onClick = { onSetMv(d.mvSw ?: key, null) }) { Text("Batalkan") }
                                if (adj?.type == "miss" && !rest && !completed) {
                                    d.mvOpt?.let { o -> OutlinedButton(onClick = { onSetMv(key, MvEntry("mv", to = o.date.toString())) }) { Text("Geser ke ${o.label}") } }
                                    d.mvOptR?.let { o -> OutlinedButton(onClick = { onSetMv(key, MvEntry("mv", to = o.date.toString())) }) { Text("Tukar libur ${o.label}") } }
                                    OutlinedButton(onClick = { onSetMv(key, MvEntry("skip")) }) { Text("Lewati") }
                                    if (d.mvList.isNotEmpty()) PickButton("Pilih hari lain…", d.mvList) { o -> onSetMv(key, MvEntry("mv", to = o.date.toString())) }
                                }
                                if (!rest && d.spOpt) OutlinedButton(onClick = openSpread) { Text("Libur dadakan") }
                                if (!rest && d.swList.isNotEmpty()) PickButton("Tukar hari…", d.swList, askSwap)
                                if (!rest && logged == null && adj?.type != "skip") {
                                    OutlinedButton(onClick = { onSetDone(key, !manual) }) { Text(if (manual) "Batal tandai" else "Tandai selesai") }
                                }
                            }
                        }
                    }
                    if (!rest) Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        val mvKm = d.mvKm
                        if (cancelled && mvKm != null) Row(verticalAlignment = Alignment.Bottom) {
                            Text(SessionAdjust.ds(mvKm), fontSize = 15.sp, fontWeight = FontWeight.Bold, color = cs.onSurfaceVariant, textDecoration = TextDecoration.LineThrough)
                            Text(" km", fontSize = 10.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(bottom = 2.dp))
                        } else if (d.km > 0) Row(verticalAlignment = Alignment.Bottom) {
                            Text(SessionAdjust.ds(d.km), fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            Text(" km", fontSize = 10.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(bottom = 2.dp))
                        }
                        WkDoneCircle(done = completed, locked = logged != null, desc = if (completed) "Sesi selesai" else "Tandai sesi selesai") { onSetDone(key, !manual) }
                    }
                }
            }
        }
        // blok strength / ankle / upper: kartu terpisah, masing-masing punya penanda selesai sendiri
        var cardIdx = 1
        listOf(Triple(d.str, "s", "GYM"), Triple(d.ank, "a", "ANKLE"), Triple(d.up, "u", "UPPER")).forEach { (blk, suffix, tag) ->
            if (blk != null) StrengthRow(d, blk, "$key:$suffix", tag, state, today, expandedKeys, onToggleKey, onSetDone, shapeAt(cardIdx++))
        }
        // aktivitas di luar jadwal (sepeda, lari bebas, lari di hari libur)
        extras.forEach { a -> ExtraActivityCard(a, dow, d.date, onOpenActivity, shapeAt(cardIdx++)) }
    }
}

@Composable
private fun ExtraActivityCard(a: ActivityEntity, dow: String, date: LocalDate, onOpenActivity: (Long) -> Unit, shape: Shape) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val bike = a.type.equals("bike", true)
    val title = if (bike) "Biking" else a.name.ifBlank { "Run" }
    WkCard(shape = shape) {
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
            Box(Modifier.width(4.dp).fillMaxHeight().background(WkGray))
            Row(Modifier.weight(1f).padding(horizontal = 10.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.width(34.dp)) {
                    Text(dow, fontFamily = WkMono, fontSize = 9.sp, color = cs.onSurfaceVariant)
                    Text(date.dayOfMonth.toString(), fontSize = 18.sp, fontWeight = FontWeight.Bold, lineHeight = 20.sp)
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text("Outside schedule", fontSize = 11.sp, color = cs.onSurfaceVariant)
                    WkChip(wkLoggedLine(a))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        WkSmallPill("Detail") { onOpenActivity(a.id) }
                        WkSmallPill("Share") { wkShare(ctx, "Share activity", "$title · ${date.dayOfMonth} ${date.month.getDisplayName(TextStyle.SHORT, Locale.ENGLISH)}\n${wkLoggedLine(a)}") }
                    }
                }
                if (a.km > 0) Row(verticalAlignment = Alignment.Top) {
                    Text(wkNum(a.km), fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text(" km", fontSize = 10.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
    }
}

@Composable
private fun StrengthRow(
    d: PDay, b: StrengthBlock, key: String, tag: String, state: UiState, today: LocalDate,
    expandedKeys: Set<String>, onToggleKey: (String) -> Unit, onSetDone: (String, Boolean) -> Unit,
    shape: Shape,
) {
    val manual = key in state.done
    val fromWatch = state.strengthWorkouts.any { it.linkedKey == key }
    val completed = manual || fromWatch
    val open = key in expandedKeys
    val cs = MaterialTheme.colorScheme
    val adj = b.adj
    WkCard(shape = shape, onClick = { onToggleKey(key) }) {
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
            Box(Modifier.width(4.dp).fillMaxHeight().background(SolidColor(Ember)))
            Row(Modifier.weight(1f).padding(horizontal = 10.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tag, Modifier.width(34.dp), fontFamily = WkMono, fontSize = 9.sp, color = cs.primary)
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(b.title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    if (completed) Text("✓ Done${if (fromWatch && !manual) " · dari jam" else ""}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = cs.primary)
                    else if (adj != null) AdjText(adj)
                    else if (d.date.isBefore(today)) Text("Missed", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = cs.error)
                    Text((if (open) "Hide sets" else "See sets") + " · ${b.lines.size} exercises", fontSize = 12.sp, color = cs.primary)
                    if (open) {
                        if (b.note.isNotBlank()) Text(b.note, fontSize = 11.sp, color = cs.onSurfaceVariant)
                        b.lines.forEach { Text("• $it", fontSize = 12.sp) }
                    }
                }
                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text("${b.mins}", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text(" min", fontSize = 10.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(bottom = 2.dp))
                    }
                    WkDoneCircle(done = completed, locked = fromWatch && !manual, desc = if (completed) "Strength selesai" else "Tandai strength selesai") { onSetDone(key, !manual) }
                }
            }
        }
    }
}

@Composable
private fun AdjText(a: DayAdj) {
    val cs = MaterialTheme.colorScheme
    val color = when (a.type) {
        "miss" -> cs.error
        "skip", "out" -> cs.onSurfaceVariant
        else -> cs.tertiary
    }
    Text(a.text, color = color, style = MaterialTheme.typography.bodySmall)
}

@Composable
private fun PickButton(text: String, options: List<DayOption>, onPick: (DayOption) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { open = true }) { Text(text) }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { o ->
                DropdownMenuItem(
                    text = { Text((if (o.warn) "⚠ " else "") + "${o.label} · ${o.what}") },
                    onClick = { open = false; onPick(o) },
                )
            }
        }
    }
}

// ---------- riwayat penyesuaian ----------

@Composable
private fun AdjustmentRow(key: String, e: MvEntry, onUndo: () -> Unit) {
    val (title, body) = when (e.t) {
        "sw" -> "${key.removePrefix("sw:")} · Tukar hari" to "Isi sesi ditukar dengan ${e.to}"
        "mv" -> "$key · Geser sesi terlewat" to "Dipindah ke ${e.to}"
        "skip" -> "$key · Dilewati" to "Keluar dari target"
        else -> "$key · Libur dadakan" to (
            (SessionAdjust.WHY_LABEL[e.why] ?: "-") + " · ${SessionAdjust.ds(e.km)} km" +
                (if (e.spread.isEmpty()) " · tidak dikejar" else "") +
                e.spread.joinToString("") { "\n${it.first} +${SessionAdjust.ds(it.second)} km" }
            )
    }
    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(body, style = MaterialTheme.typography.bodySmall)
            TextButton(onClick = onUndo) { Text("Batalkan") }
        }
    }
}

// ---------- libur dadakan ----------

private class Condition(val pain: Boolean, val score: Int, val swapTh: Int, val lightTh: Int)

/** Kondisi hari ini untuk pengaman pembagian km: nyeri aktif (kemarin/hari ini, berat ≥ 3) dan skor kesiapan terakhir. */
private fun readCondition(ctx: Context, today: LocalDate): Condition {
    val prefs = ctx.getSharedPreferences("readiness_settings", Context.MODE_PRIVATE)
    val recent = setOf(today.toString(), today.minusDays(1).toString())
    val pain = runCatching {
        val arr = JSONArray(prefs.getString("pain_entries", "[]"))
        (0 until arr.length()).any { i -> arr.optJSONObject(i)?.let { it.optString("date") in recent && it.optInt("severity", 1) >= 3 } == true }
    }.getOrDefault(false)
    val score = runCatching { ReadinessHistoryStore.load(ctx).lastOrNull { it.date == today }?.score }.getOrNull() ?: -1
    return Condition(pain, score, prefs.getInt("swap", 50), prefs.getInt("light", 65))
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SpreadDialog(
    plan: PlanOutcome.Ok, inp: AdjInput, mv: Map<String, MvEntry>, date: LocalDate,
    onDismiss: () -> Unit, onApply: (MvEntry) -> Unit,
) {
    val ctx = LocalContext.current
    val cond = remember { readCondition(ctx, inp.today) }
    var why by remember { mutableStateOf("sibuk") }
    var next by remember { mutableStateOf(false) }
    val pv = remember(plan, inp, date, why, next) { SessionAdjust.spPreview(plan, inp, date, why, next, cond.pain, cond.score, cond.swapTh, cond.lightTh) }
    if (pv == null) {
        AlertDialog(
            onDismissRequest = onDismiss, title = { Text("Libur dadakan") },
            text = { Text("Sesi ini tidak bisa diliburkan.") },
            confirmButton = { TextButton(onClick = onDismiss) { Text("OK") } },
        )
        return
    }
    var manual by remember(date, why, next) { mutableStateOf<Map<Int, String>>(emptyMap()) }
    // angka ubahan manual dijepit (kelipatan 0,5, batas per hari, jatah minggu depan, total sesi asal), sama seperti web
    val items = pv.items.mapIndexed { i, q ->
        SpItem(q.c, manual[i]?.let { it.replace(',', '.').toDoubleOrNull() ?: 0.0 } ?: q.x, q.cap, q.nx, q.done)
    }
    SessionAdjust.spClamp(items, pv.km, pv.allow)
    val total = items.sumOf { it.x }
    val left = Js.round((pv.km - total) * 10) / 10
    val cs = MaterialTheme.colorScheme
    val onlyRest = pv.lv >= 2 || items.isEmpty()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Libur dadakan · ${SessionAdjust.dlabel(pv.src)}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("${pv.src.title} · ${SessionAdjust.ds(pv.src.km)} km", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("sibuk", "capek", "sakit", "lain").forEach { k ->
                        FilterChip(selected = why == k, onClick = { why = k }, label = { Text(SessionAdjust.WHY_LABEL[k] ?: k) })
                    }
                }
                if (pv.lv >= 2) {
                    val reasons = listOfNotNull(
                        if (cond.pain) "ada nyeri aktif" else null,
                        if (cond.score >= 0 && cond.score < cond.swapTh) "skor kesiapan ${cond.score} rendah" else null,
                        if (why == "sakit") "alasan sakit/nyeri" else null,
                    ).joinToString(", ")
                    Text("Km tidak dibagi karena $reasons. Menambah beban ke hari lain berlawanan dengan alasan libur ini. Istirahat dulu; mulai lagi dengan easy.", color = cs.error, style = MaterialTheme.typography.bodySmall)
                } else {
                    if (pv.lv == 1) Text(
                        "Kondisi belum prima${if (cond.score >= 0) " (skor kesiapan ${cond.score})" else ""}${if (why == "capek") " dan alasan capek" else ""}, jadi batas tambahan tiap hari dipotong setengah.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    if (items.isEmpty()) Text("Tidak ada hari tujuan yang aman di minggu ini. Libur ini dicatat tanpa membagi km.", style = MaterialTheme.typography.bodySmall)
                    items.forEachIndexed { i, q ->
                        val typed = manual[i]?.replace(',', '.')?.toDoubleOrNull()
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(SessionAdjust.dlabel(q.c) + if (q.nx) " · minggu depan" else "")
                                Text(
                                    "${q.c.title} · ${SessionAdjust.ds(q.c.km)} km · " + if (q.done) "sudah dilari" else "maks +${SessionAdjust.ds(q.cap)} km",
                                    style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                                )
                                if (typed != null && typed != q.x) Text("dibatasi ke ${SessionAdjust.ds(q.x)} km", style = MaterialTheme.typography.bodySmall, color = cs.error)
                            }
                            OutlinedTextField(
                                value = manual[i] ?: SessionAdjust.ds(pv.items[i].x),
                                onValueChange = { v -> manual = manual.toMutableMap().apply { put(i, v) } },
                                modifier = Modifier.width(96.dp), singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                label = { Text("+ km") },
                            )
                        }
                    }
                    if (pv.hasNext) Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = next, onCheckedChange = { next = it })
                        Text("Sisa boleh ke easy minggu depan (maks. +10% dari total minggu itu)", style = MaterialTheme.typography.bodySmall)
                    }
                }
                Text(
                    if (pv.lv >= 2) "Km tidak dibagi: ${SessionAdjust.ds(pv.km)} km tidak dikejar."
                    else "Dibagi ${SessionAdjust.ds(total)} dari ${SessionAdjust.ds(pv.km)} km. " + if (left >= .5) "Sisa ${SessionAdjust.ds(left)} km tidak dikejar." else "Semua tertampung.",
                    style = MaterialTheme.typography.bodyMedium,
                )
                val hist = SessionAdjust.spHistory(mv, inp.today).filter { it.first != date.toString() }.take(5)
                if (hist.isNotEmpty()) {
                    Text("Libur dadakan terakhir", style = MaterialTheme.typography.labelMedium, color = cs.primary)
                    hist.forEach { (k, e) ->
                        Text("$k · ${SessionAdjust.WHY_LABEL[e.why]?.let { "$it · " } ?: ""}${SessionAdjust.ds(e.km)} km → " + if (e.spread.isEmpty()) "tidak dikejar" else "dibagi", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onApply(
                    MvEntry(
                        "spread", why = why, km = pv.km, f = if (pv.lv == 1) .5 else 1.0,
                        spread = if (pv.lv >= 2) emptyList() else items.filter { it.x > 0 }.map { it.c.date.toString() to it.x },
                    ),
                )
            }) { Text(if (onlyRest) "Libur saja" else "Terapkan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
    )
}

private fun phaseLabel(p: String, rec: Boolean) = when {
    rec -> "Pemulihan"; p == Phases.BASE -> "BASE"; p == Phases.BUILD -> "BUILD"; p == Phases.PEAK -> "PEAK"; else -> "TAPER"
}
