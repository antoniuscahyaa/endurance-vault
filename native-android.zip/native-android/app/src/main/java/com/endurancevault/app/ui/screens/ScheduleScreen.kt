package com.endurancevault.app.ui.screens

import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import com.endurancevault.app.domain.*
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.ui.UiState
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.time.format.TextStyle
import java.util.Locale

private val ID = Locale("id", "ID")
private data class DayView(val day: PDay, val title: String, val kind: String, val km: Double, val detail: String, val note: String = "")
private class WeekAdjustments(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("week_adjustments_v1", Context.MODE_PRIVATE)
    fun read(): JSONObject = runCatching { JSONObject(prefs.getString("data", "{}") ?: "{}") }.getOrDefault(JSONObject())
    fun write(data: JSONObject) { prefs.edit().putString("data", data.toString()).apply() }
}
private fun label(d: LocalDate): String = d.dayOfWeek.getDisplayName(TextStyle.SHORT, ID).replaceFirstChar { it.uppercase(ID) } + " " + d.dayOfMonth
private fun isHard(k: String) = k in setOf(Kinds.QUALITY, Kinds.LONG, "sub", Kinds.RACE, Kinds.EVENT)

/** Only an activity explicitly keyed to the planned calendar day completes a planned run.
 * Legacy backup convention: YYYY-MM-DD is the primary planned entry; YYYY-MM-DD~f1/f2…
 * are additional Free Run entries. Blank srcKey entries are unlinked manual/imported runs.
 */
private fun ActivityEntity.isLinkedToPlannedRun(dateIso: String): Boolean =
    type.equals("run", ignoreCase = true) && srcKey == dateIso
private fun dayViews(week: PWeek, saved: JSONObject): List<DayView> {
    val days = week.days.map { DayView(it, it.title, it.kind, it.km, it.detail) }.toMutableList()
    val swaps = saved.optJSONArray("swaps") ?: JSONArray()
    for (i in 0 until swaps.length()) {
        val s = swaps.optJSONObject(i) ?: continue
        val a = days.indexOfFirst { it.day.date.toString() == s.optString("a") }
        val b = days.indexOfFirst { it.day.date.toString() == s.optString("b") }
        if (a >= 0 && b >= 0) {
            val x = days[a]; val y = days[b]
            days[a] = x.copy(title=y.title, kind=y.kind, km=y.km, detail=y.detail, note="Ditukar dengan ${label(y.day.date)}")
            days[b] = y.copy(title=x.title, kind=x.kind, km=x.km, detail=x.detail, note="Ditukar dengan ${label(x.day.date)}")
        }
    }
    val spreads = saved.optJSONArray("spreads") ?: JSONArray()
    for (i in 0 until spreads.length()) {
        val s = spreads.optJSONObject(i) ?: continue
        val targets = s.optJSONArray("to") ?: JSONArray()
        for (j in 0 until targets.length()) {
            val t = targets.optJSONObject(j) ?: continue
            val idx = days.indexOfFirst { it.day.date.toString() == t.optString("date") }
            if (idx >= 0) {
                val x = t.optDouble("km", 0.0); val d = days[idx]
                days[idx] = d.copy(km=d.km+x, note=(d.note + " · Tambahan +${"%.1f".format(x)} km dari libur dadakan").trim(' ', '·'))
            }
        }
        val src = days.indexOfFirst { it.day.date.toString() == s.optString("date") }
        if (src >= 0) days[src] = days[src].copy(title="Libur dadakan", kind=Kinds.REST, km=0.0, note="${s.optString("reason")} · ${"%.1f".format(s.optDouble("km"))} km tidak dijalankan")
    }
    return days
}

@Composable
fun ScheduleScreen(state: UiState) {
    val context = LocalContext.current
    val store = remember { WeekAdjustments(context) }
    var saved by remember { mutableStateOf(store.read()) }
    var history by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf<Set<String>>(emptySet()) }
    var swapSource by remember { mutableStateOf<PDay?>(null) }
    var restSource by remember { mutableStateOf<PDay?>(null) }
    var restReason by remember { mutableStateOf("sibuk") }
    var swapTarget by remember { mutableStateOf("") }
    var showWarning by remember { mutableStateOf(false) }

    when (val plan = state.plan) {
        is PlanOutcome.Err -> Text(plan.message, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.error)
        is PlanOutcome.Ok -> {
            val today = LocalDate.now()
            val week = plan.weeks.firstOrNull { !today.isBefore(it.start) && !today.isAfter(it.end) }
                ?: plan.weeks.firstOrNull { !it.end.isBefore(today) } ?: plan.weeks.lastOrNull()
            val days = week?.let { dayViews(it, saved) }.orEmpty()
            val hist = saved.optJSONArray("spreads") ?: JSONArray()
            LazyColumn(Modifier.fillMaxSize().padding(horizontal=16.dp), verticalArrangement=Arrangement.spacedBy(10.dp), contentPadding=PaddingValues(vertical=12.dp)) {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                        FilterChip(selected=!history, onClick={history=false}, label={Text("This week")}, modifier=Modifier.weight(1f))
                        FilterChip(selected=history, onClick={history=true}, label={Text("History")}, modifier=Modifier.weight(1f))
                    }
                }
                if (!history) {
                    if (week != null) item {
                        EvPanel(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement=Arrangement.spacedBy(3.dp)) {
                            Text(if(plan.none) "No Race" else "${phaseLabel(week.phase, week.rec)}", style=MaterialTheme.typography.titleLarge)
                            Text("Week ${week.i+1} · ${week.start.dayOfMonth}–${week.end.dayOfMonth} ${week.end.month.getDisplayName(TextStyle.SHORT, ID)}", color=MaterialTheme.colorScheme.onSurfaceVariant)
                        } }
                    }
                    if (days.isEmpty()) item { Text("Belum ada jadwal minggu ini.") }
                    items(days, key={it.day.date.toString()}) { dv ->
                        val d=dv.day; val key=d.date.toString(); val open=key in expanded
                        val logged = state.activities.filter { it.dateIso == key && it.isLinkedToPlannedRun(key) }.maxByOrNull { it.id }
                        val completed = logged != null
                        val missed = d.date.isBefore(today) && dv.kind != Kinds.REST && !completed
                        EvPanel(Modifier.fillMaxWidth().clickable { expanded=if(open) expanded-key else expanded+key }) {
                            Column(Modifier.padding(13.dp), verticalArrangement=Arrangement.spacedBy(6.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                                    Column(Modifier.width(58.dp)) { Text(d.date.dayOfWeek.getDisplayName(TextStyle.SHORT, ID).uppercase(ID), style=MaterialTheme.typography.labelSmall); Text(d.date.dayOfMonth.toString(), style=MaterialTheme.typography.headlineSmall) }
                                    Column(Modifier.weight(1f), verticalArrangement=Arrangement.spacedBy(3.dp)) {
                                        Text(if(dv.kind==Kinds.REST) "Libur" else dv.title, style=MaterialTheme.typography.titleMedium)
                                        if (completed) {
                                            Text("Selesai · ${"%.1f".format(logged!!.km)} km${if(logged.avgHr != null) " · HR ${logged.avgHr}" else ""}", color=MaterialTheme.colorScheme.primary, style=MaterialTheme.typography.labelMedium)
                                        } else if (missed) {
                                            Text("Terlewat · belum ada aktivitas lari tercatat", color=MaterialTheme.colorScheme.error, style=MaterialTheme.typography.labelMedium)
                                        }
                                        if(dv.note.isNotBlank()) Text(dv.note, color=MaterialTheme.colorScheme.tertiary, style=MaterialTheme.typography.bodySmall)
                                        if(open && dv.detail.isNotBlank()) Text(dv.detail, style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.onSurfaceVariant)
                                        if(open && logged != null) {
                                            val pace = if(logged.km > 0.0 && logged.durationSec > 0) " · ${"%.2f".format(logged.durationSec / 60.0 / logged.km)} min/km" else ""
                                            Text("Logged · ${logged.name.ifBlank { "Run" }} · ${"%.1f".format(logged.km)} km$pace", style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.primary)
                                        }
                                        if(dv.kind!=Kinds.REST) Text("${"%.1f".format(dv.km)} km", style=MaterialTheme.typography.titleMedium)
                                        SupportBlocks(d, expanded=open)
                                    }
                                    Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
                                        Icon(if(completed) Icons.Filled.CheckCircle else Icons.Outlined.RadioButtonUnchecked,
                                            contentDescription=if(completed) "Sesi selesai" else "Sesi belum selesai",
                                            tint=if(completed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline)
                                        Text(if(open) "⌃" else "⌄", color=MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                if(open) {
                                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                        if(dv.note.startsWith("Ditukar dengan")) TextButton(onClick={
                                            val arr=saved.optJSONArray("swaps")?:JSONArray(); val n=JSONArray()
                                            for(i in 0 until arr.length()) { val q=arr.optJSONObject(i); if(q?.optString("a")!=key && q?.optString("b")!=key) n.put(q) }
                                            saved=JSONObject(saved.toString()).put("swaps",n); store.write(saved)
                                        }) { Text("Undo tukar") }
                                        if(dv.kind!=Kinds.REST && !completed && !d.date.isAfter(today) && ChronoUnit.DAYS.between(d.date,today)<=7 && d.kind !in setOf(Kinds.RACE,Kinds.EVENT)) OutlinedButton(onClick={swapSource=d; swapTarget=""}) { Text("Tukar jadwal") }
                                        if(dv.kind in setOf(Kinds.EASY,"short","medium") && d.km>0 && !d.date.isAfter(today) && ChronoUnit.DAYS.between(d.date,today)<=7 && !completed) OutlinedButton(onClick={restSource=d; restReason="sibuk"}) { Text("Libur dadakan") }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    item { Text("RIWAYAT PENYESUAIAN", style=MaterialTheme.typography.labelMedium, color=MaterialTheme.colorScheme.primary) }
                    items((0 until hist.length()).mapNotNull { hist.optJSONObject(it) }.reversed()) { s ->
                        EvPanel(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) {
                            Text("${s.optString("date")} · Libur dadakan", style=MaterialTheme.typography.titleMedium)
                            Text("${s.optString("reason")} · ${"%.1f".format(s.optDouble("km"))} km")
                            val to=s.optJSONArray("to") ?: JSONArray()
                            for(i in 0 until to.length()) { val t=to.optJSONObject(i) ?: continue; Text("${t.optString("date")} +${"%.1f".format(t.optDouble("km"))} km", style=MaterialTheme.typography.bodySmall) }
                            TextButton(onClick={ val arr=saved.optJSONArray("spreads")?:JSONArray(); val n=JSONArray(); for(i in 0 until arr.length()) { val q=arr.optJSONObject(i); if(q?.optString("date")!=s.optString("date")) n.put(q) }; saved=JSONObject(saved.toString()).put("spreads",n); store.write(saved) }) { Text("Undo") }
                        } }
                    }
                    if(hist.length()==0) item { Text("Belum ada riwayat libur dadakan.", color=MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            }
        }
    }

    if (swapSource != null) {
        val src=swapSource!!
        val available=(state.plan as? PlanOutcome.Ok)?.weeks?.firstOrNull { src.date in it.start..it.end }?.days.orEmpty().filter { it.date!=src.date && it.date>=LocalDate.now() && it.kind !in setOf(Kinds.RACE,Kinds.EVENT) && it.kind!="event" && it.kind!="race" && state.activities.none { a -> a.dateIso==it.date.toString() && a.isLinkedToPlannedRun(it.date.toString()) } }
        AlertDialog(onDismissRequest={swapSource=null}, title={Text("Tukar jadwal · ${label(src.date)}")}, text={ Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Text("Pilih hari tujuan dalam minggu yang sama. Isi sesi bertukar, sedangkan tanggal tetap.")
            available.forEach { d -> Row(Modifier.fillMaxWidth().clickable { swapTarget=d.date.toString(); showWarning=isHard(src.kind) && isHard(d.kind) }, horizontalArrangement=Arrangement.SpaceBetween) { Text("${label(d.date)} · ${if(d.kind==Kinds.REST) "Libur" else d.title}"); RadioButton(selected=swapTarget==d.date.toString(), onClick={swapTarget=d.date.toString(); showWarning=isHard(src.kind) && isHard(d.kind)}) } }
            if(showWarning) Text("Peringatan: pertukaran ini dapat membuat dua sesi berat berurutan. Pastikan pemulihan mencukupi.", color=MaterialTheme.colorScheme.error)
        } }, confirmButton={ TextButton(enabled=swapTarget.isNotBlank(), onClick={
            val arr=saved.optJSONArray("swaps")?:JSONArray(); val srcDate=src.date.toString(); val target=LocalDate.parse(swapTarget)
            val hard1=isHard(src.kind); val other=(state.plan as? PlanOutcome.Ok)?.weeks?.firstOrNull { src.date in it.start..it.end }?.days?.firstOrNull{it.date==target}; val hard2=other?.let{isHard(it.kind)}?:false
            if(hard1 && hard2 && !showWarning) { showWarning=true; return@TextButton }
            val s=JSONObject().put("a",srcDate).put("b",swapTarget).put("warning",hard1&&hard2); arr.put(s)
            saved=JSONObject(saved.toString()).put("swaps",arr); store.write(saved); swapSource=null; showWarning=false
        }) { Text("Tukar") } }, dismissButton={ TextButton(onClick={swapSource=null;showWarning=false}) { Text("Batal") } })
    }
    if(restSource!=null) {
        val src=restSource!!
        var manual by remember(src.date, restReason) { mutableStateOf<Map<String,String>>(emptyMap()) }
        val lv=if(restReason=="sakit") 2 else if(restReason=="capek") 1 else 0
        val allWeeks=(state.plan as? PlanOutcome.Ok)?.weeks.orEmpty()
        val currentWeek=allWeeks.firstOrNull{src.date in it.start..it.end}
        var includeNext by remember(src.date) { mutableStateOf(false) }
        val nextWeek=currentWeek?.let { cw -> allWeeks.firstOrNull { it.i==cw.i+1 && !it.race && it.phase!=Phases.TAPER } }
        val sameWeekCandidates=currentWeek?.days.orEmpty().filter { d -> d.date>src.date && d.date>=LocalDate.now() && d.km>0 && d.kind in setOf(Kinds.EASY,"short",Kinds.MEDIUM,Kinds.LONG) && !d.bench && state.activities.none { a -> a.dateIso==d.date.toString() && a.isLinkedToPlannedRun(d.date.toString()) } }
        val nextWeekCandidates=if(includeNext) nextWeek?.days.orEmpty().filter { d -> d.date>=LocalDate.now() && d.km>0 && d.kind in setOf(Kinds.EASY,"short") && !d.bench && state.activities.none { a -> a.dateIso==d.date.toString() && a.isLinkedToPlannedRun(d.date.toString()) } } else emptyList()
        val candidates=sameWeekCandidates+nextWeekCandidates
        val nextWeekBudget=nextWeek?.let { kotlin.math.floor(it.km*.10*2.0)/2.0 } ?: 0.0
        val caps=candidates.associateWith { d ->
            val raw=d.km*(if(d.kind==Kinds.LONG || d.b2b!=null) .25 else .40)*(if(lv==1) .5 else 1.0)
            maxOf(2.0, kotlin.math.floor(raw*2.0+0.0001)/2.0)
        }
        val auto=remember(src.date, restReason, candidates) {
            val out=mutableMapOf<String,Double>(); var left=if(lv==2) 0.0 else src.km
            var guard=0
            while(left>=.5 && guard++<80) {
                val open=candidates.filter { (out[it.date.toString()] ?: 0.0) < (caps[it] ?: 0.0) }
                if(open.isEmpty()) break
                val share=maxOf(.5, kotlin.math.floor(left/open.size*2.0)/2.0)
                for(d in open) { val key=d.date.toString(); val cur=out[key]?:0.0; val add=minOf(share,(caps[d]?:0.0)-cur,left); if(add>=.5){out[key]=cur+add;left-=add} }
            }
            out
        }
        val values=candidates.associate { d ->
            val k=d.date.toString(); val parsed=manual[k]?.replace(',','.')?.toDoubleOrNull()
            k to (parsed ?: (auto[k] ?: 0.0))
        }
        val total=values.values.sum()
        val nextTotal=values.filterKeys { key -> nextWeekCandidates.any { it.date.toString()==key } }.values.sum()
        val over=values.any { (k,v)-> v<0 || kotlin.math.abs(v*2.0-kotlin.math.round(v*2.0))>0.0001 || v>(caps[candidates.firstOrNull{it.date.toString()==k}]?:0.0) } || total>src.km+0.0001 || nextTotal>nextWeekBudget+0.0001
        val remaining=(src.km-total).coerceAtLeast(0.0)
        AlertDialog(onDismissRequest={restSource=null}, title={Text("Libur dadakan · ${label(src.date)}")}, text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Text("Pilih alasan. Atur pembagian secara manual dalam kelipatan 0,5 km. Batas per hari mengikuti rumus aplikasi lama.")
            listOf("sibuk" to "Sibuk", "capek" to "Capek", "sakit" to "Sakit/nyeri", "lain" to "Lainnya").forEach { (k,v)-> Row(Modifier.fillMaxWidth().clickable{restReason=k;manual=emptyMap()}, horizontalArrangement=Arrangement.SpaceBetween){Text(v);RadioButton(selected=restReason==k,onClick={restReason=k;manual=emptyMap()})} }
            if(lv==2) Text("Km tidak dibagi karena alasan sakit/nyeri. Istirahat dan mulai lagi dengan easy.", color=MaterialTheme.colorScheme.error)
            else {
                if(nextWeek!=null) Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically) { Checkbox(checked=includeNext,onCheckedChange={includeNext=it;manual=emptyMap()}); Text("Izinkan sisa ke Easy minggu depan (maks. +10% total minggu)") }
                candidates.forEach { d ->
                    val key=d.date.toString(); val cap=caps[d]?:0.0; val value=values[key]?:0.0
                    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp), verticalAlignment=androidx.compose.ui.Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text("${label(d.date)}${if(d.date> (currentWeek?.end ?: d.date)) " · Minggu depan" else ""} · ${d.title}"); Text("Maks +${"%.1f".format(cap)} km${if(d.date> (currentWeek?.end ?: d.date)) " · anggaran minggu depan ${"%.1f".format(nextWeekBudget)} km" else ""}", style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.onSurfaceVariant) }
                        OutlinedTextField(value=manual[key] ?: "%.1f".format(value), onValueChange={ manual=manual.toMutableMap().apply{put(key,it)} }, modifier=Modifier.width(104.dp), singleLine=true, keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal), label={Text("Tambah km")})
                    }
                }
                Text("Dibagi ${"%.1f".format(total)} dari ${"%.1f".format(src.km)} km · Sisa ${"%.1f".format(remaining)} km tidak dikejar.")
                if(includeNext) Text("Dialokasikan ke minggu depan: ${"%.1f".format(nextTotal)} / ${"%.1f".format(nextWeekBudget)} km.", style=MaterialTheme.typography.bodySmall)
                if(over) Text("Periksa nilai: batas per hari, kelipatan 0,5 km, total sesi asal, atau batas +10% minggu depan.", color=MaterialTheme.colorScheme.error)
            }
        }}, confirmButton={TextButton(enabled=!over, onClick={
            val arr=saved.optJSONArray("spreads")?:JSONArray(); val to=JSONArray()
            candidates.forEach { d -> val x=values[d.date.toString()]?:0.0; if(x>=.5) to.put(JSONObject().put("date",d.date.toString()).put("km",x)) }
            arr.put(JSONObject().put("date",src.date.toString()).put("km",src.km).put("reason",restReason).put("to",to))
            saved=JSONObject(saved.toString()).put("spreads",arr); store.write(saved); restSource=null
        }){Text(if(lv==2||total==0.0) "Libur saja" else "Terapkan") }}, dismissButton={TextButton(onClick={restSource=null}){Text("Batal")}})
    }
}

private fun phaseLabel(p:String, rec:Boolean)=when { rec->"Pemulihan"; p==Phases.BASE->"BASE"; p==Phases.BUILD->"BUILD"; p==Phases.PEAK->"PEAK"; else->"TAPER" }
