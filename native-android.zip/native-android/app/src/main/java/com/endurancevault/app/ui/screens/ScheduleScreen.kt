package com.endurancevault.app.ui.screens

import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.endurancevault.app.domain.*
import com.endurancevault.app.ui.UiState
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.time.format.TextStyle
import java.util.Locale

private val ID = Locale("id", "ID")
private data class DayView(val day: PDay, val title: String, val kind: String, val km: Double, val detail: String, val note: String = "")
private class WeekAdjustments(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("week_adjustments_v1", Context.MODE_PRIVATE)
    fun read(): JSONObject = runCatching { JSONObject(prefs.getString("data", "{}") ?: "{}") }.getOrDefault(JSONObject())
    fun write(data: JSONObject) { prefs.edit().putString("data", data.toString()).apply() }
}
private fun label(d: LocalDate): String = d.dayOfWeek.getDisplayName(TextStyle.SHORT, ID).replaceFirstChar { it.uppercase(ID) } + " " + d.dayOfMonth
private fun isHard(k: String) = k in setOf(Kinds.QUALITY, Kinds.LONG, "sub", Kinds.RACE, Kinds.EVENT)
private fun dayViews(week: PWeek, saved: JSONObject): List<DayView> {
    val days = week.days.map { DayView(it, it.title, it.kind, it.km, it.detail) }.toMutableList()
    val swaps = saved.optJSONArray("swaps") ?: JSONArray()
    for (i in 0 until swaps.length()) {
        val s = swaps.optJSONObject(i) ?: continue
        val a = days.indexOfFirst { it.day.date.toString() == s.optString("a") }
        val b = days.indexOfFirst { it.day.date.toString() == s.optString("b") }
        if (a >= 0 && b >= 0) {
            val x = days[a]; val y = days[b]
            days[a] = x.copy(title=y.title, kind=y.kind, km=y.km, detail=y.detail, note="Ditukar dengan ${label(y.day.date)}")
            days[b] = y.copy(title=x.title, kind=x.kind, km=x.km, detail=x.detail, note="Ditukar dengan ${label(x.day.date)}")
        }
    }
    val spreads = saved.optJSONArray("spreads") ?: JSONArray()
    for (i in 0 until spreads.length()) {
        val s = spreads.optJSONObject(i) ?: continue
        val targets = s.optJSONArray("to") ?: JSONArray()
        for (j in 0 until targets.length()) {
            val t = targets.optJSONObject(j) ?: continue
            val idx = days.indexOfFirst { it.day.date.toString() == t.optString("date") }
            if (idx >= 0) {
                val x = t.optDouble("km", 0.0); val d = days[idx]
                days[idx] = d.copy(km=d.km+x, note=(d.note + " · Tambahan +${"%.1f".format(x)} km dari libur dadakan").trim(' ', '·'))
            }
        }
        val src = days.indexOfFirst { it.day.date.toString() == s.optString("date") }
        if (src >= 0) days[src] = days[src].copy(title="Libur dadakan", kind=Kinds.REST, km=0.0, note="${s.optString("reason")} · ${"%.1f".format(s.optDouble("km"))} km tidak dijalankan")
    }
    return days
}

@Composable
fun ScheduleScreen(state: UiState) {
    val context = LocalContext.current
    val store = remember { WeekAdjustments(context) }
    var saved by remember { mutableStateOf(store.read()) }
    var history by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf<Set<String>>(emptySet()) }
    var swapSource by remember { mutableStateOf<PDay?>(null) }
    var restSource by remember { mutableStateOf<PDay?>(null) }
    var restReason by remember { mutableStateOf("sibuk") }
    var swapTarget by remember { mutableStateOf("") }
    var showWarning by remember { mutableStateOf(false) }

    when (val plan = state.plan) {
        is PlanOutcome.Err -> Text(plan.message, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.error)
        is PlanOutcome.Ok -> {
            val today = LocalDate.now()
            val week = plan.weeks.firstOrNull { !today.isBefore(it.start) && !today.isAfter(it.end) }
                ?: plan.weeks.firstOrNull { !it.end.isBefore(today) } ?: plan.weeks.lastOrNull()
            val days = week?.let { dayViews(it, saved) }.orEmpty()
            val hist = saved.optJSONArray("spreads") ?: JSONArray()
            LazyColumn(Modifier.fillMaxSize().padding(horizontal=16.dp), verticalArrangement=Arrangement.spacedBy(10.dp), contentPadding=PaddingValues(vertical=12.dp)) {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                        FilterChip(selected=!history, onClick={history=false}, label={Text("This week")}, modifier=Modifier.weight(1f))
                        FilterChip(selected=history, onClick={history=true}, label={Text("History")}, modifier=Modifier.weight(1f))
                    }
                }
                if (!history) {
                    if (week != null) item {
                        EvPanel(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement=Arrangement.spacedBy(3.dp)) {
                            Text(if(plan.none) "No Race" else "${phaseLabel(week.phase, week.rec)}", style=MaterialTheme.typography.titleLarge)
                            Text("Week ${week.i+1} · ${week.start.dayOfMonth}–${week.end.dayOfMonth} ${week.end.month.getDisplayName(TextStyle.SHORT, ID)}", color=MaterialTheme.colorScheme.onSurfaceVariant)
                        } }
                    }
                    if (days.isEmpty()) item { Text("Belum ada jadwal minggu ini.") }
                    items(days, key={it.day.date.toString()}) { dv ->
                        val d=dv.day; val key=d.date.toString(); val open=key in expanded
                        EvPanel(Modifier.fillMaxWidth().clickable { expanded=if(open) expanded-key else expanded+key }) {
                            Column(Modifier.padding(13.dp), verticalArrangement=Arrangement.spacedBy(6.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                                    Column(Modifier.width(58.dp)) { Text(d.date.dayOfWeek.getDisplayName(TextStyle.SHORT, ID).uppercase(ID), style=MaterialTheme.typography.labelSmall); Text(d.date.dayOfMonth.toString(), style=MaterialTheme.typography.headlineSmall) }
                                    Column(Modifier.weight(1f), verticalArrangement=Arrangement.spacedBy(3.dp)) {
                                        Text(if(dv.kind==Kinds.REST) "Libur" else dv.title, style=MaterialTheme.typography.titleMedium)
                                        if(dv.note.isNotBlank()) Text(dv.note, color=MaterialTheme.colorScheme.tertiary, style=MaterialTheme.typography.bodySmall)
                                        if(open && dv.detail.isNotBlank()) Text(dv.detail, style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.onSurfaceVariant)
                                        if(dv.kind!=Kinds.REST) Text("${"%.1f".format(dv.km)} km", style=MaterialTheme.typography.titleMedium)
                                        SupportBlocks(d, expanded=open)
                                    }
                                    Text(if(open) "⌃" else "⌄", color=MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                if(open) {
                                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                        if(dv.note.startsWith("Ditukar dengan")) TextButton(onClick={
                                            val arr=saved.optJSONArray("swaps")?:JSONArray(); val n=JSONArray()
                                            for(i in 0 until arr.length()) { val q=arr.optJSONObject(i); if(q?.optString("a")!=key && q?.optString("b")!=key) n.put(q) }
                                            saved=JSONObject(saved.toString()).put("swaps",n); store.write(saved)
                                        }) { Text("Undo tukar") }
                                        if(dv.kind!=Kinds.REST && d.date>=today && d.kind !in setOf(Kinds.RACE,Kinds.EVENT)) OutlinedButton(onClick={swapSource=d; swapTarget=""}) { Text("Tukar jadwal") }
                                        if(dv.kind in setOf(Kinds.EASY,"short","medium") && d.km>0 && !d.date.isAfter(today) && ChronoUnit.DAYS.between(d.date,today)<=7) OutlinedButton(onClick={restSource=d; restReason="sibuk"}) { Text("Libur dadakan") }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    item { Text("RIWAYAT PENYESUAIAN", style=MaterialTheme.typography.labelMedium, color=MaterialTheme.colorScheme.primary) }
                    items((0 until hist.length()).mapNotNull { hist.optJSONObject(it) }.reversed()) { s ->
                        EvPanel(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) {
                            Text("${s.optString("date")} · Libur dadakan", style=MaterialTheme.typography.titleMedium)
                            Text("${s.optString("reason")} · ${"%.1f".format(s.optDouble("km"))} km")
                            val to=s.optJSONArray("to") ?: JSONArray()
                            for(i in 0 until to.length()) { val t=to.optJSONObject(i) ?: continue; Text("${t.optString("date")} +${"%.1f".format(t.optDouble("km"))} km", style=MaterialTheme.typography.bodySmall) }
                            TextButton(onClick={ val arr=saved.optJSONArray("spreads")?:JSONArray(); val n=JSONArray(); for(i in 0 until arr.length()) { val q=arr.optJSONObject(i); if(q?.optString("date")!=s.optString("date")) n.put(q) }; saved=JSONObject(saved.toString()).put("spreads",n); store.write(saved) }) { Text("Undo") }
                        } }
                    }
                    if(hist.length()==0) item { Text("Belum ada riwayat libur dadakan.", color=MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            }
        }
    }

    if (swapSource != null) {
        val src=swapSource!!
        val available=(state.plan as? PlanOutcome.Ok)?.weeks?.firstOrNull { src.date in it.start..it.end }?.days.orEmpty().filter { it!==src && it.date>=LocalDate.now() && it.kind !in setOf(Kinds.RACE,Kinds.EVENT) && it.kind!="event" && it.kind!="race" }
        AlertDialog(onDismissRequest={swapSource=null}, title={Text("Tukar jadwal · ${label(src.date)}")}, text={ Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Text("Pilih hari tujuan dalam minggu yang sama. Isi sesi bertukar, sedangkan tanggal tetap.")
            available.forEach { d -> Row(Modifier.fillMaxWidth().clickable { swapTarget=d.date.toString() }, horizontalArrangement=Arrangement.SpaceBetween) { Text("${label(d.date)} · ${if(d.kind==Kinds.REST) "Libur" else d.title}"); RadioButton(selected=swapTarget==d.date.toString(), onClick={swapTarget=d.date.toString(); showWarning=isHard(src.kind) && isHard(d.kind)}) } }
            if(showWarning) Text("Peringatan: pertukaran ini dapat membuat dua sesi berat berurutan. Pastikan pemulihan mencukupi.", color=MaterialTheme.colorScheme.error)
        } }, confirmButton={ TextButton(enabled=swapTarget.isNotBlank(), onClick={
            val arr=saved.optJSONArray("swaps")?:JSONArray(); val srcDate=src.date.toString(); val target=LocalDate.parse(swapTarget)
            val hard1=isHard(src.kind); val other=(state.plan as? PlanOutcome.Ok)?.weeks?.firstOrNull { src.date in it.start..it.end }?.days?.firstOrNull{it.date==target}; val hard2=other?.let{isHard(it.kind)}?:false
            if(hard1 && hard2 && !showWarning) { showWarning=true; return@TextButton }
            val s=JSONObject().put("a",srcDate).put("b",swapTarget).put("warning",hard1&&hard2); arr.put(s)
            saved=JSONObject(saved.toString()).put("swaps",arr); store.write(saved); swapSource=null; showWarning=false
        }) { Text("Tukar") } }, dismissButton={ TextButton(onClick={swapSource=null;showWarning=false}) { Text("Batal") } })
    }
    if(restSource!=null) {
        val src=restSource!!; val lv=if(restReason=="sakit") 2 else if(restReason=="capek") 1 else 0
        val currentWeek=(state.plan as? PlanOutcome.Ok)?.weeks?.firstOrNull{src.date in it.start..it.end}
        val candidates=currentWeek?.days.orEmpty().filter { it.date>src.date && it.date>=LocalDate.now() && it.km>0 && it.kind in setOf(Kinds.EASY,"short",Kinds.MEDIUM,Kinds.LONG) && !it.bench && it.kind!=Kinds.RACE }
        val base=src.km; val caps=candidates.associateWith { d -> maxOf(2.0, d.km*(if(d.kind==Kinds.LONG||d.b2b!=null) .25 else .40)*(if(lv==1) .5 else 1.0)) }
        var remaining=if(lv==2) 0.0 else base
        val allocations=candidates.mapNotNull { d -> val cap=caps[d]?:0.0; val x=minOf(cap,remaining); remaining-=x; if(x>=.5) d to x else null }
        AlertDialog(onDismissRequest={restSource=null}, title={Text("Libur dadakan · ${label(src.date)}")}, text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Text("Pilih alasan. Pembagian hanya ke sesi yang belum dilalui dalam minggu yang sama.")
            listOf("sibuk" to "Sibuk", "capek" to "Capek", "sakit" to "Sakit/nyeri", "lain" to "Lainnya").forEach { (k,v)-> Row(Modifier.fillMaxWidth().clickable{restReason=k}, horizontalArrangement=Arrangement.SpaceBetween){Text(v);RadioButton(selected=restReason==k,onClick={restReason=k})} }
            if(lv==2) Text("Km tidak dibagi karena alasan sakit/nyeri. Istirahat dan mulai lagi dengan easy.", color=MaterialTheme.colorScheme.error)
            else { allocations.forEach{(d,x)->Text("${label(d)} · +${"%.1f".format(x)} km")}; Text("Sisa ${"%.1f".format(remaining)} km tidak dikejar.") }
        }}, confirmButton={TextButton(onClick={ val arr=saved.optJSONArray("spreads")?:JSONArray(); val to=JSONArray(); allocations.forEach{(d,x)->to.put(JSONObject().put("date",d.date.toString()).put("km",x))}; arr.put(JSONObject().put("date",src.date.toString()).put("km",base).put("reason",restReason).put("to",to)); saved=JSONObject(saved.toString()).put("spreads",arr); store.write(saved); restSource=null }){Text(if(lv==2||allocations.isEmpty()) "Libur saja" else "Terapkan") }}, dismissButton={TextButton(onClick={restSource=null}){Text("Batal")}})
    }
}

private fun phaseLabel(p:String, rec:Boolean)=when { rec->"Pemulihan"; p==Phases.BASE->"BASE"; p==Phases.BUILD->"BUILD"; p==Phases.PEAK->"PEAK"; else->"TAPER" }
