package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.i18n.Text
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.data.WatchDockReader
import com.endurancevault.app.data.WatchDockUi
import com.endurancevault.app.domain.WatchDock
import com.endurancevault.app.domain.WatchModel
import com.endurancevault.app.domain.WatchTile
import com.endurancevault.app.domain.WatchWorkout
import com.endurancevault.app.domain.WxSnapshot
import com.endurancevault.app.ui.watchWorkoutMatches
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.ZoneId

private val ColOk = Color(0xFF3FB67A)
private val ColWarn = Color(0xFFE0A526)
private val ColOff = Color(0xFFE5534B)
private val ColSync = Color(0xFF4F8CFF)

private fun syncLabel(s: WatchDock.SyncState) = when (s) {
    WatchDock.SyncState.OK -> "Tersinkron"; WatchDock.SyncState.WARN -> "Sinkron lama"
    WatchDock.SyncState.SYNC -> "Menyinkron…"; WatchDock.SyncState.OFF -> "Terputus"
}

private fun syncColor(s: WatchDock.SyncState) = when (s) {
    WatchDock.SyncState.OK -> ColOk; WatchDock.SyncState.WARN -> ColWarn; WatchDock.SyncState.SYNC -> ColSync; WatchDock.SyncState.OFF -> ColOff
}

/**
 * Tab dock "Jam": kartu jam (mock-up, nama, baterai, indikator sinkron), delapan ubin data harian yang bisa dibuka menjadi panel rinci,
 * latihan dari jam, dan detail data. Port dari src/js/main/30-dock-jam.js. Membaca basis data sinkron lokal, jadi data terakhir tetap
 * tampil walau jam sedang tidak terhubung. Pembacaan ulang tiap 30 detik selama layar ini terbuka.
 *
 * [onOpenSettings] = membuka halaman pengaturan jam (hubungkan, koneksi latar, zona HR, structured workout) lewat roda gigi di kartu jam.
 */
@Composable
fun WatchDockScreen(
    ui: WatchDockUi,
    activities: List<ActivityEntity>,
    wx: WxSnapshot?,
    syncing: Boolean,
    lastSyncJsSec: Long,
    message: String,
    alias: String,
    onRefresh: () -> Unit,
    onSync: () -> Unit,
    onSaveAlias: (String) -> Unit,
    onPickGpx: (Uri) -> Unit,
    onOpenActivity: (Long) -> Unit,
    onOpenSettings: () -> Unit,
) {
    var open by remember { mutableStateOf("") }
    var syncOpen by remember { mutableStateOf(false) }
    var hypV by remember { mutableStateOf<Int?>(null) }
    var aliasDialog by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    val gpxPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) onPickGpx(uri) }

    // Baca ulang tiap 30 detik selama layar terbuka (jamStart/jamStop); juga sesaat setelah sinkron selesai.
    LaunchedEffect(Unit) { while (true) { onRefresh(); delay(WatchDock.POLL_MS) } }
    LaunchedEffect(syncing) { if (!syncing) onRefresh() }
    // Panel info sinkron menutup sendiri setelah 8 detik bila tidak sedang sinkron.
    LaunchedEffect(syncOpen, syncing) { if (syncOpen && !syncing) { delay(8000); syncOpen = false } }

    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        when (ui) {
            is WatchDockUi.Loading -> Nod("Membaca data jam…")
            is WatchDockUi.Unsupported -> Nod("Inti protokol jam tidak aktif pada APK ini. Unggah seluruh isi zip terbaru lalu bangun ulang.")
            is WatchDockUi.Failed -> Nod("Gagal membaca data jam: " + ui.message)
            is WatchDockUi.Ready -> {
                val m = ui.model
                val st = WatchDock.syncState(m, syncing, lastSyncJsSec)
                StatCard(
                    m = m, wx = WatchDock.wxPick(wx, m.now, m.tzMin), st = st, open = open, syncOpen = syncOpen,
                    syncing = syncing, lastSyncJsSec = lastSyncJsSec, hypV = hypV, onHyp = { hypV = it }, alias = alias,
                    onToggle = { k -> open = if (k.isNotEmpty() && open != k) k else "" },
                    onDot = { if (syncOpen) syncOpen = false else { syncOpen = true; if (m.conn) onSync() } },
                    onGear = { syncOpen = false; onOpenSettings() },
                    onGpx = { gpxPicker.launch(arrayOf("*/*")) },
                    onAction = { if (m.conn) onSync() else { syncOpen = false; onOpenSettings() } },
                    onEditName = { aliasDialog = true },
                )
                val shownNote = note.ifBlank { if (syncing || message.contains("gagal", ignoreCase = true)) message else "" }
                if (shownNote.isNotBlank()) Nod(shownNote)
                if (!m.ready) {
                    EvPanel(Modifier.fillMaxWidth()) {
                        Nod("Belum ada data. Hubungkan jam lewat roda gigi di kartu jam, lalu tekan Sinkron sekarang. Setelah itu kartu di sini terisi dan diperbarui otomatis saat tab ini terbuka.", 0, Modifier.padding(14.dp))
                    }
                } else {
                    WorkoutsSection(m, activities, onOpenActivity = onOpenActivity, onSync = onSync, onNote = { note = it })
                    DebugSection(m)
                    Nod("Stres belum bisa dibaca dari jam. Isian manual di Kondisi tidak ditimpa.")
                }
            }
        }
    }

    if (aliasDialog) {
        var text by remember { mutableStateOf(alias) }
        AlertDialog(
            onDismissRequest = { aliasDialog = false },
            title = { Text("Nama tampilan jam") },
            text = {
                OutlinedTextField(
                    value = text, onValueChange = { text = it.take(WatchDockReader.ALIAS_MAX) }, singleLine = true,
                    placeholder = { Text("Kosong = nama asli dari jam") },
                )
            },
            confirmButton = { TextButton(onClick = { onSaveAlias(text); aliasDialog = false; onRefresh() }) { Text("Simpan") } },
            dismissButton = { TextButton(onClick = { aliasDialog = false }) { Text("Batal") } },
        )
    }
}

@Composable
private fun Nod(text: String, top: Int = 0, modifier: Modifier = Modifier) {
    Text(text, modifier.padding(top = top.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

/** Isi tab Jam (tanpa kartu pembungkus tambahan; kartu utamanya milik AppRoot): mock-up + nama + baterai (kiri), dot sinkron / roda gigi / impor GPX (kanan atas), lalu data harian sebagai grid 2 kolom. */
@Composable
private fun StatCard(
    m: WatchModel, wx: com.endurancevault.app.domain.WatchWx?, st: WatchDock.SyncState, open: String, syncOpen: Boolean,
    syncing: Boolean, lastSyncJsSec: Long, hypV: Int?, onHyp: (Int) -> Unit, alias: String,
    onToggle: (String) -> Unit, onDot: () -> Unit, onGear: () -> Unit, onGpx: () -> Unit, onAction: () -> Unit, onEditName: () -> Unit,
) {
    Column(Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(top = 4.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                WatchFace(m, wx)
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            alias.ifBlank { m.devName.ifBlank { "Jam Huawei" } }, fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f).clickable(onClick = onEditName),
                        )
                        Box(Modifier.size(32.dp).clickable(onClick = onGpx), contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.Map, contentDescription = com.endurancevault.app.ui.i18n.Lang.tr("Impor GPX dan kirim rute ke jam"), modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Box(Modifier.size(32.dp).clickable(onClick = onGear), contentAlignment = Alignment.CenterEnd) {
                            Icon(Icons.Filled.Settings, contentDescription = com.endurancevault.app.ui.i18n.Lang.tr("Pengaturan Huawei Watch"), modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    val low = m.battery != null && m.battery <= 20
                    Column(Modifier.clickable { onToggle("bat") }, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            LinearProgressIndicator(
                                progress = { (m.battery ?: 0) / 100f }, modifier = Modifier.width(70.dp).height(8.dp).clip(RoundedCornerShape(4.dp)),
                                color = if (low) ColOff else ColOk, trackColor = MaterialTheme.colorScheme.surfaceVariant,
                            )
                            Text(if (m.battery != null) "${m.battery}%" else "–", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                        }
                        val be = m.batEst.txt.ifEmpty { if (m.battery != null) "Estimasi belum tersedia" else "" }
                        if (be.isNotEmpty()) Text(be, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Row(
                        Modifier.clip(RoundedCornerShape(8.dp)).background(syncColor(st).copy(alpha = 0.14f)).clickable(onClick = onDot)
                            .padding(horizontal = 8.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Box(Modifier.size(7.dp).clip(CircleShape).background(syncColor(st)))
                        Text(syncLabel(st), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            if (syncOpen) SyncPop(m, st, syncing, lastSyncJsSec, onAction)
            if (open == "bat") DetailPanel("Baterai jam", onClose = { onToggle("") }) { WatchDetail(m, "bat", hypV, onHyp) }
            if (m.ready) {
                val tiles = m.tiles.filter { it.k != "bat" && it.k != "sleep" }
                val sl = m.tiles.firstOrNull { it.k == "sleep" }
                tiles.chunked(2).forEach { pair ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        pair.forEach { t -> TileButton(t, open == t.k, Modifier.weight(1f).height(80.dp), fixed = true) { onToggle(t.k) } }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                    pair.firstOrNull { it.k == open }?.let { t -> DetailPanel(t.label, onClose = { onToggle("") }) { WatchDetail(m, t.k, hypV, onHyp) } }
                }
                // Ubin Tidur selalu selebar grid; saat collapse memuat grafik fase dan bar durasi, saat expand isinya pindah ke panel rinci.
                if (sl != null) {
                    TileButton(sl, open == "sleep", Modifier.fillMaxWidth(), extra = { if (open != "sleep") SleepTileExtra(m, hypV, onHyp) }) { onToggle("sleep") }
                    if (open == "sleep") DetailPanel(sl.label, onClose = { onToggle("") }) { WatchDetail(m, "sleep", hypV, onHyp) }
                }
            }
        }
    }
}

@Composable
private fun SyncPop(m: WatchModel, st: WatchDock.SyncState, busy: Boolean, lastSyncJsSec: Long, onAction: () -> Unit) {
    val ts = maxOf(m.lastSyncAt ?: 0L, lastSyncJsSec)
    val title = when (st) {
        WatchDock.SyncState.OK -> "Tersinkron"; WatchDock.SyncState.WARN -> "Sinkron sudah lama"
        WatchDock.SyncState.SYNC -> "Sedang sinkron…"; WatchDock.SyncState.OFF -> "Terputus"
    }
    Card(
        shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = BorderStroke(1.dp, syncColor(st)), modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(syncColor(st)))
                Text(title, fontWeight = FontWeight.Bold)
            }
            fun row(k: String, v: String) = k to v
            listOfNotNull(
                row("Sinkron terakhir", if (ts > 0) WatchDock.clock(ts, m.tzMin) + " · " + WatchDock.ago(m.now, ts) else "–"),
                row("Data jam terakhir", if (m.lastTs != null) WatchDock.ago(m.now, m.lastTs) else "–"),
                row("Koneksi", (if (m.conn) "Terhubung" else "Tidak terhubung") + (if (m.keepAlive) " · dijaga di latar" else "")),
                (m.syncErr ?: m.linkErr)?.let { row("Galat", it.take(80)) },
            ).forEach { (k, v) ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(k, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(v, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                }
            }
            Button(onClick = onAction, enabled = !busy) { Text(if (m.conn) "Sinkron sekarang" else "Hubungkan") }
        }
    }
}

@Composable
private fun TileButton(t: WatchTile, on: Boolean, modifier: Modifier, fixed: Boolean = false, extra: @Composable () -> Unit = {}, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Card(
        modifier = modifier.clickable(onClick = onClick), shape = RoundedCornerShape(13.dp),
        colors = CardDefaults.cardColors(containerColor = if (on) cs.primary.copy(alpha = 0.08f) else cs.surfaceVariant),
        border = BorderStroke(if (on) 1.2.dp else 0.8.dp, if (on) cs.primary else cs.outlineVariant),
    ) {
        Column(
            (if (fixed) Modifier.fillMaxSize() else Modifier.fillMaxWidth()).padding(horizontal = 11.dp, vertical = 8.dp),
            verticalArrangement = if (fixed) Arrangement.spacedBy(3.dp, Alignment.CenterVertically) else Arrangement.spacedBy(3.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(t.label, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                if (t.live) Box(Modifier.size(6.dp).clip(CircleShape).background(ColOff))
            }
            Text(t.value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            if (t.sub.isNotEmpty()) Text(t.sub, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
            if (t.bar != null) LinearProgressIndicator(
                progress = { t.bar.coerceIn(0, 100) / 100f }, modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                color = if (t.low) ColOff else cs.primary, trackColor = cs.outlineVariant,
            )
            extra()
        }
    }
}

@Composable
private fun DetailPanel(title: String, onClose: () -> Unit, content: @Composable () -> Unit) {
    Card(
        shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                Text("×", Modifier.clickable(onClick = onClose).padding(horizontal = 8.dp), style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            content()
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------------
// Latihan dari jam
// ---------------------------------------------------------------------------------------------------------------------

private fun dayOf(ts: Long): String = Instant.ofEpochSecond(ts).atZone(ZoneId.systemDefault()).toLocalDate().toString()
private fun clockOf(ts: Long): String = Instant.ofEpochSecond(ts).atZone(ZoneId.systemDefault()).toLocalTime().toString().take(5)

/** Aktivitas di Jadwal yang berasal dari latihan jam ini (srcKey watch:<start> atau cocok tanggal, jam, jarak, durasi). */
private fun savedActivity(w: WatchWorkout, acts: List<ActivityEntity>): ActivityEntity? {
    acts.firstOrNull { it.srcKey == "watch:${w.start}" }?.let { return it }
    val at = Instant.ofEpochSecond(w.start).atZone(ZoneId.systemDefault())
    val type = if (WatchDock.isBike(w)) "bike" else "run"
    return acts.firstOrNull { watchWorkoutMatches(it, at.toLocalDate().toString(), at.toLocalTime().toString().take(5), w.distance / 1000.0, w.duration, type) }
}

/** Jenis yang diimpor otomatis ke Jadwal saat sinkron (lari, trail, sepeda). */
private fun importable(w: WatchWorkout) = w.sportType == 1 || w.sportType == 11 || w.sportType == 3

@Composable
private fun WorkoutsSection(m: WatchModel, acts: List<ActivityEntity>, onOpenActivity: (Long) -> Unit, onSync: () -> Unit, onNote: (String) -> Unit) {
    val all = m.workouts; if (all.isEmpty()) return
    var showAll by remember { mutableStateOf(false) }
    var showMore by remember { mutableStateOf(false) }
    val day = dayOf(all[0].start); val today = dayOf(m.now)
    val grp = all.filter { dayOf(it.start) == day }; val multi = grp.size > 1
    val pager = rememberPagerState(pageCount = { grp.size })
    val idx = if (multi) pager.currentPage else 0

    fun openW(w: WatchWorkout) {
        val a = savedActivity(w, acts)
        when {
            a != null -> onOpenActivity(a.id)
            !WatchDock.savable(w) -> onNote("Latihan ini tidak punya data jarak, jadi tidak ada halaman detail aktivitas.")
            importable(w) -> onNote("Latihan ini belum ada di Jadwal. Tekan Impor untuk menyinkronkan dan menyimpannya, lalu buka lagi detailnya.")
            else -> onNote("Jenis latihan ini tidak diimpor otomatis ke Jadwal.")
        }
    }

    Column(Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(top = 6.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(if (day == today) "Latihan hari ini" else "Latihan terakhir dari jam", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (multi) Nod("${idx + 1}/${grp.size}") else if (day != today) Nod(WatchDock.ago(m.now, all[0].start))
            }
            if (multi) {
                HorizontalPager(pager, Modifier.fillMaxWidth(), pageSpacing = 8.dp) { i -> WorkoutBox(grp[i], acts, onOpen = { openW(grp[i]) }, onImport = onSync) }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    grp.indices.forEach { i ->
                        Box(Modifier.padding(horizontal = 3.dp).size(6.dp).clip(CircleShape).background(if (i == idx) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant))
                    }
                }
            } else WorkoutBox(grp[0], acts, onOpen = { openW(grp[0]) }, onImport = onSync)

            Row(
                Modifier.fillMaxWidth().clickable { showAll = !showAll; if (!showAll) showMore = false }.padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text("Riwayat dari jam (${all.size})", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                Text(if (showAll) "▴" else "▾")
            }
            if (showAll) {
                val rows = if (showMore) all else all.take(3)
                rows.forEach { w ->
                    val pc = WatchDock.paceCell(w)
                    Row(Modifier.fillMaxWidth().clickable { openW(w) }.padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        val d = dayOf(w.start).drop(5).split("-").reversed().joinToString("/")
                        Text("$d ${clockOf(w.start)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(w.sportName.ifBlank { "Latihan" }, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, maxLines = 1)
                        Text(if (w.distance > 0) WatchDock.dec(w.distance / 1000.0, 2) + " km" else "–", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                        Text((if (pc.v != "–") pc.v + " · " else "") + (if (w.avgHr > 0) "${w.avgHr}" else "–"), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                if (all.size > 3) Row(Modifier.fillMaxWidth().clickable { showMore = !showMore }.padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(if (showMore) "Tampilkan lebih sedikit" else "Lihat semua (${all.size})", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                    Text(if (showMore) "▴" else "›")
                }
            }
        }
    }
}

/** Kartu satu latihan: nama + jam + tombol Detail/Impor di header, strip jarak-durasi-pace-HR di bawahnya. Mengetuk kartu membuka detail aktivitas. */
@Composable
private fun WorkoutBox(w: WatchWorkout, acts: List<ActivityEntity>, onOpen: () -> Unit, onImport: () -> Unit) {
    val saved = savedActivity(w, acts) != null; val pc = WatchDock.paceCell(w); val sv = WatchDock.savable(w)
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen), shape = RoundedCornerShape(13.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text(w.sportName.ifBlank { "Latihan" }, fontWeight = FontWeight.Bold)
                    Text(clockOf(w.start), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (sv && saved) Text("Detail ›", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                else if (sv && importable(w)) Text("Impor", Modifier.clickable(onClick = onImport), fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Stat(if (w.distance > 0) WatchDock.dec(w.distance / 1000.0, 2) + " km" else "–", "jarak")
                Stat(WatchDock.dur(w.duration), "durasi")
                Stat(pc.v, pc.u)
                Stat(if (w.avgHr > 0) "${w.avgHr}" else "–", "bpm" + (if (w.maxHr > 0) " · maks ${w.maxHr}" else ""))
            }
            if (sv && !saved) Nod(if (importable(w)) "Belum ada di Jadwal; ikut tersimpan otomatis saat sinkron." else "Jenis latihan ini tidak diimpor otomatis ke Jadwal.")
        }
    }
}

@Composable
private fun Stat(v: String, l: String) {
    Column {
        Text(v, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
        Text(l, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Detail data untuk mencocokkan angka dengan layar jam (lipat/buka). */
@Composable
private fun DebugSection(m: WatchModel) {
    var on by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().clickable { on = !on }.padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Detail data (untuk mencocokkan dengan jam)", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
            Text(if (on) "▴" else "▾")
        }
        if (on) Column(verticalArrangement = Arrangement.spacedBy(3.dp)) { m.debug.rows.forEach { Nod("• $it") } }
    }
}
