package com.endurancevault.app.data

import android.content.Context
import com.endurancevault.app.domain.ReadinessMetric
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

/** Daily readiness snapshots. A same-day snapshot is replaced only when the morning check is added. */
object ReadinessHistoryStore {
    data class Snapshot(val date: LocalDate, val score: Int, val morning: Boolean, val factors: Map<String, Int>)
    private const val PREFS = "readiness_history"
    private const val KEY = "snapshots"

    fun record(context: Context, date: LocalDate, metric: ReadinessMetric, morning: Boolean) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val all = load(context).associateBy { it.date }.toMutableMap()
        val old = all[date]
        if (old == null || (!old.morning && morning)) {
            all[date] = Snapshot(date, metric.score, morning, metric.parts.mapNotNull { p -> p.score?.let { p.key to it } }.toMap())
            val json = JSONArray()
            all.values.sortedBy { it.date }.takeLast(180).forEach { s ->
                val factors = JSONObject(); s.factors.forEach { (k, v) -> factors.put(k, v) }
                json.put(JSONObject().put("date", s.date.toString()).put("score", s.score).put("morning", s.morning).put("factors", factors))
            }
            prefs.edit().putString(KEY, json.toString()).apply()
        }
    }

    fun load(context: Context): List<Snapshot> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.getJSONObject(i); val factors = o.optJSONObject("factors") ?: JSONObject()
                val map = factors.keys().asSequence().mapNotNull { k -> if (factors.has(k)) k to factors.optInt(k) else null }.toMap()
                Snapshot(LocalDate.parse(o.getString("date")), o.getInt("score"), o.optBoolean("morning"), map)
            }.sortedBy { it.date }
        }.getOrDefault(emptyList())
    }
}
