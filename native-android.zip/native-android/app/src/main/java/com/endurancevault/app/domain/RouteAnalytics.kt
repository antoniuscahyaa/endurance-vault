package com.endurancevault.app.domain

import kotlin.math.abs

/** Ringkasan profil elevasi dari pasangan (jarak km, elevasi meter). Tidak mengubah D+/D− sumber aktivitas. */
object RouteAnalytics {
    data class ElevationSummary(
        val minMeters: Double,
        val maxMeters: Double,
        val rangeMeters: Double,
        val steepestUpPercent: Double?,
        val steepestDownPercent: Double?,
    )

    fun summarize(profile: List<Pair<Double, Double>>): ElevationSummary? {
        val points = profile.filter { it.first.isFinite() && it.second.isFinite() }
            .sortedBy { it.first }
        if (points.size < 2) return null
        val min = points.minOf { it.second }
        val max = points.maxOf { it.second }
        val grades = points.zipWithNext().mapNotNull { (a, b) ->
            val distanceMeters = (b.first - a.first) * 1000.0
            if (distanceMeters < 20.0) null
            else ((b.second - a.second) / distanceMeters) * 100.0
        }
        return ElevationSummary(
            minMeters = min,
            maxMeters = max,
            rangeMeters = max - min,
            steepestUpPercent = grades.filter { it > 0 }.maxOrNull(),
            steepestDownPercent = grades.filter { it < 0 }.minOrNull(),
        )
    }
}
