package com.endurancevault.app.domain

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class PainAreaGroup(val id: String, val title: String, val areas: List<Pair<String, String>>)
data class PainAlert(val area: String, val days: Int, val maxSeverity: Int, val acute: Boolean)
data class PrehabAdvice(val area: String, val exercises: List<String>, val caution: String)
data class BikePlan(val minutes: Int, val estimatedKm: Double, val multiplier: Double, val hrBand: IntRange, val capped: Boolean, val replacesQuality: Boolean)
data class ActiveLegPain(val area: String, val side: String, val severity: Int, val date: LocalDate)
data class BikeSessionEvaluation(val actualMinutes: Int, val targetMinutes: Int, val loadRatio: Double?, val averageHr: Int?, val tooHard: Boolean, val verdict: String)
data class BikeOffsetCalibration(val count: Int, val heavy: Int, val light: Int, val fit: Int, val suggestedOffset: Int?)
data class ReturnRunPhase(val phase: Int, val percent: Int, val dayNumber: Int)

/** Native port of legacy 19b/19c injury rules. Advice is informational, not a diagnosis or treatment. */
object InjuryPrevention {
    val groups = listOf(
        PainAreaGroup("lower", "Kaki bawah", listOf("betis" to "Betis", "tibia" to "Tulang kering", "ankle" to "Ankle", "achilles" to "Achilles", "tumit" to "Tumit", "plantar" to "Plantar", "pkaki" to "Punggung kaki")),
        PainAreaGroup("upperleg", "Lutut dan paha", listOf("lutut" to "Lutut", "itband" to "IT band", "pahad" to "Paha depan", "pahab" to "Paha belakang")),
        PainAreaGroup("trunk", "Panggul dan badan", listOf("groin" to "Pangkal paha", "glute" to "Glute", "pbawah" to "Punggung bawah", "bahu" to "Bahu"))
    )
    val sides = listOf("k" to "Kiri", "r" to "Kanan", "b" to "Keduanya")
    val moments = listOf("sb" to "Sebelum lari", "sl" to "Saat lari", "sa" to "Setelah lari")
    private val legAreas = setOf("betis", "tibia", "ankle", "achilles", "tumit", "plantar", "pkaki", "lutut", "itband", "pahad", "pahab")
    private val prehab = mapOf(
        "betis" to listOf("Calf raise lambat 3×12 (turun 3 detik)", "Peregangan betis dinding 2×30 detik", "Foam roll betis 1 menit per sisi"),
        "tibia" to listOf("Toe raise 3×15", "Jalan di tumit 2×30 langkah", "Kurangi tanjakan dan jalan di permukaan keras beberapa hari"),
        "ankle" to listOf("Berdiri satu kaki 3×30 detik", "Ankle alphabet", "Band eversi 2×15"),
        "achilles" to listOf("Calf raise isometrik 5×30 detik", "Kurangi lompatan dan tanjakan curam", "Periksa usia dan kondisi sepatu"),
        "tumit" to listOf("Peregangan fasia plantar 3×30 detik", "Guling bola di telapak 2 menit", "Towel scrunch 3×15"),
        "plantar" to listOf("Peregangan fasia plantar 3×30 detik", "Guling bola di telapak 2 menit", "Calf raise lambat 3×12"),
        "pkaki" to listOf("Towel scrunch 3×15", "Longgarkan simpul sepatu", "Mobilitas jari kaki 2 menit"),
        "lutut" to listOf("Glute bridge 3×12", "Step-down terkontrol 3×8", "Terminal knee extension band 2×15"),
        "itband" to listOf("Side plank 3×30 detik", "Clamshell band 2×15", "Foam roll paha luar 1 menit"),
        "pahad" to listOf("Peregangan paha depan 2×30 detik", "Split squat 3×8", "Foam roll paha depan 1 menit"),
        "pahab" to listOf("Nordic curl bantuan 3×5", "Romanian deadlift ringan 3×8", "Hindari sprint sampai nyeri reda"),
        "groin" to listOf("Adductor squeeze 3×10 (tahan 5 detik)", "Copenhagen plank lutut 3×20 detik", "Persingkat langkah dan hindari belok tajam"),
        "glute" to listOf("Glute bridge 3×12", "Clamshell band 2×15", "Peregangan piriformis 2×30 detik"),
        "pbawah" to listOf("Cat-cow 2 menit", "Bird dog 3×8 per sisi", "Dead bug 3×8"),
        "bahu" to listOf("Mobilitas bahu dengan band 2×10", "Postur lengan rileks dan ayunan santai", "Wall slide 2×10")
    )
    fun areaName(id: String) = groups.flatMap { it.areas }.firstOrNull { it.first == id }?.second ?: id
    fun sideName(id: String) = sides.firstOrNull { it.first == id }?.second ?: id
    fun momentName(id: String) = moments.firstOrNull { it.first == id }?.second ?: id
    fun alerts(entries: List<PainReadinessEntry>, today: LocalDate): List<PainAlert> {
        val days = (0..3).map { today.minusDays(it.toLong()) }.toSet()
        return entries.filter { it.date in days && it.severity >= 2 }.groupBy { it.area }.mapNotNull { (area, xs) ->
            val n = xs.map { it.date }.distinct().size
            val acute = xs.any { it.date >= today.minusDays(1) && it.severity >= 4 }
            if (n >= 3 || acute) PainAlert(area, n, xs.maxOf { it.severity }, acute) else null
        }.sortedWith(compareByDescending<PainAlert> { it.maxSeverity }.thenByDescending { it.days })
    }
    fun prehab(entries: List<PainReadinessEntry>, today: LocalDate): PrehabAdvice? {
        val recent = entries.filter { !it.date.isAfter(today) && !it.date.isBefore(today.minusDays(3)) }
        val alert = alerts(entries, today).firstOrNull()
        val entry = alert?.let { a -> recent.filter { it.area == a.area }.maxByOrNull { it.severity } }
            ?: recent.filter { it.severity >= 2 }.maxByOrNull { it.severity }
            ?: return null
        val list = prehab[entry.area] ?: return null
        val caution = if (entry.severity >= 4) "Nyeri berat (4 ke atas): istirahatkan area ini. Pertimbangkan pemeriksaan tenaga kesehatan, terutama bila tidak membaik." else "Saran umum, bukan terapi. Bila nyeri menetap lebih dari seminggu atau memburuk, periksakan ke tenaga kesehatan."
        return PrehabAdvice(entry.area, list, caution)
    }
    fun activeLegPain(entries: List<PainReadinessEntry>, today: LocalDate): List<ActiveLegPain> =
        entries.filter { it.area in legAreas && it.date in setOf(today, today.minusDays(1)) }
            .groupBy { it.area to it.side }.mapNotNull { (key, xs) -> xs.maxByOrNull { it.date } }
            .filter { it.severity >= 3 }.sortedByDescending { it.severity }
            .map { ActiveLegPain(it.area, it.side, it.severity, it.date) }

    // TRIMP weighting and duration conversion used by legacy 19c.
    private fun weight(hr: Double, rest: Double, maxHr: Double): Double {
        val r = ((hr - rest) / (maxHr - rest).coerceAtLeast(1.0)).coerceIn(0.0, 1.05)
        return if (r <= 0) 0.0 else r * exp(1.92 * r)
    }
    fun bikeReplacement(runMinutes: Int, runKind: String, runHrBand: IntRange, easyBikeBand: IntRange,
                        restHr: Int, maxHr: Int, bikeOffset: Int = 8, modeFactor: Double = 1.25,
                        bikeSpeedKmh: Double = 20.0, qualityMinutes: Int = 0): BikePlan? {
        if (runMinutes <= 0) return null
        val offset = bikeOffset.coerceIn(0, 20)
        val bikeBand = (easyBikeBand.first - offset)..(easyBikeBand.last - offset)
        val quality = runKind == "quality"
        val bikeW = weight(bikeBand.average(), restHr.toDouble(), maxHr.toDouble())
        val mode = modeFactor.coerceIn(1.0, 1.6)
        val hard = qualityMinutes.coerceIn(0, runMinutes)
        val runLoad = if (quality && hard > 0) {
            hard * weight(runHrBand.average(), restHr.toDouble(), maxHr.toDouble()) +
                (runMinutes - hard) * weight(easyBikeBand.average(), restHr.toDouble(), maxHr.toDouble())
        } else runMinutes * weight(easyBikeBand.average(), restHr.toDouble(), maxHr.toDouble())
        val k = if (bikeW > 0) (mode * runLoad / (runMinutes * bikeW)).coerceIn(1.0, if (quality && hard > 0) 2.5 else 2.0) else mode
        val rounded = (runMinutes * k / 5.0).roundToInt() * 5
        val capped = rounded > 300
        val mins = rounded.coerceIn(20, 300)
        return BikePlan(mins, (mins / 60.0 * bikeSpeedKmh.coerceIn(10.0, 40.0) * 10).roundToInt() / 10.0, k, bikeBand, capped, quality)
    }
    fun evaluateBikeSession(plan: BikePlan, actualMinutes: Int, averageHr: Int?, restHr: Int, maxHr: Int): BikeSessionEvaluation? {
        if (actualMinutes <= 0 || plan.minutes <= 0) return null
        val known = averageHr != null && averageHr > 0
        val ratio = if (known) {
            val targetWeight = weight(plan.hrBand.average(), restHr.toDouble(), maxHr.toDouble()) * plan.minutes
            val actualWeight = weight(averageHr!!.toDouble(), restHr.toDouble(), maxHr.toDouble()) * actualMinutes
            if (targetWeight > 0) actualWeight / targetWeight else null
        } else actualMinutes.toDouble() / plan.minutes
        val hard = known && averageHr!! > plan.hrBand.last + 3
        val verdict = when { ratio == null -> "unknown"; ratio < .85 -> "short"; ratio > 1.2 -> "long"; else -> "ok" }
        return BikeSessionEvaluation(actualMinutes, plan.minutes, ratio, averageHr, hard, verdict)
    }
    /** Legacy calibration: up +2 bpm if at least two sessions felt hard without high HR; down -2 if HR high but felt easy. */
    fun calibrateBikeOffset(samples: List<Pair<BikeSessionEvaluation, Int>>, currentOffset: Int): BikeOffsetCalibration {
        val recent = samples.take(6)
        var heavy = 0; var light = 0; var fit = 0
        recent.forEach { (ev, feel) ->
            if (ev.averageHr == null || ev.loadRatio == null) return@forEach
            when {
                !ev.tooHard && feel >= 4 -> heavy++
                ev.tooHard && feel <= 2 -> light++
                else -> fit++
            }
        }
        val enough = heavy + light + fit >= 3
        val suggestion = when {
            enough && heavy >= 2 && heavy > light && currentOffset < 20 -> (currentOffset + 2).coerceAtMost(20)
            enough && light >= 2 && light > heavy && currentOffset > 0 -> (currentOffset - 2).coerceAtLeast(0)
            else -> null
        }
        return BikeOffsetCalibration(heavy + light + fit, heavy, light, fit, suggestion)
    }
    fun shouldOfferBikeSwap(entries: List<PainReadinessEntry>, today: LocalDate) = activeLegPain(entries, today).isNotEmpty()
    fun recovered(entries: List<PainReadinessEntry>, today: LocalDate): Boolean {
        val bySite = entries.filter { it.area in legAreas && !it.date.isAfter(today) && !it.date.isBefore(today.minusDays(14)) }.groupBy { it.area to it.side }
        var found = false
        for (xs in bySite.values) {
            val sorted = xs.sortedByDescending { it.date }
            if (sorted.any { it.severity >= 3 }) {
                found = true
                val a = sorted.getOrNull(0) ?: return false
                val b = sorted.getOrNull(1) ?: return false
                if (a.severity >= 3 || b.severity >= 3 || ChronoUnit.DAYS.between(a.date, today) > 1 || ChronoUnit.DAYS.between(b.date, a.date) > 2) return false
            }
        }
        return found
    }
    fun returnRunPhase(start: LocalDate, today: LocalDate): ReturnRunPhase? {
        val days = ChronoUnit.DAYS.between(start, today).toInt()
        if (days !in 0..20) return null
        val phase = days / 7 + 1
        return ReturnRunPhase(phase, listOf(65, 80, 90)[phase - 1], days + 1)
    }
    /** Apply the legacy 3-week gradual return to a generated plan day. */
    fun applyReturnRun(day: PDay, phase: ReturnRunPhase): Boolean {
        if (day.bikeReplacement != null || day.km <= 0.0 || day.kind !in setOf("easy", "short", "quality", "medium", "long")) return false
        val originalKm = day.km
        val quality = day.kind == "quality"
        val toEasy = (phase.phase == 1 && (quality || day.kind == "long" || day.kind == "medium")) || (phase.phase == 2 && quality)
        val reduced = max(3.0, (originalKm * phase.percent / 100.0).roundToInt().toDouble()).coerceAtMost(originalKm)
        if (toEasy) {
            day.kind = "easy"; day.grp = "easy"; day.title = "Easy (kembali ke lari)"
            day.detail = "Kembali berlari bertahap, fase ${phase.phase} dari 3 (${phase.percent}% rencana). Lari pelan di HR easy, rute datar, tanpa interval atau tanjakan. Hentikan dan kembali ke sepeda bila nyeri naik."
        } else {
            day.detail = (day.detail + " Kembali berlari bertahap, fase ${phase.phase} dari 3 (${phase.percent}% rencana). Hentikan bila nyeri naik.").trim()
        }
        day.km = reduced
        return true
    }
}
