package com.endurancevault.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import com.endurancevault.app.data.HuaweiSleepParity
import com.endurancevault.app.domain.NightBar
import com.endurancevault.app.domain.WatchDock
import com.endurancevault.app.domain.WatchHrToday
import com.endurancevault.app.domain.WatchSpo2Point
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/**
 * Grafik dock Jam. Semua digambar di kanvas virtual lebar 320 (sama dengan viewBox SVG di web) lalu diskalakan ke lebar layar,
 * jadi koordinat, ukuran batang, dan posisi label sama persis dengan versi web.
 */

private const val VW = 320f

internal val ColBar = Color(0xFF2F6FD0)
internal val ColGood = Color(0xFF3FB67A)
internal val ColHr = Color(0xFFE5534B)
internal val ColKcal = Color(0xFFE5934B)
internal val ColDist = Color(0xFF1FA3A3)
internal val ColSpo2 = Color(0xFF3B9AD9)

internal fun stageColor(k: String): Color = Color(
    when (k) {
        "deep" -> WatchDock.C_DEEP
        "rem" -> WatchDock.C_REM
        "awake" -> WatchDock.C_AWAKE
        "extra" -> WatchDock.C_EXTRA
        else -> WatchDock.C_LIGHT
    },
)

private class Ink(val tm: TextMeasurer, val line: Color, val muted: Color, val ink: Color, val accent: Color)

@Composable
private fun rememberInk(): Ink {
    val tm = rememberTextMeasurer()
    val cs = MaterialTheme.colorScheme
    return Ink(tm, cs.onSurface.copy(alpha = 0.12f), cs.onSurfaceVariant, cs.onSurface, cs.primary)
}

/** Teks di koordinat kanvas virtual; (x, y) = titik jangkar di garis dasar, anchor 0 = awal, 1 = tengah, 2 = akhir. */
private fun DrawScope.txt(ink: Ink, s: String, x: Float, y: Float, anchor: Int, color: Color, size: Float = 9f, bold: Boolean = false) {
    val sc = this.size.width / VW
    val r = ink.tm.measure(s, TextStyle(color = color, fontSize = (size * sc).toSp(), fontWeight = if (bold) FontWeight.SemiBold else FontWeight.Normal))
    val w = r.size.width.toFloat()
    val left = when (anchor) { 1 -> x * sc - w / 2f; 2 -> x * sc - w; else -> x * sc }
    drawText(r, topLeft = Offset(left, y * sc - r.firstBaseline))
}

private fun DrawScope.line(x1: Float, y1: Float, x2: Float, y2: Float, color: Color, w: Float = 1f, dash: FloatArray? = null) {
    val sc = size.width / VW
    drawLine(color, Offset(x1 * sc, y1 * sc), Offset(x2 * sc, y2 * sc), strokeWidth = w * sc, pathEffect = dash?.let { d -> PathEffect.dashPathEffect(FloatArray(d.size) { d[it] * sc }) })
}

private fun DrawScope.grid(ink: Ink, h: Float, top: Float, fmt: (Double) -> String, lines: Boolean, labels: Boolean) {
    for (f in floatArrayOf(0f, 0.5f, 1f)) {
        val y = h - f * h
        if (lines) line(0f, y, VW, y, ink.line)
        if (labels && f > 0f) txt(ink, fmt((top * f).toDouble()), 2f, y - 2f, 0, ink.muted)
    }
}

@Composable
private fun ChartBox(h: Float, desc: String, draw: DrawScope.(Ink) -> Unit) {
    val ink = rememberInk()
    Canvas(Modifier.fillMaxWidth().aspectRatio(VW / (h + 16f)).semantics { contentDescription = desc }) { this.draw(ink) }
}

data class BarItem(val l: String, val v: Double, val now: Boolean = false, val ok: Boolean = false)
data class RangeItem(val l: String, val lo: Double, val hi: Double, val avg: Double, val now: Boolean = false)
data class LineItem(val l: String, val v: Double, val now: Boolean = false)

/** Batang vertikal (jamBarsSvg). Kosong bila semua nol. */
@Composable
fun WatchBarsChart(
    items: List<BarItem>, desc: String, goal: Double = 0.0, avg: Double = 0.0, vals: Boolean = false,
    fmt: (Double) -> String = { WatchDock.num(it) }, color: Color = ColBar, h: Float = 96f, bw: Float = 26f,
) {
    var top = 0.0; items.forEach { if (it.v > top) top = it.v }
    if (!(top > 0)) return
    if (goal > top) top = goal; if (avg > top) top = avg
    val topN = WatchDock.nice(top * 1.1).toFloat()
    ChartBox(h, desc) { ink ->
        val n = items.size; val slot = VW / n; val bwv = min(bw, slot * 0.62f)
        grid(ink, h, topN, fmt, lines = true, labels = false)
        items.forEachIndexed { i, d ->
            val bh = if (d.v > 0) max(2f, (d.v / topN * h).toFloat()) else 0f; val cx = slot * i + slot / 2
            if (bh > 0) {
                val sc = size.width / VW
                val c = if (d.ok) ColGood.copy(alpha = if (d.now) 1f else 0.85f) else color.copy(alpha = if (d.now) 1f else 0.5f)
                drawRoundRect(c, Offset((cx - bwv / 2) * sc, (h - bh) * sc), Size(bwv * sc, bh * sc), CornerRadius(min(4f, bwv / 3) * sc))
            }
            if (vals && d.v > 0) txt(ink, fmt(d.v), cx, h - bh - 3, 1, ink.ink, 8.5f, bold = true)
        }
        var yg: Float? = null
        if (goal > 0) {
            val y = (h - goal / topN * h).toFloat(); yg = y
            line(0f, y, VW, y, ColGood, 1.2f, floatArrayOf(4f, 3f)); txt(ink, fmt(goal), VW, y - 3, 2, ColGood)
        }
        if (avg > 0) {
            val ya = (h - avg / topN * h).toFloat(); val dy = if (yg != null && kotlin.math.abs(ya - yg) < 11) 11f else -3f
            line(0f, ya, VW, ya, ink.muted.copy(alpha = 0.8f), 1f, floatArrayOf(2f, 3f)); txt(ink, "rata-rata " + fmt(avg), VW, ya + dy, 2, ink.muted)
        }
        grid(ink, h, topN, fmt, lines = false, labels = true)
        items.forEachIndexed { i, d -> if (d.l.isNotEmpty()) txt(ink, d.l, slot * i + slot / 2, h + 12, 1, if (d.now) ink.accent else ink.muted, bold = d.now) }
    }
}

/** Batang rentang (min-maks) dengan titik rata-rata (jamRangeSvg); hi <= 0 dilewati. */
@Composable
fun WatchRangeChart(
    items: List<RangeItem>, desc: String, step: Double = 10.0, pad: Double = 3.0, span: Double = 20.0, cap: Double? = null,
    fmt: (Double) -> String = { WatchDock.num(it) }, color: Color = ColBar, h: Float = 96f,
) {
    val ok = items.filter { it.hi > 0 }; if (ok.isEmpty()) return
    val (lo, hi) = WatchDock.rangeAxis(ok.minOf { if (it.lo > 0) it.lo else it.hi }, ok.maxOf { it.hi }, step, pad, span, cap)
    ChartBox(h, desc) { ink ->
        val sc = size.width / VW; val n = items.size; val slot = VW / n
        fun yv(v: Double) = (h - (v - lo) / (hi - lo) * h).toFloat()
        for (f in doubleArrayOf(0.0, 0.5, 1.0)) {
            val v = lo + (hi - lo) * f; val y = (h - f * h).toFloat()
            line(0f, y, VW, y, ink.line); txt(ink, fmt(v), 2f, y - 2, 0, ink.muted)
        }
        items.forEachIndexed { i, d ->
            val cx = slot * i + slot / 2
            if (d.hi > 0) {
                val y1 = yv(d.hi); val y2 = yv(if (d.lo > 0) d.lo else d.hi); val hh = max(6f, y2 - y1)
                drawRoundRect(color.copy(alpha = if (d.now) 0.5f else 0.28f), Offset((cx - 5) * sc, y1 * sc), Size(10 * sc, hh * sc), CornerRadius(5 * sc))
                if (d.avg > 0) drawCircle(color, 3 * sc, Offset(cx * sc, yv(d.avg) * sc))
                txt(ink, fmt(if (d.avg > 0) d.avg else d.hi), cx, y1 - 4, 1, ink.ink, 8.5f, bold = true)
            }
            if (d.l.isNotEmpty()) txt(ink, d.l, cx, h + 12, 1, if (d.now) ink.accent else ink.muted, bold = d.now)
        }
    }
}

/** Garis dengan titik per hari (jamLineSvg); v <= 0 = tanpa data (garis terputus). */
@Composable
fun WatchLineChart(
    items: List<LineItem>, desc: String, step: Double = 5.0, span: Double = 10.0,
    fmt: (Double) -> String = { WatchDock.num(it) }, color: Color = ColBar, h: Float = 96f,
) {
    val ok = items.filter { it.v > 0 }; if (ok.isEmpty()) return
    val (lo, hi) = WatchDock.lineAxis(ok.minOf { it.v }, ok.maxOf { it.v }, step, span)
    ChartBox(h, desc) { ink ->
        val sc = size.width / VW; val n = items.size; val slot = VW / n
        fun yv(v: Double) = (h - (v - lo) / (hi - lo) * h).toFloat()
        for (f in doubleArrayOf(0.0, 0.5, 1.0)) {
            val v = lo + (hi - lo) * f; val y = (h - f * h).toFloat()
            line(0f, y, VW, y, ink.line); txt(ink, fmt(v), 2f, y - 2, 0, ink.muted)
        }
        val path = Path(); var pen = false
        items.forEachIndexed { i, d ->
            val cx = slot * i + slot / 2
            if (d.v > 0) { val y = yv(d.v); if (pen) path.lineTo(cx * sc, y * sc) else path.moveTo(cx * sc, y * sc); pen = true } else pen = false
        }
        drawPath(path, color, style = Stroke(1.8f * sc, cap = StrokeCap.Round, join = StrokeJoin.Round))
        items.forEachIndexed { i, d ->
            val cx = slot * i + slot / 2
            if (d.v > 0) { val y = yv(d.v); drawCircle(color, (if (d.now) 4f else 3f) * sc, Offset(cx * sc, y * sc)); txt(ink, fmt(d.v), cx, y - 7, 1, ink.ink, 8.5f, bold = true) }
            if (d.l.isNotEmpty()) txt(ink, d.l, cx, h + 12, 1, if (d.now) ink.accent else ink.muted, bold = d.now)
        }
    }
}

/** Batang bertumpuk fase tidur per malam (jamStackSvg). */
@Composable
fun WatchStackChart(items: List<NightBar>, desc: String, h: Float = 96f) {
    var mx = 0; items.forEach { if (it.asleep > mx) mx = it.asleep }
    if (mx <= 0) return
    val topH = max(8, ceil(mx / 60.0 + 0.2).toInt())
    ChartBox(h, desc) { ink ->
        val sc = size.width / VW; val n = items.size; val slot = VW / n; val bw = min(26f, slot * 0.62f)
        val fh = { v: Double -> Math.round(v).toString() + "j" }
        grid(ink, h, topH.toFloat(), fh, lines = true, labels = false)
        items.forEachIndexed { i, d ->
            val cx = slot * i + slot / 2; var y = h
            d.stages.forEach { (k, m) ->
                val bh = m / 60f / topH * h; if (!(bh > 0)) return@forEach
                y -= bh; drawRect(stageColor(k), Offset((cx - bw / 2) * sc, y * sc), Size(bw * sc, bh * sc))
            }
            if (d.asleep > 0) txt(ink, WatchDock.dec(d.asleep / 60.0, 1), cx, y - 3, 1, ink.ink, 8.5f, bold = true)
        }
        grid(ink, h, topH.toFloat(), fh, lines = false, labels = true)
        items.forEachIndexed { i, d -> if (d.l.isNotEmpty()) txt(ink, d.l, slot * i + slot / 2, h + 12, 1, if (d.now) ink.accent else ink.muted, bold = d.now) }
    }
}

/**
 * Hipnogram: blok fase tidur sepanjang malam seperti layar Sleep di jam. Empat jalur dari atas: terjaga, REM, ringan, dalam.
 * cursor = posisi slider 0..1000 (null = tanpa penanda); hit = indeks blok yang disorot (blok lain diredupkan).
 */
@Composable
fun WatchHypnogram(blocks: List<HuaweiSleepParity.Block>, t0: Long, t1: Long, tzMin: Int, desc: String, cursor: Int? = null, hit: Int? = null) {
    if (blocks.isEmpty() || t1 <= t0) return
    val h = 88f
    ChartBox(h, desc) { ink ->
        val sc = size.width / VW; val lh = h / 4; val bh = lh - 5
        val lane = mapOf("awake" to 0, "rem" to 1, "light" to 2, "deep" to 3)
        fun xt(t: Long) = max(0f, min(VW, (t - t0).toFloat() / (t1 - t0) * VW))
        for (i in 0 until 4) { val gy = i * lh + lh / 2; line(0f, gy, VW, gy, ink.line.copy(alpha = ink.line.alpha * 0.5f)) }
        var prevE = -1L; var prevLn = -1
        blocks.forEach { bk ->
            val k = if (lane.containsKey(bk.k)) bk.k else "light"; val ln = lane.getValue(k)
            val x1 = xt(bk.s); val w = max(1.6f, xt(bk.e) - x1)
            if (prevE == bk.s && prevLn != ln) line(x1, prevLn * lh + lh / 2, x1, ln * lh + lh / 2, ink.muted.copy(alpha = 0.45f))
            prevE = bk.e; prevLn = ln
        }
        blocks.forEachIndexed { idx, bk ->
            val k = if (lane.containsKey(bk.k)) bk.k else "light"; val ln = lane.getValue(k)
            val x1 = xt(bk.s); val w = max(1.6f, xt(bk.e) - x1)
            val a = if (hit == null || hit == idx) 1f else 0.4f
            drawRoundRect(stageColor(k).copy(alpha = a), Offset(x1 * sc, (ln * lh + (lh - bh) / 2) * sc), Size(w * sc, bh * sc), CornerRadius(2 * sc))
        }
        val hrs = (t1 - t0) / 3600.0; val step = if (hrs > 9) 2 else 1
        val first = ceil((t0 + tzMin * 60.0) / 3600.0 / step).toLong() * step * 3600 - tzMin * 60L
        var t = first
        while (t < t1) {
            val tx = xt(t)
            if (tx >= 14 && tx <= VW - 14) {
                val hh = (((Math.floorDiv(t + tzMin * 60L, 3600L) % 24) + 24) % 24).toInt()
                txt(ink, (if (hh < 10) "0" else "") + hh, tx, h + 12, 1, ink.muted)
            }
            t += step * 3600L
        }
        if (cursor != null) { val cx = cursor / 1000f * VW; line(cx, 0f, cx, h, ink.muted) }
    }
}

/** Grafik HR hari ini (jamHrChart): garis rata-rata, pita min-maks tiap 10 menit, garis "sekarang". */
@Composable
fun WatchHrChart(hr: WatchHrToday) {
    val h = 110f
    val (lo, hi) = WatchDock.hrAxis(hr.min, hr.max)
    ChartBox(h, "Grafik detak jantung hari ini") { ink ->
        val sc = size.width / VW
        fun xt(t: Long) = max(0f, min(VW, (t - hr.t0).toFloat() / 86400f * VW))
        fun yv(v: Double) = (h - (v - lo) / (hi - lo) * h).toFloat()
        for (v in intArrayOf(lo, Math.round((lo + hi) / 2.0).toInt(), hi)) {
            val y = yv(v.toDouble()); line(0f, y, VW, y, ink.line); txt(ink, v.toString(), 2f, y - 2, 0, ink.muted)
        }
        val half = WatchDock.BUCKET / 2
        val pts = hr.series
        if (pts.size > 1) {
            val band = Path()
            pts.forEachIndexed { i, p -> val x = xt(p.t + half) * sc; val y = yv(if (p.hrMax > 0) p.hrMax else p.hr) * sc; if (i == 0) band.moveTo(x, y) else band.lineTo(x, y) }
            pts.asReversed().forEach { p -> band.lineTo(xt(p.t + half) * sc, yv(if (p.hrMin > 0) p.hrMin else p.hr) * sc) }
            band.close(); drawPath(band, ColHr.copy(alpha = 0.14f))
        }
        val ln = Path()
        pts.forEachIndexed { i, p -> val x = xt(p.t + half) * sc; val y = yv(p.hr) * sc; if (i == 0) ln.moveTo(x, y) else ln.lineTo(x, y) }
        drawPath(ln, ColHr, style = Stroke(1.8f * sc, cap = StrokeCap.Round, join = StrokeJoin.Round))
        val nx = xt(hr.now); line(nx, 0f, nx, h, ink.accent.copy(alpha = 0.6f), 1f, floatArrayOf(3f, 3f))
        listOf("00", "06", "12", "18", "24").forEachIndexed { i, s -> txt(ink, s, i * VW / 4, h + 12, if (i == 0) 0 else if (i == 4) 2 else 1, ink.muted) }
    }
}

/** Titik dan garis sepanjang hari 0-24 jam (jamTimeSvg), dipakai untuk SpO2 hari ini; lo/hi = batas sumbu (%). */
@Composable
fun WatchTimeChart(pts: List<WatchSpo2Point>, t0: Long, now: Long, lo: Double, hi: Double, desc: String) {
    if (pts.size < 2) return
    val h = 90f
    ChartBox(h, desc) { ink ->
        val sc = size.width / VW
        fun xt(t: Long) = max(0f, min(VW, (t - t0).toFloat() / 86400f * VW))
        fun yv(v: Double) = (h - (max(lo, min(hi, v)) - lo) / (hi - lo) * h).toFloat()
        for (f in doubleArrayOf(0.0, 0.5, 1.0)) {
            val v = lo + (hi - lo) * f; val y = (h - f * h).toFloat()
            line(0f, y, VW, y, ink.line); txt(ink, Math.round(v).toString() + "%", 2f, y - 2, 0, ink.muted)
        }
        val band = Path()
        pts.forEachIndexed { i, p -> val x = xt(p.t) * sc; val y = yv(p.v) * sc; if (i == 0) band.moveTo(x, y) else band.lineTo(x, y) }
        pts.asReversed().forEach { p -> band.lineTo(xt(p.t) * sc, yv(if (p.lo > 0) p.lo else p.v) * sc) }
        band.close(); drawPath(band, ColSpo2.copy(alpha = 0.14f))
        val ln = Path(); pts.forEachIndexed { i, p -> val x = xt(p.t) * sc; val y = yv(p.v) * sc; if (i == 0) ln.moveTo(x, y) else ln.lineTo(x, y) }
        drawPath(ln, ColSpo2, style = Stroke(1.8f * sc, cap = StrokeCap.Round, join = StrokeJoin.Round))
        pts.forEach { p -> drawCircle(ColSpo2, 2 * sc, Offset(xt(p.t) * sc, yv(p.v) * sc)) }
        val nx = xt(now); line(nx, 0f, nx, h, ink.accent.copy(alpha = 0.6f), 1f, floatArrayOf(3f, 3f))
        listOf("00", "06", "12", "18", "24").forEachIndexed { i, s -> txt(ink, s, i * VW / 4, h + 12, if (i == 0) 0 else if (i == 4) 2 else 1, ink.muted) }
    }
}
