package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.i18n.Text
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CompareArrows
import androidx.compose.material.icons.outlined.Route
import androidx.compose.material.icons.outlined.Terrain
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.domain.ActDetail
import com.endurancevault.app.domain.Js
import com.endurancevault.app.domain.ProgressAnalytics
import com.endurancevault.app.domain.ProgressTabs
import com.endurancevault.app.domain.RouteActivity
import com.endurancevault.app.domain.RouteGeo
import com.endurancevault.app.domain.SimilarRouteGroup
import com.endurancevault.app.ui.UiState
import java.time.LocalDate
import java.time.format.TextStyle as JTextStyle
import java.time.temporal.ChronoUnit
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt

/**
 * Tab Routes & conditions, memakai sistem kartu yang sama dengan Rekap dan Fitness.
 * Empat kartu: Rute serupa, Bandingkan aktivitas (keduanya selebar layar), lalu Heatmap rute dan Dampak cuaca berpasangan.
 */
@Composable
internal fun RoutesTab(state: UiState, onOpen: (Long) -> Unit) {
    val runs = remember(state.activities, state.detailsByActivity) {
        state.activities
            .filter { it.type != "bike" && it.km > 0 && it.durationSec > 0 }
            .sortedBy { it.dateIso + " " + (it.startTime ?: "") }
            .mapNotNull { a -> state.detailsByActivity[a.id]?.let { RtRun(a, it) } }
    }
    val byId = remember(runs) { runs.associateBy { it.a.id } }
    val groups = remember(runs) {
        runCatching {
            ProgressAnalytics.similarRoutes(
                runs.filter { it.d.hasRoute }.map { RouteActivity(it.a.id, it.a.dateIso, it.a.km, it.d.route) },
            )
        }.getOrDefault(emptyList()).sortedByDescending { it.members.size }
    }
    val heat = remember(runs) { rtBuildMap(runs) }
    val wx = remember(runs) { rtWeather(runs) }

    var oSim by rememberSaveable { mutableStateOf(false) }
    var oCmp by rememberSaveable { mutableStateOf(false) }
    var oHeat by rememberSaveable { mutableStateOf(false) }
    var oWx by rememberSaveable { mutableStateOf(false) }

    RtSimilar(groups, byId, onOpen, oSim, { oSim = !oSim }, Modifier.fillMaxWidth())
    RtCompare(runs, oCmp, { oCmp = !oCmp }, Modifier.fillMaxWidth())
    RcPair(oHeat, oWx,
        left = { m -> RtHeat(runs, heat, oHeat, { oHeat = !oHeat }, m) },
        right = { m -> RtWeather(wx, oWx, { oWx = !oWx }, m) })
}

// ===================== model & helper =====================

private val RT_LOC = com.endurancevault.app.ui.i18n.Lang.locale

/** Satu lari beserta detailnya. */
private class RtRun(val a: ActivityEntity, val d: ActDetail) {
    val pace: Double? get() = (d.avgPace ?: if (a.km > 0) a.durationSec / 60.0 / a.km else null)?.takeIf { it in 2.0..20.0 }
    val hr: Int? get() = d.hr ?: a.avgHr
    val gain: Int? get() = d.gain ?: a.gain
}

private class RtMap(val lines: List<List<Offset>>, val aspect: Float)

private class RtWx(val date: String, val temp: Double, val feels: Double?, val pace: Double, val hr: Double?)

private fun rtF1(x: Double): String = String.format(Locale.US, "%.1f", x).replace('.', ',')
private fun rtF2(x: Double): String = String.format(Locale.US, "%.2f", x).replace('.', ',')
private fun rtSigned(x: Int): String = if (x > 0) "+$x" else if (x < 0) "−${abs(x)}" else "0"
private fun rtSignedD(x: Double, f: (Double) -> String): String = if (x > 0.0) "+" + f(x) else if (x < 0.0) "−" + f(abs(x)) else f(0.0)

private fun rtDate(iso: String): String {
    val d = runCatching { LocalDate.parse(iso) }.getOrNull() ?: return iso
    return "${d.dayOfMonth} ${d.month.getDisplayName(JTextStyle.SHORT, RT_LOC)}"
}

private fun rtIntDelta(x: Int?, y: Int?): String = if (x != null && y != null) rtSigned(x - y) else "–"

/** Pasangan (setahun lalu, terbaru) bila ada anggota dengan selisih 365 hari ± 45 hari. */
private fun rtYearAgo(members: List<RtRun>): Pair<RtRun, RtRun>? {
    val now = members.lastOrNull() ?: return null
    val nowD = runCatching { LocalDate.parse(now.a.dateIso) }.getOrNull() ?: return null
    val best = members.filter { it.a.id != now.a.id }.mapNotNull { m ->
        runCatching { LocalDate.parse(m.a.dateIso) }.getOrNull()?.let { d -> m to abs(ChronoUnit.DAYS.between(d, nowD) - 365L) }
    }.minByOrNull { it.second } ?: return null
    return if (best.second <= 45L) best.first to now else null
}

/** Semua rute ber-koordinat dalam satu bingkai 0..1 (maks 80 lari terakhir, ≤ ~250 titik per rute). */
private fun rtBuildMap(runs: List<RtRun>): RtMap? {
    val src = runs.filter { it.d.geo != null && it.d.hasRoute }.takeLast(80)
    if (src.isEmpty()) return null
    val ll = src.mapNotNull { r ->
        val frame = r.d.geo ?: return@mapNotNull null
        val pts = RouteGeo.toLatLon(frame, r.d.route)
        val step = (pts.size / 250).coerceAtLeast(1)
        pts.filterIndexed { i, _ -> i % step == 0 || i == pts.lastIndex }
    }
    val all = ll.flatten()
    if (all.size < 2) return null
    val cosLat = cos(Math.toRadians(all.map { it.lat }.average()))
    val minLon = all.minOf { it.lon }; val maxLon = all.maxOf { it.lon }
    val minLat = all.minOf { it.lat }; val maxLat = all.maxOf { it.lat }
    val w = ((maxLon - minLon) * cosLat).coerceAtLeast(1e-6)
    val h = (maxLat - minLat).coerceAtLeast(1e-6)
    val lines = ll.map { pts -> pts.map { p -> Offset(((p.lon - minLon) * cosLat / w).toFloat(), ((maxLat - p.lat) / h).toFloat()) } }
    return RtMap(lines, (w / h).toFloat())
}

private fun rtWeather(runs: List<RtRun>): List<RtWx> = runs.mapNotNull { r ->
    val t = r.d.weatherTempC ?: r.d.weather?.tempC ?: return@mapNotNull null
    val p = r.pace ?: return@mapNotNull null
    RtWx(r.a.dateIso, t, r.d.weatherFeelsLikeC ?: r.d.weather?.feelsLikeC, p, r.hr?.toDouble())
}

@Composable
private fun rtColors(n: Int): List<Color> {
    val cs = MaterialTheme.colorScheme
    val pal = listOf(cs.tertiary, cs.secondary, Color(0xFF4C8FE0), cs.error, Color(0xFFD8B04A))
    return List(n) { i -> if (i == n - 1) cs.primary else pal[i % pal.size].copy(alpha = .8f) }
}

@Composable
private fun RtDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Text(label.uppercase(Locale.ROOT), style = monoStyle(9f, .3f), color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
    }
}

/**
 * Grafik garis banyak seri dengan satu skala bersama (agar bisa dibandingkan langsung). Seri terakhir = aksen.
 * Nilai NaN memutus garis. [invert] = nilai kecil di atas (pace: atas = lebih cepat).
 */
@Composable
internal fun RtLines(
    series: List<Pair<String, List<Float>>>, unit: String = "", invert: Boolean = false, height: Int = 110,
    fmt: (Float) -> String = { rtF1(it.toDouble()) },
) {
    val finite = series.flatMap { it.second }.filter { it.isFinite() }
    if (finite.size < 2) {
        RcMuted("Belum cukup data historis untuk membentuk tren.")
        return
    }
    val grid = MaterialTheme.colorScheme.outlineVariant
    val colors = rtColors(series.size)
    val mn = finite.minOrNull() ?: 0f
    val mx = finite.maxOrNull() ?: 1f
    val span = (mx - mn).takeIf { it > 1e-4f } ?: 1f
    val maxN = series.maxOf { it.second.size }
    Canvas(Modifier.fillMaxWidth().height(height.dp)) {
        val padV = 8.dp.toPx(); val h = size.height - 2 * padV
        repeat(3) { i ->
            val gy = padV + h * i / 2f
            drawLine(grid.copy(alpha = .55f), Offset(0f, gy), Offset(size.width, gy), 1.dp.toPx())
        }
        series.forEachIndexed { si, s ->
            val c = colors[si]
            val sw = if (si == series.lastIndex) 2.6.dp.toPx() else 1.6.dp.toPx()
            var path = Path(); var started = false
            s.second.forEachIndexed { i, v ->
                if (!v.isFinite()) {
                    if (started) { drawPath(path, c, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round)); path = Path(); started = false }
                } else {
                    val x = if (maxN <= 1) 0f else size.width * i / (maxN - 1)
                    val t = (v - mn) / span
                    val y = padV + h * (if (invert) t else 1f - t)
                    if (!started) { path.moveTo(x, y); started = true } else path.lineTo(x, y)
                }
            }
            if (started) drawPath(path, c, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        series.forEachIndexed { i, s -> if (i >= series.size - 6) RtDot(colors[i], s.first) }
    }
    RcMono("${fmt(mn)}–${fmt(mx)}" + (if (unit.isNotEmpty()) " $unit" else "") + (if (invert) " · atas = lebih cepat" else ""))
}

// ===================== 1. Rute serupa =====================

@Composable
private fun RtSimilar(
    groups: List<SimilarRouteGroup>, byId: Map<Long, RtRun>, onOpen: (Long) -> Unit,
    open: Boolean, onToggle: () -> Unit, modifier: Modifier,
) {
    RcCard(Icons.Outlined.Route, "RUTE SERUPA", open, onToggle, modifier,
        headText = "${groups.size} grup",
        summary = {
            if (groups.isEmpty()) {
                RcMuted("Belum ada dua aktivitas dengan bentuk rute dan jarak yang cukup mirip.")
            } else {
                RcBig("${groups.size} grup", "Kelompok rute GPS · jarak ±12% · bentuk lintasan", "${groups.first().members.size}× terbanyak")
                groups.take(3).forEachIndexed { i, g ->
                    RcMono("RUTE ${i + 1} · ${g.members.size}× · ${fmtKmUi(g.representative.km)} km")
                }
            }
        },
        body = {
            if (groups.isEmpty()) {
                RcMuted("Belum ada dua aktivitas dengan bentuk rute dan jarak yang cukup mirip.")
            } else {
                groups.take(6).forEachIndexed { gi, g ->
                    val members = g.members.mapNotNull { byId[it.id] }.sortedBy { it.a.dateIso }
                    RtGroup(gi, g, members, onOpen)
                }
                if (groups.size > 6) RcMuted("+${groups.size - 6} grup lain tidak ditampilkan.")
                RcInfo("Rute dikelompokkan dari bentuk lintasan GPS dan jarak (±12%). Perbandingan bersifat deskriptif; tidak mengoreksi cuaca, elevasi, arah lintasan, atau tingkat usaha.")
            }
        })
}

@Composable
private fun RtGroup(index: Int, g: SimilarRouteGroup, members: List<RtRun>, onOpen: (Long) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val elev = remember(members) {
        members.map { r -> rtDate(r.a.dateIso) to ProgressTabs.resample(r.d.profile, 40) }.filter { it.second.isNotEmpty() }
    }
    val pace = remember(members) {
        members.filter { it.d.splits.isNotEmpty() }.map { r -> rtDate(r.a.dateIso) to r.d.splits.take(30).map { it.pace.toFloat() } }
    }
    RcInner(pad = 12) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("RUTE ${index + 1}", Modifier.weight(1f), style = monoStyle(10f, .3f), color = cs.onSurfaceVariant)
            RcTag("${members.size} aktivitas", 2)
        }
        RcMuted("${fmtKmUi(g.representative.km)} km · ${members.firstOrNull()?.let { rtDate(it.a.dateIso) } ?: "–"} sampai ${members.lastOrNull()?.let { rtDate(it.a.dateIso) } ?: "–"}")
        if (elev.size >= 2) {
            Text("OVERLAY PROFIL ELEVASI", style = monoStyle(9f, .4f), color = cs.onSurfaceVariant)
            RtLines(elev, unit = "m", fmt = { Js.idn(it.roundToInt()) })
        }
        if (pace.size >= 2) {
            Text("PACE PER KILOMETER", style = monoStyle(9f, .4f), color = cs.onSurfaceVariant)
            RtLines(pace, unit = "/km", invert = true, fmt = { Js.paceStr(it.toDouble()) })
        }
        val w = listOf(1.2f, 1f, 1f, .8f, .8f)
        RcTableRow(listOf("Tanggal", "Jarak", "Pace", "HR", "D+"), w, head = true)
        members.asReversed().take(12).forEach { r ->
            Box(Modifier.clickable { onOpen(r.a.id) }) {
                RcTableRow(listOf(
                    rtDate(r.a.dateIso), fmtKmUi(r.a.km), r.pace?.let { Js.paceStr(it) } ?: "–",
                    r.hr?.toString() ?: "–", r.gain?.toString() ?: "–",
                ), w)
            }
        }
        if (members.size > 12) RcMuted("+${members.size - 12} aktivitas lebih lama.")
        rtYearAgo(members)?.let { (old, now) ->
            Text("PERBANDINGAN SEKITAR SETAHUN", style = monoStyle(9f, .4f), color = cs.onSurfaceVariant)
            val w2 = listOf(1.2f, 1f, 1f)
            RcTableRow(listOf("Tanggal", "Pace", "HR"), w2, head = true)
            listOf(old, now).forEach { r ->
                RcTableRow(listOf(rtDate(r.a.dateIso), r.pace?.let { Js.paceStr(it) } ?: "–", r.hr?.toString() ?: "–"), w2)
            }
            val p0 = old.pace; val p1 = now.pace
            val parts = mutableListOf<String>()
            if (p0 != null && p1 != null) parts += "pace ${rtSigned(((p1 - p0) * 60.0).roundToInt())} dtk/km"
            val h0 = old.hr; val h1 = now.hr
            if (h0 != null && h1 != null) parts += "HR ${rtSigned(h1 - h0)} bpm"
            if (parts.isNotEmpty()) RcMuted("Perubahan: " + parts.joinToString(" · "))
        }
    }
}

// ===================== 2. Bandingkan aktivitas =====================

@Composable
private fun RtPicker(choices: List<RtRun>, selected: Long, onSelect: (Long) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(99.dp)
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        choices.forEach { r ->
            val on = r.a.id == selected
            Box(
                Modifier.clip(shape)
                    .then(if (on) Modifier.background(GRAD) else Modifier.border(.8.dp, cs.outlineVariant, shape))
                    .clickable { onSelect(r.a.id) }.padding(horizontal = 12.dp, vertical = 8.dp),
            ) {
                Text("${rtDate(r.a.dateIso)} · ${fmtKmUi(r.a.km)} km", style = MaterialTheme.typography.labelLarge,
                    color = if (on) Color.White else cs.onSurfaceVariant, maxLines = 1)
            }
        }
    }
}

@Composable
private fun RtCompare(runs: List<RtRun>, open: Boolean, onToggle: () -> Unit, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    var selA by rememberSaveable { mutableStateOf<Long?>(null) }
    var selB by rememberSaveable { mutableStateOf<Long?>(null) }
    val choices = remember(runs) { runs.takeLast(30).asReversed() }
    val a = choices.firstOrNull { it.a.id == selA } ?: choices.getOrNull(0)
    val b = choices.firstOrNull { it.a.id == selB } ?: choices.getOrNull(1)
    val ready = choices.size >= 2 && a != null && b != null
    RcCard(Icons.Outlined.CompareArrows, "BANDINGKAN AKTIVITAS", open, onToggle, modifier,
        headText = "${runs.size} aktivitas",
        summary = {
            if (!ready || a == null || b == null) {
                RcMuted("Minimal dua aktivitas dengan detail FIT/GPX/TCX diperlukan.")
            } else {
                val pa = a.pace; val pb = b.pace
                val dp = if (pa != null && pb != null) ((pa - pb) * 60.0).roundToInt() else null
                RcBig(
                    "${pa?.let { Js.paceStr(it) } ?: "–"} vs ${pb?.let { Js.paceStr(it) } ?: "–"}",
                    "Pace /km · A ${rtDate(a.a.dateIso)} · B ${rtDate(b.a.dateIso)}",
                    dp?.let { "Δ ${abs(it)} dtk" },
                )
                RcStats(listOf(
                    "Jarak" to "${fmtKmUi(a.a.km)} / ${fmtKmUi(b.a.km)}",
                    "HR" to "${a.hr ?: "–"} / ${b.hr ?: "–"}",
                    "D+" to "${a.gain ?: "–"} / ${b.gain ?: "–"}",
                ))
            }
        },
        body = {
            if (!ready || a == null || b == null) {
                RcMuted("Minimal dua aktivitas dengan detail FIT/GPX/TCX diperlukan.")
            } else {
                Text("AKTIVITAS A", style = monoStyle(9f, .4f), color = cs.onSurfaceVariant)
                RtPicker(choices, a.a.id) { selA = it }
                Text("AKTIVITAS B", style = monoStyle(9f, .4f), color = cs.onSurfaceVariant)
                RtPicker(choices, b.a.id) { selB = it }
                if (a.a.id == b.a.id) {
                    RcMuted("Pilih dua aktivitas yang berbeda.")
                } else {
                    val pa = a.pace; val pb = b.pace
                    RcInner {
                        val w = listOf(1f, 1f, 1f, 1f)
                        RcTableRow(listOf("", "A", "B", "A − B"), w, head = true)
                        RcTableRow(listOf("Jarak km", fmtKmUi(a.a.km), fmtKmUi(b.a.km), rtSignedD(a.a.km - b.a.km) { rtF1(it) }), w)
                        RcTableRow(listOf("Pace /km", pa?.let { Js.paceStr(it) } ?: "–", pb?.let { Js.paceStr(it) } ?: "–",
                            if (pa != null && pb != null) "${rtSigned(((pa - pb) * 60.0).roundToInt())} dtk" else "–"), w)
                        val ga = a.d.gapPace; val gb = b.d.gapPace
                        if (ga != null && gb != null) {
                            RcTableRow(listOf("GAP /km", Js.paceStr(ga), Js.paceStr(gb), "${rtSigned(((ga - gb) * 60.0).roundToInt())} dtk"), w)
                        }
                        RcTableRow(listOf("HR bpm", a.hr?.toString() ?: "–", b.hr?.toString() ?: "–", rtIntDelta(a.hr, b.hr)), w)
                        RcTableRow(listOf("D+ m", a.gain?.toString() ?: "–", b.gain?.toString() ?: "–", rtIntDelta(a.gain, b.gain)), w, line = false)
                    }
                    val la = "A ${rtDate(a.a.dateIso)}"; val lb = "B ${rtDate(b.a.dateIso)}"
                    if (a.d.splits.isNotEmpty() && b.d.splits.isNotEmpty()) {
                        Text("PACE PER KILOMETER · A VS B", style = monoStyle(9f, .4f), color = cs.onSurfaceVariant)
                        RtLines(
                            listOf(la to a.d.splits.take(30).map { it.pace.toFloat() }, lb to b.d.splits.take(30).map { it.pace.toFloat() }),
                            unit = "/km", invert = true, fmt = { Js.paceStr(it.toDouble()) },
                        )
                        RcInner {
                            val w = listOf(.7f, 1f, 1f)
                            RcTableRow(listOf("KM", "A", "B"), w, head = true)
                            val rows = minOf(a.d.splits.size, b.d.splits.size, 12)
                            repeat(rows) { i ->
                                RcTableRow(listOf("${i + 1}", Js.paceStr(a.d.splits[i].pace), Js.paceStr(b.d.splits[i].pace)), w, line = i < rows - 1)
                            }
                        }
                    }
                    val ea = ProgressTabs.resample(a.d.profile, 40); val eb = ProgressTabs.resample(b.d.profile, 40)
                    if (ea.isNotEmpty() && eb.isNotEmpty()) {
                        Text("PROFIL ELEVASI · A VS B", style = monoStyle(9f, .4f), color = cs.onSurfaceVariant)
                        RtLines(listOf(la to ea, lb to eb), unit = "m", fmt = { Js.idn(it.roundToInt()) })
                    }
                }
            }
        })
}

// ===================== 3. Heatmap rute & ridgeline =====================

@Composable
private fun RtHeatCanvas(map: RtMap, heightDp: Int) {
    val line = MaterialTheme.colorScheme.primary
    val bg = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .5f)
    Canvas(Modifier.fillMaxWidth().height(heightDp.dp).clip(RoundedCornerShape(12.dp)).background(bg)) {
        val pad = 8.dp.toPx()
        val aw = (size.width - 2 * pad).coerceAtLeast(1f); val ah = (size.height - 2 * pad).coerceAtLeast(1f)
        val cw: Float; val ch: Float
        if (aw / ah > map.aspect) { ch = ah; cw = ah * map.aspect } else { cw = aw; ch = aw / map.aspect }
        val ox = pad + (aw - cw) / 2f; val oy = pad + (ah - ch) / 2f
        map.lines.forEach { pts ->
            if (pts.size >= 2) {
                val p = Path()
                pts.forEachIndexed { i, o ->
                    val x = ox + o.x * cw; val y = oy + o.y * ch
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                drawPath(p, line.copy(alpha = .22f), style = Stroke(2.2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
    }
}

/** Ridgeline: profil elevasi beberapa lari terakhir bertumpuk; yang terbaru di depan. */
@Composable
private fun RtRidge(items: List<RtRun>) {
    val cs = MaterialTheme.colorScheme
    val tm = rememberTextMeasurer()
    val ts = tickStyle()
    val series = remember(items) {
        items.map { rtDate(it.a.dateIso) to ProgressTabs.resample(it.d.profile, 60) }.filter { it.second.isNotEmpty() }
    }
    if (series.isEmpty()) {
        RcMuted("Belum ada profil elevasi.")
        return
    }
    val fillC = cs.surfaceVariant
    val strokeC = cs.primary
    val n = series.size
    Canvas(Modifier.fillMaxWidth().height((56 + 26 * (n - 1)).dp)) {
        val bandH = 56.dp.toPx()
        val step = if (n > 1) (size.height - bandH) / (n - 1) else 0f
        series.forEachIndexed { i, s ->
            val vals = s.second
            val base = bandH + i * step
            val lo = vals.minOrNull() ?: 0f
            val hi = vals.maxOrNull() ?: 1f
            val sp = (hi - lo).takeIf { it > 1e-3f } ?: 1f
            val top = Path(); val area = Path()
            vals.forEachIndexed { k, v ->
                val x = size.width * k / (vals.size - 1).coerceAtLeast(1)
                val y = base - (v - lo) / sp * (bandH - 10.dp.toPx())
                if (k == 0) { top.moveTo(x, y); area.moveTo(0f, base); area.lineTo(x, y) } else { top.lineTo(x, y); area.lineTo(x, y) }
            }
            area.lineTo(size.width, base); area.close()
            drawPath(area, fillC)
            drawPath(top, strokeC.copy(alpha = if (i == n - 1) 1f else .7f), style = Stroke(1.8.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            drawText(tm, s.first, Offset(4.dp.toPx(), base - 13.dp.toPx()), style = ts)
        }
    }
}

@Composable
private fun RtHeat(runs: List<RtRun>, heat: RtMap?, open: Boolean, onToggle: () -> Unit, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val withRoute = remember(runs) { runs.count { it.d.hasRoute } }
    val gainTotal = remember(runs) { runs.sumOf { it.gain ?: 0 } }
    val ridge = remember(runs) { runs.filter { it.d.profile.size >= 2 }.takeLast(6) }
    RcCard(Icons.Outlined.Terrain, "HEATMAP RUTE", open, onToggle, modifier,
        headText = "$withRoute rute",
        summary = {
            if (heat == null) RcMuted("Belum ada rute dengan koordinat.") else RtHeatCanvas(heat, 84)
            RcStats(listOf("Rute" to "$withRoute", "D+ total" to "${Js.idn(gainTotal)} m"))
        },
        body = {
            if (heat == null) {
                RcMuted("Belum ada rute dengan koordinat. Impor aktivitas FIT/GPX/TCX atau sinkronkan dari jam.")
            } else {
                Text("SEMUA RUTE DI SATU PETA", style = monoStyle(9f, .4f), color = cs.onSurfaceVariant)
                RtHeatCanvas(heat, 240)
                RcMuted("Garis makin pekat bila rute sering dilewati (maks 80 lari terakhir).")
            }
            if (ridge.isNotEmpty()) {
                Text("RIDGELINE ELEVASI · ${ridge.size} LARI TERAKHIR", style = monoStyle(9f, .4f), color = cs.onSurfaceVariant)
                RcInner { RtRidge(ridge) }
            }
            RcStats(listOf("Total D+" to "${Js.idn(gainTotal)} m", "Rute" to "$withRoute"))
        })
}

// ===================== 4. Dampak cuaca =====================

@Composable
private fun RtScatter(points: List<Pair<Double, Double>>, tr: ProgressTabs.Trend?) {
    if (points.size < 2) {
        RcMuted("Belum cukup lari bercuaca untuk scatter.")
        return
    }
    val cs = MaterialTheme.colorScheme
    val grid = cs.outlineVariant; val dot = cs.primary; val trendC = cs.tertiary
    Canvas(Modifier.fillMaxWidth().height(140.dp)) {
        val l = 10.dp.toPx(); val r = 10.dp.toPx(); val t = 10.dp.toPx(); val b = 10.dp.toPx()
        val minX = points.minOf { it.first }; val maxX = points.maxOf { it.first }
        val minY = points.minOf { it.second }; val maxY = points.maxOf { it.second }
        val spanX = (maxX - minX).takeIf { it > 1e-9 } ?: 1.0
        val spanY = (maxY - minY).takeIf { it > 1e-9 } ?: 1.0
        fun px(x: Double) = l + (size.width - l - r) * ((x - minX) / spanX).toFloat()
        fun py(y: Double) = size.height - b - (size.height - t - b) * ((y - minY) / spanY).toFloat()
        repeat(3) { i ->
            val gy = t + (size.height - t - b) * i / 2f
            drawLine(grid, Offset(l, gy), Offset(size.width - r, gy), 1.dp.toPx())
        }
        if (tr != null) {
            val y0 = (tr.intercept + tr.slope * minX).coerceIn(minY, maxY)
            val y1 = (tr.intercept + tr.slope * maxX).coerceIn(minY, maxY)
            drawLine(trendC, Offset(px(minX), py(y0)), Offset(px(maxX), py(y1)), 2.dp.toPx(), cap = StrokeCap.Round)
        }
        points.forEach { (x, y) -> drawCircle(dot.copy(alpha = .72f), 4.dp.toPx(), Offset(px(x), py(y))) }
    }
}

@Composable
private fun RtWeather(wx: List<RtWx>, open: Boolean, onToggle: () -> Unit, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    var metric by rememberSaveable { mutableIntStateOf(0) }
    val hasHr = wx.count { it.hr != null } >= 3
    val m = if (metric == 1 && hasHr) 1 else 0
    val pts = wx.mapNotNull { w -> (if (m == 0) w.pace else w.hr)?.let { w.temp to it } }
    val tr = ProgressTabs.trend(pts)
    val bands = (0..2).map { bi -> wx.filter { ProgressTabs.tempBand(it.temp) == bi } }
    RcCard(Icons.Outlined.WbSunny, "DAMPAK CUACA", open, onToggle, modifier,
        headText = "${wx.size} lari",
        summary = {
            if (wx.isEmpty()) {
                RcMuted("Arsip cuaca historis belum tersedia pada data aktivitas ini.")
            } else {
                val r = ProgressTabs.trend(wx.map { it.temp to it.pace })?.r
                RcBig(r?.let { "r = ${rtF2(it)}" } ?: "–", "Suhu vs pace · ${wx.size} lari")
                RcStats(ProgressTabs.BAND_LABELS.mapIndexed { i, label ->
                    label to (bands[i].takeIf { it.isNotEmpty() }?.let { Js.paceStr(it.map { x -> x.pace }.average()) } ?: "–")
                })
            }
        },
        body = {
            if (wx.isEmpty()) {
                RcMuted("Arsip cuaca historis belum tersedia pada data aktivitas ini.")
            } else {
                if (hasHr) RcSeg(listOf("Pace", "HR"), m) { metric = it }
                Text(if (m == 0) "SUHU VS PACE · TIAP TITIK SATU LARI" else "SUHU VS HR · TIAP TITIK SATU LARI", style = monoStyle(9f, .4f), color = cs.onSurfaceVariant)
                RcInner {
                    RtScatter(pts, tr)
                    RcLegend("${Js.roundI(pts.minOf { it.first })}°C", "${Js.roundI(pts.maxOf { it.first })}°C")
                    RcMono(if (m == 0) "↑ lebih lambat · garis = tren" else "↑ HR lebih tinggi · garis = tren")
                }
                RcStats(listOf(
                    "Korelasi" to (tr?.r?.let { "r = ${rtF2(it)}" } ?: "–"),
                    "Tren" to (tr?.let {
                        if (m == 0) "${rtSignedD(it.slope * 60.0) { x -> rtF1(x) }} dtk/°C" else "${rtSignedD(it.slope) { x -> rtF1(x) }} bpm/°C"
                    } ?: "–"),
                ))
                RcInner {
                    val w = listOf(1.1f, .8f, 1f, 1f)
                    RcTableRow(listOf("Pita suhu", "Lari", "Pace", "HR"), w, head = true)
                    bands.forEachIndexed { i, rows ->
                        if (rows.isNotEmpty()) {
                            val hrs = rows.mapNotNull { it.hr }
                            RcTableRow(listOf(
                                ProgressTabs.BAND_LABELS[i], "${rows.size}", Js.paceStr(rows.map { it.pace }.average()),
                                if (hrs.isNotEmpty()) "${hrs.average().roundToInt()}" else "–",
                            ), w)
                        }
                    }
                }
                Text("LARI TERAKHIR", style = monoStyle(9f, .4f), color = cs.onSurfaceVariant)
                RcInner {
                    val w = listOf(1.1f, 1f, 1f, 1f)
                    RcTableRow(listOf("Tanggal", "Suhu", "Terasa", "Pace"), w, head = true)
                    wx.takeLast(10).asReversed().forEach { x ->
                        RcTableRow(listOf(rtDate(x.date), "${rtF1(x.temp)}°", x.feels?.let { "${rtF1(it)}°" } ?: "–", Js.paceStr(x.pace)), w)
                    }
                }
                RcInfo("Korelasi bukan sebab-akibat; medan, intensitas, tidur, dan kelelahan juga memengaruhi pace. Garis tren adalah regresi linear sederhana dari titik yang ada.")
            }
        })
}
