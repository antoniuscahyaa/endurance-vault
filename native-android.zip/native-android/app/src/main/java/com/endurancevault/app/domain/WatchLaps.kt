package com.endurancevault.app.domain

/**
 * Lap dari jam: blok `sections` yang diunduh jam (Workout 17/16) diubah menjadi batas segmen.
 *
 * Yang dipakai hanya jarak tiap blok (meter), sebagai batas pada deret 1 Hz; waktu, pace, HR, kadens, dan elevasi segmen
 * dihitung ulang oleh [SegmentSplit] dari data per detik, jadi tidak bergantung pada satuan field lain dari jam.
 * Satuan jarak belum terverifikasi di perangkat, maka dipakai pengaman: total jarak blok harus cocok dengan total
 * deret (selisih <= 10%), kalau tidak, tidak ada segmen yang dibuat.
 *
 * Blok yang semuanya sekitar 1 km dianggap pemisah otomatis per km (sudah ada di tabel "Per km") dan dilewati, supaya
 * setiap lari tidak dipenuhi segmen km dan editor tidak langsung membuka mode manual.
 */
object WatchLaps {
    /** Toleransi kecocokan total jarak blok dengan total deret. */
    private const val SUM_TOLERANCE = 0.10

    /** Blok dianggap "per km otomatis" bila jaraknya dalam rentang ini (m). */
    private const val AUTO_KM_MIN = 900.0
    private const val AUTO_KM_MAX = 1100.0

    /** Apakah semua blok (kecuali yang terakhir, boleh sisa) berukuran sekitar 1 km. */
    fun isAutoKm(distancesM: List<Double>): Boolean {
        if (distancesM.size < 2) return false
        val body = distancesM.dropLast(1)
        return body.all { it in AUTO_KM_MIN..AUTO_KM_MAX } && distancesM.last() <= AUTO_KM_MAX
    }

    /**
     * Batas segmen dari jarak tiap blok ([distancesM], meter, berurutan), atau null bila blok tidak ada, tidak cocok
     * dengan sesi, atau hanya pemisah per km. Segmen hasilnya tanpa label.
     */
    fun draftsFromSections(ts: ActivityTimeSeries, distancesM: List<Double>): List<SegmentSplit.Draft>? {
        val d = distancesM.filter { it.isFinite() && it > 0 }
        if (d.size < 2 || d.size != distancesM.size) return null
        if (isAutoKm(d)) return null
        val totalM = ts.distanceMeters.last() - ts.distanceMeters.first()
        if (totalM <= 0 || kotlin.math.abs(d.sum() - totalM) > totalM * SUM_TOLERANCE) return null
        val total = SegmentSplit.totalSec(ts)
        val out = ArrayList<SegmentSplit.Draft>()
        var cum = 0.0
        var prev = 0
        d.forEachIndexed { i, m ->
            cum += m
            val end = if (i == d.lastIndex) total else SegmentSplit.secAtMeters(ts, cum)
            if (end - prev >= SegmentSplit.MIN_SEG_SEC) { out += SegmentSplit.Draft(end, null); prev = end }
            else if (out.isNotEmpty() && i == d.lastIndex) out[out.lastIndex] = SegmentSplit.Draft(total, null)
        }
        return out.takeIf { it.size >= 2 && it.last().endSec == total && SegmentSplit.validate(ts, it) == null }
    }
}
