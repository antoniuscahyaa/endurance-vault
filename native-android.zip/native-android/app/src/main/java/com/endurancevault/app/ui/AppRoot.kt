package com.endurancevault.app.ui


import com.endurancevault.app.ui.i18n.Text
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import com.endurancevault.app.domain.TrainingMetrics

import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.Icon
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.foundation.layout.size
import androidx.compose.ui.Alignment
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.navArgument
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.endurancevault.app.ui.screens.ActivityDetailScreen
import com.endurancevault.app.ui.screens.RouteVideoScreen
import com.endurancevault.app.ui.screens.StickerScreen
import com.endurancevault.app.ui.screens.ProfileScreen
import com.endurancevault.app.ui.screens.rememberProfileAvatar
import com.endurancevault.app.ui.screens.ProgressScreen
import com.endurancevault.app.ui.screens.ScheduleScreen
import com.endurancevault.app.ui.screens.PlanOverviewScreen
import com.endurancevault.app.ui.screens.TodayScreen
import com.endurancevault.app.ui.screens.HuaweiWatchSection
import com.endurancevault.app.domain.ProgressAnalytics
import com.endurancevault.app.domain.CourseStrategy
import com.endurancevault.app.domain.RouteGeo
import com.endurancevault.app.ui.screens.ExploreCollectionScreen
import com.endurancevault.app.ui.screens.ExploreRouteDetailScreen
import com.endurancevault.app.ui.screens.ExploreScreen
import com.endurancevault.app.ui.screens.exViewAt
import com.endurancevault.app.ui.screens.GpxPreviewDialog
import com.endurancevault.app.ui.screens.WatchBadge
import com.endurancevault.app.ui.screens.restHrFrom
import com.endurancevault.app.ui.screens.WatchDockScreen
import com.endurancevault.app.ui.screens.WatchHeaderPill
import com.endurancevault.app.ui.screens.WatchSettingsCard
import com.endurancevault.app.ui.screens.watchBadgeOf

private enum class Tab(val route: String, val label: String, val icon: ImageVector) {
    Today("today", "Hari ini", Icons.Filled.Home),
    Profile("profile", "Profil", Icons.Filled.Person),
    Progress("progress", "Progres", Icons.Filled.ShowChart),
    Watch("watch", "Jam", Icons.Filled.Favorite),
    Week("week", "Minggu", Icons.Filled.CalendarMonth),
    Schedule("schedule", "Jadwal", Icons.Filled.CalendarMonth),
    Explore("explore", "Explore", Icons.Filled.Explore),
}

@Composable
private fun EnduranceProfileHeader(
    name: String,
    photoUri: String?,
    recoveryHours: Int,
    onOpenProfile: () -> Unit,
    onOpenSettings: () -> Unit,
    watchBadge: WatchBadge? = null,
) {
    val avatar = rememberProfileAvatar(photoUri)
    val readyAt = LocalTime.now().plusHours(recoveryHours.coerceAtLeast(0).toLong())
    val readyLabel = readyAt.format(DateTimeFormatter.ofPattern("HH:mm"))
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        androidx.compose.foundation.layout.Box(
            modifier = Modifier.size(62.dp).clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape)
                .clickable(onClick = onOpenProfile),
            contentAlignment = Alignment.Center,
        ) {
            if (avatar != null) {
                Image(bitmap = avatar, contentDescription = com.endurancevault.app.ui.i18n.Lang.tr("Buka profil"), contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize().clip(CircleShape))
            } else {
                Icon(Icons.Filled.Person, contentDescription = com.endurancevault.app.ui.i18n.Lang.tr("Buka profil"), tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(32.dp))
            }
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth().clickable(onClick = if (name.isBlank()) onOpenSettings else onOpenProfile),
            ) {
                Text(
                    name.ifBlank { "Tambahkan nama di Pengaturan" },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.weight(1f, fill = false),
                ) {
                    Row(
                        Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(7.dp),
                    ) {
                        androidx.compose.foundation.layout.Box(Modifier.size(7.dp).clip(CircleShape).background(MaterialTheme.colorScheme.tertiary))
                        Text("Recovery ${recoveryHours} h", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, maxLines = 1)
                        Text(
                            "ready $readyLabel", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false),
                        )
                    }
                }
                if (watchBadge != null) WatchHeaderPill(watchBadge)
            }
        }
        Surface(
            shape = CircleShape, color = MaterialTheme.colorScheme.surfaceVariant,
            border = androidx.compose.foundation.BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier.size(48.dp).clickable(onClick = onOpenSettings),
        ) {
            androidx.compose.foundation.layout.Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Settings, contentDescription = com.endurancevault.app.ui.i18n.Lang.tr("Pengaturan"), tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
            }
        }
    }
}

/** Isi ProfileScreen dengan semua state dari ViewModel; dipakai oleh tab Profil dan halaman Pengaturan terpisah. */
@Composable
private fun ProfileHost(vm: MainViewModel, state: UiState, onOpenActivity: (Long) -> Unit, settingsMode: Boolean, onBack: () -> Unit, onOpenStickers: () -> Unit = {}, onOpenProgressDock: (String) -> Unit = {},
    profileName: String = "", profilePhotoUri: String? = null, onEditProfileName: () -> Unit = {}, onPickProfilePhoto: () -> Unit = {},
    watchBadge: WatchBadge? = null, onWatchDot: () -> Unit = {}, onOpenWatch: () -> Unit = {},
) {
        val imp by vm.importState.collectAsState()
        val backupUi by vm.backupState.collectAsState()
        val watchMsg by vm.watchMessage.collectAsState()
        val watchSyncing by vm.watchSyncing.collectAsState()
        val watchAdvancedMessage by vm.watchAdvancedMessage.collectAsState()
        val liveHr by vm.liveHrJson.collectAsState()
        val weather by vm.weatherMessage.collectAsState()
        val weatherBusy by vm.weatherBusy.collectAsState()
        val weatherLat by vm.weatherLat.collectAsState()
        val weatherLon by vm.weatherLon.collectAsState()
        val weatherWatchStatus by vm.weatherWatchStatus.collectAsState()
        val agpsStatus by vm.agpsStatus.collectAsState()
        val notifyStatus by vm.notifyStatus.collectAsState()
        val aiStatus by vm.aiStatus.collectAsState()
        val aiMessages by vm.aiMessages.collectAsState()
        val aiBusy by vm.aiBusy.collectAsState()
        val duplicateStatus by vm.duplicateStatus.collectAsState()
        val profileTrackMsg by vm.trackMsg.collectAsState()
        ProfileScreen(
            state, vm::saveSettings, imp, vm::startImport, vm::confirmImport, vm::dismissImport, vm::mergeDuplicateActivities, vm::scanDuplicateActivities, duplicateStatus,
            vm::saveDaily, vm::saveGear, vm::deleteGear,
            watchMsg, vm::connectWatch, vm::disconnectWatch, vm::forgetAndReconnectWatch, vm::syncWatch, watchSyncing,
            watchAdvancedMessage, liveHr, vm::refreshLiveHr, vm::setLiveHr, vm::syncWatchHrZones,
            vm::pushStructuredWorkout, vm::pushGpxRoute,
            weather, weatherBusy, weatherLat, weatherLon, { lat, lon -> vm.fetchWeather(lat, lon) }, { q -> vm.searchWeatherCity(q) }, vm::useCurrentLocation, { lat, lon, name -> vm.sendWeatherToWatch(lat, lon, name) },
            weatherWatchStatus, agpsStatus, { enabled, mirror -> vm.setAgps(enabled, mirror) }, { vm.testAgps() },
            notifyStatus, { enabled, quiet, start, end, screenOff, apps -> vm.setWatchNotifications(enabled, quiet, start, end, screenOff, apps) }, { vm.testWatchNotification() },
            aiStatus, aiMessages, vm::saveAiKey, vm::sendAiQuestion, aiBusy,
            vm::deleteActivity, onOpenActivity, vm::importTracks, profileTrackMsg,
            settingsMode = settingsMode, onBack = onBack,
            backupUi = backupUi, backupFileName = vm::backupFileName, onExportBackup = vm::exportBackup,
            onStartRestore = vm::startRestore, onConfirmRestore = vm::confirmRestore, onDismissBackup = vm::dismissBackup,
            onOpenStickers = onOpenStickers, onOpenProgressDock = onOpenProgressDock,
            profileName = profileName, profilePhotoUri = profilePhotoUri,
            onEditProfileName = onEditProfileName, onPickProfilePhoto = onPickProfilePhoto,
            settingsExtra = { if (watchBadge != null) WatchSettingsCard(watchBadge, onOpen = onOpenWatch, onDot = onWatchDot) },
        )
}

@Composable
fun AppRoot(vm: MainViewModel = viewModel()) {
    val nav = rememberNavController()
    val state by vm.state.collectAsState()
    val gpxPreview by vm.gpxPreview.collectAsState()
    gpxPreview?.let { gp ->
        // indeks kemampuan dari lari terakhir, dasar tiga opsi prediksi waktu (Ringan/Sedang/Berat)
        val ability = remember(gp, state.settings, state.activities, state.daily) {
            runCatching { ProgressAnalytics.runningAbility(state.settings, state.activities, state.daily) }.getOrNull()
        }
        GpxPreviewDialog(gp, ability, onSend = { pace -> vm.confirmGpxRoute(pace) }, onDismiss = vm::dismissGpxPreview)
    }
    val context = LocalContext.current
    val profilePrefs = remember { context.getSharedPreferences("profile_identity", android.content.Context.MODE_PRIVATE) }
    var profileName by remember { mutableStateOf(profilePrefs.getString("name", "") ?: "") }
    var profilePhotoUri by remember { mutableStateOf(profilePrefs.getString("photo_uri", null)) }
    var showProfileNameDialog by remember { mutableStateOf(false) }
    var showSettings by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf(false) }
    androidx.activity.compose.BackHandler(enabled = showSettings) { showSettings = false }
    var editedProfileName by remember { mutableStateOf(profileName) }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            profilePhotoUri = uri.toString()
            profilePrefs.edit().putString("photo_uri", uri.toString()).apply()
        }
    }
    val trainingMetrics = remember(state.settings, state.activities, state.daily, state.plan, state.hrHistByActivity) {
        runCatching { TrainingMetrics.calculate(state.settings, state.activities, state.daily, state.plan, hrHistByActivity = state.hrHistByActivity) }.getOrNull()
    }
    val recoveryHours = trainingMetrics?.recoveryRemainingHours ?: 0
    // Status jam untuk header dan kartu Pengaturan (tab Jam sudah tidak ada di dock). Dibaca ulang tiap menit dan setiap sinkron mulai/selesai.
    val wbDock by vm.watchDock.collectAsState()
    val wbSyncing by vm.watchSyncing.collectAsState()
    val wbLastSync by vm.watchLastSyncJs.collectAsState()
    val wbAlias by vm.watchAlias.collectAsState()
    val watchBadge = watchBadgeOf(wbDock, wbSyncing, wbLastSync, wbAlias)
    LaunchedEffect(Unit) { while (true) { vm.refreshWatchDock(); kotlinx.coroutines.delay(60_000L) } }
    LaunchedEffect(wbSyncing) { vm.refreshWatchDock() }
    // Acuan latihan (batas HR easy, rentang HR threshold, pace easy) mengikuti zona dan data lari secara otomatis; mesin rencana membaca nilai yang tersimpan.
    LaunchedEffect(state.activities, state.daily, state.settings) {
        val cur = state.settings
        val refs = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
            runCatching { com.endurancevault.app.domain.TrainingRefs.compute(cur, state.activities, state.daily, restHrFrom(state.daily).first) }.getOrNull()
        } ?: return@LaunchedEffect
        com.endurancevault.app.domain.TrainingRefs.update(cur, refs)?.let { vm.saveSettings(it) }
    }
    var progressInitialTab by remember { mutableStateOf("Rekap") }
    val current = nav.currentBackStackEntryAsState().value?.destination?.route
    // Halaman Jam dibuka dari Pengaturan: Back kembali ke Pengaturan, bukan ke Hari ini.
    var settingsReturnRoute by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf<String?>(null) }
    androidx.activity.compose.BackHandler(enabled = settingsReturnRoute != null && current == settingsReturnRoute) {
        settingsReturnRoute = null
        nav.popBackStack()
        showSettings = true
    }
    LaunchedEffect(current) {
        if (current != Tab.Watch.route && current != "watchsettings") settingsReturnRoute = null
    }
    // Jadwal is a contextual destination: it exists only while a training plan is selected.
    val hasTrainingPlan = state.settings.rtype != "none"
    LaunchedEffect(hasTrainingPlan, current) {
        if (!hasTrainingPlan && current == Tab.Schedule.route) {
            nav.navigate(Tab.Week.route) { popUpTo(Tab.Today.route); launchSingleTop = true }
        }
    }
    // Jam ada di Pengaturan (kartu Jam) dan pil status di header; rute "watch" tetap ada tanpa tab dock.
    val onWatchDot: () -> Unit = {
        if (watchBadge?.conn == true) { if (!wbSyncing) vm.syncWatch(false) }
        else { settingsReturnRoute = "watchsettings"; showSettings = false; nav.navigate("watchsettings") { launchSingleTop = true } }
    }
    val onOpenWatch: () -> Unit = { settingsReturnRoute = Tab.Watch.route; showSettings = false; nav.navigate(Tab.Watch.route) { launchSingleTop = true } }
    // Estimasi waktu rute di Explore: tempo "sedang" dari indeks kemampuan lari terakhir (sama dengan dialog Kirim ke jam).
    val exploreAbility = remember(state.settings, state.activities, state.daily) {
        runCatching { ProgressAnalytics.runningAbility(state.settings, state.activities, state.daily) }.getOrNull()
    }
    val exploreEstimate: (List<CourseStrategy.Pt>) -> Double? = { pts ->
        exploreAbility?.let { ab -> runCatching { CourseStrategy.forecast(pts, ab.value, "dry")?.minutesOf(CourseStrategy.Effort.MODERATE) }.getOrNull() }
    }
    val tabs = buildList {
        add(Tab.Today); add(Tab.Progress); add(Tab.Week)
        if (hasTrainingPlan) add(Tab.Schedule)
        add(Tab.Explore)
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentColor = MaterialTheme.colorScheme.onBackground,
        bottomBar = {
            // Dock mengikuti pola aplikasi lama: transparan, empat tujuan utama,
            // Today menjadi tombol utama; Jadwal hanya muncul ketika plan aktif.
            if (!showSettings) Surface(color = MaterialTheme.colorScheme.background, tonalElevation = 0.dp) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth().navigationBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(32.dp))
                            .padding(horizontal = 6.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                    tabs.forEach { t ->
                        val selected = current == t.route || (t == Tab.Explore && current?.startsWith("explore") == true)
                        val isHome = t == Tab.Today
                        Column(
                            modifier = Modifier
                                .weight(if (isHome) 1.18f else 1f)
                                .height(54.dp)
                                .then(
                                    Modifier
                                )
                                .background(
                                    if (isHome && selected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    RoundedCornerShape(14.dp),
                                )
                                .clickable {
                                    nav.navigate(t.route) {
                                        popUpTo(Tab.Today.route) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                                .padding(vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                        ) {
                            Icon(
                                t.icon,
                                contentDescription = t.label,
                                modifier = Modifier.size(20.dp),
                                tint = when {
                                    isHome && selected -> MaterialTheme.colorScheme.onPrimary
                                    selected -> MaterialTheme.colorScheme.primary
                                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                                },
                            )
                            Text(
                                t.label,
                                maxLines = 1,
                                style = MaterialTheme.typography.labelSmall,
                                color = when {
                                    isHome && selected -> MaterialTheme.colorScheme.onPrimary
                                    selected -> MaterialTheme.colorScheme.primary
                                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                                },
                            )
                        }
                    }
                    }
                }
            }
        },
    ) { pad ->
        if (showSettings) {
            // Halaman penuh di luar kartu utama: tanpa header profil dan tanpa dock.
            androidx.compose.foundation.layout.Box(Modifier.fillMaxSize().padding(pad).background(MaterialTheme.colorScheme.background)) {
                ProfileHost(vm, state, onOpenActivity = { id -> showSettings = false; nav.navigate("activity/$id") }, settingsMode = true, onBack = { showSettings = false }, onOpenStickers = { showSettings = false; nav.navigate("sticker") },
                    watchBadge = watchBadge, onWatchDot = onWatchDot, onOpenWatch = onOpenWatch,
                    onOpenProgressDock = { tab -> showSettings = false; progressInitialTab = tab; nav.navigate(Tab.Progress.route) { popUpTo(Tab.Today.route) { saveState = true }; launchSingleTop = true } },
                    profileName = profileName, profilePhotoUri = profilePhotoUri,
                    onEditProfileName = { editedProfileName = profileName; showProfileNameDialog = true },
                    onPickProfilePhoto = { photoPicker.launch(arrayOf("image/*")) })
            }
        } else Column(
            modifier = Modifier.fillMaxSize().padding(pad).background(MaterialTheme.colorScheme.background),
        ) {
            EnduranceProfileHeader(
                name = profileName,
                photoUri = profilePhotoUri,
                recoveryHours = recoveryHours,
                onOpenProfile = { nav.navigate(Tab.Profile.route) { launchSingleTop = true } },
                onOpenSettings = { showSettings = true },
                watchBadge = watchBadge,
            )
            Surface(
                modifier = Modifier.fillMaxWidth().weight(1f).padding(horizontal = 14.dp).padding(bottom = 8.dp),
                shape = RoundedCornerShape(30.dp),
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant),
            ) {
                NavHost(nav, startDestination = Tab.Today.route, modifier = Modifier.fillMaxSize()) {
            composable(Tab.Today.route) {
                val weatherSnap by vm.weatherSnapshot.collectAsState()
                val weatherBusy by vm.weatherBusy.collectAsState()
                val weatherLabel by vm.weatherPlaceLabel.collectAsState()
                val weatherError by vm.weatherError.collectAsState()
                TodayScreen(
                    state = state, onAdd = vm::addActivity, weather = weatherSnap, weatherPlaceLabel = weatherLabel,
                    weatherBusy = weatherBusy, weatherError = weatherError,
                    onRefreshWeather = vm::refreshWeatherFromCard,
                    onAutoRefreshWeather = { maxAge -> vm.refreshWeatherIfStale(maxAge) },
                    onOpenActivity = { id -> nav.navigate("activity/$id") },
                    onGoWeek = { nav.navigate(Tab.Week.route) { launchSingleTop = true } },
                )
            }
            composable(Tab.Progress.route) {
                val trackMsg by vm.trackMsg.collectAsState()
                ProgressScreen(
                    state = state,
                    onDelete = vm::deleteActivity,
                    onOpen = { id -> nav.navigate("activity/$id") },
                    onImportTracks = vm::importTracks,
                    trackMsg = trackMsg,
                    initialTab = progressInitialTab,
                    onSaveSettings = vm::saveSettings,
                )
            }
            composable(Tab.Week.route) {
                val weekTrackMsg by vm.trackMsg.collectAsState()
                ScheduleScreen(
                    state,
                    onOpenActivity = { id -> nav.navigate("activity/$id") },
                    onSetMv = vm::setMv,
                    onSetDone = vm::setDone,
                    onImportTracks = vm::importTracks,
                    trackMsg = weekTrackMsg,
                )
            }
            composable(Tab.Schedule.route) {
                if (hasTrainingPlan) PlanOverviewScreen(state, onOpenActivity = { id -> nav.navigate("activity/$id") }) else TodayScreen(state, vm::addActivity)
            }
            composable(Tab.Watch.route) {
                val watchMsg by vm.watchMessage.collectAsState()
                val watchSyncing by vm.watchSyncing.collectAsState()
                val watchAdvancedMessage by vm.watchAdvancedMessage.collectAsState()
                val dock by vm.watchDock.collectAsState()
                val dockWx by vm.weatherSnapshot.collectAsState()
                val dockLastSyncJs by vm.watchLastSyncJs.collectAsState()
                val dockAlias by vm.watchAlias.collectAsState()
                androidx.compose.foundation.lazy.LazyColumn(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp),
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 18.dp, bottom = 24.dp),
                ) {
                    item {
                        // Dock Jam: kartu jam, ubin data harian, latihan dari jam. Roda gigi membuka halaman pengaturan jam (route watchsettings).
                        WatchDockScreen(
                            ui = dock, activities = state.activities, wx = dockWx, syncing = watchSyncing,
                            lastSyncJsSec = dockLastSyncJs, message = watchMsg, alias = dockAlias,
                            onRefresh = vm::refreshWatchDock, onSync = { vm.syncWatch(false) }, onSaveAlias = vm::setWatchAlias,
                            onPickGpx = vm::pushGpxRoute, onOpenActivity = { id -> nav.navigate("activity/$id") },
                            onOpenSettings = { nav.navigate("watchsettings") },
                        )
                    }
                }
            }
            composable("watchsettings") {
                val watchMsg by vm.watchMessage.collectAsState()
                val watchSyncing by vm.watchSyncing.collectAsState()
                val watchAdvancedMessage by vm.watchAdvancedMessage.collectAsState()
                val agpsStatus by vm.agpsStatus.collectAsState()
                val notifyStatus by vm.notifyStatus.collectAsState()
                androidx.compose.foundation.layout.Box(Modifier.fillMaxSize()) {
                    androidx.compose.foundation.lazy.LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                        verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 18.dp, bottom = 96.dp),
                    ) {
                        item {
                            HuaweiWatchSection(
                                message = watchMsg, onConnect = vm::connectWatch, onDisconnect = vm::disconnectWatch,
                                onForgetAndReconnect = vm::forgetAndReconnectWatch, onSync = vm::syncWatch,
                                isSyncing = watchSyncing, settings = state.settings, advancedMessage = watchAdvancedMessage,
                                onSyncHrZones = vm::syncWatchHrZones, onPushWorkout = vm::pushStructuredWorkout,
                                onSaveSettings = vm::saveSettings, daily = state.daily,
                                agpsContent = { com.endurancevault.app.ui.screens.WatchAgpsSection(agpsStatus, { enabled, mirror -> vm.setAgps(enabled, mirror) }, { vm.testAgps() }) },
                                notifyContent = {
                                    com.endurancevault.app.ui.screens.WatchNotifySection(
                                        notifyStatus,
                                        { enabled, quiet, start, end, screenOff, apps -> vm.setWatchNotifications(enabled, quiet, start, end, screenOff, apps) },
                                        { vm.testWatchNotification() },
                                    )
                                },
                            )
                        }
                    }
                    Surface(
                        modifier = Modifier.align(Alignment.BottomEnd).padding(end = 18.dp, bottom = 18.dp).size(44.dp)
                            .clip(CircleShape).clickable { nav.popBackStack() },
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant),
                    ) {
                        androidx.compose.foundation.layout.Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = com.endurancevault.app.ui.i18n.Lang.tr("Kembali"), modifier = Modifier.size(22.dp))
                        }
                    }
                }
            }
            composable("activity/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
                ActivityDetailScreen(
                    state, e.arguments?.getLong("id") ?: -1L, vm::detailOf, trainingMetrics, vm::setActivityGear, vm::setActivityFeel,
                    onDelete = vm::deleteActivity, onCrop = vm::cropActivity, onEdit = vm::editActivity,
                    onSaveSegments = vm::saveSegments,
                    onOpenSticker = { sid -> nav.navigate("sticker/$sid") },
                    onOpenRouteVideo = { sid -> nav.navigate("routevideo/$sid") },
                ) { nav.popBackStack() }
            }
            composable("sticker") {
                StickerScreen(state, -1L, vm::detailOf) { nav.popBackStack() }
            }
            composable("sticker/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
                StickerScreen(state, e.arguments?.getLong("id") ?: -1L, vm::detailOf) { nav.popBackStack() }
            }
            composable(Tab.Explore.route) {
                ExploreScreen(
                    ctl = vm.explore,
                    initialCenter = RouteGeo.LatLon(vm.weatherLat.value.toDoubleOrNull() ?: -6.99, vm.weatherLon.value.toDoubleOrNull() ?: 110.42),
                    estimateMin = exploreEstimate,
                    onOpenCollection = { nav.navigate("explore/collection") { launchSingleTop = true } },
                )
            }
            composable("explore/collection") {
                ExploreCollectionScreen(
                    ctl = vm.explore,
                    mapCenter = vm.explore.lastView?.let { v -> RouteGeo.LatLon(RouteGeo.latOfWorldY(v.cy0, 0), RouteGeo.lonOfWorldX(v.cx0, 0)) },
                    onBack = { nav.popBackStack() },
                    onOpenRoute = { id -> nav.navigate("explore/route/$id") { launchSingleTop = true } },
                    onShowPlace = { p -> vm.explore.lastView = exViewAt(RouteGeo.LatLon(p.lat, p.lon), 16.0); nav.navigate(Tab.Explore.route) { popUpTo(Tab.Today.route) { saveState = false }; launchSingleTop = true } },
                )
            }
            composable("explore/route/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { e ->
                ExploreRouteDetailScreen(
                    ctl = vm.explore,
                    routeId = e.arguments?.getString("id") ?: "",
                    estimateMin = exploreEstimate,
                    onBack = { nav.popBackStack() },
                    onEdit = { nav.navigate(Tab.Explore.route) { popUpTo(Tab.Today.route) { saveState = false }; launchSingleTop = true } },
                    onSendToWatch = { r ->
                        val prev = r.toWatchPreview()
                        if (prev != null) vm.gpxPreview.value = prev else vm.explore.message.value = "Rute terlalu pendek untuk dikirim ke jam."
                    },
                )
            }
            composable("routevideo/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
                RouteVideoScreen(state, e.arguments?.getLong("id") ?: -1L, vm::detailOf) { nav.popBackStack() }
            }
            composable(Tab.Profile.route) {
                ProfileHost(vm, state, onOpenActivity = { id -> nav.navigate("activity/$id") }, settingsMode = false, onBack = {}, onOpenStickers = { nav.navigate("sticker") },
                    onOpenProgressDock = { tab -> progressInitialTab = tab; nav.navigate(Tab.Progress.route) { popUpTo(Tab.Today.route) { saveState = true }; launchSingleTop = true } })
            }
                }
            }
        }
        if (showProfileNameDialog) {
            AlertDialog(
                onDismissRequest = { showProfileNameDialog = false },
                title = { Text("Nama profil") },
                text = {
                    OutlinedTextField(
                        value = editedProfileName,
                        onValueChange = { editedProfileName = it },
                        singleLine = true,
                        label = { Text("Nama") },
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        profileName = editedProfileName.trim()
                        profilePrefs.edit().putString("name", profileName).apply()
                        showProfileNameDialog = false
                    }) { Text("Simpan") }
                },
                dismissButton = { TextButton(onClick = { showProfileNameDialog = false }) { Text("Batal") } },
            )
        }
    }
}
