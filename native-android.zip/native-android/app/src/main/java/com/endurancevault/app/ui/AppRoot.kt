package com.endurancevault.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.navArgument
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.endurancevault.app.ui.screens.ActivityDetailScreen
import com.endurancevault.app.ui.screens.ProfileScreen
import com.endurancevault.app.ui.screens.ProgressScreen
import com.endurancevault.app.ui.screens.ScheduleScreen
import com.endurancevault.app.ui.screens.TodayScreen

private enum class Tab(val route: String, val label: String, val icon: ImageVector) {
    Today("today", "Hari ini", Icons.Filled.Home),
    Schedule("schedule", "Jadwal", Icons.Filled.CalendarMonth),
    Progress("progress", "Progres", Icons.Filled.ShowChart),
    Profile("profile", "Profil", Icons.Filled.Person),
}

@Composable
fun AppRoot(vm: MainViewModel = viewModel()) {
    val nav = rememberNavController()
    val state by vm.state.collectAsState()
    val current = nav.currentBackStackEntryAsState().value?.destination?.route

    Scaffold(
        bottomBar = {
            NavigationBar {
                Tab.entries.forEach { t ->
                    NavigationBarItem(
                        selected = current == t.route,
                        onClick = {
                            nav.navigate(t.route) {
                                popUpTo(Tab.Today.route) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(t.icon, contentDescription = t.label) },
                        label = { Text(t.label) },
                    )
                }
            }
        },
    ) { pad ->
        NavHost(nav, startDestination = Tab.Today.route, modifier = Modifier.padding(pad)) {
            composable(Tab.Today.route) { TodayScreen(state, vm::addActivity) }
            composable(Tab.Schedule.route) { ScheduleScreen(state) }
            composable(Tab.Progress.route) {
                val msg by vm.trackMsg.collectAsState()
                ProgressScreen(state, vm::deleteActivity, { id -> nav.navigate("activity/$id") }, vm::importTracks, msg)
            }
            composable("activity/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
                ActivityDetailScreen(state, e.arguments?.getLong("id") ?: -1L, vm::detailOf) { nav.popBackStack() }
            }
            composable(Tab.Profile.route) {
                val imp by vm.importState.collectAsState()
                val watchMsg by vm.watchMessage.collectAsState()
                val watchSyncing by vm.watchSyncing.collectAsState()
                val watchAdvancedMessage by vm.watchAdvancedMessage.collectAsState()
                val liveHr by vm.liveHrJson.collectAsState()
                ProfileScreen(
                    state, vm::saveSettings, imp, vm::startImport, vm::confirmImport, vm::dismissImport,
                    vm::saveDaily, vm::saveGear, vm::deleteGear,
                    watchMsg, vm::connectWatch, vm::disconnectWatch, vm::syncWatch, watchSyncing,
                    watchAdvancedMessage, liveHr, vm::refreshLiveHr, vm::setLiveHr, vm::syncWatchHrZones,
                    vm::pushStructuredWorkout, vm::pushGpxRoute,
                )
            }
        }
    }
}
