package com.endurancevault.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.Surface
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.Alignment
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.navArgument
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.endurancevault.app.ui.screens.ActivityDetailScreen
import com.endurancevault.app.ui.screens.ProfileScreen
import com.endurancevault.app.ui.screens.ProgressScreen
import com.endurancevault.app.ui.screens.ScheduleScreen
import com.endurancevault.app.ui.screens.PlanOverviewScreen
import com.endurancevault.app.ui.screens.TodayScreen
import com.endurancevault.app.ui.screens.HuaweiWatchSection

private enum class Tab(val route: String, val label: String, val icon: ImageVector) {
    Today("today", "Today", Icons.Filled.Home),
    Profile("profile", "Profile", Icons.Filled.Person),
    Watch("watch", "Watch", Icons.Filled.CalendarMonth),
    Week("week", "Week", Icons.Filled.ShowChart),
    Schedule("schedule", "Jadwal", Icons.Filled.CalendarMonth),
}

@Composable
fun AppRoot(vm: MainViewModel = viewModel()) {
    val nav = rememberNavController()
    val state by vm.state.collectAsState()
    val current = nav.currentBackStackEntryAsState().value?.destination?.route
    // Jadwal is a contextual destination: it exists only while a training plan is selected.
    val hasTrainingPlan = state.settings.rtype != "none"
    LaunchedEffect(hasTrainingPlan, current) {
        if (!hasTrainingPlan && current == Tab.Schedule.route) {
            nav.navigate(Tab.Week.route) { popUpTo(Tab.Today.route); launchSingleTop = true }
        }
    }
    val tabs = buildList {
        add(Tab.Today); add(Tab.Profile); add(Tab.Watch); add(Tab.Week)
        if (hasTrainingPlan) add(Tab.Schedule)
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentColor = MaterialTheme.colorScheme.onBackground,
        bottomBar = {
            Box(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 7.dp)) {
                Surface(
                    modifier = Modifier.fillMaxWidth().shadow(16.dp, RoundedCornerShape(25.dp)),
                    shape = RoundedCornerShape(25.dp), color = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.onSurface, tonalElevation = 2.dp,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                    NavigationBar(containerColor = Color.Transparent, contentColor = MaterialTheme.colorScheme.onSurface, tonalElevation = 0.dp) {
                        tabs.forEach { t ->
                            val selected = current == t.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = {
                                    nav.navigate(t.route) {
                                        popUpTo(Tab.Today.route) { saveState = true }
                                        launchSingleTop = true; restoreState = true
                                    }
                                },
                                icon = { Icon(t.icon, contentDescription = t.label) },
                                label = { Text(t.label, maxLines = 1) },
                                alwaysShowLabel = selected,
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    indicatorColor = MaterialTheme.colorScheme.primary,
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                ),
                            )
                        }
                    }
                }
            }
        },
    ) { pad ->
        NavHost(nav, startDestination = Tab.Today.route, modifier = Modifier.padding(pad)) {
            composable(Tab.Today.route) { TodayScreen(state, vm::addActivity) }
            composable(Tab.Week.route) { ScheduleScreen(state) }
            composable(Tab.Schedule.route) {
                if (hasTrainingPlan) PlanOverviewScreen(state) else TodayScreen(state, vm::addActivity)
            }
            composable(Tab.Watch.route) {
                val watchMsg by vm.watchMessage.collectAsState()
                val watchSyncing by vm.watchSyncing.collectAsState()
                val watchAdvancedMessage by vm.watchAdvancedMessage.collectAsState()
                val liveHr by vm.liveHrJson.collectAsState()
                androidx.compose.foundation.lazy.LazyColumn(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp)
                ) {
                    item { Text("WATCH", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary) }
                    item {
                        HuaweiWatchSection(
                            message = watchMsg, onConnect = vm::connectWatch, onDisconnect = vm::disconnectWatch,
                            onForgetAndReconnect = vm::forgetAndReconnectWatch, onSync = vm::syncWatch,
                            isSyncing = watchSyncing, settings = state.settings, advancedMessage = watchAdvancedMessage,
                            liveHr = liveHr, onRefreshLiveHr = vm::refreshLiveHr, onSetLiveHr = vm::setLiveHr,
                            onSyncHrZones = vm::syncWatchHrZones, onPushWorkout = vm::pushStructuredWorkout,
                            onPushRoute = vm::pushGpxRoute,
                        )
                    }
                }
            }
            composable("activity/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
                ActivityDetailScreen(state, e.arguments?.getLong("id") ?: -1L, vm::detailOf) { nav.popBackStack() }
            }
            composable(Tab.Profile.route) {
                val imp by vm.importState.collectAsState()
                val watchMsg by vm.watchMessage.collectAsState()
                val watchSyncing by vm.watchSyncing.collectAsState()
                val watchAdvancedMessage by vm.watchAdvancedMessage.collectAsState()
                val liveHr by vm.liveHrJson.collectAsState()
                val weather by vm.weatherMessage.collectAsState()
                val weatherBusy by vm.weatherBusy.collectAsState()
                val weatherLat by vm.weatherLat.collectAsState()
                val weatherLon by vm.weatherLon.collectAsState()
                val weatherWatchStatus by vm.weatherWatchStatus.collectAsState()
                val agpsStatus by vm.agpsStatus.collectAsState()
                val notifyStatus by vm.notifyStatus.collectAsState()
                val aiStatus by vm.aiStatus.collectAsState()
                val aiMessages by vm.aiMessages.collectAsState()
                val aiBusy by vm.aiBusy.collectAsState()
                ProfileScreen(
                    state, vm::saveSettings, imp, vm::startImport, vm::confirmImport, vm::dismissImport,
                    vm::saveDaily, vm::saveGear, vm::deleteGear,
                    watchMsg, vm::connectWatch, vm::disconnectWatch, vm::forgetAndReconnectWatch, vm::syncWatch, watchSyncing,
                    watchAdvancedMessage, liveHr, vm::refreshLiveHr, vm::setLiveHr, vm::syncWatchHrZones,
                    vm::pushStructuredWorkout, vm::pushGpxRoute,
                    weather, weatherBusy, weatherLat, weatherLon, { lat, lon -> vm.fetchWeather(lat, lon) }, { q -> vm.searchWeatherCity(q) }, vm::useCurrentLocation, { lat, lon, name -> vm.sendWeatherToWatch(lat, lon, name) },
                    weatherWatchStatus, agpsStatus, { enabled, mirror -> vm.setAgps(enabled, mirror) }, { vm.testAgps() },
                    notifyStatus, { enabled, quiet, start, end, screenOff, apps -> vm.setWatchNotifications(enabled, quiet, start, end, screenOff, apps) }, { vm.testWatchNotification() },
                    aiStatus, aiMessages, vm::saveAiKey, vm::sendAiQuestion, aiBusy,
                )
            }
        }
    }
}
