package com.endurancevault.app.ui.screens

import android.Manifest
import android.bluetooth.BluetoothManager
import android.content.Context
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import com.rencanalari.huaweiwatch.ProtocolBridge
import org.json.JSONObject

private data class BondedWatch(val name: String, val address: String)

@Composable
fun HuaweiWatchSection(
    message: String,
    onConnect: (String) -> Unit,
    onDisconnect: () -> Unit,
    onSync: (Boolean) -> Unit,
) {
    val context = LocalContext.current
    var devices by remember { mutableStateOf<List<BondedWatch>>(emptyList()) }
    var warningAccepted by remember { mutableStateOf(false) }
    var accountId by remember { mutableStateOf("") }
    var accountHint by remember { mutableStateOf<String?>(null) }
    var discoveryMessage by remember { mutableStateOf("Perangkat belum diperiksa.") }
    var protocolStatus by remember { mutableStateOf<JSONObject?>(null) }

    fun refreshBonded() {
        try {
            val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
            val adapter = manager?.adapter
            if (adapter == null) {
                discoveryMessage = "Bluetooth tidak tersedia pada ponsel ini."
                devices = emptyList()
                return
            }
            if (!adapter.isEnabled) {
                discoveryMessage = "Bluetooth ponsel sedang mati. Aktifkan Bluetooth terlebih dahulu."
                devices = emptyList()
                return
            }
            val found = adapter.bondedDevices.orEmpty().mapNotNull { d ->
                val name = d.name ?: return@mapNotNull null
                val n = name.lowercase()
                if (n.contains("huawei") || n.contains("honor") || n.contains("watch fit") || n.contains("band")) {
                    BondedWatch(name, d.address)
                } else null
            }.sortedBy { it.name.lowercase() }
            devices = found
            discoveryMessage = if (found.isEmpty())
                "Belum ada jam Huawei/Honor yang dipasangkan di pengaturan Bluetooth Android."
            else "${found.size} perangkat terpasang ditemukan."
            protocolStatus = runCatching { ProtocolBridge.get(context).status() }.getOrNull()
        } catch (e: SecurityException) {
            discoveryMessage = "Izin Bluetooth belum diberikan. Izinkan akses perangkat terdekat lalu coba lagi."
        } catch (e: Exception) {
            discoveryMessage = "Gagal membaca perangkat: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    val permissions = buildList {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            add(Manifest.permission.BLUETOOTH_CONNECT)
            add(Manifest.permission.BLUETOOTH_SCAN)
        } else {
            add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }
    val bluetoothPermissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        listOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
    } else {
        listOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        val bluetoothGranted = bluetoothPermissions.all {
            result[it] == true || ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }
        if (bluetoothGranted) refreshBonded()
        else discoveryMessage = "Izin Bluetooth / perangkat terdekat belum diberikan. Izin notifikasi bersifat opsional."
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("Huawei Watch · Bluetooth langsung", style = MaterialTheme.typography.titleLarge)
            Text(
                "EnduranceVault menggunakan protokol Bluetooth JoyoFit/Gadgetbridge yang sudah ada di proyek Rencana Lari. Tidak memakai Huawei Health, Health Kit, atau akun Huawei untuk sinkronisasi.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                "Penting: jam Huawei hanya dapat terikat ke satu aplikasi pendamping. Saat ikatan langsung pertama dibuat, koneksi Huawei Health dapat terputus. Jangan lanjutkan jika kamu masih ingin Huawei Health menjadi aplikasi pendamping utama.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
            )
            Row {
                Checkbox(checked = warningAccepted, onCheckedChange = { warningAccepted = it })
                Text(
                    "Saya memahami konsekuensi ikatan Bluetooth langsung dan ingin melanjutkan.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 10.dp),
                )
            }
            Text(
                "ID akun Huawei opsional (17–19 angka). Pada sebagian jam, ID yang sama dengan akun Huawei Health dapat mencegah permintaan reset saat ikatan pertama. Simpan sebelum menghubungkan; ID disimpan lokal dan hanya petunjuk 4 digit terakhir yang ditampilkan.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedTextField(
                value = accountId,
                onValueChange = { accountId = it.filter { c -> c.isDigit() }.take(19) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("ID akun Huawei (opsional)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                visualTransformation = PasswordVisualTransformation(),
            )
            OutlinedButton(
                onClick = {
                    try {
                        val bridge = ProtocolBridge.get(context)
                        bridge.setHuaweiAccount(accountId.trim())
                        val info = bridge.huaweiAccountInfo()
                        accountHint = if (info.optBoolean("set")) "ID tersimpan (…${info.optString("hint")})." else "ID akun dihapus."
                        accountId = ""
                    } catch (e: Exception) {
                        accountHint = "ID tidak valid: ${e.message ?: e.javaClass.simpleName}"
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Simpan ID akun di perangkat") }
            accountHint?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            Button(
                onClick = {
                    if (permissions.isEmpty() || permissions.all {
                            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
                        }) refreshBonded()
                    else permissionLauncher.launch(permissions.toTypedArray())
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Periksa perangkat Bluetooth terpasang") }

            Text(discoveryMessage, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            devices.forEach { watch ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(watch.name, style = MaterialTheme.typography.titleMedium)
                        Text("Perangkat sudah dipasangkan di Android", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Button(
                            onClick = { onConnect(watch.address) },
                            enabled = warningAccepted,
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("Hubungkan ke EnduranceVault") }
                    }
                }
            }

            protocolStatus?.let { st ->
                val state = st.optString("state", "disconnected")
                val battery = st.optInt("battery", -1)
                Text(
                    "Status protokol: $state" + if (battery >= 0) " · baterai jam $battery%" else "",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            Text(message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { onSync(false) }, modifier = Modifier.weight(1f)) { Text("Sinkronkan") }
                OutlinedButton(onClick = onDisconnect, modifier = Modifier.weight(1f)) { Text("Putuskan") }
            }
            OutlinedButton(onClick = { onSync(true) }, modifier = Modifier.fillMaxWidth()) {
                Text("Sinkron riwayat penuh dari jam")
            }
            Text(
                "Data workout dengan GPS diimpor sebagai aktivitas dengan rute; workout tanpa GPS sebagai ringkasan. Pengambilan workout ke jadwal dibatasi 100 sesi terbaru per sinkron penuh. HR istirahat, HRV, tidur, dan fase tidur mengisi catatan harian tanpa menimpa nilai manual.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
