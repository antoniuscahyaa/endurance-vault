package com.endurancevault.app.ui.screens

import android.Manifest
import android.bluetooth.BluetoothManager
import android.content.Context
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import com.rencanalari.huaweiwatch.ProtocolBridge
import com.rencanalari.huaweiwatch.KeepAliveConfig
import org.json.JSONObject
import com.endurancevault.app.domain.PlanSettings

private data class BondedWatch(val name: String, val address: String)

@Composable
fun HuaweiWatchSection(
    message: String,
    onConnect: (String) -> Unit,
    onDisconnect: () -> Unit,
    onForgetAndReconnect: (String) -> Unit,
    onSync: (Boolean) -> Unit,
    isSyncing: Boolean,
    settings: PlanSettings,
    advancedMessage: String,
    liveHr: JSONObject,
    onRefreshLiveHr: () -> Unit,
    onSetLiveHr: (Boolean) -> Unit,
    onSyncHrZones: (PlanSettings) -> Unit,
    onPushWorkout: (String, Int, Int, Int, Int, Int) -> Unit,
    onPushRoute: (android.net.Uri) -> Unit,
) {
    val context = LocalContext.current
    var devices by remember { mutableStateOf<List<BondedWatch>>(emptyList()) }
    var warningAccepted by remember { mutableStateOf(false) }
    var accountId by remember { mutableStateOf("") }
    var accountHint by remember { mutableStateOf<String?>(null) }
    var accountSaved by remember { mutableStateOf(false) }
    var discoveryMessage by remember { mutableStateOf("Perangkat belum diperiksa.") }
    var protocolStatus by remember { mutableStateOf<JSONObject?>(null) }
    var keepInterval by remember { mutableStateOf(KeepAliveConfig.intervalMin(context).toString()) }
    var lowBattery by remember { mutableStateOf(KeepAliveConfig.lowBatteryPct(context).toString()) }
    var keepAliveWanted by remember { mutableStateOf(KeepAliveConfig.wanted(context)) }
    var keepAliveMessage by remember { mutableStateOf("Penjagaan latar ${if (KeepAliveConfig.wanted(context)) "diaktifkan" else "nonaktif"}.") }
    var forgetTarget by remember { mutableStateOf<BondedWatch?>(null) }
    var courseName by remember { mutableStateOf("EnduranceVault Interval") }
    var warmup by remember { mutableStateOf("10") }
    var repeats by remember { mutableStateOf("4") }
    var runMin by remember { mutableStateOf("4") }
    var recovery by remember { mutableStateOf("2") }
    var cooldown by remember { mutableStateOf("10") }
    val routePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) onPushRoute(uri) }

    fun refreshAccountStatus() {
        runCatching { ProtocolBridge.get(context).huaweiAccountInfo() }
            .onSuccess { info ->
                accountSaved = info.optBoolean("set")
                accountHint = if (accountSaved) "ID akun tersimpan di perangkat (…${info.optString("hint")})." else "Belum ada ID akun Huawei tersimpan."
            }
            .onFailure { accountHint = "Status ID akun tidak dapat dibaca: ${it.message ?: it.javaClass.simpleName}" }
    }

    fun refreshProtocolStatus() {
        protocolStatus = runCatching { ProtocolBridge.get(context).status() }.getOrNull()
    }

    LaunchedEffect(context) {
        refreshAccountStatus()
        refreshProtocolStatus()
    }
    LaunchedEffect(liveHr.optBoolean("active")) {
        if (liveHr.optBoolean("active")) {
            while (true) {
                onRefreshLiveHr()
                kotlinx.coroutines.delay(1200)
            }
        }
    }

    fun refreshBonded() {
        try {
            val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
            val adapter = manager?.adapter
            if (adapter == null) {
                discoveryMessage = "Bluetooth tidak tersedia pada ponsel ini."
                devices = emptyList()
                return
            }
            if (!adapter.isEnabled) {
                discoveryMessage = "Bluetooth ponsel sedang mati. Aktifkan Bluetooth terlebih dahulu."
                devices = emptyList()
                return
            }
            val found = adapter.bondedDevices.orEmpty().mapNotNull { d ->
                val name = d.name ?: return@mapNotNull null
                val n = name.lowercase()
                if (n.contains("huawei") || n.contains("honor") || n.contains("watch fit") || n.contains("band")) {
                    BondedWatch(name, d.address)
                } else null
            }.sortedBy { it.name.lowercase() }
            devices = found
            discoveryMessage = if (found.isEmpty())
                "Belum ada jam Huawei/Honor yang dipasangkan di pengaturan Bluetooth Android."
            else "${found.size} perangkat terpasang ditemukan."
            refreshProtocolStatus()
        } catch (e: SecurityException) {
            discoveryMessage = "Izin Bluetooth belum diberikan. Izinkan akses perangkat terdekat lalu coba lagi."
        } catch (e: Exception) {
            discoveryMessage = "Gagal membaca perangkat: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    val permissions = buildList {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            add(Manifest.permission.BLUETOOTH_CONNECT)
            add(Manifest.permission.BLUETOOTH_SCAN)
        } else {
            add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }
    val bluetoothPermissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        listOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
    } else {
        listOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        val bluetoothGranted = bluetoothPermissions.all {
            result[it] == true || ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }
        if (bluetoothGranted) refreshBonded()
        else discoveryMessage = "Izin Bluetooth / perangkat terdekat belum diberikan. Izin notifikasi bersifat opsional."
    }

    forgetTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { forgetTarget = null },
            title = { Text("Lupakan jam & ikat ulang?") },
            text = { Text("Kunci autentikasi/pairing lama untuk ${target.name} akan dihapus, lalu aplikasi mencoba menghubungkan ulang. Huawei Health dapat terputus dari jam. Data latihan dan riwayat EnduranceVault tidak dihapus. Konfirmasi pairing pada layar jam bila diminta.") },
            confirmButton = {
                TextButton(onClick = {
                    forgetTarget = null
                    onForgetAndReconnect(target.address)
                }, enabled = !isSyncing) { Text("Lupakan & hubungkan ulang") }
            },
            dismissButton = { TextButton(onClick = { forgetTarget = null }) { Text("Batal") } },
        )
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("Huawei Watch · Bluetooth langsung", style = MaterialTheme.typography.titleLarge)
            Text(
                "EnduranceVault menggunakan protokol Bluetooth langsung JoyoFit/Gadgetbridge dari proyek Rencana Lari. Bukan Huawei Health atau Health Kit. ID akun Huawei opsional hanya dipakai saat proses pairing bila jam memerlukannya; data disinkronkan langsung melalui Bluetooth.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                "Penting: jam Huawei hanya dapat terikat ke satu aplikasi pendamping. Saat ikatan langsung pertama dibuat, koneksi Huawei Health dapat terputus. Jangan lanjutkan jika kamu masih ingin Huawei Health menjadi aplikasi pendamping utama.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
            )
            Row {
                Checkbox(checked = warningAccepted, onCheckedChange = { warningAccepted = it })
                Text(
                    "Saya memahami konsekuensi ikatan Bluetooth langsung dan ingin melanjutkan.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 10.dp),
                )
            }
            Text(
                "ID akun Huawei opsional (17–19 angka). Pada sebagian jam, ID yang sama dengan akun Huawei Health dapat mencegah permintaan reset saat ikatan pertama. Simpan sebelum menghubungkan; ID disimpan lokal dan hanya petunjuk 4 digit terakhir yang ditampilkan.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedTextField(
                value = accountId,
                onValueChange = { accountId = it.filter { c -> c.isDigit() }.take(19) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("ID akun Huawei (opsional)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                visualTransformation = PasswordVisualTransformation(),
            )
            OutlinedButton(
                onClick = {
                    try {
                        val clean = accountId.trim()
                        require(clean.matches(Regex("[0-9]{17,19}"))) { "Masukkan ID 17–19 angka." }
                        val bridge = ProtocolBridge.get(context)
                        bridge.setHuaweiAccount(clean)
                        accountId = ""
                        refreshAccountStatus()
                    } catch (e: Exception) {
                        accountHint = "ID tidak disimpan: ${e.message ?: e.javaClass.simpleName}"
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = accountId.trim().matches(Regex("[0-9]{17,19}")),
            ) { Text("Simpan ID akun di perangkat") }
            if (accountSaved) {
                OutlinedButton(
                    onClick = {
                        runCatching { ProtocolBridge.get(context).setHuaweiAccount("") }
                            .onSuccess { accountId = ""; refreshAccountStatus() }
                            .onFailure { accountHint = "Gagal menghapus ID: ${it.message ?: it.javaClass.simpleName}" }
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Hapus ID akun tersimpan") }
            }
            accountHint?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            Button(
                onClick = {
                    if (permissions.isEmpty() || permissions.all {
                            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
                        }) refreshBonded()
                    else permissionLauncher.launch(permissions.toTypedArray())
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Periksa perangkat Bluetooth terpasang") }

            Text(discoveryMessage, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            devices.forEach { watch ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(watch.name, style = MaterialTheme.typography.titleMedium)
                        Text("Perangkat sudah dipasangkan di Android", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Button(
                            onClick = { onConnect(watch.address) },
                            enabled = warningAccepted && !isSyncing,
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("Hubungkan ke EnduranceVault") }
                        OutlinedButton(
                            onClick = { forgetTarget = watch },
                            enabled = warningAccepted && !isSyncing,
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("Lupakan jam & ikat ulang") }
                    }
                }
            }

            protocolStatus?.let { st ->
                val state = st.optString("state", "disconnected")
                val battery = st.optInt("battery", -1)
                Text(
                    "Status protokol: $state" + if (battery >= 0) " · baterai jam $battery%" else " · baterai belum dibaca",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            OutlinedButton(onClick = { refreshProtocolStatus(); refreshBonded() }, modifier = Modifier.fillMaxWidth()) {
                Text("Perbarui status koneksi dan perangkat")
            }
            Text(message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { onSync(false) }, enabled = !isSyncing, modifier = Modifier.weight(1f)) { Text(if (isSyncing) "Sedang sinkron…" else "Sinkronkan") }
                OutlinedButton(onClick = onDisconnect, enabled = !isSyncing, modifier = Modifier.weight(1f)) { Text("Putuskan") }
            }
            OutlinedButton(onClick = { onSync(true) }, enabled = !isSyncing, modifier = Modifier.fillMaxWidth()) {
                Text("Sinkron riwayat penuh dari jam")
            }
            Text(
                "Data workout dengan GPS diimpor sebagai aktivitas dengan rute; workout tanpa GPS sebagai ringkasan. Pengambilan workout ke jadwal dibatasi 100 sesi terbaru per sinkron penuh. HR istirahat, HRV, tidur, dan fase tidur mengisi catatan harian tanpa menimpa nilai manual.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            androidx.compose.material3.HorizontalDivider()
            Text("Fitur lanjutan jam", style = MaterialTheme.typography.titleMedium)
            Text("Live Heart Rate", style = MaterialTheme.typography.titleSmall)
            Text("${liveHr.optInt("bpm")} bpm · " + if (liveHr.optBoolean("running")) "stream aktif" else if (liveHr.optBoolean("active")) "menunggu bacaan" else "nonaktif", style = MaterialTheme.typography.bodyMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { onSetLiveHr(!liveHr.optBoolean("active")) }, modifier = Modifier.weight(1f), enabled = !isSyncing) { Text(if (liveHr.optBoolean("active")) "Matikan Live HR" else "Aktifkan Live HR") }
                OutlinedButton(onClick = onRefreshLiveHr, modifier = Modifier.weight(1f)) { Text("Perbarui HR") }
            }
            Text("Zona HR", style = MaterialTheme.typography.titleSmall)
            Text("Kirim batas zona dari pengaturan latihan EnduranceVault (${settings.zm.uppercase()}) ke jam.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = { onSyncHrZones(settings) }, modifier = Modifier.fillMaxWidth(), enabled = !isSyncing) { Text("Kirim zona HR ke jam") }
            Text("Structured workout", style = MaterialTheme.typography.titleSmall)
            OutlinedTextField(value = courseName, onValueChange = { courseName = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Nama workout") })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(value = warmup, onValueChange = { warmup = it.filter(Char::isDigit).take(2) }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("Pemanasan (menit)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(value = repeats, onValueChange = { repeats = it.filter(Char::isDigit).take(2) }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("Repetisi") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(value = runMin, onValueChange = { runMin = it.filter(Char::isDigit).take(3) }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("Lari (menit)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(value = recovery, onValueChange = { recovery = it.filter(Char::isDigit).take(2) }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("Recovery (menit)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(value = cooldown, onValueChange = { cooldown = it.filter(Char::isDigit).take(2) }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("Pendinginan") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }
            OutlinedButton(onClick = { onPushWorkout(courseName, warmup.toIntOrNull() ?: 0, repeats.toIntOrNull() ?: 0, runMin.toIntOrNull() ?: 0, recovery.toIntOrNull() ?: 0, cooldown.toIntOrNull() ?: 0) }, modifier = Modifier.fillMaxWidth(), enabled = !isSyncing) { Text("Kirim structured workout") }
            Text("Rute GPX", style = MaterialTheme.typography.titleSmall)
            Text("Pilih file .gpx untuk dikirim sebagai rute navigasi ke jam. Dukungan bergantung pada kapabilitas firmware dan layanan P2P jam.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = { routePicker.launch(arrayOf("application/gpx+xml", "application/xml", "text/xml", "*/*")) }, modifier = Modifier.fillMaxWidth(), enabled = !isSyncing) { Text("Pilih dan kirim rute GPX") }
            Text(advancedMessage, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            androidx.compose.material3.HorizontalDivider()
            Text("Koneksi latar belakang", style = MaterialTheme.typography.titleMedium)
            Text(
                "Saat aktif, EnduranceVault menjaga koneksi dan menyinkronkan data secara berkala melalui notifikasi layanan. Pengaturan ini tidak menjamin Android atau EMUI/HarmonyOS akan selalu mengizinkan proses berjalan; optimasi baterai ponsel mungkin tetap perlu diatur manual.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedTextField(
                value = keepInterval,
                onValueChange = { keepInterval = it.filter(Char::isDigit).take(2) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Interval sinkron otomatis (2–60 menit)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            )
            OutlinedTextField(
                value = lowBattery,
                onValueChange = { lowBattery = it.filter(Char::isDigit).take(2) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Peringatan baterai jam rendah (0–50%, 0 = mati)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            )
            Text(keepAliveMessage, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(
                onClick = {
                    val interval = keepInterval.toIntOrNull()
                    val threshold = lowBattery.toIntOrNull()
                    if (interval == null || interval !in 2..60 || threshold == null || threshold !in 0..50) {
                        keepAliveMessage = "Nilai tidak valid. Interval 2–60 menit dan ambang baterai 0–50%."
                    } else {
                        KeepAliveConfig.setIntervalMin(context, interval)
                        KeepAliveConfig.setLowBatteryPct(context, threshold)
                        KeepAliveConfig.setWanted(context, true)
                        val error = KeepAliveConfig.start(context)
                        keepAliveWanted = true
                        keepAliveMessage = if (error == null) "Penjagaan latar diaktifkan. Interval $interval menit; peringatan baterai $threshold%."
                            else "Pengaturan tersimpan, tetapi layanan belum dapat dimulai: $error"
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = !isSyncing,
            ) { Text("Simpan & aktifkan koneksi latar") }
            OutlinedButton(
                onClick = {
                    KeepAliveConfig.setWanted(context, false)
                    KeepAliveConfig.stop(context)
                    keepAliveWanted = false
                    keepAliveMessage = "Penjagaan latar dimatikan. Koneksi aktif tidak diputus; sinkron otomatis berhenti."
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = keepAliveWanted && !isSyncing,
            ) { Text("Matikan sinkron latar") }
        }
    }
}
