package com.endurancevault.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.endurancevault.app.domain.PDay
import com.endurancevault.app.domain.StrengthBlock

/** Nama metode latihan untuk penanda di hari (tm: pyr | pol | maf). */
internal fun methodTag(tm: String?): String? = when (tm) {
    "pyr" -> "Metode Pyramidal"
    "pol" -> "Metode Polarized"
    "maf" -> "Metode Base ringan (MAF)"
    else -> null
}

private fun StrengthBlock.shortLabel() = "$title · $mins mnt"

/**
 * Penanda metode latihan dan blok strength (kaki, ankle, upper) pada satu hari.
 * @param expanded false: satu baris ringkas; true: lengkap dengan catatan dan daftar gerakan.
 */
@Composable
internal fun SupportBlocks(d: PDay, expanded: Boolean) {
    val blocks = listOfNotNull(d.str, d.ank, d.up)
    val tag = methodTag(d.tm)
    if (blocks.isEmpty() && tag == null) return
    if (!expanded) {
        tag?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.tertiary) }
        blocks.forEach { Text("+ ${it.shortLabel()}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary) }
        return
    }
    tag?.let { Text(it, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.tertiary) }
    blocks.forEach { b ->
        Card(
            Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        ) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(b.shortLabel(), style = MaterialTheme.typography.titleSmall)
                Text(b.note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                b.lines.forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium) }
            }
        }
    }
}
