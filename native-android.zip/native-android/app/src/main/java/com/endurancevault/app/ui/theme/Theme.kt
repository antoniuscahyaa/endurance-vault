package com.endurancevault.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Ember = Color(0xFFFF7A12)
val Ink = Color(0xFF0B0C0F)
val Panel = Color(0xFF16181D)
val PanelHi = Color(0xFF1F2229)

private val Dark = darkColorScheme(
    primary = Ember,
    onPrimary = Color.Black,
    background = Ink,
    onBackground = Color(0xFFECEDEF),
    surface = Panel,
    onSurface = Color(0xFFECEDEF),
    surfaceVariant = PanelHi,
    onSurfaceVariant = Color(0xFFA9ADB6),
    error = Color(0xFFFF6B6B),
)

@Composable
fun EnduranceVaultTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Dark, content = content)
}
