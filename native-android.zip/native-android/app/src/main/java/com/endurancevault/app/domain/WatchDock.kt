package com.endurancevault.app.domain

import com.endurancevault.app.data.HuaweiSleepParity
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * Port dari src/js/main/30-dock-jam.js (tab dock "Jam" di versi web): semua fungsi `jam*` yang murni (tanpa DOM).
 * Tidak menyentuh Android, jadi bisa diuji di JVM (WatchDockTest). Angka, pembulatan, dan teks mengikuti versi web
 * (Bahasa Indonesia; ribuan dipisah titik, desimal koma).
 */

// ---------------------------------------------------------------------------------------------------------------------
// Model tampilan
// ---------------------------------------------------------------------------------------------------------------------

/** Satu ubin data harian (langkah, HR, HR istirahat, kalori, jarak, SpO2, tidur, baterai). */
data class WatchTile(
    val k: String, val label: String, val value: String, val sub: String,
    val bar: Int? = null, val live: Boolean = false, val low: Boolean = false,
)

data class WatchHr(val min: Int, val avg: Int, val max: Int)
data class WatchHrPoint(val t: Long, val hr: Double, val hrMin: Double, val hrMax: Double)
data class WatchHrToday(val min: Int, val avg: Int, val max: Int, val series: List<WatchHrPoint>, val t0: Long, val now: Long)

/** Angka hari ini yang sudah digabung (dipakai panel rinci dan baris hari ini di grafik 7 hari). */
data class WatchCur(
    val steps: Double, val kcal: Double, val dist: Double, val rhr: Int,
    val spo2: Int, val spo2Avg: Double, val spo2Min: Int, val spo2Max: Int, val spo2N: Int, val hr: WatchHr?,
)

data class WatchDay(
    val d: String, val l: String, val now: Boolean,
    val steps: Double = 0.0, val kcal: Double = 0.0, val dist: Double = 0.0, val rhr: Int = 0,
    val hrAvg: Int = 0, val hrMin: Int = 0, val hrMax: Int = 0,
    val spo2Avg: Int = 0, val spo2Min: Int = 0, val spo2Max: Int = 0,
)

data class WatchHourly(val steps: DoubleArray, val kcal: DoubleArray, val dist: DoubleArray, val hasCal: Boolean, val hasDist: Boolean)
data class WatchSpo2Point(val t: Long, val v: Double, val lo: Double)

data class SleepStage(val k: String, val label: String, val min: Int)

data class SleepSummary(
    val date: String, val bed: String, val wake: String, val asleep: Int, val eff: Int?,
    val stages: List<SleepStage>, val tot: Int,
    val wakes: List<HuaweiSleepParity.Wake>, val wakeN: Int, val wakeMin: Int,
    val extras: List<HuaweiSleepParity.Extra>, val extraMin: Int, val lat: Int,
    val start: Long, val end: Long, val blocks: List<HuaweiSleepParity.Block>,
    val score: Int = 0, val spo2: Int = 0, val resp: Int = 0,
)

/** Satu malam untuk sumbu 7 hari (batang bertumpuk dan daftar terbangun). */
data class NightBar(
    val l: String, val now: Boolean, val date: String = "", val asleep: Int = 0, val awake: Int = 0,
    val stages: List<Pair<String, Int>> = emptyList(), val bed: String = "", val wake: String = "",
    val wakes: List<HuaweiSleepParity.Wake> = emptyList(), val extras: List<HuaweiSleepParity.Extra> = emptyList(),
    val lat: Int = 0, val wakeN: Int = 0,
)

data class BatPoint(val t: Long, val p: Int)
data class BatEst(val liveH: Double?, val endTs: Long?, val runH: Double?, val charging: Boolean, val txt: String)
data class BatSession(val s: Int, val e: Int, val used: Int, val ph: Double?, val ap: Boolean)

/** Latihan dari jam (tabel workouts). */
data class WatchWorkout(
    val start: Long, val end: Long, val sportType: Int, val sportName: String, val duration: Int, val distance: Int,
    val calories: Int, val avgHr: Int, val maxHr: Int, val complete: Boolean, val recoveryHours: Double, val gpsPoints: Int,
)

/** Potongan cuaca yang dipakai watchface mock-up: suhu jam ini, 3 jam berikutnya, tertinggi/terendah, terbenam. */
data class WatchWxHour(val h: String, val t: Int, val kind: String)
data class WatchWx(val t: Int, val hi: Int?, val lo: Int?, val sun: String, val hours: List<WatchWxHour>)

data class WatchDockDebug(val rows: List<String>)

data class WatchModel(
    val ready: Boolean, val conn: Boolean, val state: String, val battery: Int?, val device: String, val devName: String,
    val tiles: List<WatchTile>, val hr: WatchHrToday?, val sleep: SleepSummary?,
    val cur: WatchCur, val wk: List<WatchDay>, val hourly: WatchHourly, val spo2s: List<WatchSpo2Point>,
    val nights7: List<NightBar>, val naps: List<HuaweiSleepParity.Nap>, val workouts: List<WatchWorkout>,
    val batEst: BatEst, val batSessions: List<Pair<Long, BatSession>>,
    val recH: Double, val keepAlive: Boolean, val lastSyncAt: Long?, val syncErr: String?, val linkErr: String?,
    val lastTs: Long?, val now: Long, val tzMin: Int, val t0: Long, val hrMax: Int, val debug: WatchDockDebug,
) {
    val tile: Map<String, WatchTile> get() = tiles.associateBy { it.k }
}

/** Mentah hasil baca plugin (status, live, daily, workouts) + hasil olahan tidur dan log baterai. */
class WatchRaw(
    val status: JSONObject,
    val live: JSONObject,
    val daily: JSONObject,
    val nights: List<HuaweiSleepParity.Night>,
    val naps: List<HuaweiSleepParity.Nap>,
    val sleepHr: Double,
    val workouts: List<WatchWorkout>,
    val batLog: List<BatPoint>,
    val alias: String = "",
)

/** Satu info blok di posisi slider hipnogram. */
data class HypInfo(val i: Int, val k: String, val label: String, val from: String, val to: String, val dur: String)

/** Sel pace/kecepatan satu latihan. */
data class PaceCell(val v: String, val u: String)

// ---------------------------------------------------------------------------------------------------------------------
// Fungsi murni
// ---------------------------------------------------------------------------------------------------------------------

object WatchDock {
    const val GOAL = 10_000
    const val BUCKET = 600
    const val POLL_MS = 30_000L
    const val SYNC_MS = 300_000L
    val DOW = listOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min")

    // Warna fase tidur (sama dengan CSS web: jm-s-deep/rem/light/awake/extra).
    const val C_DEEP = 0xFF2F6FD0
    const val C_REM = 0xFF8E6BD8
    const val C_LIGHT = 0xFF7AA7E8
    const val C_AWAKE = 0xFFE5934B
    const val C_EXTRA = 0xFF9AA7B8

    private fun r(x: Double): Double = floor(x + 0.5)
    private fun JSONObject?.dd(k: String): Double = this?.optDouble(k, 0.0)?.takeIf { it.isFinite() } ?: 0.0
    private fun JSONObject?.ii(k: String): Int = this.dd(k).toInt()
    private fun JSONObject?.ll(k: String): Long = this.dd(k).toLong()
    private fun JSONObject?.has0(k: String): Boolean = this != null && this.has(k) && !this.isNull(k)
    private fun JSONObject?.ss(k: String): String? =
        if (this != null && this.has(k) && !this.isNull(k)) this.optString(k).takeIf { it.isNotBlank() } else null

    // ---- format ----

    fun num(n: Double): String {
        val v = r(n).toLong(); val s = abs(v).toString(); val sb = StringBuilder()
        s.forEachIndexed { i, c -> if (i > 0 && (s.length - i) % 3 == 0) sb.append('.'); sb.append(c) }
        return (if (v < 0) "-" else "") + sb
    }

    fun dec(n: Double, d: Int): String {
        val p = 10.0.pow(d)
        return String.format(Locale.US, "%.${d}f", r(n * p) / p).replace('.', ',')
    }

    /** Satuan jarak dari jam tidak pasti (meter atau sentimeter): pilih yang masuk akal terhadap panjang langkah 0,3-1,5 m. */
    fun distM(dist: Double, steps: Double): Double {
        if (dist <= 0) return if (steps > 0) r(steps * 0.75) else 0.0
        if (steps <= 0) return dist
        val q = dist / steps
        if (q in 0.3..1.5) return dist
        if (q in 30.0..150.0) return dist / 100
        return steps * 0.75
    }

    fun kcal(cal: Double): Int = r(cal / 1000).toInt()
    fun kcalF(cal: Double): Double = cal / 1000
    fun kcalTxt(k: Double): String = if (k >= 10) num(k) + " kkal" else if (k > 0) dec(k, 1) + " kkal" else "0 kkal"

    /** HR istirahat satu hari: nilai terbaru yang dilaporkan jam; rata-rata hanya cadangan untuk data lama. */
    fun rhrOf(d: JSONObject?): Int {
        val last = d.dd("rhrLast"); val n = d.ii("rhrN"); val avg = d.dd("rhrAvg")
        val v = r(if (last > 0) last else if (n >= 1 && avg > 0) avg else 0.0)
        return if (v in 30.0..120.0) v.toInt() else 0
    }

    fun ago(nowSec: Long, ts: Long): String {
        if (ts <= 0) return ""
        val m = max(0L, (nowSec - ts) / 60)
        if (m < 1) return "baru saja"
        if (m < 60) return "$m mnt lalu"
        val h = m / 60
        if (h < 24) return "$h jam lalu"
        return "${h / 24} hari lalu"
    }

    /** Menit -> "6j 40m". */
    fun hm(min: Int): String { val m = max(0, min); return "${m / 60}j ${m % 60}m" }
    fun hm(min: Double): String = hm(r(min).toInt())

    private fun pad(n: Int) = if (n < 10) "0$n" else "$n"

    /** Jam:menit lokal (zona = menit offset dari UTC), padanan hwHm. */
    fun clock(ts: Long, tzMin: Int): String {
        val lm = (((Math.floorDiv(ts, 60L) + tzMin) % 1440 + 1440) % 1440).toInt()
        return pad(lm / 60) + ":" + pad(lm % 60)
    }

    /** Tanggal lokal ISO, padanan hwLocalDate. */
    fun localDate(ts: Long, tzMin: Int): String =
        Instant.ofEpochSecond(ts + tzMin * 60L).atZone(ZoneOffset.UTC).toLocalDate().toString()

    fun dur(sec: Int): String {
        val s = max(0, sec); val h = s / 3600; val m = s % 3600 / 60; val x = s % 60
        return if (h > 0) "$h:${pad(m)}:${pad(x)}" else "$m:${pad(x)}"
    }

    fun paceStr(minPerKm: Double): String {
        if (!minPerKm.isFinite() || minPerKm <= 0) return "–"
        val s = r(minPerKm * 60).toInt(); return "${s / 60}:${pad(s % 60)}"
    }

    /** Nama tipe jam tanpa kode: "HUAWEI WATCH FIT 4" -> "Watch Fit 4". */
    fun devName(d: JSONObject?): String {
        val raw = d.ss("name") ?: d.ss("model") ?: ""
        val n = raw.replace(Regex("^\\s*huawei\\s+", RegexOption.IGNORE_CASE), "").replace(Regex("\\s*\\([^)]*\\)\\s*$"), "").trim()
        if (n.isEmpty()) return ""
        return Regex("(^|\\s)(\\S)").replace(n.lowercase()) { it.groupValues[1] + it.groupValues[2].uppercase() }
    }

    // ---- 7 hari ----

    /** 7 hari terakhir (termasuk hari ini) dari baris harian jam; hari tanpa data = 0 dan ditandai kosong. */
    data class StepDay(val d: String, val l: String, val steps: Double, val has: Boolean, val now: Boolean)

    fun weekSteps(days: JSONArray?, todayIso: String, n: Int): List<StepDay> {
        val map = daysMap(days); val t = LocalDate.parse(todayIso)
        return (n - 1 downTo 0).map { i ->
            val d = t.minusDays(i.toLong()); val iso = d.toString(); val row = map[iso]
            val st = row.dd("steps")
            StepDay(iso, DOW[d.dayOfWeek.value - 1], if (row != null) st else 0.0, row != null && st > 0, i == 0)
        }
    }

    private fun daysMap(days: JSONArray?): Map<String, JSONObject> {
        val map = HashMap<String, JSONObject>()
        if (days != null) for (i in 0 until days.length()) days.optJSONObject(i)?.let { o -> o.ss("day")?.let { map[it] = o } }
        return map
    }

    /** 7 hari dengan semua metrik harian. cur = angka hari ini yang sudah digabung. */
    fun weekDetail(days: JSONArray?, todayIso: String, n: Int, cur: WatchCur?): List<WatchDay> {
        val map = daysMap(days); val t = LocalDate.parse(todayIso)
        return (n - 1 downTo 0).map { i ->
            val d = t.minusDays(i.toLong()); val iso = d.toString(); val row = map[iso]; val now = i == 0
            var o = WatchDay(iso, DOW[d.dayOfWeek.value - 1], now)
            if (row != null) {
                val steps = row.dd("steps"); val distRaw = row.dd("distance")
                o = o.copy(
                    steps = steps, kcal = kcalF(row.dd("calories")),
                    dist = if (steps > 0 || distRaw > 0) distM(distRaw, steps) else 0.0, rhr = rhrOf(row),
                )
                if (row.ii("hrN") > 0 && row.dd("hrAvg") > 0) o = o.copy(hrAvg = r(row.dd("hrAvg")).toInt(), hrMin = row.ii("hrMin"), hrMax = row.ii("hrMax"))
                if (row.ii("spo2N") > 0 && row.dd("spo2Avg") > 0) {
                    val avg = r(row.dd("spo2Avg")).toInt()
                    o = o.copy(spo2Avg = avg, spo2Min = row.ii("spo2Min"), spo2Max = row.ii("spo2Max").takeIf { it > 0 } ?: avg)
                }
            }
            if (now && cur != null) {
                o = o.copy(steps = max(o.steps, cur.steps), kcal = max(o.kcal, cur.kcal), dist = max(o.dist, cur.dist))
                if (cur.hr != null && cur.hr.avg > 0) o = o.copy(hrAvg = cur.hr.avg, hrMin = cur.hr.min, hrMax = cur.hr.max)
                if (cur.spo2Avg > 0) {
                    val avg = r(cur.spo2Avg).toInt()
                    o = o.copy(spo2Avg = avg, spo2Min = cur.spo2Min.takeIf { it > 0 } ?: avg, spo2Max = cur.spo2Max.takeIf { it > 0 } ?: avg)
                }
            }
            o
        }
    }

    /** Per jam hari ini dari seri 10 menit: langkah, kkal, meter (satuan jarak disamakan dengan distM). */
    fun hourly(series: JSONArray?, t0: Long): WatchHourly {
        val st = DoubleArray(24); val kc = DoubleArray(24); var ds = DoubleArray(24)
        var hasC = false; var hasD = false; var sd = 0.0; var ss = 0.0
        if (series != null) for (i in 0 until series.length()) {
            val p = series.optJSONObject(i) ?: continue
            val h = Math.floorDiv(p.ll("t") - t0, 3600L).toInt(); if (h < 0 || h > 23) continue
            st[h] += p.dd("steps"); ss += p.dd("steps")
            if (p.has0("cal")) { hasC = true; kc[h] += kcalF(p.dd("cal")) }
            if (p.has0("dist")) { hasD = true; ds[h] += p.dd("dist"); sd += p.dd("dist") }
        }
        val k = if (hasD && sd > 0) distM(sd, ss) / sd else 1.0
        ds = DoubleArray(24) { ds[it] * k }
        return WatchHourly(st, kc, ds, hasC && kc.any { it > 0 }, hasD && sd > 0)
    }

    /** Satu malam per hari (tanggal bangun) untuk sumbu 7 hari. */
    fun nightsWeek(nights: List<HuaweiSleepParity.Night>, wk: List<WatchDay>): List<NightBar> {
        val map = nights.associateBy { it.date }
        return wk.map { d ->
            val n = map[d.d] ?: return@map NightBar(d.l, d.now)
            val st = mutableListOf<Pair<String, Int>>()
            if (n.hasStages) { st += "deep" to n.deep; st += "rem" to n.rem; st += "light" to (n.light + n.unknown) } else st += "light" to n.sleepMinutes
            if (n.extraMinutes > 0) st += "extra" to n.extraMinutes
            NightBar(d.l, d.now, d.d, n.sleepMinutes + n.extraMinutes, n.awake, st, n.bed, n.wake, n.wakes, n.extras, n.latencyMin, n.awakeCount)
        }
    }

    /** Ringkasan satu malam: durasi, persentase fase, efisiensi. */
    fun sleepSummary(n: HuaweiSleepParity.Night?): SleepSummary? {
        if (n == null) return null
        val main = n.sleepMinutes; val asleep = main + n.extraMinutes; val tot = main + n.awake
        val st = mutableListOf<SleepStage>()
        if (n.hasStages) {
            st += SleepStage("deep", "Dalam", n.deep); st += SleepStage("rem", "REM", n.rem); st += SleepStage("light", "Ringan", n.light + n.unknown)
            if (n.awake > 0) st += SleepStage("awake", "Terjaga", n.awake)
        }
        return SleepSummary(
            date = n.date, bed = n.bed, wake = n.wake, asleep = asleep,
            eff = if (tot > 0) r(main.toDouble() / tot * 100).toInt() else null,
            stages = st, tot = max(1, st.sumOf { it.min }), wakes = n.wakes, wakeN = n.awakeCount, wakeMin = n.awakeMinutes,
            extras = n.extras, extraMin = n.extraMinutes, lat = n.latencyMin, start = n.start, end = n.end, blocks = n.blocks,
        )
    }

    // ---- baterai ----

    const val BAT_KEEP = 60L * 86400; private const val BAT_NEAR = 5400L; private const val BAT_AP = 1200L

    /** Tambah cuplikan baterai ke log (padanan hwBatAdd). */
    fun batAdd(log: List<BatPoint>, p: Int, t: Long): List<BatPoint> {
        if (p !in 0..100 || t <= 0) return log
        val last = log.lastOrNull()
        if (last != null && t < last.t) return log
        if (last != null && last.p == p && t - last.t < 600) return log
        val cut = t - BAT_KEEP
        val out = (log + BatPoint(t, p)).dropWhile { it.t < cut }
        return if (out.size > 3000) out.takeLast(3000) else out
    }

    /**
     * Estimasi baterai habis. liveH = dari laju turun cuplikan terbaru (1 jam terakhir, atau 6 jam bila kurang), dihitung sejak cuplikan naik
     * terakhir. runH = bila dipakai lari, dari rata-rata laju per jam sesi sebelumnya (runPh).
     */
    fun batEst(log: List<BatPoint>, now: Long, level: Int?, runPh: Double): BatEst {
        val empty = BatEst(null, null, null, false, "")
        if (level == null || level <= 0) return empty
        val n = log.size
        if (n >= 2 && log[n - 1].p > log[n - 2].p && now - log[n - 1].t <= 1800) return BatEst(null, null, null, true, "Sedang mengisi")
        var liveH: Double? = null; var endTs: Long? = null
        for (w in longArrayOf(3600L, 6L * 3600L)) {
            if (liveH != null) break
            var pts = log.filter { it.t >= now - w && it.t <= now + 60 }
            var from = 0
            for (i in 1 until pts.size) if (pts[i].p > pts[i - 1].p) from = i
            pts = pts.drop(from); if (pts.size < 2) continue
            val span = pts.last().t - pts.first().t; val drop = pts.first().p - pts.last().p
            if (span >= 900 && drop >= 1) {
                liveH = min(99.0, level / (drop / (span / 3600.0))); endTs = now + (liveH * 3600).toLong()
            }
        }
        val runH = if (runPh > 0) min(99.0, level / runPh) else null
        return BatEst(liveH, endTs, runH, false, "")
    }

    fun batTxt(e: BatEst, tzMin: Int): String {
        if (e.charging) return "Sedang mengisi"
        val h = e.liveH ?: return ""
        return "Habis ±" + clock(e.endTs ?: 0, tzMin) + " (" + dec(h, if (h < 10) 1 else 0) + " j lagi)"
    }

    /** Baterai terpakai selama satu sesi (detik awal/akhir). Null bila cuplikan tidak cukup atau jam diisi (padanan hwBatSession). */
    fun batSession(log: List<BatPoint>, start: Long, end: Long): BatSession? {
        if (end <= start) return null
        var b: BatPoint? = null; var a: BatPoint? = null
        for (x in log) if (x.t <= start && start - x.t <= BAT_NEAR) b = x
        if (b == null) b = log.firstOrNull { it.t > start && it.t <= start + 600 }
        a = log.firstOrNull { it.t >= end && it.t - end <= BAT_NEAR }
        if (a == null) a = log.lastOrNull { it.t < end && it.t >= end - 600 }
        if (b == null || a == null || a.t <= b.t) return null
        var prev: BatPoint? = null; var ok = true
        for (x in log) { if (x.t < b.t || x.t > a.t) continue; if (prev != null && x.p - prev.p >= 2) ok = false; prev = x }
        if (!ok) return null
        var used = b.p - a.p
        if (used < 0) { if (used < -1) return null; used = 0 }
        val hrs = (end - start) / 3600.0
        if (used == 0 && hrs >= 0.5) return null
        val ph = if (hrs >= 1.0 / 6 && used >= 1) r(used / hrs * 10) / 10 else null
        val ap = start - b.t > BAT_AP || b.t > start || a.t - end > BAT_AP || a.t < end
        return BatSession(b.p, a.p, used, ph, ap)
    }

    /** Baterai 0% pada sesi >= 30 menit tidak masuk akal: dua bacaan yang sama, jadi tidak ditampilkan (hwBatOk). */
    fun batOk(b: BatSession?, minutes: Double): Boolean = b != null && b.used >= 0 && !(b.used == 0 && minutes >= 30)

    // ---- model ----

    /** Rakit model tampilan dari hasil pembacaan mentah (padanan jamModel). */
    fun model(raw: WatchRaw, nowSec: Long, tzMin: Int, hrMaxEst: Int?): WatchModel {
        val st = raw.status; val lv = raw.live; val td = lv.optJSONObject("today"); val la = lv.optJSONObject("latest")
        val daysArr = raw.daily.optJSONArray("days"); val days = daysMap(daysArr)
        val state = st.ss("state") ?: "disconnected"
        val conn = state == "connected" || state == "syncing"
        val battery = if (st.has0("battery") && st.dd("battery") >= 0) r(st.dd("battery")).toInt() else null
        val dev = st.optJSONObject("device")
        val device = listOfNotNull(dev.ss("name"), dev.ss("model")).distinct().joinToString(" · ")
        val devName = raw.alias.ifBlank { devName(dev) }

        // Sesi lari terakhir yang punya data baterai -> laju per jam (padanan jamBatRunPh, dibaca dari log baterai).
        val sessions = raw.workouts.filter { it.duration > 0 }.take(8)
            .mapNotNull { w -> batSession(raw.batLog, w.start, w.start + w.duration)?.takeIf { batOk(it, w.duration / 60.0) }?.let { w.start to it } }
        val phs = sessions.mapNotNull { (_, b) -> b.ph?.takeIf { it > 0 && !b.ap } }
        val runPh = if (phs.isEmpty()) 0.0 else phs.sum() / phs.size
        val be0 = batEst(raw.batLog, nowSec, battery, runPh)
        val be = be0.copy(txt = batTxt(be0, tzMin))

        val lastTs = la.ll("sampleTs").takeIf { it > 0 } ?: td.ll("lastTs").takeIf { it > 0 }
        val ready = lastTs != null || days.isNotEmpty()
        val today = localDate(nowSec, tzMin)
        val tt = lv.optJSONObject("totals")
        val tdy = days[today]

        // Ambil yang terbesar dari tiga sumber supaya ubin sama dengan grafik 7 hari dan tidak pernah mundur.
        val steps = max(max(tt.dd("steps"), td.dd("steps")), tdy.dd("steps"))
        val d1 = if (tt.dd("distance") > 0) distM(tt.dd("distance"), tt.dd("steps")) else 0.0
        val d2 = if (td.dd("distance") > 0) distM(td.dd("distance"), td.dd("steps")) else 0.0
        val d3 = if (tdy.dd("distance") > 0) distM(tdy.dd("distance"), tdy.dd("steps")) else 0.0
        var dist = max(max(d1, d2), d3); var distEst = false
        if (!(dist > 0) && steps > 0) { dist = r(steps * 0.75); distEst = true }
        val kcalV = max(max(tt.dd("calories"), kcalF(td.dd("calories"))), if (tdy != null) kcalF(tdy.dd("calories")) else 0.0)

        // HR istirahat: nilai terbaru dalam 7 hari terakhir.
        var rhr = 0; var rhrDay: String? = null
        if (daysArr != null) for (i in daysArr.length() - 1 downTo 0) {
            val o = daysArr.optJSONObject(i); val rv = rhrOf(o)
            if (rv > 0) { rhr = rv; rhrDay = o.ss("day"); break }
        }
        // Tidur semalam: malam terakhir bila bangunnya dalam 36 jam.
        val lastNight = raw.nights.lastOrNull()?.takeIf { nowSec - it.end <= 36 * 3600 }
        var sl = sleepSummary(lastNight)
        val hrNow = la.ii("hr").takeIf { it > 0 }
        val hrAge = if (hrNow != null) nowSec - la.ll("hrTs") else 0L
        val fresh = hrNow != null && hrAge <= 900
        val spo2 = la.ii("spo2")

        val tiles = listOf(
            WatchTile("steps", "Langkah", num(steps),
                "dari " + num(GOAL.toDouble()) + (if (tt.ll("updatedAt") > 0) " · sinkron " + ago(nowSec, tt.ll("updatedAt")) else ""),
                bar = min(100, r(steps / GOAL * 100).toInt())),
            WatchTile("hr", if (fresh) "Detak jantung" else "HR terakhir", if (hrNow != null) "$hrNow bpm" else "–",
                if (hrNow != null) ago(nowSec, la.ll("hrTs")) else "belum ada data", live = fresh),
            WatchTile("rhr", "HR istirahat", if (rhr > 0) "$rhr bpm" else "–",
                if (rhr > 0) (if (rhrDay == today) "hari ini" else (rhrDay ?: "")) else "belum ada data"),
            WatchTile("kcal", "Kalori", if (ready) kcalTxt(kcalV) else "–", "hari ini"),
            WatchTile("dist", "Jarak", if (dist > 0) dec(dist / 1000, 2) + " km" else (if (ready) "0 km" else "–"),
                if (distEst) "hari ini · perkiraan dari langkah" else "hari ini"),
            WatchTile("spo2", "SpO₂", if (spo2 > 0) "$spo2%" else "–",
                if (spo2 > 0) (if (td.ii("spo2N") > 1) "rata-rata ${r(td.dd("spo2Avg")).toInt()}% · min ${td.ii("spo2Min")}%" else ago(nowSec, la.ll("spo2Ts"))) else "belum dikirim jam"),
            WatchTile("sleep", "Tidur semalam", if (sl != null) hm(sl.asleep) else "–",
                if (sl != null) sl.bed + "–" + sl.wake + (if (raw.sleepHr > 0 && lastNight != null) " · HR " + r(raw.sleepHr).toInt() else "") else "belum ada data"),
            WatchTile("bat", "Baterai jam", if (battery != null) "$battery%" else "–", be.txt.ifEmpty { device }, bar = battery, low = battery != null && battery <= 20),
        )

        val t0 = nowSec - Math.floorMod(nowSec + tzMin * 60L, 86400L)
        val hrToday = if (td.ii("hrN") >= 2) {
            val ser = lv.optJSONArray("series"); val pts = ArrayList<WatchHrPoint>()
            if (ser != null) for (i in 0 until ser.length()) {
                val p = ser.optJSONObject(i) ?: continue
                if (p.dd("hr") > 0) pts += WatchHrPoint(p.ll("t"), p.dd("hr"), p.dd("hrMin"), p.dd("hrMax"))
            }
            WatchHrToday(td.ii("hrMin"), r(td.dd("hrAvg")).toInt(), td.ii("hrMax"), pts, t0, nowSec)
        } else null

        val cur = WatchCur(
            steps = steps, kcal = kcalV, dist = dist, rhr = rhr, spo2 = max(0, spo2),
            spo2Avg = if (td.ii("spo2N") > 0) td.dd("spo2Avg") else 0.0, spo2Min = if (td.ii("spo2N") > 0) td.ii("spo2Min") else 0,
            spo2Max = if (td.ii("spo2N") > 0) td.ii("spo2Max") else 0, spo2N = td.ii("spo2N"),
            hr = if (td.ii("hrN") >= 2) WatchHr(td.ii("hrMin"), r(td.dd("hrAvg")).toInt(), td.ii("hrMax")) else null,
        )
        val wk = weekDetail(daysArr, today, 7, cur)
        val series = lv.optJSONArray("series")
        val spo2s = ArrayList<WatchSpo2Point>()
        if (series != null) for (i in 0 until series.length()) {
            val p = series.optJSONObject(i) ?: continue
            if (p.dd("spo2") > 0) spo2s += WatchSpo2Point(p.ll("t") + BUCKET / 2, p.dd("spo2"), if (p.dd("spo2Min") > 0) p.dd("spo2Min") else p.dd("spo2"))
        }
        // Skor tidur, SpO2 dan laju napas dari ringkasan "Sleep health" jam: skor yang berakhir paling dekat dengan malam ini (<= 3 jam).
        if (sl != null && sl.end > 0) {
            val sc = raw.daily.optJSONArray("sleepScores"); var bestD = Long.MAX_VALUE; var bs: JSONObject? = null
            if (sc != null) for (i in 0 until sc.length()) {
                val c = sc.optJSONObject(i) ?: continue; val dd = abs(c.ll("end") - sl.end)
                if (dd <= 3 * 3600 && dd < bestD) { bestD = dd; bs = c }
            }
            if (bs != null && bs.ii("score") > 0) {
                val sp = bs.ii("avgSpo2"); val rr = bs.ii("avgResp")
                sl = sl.copy(score = bs.ii("score"), spo2 = if (sp in 50..100) sp else 0, resp = if (rr in 4..60) rr else 0)
            }
        }
        // Pemulihan: sisa recoveryHours latihan terakhir yang punya data.
        val rw = raw.workouts.filter { it.recoveryHours > 0 && it.duration > 0 }.maxByOrNull { it.start }
        val recH = if (rw != null) max(0.0, rw.recoveryHours - (nowSec - (rw.start + rw.duration)) / 3600.0) else 0.0
        val workouts = raw.workouts.filter { it.duration > 0 }.sortedByDescending { it.start }

        // Diagnostik: bandingkan dengan layar jam.
        val napsTxt = raw.naps.map { d -> d.date + " siang " + d.list.joinToString(", ") { x -> x.a + "–" + x.b } + " · " + hm(d.minutes) }
        val sessTxt = raw.nights.map { n -> n.date + " " + n.bed + "–" + n.wake + " · " + hm(n.sleepMinutes) + (if (n.awakeCount > 0) " · ${n.awakeCount}× terbangun" else "") } + napsTxt
        val scoreTxt = ArrayList<String>().also { out ->
            val sc = raw.daily.optJSONArray("sleepScores")
            if (sc != null) for (i in 0 until sc.length()) { val s = sc.optJSONObject(i) ?: continue
                out += localDate(s.ll("end"), tzMin) + " " + clock(s.ll("start"), tzMin) + "–" + clock(s.ll("end"), tzMin) + " · skor " + s.ii("score") }
        }
        val frame = st.ss("frameStats")
        val dbg = listOf(
            "Langkah: sampel ${num(td.dd("steps"))} / total jam " + (if (tt == null) "belum ada (sinkron dulu)" else num(tt.dd("steps")) + (if (tt.ll("updatedAt") > 0) " (" + ago(nowSec, tt.ll("updatedAt")) + ")" else "")),
            "Langkah: baris harian (sama dengan batang 7 hari) " + (if (tdy == null) "–" else num(tdy.dd("steps"))),
            "Kalori: sampel ${dec(kcalF(td.dd("calories")), 1)} / total jam " + (if (tt == null) "–" else num(tt.dd("calories"))) + " kkal",
            "Jarak: sampel ${num(td.dd("distance"))} / total jam " + (if (tt == null) "–" else num(tt.dd("distance"))) + " m",
            "HR istirahat hari ini: " + (if (tdy != null && tdy.ii("rhrN") > 0) "${tdy.ii("rhrN")} sampel · terakhir ${tdy.ii("rhrLast")} · min ${tdy.ii("rhrMin")} · rata-rata ${r(tdy.dd("rhrAvg")).toInt()}" else "–"),
            "Sampel SpO₂ hari ini: ${td.ii("spo2N")}",
            "Isi bingkai jam: " + (frame ?: "–"),
            "Sampel HR hari ini: ${td.ii("hrN")} · sampel terakhir " + (if (lastTs != null) ago(nowSec, lastTs) else "–"),
            "Sesi tidur terbaca: " + (if (sessTxt.isEmpty()) "–" else sessTxt.joinToString(" | ")),
            "Skor tidur dari jam: " + (if (scoreTxt.isEmpty()) "–" else scoreTxt.joinToString(" | ")),
        )

        return WatchModel(
            ready = ready, conn = conn, state = state, battery = battery, device = device, devName = devName,
            tiles = tiles, hr = hrToday, sleep = sl, cur = cur, wk = wk, hourly = hourly(series, t0), spo2s = spo2s,
            nights7 = nightsWeek(raw.nights, wk), naps = raw.naps.takeLast(8), workouts = workouts,
            batEst = be, batSessions = sessions, recH = recH, keepAlive = st.optBoolean("keepAlive", false),
            lastSyncAt = st.ll("lastSyncAt").takeIf { it > 0 }, syncErr = st.ss("lastSyncError"), linkErr = st.ss("error"),
            lastTs = lastTs, now = nowSec, tzMin = tzMin, t0 = t0, hrMax = if (hrMaxEst != null && hrMaxEst > 0) hrMaxEst else 190,
            debug = WatchDockDebug(dbg),
        )
    }

    // ---- indikator sinkron ----

    enum class SyncState { OK, WARN, SYNC, OFF }

    /** ok (hijau, <15 mnt), warn (kuning, lebih lama), sync (biru, berjalan), off (merah, terputus atau galat). */
    fun syncState(m: WatchModel, busy: Boolean, lastSyncJsSec: Long): SyncState {
        if (busy) return SyncState.SYNC
        if (!m.conn || m.syncErr != null || m.linkErr != null) return SyncState.OFF
        val ts = max(m.lastSyncAt ?: 0L, lastSyncJsSec)
        return if (ts > 0 && m.now - ts <= 900) SyncState.OK else SyncState.WARN
    }

    // ---- hipnogram ----

    fun hypLabels(s: SleepSummary?): Map<String, String> {
        val o = mutableMapOf("awake" to "Terjaga", "rem" to "REM", "light" to "Ringan", "deep" to "Dalam", "unk" to "Ringan")
        s?.stages?.forEach { o[it.k] = it.label }
        return o
    }

    /** Blok di waktu t (detik). Di luar semua blok: blok terdekat. */
    fun hypInfo(bl: List<HuaweiSleepParity.Block>, t: Long, lb: Map<String, String>, tzMin: Int): HypInfo? {
        if (bl.isEmpty()) return null
        var hit = bl.size - 1; var best = Long.MAX_VALUE
        for (i in bl.indices) {
            if (t >= bl[i].s && t < bl[i].e) { hit = i; best = -1; break }
            val d = min(abs(t - bl[i].s), abs(t - bl[i].e)); if (d < best) { best = d; hit = i }
        }
        val b = bl[hit]; val k = if (lb.containsKey(b.k)) b.k else "light"; val mn = max(1, r((b.e - b.s) / 60.0).toInt())
        return HypInfo(hit, k, lb[k] ?: k, clock(b.s, tzMin), clock(b.e, tzMin), if (mn < 60) "$mn mnt" else hm(mn))
    }

    /** Posisi awal slider (0..1000): di blok terjaga terakhir bila ada, selain itu tengah malam. */
    fun hypDefault(s: SleepSummary): Int {
        val bl = s.blocks
        for (i in bl.indices.reversed()) if (bl[i].k == "awake") return r(((bl[i].s + bl[i].e) / 2.0 - s.start) / (s.end - s.start) * 1000).toInt().coerceIn(0, 1000)
        return 500
    }

    // ---- latihan ----

    fun isBike(w: WatchWorkout) = w.sportType == 3
    fun xKind(w: WatchWorkout): String? = when (w.sportType) { 4, 14 -> "hike"; 6, 8 -> "swim"; else -> null }

    fun paceCell(w: WatchWorkout): PaceCell {
        if (!(w.distance > 0 && w.duration > 0)) return PaceCell("–", "pace")
        if (w.sportType == 3) return PaceCell(dec(w.distance / 1000.0 / (w.duration / 3600.0), 1), "km/j")
        if (xKind(w) == "swim") return PaceCell(paceStr(w.duration / 60.0 / (w.distance / 100.0)), "/100 m")
        val p = paceStr(w.duration / 60.0 / (w.distance / 1000.0))
        return PaceCell(p, "/km")
    }

    /** Latihan hanya bisa disimpan/dibuka bila punya jarak dan durasi dan sudah lengkap. */
    fun savable(w: WatchWorkout): Boolean = w.start > 0 && w.duration > 0 && w.distance > 0 && w.complete

    /** Baca daftar latihan dari JSON plugin. */
    fun parseWorkouts(arr: JSONArray?): List<WatchWorkout> {
        val out = ArrayList<WatchWorkout>()
        if (arr != null) for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out += WatchWorkout(
                start = o.ll("start"), end = o.ll("end"), sportType = o.ii("sportType"), sportName = o.optString("sportName", ""),
                duration = o.ii("duration"), distance = o.ii("distance"), calories = o.ii("calories"),
                avgHr = o.ii("avgHr"), maxHr = o.ii("maxHr"), complete = o.optBoolean("complete", true),
                recoveryHours = o.dd("recoveryHours"), gpsPoints = o.ii("gpsPoints"),
            )
        }
        return out
    }

    // ---- cuaca untuk watchface mock-up ----

    /** Jenis ikon cuaca dari kode WMO: sun, cloud, atau rain. */
    fun wxKind(c: Int): String = if (c in 51..67 || c in 80..99) "rain" else if (c == 0 || c == 1) "sun" else "cloud"

    /** Potongan prakiraan dari snapshot cuaca aplikasi (suhu jam ini, 3 jam berikutnya, tertinggi/terendah, terbenam); null bila basi atau kosong. */
    fun wxPick(s: WxSnapshot?, nowSec: Long, tzMin: Int): WatchWx? {
        if (s == null || s.hours.isEmpty()) return null
        val day = localDate(nowSec, tzMin); val nl = day + "T" + clock(nowSec, tzMin)
        var cur = -1; val nx = ArrayList<Int>()
        for (i in s.hours.indices) { if (s.hours[i].time <= nl) cur = i else if (nx.size < 3) nx += i }
        if (cur < 0 || !s.hours[cur].time.startsWith(day) || nx.isEmpty()) return null
        val d = s.days.firstOrNull { it.date == day }
        val sun = if (s.days.firstOrNull()?.date == day) (s.sunset?.takeIf { it.length >= 16 }?.substring(11, 16) ?: "") else ""
        return WatchWx(
            t = r(s.hours[cur].temp).toInt(), hi = d?.let { r(it.hi).toInt() }, lo = d?.let { r(it.lo).toInt() }, sun = sun,
            hours = nx.map { WatchWxHour(s.hours[it].time.substring(11, 16), r(s.hours[it].temp).toInt(), wxKind(s.hours[it].code)) },
        )
    }

    /** Tanggal dan jam seperti di watchface: "SUN 10/25" dan "09:54:55" menurut zona waktu jam. */
    fun faceClock(ts: Long, tzMin: Int): Pair<String, String> {
        val lm = (((Math.floorDiv(ts, 60L) + tzMin) % 1440 + 1440) % 1440).toInt(); val s = (((ts % 60) + 60) % 60).toInt()
        val iso = localDate(ts, tzMin); val d = LocalDate.parse(iso)
        val dw = listOf("MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN")[d.dayOfWeek.value - 1]
        return (pad(lm / 60) + ":" + pad(lm % 60) + ":" + pad(s)) to (dw + " " + iso.substring(5, 7) + "/" + iso.substring(8, 10))
    }

    // ---- skala grafik ----

    /** Angka "bulat" berikutnya untuk puncak sumbu (jamNice). */
    fun nice(v: Double): Double {
        if (!(v > 0)) return 1.0
        val p = 10.0.pow(floor(Math.log10(v))); val f = v / p
        return (if (f <= 1) 1.0 else if (f <= 2) 2.0 else if (f <= 2.5) 2.5 else if (f <= 5) 5.0 else 10.0) * p
    }

    fun kShort(v: Double): String = if (v >= 1000) dec(v / 1000, 1) + "k" else r(v).toInt().toString()
    fun kmShort(v: Double): String = dec(v, if (v < 10) 1 else 0)

    fun avgOf(list: List<WatchDay>, sel: (WatchDay) -> Double): Double = if (list.isEmpty()) 0.0 else list.sumOf(sel) / list.size
    fun maxOf(list: List<WatchDay>, sel: (WatchDay) -> Double): WatchDay? = list.fold(null as WatchDay?) { b, d -> if (b == null || sel(d) > sel(b)) d else b }
    fun minOf(list: List<WatchDay>, sel: (WatchDay) -> Double): WatchDay? = list.fold(null as WatchDay?) { b, d -> if (b == null || sel(d) < sel(b)) d else b }

    /** Sumbu y grafik rentang: (lo, hi) dibulatkan ke kelipatan step dengan lebar minimal span (jamRangeSvg). */
    fun rangeAxis(lo0: Double, hi0: Double, step: Double, padV: Double, span: Double, cap: Double?): Pair<Double, Double> {
        var lo = floor((lo0 - padV) / step) * step; var hi = ceil((hi0 + padV) / step) * step
        val sp = max(span, ceil((hi - lo) / (2 * step)) * 2 * step)
        if (cap != null) { hi = min(cap, lo + sp); lo = hi - sp } else hi = lo + sp
        return lo to hi
    }

    /** Sumbu y grafik garis (jamLineSvg). */
    fun lineAxis(lo0: Double, hi0: Double, step: Double, span: Double): Pair<Double, Double> {
        val lo = floor((lo0 - 2) / step) * step; var hi = ceil((hi0 + 2) / step) * step
        hi = lo + max(span, ceil((hi - lo) / (2 * step)) * 2 * step)
        return lo to hi
    }

    /** Sumbu y grafik HR hari ini (jamHrPath): batas 10-an dengan lebar minimal 40. */
    fun hrAxis(minV: Int, maxV: Int): Pair<Int, Int> {
        val lo = floor((minV - 5) / 10.0).toInt() * 10; var hi = ceil((maxV + 5) / 10.0).toInt() * 10
        if (hi - lo < 40) hi = lo + 40
        return lo to hi
    }
}
