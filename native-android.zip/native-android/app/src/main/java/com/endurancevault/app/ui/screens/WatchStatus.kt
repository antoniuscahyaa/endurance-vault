package com.endurancevault.app.ui.screens

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Watch
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.endurancevault.app.data.WatchDockUi
import com.endurancevault.app.domain.WatchDock

/**
 * Ringkasan status jam untuk tempat-tempat di luar tab Jam: kartu di Pengaturan dan pil di bawah nama pada header.
 * [state] null = belum diketahui (abu-abu). [conn] true = jam sedang terhubung, jadi ketukan titik langsung menyinkron.
 */
internal data class WatchBadge(
    val title: String,
    val summary: String,
    val battery: Int?,
    val state: WatchDock.SyncState?,
    val conn: Boolean,
)

internal fun watchBadgeOf(ui: WatchDockUi, syncing: Boolean, lastSyncJsSec: Long, alias: String): WatchBadge? = when (ui) {
    is WatchDockUi.Unsupported -> null
    is WatchDockUi.Loading -> WatchBadge(alias.ifBlank { "Jam" }, "Membaca data jam…", null, null, false)
    is WatchDockUi.Failed -> WatchBadge(alias.ifBlank { "Jam" }, "Gagal membaca data jam", null, WatchDock.SyncState.OFF, false)
    is WatchDockUi.Ready -> {
        val m = ui.model
        val st = WatchDock.syncState(m, syncing, lastSyncJsSec)
        val link = when {
            st == WatchDock.SyncState.SYNC -> "Menyinkron…"
            m.conn -> "Terhubung"
            else -> "Terputus"
        }
        val bat = m.battery?.let { " · Baterai $it%" } ?: ""
        WatchBadge(alias.ifBlank { m.devName.ifBlank { "Jam Huawei" } }, link + bat, m.battery, st, m.conn)
    }
}

private fun dotColor(s: WatchDock.SyncState?): Color = when (s) {
    WatchDock.SyncState.OK -> Color(0xFF3FB67A)
    WatchDock.SyncState.WARN -> Color(0xFFE0A526)
    WatchDock.SyncState.SYNC -> Color(0xFF4F8CFF)
    WatchDock.SyncState.OFF -> Color(0xFFE5534B)
    null -> Color(0xFF9AA0A6)
}

private fun dotLabel(s: WatchDock.SyncState?): String = when (s) {
    WatchDock.SyncState.OK -> "Tersinkron"
    WatchDock.SyncState.WARN -> "Sinkron lama"
    WatchDock.SyncState.SYNC -> "Menyinkron"
    WatchDock.SyncState.OFF -> "Terputus"
    null -> "Status jam belum diketahui"
}

/** Lingkaran status; berkedip pelan selama sinkron berjalan. */
@Composable
private fun WatchDot(state: WatchDock.SyncState?, size: Dp, modifier: Modifier = Modifier) {
    val a = if (state == WatchDock.SyncState.SYNC) {
        rememberInfiniteTransition(label = "watchDot").animateFloat(
            initialValue = 0.35f, targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "watchDotAlpha",
        ).value
    } else 1f
    Box(modifier.size(size).alpha(a).clip(CircleShape).background(dotColor(state)))
}

/**
 * Kartu jam di Pengaturan, tepat di bawah kartu profil dengan bentuk dan lebar yang sama.
 * Ketuk kartu = buka halaman Jam; ketuk titik di pojok kanan atas = sinkron otomatis ([onDot]).
 */
@Composable
internal fun WatchSettingsCard(badge: WatchBadge, onOpen: () -> Unit, onDot: () -> Unit, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(16.dp)
    Box(modifier.fillMaxWidth().clip(shape).border(BorderStroke(0.8.dp, cs.outlineVariant), shape).clickable(onClick = onOpen)) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(
                Modifier.size(56.dp).clip(CircleShape).background(cs.surfaceVariant).border(1.dp, cs.outlineVariant, CircleShape),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Outlined.Watch, contentDescription = null, tint = cs.onSurfaceVariant, modifier = Modifier.size(28.dp)) }
            Column(Modifier.weight(1f).padding(end = 24.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    badge.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Text(
                    badge.summary, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                )
            }
        }
        Box(
            Modifier.align(Alignment.TopEnd).size(40.dp).clip(CircleShape).clickable(onClick = onDot)
                .semantics { contentDescription = "${dotLabel(badge.state)}. Ketuk untuk sinkron" },
            contentAlignment = Alignment.Center,
        ) { WatchDot(badge.state, 12.dp) }
    }
}

/** Pil kecil di samping pill Recovery: titik status sinkron + persen baterai. Ketuk = sinkron otomatis ([onClick]). */
@Composable
internal fun WatchHeaderPill(badge: WatchBadge, onClick: () -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Surface(
        shape = shape,
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.clip(shape).clickable(onClick = onClick)
            .semantics { contentDescription = "${dotLabel(badge.state)}, baterai jam ${badge.battery ?: "tidak diketahui"}" },
    ) {
        Row(
            Modifier.padding(horizontal = 11.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            WatchDot(badge.state, 8.dp)
            Text(
                badge.battery?.let { "$it%" } ?: "–",
                style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, maxLines = 1,
            )
        }
    }
}
