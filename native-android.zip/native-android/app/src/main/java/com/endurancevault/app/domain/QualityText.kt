package com.endurancevault.app.domain

import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/** Teks dan parameter sesi kualitas serta long run (padanan qDetail, roadQ, roadLong, qParse di web). */

internal fun qDetail(phase: String, i: Int, cut: Boolean, s: PlanSettings, road: Boolean): String {
    val hr = "HR easy ≤ ${s.hr}"
    val tb = thrBand(s) ?: listOf(164, 172)
    val tlo = tb[0] - 4; val thi = tb[1] - 2
    fun tmp(m: Int) = "Tempo $m mnt tanpa henti di HR $tlo–$thi (sedikit di bawah threshold)."
    if (phase == Phases.TAPER) return "Strides 4×20 dtk, sisanya easy."
    if (phase == Phases.BASE) {
        if (cut) return "Fartlek ringan 8×1 mnt kencang, 1 mnt easy. Sisanya easy, $hr."
        if (i % 2 == 0) {
            val bl = listOf("3×8", "3×8", "3×10", "4×8", "3×10", "4×8", "3×12")
            val tt = bl[min(i / 2, bl.size - 1)]
            return "Pemanasan easy 15 mnt, $tt mnt (HR ${s.thr}), jog 2 mnt antar set, pendinginan easy. " +
                "Bila HR easy naik atau kaki berat 2 hari berturut-turut, ganti dengan strides."
        }
        return (if (!road && (i / 2) % 2 != 0) "Tanjakan pendek 6×45 dtk, jalan turun. " else "Strides 6×20 dtk di akhir easy. ") +
            "Sisanya easy, $hr."
    }
    if (cut) return "Fartlek ringan 8×1 mnt kencang, 1 mnt easy. Pemanasan dan pendinginan easy."
    val th = "(HR ${s.thr}), jog 2 mnt antar set"
    if (phase == Phases.BUILD) {
        var l = listOf(
            "Threshold 3×10 mnt $th.",
            "Mendaki panjang 40 mnt: power hike di tanjakan curam, lari ringan di landai (rute jalan menanjak atau treadmill incline). Napas tetap terkendali.",
            "Threshold 4×10 mnt $th.",
            "Mendaki panjang 50 mnt: power hike di tanjakan curam, lari ringan di landai (rute jalan menanjak atau treadmill incline). Napas tetap terkendali.",
            "Threshold 3×15 mnt $th.",
            "Mendaki panjang 60 mnt: power hike di tanjakan curam, lari ringan di landai (rute jalan menanjak atau treadmill incline). Napas tetap terkendali.",
        )
        if (road) l = listOf("Threshold 3×10 mnt $th.", tmp(30), "Threshold 4×10 mnt $th.", tmp(40), "Threshold 3×15 mnt $th.", tmp(50))
        return l[i % l.size] + " Pemanasan dan pendinginan easy."
    }
    var p = listOf(
        "Tanjakan tempo 3×12 mnt naik, terkendali.", "Threshold 2×20 mnt $th.",
        "Mendaki panjang 60–75 mnt naik terus, power hike di jalan menanjak, tongkat bila ada.",
    )
    if (road) p = listOf("Threshold 3×12 mnt $th.", "Threshold 2×20 mnt $th.", tmp(60))
    return p[i % p.size] + " Pemanasan dan pendinginan easy."
}

/** qParse: isi qk/qMin/qBand dari teks detail (jalur trail). */
internal fun qParse(o: PDay, s: PlanSettings) {
    val t = o.detail
    Regex("(\\d+)×(\\d+) mnt \\(HR").find(t)?.let {
        o.qk = "thr"; o.qMin = (it.groupValues[1].toInt() * it.groupValues[2].toInt()).toDouble(); o.qBand = thrBand(s); return
    }
    Regex("Tempo (\\d+) mnt tanpa henti di HR (\\d+)–(\\d+)").find(t)?.let {
        o.qk = "thr"; o.qMin = it.groupValues[1].toDouble(); o.qBand = listOf(it.groupValues[2].toInt(), it.groupValues[3].toInt()); return
    }
    Regex("Mendaki panjang (\\d+)(?:–(\\d+))? mnt").find(t)?.let {
        o.qk = "hike"; o.qMin = (it.groupValues[2].ifEmpty { it.groupValues[1] }).toDouble(); return
    }
    Regex("Tanjakan tempo (\\d+)×(\\d+) mnt").find(t)?.let {
        o.qk = "hike"; o.qMin = (it.groupValues[1].toInt() * it.groupValues[2].toInt()).toDouble(); return
    }
    o.qk = "none"
}

internal class RoadQ(var title: String = "Sesi kualitas", var detail: String = "", var k: String = "none", var min: Double = 0.0, var band: List<Int>? = null)

internal fun roadQ(s: PlanSettings, rc: RC, phase: String, i: Int, cut: Boolean, q: Int): RoadQ {
    val t = s.rtype
    val rp = racePaces(s)
    val b = thrBand(s) ?: listOf(164, 172)
    val mx = hrMaxEst(s)
    val ep = Js.parsePaceStr(s.pace)
    val wu = " Pemanasan 15 mnt easy, pendinginan 10 mnt easy."
    val th = "(HR ${s.thr}), jog 2 mnt antar set"
    val rb = RBAND.getValue(t)
    val rband = listOf(Js.roundI(rb[0] * mx), Js.roundI(rb[1] * mx))
    val w5 = rp?.p5 ?: (ep * .78); val w10 = rp?.p10 ?: (ep * .82)
    val wh = rp?.phm ?: (ep * .86); val wm = rp?.pfm ?: (ep * .9)
    val o = RoadQ()

    fun thr(reps: Int, m: Int) {
        o.k = "thr"; o.min = (reps * m).toDouble(); o.band = b; o.title = "Threshold"
        o.detail = "Threshold $reps×$m mnt $th." + (if (rp != null) " Pace sekitar ${Js.paceStr(rp.thr)}/km." else "") + wu
    }
    fun tempo(m: Int) {
        val lo = b[0] - 4; val hi = b[1] - 2
        o.k = "thr"; o.min = m.toDouble(); o.band = listOf(lo, hi); o.title = "Tempo"
        o.detail = "Tempo $m mnt tanpa henti di HR $lo–$hi (sedikit di bawah threshold)." +
            (if (rp != null) " Pace sekitar ${Js.paceStr((rp.thr + wh) / 2)}/km." else "") + wu
    }
    fun vo2(txt: String, reps: Int, work: Double) {
        o.k = "vo2"; o.min = Js.round(reps * work); o.band = listOf(Js.roundI(.9 * mx), 999); o.title = "Interval VO2max"
        o.detail = "$txt, jog 2–3 mnt antar repetisi." +
            (if (rp != null) " Pace sekitar ${Js.paceStr(rp.p5)}/km (usaha 3K–5K)." else " Usaha keras tapi terkendali (8–9 dari 10).") +
            " HR baru naik di repetisi ke-2 dan seterusnya, itu normal." + wu
    }
    fun rps(txt: String, reps: Int, work: Double, p: Double?) {
        o.k = "rp"; o.min = Js.round(reps * work); o.band = rband; o.title = "Pace lomba ${rc.nm}"
        o.detail = txt + (if (rp != null && p != null && p != 0.0) " Pace sekitar ${Js.paceStr(p)}/km." else " Usaha sesuai target lomba.") +
            " Jog 2–3 mnt antar repetisi." + wu
    }

    if (phase == Phases.TAPER) {
        o.title = "Easy + strides"; o.detail = "Easy dengan strides 4×20 dtk."
        if (t == "hm" || t == "fm") {
            o.title = "Tempo ringan"; o.k = "rp"; o.min = 12.0; o.band = rband
            o.detail = "2×6 mnt di pace lomba (usaha terkendali), jog 3 mnt antar set.$wu"
        }
        return o
    }
    if (cut) { o.title = "Fartlek ringan"; o.detail = "Fartlek 8×1 mnt kencang, 1 mnt easy.$wu"; return o }
    val sb = if (t == "pb") pbLen(s) else Js.roundI((q - 3) * 0.4)
    var k = max(0, i - sb)
    if (phase == Phases.BASE) {
        if (i % 2 == 0) {
            val bl = listOf(3 to 8, 3 to 8, 3 to 10, 4 to 8, 3 to 10, 4 to 8, 3 to 12)
            val bb = bl[min(i / 2, bl.size - 1)]
            thr(bb.first, bb.second); o.title = "Threshold ringan"
            o.detail += " Bila HR easy naik atau kaki berat 2 hari berturut-turut, ganti dengan strides."
        } else {
            o.title = "Strides dan tanjakan pendek"
            o.detail = "Easy, lalu tanjakan pendek 6×10 dtk sprint (jalan turun), kemudian strides 6×20 dtk. Sisanya easy, HR ≤ ${s.hr}."
        }
        return o
    }
    if (phase == Phases.BUILD) {
        val l: List<() -> Unit>
        when (t) {
            "5k" -> l = listOf({ vo2("5×3 mnt di usaha 3K–5K", 5, 3.0) }, { thr(3, 10) }, { vo2("6×800 m di usaha 3K–5K", 6, .8 * w5) },
                { thr(2, 15) }, { vo2("4×1000 m di usaha 3K–5K", 4, w5) }, { thr(3, 12) })
            "10k" -> l = listOf({ vo2("5×4 mnt di usaha 3K–5K", 5, 4.0) }, { thr(3, 10) }, { vo2("6×1000 m di usaha 3K–5K", 6, w5) },
                { thr(2, 15) }, { vo2("4×5 mnt di usaha 3K–5K", 4, 5.0) }, { thr(4, 10) })
            "hm" -> l = listOf({ thr(3, 12) }, { thr(4, 10) }, { vo2("5×3 mnt di usaha 5K", 5, 3.0) },
                { thr(3, 15) }, { tempo(30) }, { vo2("6×3 mnt di usaha 5K", 6, 3.0) })
            "pb" -> {
                val pf = pbFocusOf(s); val pl = pbLen(s)
                l = when (pf) {
                    "thr" -> listOf({ thr(3, 12) }, { tempo(30) }, { thr(4, 10) }, { tempo(40) }, { thr(3, 15) }, { tempo(45) })
                    "vo2" -> listOf({ vo2("5×3 mnt di usaha 3K–5K", 5, 3.0) }, { vo2("6×800 m di usaha 3K–5K", 6, .8 * w5) },
                        { vo2("5×4 mnt di usaha 3K–5K", 5, 4.0) }, { vo2("4×1000 m di usaha 3K–5K", 4, w5) },
                        { vo2("6×3 mnt di usaha 3K–5K", 6, 3.0) }, { vo2("5×1000 m di usaha 3K–5K", 5, w5) })
                    "vol" -> listOf({ tempo(20) }, { thr(2, 10) }, { tempo(25) }, { thr(3, 8) }, { tempo(30) }, { thr(2, 12) })
                    else -> listOf({ thr(3, 12) }, { vo2("5×3 mnt di usaha 3K–5K", 5, 3.0) }, { tempo(30) }, { thr(4, 10) },
                        { vo2("5×4 mnt di usaha 3K–5K", 5, 4.0) }, { tempo(40) })
                }
                if (pf != "mix") k = max(0, i - i / pl - (pl - 1))
            }
            else -> l = listOf({ thr(3, 12) }, { tempo(40) }, { thr(4, 10) }, { tempo(50) }, { thr(3, 15) }, { tempo(60) })
        }
        l[k % l.size](); return o
    }
    val lp: List<() -> Unit> = when (t) {
        "5k" -> listOf({ rps("6×800 m di pace 5K", 6, .8 * w5, rp?.p5) }, { thr(2, 15) }, { rps("5×1000 m di pace 5K", 5, w5, rp?.p5) })
        "10k" -> listOf({ rps("4×1,6 km di pace 10K", 4, 1.6 * w10, rp?.p10) }, { thr(2, 15) }, { rps("3×2 km di pace 10K", 3, 2 * w10, rp?.p10) })
        "hm" -> listOf({ rps("2×20 mnt di pace half marathon", 2, 20.0, rp?.phm) }, { rps("3×3 km di pace half marathon", 3, 3 * wh, rp?.phm) }, { thr(3, 12) })
        else -> listOf({ rps("2×6 km di pace maraton", 2, 6 * wm, rp?.pfm) }, { rps("3×5 km di pace maraton", 3, 5 * wm, rp?.pfm) }, { tempo(40) })
    }
    lp[max(0, i - (q - 3)) % lp.size](); return o
}

internal fun roadLong(s: PlanSettings, rc: RC, phase: String, i: Int, q: Int, kmr: Int, o: PDay): String {
    val t = s.rtype
    val rp = racePaces(s); val mx = hrMaxEst(s); val ep = Js.parsePaceStr(s.pace)
    val rb0 = RBAND.getValue(t)
    val rb = listOf(Js.roundI(rb0[0] * mx), Js.roundI(rb0[1] * mx))
    val txt = "HR ≤ ${s.hr}. Di jalan datar, jangan kejar pace."
    if (phase == Phases.TAPER) return "HR ≤ ${s.hr}. Lebih pendek dan santai."
    if (phase == Phases.BASE) return txt
    if (t == "pb") {
        if (pbFocusOf(s) == "vol" && phase == Phases.BUILD && i % 2 == 1)
            return "$txt Di 20 mnt terakhir naikkan ke usaha steady (napas lebih berat tapi masih teratur), lalu tutup dengan strides 4×20 dtk."
        return txt + (if (phase == Phases.BUILD && i % 2 == 0) " Pekan ini murni easy." else " Tutup dengan strides 4×20 dtk.")
    }
    if (t == "5k" || t == "10k") return "$txt Tutup dengan strides 4×20 dtk."
    if (phase == Phases.BUILD && i % 2 == 0) return "$txt Pekan ini murni easy."
    val seg = if (t == "hm") min(8, Js.roundI(kmr * .3)) else min(14, Js.roundI(kmr * .4))
    val pr = if (t == "hm") (rp?.phm ?: (ep * .86)) else (rp?.pfm ?: (ep * .9))
    o.qk = "rp"; o.qMin = Js.round(seg * pr); o.qBand = rb
    return "Easy HR ≤ ${s.hr}, lalu $seg km terakhir di pace " + (if (t == "hm") "half marathon" else "maraton") +
        (if (rp != null) " (sekitar ${Js.paceStr(pr)}/km)" else " (usaha terkendali, napas teratur)") + ". " +
        (if (t == "fm") "Latih nutrisi lomba: sekitar 60 g karbohidrat per jam dan minum sesuai rencana." else "Latih nutrisi lomba.")
}

/* ===== Estimasi jarak sesi kualitas (qualEst / qualBalance) ===== */

private fun qeF(k: String) = when (k) { "thr" -> .82; "vo2" -> .78; else -> .86 }

internal fun qualEst(dd: PDay, ep: Double): QEst? {
    if (dd.kind != Kinds.QUALITY || dd.bench || !(ep > 0)) return null
    val qk = dd.qk
    if (qk != "thr" && qk != "vo2" && qk != "rp") return null
    val qeJog = 1.25
    val t = dd.detail
    fun num(x: String) = x.replace(',', '.').toDouble()
    val wu = Regex("[Pp]emanasan(?: easy)? (\\d+) mnt").find(t)?.groupValues?.get(1)?.toDouble() ?: 15.0
    val cd = Regex("pendinginan(?: easy)? (\\d+) mnt").find(t)?.groupValues?.get(1)?.toDouble() ?: 10.0
    val jog = Regex("jog (\\d+)(?:–\\d+)? mnt").find(t)?.groupValues?.get(1)?.toDouble() ?: 2.0
    val pm = Regex("Pace sekitar (\\d+):(\\d{2})/km").find(t)
    val wp = if (pm != null) pm.groupValues[1].toDouble() + pm.groupValues[2].toDouble() / 60 else ep * qeF(qk)
    val m = Regex("(\\d+)×([\\d.,]+) (mnt|m|km)\\b").find(t)
    val n: Double; val wmin: Double; val wkm: Double; val jm: Double
    if (m != null) {
        n = m.groupValues[1].toDouble(); val v = num(m.groupValues[2])
        when (m.groupValues[3]) {
            "mnt" -> { wmin = v; wkm = v / wp }
            "km" -> { wkm = v; wmin = v * wp }
            else -> { wkm = v / 1000; wmin = wkm * wp }
        }
        jm = jog
    } else {
        val tm = Regex("Tempo (\\d+) mnt").find(t) ?: return null
        n = 1.0; wmin = tm.groupValues[1].toDouble(); wkm = wmin / wp; jm = 0.0
    }
    val mins = wu + cd + n * (wmin + jm)
    val km = wu / ep + cd / ep + n * wkm + n * jm / (ep * qeJog)
    if (!(mins > 0) || !(km > 0)) return null
    return QEst(Js.roundI(mins), max(3, Js.roundI(km)), 0.0, ep, wp)
}

internal fun qualBalance(days: List<PDay>, s: PlanSettings, gm: Double, easyPace: Double? = null) {
    val ep = easyPace?.takeIf { it > 0 } ?: Js.parsePaceStr(s.pace)
    var sur = 0.0; var hit = 0
    days.forEach { d ->
        if (d.role != "quality") return@forEach
        val e = qualEst(d, ep) ?: return@forEach
        val old = d.km
        d.est = QEst(e.min, e.km, old, ep, e.wp); d.km = e.km.toDouble(); sur += old - e.km; hit++
        d.detail += " Estimasi jarak sekitar ${e.km} km dari total sekitar ${e.min} menit (pace easy ${Js.paceStr(ep)}/km, set utama ${Js.paceStr(e.wp)}/km). Selisih km dibagikan ke sesi easy dan medium."
    }
    if (hit == 0 || sur == 0.0) return
    val rec = days.filter { (it.role == "easy" || it.role == "medium") && !it.bench && it.altMins == null && it.km > 0 }
    if (rec.isEmpty()) return
    var tot = 0.0; rec.forEach { tot += it.km }
    val amt = kotlin.math.abs(sur); val up = sur > 0
    class Part(val d: PDay, val f: Int, val r: Double)
    val part = rec.map { d -> val x = amt * d.km / tot; Part(d, floor(x).toInt(), x - floor(x)) }
    var left = Js.roundI(amt) - part.sumOf { it.f }
    val fs = IntArray(part.size) { part[it].f }
    part.indices.sortedByDescending { part[it].r }.forEach { ix -> if (left > 0) { fs[ix]++; left-- } }
    part.forEachIndexed { ix, p ->
        val d = p.d; var a = fs[ix]
        if (a == 0) return@forEachIndexed
        if (up) d.km += a else {
            val fl = max(3, Js.roundI(d.km * .7)); a = min(a, max(0, (d.km - fl).toInt()))
            if (a == 0) return@forEachIndexed
            d.km -= a
        }
        d.xtra = if (up) a else -a
        val note = if (up) " Tambahan $a km dari selisih sesi kualitas." else " Dikurangi $a km karena sesi kualitas lebih panjang dari jatah."
        d.detail += note
        val mk = d.mk
        if (mk != null && !d.glock && gm > 0) mk(Js.r50(d.km * gm))
    }
}
