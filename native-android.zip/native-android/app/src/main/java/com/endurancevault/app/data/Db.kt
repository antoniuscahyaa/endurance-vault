package com.endurancevault.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "activity")
data class ActivityEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateIso: String,              // yyyy-MM-dd
    val km: Double,
    val durationSec: Int,
    val avgHr: Int? = null,
    val feel: Int? = null,            // rasa setelah lari 1..5
    val note: String = "",
    val srcKey: String = "",          // kunci di cadangan web ("2026-11-03" atau "2026-11-03~f1"); kosong = dicatat di aplikasi ini
    val name: String = "",
    val gain: Int? = null,            // D+ (m)
    val startTime: String? = null,    // HH:mm
    val maxHr: Int? = null,
    val type: String = "run",         // run | bike
    val gearId: String? = null,
    val detailFile: String? = null,   // nama berkas detail (rute, split, grafik) di ActStore
)

/** Catatan harian kondisi (tidur, HR istirahat, HRV, rasa kaki, mood). `raw` menyimpan objek web utuh agar tidak ada field yang hilang. */
@Entity(tableName = "daily")
data class DailyEntity(
    @PrimaryKey val dateIso: String,
    val rhr: Int? = null,
    val hrv: Int? = null,
    val leg: Int? = null,             // rasa kaki 1 (segar) sampai 5 (sangat berat)
    val mood: Int? = null,            // stres/mood 1 (santai) sampai 5 (stres berat)
    val sleepH: Double? = null,       // jam tidur
    val raw: String = "{}",
)

@Entity(tableName = "gear")
data class GearEntity(
    @PrimaryKey val id: String,
    val name: String,
    val model: String = "",
    val km0: Double = 0.0,            // jarak awal sebelum dicatat di aplikasi
    val limitKm: Double = 0.0,        // batas pakai (0 = tanpa batas)
    val retired: Boolean = false,
    val isDefault: Boolean = false,
)

/** Data pendamping dari cadangan web yang dipulihkan utuh sebagai JSON: done, mv, pr, fav, sp, sl, cs. */
@Entity(tableName = "kv")
data class KvEntity(@PrimaryKey val key: String, val json: String)

@Dao
abstract class CompanionDao {
    @Query("SELECT * FROM daily ORDER BY dateIso DESC")
    abstract fun observeDaily(): Flow<List<DailyEntity>>

    @Query("SELECT * FROM gear ORDER BY name")
    abstract fun observeGear(): Flow<List<GearEntity>>

    @Query("SELECT json FROM kv WHERE `key` = :key")
    abstract suspend fun kv(key: String): String?

    @Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE)
    abstract suspend fun putDaily(list: List<DailyEntity>)

    @Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE)
    abstract suspend fun putGear(list: List<GearEntity>)

    @Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE)
    abstract suspend fun putKv(list: List<KvEntity>)

    @Query("DELETE FROM daily") abstract suspend fun clearDaily()
    @Query("DELETE FROM gear") abstract suspend fun clearGear()
    @Query("DELETE FROM kv") abstract suspend fun clearKv()

    @Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE)
    abstract suspend fun saveDaily(item: DailyEntity)

    @Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE)
    abstract suspend fun saveGear(item: GearEntity)

    @Query("DELETE FROM gear WHERE id = :id")
    abstract suspend fun deleteGear(id: String)

    /** Pemulihan cadangan web mengganti data pendamping seluruhnya, seperti halnya di versi web. */
    @Transaction
    open suspend fun replaceAll(daily: List<DailyEntity>, gear: List<GearEntity>, kv: List<KvEntity>) {
        clearDaily(); clearGear(); clearKv()
        putDaily(daily); putGear(gear); putKv(kv)
    }
}

@Dao
abstract class ActivityDao {
    @Query("SELECT * FROM activity ORDER BY dateIso DESC, id DESC")
    abstract fun observeAll(): Flow<List<ActivityEntity>>

    @Insert
    abstract suspend fun insert(a: ActivityEntity): Long

    @Query("UPDATE activity SET detailFile = :file WHERE id = :id")
    abstract suspend fun setDetail(id: Long, file: String)

    @Query("SELECT * FROM activity WHERE id = :id")
    abstract suspend fun byId(id: Long): ActivityEntity?

    @Insert
    abstract suspend fun insertAll(list: List<ActivityEntity>)

    @Query("DELETE FROM activity WHERE id = :id")
    abstract suspend fun delete(id: Long)

    @Query("DELETE FROM activity WHERE srcKey != ''")
    abstract suspend fun deleteImported()

    /** Pemulihan dari cadangan web menimpa catatan hasil impor sebelumnya; catatan yang dibuat di aplikasi ini tetap. */
    @Transaction
    open suspend fun replaceImported(list: List<ActivityEntity>) {
        deleteImported()
        insertAll(list)
    }
}

private val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE activity ADD COLUMN srcKey TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE activity ADD COLUMN name TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE activity ADD COLUMN gain INTEGER")
        db.execSQL("ALTER TABLE activity ADD COLUMN startTime TEXT")
        db.execSQL("ALTER TABLE activity ADD COLUMN maxHr INTEGER")
        db.execSQL("ALTER TABLE activity ADD COLUMN type TEXT NOT NULL DEFAULT 'run'")
        db.execSQL("ALTER TABLE activity ADD COLUMN gearId TEXT")
    }
}

private val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE activity ADD COLUMN detailFile TEXT")
    }
}

private val MIGRATION_3_4 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS daily (dateIso TEXT NOT NULL, rhr INTEGER, hrv INTEGER, leg INTEGER, mood INTEGER, sleepH REAL, raw TEXT NOT NULL, PRIMARY KEY(dateIso))")
        db.execSQL("CREATE TABLE IF NOT EXISTS gear (id TEXT NOT NULL, name TEXT NOT NULL, model TEXT NOT NULL, km0 REAL NOT NULL, limitKm REAL NOT NULL, retired INTEGER NOT NULL, isDefault INTEGER NOT NULL, PRIMARY KEY(id))")
        db.execSQL("CREATE TABLE IF NOT EXISTS kv (`key` TEXT NOT NULL, json TEXT NOT NULL, PRIMARY KEY(`key`))")
    }
}

@Database(entities = [ActivityEntity::class, DailyEntity::class, GearEntity::class, KvEntity::class], version = 4, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun activities(): ActivityDao
    abstract fun companion(): CompanionDao

    companion object {
        fun create(ctx: Context): AppDb =
            Room.databaseBuilder(ctx, AppDb::class.java, "endurancevault.db")
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)
                .build()
    }
}
