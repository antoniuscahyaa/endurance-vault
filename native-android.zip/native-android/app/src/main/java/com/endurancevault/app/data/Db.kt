package com.endurancevault.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "activity")
data class ActivityEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateIso: String,          // yyyy-MM-dd
    val km: Double,
    val durationSec: Int,
    val avgHr: Int? = null,
    val feel: Int? = null,        // rasa setelah lari 1..5
    val note: String = "",
)

@Dao
interface ActivityDao {
    @Query("SELECT * FROM activity ORDER BY dateIso DESC, id DESC")
    fun observeAll(): Flow<List<ActivityEntity>>

    @Insert
    suspend fun insert(a: ActivityEntity): Long

    @Query("DELETE FROM activity WHERE id = :id")
    suspend fun delete(id: Long)
}

@Database(entities = [ActivityEntity::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun activities(): ActivityDao

    companion object {
        fun create(ctx: Context): AppDb =
            Room.databaseBuilder(ctx, AppDb::class.java, "endurancevault.db").build()
    }
}
