package com.endurancevault.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "activity")
data class ActivityEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateIso: String,              // yyyy-MM-dd
    val km: Double,
    val durationSec: Int,
    val avgHr: Int? = null,
    val feel: Int? = null,            // rasa setelah lari 1..5
    val note: String = "",
    val srcKey: String = "",          // kunci di cadangan web ("2026-11-03" atau "2026-11-03~f1"); kosong = dicatat di aplikasi ini
    val name: String = "",
    val gain: Int? = null,            // D+ (m)
    val startTime: String? = null,    // HH:mm
    val maxHr: Int? = null,
    val type: String = "run",         // run | bike
    val gearId: String? = null,
)

@Dao
abstract class ActivityDao {
    @Query("SELECT * FROM activity ORDER BY dateIso DESC, id DESC")
    abstract fun observeAll(): Flow<List<ActivityEntity>>

    @Insert
    abstract suspend fun insert(a: ActivityEntity): Long

    @Insert
    abstract suspend fun insertAll(list: List<ActivityEntity>)

    @Query("DELETE FROM activity WHERE id = :id")
    abstract suspend fun delete(id: Long)

    @Query("DELETE FROM activity WHERE srcKey != ''")
    abstract suspend fun deleteImported()

    /** Pemulihan dari cadangan web menimpa catatan hasil impor sebelumnya; catatan yang dibuat di aplikasi ini tetap. */
    @Transaction
    open suspend fun replaceImported(list: List<ActivityEntity>) {
        deleteImported()
        insertAll(list)
    }
}

private val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE activity ADD COLUMN srcKey TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE activity ADD COLUMN name TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE activity ADD COLUMN gain INTEGER")
        db.execSQL("ALTER TABLE activity ADD COLUMN startTime TEXT")
        db.execSQL("ALTER TABLE activity ADD COLUMN maxHr INTEGER")
        db.execSQL("ALTER TABLE activity ADD COLUMN type TEXT NOT NULL DEFAULT 'run'")
        db.execSQL("ALTER TABLE activity ADD COLUMN gearId TEXT")
    }
}

@Database(entities = [ActivityEntity::class], version = 2, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun activities(): ActivityDao

    companion object {
        fun create(ctx: Context): AppDb =
            Room.databaseBuilder(ctx, AppDb::class.java, "endurancevault.db")
                .addMigrations(MIGRATION_1_2)
                .build()
    }
}
