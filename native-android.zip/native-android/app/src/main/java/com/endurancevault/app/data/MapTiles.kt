package com.endurancevault.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import com.endurancevault.app.domain.RouteGeo.TileId
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Gaya peta dasar. [maxNative] = zoom ubin tertinggi yang tersedia di server (di atasnya ubin diperbesar, bukan diminta ulang),
 * [dir] = folder cache di cacheDir (peta default memakai folder lama "osm-tiles" agar cache 0.5.47 tetap terpakai).
 */
enum class MapStyle(val dir: String, val maxNative: Int, val attribution: String) {
    DEFAULT("osm-tiles", 18, "© OpenStreetMap"),
    SATELLITE("tiles-satelit", 17, "Esri, Maxar, Earthstar Geographics"),
    TOPO("tiles-topo", 17, "© OpenTopoMap (CC-BY-SA) · © OpenStreetMap"),
    /** Peta kontur untuk mendaki: garis kontur, bayangan relief, dan tinta ketinggian dirender di perangkat dari ubin elevasi Terrarium. */
    CONTOUR("tiles-kontur", 17, "Kontur dirender di perangkat · Elevasi: Terrain Tiles (SRTM, dll.)"),
    ;

    fun url(t: TileId): String = when (this) {
        DEFAULT -> "https://tile.openstreetmap.org/${t.z}/${t.x}/${t.y}.png"
        // Esri memakai urutan z/y/x
        SATELLITE -> "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${t.z}/${t.y}/${t.x}"
        TOPO -> "https://tile.opentopomap.org/${t.z}/${t.x}/${t.y}.png"
        CONTOUR -> "" // tidak diunduh: dirender oleh ContourTiles
    }
}

/** Nama gaya peta untuk pesan dan label aksesibilitas. */
val MapStyle.label: String
    get() = when (this) {
        MapStyle.DEFAULT -> "default"
        MapStyle.SATELLITE -> "satelit"
        MapStyle.TOPO -> "topografi"
        MapStyle.CONTOUR -> "kontur"
    }

/** Gaya peta berikutnya dalam urutan siklus tombol ganti peta. */
fun MapStyle.next(): MapStyle = MapStyle.values()[(ordinal + 1) % MapStyle.values().size]

/**
 * Pemuat ubin peta (OpenStreetMap, citra satelit Esri, OpenTopoMap, kontur render sendiri) untuk latar rute.
 * Cache memori (LRU) + cache disk di cacheDir/osm-tiles; ubin lebih dari 14 hari diunduh ulang,
 * dan ubin basi tetap dipakai bila jaringan gagal. Kebijakan OSM: wajib User-Agent yang jelas dan mengutamakan cache.
 */
object MapTiles {
    private const val USER_AGENT = "EnduranceVault/0.5.51 (Android; personal fitness log)"
    private const val MAX_AGE_MS = 14L * 24 * 60 * 60 * 1000

    private val mem = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 1024 / 16).toInt().coerceIn(2048, 24_576), // KB
    ) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    private fun key(style: MapStyle, t: TileId) = "${style.name}/${t.z}/${t.x}/${t.y}"

    /** Bitmap ubin, atau null bila tidak ada di cache dan unduhan gagal (offline, timeout, dll.). */
    suspend fun load(context: Context, t: TileId, style: MapStyle = MapStyle.DEFAULT): Bitmap? = withContext(Dispatchers.IO) {
        val k = key(style, t)
        mem.get(k)?.let { return@withContext it }
        val file = File(context.applicationContext.cacheDir, "${style.dir}/${t.z}/${t.x}/${t.y}.png")
        // ubin kontur hasil render tidak berubah, jadi tidak perlu diperbarui berkala
        val maxAge = if (style == MapStyle.CONTOUR) Long.MAX_VALUE else MAX_AGE_MS
        val fresh = file.isFile && System.currentTimeMillis() - file.lastModified() < maxAge
        if (fresh) decode(file)?.let { mem.put(k, it); return@withContext it }
        val bytes = if (style == MapStyle.CONTOUR) ContourTiles.render(context.applicationContext, t) else download(style, t)
        if (bytes != null) {
            runCatching { file.parentFile?.mkdirs(); file.writeBytes(bytes) }
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            if (bmp != null) { mem.put(k, bmp); return@withContext bmp }
        }
        if (file.isFile) decode(file)?.let { mem.put(k, it); return@withContext it }
        null
    }

    private fun decode(file: File): Bitmap? = runCatching { BitmapFactory.decodeFile(file.absolutePath) }.getOrNull()

    private fun download(style: MapStyle, t: TileId): ByteArray? {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(style.url(t)).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8_000
                readTimeout = 8_000
                setRequestProperty("User-Agent", USER_AGENT)
            }
            if (conn.responseCode != 200) null else conn.inputStream.use { it.readBytes() }
        } catch (_: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }
}
