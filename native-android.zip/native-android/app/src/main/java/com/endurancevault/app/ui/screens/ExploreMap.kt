package com.endurancevault.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import com.endurancevault.app.ui.i18n.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.endurancevault.app.data.MapStyle
import com.endurancevault.app.data.MapTiles
import com.endurancevault.app.domain.CourseStrategy.Pt
import com.endurancevault.app.domain.ExPlace
import com.endurancevault.app.domain.RouteGeo
import com.endurancevault.app.ui.theme.Ember
import kotlin.math.floor
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

internal val ExBlue = Color(0xFF2563EB)
internal val ExPinFill = Color(0xFFF59E0B)
internal val ExPinLine = Color(0xFF92400E)
internal val ExStartGreen = Color(0xFF2E9E5B)
internal val ExEraseRed = Color(0xFFD33F3F)
internal val ExSteep = Color(0xFF8B1A1A)
internal val ExTrace = Color(0xFF7C3AED)

/** Permintaan agar peta menyesuaikan tampilan ke [points]; [key] berubah = permintaan baru. */
internal class ExFit(val key: Int, val points: List<RouteGeo.LatLon>)

/** Kamera ubin: zoom ubin dibatasi [maxNative] (server tak punya ubin lebih tinggi); sisanya jadi pembesaran. */
private fun exCamFor(v: RouteGeo.View, maxNative: Int): RouteGeo.Camera {
    val z = floor(v.zoomF).toInt().coerceIn(0, maxNative)
    val k = 2.0.pow(z)
    return RouteGeo.Camera(z, 2.0.pow(v.zoomF - z), v.cx0 * k, v.cy0 * k)
}

internal fun exScreenToLatLon(v: RouteGeo.View, s: IntSize, o: Offset): RouteGeo.LatLon {
    val k = 2.0.pow(v.zoomF)
    val px = v.cx0 + (o.x - s.width / 2.0) / k
    val py = v.cy0 + (o.y - s.height / 2.0) / k
    return RouteGeo.LatLon(RouteGeo.latOfWorldY(py, 0), RouteGeo.lonOfWorldX(px, 0))
}

/** Tampilan yang berpusat di [p] pada zoom [zoom]. */
internal fun exViewAt(p: RouteGeo.LatLon, zoom: Double) = RouteGeo.View(zoom, RouteGeo.worldX(p.lon, 0), RouteGeo.worldY(p.lat, 0))

/**
 * Peta interaktif layar penuh untuk Explore: ubin (default OSM, satelit Esri, topografi OpenTopoMap) dari cache disk,
 * cubit dan geser, ketuk untuk menaruh titik. Menggambar rute, titik pegangan (hijau awal, biru tengah, hitam akhir),
 * bagian yang akan dihapus (merah, mulai [eraseFromIdx]), pin lokasi tersimpan (oranye), dan posisi saya.
 */
@Composable
internal fun ExploreMapCanvas(
    view: RouteGeo.View,
    onView: (RouteGeo.View) -> Unit,
    style: MapStyle,
    routePts: List<Pt>,
    anchors: List<RouteGeo.LatLon>,
    places: List<ExPlace>,
    modifier: Modifier = Modifier,
    eraseFromIdx: Int? = null,
    eraseToIdx: Int? = null,
    steep: List<IntRange> = emptyList(),
    trace: List<RouteGeo.LatLon> = emptyList(),
    marker: RouteGeo.LatLon? = null,
    myLocation: RouteGeo.LatLon? = null,
    fit: ExFit? = null,
    onTap: (RouteGeo.LatLon) -> Unit = {},
) {
    val context = LocalContext.current
    var size by remember { mutableStateOf(IntSize.Zero) }
    val latestView by rememberUpdatedState(view)
    val latestOnView by rememberUpdatedState(onView)
    val latestOnTap by rememberUpdatedState(onTap)
    val latestSize by rememberUpdatedState(size)
    val bitmaps = remember { mutableStateMapOf<Pair<MapStyle, RouteGeo.TileId>, ImageBitmap>() }
    var offline by remember { mutableStateOf(false) }

    val cam = remember(view, style) { exCamFor(view, style.maxNative) }
    val placed = remember(cam, size) {
        if (size.width > 0) RouteGeo.tilesFor(cam, size.width.toDouble(), size.height.toDouble()) else emptyList()
    }

    LaunchedEffect(fit?.key, size) {
        if (fit != null && size.width > 0 && fit.points.isNotEmpty()) {
            RouteGeo.fitView(fit.points, size.width.toDouble(), size.height.toDouble(), 0.18)?.let { latestOnView(it) }
        }
    }

    LaunchedEffect(placed, style) {
        if (bitmaps.size > 220) bitmaps.clear()
        coroutineScope {
            placed.map { it.id }.distinct().forEach { id ->
                if (bitmaps[style to id] == null) launch {
                    val bmp = MapTiles.load(context, id, style)
                    if (bmp != null) { bitmaps[style to id] = bmp.asImageBitmap(); offline = false } else offline = true
                }
            }
        }
    }

    Box(modifier.fillMaxSize().background(Color(0xFFE9E6DF))) {
        Canvas(
            Modifier.fillMaxSize()
                .onSizeChanged { size = it }
                .pointerInput(Unit) {
                    detectTransformGestures { centroid, pan, zoom, _ ->
                        val s = latestSize
                        if (s.width > 0) {
                            latestOnView(
                                RouteGeo.transform(
                                    latestView, s.width.toDouble(), s.height.toDouble(),
                                    centroid.x.toDouble(), centroid.y.toDouble(), pan.x.toDouble(), pan.y.toDouble(),
                                    zoom.toDouble(), minZoom = 2.0,
                                ),
                            )
                        }
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures(onTap = { o -> if (latestSize.width > 0) latestOnTap(exScreenToLatLon(latestView, latestSize, o)) })
                },
        ) {
            val s = cam.scale
            val cx = size.width / 2.0
            val cy = size.height / 2.0
            fun sx(wx: Double) = (cx + (wx - cam.centerX) * s).toFloat()
            fun sy(wy: Double) = (cy + (wy - cam.centerY) * s).toFloat()
            fun pos(lat: Double, lon: Double) = Offset(sx(RouteGeo.worldX(lon, cam.zoom)), sy(RouteGeo.worldY(lat, cam.zoom)))

            val tile = RouteGeo.TILE.toDouble()
            placed.forEach { p ->
                val bmp = bitmaps[style to p.id] ?: return@forEach
                val left = sx(p.ux * tile).roundToInt()
                val top = sy(p.id.y * tile).roundToInt()
                val right = sx((p.ux + 1) * tile).roundToInt()
                val bottom = sy((p.id.y + 1) * tile).roundToInt()
                drawImage(bmp, dstOffset = IntOffset(left, top), dstSize = IntSize(right - left, bottom - top))
            }

            if (routePts.size >= 2) {
                val path = Path()
                routePts.forEachIndexed { i, p -> val o = pos(p.lat, p.lon); if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y) }
                drawPath(path, Color.White.copy(alpha = 0.92f), style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                drawPath(path, Ember, style = Stroke(width = 4.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                steep.forEach { r ->
                    val sp = Path()
                    for (i in r.first..minOf(r.last, routePts.lastIndex)) {
                        val o = pos(routePts[i].lat, routePts[i].lon)
                        if (i == r.first) sp.moveTo(o.x, o.y) else sp.lineTo(o.x, o.y)
                    }
                    drawPath(sp, ExSteep, style = Stroke(width = 4.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
                if (eraseFromIdx != null && eraseFromIdx in 0 until routePts.size - 1) {
                    val cut = Path()
                    val endIdx = (eraseToIdx ?: routePts.lastIndex).coerceIn(eraseFromIdx + 1, routePts.lastIndex)
                    for (i in eraseFromIdx..endIdx) {
                        val o = pos(routePts[i].lat, routePts[i].lon)
                        if (i == eraseFromIdx) cut.moveTo(o.x, o.y) else cut.lineTo(o.x, o.y)
                    }
                    drawPath(cut, ExEraseRed, style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
            }

            if (trace.size >= 2) {
                val tp = Path()
                trace.forEachIndexed { i, q -> val o = pos(q.lat, q.lon); if (i == 0) tp.moveTo(o.x, o.y) else tp.lineTo(o.x, o.y) }
                drawPath(tp, Color.White.copy(alpha = 0.8f), style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                drawPath(tp, ExTrace, style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            }

            places.forEach { drawPin(pos(it.lat, it.lon)) }

            anchors.forEachIndexed { i, a ->
                val o = pos(a.lat, a.lon)
                val last = i == anchors.lastIndex && anchors.size > 1
                val first = i == 0
                drawCircle(Color.White, 9.dp.toPx(), o)
                drawCircle(if (first) ExStartGreen else if (last) Color(0xFF1C1C1E) else ExBlue, 6.5.dp.toPx(), o)
            }

            marker?.let {
                val o = pos(it.lat, it.lon)
                drawCircle(Color.White, 10.dp.toPx(), o)
                drawCircle(Color(0xFF1C1C1E), 7.dp.toPx(), o)
                drawCircle(Ember, 3.dp.toPx(), o)
            }

            myLocation?.let {
                val o = pos(it.lat, it.lon)
                drawCircle(ExBlue.copy(alpha = 0.18f), 18.dp.toPx(), o)
                drawCircle(Color.White, 8.dp.toPx(), o)
                drawCircle(ExBlue, 5.5.dp.toPx(), o)
            }
        }

        Text(
            style.attribution,
            modifier = Modifier.align(Alignment.BottomStart).padding(start = 4.dp, bottom = 2.dp).background(Color.White.copy(alpha = 0.65f)).padding(horizontal = 3.dp),
            color = Color(0xFF333333), fontSize = 7.sp, lineHeight = 9.sp,
        )
        if (offline && bitmaps.isEmpty()) {
            Text(
                "Peta dasar tidak termuat (offline). Ketuk tetap menaruh titik; peta muncul saat tersambung.",
                modifier = Modifier.align(Alignment.Center).padding(24.dp).background(Color.White.copy(alpha = 0.85f)).padding(8.dp),
                color = Color(0xFF333333), fontSize = 12.sp,
            )
        }
    }
}

/** Pin lokasi tersimpan: ujung pin tepat di [tip]. */
private fun DrawScope.drawPin(tip: Offset) {
    val r = 9.dp.toPx()
    val head = Offset(tip.x, tip.y - r * 1.9f)
    val body = Path().apply {
        moveTo(tip.x, tip.y)
        lineTo(head.x - r * 0.8f, head.y + r * 0.6f)
        lineTo(head.x + r * 0.8f, head.y + r * 0.6f)
        close()
    }
    drawPath(body, ExPinFill)
    drawCircle(ExPinLine, r + 1.2.dp.toPx(), head)
    drawCircle(ExPinFill, r, head)
    drawCircle(Color.White, r * 0.38f, head)
}
