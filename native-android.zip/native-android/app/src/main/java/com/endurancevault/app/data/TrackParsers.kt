package com.endurancevault.app.data

import com.endurancevault.app.domain.ActImportException
import com.endurancevault.app.domain.FitLap
import com.endurancevault.app.domain.ParsedTrack
import com.endurancevault.app.domain.Pt
import java.io.ByteArrayInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.time.LocalDateTime
import java.time.OffsetDateTime
import java.time.ZoneOffset
import javax.xml.parsers.SAXParserFactory
import org.xml.sax.Attributes
import org.xml.sax.InputSource
import org.xml.sax.helpers.DefaultHandler
import kotlin.math.min

/** Pembaca berkas aktivitas: FIT (biner Garmin/Huawei/Coros), GPX, dan TCX. Mengikuti parseFit/parseAct di web. */
object TrackParsers {
    /** Pilih pembaca dari isi berkas (tanda ".FIT" di byte 8–11), bukan dari nama. */
    fun parse(bytes: ByteArray): ParsedTrack =
        if (bytes.size >= 12 && bytes[8] == '.'.code.toByte() && bytes[9] == 'F'.code.toByte() &&
            bytes[10] == 'I'.code.toByte() && bytes[11] == 'T'.code.toByte()
        ) FitParser.parse(bytes) else XmlTrackParser.parse(bytes)
}

object FitParser {
    private const val EPOCH = 631065600000.0
    private val SZ = mapOf(0 to 1, 1 to 1, 2 to 1, 3 to 2, 4 to 2, 5 to 4, 6 to 4, 8 to 4, 9 to 8, 10 to 1, 11 to 2, 12 to 4, 13 to 1, 14 to 8, 15 to 8, 16 to 8)
    private class Def(val le: Boolean, val gm: Int, val fn: IntArray, val fs: IntArray, val ft: IntArray, val dsz: Int)

    fun parse(buf: ByteArray): ParsedTrack {
        try {
            return parseUnsafe(buf)
        } catch (e: ActImportException) {
            throw e
        } catch (e: RuntimeException) {
            throw ActImportException("berkas FIT rusak")
        }
    }

    private fun parseUnsafe(buf: ByteArray): ParsedTrack {
        val n = buf.size
        if (n < 14) throw ActImportException("berkas FIT terlalu kecil")
        val bb = ByteBuffer.wrap(buf)
        fun u8(o: Int) = buf[o].toInt() and 0xFF
        fun u16(o: Int, le: Boolean): Int { bb.order(if (le) ByteOrder.LITTLE_ENDIAN else ByteOrder.BIG_ENDIAN); return bb.getShort(o).toInt() and 0xFFFF }
        fun u32(o: Int, le: Boolean): Long { bb.order(if (le) ByteOrder.LITTLE_ENDIAN else ByteOrder.BIG_ENDIAN); return bb.getInt(o).toLong() and 0xFFFFFFFFL }
        val hs = u8(0)
        val end = min(n.toLong(), hs + u32(4, true)).toInt()
        if (u32(8, true) != 0x5449462EL) throw ActImportException("bukan berkas FIT yang valid")

        fun rd(o: Int, bt: Int, le: Boolean): Double? {
            bb.order(if (le) ByteOrder.LITTLE_ENDIAN else ByteOrder.BIG_ENDIAN)
            return when (bt) {
                1 -> bb.get(o).toInt().let { if (it == 0x7F) null else it.toDouble() }
                0, 2, 13 -> u8(o).let { if (it == 0xFF) null else it.toDouble() }
                10 -> u8(o).let { if (it == 0) null else it.toDouble() }
                3 -> bb.getShort(o).toInt().let { if (it == 0x7FFF) null else it.toDouble() }
                4 -> u16(o, le).let { if (it == 0xFFFF) null else it.toDouble() }
                11 -> u16(o, le).let { if (it == 0) null else it.toDouble() }
                5 -> bb.getInt(o).let { if (it == 0x7FFFFFFF) null else it.toDouble() }
                6 -> u32(o, le).let { if (it == 0xFFFFFFFFL) null else it.toDouble() }
                12 -> u32(o, le).let { if (it == 0L) null else it.toDouble() }
                8 -> bb.getFloat(o).let { if (it.isNaN() || it.isInfinite()) null else it.toDouble() }
                9 -> bb.getDouble(o).let { if (it.isNaN() || it.isInfinite()) null else it }
                else -> null
            }
        }

        val defs = HashMap<Int, Def>()
        var pos = hs; var lastTs = 0L
        val pts = ArrayList<Pt>(); val laps = ArrayList<FitLap>(); var sport = ""
        while (pos < end) {
            val h = u8(pos++)
            val def: Def
            if ((h and 0x80) != 0) {
                val lt = (h shr 5) and 3
                def = defs[lt] ?: throw ActImportException("berkas FIT rusak")
                val off = h and 0x1F
                var nt = (lastTs - (lastTs and 0x1F)) + off
                if (off < (lastTs and 0x1F)) nt += 0x20
                lastTs = nt
            } else if ((h and 0x40) != 0) {
                val lt = h and 0x0F; pos++
                val le = u8(pos++) == 0
                val gm = u16(pos, le); pos += 2
                val nf = u8(pos++)
                val fn = IntArray(nf); val fs = IntArray(nf); val ft = IntArray(nf)
                for (k in 0 until nf) { fn[k] = u8(pos); fs[k] = u8(pos + 1); ft[k] = u8(pos + 2) and 0x1F; pos += 3 }
                var dsz = 0
                if ((h and 0x20) != 0) { val nd = u8(pos++); for (k in 0 until nd) { dsz += u8(pos + 1); pos += 3 } }
                defs[lt] = Def(le, gm, fn, fs, ft, dsz)
                continue
            } else {
                def = defs[h and 0x0F] ?: throw ActImportException("berkas FIT rusak")
            }
            val f = HashMap<Int, Double>()
            var p2 = pos
            for (k in def.fn.indices) {
                val bt = def.ft[k]; val sz = SZ[bt] ?: 1
                if (!(bt == 7 || bt == 14 || bt == 15 || bt == 16 || def.fs[k] < sz)) rd(p2, bt, def.le)?.let { f[def.fn[k]] = it }
                p2 += def.fs[k]
            }
            pos = p2 + def.dsz
            f[253]?.let { lastTs = it.toLong() }
            when (def.gm) {
                20 -> {
                    val ts: Double = (if ((h and 0x80) != 0) lastTs.toDouble() else f[253]) ?: continue
                    val alt = f[78]?.let { it / 5 - 500 } ?: f[2]?.let { it / 5 - 500 } ?: Double.NaN
                    pts.add(Pt(
                        la = f[0]?.let { it * 180 / 2147483648.0 } ?: Double.NaN, lo = f[1]?.let { it * 180 / 2147483648.0 } ?: Double.NaN,
                        t = EPOCH + ts * 1000, e = alt, h = f[3] ?: Double.NaN, c = f[4] ?: Double.NaN,
                        d = f[5]?.let { it / 100 } ?: Double.NaN, tp = f[13] ?: Double.NaN,
                    ))
                }
                19 -> f[253]?.let {
                    laps.add(FitLap(EPOCH + it * 1000, f[23]?.toInt(), f[7]?.let { v -> v / 1000 }, f[8]?.let { v -> v / 1000 },
                        f[9]?.let { v -> v / 100 }, f[15]?.toInt(), f[17]?.toInt()))
                }
                18 -> if (f[5] != null && sport.isEmpty()) {
                    sport = mapOf(1 to "running", 2 to "biking", 5 to "swimming", 11 to "walking", 17 to "hiking", 10 to "training")[f[5]!!.toInt()] ?: ""
                }
            }
        }
        return ParsedTrack(pts, sport, "", laps)
    }
}

object XmlTrackParser {
    fun parse(bytes: ByteArray): ParsedTrack {
        val h = Handler()
        try {
            val f = SAXParserFactory.newInstance()
            f.isNamespaceAware = false
            // Tolak DOCTYPE/entitas eksternal bila pengurai mendukung (berkas dari luar tidak dipercaya)
            runCatching { f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }
            runCatching { f.setFeature("http://xml.org/sax/features/external-general-entities", false) }
            runCatching { f.setFeature("http://xml.org/sax/features/external-parameter-entities", false) }
            f.newSAXParser().parse(InputSource(ByteArrayInputStream(bytes)), h)
        } catch (e: Exception) {
            throw ActImportException("bukan berkas GPX/TCX/FIT yang valid")
        }
        return if (h.gpx.isNotEmpty()) ParsedTrack(h.gpx, h.type, h.firstName.trim())
        else ParsedTrack(h.tcx, h.sport, "")
    }

    internal fun time(s: String?): Double {
        if (s.isNullOrBlank()) return Double.NaN
        val t = s.trim()
        return try { OffsetDateTime.parse(t).toInstant().toEpochMilli().toDouble() }
        catch (e: Exception) {
            try { LocalDateTime.parse(t).toInstant(ZoneOffset.UTC).toEpochMilli().toDouble() } catch (e2: Exception) { Double.NaN }
        }
    }

    private fun num(s: String?): Double = s?.trim()?.toDoubleOrNull() ?: Double.NaN

    private class Handler : DefaultHandler() {
        val gpx = ArrayList<Pt>(); val tcx = ArrayList<Pt>()
        var sport = ""; var firstName = ""; var type = ""
        private var gotName = false; private var gotType = false; private var gotSport = false
        private val stack = ArrayList<String>()
        private val text = StringBuilder()
        private var inTrkpt = false; private var inTp = false
        private var la = Double.NaN; private var lo = Double.NaN
        private val cur = HashMap<String, String>()

        override fun startElement(uri: String?, localName: String?, qName: String, a: Attributes) {
            val n = qName.substringAfter(':')
            stack.add(n); text.setLength(0)
            when (n) {
                "trkpt" -> { inTrkpt = true; cur.clear(); la = num(a.getValue("lat")); lo = num(a.getValue("lon")) }
                "Trackpoint" -> { inTp = true; cur.clear() }
                "Activity" -> if (!gotSport) { sport = a.getValue("Sport") ?: ""; gotSport = true }
            }
        }

        override fun characters(ch: CharArray, start: Int, length: Int) { text.append(ch, start, length) }

        override fun endElement(uri: String?, localName: String?, qName: String) {
            val n = qName.substringAfter(':')
            val t = text.toString()
            stack.removeAt(stack.size - 1)
            if (n == "name" && !gotName) { firstName = t; gotName = true }
            if (n == "type" && !gotType) { type = t; gotType = true }
            if (inTrkpt || inTp) {
                val key = if (n == "Value") { if (stack.lastOrNull() == "HeartRateBpm") n else "" } else n
                if (key.isNotEmpty() && !cur.containsKey(key)) cur[key] = t
            }
            when (n) {
                "trkpt" -> {
                    inTrkpt = false
                    gpx.add(Pt(la, lo, time(cur["time"]), num(cur["ele"]), num(cur["hr"]), num(cur["cad"]), Double.NaN))
                }
                "Trackpoint" -> {
                    inTp = false
                    tcx.add(Pt(
                        num(cur["LatitudeDegrees"]), num(cur["LongitudeDegrees"]), time(cur["Time"]), num(cur["AltitudeMeters"]),
                        num(cur["Value"]), num(cur["Cadence"] ?: cur["RunCadence"]), num(cur["DistanceMeters"]),
                    ))
                }
            }
            text.setLength(0)
        }
    }
}
