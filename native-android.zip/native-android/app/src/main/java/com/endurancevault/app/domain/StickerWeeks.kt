package com.endurancevault.app.domain

import com.endurancevault.app.data.ActivityEntity
import java.time.LocalDate

/** Hari rencana, disederhanakan dari [PDay]. */
class SwDay(val date: LocalDate, val kind: String, val km: Double)

/** Minggu rencana: [index] = nomor minggu (0-based, tampil sebagai index + 1). */
class SwWeek(val index: Int, val days: List<SwDay>, val planKm: Double)

/**
 * Satu aktivitas untuk ringkasan minggu. [free] = Free Run (bukan log hari rencana); [hist] histogram HR bila ada.
 */
class SwRun(
    val id: Long, val date: LocalDate, val km: Double, val min: Double, val hr: Int?, val gain: Double,
    val bike: Boolean, val free: Boolean, val hist: Map<Int, Double>?,
)

/** Masukan data minggu: minggu rencana, semua aktivitas, dan tanggal yang dicentang selesai manual. */
class SwInput(val weeks: List<SwWeek>, val runs: List<SwRun>, val done: Set<String>)

class SwDayStat(val label: String, val date: LocalDate, val plan: Double, val act: Double)
class SwZones(val secs: DoubleArray, val total: Double)

/** Ringkasan satu minggu (padanan `weekSummary`, bagian yang dipakai stiker). */
class SwSummary(
    val index: Int, val planKm: Double, val km: Double, val min: Double, val gain: Double,
    val nDone: Int, val nFree: Int, val nPlan: Int, val pace: Double?, val hr: Double?,
    val zones: SwZones?, val days: List<SwDayStat>,
)

class SwTrendPt(val index: Int, val pace: Double, val cur: Boolean)

/** Minggu tempat sesi ini berada, lengkap dengan ringkasannya; [pos] = posisi di daftar minggu. */
class SwCtx(val pos: Int, val summary: SwSummary)

object StickerWeeks {
    private val DOW = listOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min")

    /**
     * Susun masukan dari aktivitas dan rencana. Di web Free Run punya kunci `tanggal~fN`; di native baris
     * dengan `srcKey` berisi "~f" adalah Free Run, dan bila satu tanggal punya beberapa baris tanpa "~f"
     * baris pertama (id terkecil) dianggap log hari rencana dan sisanya Free Run.
     */
    fun inputOf(
        weeks: List<PWeek>, activities: List<ActivityEntity>, done: Set<String>, hist: (ActivityEntity) -> Map<Int, Double>?,
    ): SwInput {
        val sw = weeks.map { w -> SwWeek(w.i, w.days.map { SwDay(it.date, it.kind, it.km) }, w.km) }
        val firstOfDate = HashSet<String>()
        val runs = activities.sortedBy { it.id }.mapNotNull { a ->
            val d = runCatching { LocalDate.parse(a.dateIso.take(10)) }.getOrNull() ?: return@mapNotNull null
            val free = if (a.srcKey.contains("~f")) true else !firstOfDate.add(a.dateIso.take(10))
            SwRun(a.id, d, a.km, a.durationSec / 60.0, a.avgHr, (a.gain ?: 0).toDouble(), a.type == "bike", free, hist(a))
        }
        return SwInput(sw, runs, done)
    }

    /** Minggu yang memuat [date] (antara hari pertama dan terakhir minggu itu), atau null. */
    fun weekPos(date: LocalDate, input: SwInput): Int? {
        input.weeks.forEachIndexed { i, w ->
            val d = w.days
            if (d.isNotEmpty() && !date.isBefore(d.first().date) && !date.isAfter(d.last().date)) return i
        }
        return null
    }

    fun summarize(w: SwWeek, input: SwInput, zc: ZoneCuts): SwSummary {
        var km = 0.0; var min = 0.0; var gain = 0.0; var nDone = 0; var nFree = 0; var nPlan = 0
        var pK = 0.0; var pM = 0.0; var hW = 0.0; var hT = 0.0
        fun addPace(r: SwRun) {
            if (r.bike || !(r.km > 0 && r.min > 0)) return
            pK += r.km; pM += r.min
            if ((r.hr ?: 0) > 0) { hW += r.hr!! * r.min; hT += r.min }
        }
        val dayLog = HashMap<LocalDate, SwRun>()
        input.runs.filter { !it.free }.forEach { dayLog.putIfAbsent(it.date, it) }
        val act = DoubleArray(w.days.size)
        val labels = w.days.map { DOW[it.date.dayOfWeek.value - 1] }
        w.days.forEachIndexed { i, d ->
            val l = dayLog[d.date]
            val bike = l?.bike == true
            val run = d.kind != Kinds.REST
            if (run) {
                nPlan++
                if (d.date.toString() in input.done || (l != null && l.km > 0)) nDone++
            }
            if (l != null && l.km > 0 && !bike) act[i] = l.km
            if (l != null && !bike) { km += l.km; min += l.min; gain += l.gain }
            if (l != null && run && (d.kind == Kinds.EASY || d.kind == "short")) addPace(l)
        }
        // Free Run tidak ada di hari rencana: tambahkan ke total, grafik harian, hitungan sesi, dan pace/HR
        if (w.days.isNotEmpty()) {
            val a0 = w.days.first().date; val z0 = w.days.last().date
            input.runs.filter { it.free && !it.date.isBefore(a0) && !it.date.isAfter(z0) }.forEach { r ->
                if (r.bike || !(r.km > 0 || r.min > 0)) return@forEach
                val di = w.days.indexOfFirst { it.date == r.date }
                nFree++; km += r.km; min += r.min; gain += r.gain
                if (di >= 0 && r.km > 0) act[di] += r.km
                addPace(r)
            }
        }
        return SwSummary(
            w.index, w.planKm, km, min, gain, nDone, nFree, nPlan,
            if (pK > 0) pM / pK else null, if (hT > 0) hW / hT else null,
            zones(w, input, zc), w.days.mapIndexed { i, d -> SwDayStat(labels[i], d.date, d.km, act[i]) },
        )
    }

    /** Waktu per zona HR dari semua aktivitas minggu itu yang punya data HR lebih dari 60 detik; null bila tidak ada. */
    private fun zones(w: SwWeek, input: SwInput, zc: ZoneCuts): SwZones? {
        if (w.days.isEmpty()) return null
        val a0 = w.days.first().date; val z0 = w.days.last().date
        val s = DoubleArray(5)
        input.runs.forEach { r ->
            val h = r.hist
            if (h == null || r.date.isBefore(a0) || r.date.isAfter(z0) || h.values.sum() <= 60) return@forEach
            val z = Zones.secs(h, zc)
            for (i in 0 until 5) s[i] += z[i]
        }
        val t = s.sum()
        return if (t > 0) SwZones(s, t) else null
    }

    /** Konteks minggu untuk sesi pada [date]; null bila sesi tidak masuk minggu rencana mana pun. */
    fun contextOf(date: LocalDate, input: SwInput, zc: ZoneCuts): SwCtx? {
        val pos = weekPos(date, input) ?: return null
        return SwCtx(pos, summarize(input.weeks[pos], input, zc))
    }

    /** Pace rata-rata mingguan dari minggu rencana sampai minggu sesi ini (paling banyak [n]); null bila kurang dari dua minggu. */
    fun trend(ctx: SwCtx, input: SwInput, zc: ZoneCuts, n: Int): List<SwTrendPt>? {
        val out = ArrayList<SwTrendPt>()
        for (i in maxOf(0, ctx.pos - n + 1)..ctx.pos) {
            val ws = if (i == ctx.pos) ctx.summary else summarize(input.weeks[i], input, zc)
            if (ws.pace != null && ws.pace > 0) out.add(SwTrendPt(input.weeks[i].index, ws.pace, i == ctx.pos))
        }
        return if (out.size >= 2) out else null
    }
}
