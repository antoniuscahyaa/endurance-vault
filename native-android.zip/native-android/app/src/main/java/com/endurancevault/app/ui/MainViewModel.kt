package com.endurancevault.app.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.endurancevault.app.EnduranceVaultApp
import com.endurancevault.app.data.ActStore
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.data.BackupException
import com.endurancevault.app.data.BackupParser
import com.endurancevault.app.data.KvEntity
import com.endurancevault.app.data.DailyEntity
import com.endurancevault.app.data.GearEntity
import com.endurancevault.app.data.ParsedBackup
import com.endurancevault.app.data.TrackParsers
import com.endurancevault.app.data.HuaweiWatchImport
import com.rencanalari.huaweiwatch.ProtocolBridge
import com.rencanalari.huaweiwatch.ProtocolGateway
import com.rencanalari.huaweiwatch.KeepAliveConfig
import org.json.JSONObject
import org.json.JSONArray
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import com.endurancevault.app.domain.ActBuilder
import com.endurancevault.app.domain.ActImportException
import com.endurancevault.app.domain.ActDetail
import com.endurancevault.app.domain.EasyPace
import com.endurancevault.app.domain.PlanEngine
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.PlanSettings
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class UiState(
    val settings: PlanSettings,
    val plan: PlanOutcome,
    val activities: List<ActivityEntity>,
    val daily: List<DailyEntity> = emptyList(),
    val gear: List<GearEntity> = emptyList(),
    val hrHistByActivity: Map<Long, Map<Int, Double>> = emptyMap(),
)

sealed interface ImportUi {
    data object Idle : ImportUi
    data object Working : ImportUi
    class Confirm(val backup: ParsedBackup, val file: File) : ImportUi
    class Done(val message: String) : ImportUi
    class Failed(val message: String) : ImportUi
}

/** Pace easy dari lari tercatat (null bila belum ada pekan lengkap sebelum pekan ini). */
internal fun easyPaceOf(s: PlanSettings, acts: List<ActivityEntity>): Double? {
    val runs = acts.map { EasyPace.Run(it.dateIso, it.km, it.durationSec / 60.0, it.avgHr, it.type, it.gain) }
    return EasyPace.estimate(runs, EasyPace.sessHr(s))?.pace?.takeIf { it > 0 }
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val a = app as EnduranceVaultApp
    private val settingsFlow = MutableStateFlow(a.settings.load())

    val state: StateFlow<UiState> = combine(
        settingsFlow,
        a.db.activities().observeAll(),
        a.db.companion().observeDaily(),
        a.db.companion().observeGear(),
    ) { s, acts, daily, gear ->
        UiState(s, PlanEngine.plan(s, easyPace = easyPaceOf(s, acts)), acts, daily, gear)
    }.map { ui ->
        val hist = withContext(Dispatchers.IO) {
            ui.activities.mapNotNull { act ->
                act.detailFile?.let { file -> a.acts.readHrHist(file).takeIf { it.isNotEmpty() }?.let { act.id to it } }
            }.toMap()
        }
        ui.copy(hrHistByActivity = hist)
    }.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5_000),
        UiState(settingsFlow.value, PlanEngine.plan(settingsFlow.value), emptyList()),
    )

    val importState = MutableStateFlow<ImportUi>(ImportUi.Idle)

    /** Pesan hasil impor berkas FIT/GPX/TCX (null = tidak ada). */
    val trackMsg = MutableStateFlow<String?>(null)
    val watchMessage = MutableStateFlow("Jam belum dihubungkan.")
    private val watchSyncLock = AtomicBoolean(false)
    val watchSyncing = MutableStateFlow(false)
    private val watchBridge by lazy { ProtocolBridge.get(a) }

    fun saveSettings(s: PlanSettings) {
        a.settings.save(s)
        settingsFlow.update { s }
    }

    fun addActivity(e: ActivityEntity) = viewModelScope.launch { a.db.activities().insert(e) }
    fun deleteActivity(id: Long) = viewModelScope.launch { a.db.activities().delete(id) }

    /** Catatan kesiapan harian disimpan native di Room; tanggal menjadi identitas unik. */
    fun saveDaily(item: DailyEntity) = viewModelScope.launch { a.db.companion().saveDaily(item) }

    /** Gear dapat diperbarui/dipensiunkan tanpa menghapus riwayat aktivitas yang pernah memakainya. */
    fun saveGear(item: GearEntity) = viewModelScope.launch { a.db.companion().saveGear(item) }
    fun deleteGear(id: String) = viewModelScope.launch { a.db.companion().deleteGear(id) }

    /** Salin berkas ke penyimpanan aplikasi (utuh, tanpa kehilangan data), lalu baca ringkasannya. */
    fun startImport(uri: Uri) {
        importState.value = ImportUi.Working
        viewModelScope.launch {
            importState.value = try {
                val picked = withContext(Dispatchers.IO) {
                    val dir = File(a.filesDir, "imports").apply { mkdirs() }
                    val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
                    val f = File(dir, "cadangan-web-$stamp.json")
                    val ins = a.contentResolver.openInputStream(uri) ?: throw BackupException("Berkas tidak bisa dibuka.")
                    ins.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                    try {
                        f to f.inputStream().use { BackupParser.parse(it) }
                    } catch (e: BackupException) {
                        f.delete(); throw e
                    }
                }
                ImportUi.Confirm(picked.second, picked.first)
            } catch (e: BackupException) {
                ImportUi.Failed(e.message ?: "Cadangan tidak bisa dibaca.")
            } catch (e: Exception) {
                ImportUi.Failed("Gagal membaca berkas: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    fun confirmImport() {
        val c = importState.value as? ImportUi.Confirm ?: return
        importState.value = ImportUi.Working
        viewModelScope.launch {
            try {
                // Lintasan kedua: salin rute GPS dan grafik tiap aktivitas ke berkas terpisah
                val keys = withContext(Dispatchers.IO) {
                    a.acts.clearBackupFiles()
                    c.file.inputStream().use { BackupParser.extractActs(it, a.acts.dir) }
                }.toSet()
                val list = c.backup.activities.map {
                    if (it.srcKey in keys) it.copy(detailFile = ActStore.backupFileName(it.srcKey)) else it
                }
                a.db.activities().replaceImported(list)
                a.db.companion().replaceAll(c.backup.daily, c.backup.gear, c.backup.kv.map { KvEntity(it.key, it.value) })
                saveSettings(c.backup.settings)
                importState.value = ImportUi.Done(
                    "Pengaturan rencana, ${list.size} catatan lari (${list.count { it.detailFile != null }} dengan rute dan grafik), " +
                        "${c.backup.daily.size} catatan harian, dan ${c.backup.gear.size} gear dipulihkan. " +
                        "Salinan lengkap cadangan disimpan di penyimpanan aplikasi.",
                )
            } catch (e: Exception) {
                importState.value = ImportUi.Failed("Gagal memulihkan: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    /** Impor satu atau beberapa berkas FIT/GPX/TCX sebagai aktivitas dengan rute dan grafik. */
    fun importTracks(uris: List<Uri>) {
        trackMsg.value = "Membaca ${uris.size} berkas…"
        viewModelScope.launch {
            var added = 0; var attached = 0; var skipped = 0
            val errs = mutableListOf<String>()
            for ((i, u) in uris.withIndex()) {
                try {
                    val act = withContext(Dispatchers.IO) {
                        val bytes = a.contentResolver.openInputStream(u)?.use { it.readBytes() }
                            ?: throw ActImportException("berkas tidak bisa dibuka")
                        if (bytes.size > 80_000_000) throw ActImportException("berkas terlalu besar (maks 80 MB)")
                        val t = TrackParsers.parse(bytes)
                        ActBuilder.build(t.pts, t.sport, t.name)
                    }
                    val date = act["date"] as String; val st = act["st"] as String
                    val km = act["km"] as Double
                    val existing = state.value.activities.firstOrNull {
                        it.dateIso == date && (it.startTime == st || it.startTime == null) && kotlin.math.abs(it.km - km) < 0.3 && it.type == (if (act["bike"] == true) "bike" else "run")
                    }
                    if (existing != null && existing.detailFile != null) { skipped++; continue }
                    val id = existing?.id ?: a.db.activities().insert(
                        ActivityEntity(
                            dateIso = date, km = km, durationSec = Math.round((act["min"] as Double) * 60).toInt(),
                            avgHr = (act["hr"] as? Double)?.toInt(), maxHr = (act["hrMax"] as? Double)?.toInt(),
                            gain = (act["gain"] as? Double)?.toInt(), startTime = st, name = act["nm"] as String,
                            type = if (act["bike"] == true) "bike" else "run",
                        ),
                    )
                    val file = ActStore.importFileName(id)
                    withContext(Dispatchers.IO) { a.acts.write(file, act) }
                    a.db.activities().setDetail(id, file)
                    if (existing != null) attached++ else added++
                } catch (e: ActImportException) {
                    errs.add("berkas ${i + 1}: ${e.message}")
                } catch (e: Exception) {
                    errs.add("berkas ${i + 1}: ${e.message ?: e.javaClass.simpleName}")
                }
            }
            trackMsg.value = buildString {
                append("$added aktivitas baru")
                if (attached > 0) append(", $attached dilengkapi rute dan grafik")
                if (skipped > 0) append(", $skipped sudah ada")
                if (errs.isNotEmpty()) append(". Gagal: " + errs.joinToString("; "))
                append(".")
            }
        }
    }

    /** Hubungkan langsung ke jam Huawei melalui protokol Bluetooth JoyoFit/Gadgetbridge yang sudah ada di proyek sumber. */
    fun connectWatch(address: String) {
        watchMessage.value = "Menghubungkan ke jam… konfirmasi permintaan ikatan pada layar jam bila muncul."
        watchBridge.connect(address, object : ProtocolGateway.Callback {
            override fun ok(result: JSONObject) {
                KeepAliveConfig.setWanted(a, true)
                val keep = KeepAliveConfig.start(a)
                watchMessage.value = buildString {
                    append("Terhubung: ").append(result.optString("name", "Huawei Watch"))
                    result.optString("model").takeIf { it.isNotBlank() }?.let { append(" · ").append(it) }
                    append(".")
                    if (keep != null) append(" Penjagaan latar belum aktif: ").append(keep)
                    else append(" Penjagaan koneksi latar aktif.")
                }
                syncWatch(false)
            }
            override fun error(code: String, message: String) {
                watchMessage.value = "Gagal menghubungkan [$code]: $message"
            }
        })
    }

    fun disconnectWatch() {
        KeepAliveConfig.setWanted(a, false)
        KeepAliveConfig.stop(a)
        watchBridge.disconnect()
        watchMessage.value = "Jam diputuskan. Data yang sudah tersimpan tidak dihapus."
    }

    fun syncWatch(fullHistory: Boolean = false) {
        if (!watchSyncLock.compareAndSet(false, true)) {
            watchMessage.value = "Sinkronisasi sedang berjalan. Tunggu hingga selesai sebelum meminta sinkronisasi berikutnya."
            return
        }
        watchSyncing.value = true
        watchMessage.value = if (fullHistory) "Mengambil seluruh riwayat dari jam…" else "Menyinkronkan data jam…"
        try {
            watchBridge.sync(fullHistory, object : ProtocolGateway.Callback {
                override fun ok(result: JSONObject) {
                    viewModelScope.launch {
                        try {
                            val imported = withContext(Dispatchers.IO) { importWatchData(fullHistory) }
                            val samples = result.optInt("samples", 0)
                            val sleep = result.optInt("sleep", 0)
                            val workouts = result.optInt("workouts", 0)
                            watchMessage.value = "Sinkron selesai: $samples sampel, $sleep segmen tidur, $workouts workout. " +
                                "${imported.first} hari kondisi diperbarui; ${imported.second} aktivitas diimpor."
                        } catch (e: Exception) {
                            watchMessage.value = "Sinkron jam berhasil, tetapi impor ke EnduranceVault gagal: ${e.message ?: e.javaClass.simpleName}"
                        } finally {
                            watchSyncLock.set(false)
                            watchSyncing.value = false
                        }
                    }
                }
                override fun error(code: String, message: String) {
                    watchMessage.value = "Sinkron gagal [$code]: $message"
                    watchSyncLock.set(false)
                    watchSyncing.value = false
                }
            })
        } catch (e: Exception) {
            watchMessage.value = "Sinkron gagal: ${e.message ?: e.javaClass.simpleName}"
            watchSyncLock.set(false)
            watchSyncing.value = false
        }
    }

    private suspend fun importWatchData(fullHistory: Boolean): Pair<Int, Int> {
        val now = System.currentTimeMillis() / 1000L
        val since = if (fullHistory) 0L else now - 45L * 24L * 3600L
        val zone = ZoneId.systemDefault()
        val offsetMin = zone.rules.getOffset(Instant.now()).totalSeconds / 60
        val dailyPayload = watchBridge.readDaily(since, offsetMin)
        val existingDaily = state.value.daily
        val dailyRows = HuaweiWatchImport.daily(dailyPayload, existingDaily, zone)
        dailyRows.forEach { a.db.companion().saveDaily(it) }

        val workoutPayload = watchBridge.readWorkouts(since, if (fullHistory) 100 else 60).optJSONArray("workouts") ?: JSONArray()
        val existingKeys = state.value.activities.map { it.srcKey }.filter { it.startsWith("watch:") }.toMutableSet()
        var imported = 0
        for (i in 0 until workoutPayload.length()) {
            val w = workoutPayload.optJSONObject(i) ?: continue
            val start = w.optLong("start", 0L)
            val duration = w.optInt("duration", 0)
            val distanceM = w.optInt("distance", 0)
            val sport = w.optInt("sportType", -1)
            if (start <= 0 || duration <= 0 || distanceM <= 0 || w.optBoolean("complete", true).not()) continue
            val type = when (sport) {
                1, 11 -> "run"
                3 -> "bike"
                else -> continue
            }
            val srcKey = "watch:$start"
            if (srcKey in existingKeys) continue
            val startAt = Instant.ofEpochSecond(start).atZone(zone)
            val date = startAt.toLocalDate().toString()
            val time = startAt.toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm"))
            val km = distanceM / 1000.0
            val points = if (w.optInt("gpsPoints", 0) >= 2) {
                runCatching { watchBridge.readWorkoutPoints(start).optJSONArray("points") }.getOrNull()
            } else null

            var detailFile: String? = null
            var gain: Int? = null
            var name = w.optString("sportName", if (type == "bike") "Cycling" else "Huawei Watch Run")
            if (points != null && points.length() >= 2) {
                val gpx = watchPointsToGpx(points, name)
                val built = runCatching {
                    val parsed = TrackParsers.parse(gpx)
                    ActBuilder.build(parsed.pts, parsed.sport, parsed.name)
                }.getOrNull()
                if (built != null) {
                    name = (built["nm"] as? String)?.ifBlank { name } ?: name
                    gain = (built["gain"] as? Double)?.toInt()
                    val id = a.db.activities().insert(
                        ActivityEntity(
                            dateIso = date, km = km, durationSec = duration,
                            avgHr = w.optInt("avgHr").takeIf { it in 30..230 },
                            maxHr = w.optInt("maxHr").takeIf { it in 30..230 },
                            gain = gain, startTime = time, name = name, type = type, srcKey = srcKey,
                            note = watchWorkoutNote(w),
                        ),
                    )
                    val file = ActStore.importFileName(id)
                    val payload = HashMap(built)
                    payload["watch"] = JSONObject(w.toString()).toString()
                    withContext(Dispatchers.IO) { a.acts.write(file, payload) }
                    a.db.activities().setDetail(id, file)
                    detailFile = file
                }
            }
            if (detailFile == null) {
                a.db.activities().insert(
                    ActivityEntity(
                        dateIso = date, km = km, durationSec = duration,
                        avgHr = w.optInt("avgHr").takeIf { it in 30..230 },
                        maxHr = w.optInt("maxHr").takeIf { it in 30..230 },
                        startTime = time, name = name, type = type, srcKey = srcKey,
                        note = watchWorkoutNote(w),
                    ),
                )
            }
            existingKeys.add(srcKey)
            imported++
        }
        return dailyRows.size to imported
    }

    private fun watchWorkoutNote(w: JSONObject): String = JSONObject().apply {
        put("source", "huawei-watch")
        if (w.has("recoveryHours")) put("recoveryHours", w.optDouble("recoveryHours"))
        if (w.has("workoutLoad")) put("workoutLoad", w.optInt("workoutLoad"))
        if (w.has("aerobicEffect")) put("aerobicEffect", w.optDouble("aerobicEffect"))
        if (w.has("anaerobicEffect")) put("anaerobicEffect", w.optDouble("anaerobicEffect"))
        if (w.has("recoveryHr")) put("recoveryHr", w.optJSONArray("recoveryHr"))
    }.toString()

    private fun watchPointsToGpx(points: JSONArray, title: String): ByteArray {
        val out = StringBuilder()
        out.append("""<?xml version="1.0" encoding="UTF-8"?><gpx version="1.1" creator="EnduranceVault" xmlns="http://www.topografix.com/GPX/1/1" xmlns:gpxtpx="http://www.garmin.com/xmlschemas/TrackPointExtension/v1"><trk><name>""")
        out.append(title.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))
        out.append("</name><trkseg>")
        for (i in 0 until points.length()) {
            val p = points.optJSONObject(i) ?: continue
            if (p.isNull("lat") || p.isNull("lon")) continue
            val lat = p.optDouble("lat", Double.NaN)
            val lon = p.optDouble("lon", Double.NaN)
            if (!lat.isFinite() || !lon.isFinite() || lat !in -90.0..90.0 || lon !in -180.0..180.0) continue
            out.append("<trkpt lat=\"").append(lat).append("\" lon=\"").append(lon).append("\">")
            if (!p.isNull("alt")) out.append("<ele>").append(p.optDouble("alt")).append("</ele>")
            val ts = p.optLong("ts", 0L)
            if (ts > 0) out.append("<time>").append(Instant.ofEpochSecond(ts).toString()).append("</time>")
            val hr = p.optInt("hr", 0)
            val cad = p.optInt("cad", 0)
            if (hr > 0 || cad > 0) {
                out.append("<extensions><gpxtpx:TrackPointExtension>")
                if (hr > 0) out.append("<gpxtpx:hr>").append(hr).append("</gpxtpx:hr>")
                if (cad > 0) out.append("<gpxtpx:cad>").append(cad).append("</gpxtpx:cad>")
                out.append("</gpxtpx:TrackPointExtension></extensions>")
            }
            out.append("</trkpt>")
        }
        out.append("</trkseg></trk></gpx>")
        return out.toString().toByteArray(Charsets.UTF_8)
    }

    fun clearTrackMsg() { trackMsg.value = null }

    /** Baca detail (rute, split, grafik) satu aktivitas dari berkasnya. */
    suspend fun detailOf(e: ActivityEntity): ActDetail? = withContext(Dispatchers.IO) { e.detailFile?.let { a.acts.read(it) } }

    fun dismissImport() { importState.value = ImportUi.Idle }
}
