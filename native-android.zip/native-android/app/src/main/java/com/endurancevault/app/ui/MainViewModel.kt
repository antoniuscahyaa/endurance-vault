package com.endurancevault.app.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.endurancevault.app.EnduranceVaultApp
import com.endurancevault.app.data.ActStore
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.data.BackupException
import com.endurancevault.app.data.BackupParser
import com.endurancevault.app.data.KvEntity
import com.endurancevault.app.data.ParsedBackup
import com.endurancevault.app.data.TrackParsers
import com.endurancevault.app.domain.ActBuilder
import com.endurancevault.app.domain.ActImportException
import com.endurancevault.app.domain.ActDetail
import com.endurancevault.app.domain.EasyPace
import com.endurancevault.app.domain.PlanEngine
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.PlanSettings
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class UiState(
    val settings: PlanSettings,
    val plan: PlanOutcome,
    val activities: List<ActivityEntity>,
)

sealed interface ImportUi {
    data object Idle : ImportUi
    data object Working : ImportUi
    class Confirm(val backup: ParsedBackup, val file: File) : ImportUi
    class Done(val message: String) : ImportUi
    class Failed(val message: String) : ImportUi
}

/** Pace easy dari lari tercatat (null bila belum ada pekan lengkap sebelum pekan ini). */
internal fun easyPaceOf(s: PlanSettings, acts: List<ActivityEntity>): Double? {
    val runs = acts.map { EasyPace.Run(it.dateIso, it.km, it.durationSec / 60.0, it.avgHr, it.type, it.gain) }
    return EasyPace.estimate(runs, EasyPace.sessHr(s))?.pace?.takeIf { it > 0 }
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val a = app as EnduranceVaultApp
    private val settingsFlow = MutableStateFlow(a.settings.load())

    val state: StateFlow<UiState> = combine(settingsFlow, a.db.activities().observeAll()) { s, acts ->
        UiState(s, PlanEngine.plan(s, easyPace = easyPaceOf(s, acts)), acts)
    }.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5_000),
        UiState(settingsFlow.value, PlanEngine.plan(settingsFlow.value), emptyList()),
    )

    val importState = MutableStateFlow<ImportUi>(ImportUi.Idle)

    /** Pesan hasil impor berkas FIT/GPX/TCX (null = tidak ada). */
    val trackMsg = MutableStateFlow<String?>(null)

    fun saveSettings(s: PlanSettings) {
        a.settings.save(s)
        settingsFlow.update { s }
    }

    fun addActivity(e: ActivityEntity) = viewModelScope.launch { a.db.activities().insert(e) }
    fun deleteActivity(id: Long) = viewModelScope.launch { a.db.activities().delete(id) }

    /** Salin berkas ke penyimpanan aplikasi (utuh, tanpa kehilangan data), lalu baca ringkasannya. */
    fun startImport(uri: Uri) {
        importState.value = ImportUi.Working
        viewModelScope.launch {
            importState.value = try {
                val picked = withContext(Dispatchers.IO) {
                    val dir = File(a.filesDir, "imports").apply { mkdirs() }
                    val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
                    val f = File(dir, "cadangan-web-$stamp.json")
                    val ins = a.contentResolver.openInputStream(uri) ?: throw BackupException("Berkas tidak bisa dibuka.")
                    ins.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                    try {
                        f to f.inputStream().use { BackupParser.parse(it) }
                    } catch (e: BackupException) {
                        f.delete(); throw e
                    }
                }
                ImportUi.Confirm(picked.second, picked.first)
            } catch (e: BackupException) {
                ImportUi.Failed(e.message ?: "Cadangan tidak bisa dibaca.")
            } catch (e: Exception) {
                ImportUi.Failed("Gagal membaca berkas: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    fun confirmImport() {
        val c = importState.value as? ImportUi.Confirm ?: return
        importState.value = ImportUi.Working
        viewModelScope.launch {
            try {
                // Lintasan kedua: salin rute GPS dan grafik tiap aktivitas ke berkas terpisah
                val keys = withContext(Dispatchers.IO) {
                    a.acts.clearBackupFiles()
                    c.file.inputStream().use { BackupParser.extractActs(it, a.acts.dir) }
                }.toSet()
                val list = c.backup.activities.map {
                    if (it.srcKey in keys) it.copy(detailFile = ActStore.backupFileName(it.srcKey)) else it
                }
                a.db.activities().replaceImported(list)
                a.db.companion().replaceAll(c.backup.daily, c.backup.gear, c.backup.kv.map { KvEntity(it.key, it.value) })
                saveSettings(c.backup.settings)
                importState.value = ImportUi.Done(
                    "Pengaturan rencana, ${list.size} catatan lari (${list.count { it.detailFile != null }} dengan rute dan grafik), " +
                        "${c.backup.daily.size} catatan harian, dan ${c.backup.gear.size} gear dipulihkan. " +
                        "Salinan lengkap cadangan disimpan di penyimpanan aplikasi.",
                )
            } catch (e: Exception) {
                importState.value = ImportUi.Failed("Gagal memulihkan: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    /** Impor satu atau beberapa berkas FIT/GPX/TCX sebagai aktivitas dengan rute dan grafik. */
    fun importTracks(uris: List<Uri>) {
        trackMsg.value = "Membaca ${uris.size} berkas…"
        viewModelScope.launch {
            var added = 0; var attached = 0; var skipped = 0
            val errs = mutableListOf<String>()
            for ((i, u) in uris.withIndex()) {
                try {
                    val act = withContext(Dispatchers.IO) {
                        val bytes = a.contentResolver.openInputStream(u)?.use { it.readBytes() }
                            ?: throw ActImportException("berkas tidak bisa dibuka")
                        if (bytes.size > 80_000_000) throw ActImportException("berkas terlalu besar (maks 80 MB)")
                        val t = TrackParsers.parse(bytes)
                        ActBuilder.build(t.pts, t.sport, t.name)
                    }
                    val date = act["date"] as String; val st = act["st"] as String
                    val km = act["km"] as Double
                    val existing = state.value.activities.firstOrNull {
                        it.dateIso == date && (it.startTime == st || it.startTime == null) && kotlin.math.abs(it.km - km) < 0.3 && it.type == (if (act["bike"] == true) "bike" else "run")
                    }
                    if (existing != null && existing.detailFile != null) { skipped++; continue }
                    val id = existing?.id ?: a.db.activities().insert(
                        ActivityEntity(
                            dateIso = date, km = km, durationSec = Math.round((act["min"] as Double) * 60).toInt(),
                            avgHr = (act["hr"] as? Double)?.toInt(), maxHr = (act["hrMax"] as? Double)?.toInt(),
                            gain = (act["gain"] as? Double)?.toInt(), startTime = st, name = act["nm"] as String,
                            type = if (act["bike"] == true) "bike" else "run",
                        ),
                    )
                    val file = ActStore.importFileName(id)
                    withContext(Dispatchers.IO) { a.acts.write(file, act) }
                    a.db.activities().setDetail(id, file)
                    if (existing != null) attached++ else added++
                } catch (e: ActImportException) {
                    errs.add("berkas ${i + 1}: ${e.message}")
                } catch (e: Exception) {
                    errs.add("berkas ${i + 1}: ${e.message ?: e.javaClass.simpleName}")
                }
            }
            trackMsg.value = buildString {
                append("$added aktivitas baru")
                if (attached > 0) append(", $attached dilengkapi rute dan grafik")
                if (skipped > 0) append(", $skipped sudah ada")
                if (errs.isNotEmpty()) append(". Gagal: " + errs.joinToString("; "))
                append(".")
            }
        }
    }

    fun clearTrackMsg() { trackMsg.value = null }

    /** Baca detail (rute, split, grafik) satu aktivitas dari berkasnya. */
    suspend fun detailOf(e: ActivityEntity): ActDetail? = withContext(Dispatchers.IO) { e.detailFile?.let { a.acts.read(it) } }

    fun dismissImport() { importState.value = ImportUi.Idle }
}
