package com.endurancevault.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.endurancevault.app.EnduranceVaultApp
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.domain.PlanEngine
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.PlanSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class UiState(
    val settings: PlanSettings,
    val plan: PlanOutcome,
    val activities: List<ActivityEntity>,
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val a = app as EnduranceVaultApp
    private val settingsFlow = MutableStateFlow(a.settings.load())

    val state: StateFlow<UiState> = combine(settingsFlow, a.db.activities().observeAll()) { s, acts ->
        UiState(s, PlanEngine.plan(s), acts)
    }.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5_000),
        UiState(settingsFlow.value, PlanEngine.plan(settingsFlow.value), emptyList()),
    )

    fun saveSettings(s: PlanSettings) {
        a.settings.save(s)
        settingsFlow.update { s }
    }

    fun addActivity(e: ActivityEntity) = viewModelScope.launch { a.db.activities().insert(e) }
    fun deleteActivity(id: Long) = viewModelScope.launch { a.db.activities().delete(id) }
}
