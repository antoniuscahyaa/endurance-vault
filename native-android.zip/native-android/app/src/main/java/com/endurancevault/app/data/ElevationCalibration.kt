package com.endurancevault.app.data

import org.json.JSONObject

/**
 * Menyelaraskan elevasi hasil hitung aplikasi (dari altitude rute) dengan total elevasi yang dicatat jam.
 *
 * Aplikasi menjumlahkan perubahan altitude dengan ambang histeresis (lihat `ActBuilder`), jam memakai algoritmanya
 * sendiri, jadi angkanya bisa berbeda beberapa persen. Karena yang tampil di layar jam adalah rujukan pengguna,
 * Elevation Gain/Loss aktivitas diganti dengan angka jam, dan Elev. Gain/Loss tiap km diskalakan dengan rasio yang sama
 * agar jumlah per km tetap sejalan dengan totalnya. Profil elevasi (grafik) tidak diubah.
 *
 * Angka jam yang sebenarnya hanya jumlah sampel mentah (`*Source` bukan "watch") dan sering membengkak karena derau
 * barometer; angka seperti itu hanya dipakai bila rasionya masuk akal ([MIN_RATIO]..[MAX_RATIO]).
 */
object ElevationCalibration {
    const val MIN_RATIO = 0.6
    const val MAX_RATIO = 1.6

    /** Total hitungan aplikasi di bawah ini terlalu kecil untuk dijadikan pembagi rasio yang stabil. */
    private const val MIN_COMPUTED_M = 10.0

    private fun JSONObject.meters(key: String): Double? {
        if (!has(key) || isNull(key)) return null
        val v = optDouble(key, Double.NaN)
        return if (v.isNaN() || v.isInfinite() || v < 0) null else v
    }

    /** Hasil kalibrasi satu sisi (naik atau turun): total baru dan faktor skala split (null = split tidak diubah). */
    private class Side(val total: Double, val factor: Double?)

    private fun side(computed: Double?, watch: Double?, trusted: Boolean): Side? {
        if (watch == null) return null
        if (computed == null) return Side(watch, null) // rute tanpa altitude: pakai angka jam apa adanya
        if (computed < MIN_COMPUTED_M || watch <= 0.0) return if (trusted) Side(watch, null) else null
        val ratio = watch / computed
        if (!trusted && ratio !in MIN_RATIO..MAX_RATIO) return null
        return Side(watch, ratio)
    }

    /**
     * @param act objek aktivitas dari `ActBuilder.build` (tidak diubah)
     * @param watch baris workout dari `readWorkouts` (membawa elevationGain/Loss dan `*Source`)
     * @return salinan [act] dengan `gain`/`loss` dan `g`/`l` per split diselaraskan; `gainRaw`/`lossRaw` menyimpan
     *         hitungan aplikasi sebelum kalibrasi
     */
    fun calibrate(act: Map<String, Any?>, watch: JSONObject): Map<String, Any?> {
        val out = LinkedHashMap(act)
        val gain = side(act["gain"] as? Double, watch.meters("elevationGain"), watch.optString("elevationGainSource") == "watch")
        val loss = side(act["loss"] as? Double, watch.meters("elevationLoss"), watch.optString("elevationLossSource") == "watch")
        if (gain == null && loss == null) return out

        if (gain != null) {
            (act["gain"] as? Double)?.let { out["gainRaw"] = it }
            out["gain"] = Math.round(gain.total).toDouble()
        }
        if (loss != null) {
            (act["loss"] as? Double)?.let { out["lossRaw"] = it }
            out["loss"] = Math.round(loss.total).toDouble()
        }
        val gf = gain?.factor; val lf = loss?.factor
        if (gf != null || lf != null) {
            @Suppress("UNCHECKED_CAST")
            val splits = act["sp"] as? List<Map<String, Any?>>
            if (splits != null) {
                out["sp"] = splits.map { s ->
                    val m = LinkedHashMap(s)
                    if (gf != null) (s["g"] as? Number)?.let { m["g"] = Math.round(it.toDouble() * gf).toDouble() }
                    if (lf != null) (s["l"] as? Number)?.let { m["l"] = Math.round(it.toDouble() * lf).toDouble() }
                    m
                }
            }
        }
        return out
    }
}
