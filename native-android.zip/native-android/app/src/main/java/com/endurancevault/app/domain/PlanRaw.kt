package com.endurancevault.app.domain

import java.time.LocalDate

/**
 * Padanan planRaw(s) di web (03-perencana-gear-statistik.js): sebelum plan() dipanggil, HR easy dan rentang threshold sesi
 * diturunkan dari zona HR (zoneSessFor), dan pace diganti pace easy dari lari tercatat. Tanpa langkah ini, teks "HR ≤ ..." dan
 * band threshold memakai angka manual lama, bukan zona yang berlaku.
 */
object PlanRaw {
    fun settingsFor(s: PlanSettings, easyPace: Double?, restDefault: Int = 55): PlanSettings {
        val zc = Zones.cuts(s, restDefault)
        val (hr, thr) = Zones.sessionRefs(zc)
        return s.copy(
            pace = if (easyPace != null && easyPace > 0) Js.paceStr(easyPace) else s.pace,
            hr = hr,
            thrSrc = s.thrSrc ?: s.thr,
            thr = "${thr.first}–${thr.last}",
        )
    }

    fun plan(s: PlanSettings, today: LocalDate = LocalDate.now(), easyPace: Double? = null, restDefault: Int = 55): PlanOutcome =
        PlanEngine.plan(settingsFor(s, easyPace, restDefault), today, easyPace)
}
