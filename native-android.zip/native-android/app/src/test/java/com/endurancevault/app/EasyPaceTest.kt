package com.endurancevault.app

import com.endurancevault.app.domain.EasyPace
import com.endurancevault.app.domain.EasyPace.Run
import com.endurancevault.app.domain.PlanEngine
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.PlanSettings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

/** Padanan easyWeeks/easyPaceEst di web (03-perencana-gear-statistik.js). */
class EasyPaceTest {
    private val today = LocalDate.of(2026, 11, 5) // Kamis; pekan berjalan mulai 2026-11-02

    @Test fun hanyaLariEasyYangDihitung() {
        val runs = listOf(
            Run("2026-10-27", 10.0, 70.0, 140),               // 7:00/km, ikut
            Run("2026-10-29", 5.0, 30.0, 145),                // 6:00/km, ikut
            Run("2026-10-30", 8.0, 40.0, 170),                // HR di atas batas, tidak ikut
            Run("2026-10-31", 12.0, 60.0, 140, type = "bike"), // sepeda, tidak ikut
            Run("2026-10-28", 5.0, 25.0, 140, gain = 150),    // 30 m/km, tidak ikut
            Run("2026-10-26", 5.0, 30.0, null),               // tanpa HR, tidak ikut
        )
        val w = EasyPace.weeks(runs, 150)
        assertEquals(1, w.size)
        assertEquals("2026-10-26", w[0].week)
        assertEquals(2, w[0].n)
        assertEquals(15.0, w[0].km, 1e-9)
        assertEquals(100.0 / 15.0, w[0].pace, 1e-9)
        assertEquals((140 * 70 + 145 * 30) / 100.0, w[0].hr, 1e-9)
    }

    @Test fun pekanBerjalanTidakDipakaiSebagaiEstimasi() {
        val runs = listOf(
            Run("2026-10-20", 10.0, 70.0, 140),   // pekan 2026-10-19
            Run("2026-11-03", 10.0, 50.0, 140),   // pekan berjalan
        )
        val e = EasyPace.estimate(runs, 150, today)
        assertNotNull(e)
        assertEquals("2026-10-19", e!!.week)
        assertEquals(7.0, e.pace, 1e-9)
        assertNull(EasyPace.estimate(listOf(Run("2026-11-03", 10.0, 50.0, 140)), 150, today))
    }

    @Test fun planMemakaiPaceEasyDariLog() {
        val s = PlanSettings(rtype = "hm", start = LocalDate.of(2026, 11, 2), race = LocalDate.of(2027, 2, 21), pace = "6:30", goalT = "1:45:00", qSess = "1")
        fun detailQ(o: PlanOutcome): String {
            o as PlanOutcome.Ok
            return o.weeks.flatMap { it.days }.filter { it.role == "quality" }.joinToString("|") { it.detail }
        }
        val a = PlanEngine.plan(s, today)
        val b = PlanEngine.plan(s, today, easyPace = 5.0)
        assertTrue(a is PlanOutcome.Ok && b is PlanOutcome.Ok)
        assertNotEquals(detailQ(a), detailQ(b))
        assertEquals(detailQ(a), detailQ(PlanEngine.plan(s, today, easyPace = null)))
    }
}
