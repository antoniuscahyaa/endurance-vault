package com.endurancevault.app

import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.domain.ActivityAnalytics
import com.endurancevault.app.domain.Split
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.time.LocalDate

class ActivityAnalyticsTest {
    @Test fun summaryExcludesBikeAndFutureRecordsFrom28Days() {
        val rows = listOf(
            ActivityEntity(dateIso = "2026-11-05", km = 10.0, durationSec = 3600),
            ActivityEntity(dateIso = "2026-10-20", km = 5.0, durationSec = 1800),
            ActivityEntity(dateIso = "2026-11-04", km = 30.0, durationSec = 3600, type = "bike"),
            ActivityEntity(dateIso = "2026-11-07", km = 8.0, durationSec = 2400),
        )
        val s = ActivityAnalytics.summarize(rows, LocalDate.parse("2026-11-06"))
        assertEquals(3, s.runCount)
        assertEquals(23.0, s.totalKm, 1e-9)
        assertEquals(15.0, s.last28Km, 1e-9)
        assertEquals(2, s.last28Runs)
        assertEquals(10.0, s.longestKm!!, 1e-9)
    }

    @Test fun compareHalvesWeightsPaceByDistanceAndIgnoresPartial() {
        val result = ActivityAnalytics.compareHalves(listOf(
            Split(1.0, 6.0, null, 0, 0, null, null, false),
            Split(1.0, 7.0, null, 0, 0, null, null, false),
            Split(0.4, 10.0, null, 0, 0, null, null, true),
        ))!!
        assertEquals(6.0, result.firstPace, 1e-9)
        assertEquals(7.0, result.secondPace, 1e-9)
        assertEquals(100.0 / 6.0, result.changePercent, 1e-9)
    }

    @Test fun oneFullSplitIsInsufficientForHalfComparison() {
        assertNull(ActivityAnalytics.compareHalves(listOf(Split(1.0, 6.0, null, 0, 0, null, null, false))))
    }
}
