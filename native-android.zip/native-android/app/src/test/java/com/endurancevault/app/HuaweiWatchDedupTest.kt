package com.endurancevault.app

import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.ui.watchWorkoutMatches
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HuaweiWatchDedupTest {
    private val existing = ActivityEntity(
        id = 42, dateIso = "2026-11-05", km = 8.8, durationSec = 3300,
        avgHr = 154, startTime = "06:30", name = "Morning run", type = "run",
    )

    @Test fun sameWorkoutFromBackupIsMatched() {
        assertTrue(watchWorkoutMatches(existing, "2026-11-05", "06:33", 8.9, 3420, "run"))
    }

    @Test fun differentTimeOrDistanceIsNotMatched() {
        assertFalse(watchWorkoutMatches(existing, "2026-11-05", "08:00", 8.9, 3420, "run"))
        assertFalse(watchWorkoutMatches(existing, "2026-11-05", "06:32", 15.0, 3420, "run"))
        assertFalse(watchWorkoutMatches(existing, "2026-11-05", "06:32", 8.9, 3420, "bike"))
    }
}
