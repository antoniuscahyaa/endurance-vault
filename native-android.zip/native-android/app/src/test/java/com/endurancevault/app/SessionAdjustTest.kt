package com.endurancevault.app

import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

/** Uji logika tukar hari, libur dadakan, geser dan lewati (port dari rencana-lari). Minggu uji: Sen 2 Nov 2026 – Min 8 Nov 2026. */
class SessionAdjustTest {
    private val mon = LocalDate.of(2026, 11, 2)

    private fun plan(): PlanOutcome.Ok {
        fun day(i: Int, kind: String, title: String, km: Double) =
            PDay(mon.plusDays(i.toLong()), i, kind, kind, title, km, "detail $title")
        val days = mutableListOf(
            day(0, Kinds.REST, "Libur", 0.0), day(1, Kinds.EASY, "Easy", 10.0), day(2, Kinds.QUALITY, "Threshold", 8.0),
            day(3, Kinds.EASY, "Easy", 6.0), day(4, Kinds.REST, "Libur", 0.0), day(5, Kinds.EASY, "Easy", 6.0), day(6, Kinds.LONG, "Long run", 20.0),
        )
        val week = PWeek(0, mon, mon.plusDays(6), Phases.BUILD, false, false, false, days, 50.0)
        return PlanOutcome.Ok(listOf(week), mon, mon.plusDays(60), 9, false, false, true, 0, 0)
    }

    private fun inp(today: LocalDate, mv: Map<String, MvEntry> = emptyMap(), logged: Map<String, Double> = emptyMap(), done: Set<String> = emptySet()) =
        AdjInput(today, mv, done, logged, 150)

    private fun days(p: PlanOutcome.Ok) = p.weeks.single().days

    @Test fun swapExchangesSessionContentButKeepsDates() {
        val p = plan(); val wed = mon.plusDays(2); val thu = mon.plusDays(3)
        SessionAdjust.apply(p, inp(wed, mapOf("sw:$wed" to MvEntry("sw", to = thu.toString()))))
        val d = days(p)
        assertEquals(Kinds.EASY, d[2].kind); assertEquals(6.0, d[2].km, 0.0001)
        assertEquals(Kinds.QUALITY, d[3].kind); assertEquals(8.0, d[3].km, 0.0001)
        assertEquals(wed, d[2].date)
        assertEquals("Ditukar dengan Kam 5 Nov", d[2].adj!!.text)
        assertTrue(d[2].mvUndo); assertEquals("sw:$wed", d[3].mvSw)
    }

    @Test fun swapListCoversRestDaysAndWarnsOnNewConsecutiveHardPair() {
        val p = plan(); val wed = mon.plusDays(2)
        SessionAdjust.apply(p, inp(wed))
        val opts = days(p)[2].swList.associateBy { it.date.dayOfWeek.value }
        assertEquals(setOf(4, 5, 6, 7), opts.keys)             // Kam, Jum (libur), Sab, Min
        assertEquals("Libur", opts[5]!!.what)
        assertTrue(opts[6]!!.warn)                              // quality ke Sabtu bersebelahan dengan long run
        assertFalse(opts[4]!!.warn)
    }

    @Test fun swapIsNotOfferedForDoneOrPastSessions() {
        val p = plan(); val wed = mon.plusDays(2)
        SessionAdjust.apply(p, inp(wed, logged = mapOf(mon.plusDays(3).toString() to 6.0)))
        assertTrue(days(p)[2].swList.none { it.date == mon.plusDays(3) })
        assertTrue(days(p)[1].swList.isEmpty())                 // Selasa sudah lewat
    }

    @Test fun spreadDistributionFollowsWebCaps() {
        val p = plan(); val thu = mon.plusDays(3)
        val all = SessionAdjust.flatten(p)
        val r = SessionAdjust.spDist(all, all[3], false, 1.0, inp(thu))
        assertEquals(2, r.items.size)
        assertEquals(2.5, r.items[0].x, 0.0001)                 // Sabtu: maks +40% dari 6 km = 2,5
        assertEquals(3.5, r.items[1].x, 0.0001)                 // Minggu: sisa, batas 25% dari 20 = 5
        assertEquals(0.0, r.left, 0.0001)
    }

    @Test fun spreadMovesKmAndKeepsWeekTotal() {
        val p = plan(); val thu = mon.plusDays(3)
        val e = MvEntry("spread", why = "sibuk", km = 6.0, spread = listOf(mon.plusDays(5).toString() to 2.5, mon.plusDays(6).toString() to 3.5))
        SessionAdjust.apply(p, inp(thu, mapOf(thu.toString() to e)))
        val d = days(p)
        assertEquals(0.0, d[3].km, 0.0001); assertEquals("spread", d[3].adj!!.type); assertEquals(6.0, d[3].mvKm!!, 0.0001)
        assertEquals(8.5, d[5].km, 0.0001); assertEquals(23.5, d[6].km, 0.0001)
        assertEquals(50.0, p.weeks.single().km, 0.0001)
        assertTrue(d[3].mvUndo)
    }

    @Test fun spreadLevelsFollowConditionRules() {
        assertEquals(2, SessionAdjust.spLevel(false, 40, 50, 65, "sibuk"))
        assertEquals(1, SessionAdjust.spLevel(false, 60, 50, 65, "sibuk"))
        assertEquals(1, SessionAdjust.spLevel(false, -1, 50, 65, "capek"))
        assertEquals(2, SessionAdjust.spLevel(true, 80, 50, 65, "sibuk"))
        assertEquals(2, SessionAdjust.spLevel(false, 90, 50, 65, "sakit"))
        assertEquals(0, SessionAdjust.spLevel(false, 90, 50, 65, "sibuk"))
    }

    @Test fun clampKeepsManualValuesInsideCapsAndSourceKm() {
        val p = plan(); val all = SessionAdjust.flatten(p)
        val items = listOf(SpItem(all[5], 9.0, 2.5, false), SpItem(all[6], 9.0, 5.0, false))
        val left = SessionAdjust.spClamp(items, 6.0, 0.0)
        assertEquals(2.5, items[0].x, 0.0001); assertEquals(3.5, items[1].x, 0.0001)
        assertEquals(0.0, left, 0.0001)
    }

    @Test fun missedQualityShiftsToNextEasyDay() {
        val p = plan(); val thu = mon.plusDays(3)
        SessionAdjust.apply(p, inp(thu))
        val d = days(p)
        assertEquals(Kinds.QUALITY, d[3].kind)
        assertEquals("Digeser dari Rab 4 Nov", d[3].adj!!.text)
        assertEquals("out", d[2].adj!!.type)
        assertEquals("miss", d[1].adj!!.type)                   // Selasa easy tidak dilari
    }

    @Test fun loggedSessionIsNotMissed() {
        val p = plan(); val thu = mon.plusDays(3)
        SessionAdjust.apply(p, inp(thu, logged = mapOf(mon.plusDays(1).toString() to 10.0)))
        assertNull(days(p)[1].adj)
    }

    @Test fun skipRemovesKmFromWeekAndCanBeUndone() {
        val p = plan(); val thu = mon.plusDays(3); val tue = mon.plusDays(1)
        SessionAdjust.apply(p, inp(thu, mapOf(tue.toString() to MvEntry("skip"))))
        val d = days(p)
        assertEquals("skip", d[1].adj!!.type); assertEquals(0.0, d[1].km, 0.0001); assertEquals(10.0, d[1].mvKm!!, 0.0001)
        assertEquals(40.0, p.weeks.single().km, 0.0001); assertTrue(d[1].mvUndo)
    }

    @Test fun missedSessionCanBeMovedToAnotherDay() {
        val p = plan(); val thu = mon.plusDays(3); val tue = mon.plusDays(1); val sat = mon.plusDays(5)
        SessionAdjust.apply(p, inp(thu, mapOf(tue.toString() to MvEntry("mv", to = sat.toString()))))
        val d = days(p)
        assertEquals(10.0, d[5].km, 0.0001); assertEquals("in", d[5].adj!!.type)
        assertEquals("out", d[1].adj!!.type); assertEquals(0.0, d[1].km, 0.0001)
    }

    @Test fun completionAcceptsWatchRunsButNotFreeRuns() {
        fun act(src: String, km: Double) = ActivityEntity(dateIso = "2026-11-03", km = km, durationSec = 3600, srcKey = src)
        assertEquals(10.0, SessionAdjust.primaryRun(listOf(act("watch:1", 10.0), act("2026-11-03~f1", 3.0)), "2026-11-03")!!.km, 0.0001)
        assertNull(SessionAdjust.primaryRun(listOf(act("2026-11-03~f1", 3.0)), "2026-11-03"))
        assertEquals(5.0, SessionAdjust.primaryRun(listOf(act("watch:1", 12.0), act("2026-11-03", 5.0)), "2026-11-03")!!.km, 0.0001) // yang bertaut (srcKey = tanggal) menang
        assertEquals(mapOf("2026-11-03" to 10.0), SessionAdjust.loggedKm(listOf(act("watch:1", 10.0))))
    }
}
