package com.endurancevault.app

import com.endurancevault.app.domain.ActivityTimeSeries
import com.endurancevault.app.domain.WatchLaps
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WatchLapsTest {
    /** 0..[total] dtk, 3 m/dtk konstan. */
    private fun ts(total: Int): ActivityTimeSeries {
        val sec = (0..total).toList()
        return ActivityTimeSeries(
            seconds = sec, distanceMeters = sec.map { it * 3.0 },
            heartRateBpm = sec.map { 150 }, cadenceSpm = sec.map { 170 },
            elevationMeters = sec.map { 10.0 }, gapSpeedCmPerSec = sec.map { 0 }, grade = sec.map { null },
        )
    }

    @Test fun realLapsBecomeUnlabeledSegments() {
        // 2700 m total: 900 + 300 + 900 + 300 + 300
        val p = WatchLaps.draftsFromSections(ts(900), listOf(900.0, 300.0, 900.0, 300.0, 300.0))
        assertNotNull(p)
        assertEquals(listOf(300, 400, 700, 800, 900), p!!.map { it.endSec })
        assertTrue(p.all { it.kind == null })
    }

    @Test fun autoKmBlocksAreSkipped() {
        // 3 km + sisa 400 m: pemisah otomatis per km
        val t = ts(1133)
        assertTrue(WatchLaps.isAutoKm(listOf(1000.0, 1000.0, 1000.0, 400.0)))
        assertNull(WatchLaps.draftsFromSections(t, listOf(1000.0, 1000.0, 1000.0, 400.0)))
    }

    @Test fun mixedBlocksAreNotAutoKm() {
        assertFalse(WatchLaps.isAutoKm(listOf(1000.0, 400.0, 1000.0)))
        assertFalse(WatchLaps.isAutoKm(listOf(5000.0)))
    }

    @Test fun mismatchedTotalIsRejected() {
        // total deret 2700 m, blok berjumlah 27000 (satuan salah)
        assertNull(WatchLaps.draftsFromSections(ts(900), listOf(9000.0, 3000.0, 9000.0, 3000.0, 3000.0)))
    }

    @Test fun invalidBlocksAreRejected() {
        assertNull(WatchLaps.draftsFromSections(ts(900), emptyList()))
        assertNull(WatchLaps.draftsFromSections(ts(900), listOf(2700.0)))
        assertNull(WatchLaps.draftsFromSections(ts(900), listOf(1350.0, Double.NaN)))
        assertNull(WatchLaps.draftsFromSections(ts(900), listOf(1350.0, -1.0, 1350.0)))
    }

    @Test fun lastSegmentAbsorbsSmallDifference() {
        // blok berjumlah 2650 m (sesi 2700 m, selisih <10%); segmen terakhir menyerap sisanya
        val p = WatchLaps.draftsFromSections(ts(900), listOf(1200.0, 450.0, 1000.0))!!
        assertEquals(900, p.last().endSec)
        assertEquals(3, p.size)
    }
}
