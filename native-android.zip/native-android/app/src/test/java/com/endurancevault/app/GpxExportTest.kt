package com.endurancevault.app

import com.endurancevault.app.domain.ActBuilder
import com.endurancevault.app.domain.ActCrop
import com.endurancevault.app.domain.ActDetail
import com.endurancevault.app.domain.ActivityTimeSeries
import com.endurancevault.app.domain.GpxExport
import com.endurancevault.app.domain.GpsTrackCodec
import com.endurancevault.app.domain.Pt
import com.endurancevault.app.domain.RouteGeo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.ZoneOffset
import kotlin.math.abs

class GpxExportTest {
    private fun detail(withSeries: Boolean = true, withGeo: Boolean = true, bike: Boolean = false): ActDetail {
        val n = 601
        val ts = if (withSeries) ActivityTimeSeries(
            seconds = (0 until n).toList(),
            distanceMeters = (0 until n).map { it * 18.5 },
            heartRateBpm = (0 until n).map { if (it < 10) 0 else 150 },
            cadenceSpm = (0 until n).map { 172 },
            elevationMeters = (0 until n).map { if (it == 3) null else 10.0 + it * 0.01 },
            gapSpeedCmPerSec = List(n) { 0 },
            grade = List(n) { null },
        ) else null
        return ActDetail(
            date = "2026-11-08", startTime = "06:00", name = "Lari <pagi> & santai", bike = bike, kind = "easy",
            km = 11.1, movingMin = 10.0, elapsedMin = 12.0, gain = 6, loss = 0, hr = 150, hrMax = 160, cad = 172, gapPace = null,
            splits = emptyList(), segments = emptyList(),
            route = listOf(0 to 500, 500 to 500, 1000 to 500), routeW = 1000, routeH = 1000,
            profile = emptyList(), paceSeries = emptyList(), hrSeries = emptyList(), cadSeries = emptyList(), hrHist = emptyMap(),
            timeSeries = ts, startEpochMs = 1_762_585_200_000L,
            geo = if (withGeo) RouteGeo.Frame(106.8, -6.2, 10000.0, 0.994) else null,
        )
    }

    @Test fun buildsOnePointPerSecondWithSensors() {
        val r = GpxExport.build(detail(), "Lari <pagi> & santai")!!
        assertEquals(601, r.points)
        assertEquals(601, Regex("<trkpt ").findAll(r.xml).count())
        assertTrue(r.xml.contains("<time>2026-11-08T"))
        assertTrue(r.xml.contains("<gpxtpx:hr>150</gpxtpx:hr>"))
        assertTrue("kadens lari dibagi dua", r.xml.contains("<gpxtpx:cad>86</gpxtpx:cad>"))
        assertTrue(r.xml.contains("<type>running</type>"))
        assertTrue("karakter XML di-escape", r.xml.contains("Lari &lt;pagi&gt; &amp; santai"))
    }

    @Test fun skipsInvalidHrAndMissingElevation() {
        val r = GpxExport.build(detail(), "x")!!
        val first = r.xml.substringAfter("<trkpt ").substringBefore("</trkpt>")
        assertTrue("HR 0 tidak ditulis", !first.contains("gpxtpx:hr"))
        val fourth = r.xml.split("<trkpt ")[4].substringBefore("</trkpt>")
        assertTrue("elevasi null tidak ditulis", !fourth.contains("<ele>"))
    }

    @Test fun bikeUsesCyclingAndKeepsCadence() {
        val r = GpxExport.build(detail(bike = true), "x")!!
        assertTrue(r.xml.contains("<type>cycling</type>"))
        assertTrue(r.xml.contains("<gpxtpx:cad>172</gpxtpx:cad>"))
    }

    @Test fun reportsPauseAndDistanceGap() {
        val r = GpxExport.build(detail(), "x")!!
        assertTrue(r.warnings.any { it.contains("elapsed") })
    }

    @Test fun nullWithoutRouteOrGeo() {
        assertNull(GpxExport.build(detail(withGeo = false), "x"))
    }

    @Test fun fallsBackToRoutePointsWithoutTimeSeries() {
        val r = GpxExport.build(detail(withSeries = false), "x")
        assertNotNull(r)
        assertEquals(3, r!!.points)
        assertTrue(r.warnings.any { it.contains("per detik") })
    }

    @Test fun fileNameIsSafe() {
        assertEquals("Lari_pagi_santai", GpxExport.safeFileName("Lari <pagi> & santai"))
    }

    // ---- Jejak GPS asli (kunci `gt`) ----

    private val t0 = 1_762_500_000_000.0

    /** Lari 600 dtk dengan tikungan kecil (zig-zag ±15 m) yang akan hilang pada rute ±140 titik, dan jeda 5 menit di tengah. */
    private fun zigzagRun(): Map<String, Any?> {
        val pts = ArrayList<Pt>()
        var wall = 0
        for (s in 0..600) {
            if (s == 300) wall += 300 // jeda 5 menit: tidak ada titik, lalu lanjut
            val zig = if (s % 20 < 10) 0.0 else 0.00014
            pts += Pt(la = -6.2 + s * 0.00003, lo = 106.8 + zig, t = t0 + wall * 1000.0, e = 20.0, h = 150.0, c = 170.0)
            wall++
        }
        return ActBuilder.build(pts, "running", "Zigzag", ZoneOffset.UTC)
    }

    /** Lewat berkas JSON sungguhan (seperti di aplikasi) supaya tipe angka dan pembacaan `gt` ikut teruji. */
    private fun detailOf(act: Map<String, Any?>): ActDetail {
        val dir = java.nio.file.Files.createTempDirectory("ev-gpx").toFile()
        try {
            val store = com.endurancevault.app.data.ActStore(dir)
            store.write("f_1.json", act)
            return store.read("f_1.json")!!
        } finally { dir.deleteRecursively() }
    }

    @Test fun builderStoresOneGpsPointPerSecondAlignedWithSeries() {
        val act = zigzagRun()
        val tl = act["tl"] as Map<*, *>
        val gt = GpsTrackCodec.decode(act["gt"])!!
        assertEquals((tl["s"] as List<*>).size, gt.size)
        // jam dinding memuat jeda 300 dtk, sedangkan detik gerak tidak
        assertTrue(gt.wallSec.last() - gt.wallSec.first() >= 600 + 290)
    }

    @Test fun exactExportKeepsSmallTurnsAndRealClock() {
        val act = zigzagRun()
        val d = detailOf(act)
        val r = GpxExport.build(d, "Zigzag")!!
        assertTrue(r.exact)
        assertEquals(d.timeSeries!!.seconds.size, r.points)
        // jarak dari koordinat ≈ jarak aplikasi (selisih < 2%), tanpa peringatan jarak
        assertTrue("selisih ${r.gpxKm} vs ${r.appKm}", abs(r.gpxKm - r.appKm) / r.appKm < 0.02)
        assertTrue(r.warnings.none { it.contains("Jarak dari koordinat") })
        // jeda terbawa lewat stempel waktu, jadi tidak ada peringatan elapsed
        assertTrue(r.warnings.none { it.contains("elapsed") })
        val times = Regex("<time>([^<]+)</time>").findAll(r.xml).map { java.time.Instant.parse(it.groupValues[1]).epochSecond }.drop(1).toList()
        assertTrue("waktu naik tegas", times.zipWithNext().all { (a, b) -> b > a })
        assertTrue("ada celah jeda", times.zipWithNext().any { (a, b) -> b - a >= 290 })
    }

    @Test fun approximateExportIsMarkedAndCloseToExactShapeOnlyForOldData() {
        val act = HashMap(zigzagRun()); act.remove("gt")
        val old = GpxExport.build(detailOf(act), "Zigzag")!!
        assertEquals(false, old.exact)
        assertTrue(old.warnings.any { it.contains("ditaksir") })
        val exact = GpxExport.build(detailOf(zigzagRun()), "Zigzag")!!
        // rute sederhana memangkas zig-zag sehingga lebih pendek dari jejak asli
        assertTrue(old.gpxKm < exact.gpxKm)
    }

    @Test fun mismatchedTrackFallsBackToApproximate() {
        val act = HashMap(zigzagRun())
        val short = GpsTrackCodec.encode(listOf(-6.2, -6.1999), listOf(106.8, 106.8), listOf(0.0, 1.0))
        act["gt"] = short
        assertNull(detailOf(act).gpsTrack)
        assertEquals(false, GpxExport.build(detailOf(act), "x")!!.exact)
    }

    @Test fun cropKeepsGpsTrackAlignedAndTimesAbsolute() {
        val act = zigzagRun()
        val r = ActCrop.crop(act, 100, 250, ZoneOffset.UTC)
        val d = detailOf(r.act)
        assertNotNull(d.gpsTrack)
        assertEquals(d.timeSeries!!.seconds.size, d.gpsTrack!!.size)
        val full = GpsTrackCodec.decode(act["gt"])!!
        // detik gerak 100 jatuh pada jam dinding yang sama dengan di jejak utuh (waktu tetap relatif terhadap t0 asli)
        val i0 = (act["tl"] as Map<*, *>).let { (it["s"] as List<*>).indexOfFirst { s -> (s as Number).toInt() >= 100 } }
        assertEquals(full.wallSec[i0], d.gpsTrack!!.wallSec.first())
        val gpx = GpxExport.build(d, "x")!!
        assertTrue(gpx.exact)
        assertEquals(d.gpsTrack!!.size, gpx.points)
    }

    @Test fun codecRoundTripAndAlignmentCheck() {
        val lat = listOf(-6.2, -6.199970, -6.199941); val lon = listOf(106.8, 106.80014, 106.80014)
        val enc = GpsTrackCodec.encode(lat, lon, listOf(0.0, 1.0, 2.4))!!
        val dec = GpsTrackCodec.decode(enc)!!
        assertEquals(-6.199941, dec.lat[2], 1e-6)
        assertEquals(106.80014, dec.lon[1], 1e-6)
        assertEquals(listOf(0, 1, 2), dec.wallSec.toList())
        val tl = mapOf("s" to listOf(0, 1, 2), "d" to listOf(0.0, 3.0, 6.0))
        assertTrue(GpsTrackCodec.alignedWith(tl, mapOf("s" to listOf(0, 1, 2), "d" to listOf(0.0, 3.0, 6.4))))
        assertEquals(false, GpsTrackCodec.alignedWith(tl, mapOf("s" to listOf(0, 1), "d" to listOf(0.0, 3.0))))
        assertEquals(false, GpsTrackCodec.alignedWith(tl, mapOf("s" to listOf(0, 1, 2), "d" to listOf(0.0, 3.0, 9.0))))
        assertNull(GpsTrackCodec.decode(emptyMap<String, Any?>()))
    }

    @Test fun noGpsMeansNoTrack() {
        val pts = (0..300).map { s -> Pt(t = t0 + s * 1000.0, d = s * 3.0, h = 150.0) }
        val act = ActBuilder.build(pts, "running", "Treadmill", ZoneOffset.UTC)
        assertNull(act["gt"])
    }
}
