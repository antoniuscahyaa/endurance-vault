package com.endurancevault.app

import com.endurancevault.app.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

class RecapAnalyticsTest {
    private val today = LocalDate.parse("2026-11-04") // Rabu
    private fun d(s: String) = LocalDate.parse(s)
    private fun run(id: Long, date: String, km: Double, min: Double = km * 6, hr: Int? = 140, gain: Double = 0.0, loss: Double? = null, bike: Boolean = false) =
        RecapRun(id, d(date), km, min, hr, gain, loss, bike)
    private fun week(i: Int, start: String, km: Double, kinds: List<String>): RecapPlanWeek {
        val s = d(start)
        return RecapPlanWeek(i, s, km, kinds.mapIndexed { n, k -> RecapPlanDay(s.plusDays(n.toLong()), k, if (k == Kinds.REST) 0.0 else km / 5) })
    }

    @Test fun weeklyBucketsGroupByMondayExcludeBikeAndComputeVam() {
        val runs = listOf(
            run(1, "2026-11-02", 10.0, 60.0, gain = 300.0, loss = 280.0),
            run(2, "2026-11-04", 5.0, 30.0, gain = 50.0),
            run(3, "2026-11-03", 40.0, 90.0, bike = true),
            run(4, "2026-10-27", 8.0, 48.0),
        )
        val b = RecapAnalytics.weeklyBuckets(runs, today)
        assertEquals(16, b.size)
        assertEquals(d("2026-11-02"), b.last().start)
        assertEquals(15.0, b.last().km, 1e-9)
        assertEquals(2, b.last().n)
        assertEquals(280.0, b.last().loss, 1e-9)
        assertEquals(8.0, b[14].km, 1e-9)
        // 350 m dalam 90 menit = 233 m/jam
        assertEquals(233, b.last().vam)
        assertEquals(0, RecapAnalytics.vam(99.0, 60.0))
        assertEquals(0, RecapAnalytics.vam(500.0, 9.0))
    }

    @Test fun niceMaxAndSpikes() {
        assertEquals(50.0, RecapAnalytics.niceMax(37.0), 1e-9)
        assertEquals(1.0, RecapAnalytics.niceMax(0.0), 1e-9)
        val s = RecapAnalytics.spikeScan(listOf(10.0, 10.5, 12.0, 15.0), listOf(false, false, false, false), 3.0)
        // 10.5->12 = +14% (selisih 1.5 < 3, tidak dihitung); 12->15 = +25% (hi)
        assertEquals(1, s.size); assertEquals(3, s[0].i); assertTrue(s[0].high); assertEquals(25, s[0].pct)
        // minggu pemulihan dilewati sebagai pembanding
        val s2 = RecapAnalytics.spikeScan(listOf(20.0, 12.0, 24.0), listOf(false, true, false), 0.0)
        assertEquals(1, s2.size); assertEquals(0, s2[0].from); assertEquals(20, s2[0].pct)
        // kembali ke level normal setelah minggu pemulihan bukan lonjakan
        assertTrue(RecapAnalytics.spikeScan(listOf(20.0, 12.0, 21.0), listOf(false, true, false), 0.0).isEmpty())
    }

    @Test fun progressEvalAndPaceDelta() {
        val w1 = week(0, "2026-10-26", 40.0, listOf("easy", "quality", "rest", "easy", "long"))
        val w2 = week(1, "2026-11-02", 42.0, listOf("easy", "quality", "rest", "easy", "long"))
        val runs = listOf(
            run(1, "2026-10-26", 8.0, 56.0, hr = 138),   // easy 7:00
            run(2, "2026-11-02", 8.0, 53.6, hr = 136),   // easy 6:42
        )
        val rows = RecapAnalytics.progressRows(listOf(w1, w2), runs)
        assertEquals(2, rows.size)
        val txt = RecapAnalytics.progressEval(rows, 1)
        assertTrue(txt[0].startsWith("M2 sejauh ini"))
        assertTrue(txt.last().contains("Membaik"))
        assertEquals(listOf(null, -18), RecapAnalytics.paceDeltas(rows))
    }

    @Test fun adherenceCountsDueSessionsAndOffer() {
        val w = week(0, "2026-11-02", 40.0, listOf("easy", "quality", "easy", "easy", "rest"))
        val done = setOf(d("2026-11-02"))
        // today = Rabu 4 Nov: Sen (done), Sel (missed), Rab (belum selesai -> belum jatuh tempo)
        val r = RecapAnalytics.adhWeekRow(w, done, today, emptySet())
        assertEquals(2, r.due); assertEquals(1, r.done); assertEquals(50, r.pct)
        // hari yang dikecualikan (libur dadakan) tidak dihitung
        val r2 = RecapAnalytics.adhWeekRow(w, done, today, setOf(d("2026-11-03")))
        assertEquals(1, r2.due); assertEquals(100, r2.pct)
        val sc = RecapAnalytics.adhScan(listOf(AdhRow(0, 4, 4), AdhRow(1, 4, 4), AdhRow(2, 4, 3), AdhRow(3, 4, 1)))
        assertEquals(25, sc.pct); assertEquals("down", sc.dir); assertEquals(92, sc.prevAvg)
        val offer = RecapAnalytics.adhOffer(listOf(AdhRow(2, 4, 4), AdhRow(3, 4, 1)))
        assertNotNull(offer); assertTrue(offer!!.cur); assertEquals(3, offer.miss)
        assertNull(RecapAnalytics.adhOffer(listOf(AdhRow(2, 4, 4), AdhRow(3, 4, 3))))
    }

    @Test fun reviewStreakAchievementsAndPrs() {
        val weeks = listOf(week(0, "2026-10-26", 30.0, listOf("easy", "easy", "rest", "easy", "long")), week(1, "2026-11-02", 30.0, listOf("easy", "easy", "rest", "easy", "long")))
        val runs = listOf(
            run(1, "2026-10-26", 8.0), run(2, "2026-10-27", 8.0), run(3, "2026-10-29", 14.0),
            run(4, "2026-11-02", 9.0), run(5, "2026-11-03", 20.0),
        )
        val dates = runs.map { it.date }.toSet()
        val rv = RecapAnalytics.weekReview(d("2026-11-02"), runs, weeks, dates)
        assertEquals(2, rv.n); assertEquals(29.0, rv.km, 1e-9); assertEquals(29.0 / 30.0, rv.km / rv.planKm!!, 1e-9)
        assertTrue(rv.recLong); assertFalse(rv.recWeek)
        assertEquals(30.0, rv.prevKm, 1e-9)
        assertEquals(2, RecapAnalytics.weekStreak(runs, weeks, dates, today))
        val rest = setOf(d("2026-10-28"))
        // 26,27 lari, 28 libur rencana (tidak memutus), 29 lari; 30,31,1 tidak ada -> putus. Mulai dari 4 Nov: 4 Nov tidak ada, 3 Nov ada, 2 Nov ada, 1 Nov kosong -> 2
        assertEquals(2, RecapAnalytics.dayStreak(runs, rest, today))
        val ac = RecapAnalytics.achievements(runs, 1, 4, 2)
        assertFalse(ac.first { it.text == "100 km total" }.on)
        assertTrue(ac.first { it.text == "Lari terpanjang ≥ 10 km" }.on)
        assertTrue(ac.first { it.text == "2 minggu beruntun" }.on)
        assertFalse(ac.first { it.text == "Semua jarak PR terisi" }.on)
        val atEnd = listOf(RecapPr("5K", 5.0, 24.0, d("2026-11-03")), RecapPr("10K", 10.0, 50.0, d("2026-10-01")))
        val atStart = listOf(RecapPr("5K", 5.0, 25.0, d("2026-09-01")), RecapPr("10K", 10.0, 50.0, d("2026-10-01")))
        assertEquals(listOf("5K" to 24.0), RecapAnalytics.newPrsIn(d("2026-11-02"), atEnd, atStart))
    }

    @Test fun aggregatesHeatmapAndConsistency() {
        val runs = listOf(run(1, "2026-11-02", 10.0, 60.0, gain = 100.0), run(2, "2026-11-02", 5.0, 30.0), run(3, "2025-11-02", 20.0, 120.0), run(4, "2026-11-03", 30.0, 60.0, bike = true))
        val dm = RecapAnalytics.dayAggregates(runs)
        assertEquals(15.0, dm[d("2026-11-02")]!!.km, 1e-9); assertEquals(2, dm[d("2026-11-02")]!!.n)
        assertNull(dm[d("2026-11-03")])
        assertEquals(listOf(2025, 2026), RecapAnalytics.years(dm, today))
        val a = RecapAnalytics.monthAgg(dm, 2026)
        assertEquals(15.0, a[10].km, 1e-9); assertEquals(1, a[10].days)
        assertEquals("▲100%", RecapAnalytics.deltaText(10.0, 5.0))
        assertEquals("▼25%", RecapAnalytics.deltaText(15.0, 20.0))
        assertEquals("=", RecapAnalytics.deltaText(5.0, 5.0)); assertEquals("", RecapAnalytics.deltaText(5.0, 0.0))
        val cut = RecapAnalytics.levels(listOf(0.0, 1.0, 2.0, 3.0, 4.0, 5.0))
        assertEquals(0, RecapAnalytics.levelOf(0.0, cut)); assertEquals(1, RecapAnalytics.levelOf(2.0, cut)); assertEquals(4, RecapAnalytics.levelOf(5.0, cut))
        val (cells, weeks) = RecapAnalytics.yearGrid(2026)
        assertEquals(3, cells.first { it.date == d("2026-01-01") }.row)  // 1 Jan 2026 = Kamis (baris indeks 3)
        assertEquals(53, weeks)
        assertEquals(365, cells.count { it.inYear })
        val (km, days) = RecapAnalytics.ytd(dm, 2025, today)
        assertEquals(20.0, km, 1e-9); assertEquals(1, days)
        assertEquals(1, RecapAnalytics.monthDayLevel(5.9, true)); assertEquals(2, RecapAnalytics.monthDayLevel(8.0, true)); assertEquals(3, RecapAnalytics.monthDayLevel(12.0, true)); assertEquals(0, RecapAnalytics.monthDayLevel(0.0, true))
        val months = RecapAnalytics.monthRange(listOf(d("2024-01-15")), null, today)
        assertEquals(24, months.size); assertEquals("2026-11", months.last().toString())
    }

    @Test fun predictionRoundTripAndEasyWeeks() {
        val v = RecapAnalytics.vdotOf(5000.0, 25.0)
        assertEquals(25.0, RecapAnalytics.raceTimeV(v, 5000.0), 1e-3)
        assertTrue(RecapAnalytics.raceTimeV(v, 10000.0) > 50.0)
        val ref = RecapAnalytics.bestPrRef(listOf(RecapPr("5K", 5.0, 25.0, d("2026-10-01")), RecapPr("1 km", 1.0, 4.0, d("2026-10-01"))))
        assertEquals("5K", ref!!.label)
        assertEquals(25.0 * Math.pow(2.0, 1.06), RecapAnalytics.riegel(25.0, 5.0, 10.0), 1e-9)
        val e = RecapAnalytics.easyWeeks(listOf(run(1, "2026-11-02", 8.0, 56.0, hr = 138), run(2, "2026-11-03", 10.0, 55.0, hr = 170), run(3, "2026-11-04", 8.0, 56.0, hr = 138, gain = 400.0)), 145)
        assertEquals(1, e.size); assertEquals(7.0, e[0].pace, 1e-9); assertEquals(1, e[0].n)
    }
    @Test fun adherenceSignal() {
        val rows = listOf(AdhRow(0, 4, 4), AdhRow(1, 4, 4), AdhRow(2, 4, 3), AdhRow(3, 4, 1))
        val sc = RecapAnalytics.adhScan(rows); val offer = RecapAnalytics.adhOffer(rows)
        assertNotNull(offer); assertTrue(offer!!.cur)
        assertEquals(1, RecapAnalytics.adhSignal(sc, offer))
        val good = RecapAnalytics.adhScan(listOf(AdhRow(0, 4, 4), AdhRow(1, 4, 4), AdhRow(2, 4, 4)))
        assertEquals(0, RecapAnalytics.adhSignal(good, null))
        val bad = listOf(AdhRow(0, 4, 4), AdhRow(1, 4, 2), AdhRow(2, 4, 2), AdhRow(3, 4, 4))
        assertEquals(2, RecapAnalytics.adhSignal(RecapAnalytics.adhScan(bad), AdhOffer(false, 4, 50)))
    }

    @Test fun verticalLoadWindowAndTrend() {
        val runs = listOf(
            run(1, "2026-10-10", 20.0, gain = 900.0, loss = 880.0),
            run(2, "2026-11-03", 10.0, gain = 30.0, loss = 32.0),
            run(3, "2026-11-02", 40.0, gain = 900.0, bike = true),
        )
        val v = RecapAnalytics.verticalLoad(runs, today)!!
        assertEquals(30.0, v.up, 1e-9); assertEquals(32.0, v.down, 1e-9)
        assertTrue(v.chronic > v.acute); assertTrue(v.ratio!! < 0.8); assertEquals("turun", v.trend)
        assertNull(RecapAnalytics.verticalLoad(listOf(run(1, "2026-11-03", 10.0)), today))
    }

    @Test fun cycleSummaryBoundsAndTests() {
        val ws = (0..5).map { i ->
            val s = d("2026-10-19").plusWeeks(i.toLong())
            RecapPlanWeek(i, s, 50.0, (0..6).map { n -> RecapPlanDay(s.plusDays(n.toLong()), if (n == 6) Kinds.REST else "easy", 8.0, bench = (i == 5 && n == 2)) }, cut = i == 5)
        } + (6..8).map { i ->
            val s = d("2026-10-19").plusWeeks(i.toLong())
            RecapPlanWeek(i, s, 60.0, (0..6).map { n -> RecapPlanDay(s.plusDays(n.toLong()), "easy", 8.0) }, cut = i == 8)
        }
        val runs = listOf(run(1, "2026-10-20", 10.0), run(2, "2026-11-03", 12.0), run(3, "2026-10-19", 5.0, bike = true))
        val c = RecapAnalytics.cycleSummary(ws, runs, today)!!
        assertEquals(1, c.cycle); assertEquals(1, c.fromWeek); assertEquals(6, c.toWeek); assertTrue(c.recovery)
        assertEquals(22.0, c.loggedKm, 1e-9); assertEquals(300.0, c.planKm, 1e-9)
        assertEquals(d("2026-11-25"), c.nextTest); assertTrue(c.tests.isEmpty())
        val c2 = RecapAnalytics.cycleSummary(ws, runs + run(9, "2026-11-25", 6.3, 40.0, hr = 148), d("2026-11-30"))!!
        assertEquals(2, c2.cycle); assertEquals(7, c2.fromWeek); assertEquals(1, c2.tests.size); assertEquals(148, c2.tests[0].hr)
        assertNull(RecapAnalytics.cycleSummary(ws, runs, d("2027-03-01")))
    }
}
