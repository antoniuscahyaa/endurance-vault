package com.endurancevault.app

import com.endurancevault.app.domain.FrameStats
import com.endurancevault.app.domain.RouteVideoCamera
import com.endurancevault.app.domain.RouteVideoKeys
import com.endurancevault.app.domain.RouteVideoPrefs
import com.endurancevault.app.domain.RouteVideoText
import com.endurancevault.app.domain.RouteVideoTrack
import com.endurancevault.app.domain.VideoPanel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RouteVideoTest {
    /** Lari lurus 3 km ke timur, 1 sampel/detik, pace tetap 6:00/km, naik 30 m. */
    private fun track(n: Int = 1080, gain: Int? = null): RouteVideoTrack {
        val dist = DoubleArray(n) { it * 3000.0 / (n - 1) }
        return RouteVideoTrack(
            lat = DoubleArray(n) { -6.2 }, lon = DoubleArray(n) { 106.8 + dist[it] / 111_320.0 },
            dist = dist, sec = IntArray(n) { it },
            hr = IntArray(n) { 150 }, cad = IntArray(n) { 170 },
            ele = DoubleArray(n) { 100.0 + 30.0 * it / (n - 1) }, gradeRaw = DoubleArray(n) { Double.NaN },
            title = "Lari pagi", dateText = "10 Nov 2026", officialGain = gain,
        )
    }

    @Test fun prefsRoundTripKeepsPositionAndSize() {
        val p = RouteVideoPrefs(
            panels = listOf(VideoPanel("pace", 12.5, 40.0, 150), VideoPanel("hr", 60.0, 80.0, 70)),
            live = false, tilt = 61, exaggeration = 2.5, orbit = 90, ink = "k", panelBg = "soft", durationSec = 20,
        )
        val q = RouteVideoPrefs.fromJson(p.toJson())
        assertEquals(p.panels, q.panels)
        assertEquals(false, q.live)
        assertEquals(61, q.tilt)
        assertEquals(2.5, q.exaggeration, 1e-9)
        assertEquals("k", q.ink)
        assertEquals(20, q.durationSec)
    }

    @Test fun brokenJsonFallsBackToDefaults() {
        assertEquals(RouteVideoPrefs(), RouteVideoPrefs.fromJson(null))
        assertEquals(RouteVideoPrefs(), RouteVideoPrefs.fromJson("{bukan json"))
    }

    @Test fun sanitizeClampsAndDropsUnknownPanels() {
        val p = RouteVideoPrefs(
            panels = listOf(VideoPanel("pace", -5.0, 140.0, 999), VideoPanel("pace", 1.0, 1.0, 100), VideoPanel("ngawur", 1.0, 1.0, 100)),
            tilt = 5, exaggeration = 99.0, orbit = -3, durationSec = 1, ink = "?", lineColor = "merah",
        ).sanitized()
        assertEquals(listOf(VideoPanel("pace", 0.0, 100.0, RouteVideoKeys.MAX_SIZE)), p.panels)
        assertEquals(20, p.tilt); assertEquals(4.0, p.exaggeration, 1e-9); assertEquals(0, p.orbit)
        assertEquals(6, p.durationSec); assertEquals("w", p.ink); assertEquals("#C6F432", p.lineColor)
    }

    @Test fun defaultLayoutCoversEveryKeyInsideTheFrame() {
        RouteVideoKeys.ALL.forEach { k ->
            val d = RouteVideoKeys.defaultPanel(k)
            assertEquals(k, d.key)
            assertTrue(d.x in 0.0..100.0 && d.y in 0.0..100.0)
        }
    }

    @Test fun cameraTimelineStartsAtZeroAndEndsAtOne() {
        val prefs = RouteVideoPrefs()
        assertEquals(0.0, RouteVideoCamera.at(0.0, prefs).routeFrac, 1e-9)
        assertEquals(0.0, RouteVideoCamera.at(RouteVideoCamera.T_IN, prefs).routeFrac, 1e-9)
        assertEquals(1.0, RouteVideoCamera.at(RouteVideoCamera.T_OUT, prefs).routeFrac, 1e-9)
        assertEquals(1.0, RouteVideoCamera.at(1.0, prefs).routeFrac, 1e-9)
        // Bagian lari: kemajuan rute naik terus.
        var last = -1.0
        for (i in 0..100) { val r = RouteVideoCamera.at(i / 100.0, prefs).routeFrac; assertTrue(r >= last); last = r }
    }

    @Test fun cameraPitchFollowsTiltInTheMiddle() {
        val c = RouteVideoCamera.at(0.5, RouteVideoPrefs(tilt = 40))
        assertEquals(40.0, c.pitchDeg, 1e-6)
        assertEquals(1.0, c.distMul, 1e-6)
    }

    @Test fun liveStatsFollowRunnerPosition() {
        val t = track()
        val half = t.statsAt(0.5, live = true)
        assertEquals(1500.0, half.distM, 5.0)
        assertEquals(540.0, half.sec.toDouble(), 3.0)
        assertEquals(6.0, half.pace!!, 0.05)
        assertEquals(150, half.hr)
        assertEquals(170, half.cad)
        val start = t.statsAt(0.0, live = true)
        assertEquals(0.0, start.distM, 1e-9)
        assertEquals(0.0, start.gain, 1e-9)
    }

    @Test fun totalStatsSummariseWholeRun() {
        val s = track().statsAt(0.2, live = false)
        assertEquals(3000.0, s.distM, 1e-6)
        assertEquals(1079, s.sec)
        assertEquals(6.0, s.pace!!, 0.05)
        assertEquals(150, s.hr)
        assertTrue(s.gain > 20.0)
    }

    @Test fun gainCanBeAlignedToOfficialValue() {
        val s = track(gain = 55).statsAt(1.0, live = true)
        assertEquals(55.0, s.gain, 0.5)
    }

    @Test fun gradeIsDerivedFromElevationWhenMissing() {
        // 30 m naik dalam 3000 m = 1%
        val g = track().statsAt(0.5, live = true).grade
        assertNotNull(g)
        assertEquals(1.0, g!!, 0.1)
    }

    @Test fun profileSamplesRiseMonotonically() {
        val p = track().profileSamples(50)
        assertEquals(50, p.size)
        for (i in 1 until p.size) assertTrue(p[i] >= p[i - 1] - 1e-9)
    }

    @Test fun missingHeartRateShowsDash() {
        val st = FrameStats(0, 0.0, 0.0, 0, null, null, null, null, 0.0, null)
        assertEquals("–", RouteVideoText.cell("hr", st, true, false)!!.value)
        assertEquals("–", RouteVideoText.cell("pace", st, true, false)!!.value)
        assertEquals("–", RouteVideoText.cell("grad", st, true, false)!!.value)
        assertNull(RouteVideoText.cell("judul", st, true, false))
    }

    @Test fun cellsUseIndonesianFormatting() {
        val st = FrameStats(1, .5, 5234.0, 1830, 5.5, 152, 3.24, 123.4, 85.0, 172)
        assertEquals("5,23", RouteVideoText.cell("jarak", st, true, false)!!.value)
        assertEquals("30:30", RouteVideoText.cell("waktu", st, true, false)!!.value)
        assertEquals("5:30", RouteVideoText.cell("pace", st, true, false)!!.value)
        assertEquals("+3,2", RouteVideoText.cell("grad", st, true, false)!!.value)
        assertEquals("123", RouteVideoText.cell("elev", st, true, false)!!.value)
        assertEquals("10,9", RouteVideoText.cell("pace", st, true, true)!!.value)   // sepeda: km/j
        assertEquals("10 Nov 2026", RouteVideoText.dateId("2026-11-10"))
    }
}
