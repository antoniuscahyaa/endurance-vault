package com.endurancevault.app

import com.endurancevault.app.data.ElevationCalibration
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ElevationCalibrationTest {
    private fun split(k: Int, g: Double, l: Double) = linkedMapOf<String, Any?>("k" to k.toDouble(), "p" to 5.0, "g" to g, "l" to l)

    private fun act(gain: Double? = 100.0, loss: Double? = 90.0) = mapOf<String, Any?>(
        "gain" to gain, "loss" to loss,
        "sp" to listOf(split(1, 40.0, 30.0), split(2, 60.0, 60.0)),
    )

    private fun watch(gain: Double? = null, loss: Double? = null, gainSrc: String? = "watch", lossSrc: String? = "watch") = JSONObject().apply {
        gain?.let { put("elevationGain", it); gainSrc?.let { s -> put("elevationGainSource", s) } }
        loss?.let { put("elevationLoss", it); lossSrc?.let { s -> put("elevationLossSource", s) } }
    }

    @Suppress("UNCHECKED_CAST")
    private fun splits(m: Map<String, Any?>) = m["sp"] as List<Map<String, Any?>>

    @Test fun totalsBecomeTheWatchValuesAndSplitsAreScaledByTheSameRatio() {
        val out = ElevationCalibration.calibrate(act(), watch(gain = 120.0, loss = 81.0))
        assertEquals(120.0, out["gain"] as Double, 0.0)
        assertEquals(81.0, out["loss"] as Double, 0.0)
        assertEquals(100.0, out["gainRaw"] as Double, 0.0)
        assertEquals(90.0, out["lossRaw"] as Double, 0.0)
        // gain x1,2: 40->48, 60->72 (jumlah 120); loss x0,9: 30->27, 60->54 (jumlah 81)
        assertEquals(listOf(48.0, 72.0), splits(out).map { it["g"] })
        assertEquals(listOf(27.0, 54.0), splits(out).map { it["l"] })
    }

    @Test fun inputIsNotMutated() {
        val a = act()
        ElevationCalibration.calibrate(a, watch(gain = 120.0, loss = 81.0))
        assertEquals(100.0, a["gain"] as Double, 0.0)
        assertEquals(40.0, splits(a)[0]["g"] as Double, 0.0)
    }

    @Test fun routeWithoutAltitudeTakesTheWatchTotalsAsIs() {
        val a = mapOf<String, Any?>("sp" to listOf(split(1, 0.0, 0.0)))
        val out = ElevationCalibration.calibrate(a, watch(gain = 55.4, loss = 40.6))
        assertEquals(55.0, out["gain"] as Double, 0.0)
        assertEquals(41.0, out["loss"] as Double, 0.0)
        assertNull(out["gainRaw"])
        assertEquals(0.0, splits(out)[0]["g"] as Double, 0.0)
    }

    @Test fun untrustedSampleSumFarFromComputedValueIsIgnored() {
        // jam hanya menjumlahkan sampel mentah (derau): 400 m vs hitungan 100 m -> rasio 4, tidak dipakai
        val out = ElevationCalibration.calibrate(act(), watch(gain = 400.0, gainSrc = "samples"))
        assertEquals(100.0, out["gain"] as Double, 0.0)
        assertEquals(40.0, splits(out)[0]["g"] as Double, 0.0)
    }

    @Test fun untrustedValueWithinRangeIsAccepted() {
        val out = ElevationCalibration.calibrate(act(), watch(gain = 110.0, gainSrc = null)) // sumber tidak diketahui (data lama)
        assertEquals(110.0, out["gain"] as Double, 0.0)
    }

    @Test fun trustedWatchValueWinsEvenFarFromComputed() {
        val out = ElevationCalibration.calibrate(act(), watch(gain = 250.0))
        assertEquals(250.0, out["gain"] as Double, 0.0)
        assertEquals(250.0, splits(out).sumOf { it["g"] as Double }, 0.0) // split ikut diskalakan x2,5
    }

    @Test fun noWatchElevationLeavesActivityUntouched() {
        val a = act()
        val out = ElevationCalibration.calibrate(a, JSONObject())
        assertEquals(a, out)
    }

    @Test fun flatWatchValueSetsTotalWithoutScalingSplits() {
        val out = ElevationCalibration.calibrate(act(), watch(gain = 0.0))
        assertEquals(0.0, out["gain"] as Double, 0.0)
        assertEquals(40.0, splits(out)[0]["g"] as Double, 0.0)
    }
}
