package com.endurancevault.app

import com.endurancevault.app.domain.ActBuilder
import com.endurancevault.app.domain.ActCrop
import com.endurancevault.app.domain.ActEdit
import com.endurancevault.app.domain.ActImportException
import com.endurancevault.app.domain.ActTombstones
import com.endurancevault.app.domain.Pt
import com.endurancevault.app.domain.RouteGeo
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.time.ZoneOffset

class ActEditCropTest {
    private val t0 = 1_762_500_000_000.0

    /** Lari lurus ke utara ±3,3 m/dtk, 600 dtk, elevasi naik 0,05 m/dtk, HR 150, kadens [cad] spm. */
    private fun run(cad: Double = 170.0): Map<String, Any?> {
        val pts = (0..600).map { s ->
            Pt(la = -6.2 + s * 0.00003, lo = 106.8, t = t0 + s * 1000.0, e = 20.0 + s * 0.05, h = 150.0, c = cad)
        }
        return ActBuilder.build(pts, "running", "Lari pagi", ZoneOffset.UTC)
    }

    @Test fun cropMiddleRecomputesStatsAndKeepsIdentity() {
        val act = run()
        val r = ActCrop.crop(act, 120, 480, ZoneOffset.UTC)
        assertEquals(1.2, r.km, 0.03)
        assertEquals(360.0, r.durationSec.toDouble(), 2.0)
        assertEquals(150, r.avgHr)
        assertNotNull(r.gain)
        // sekitar 18 m (360 dtk x 0,05 m)
        assertEquals(18.0, r.gain!!.toDouble(), 3.0)
        assertEquals(act["date"], r.act["date"]); assertEquals(act["st"], r.act["st"]); assertEquals(act["t0"], r.act["t0"])
        assertEquals("Lari pagi", r.act["nm"])
        // deret 1 Hz baru dimulai dari nol dan panjangnya sesuai potongan
        val ts = ActCrop.seriesOf(r.act)!!
        assertEquals(0, ts.seconds.first()); assertEquals(0.0, ts.distanceMeters.first(), 0.01)
        assertEquals(360.0, ts.seconds.last().toDouble(), 2.0)
    }

    @Test fun cropFullRangeKeepsTotals() {
        val act = run()
        val r = ActCrop.crop(act, 0, 600, ZoneOffset.UTC)
        assertEquals((act["km"] as Number).toDouble(), r.km, 0.02)
        assertEquals(600.0, r.durationSec.toDouble(), 2.0)
    }

    @Test fun cadenceIsNotDoubledAgain() {
        // Kadens mentah 60 (di bawah 120) digandakan sekali oleh impor berkas menjadi 120 spm. Crop membaca nilai tersimpan
        // yang sudah dalam spm dan tidak boleh menggandakannya lagi.
        val low = run(cad = 60.0)
        assertEquals(120, (low["cad"] as Number).toInt())
        assertEquals(120, (ActCrop.crop(low, 60, 400, ZoneOffset.UTC).act["cad"] as Number).toInt())
        val normal = run(cad = 170.0)
        assertEquals(170, (ActCrop.crop(normal, 60, 400, ZoneOffset.UTC).act["cad"] as Number).toInt())
    }

    @Test fun routeIsCroppedByDistanceProportion() {
        val act = run()
        val r = ActCrop.crop(act, 120, 480, ZoneOffset.UTC)
        val rt = (r.act["rt"] as List<*>).map { (it as List<*>).map { v -> (v as Number).toInt() } }
        assertTrue(rt.size >= 2)
        assertTrue(rt.all { it[0] in 0..1000 && it[1] in 0..1000 })
        val frame = RouteGeo.frameOf(r.act["ge"] as List<*>)!!
        // Rute lurus ke utara: y kecil = lintang lebih utara. Awal di detik 120, akhir di detik 480.
        val startLat = frame.lat(rt.first()[1].toDouble()); val endLat = frame.lat(rt.last()[1].toDouble())
        assertEquals(-6.2 + 120 * 0.00003, startLat, 0.0006)
        assertEquals(-6.2 + 480 * 0.00003, endLat, 0.0006)
        assertEquals(106.8, frame.lon(rt.first()[0].toDouble()), 0.001)
    }

    @Test fun staleWholeSessionKeysAreDropped() {
        val act = LinkedHashMap(run()); act["sg"] = listOf<Any?>(); act["vam"] = mapOf("a" to 500.0); act["bat"] = mapOf("s" to 90.0)
        val r = ActCrop.crop(act, 0, 300, ZoneOffset.UTC)
        assertFalse(r.act.containsKey("sg")); assertFalse(r.act.containsKey("vam")); assertFalse(r.act.containsKey("bat"))
    }

    @Test fun strideStartShiftsWithTheCrop() {
        val act = LinkedHashMap(run()); act["ez"] = mapOf("on" to true, "st" to 200.0); act["zs"] = 200.0
        val shifted = ActCrop.crop(act, 150, 500, ZoneOffset.UTC)
        assertEquals(50, ((shifted.act["ez"] as Map<*, *>)["st"] as Number).toInt())
        assertEquals(50, (shifted.act["zs"] as Number).toInt())
        // pemanasan terpotong seluruhnya: mulai dari 0
        assertEquals(0, ((ActCrop.crop(act, 250, 500, ZoneOffset.UTC).act["ez"] as Map<*, *>)["st"] as Number).toInt())
        // fase setelah pemanasan jatuh di luar potongan: dibuang
        assertNull((ActCrop.crop(act, 0, 150, ZoneOffset.UTC).act["ez"] as Map<*, *>)["st"])
    }

    @Test fun tooShortOrMissingSeriesIsRejected() {
        try { ActCrop.crop(run(), 100, 130, ZoneOffset.UTC); fail() } catch (e: ActImportException) { assertTrue(e.message!!.contains("1 menit")) }
        val noSeries = LinkedHashMap(run()); noSeries.remove("tl")
        try { ActCrop.crop(noSeries, 0, 300, ZoneOffset.UTC); fail() } catch (e: ActImportException) { assertTrue(e.message!!.contains("per detik")) }
    }

    @Test fun windowMatchesCrop() {
        val act = run()
        val ts = ActCrop.seriesOf(act)!!
        val w = ActCrop.window(ts, 120, 480)!!
        val r = ActCrop.crop(act, 120, 480, ZoneOffset.UTC)
        assertEquals(w.meters / 1000.0, r.km, 0.02)
        assertTrue(w.valid)
        assertFalse(ActCrop.window(ts, 100, 130)!!.valid)
    }

    // ---- edit ----

    private val watchNote = JSONObject()
        .put("source", "huawei-watch").put("userNote", "enak").put("workoutLoad", 90).put("aerobicEffect", 3.1)
        .put("recoveryHr", org.json.JSONArray(listOf(150, 130))).put("watchStart", 1_762_500_000L).toString()

    @Test fun userNoteKeepsWatchMetrics() {
        assertEquals("enak", ActEdit.userNote(watchNote))
        val edited = ActEdit.withUserNote(watchNote, "  tempo  ")
        assertEquals("tempo", ActEdit.userNote(edited))
        assertEquals(90, JSONObject(edited).getInt("workoutLoad"))
        assertEquals("catatan", ActEdit.withUserNote("lama", " catatan "))
        assertEquals("catatan", ActEdit.userNote("catatan"))
        assertFalse(JSONObject(ActEdit.withUserNote(watchNote, "")).has("userNote"))
    }

    @Test fun markCroppedDropsWatchMetricsButKeepsIdentity() {
        val o = JSONObject(ActEdit.markCropped(watchNote))
        assertTrue(o.getBoolean("cropped"))
        for (k in ActEdit.WATCH_METRIC_KEYS) assertFalse(k, o.has(k))
        assertEquals("enak", o.getString("userNote")); assertEquals(1_762_500_000L, o.getLong("watchStart"))
        assertTrue(ActEdit.isCropped(o.toString()))
        assertEquals("catatan biasa", ActEdit.markCropped("catatan biasa"))
    }

    @Test fun watchStartIsBackfilledFromDetail() {
        val bare = JSONObject().put("source", "huawei-watch").toString()
        val detail = mapOf<String, Any?>("watch" to JSONObject().put("start", 1_762_500_123L).toString())
        assertEquals(1_762_500_123L, JSONObject(ActEdit.withWatchStart(bare, detail)).getLong("watchStart"))
        assertEquals("teks", ActEdit.withWatchStart("teks", detail))
        assertEquals(watchNote, ActEdit.withWatchStart(watchNote, detail))
    }

    @Test fun validateRejectsBadInput() {
        assertNull(ActEdit.validate("2026-11-08", "06:30", "run"))
        assertNull(ActEdit.validate("2026-11-08", "", "bike"))
        assertNotNull(ActEdit.validate("08-11-2026", "06:30", "run"))
        assertNotNull(ActEdit.validate("2026-02-30", "06:30", "run"))
        assertNotNull(ActEdit.validate("2026-11-08", "6:30", "run"))
        assertNotNull(ActEdit.validate("2026-11-08", "25:00", "run"))
        assertNotNull(ActEdit.validate("2026-11-08", "06:30", "swim"))
    }

    @Test fun applyToDetailUpdatesNameTypeAndRecomputesT0() {
        val act = mapOf<String, Any?>("date" to "2026-11-07", "st" to "06:30", "t0" to 1.0, "nm" to "lama", "bike" to false)
        val out = ActEdit.applyToDetail(act, ActEdit.Fields("Baru", "", "bike", "2026-11-08", "07:15"), ZoneOffset.UTC)
        assertEquals("Baru", out["nm"]); assertEquals(true, out["bike"])
        assertEquals("2026-11-08", out["date"]); assertEquals("07:15", out["st"])
        assertEquals(java.time.LocalDateTime.of(2026, 11, 8, 7, 15).toInstant(ZoneOffset.UTC).toEpochMilli(), (out["t0"] as Number).toLong())
        // tanpa perubahan tanggal/jam, t0 tidak disentuh; hiking/renang tidak diubah menjadi lari
        val same = ActEdit.applyToDetail(mapOf("date" to "2026-11-07", "st" to "06:30", "t0" to 1.0, "xk" to "hike", "bike" to true),
            ActEdit.Fields("x", "", "run", "2026-11-07", "06:30"), ZoneOffset.UTC)
        assertEquals(1.0, (same["t0"] as Number).toDouble(), 0.0); assertEquals(true, same["bike"])
    }

    // ---- hapus ----

    @Test fun tombstonesOnlyForWatchActivities() {
        val detail = mapOf<String, Any?>("watch" to JSONObject().put("start", 1_762_500_000L).toString())
        // baris gabungan: kunci web + detail jam
        val merged = ActTombstones.keysFor("2026-11-07", "run", "2026-11-07", "06:30", watchNote, detail)
        assertTrue("watch:1762500000" in merged)
        assertTrue(ActTombstones.slot("2026-11-07", "06:30", "run") in merged)
        // baris jam murni
        assertTrue("watch:5" in ActTombstones.keysFor("watch:5", "run", "2026-11-07", "06:30", "", null))
        // manual / impor berkas: tidak ada penanda, workout jam di slot yang sama tetap boleh masuk
        assertTrue(ActTombstones.keysFor("", "run", "2026-11-07", "06:30", "catatan", null).isEmpty())
    }

    @Test fun tombstoneBlocksByKeyOrSlotAndRoundTrips() {
        val keys = setOf("watch:1762500000", ActTombstones.slot("2026-11-07", "06:30", "run"))
        val back = ActTombstones.parse(ActTombstones.toJson(keys))
        assertEquals(keys, back)
        assertTrue(ActTombstones.blocked(back, "watch:1762500000", "2026-11-08", "09:00", "run"))
        assertTrue(ActTombstones.blocked(back, "watch:1", "2026-11-07", "06:30", "run"))
        assertFalse(ActTombstones.blocked(back, "watch:1", "2026-11-07", "06:30", "bike"))
        assertFalse(ActTombstones.blocked(emptySet(), "watch:1", "2026-11-07", "06:30", "run"))
        assertTrue(ActTombstones.parse(null).isEmpty()); assertTrue(ActTombstones.parse("bukan json").isEmpty())
    }
}
