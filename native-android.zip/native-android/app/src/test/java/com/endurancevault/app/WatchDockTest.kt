package com.endurancevault.app

import com.endurancevault.app.data.HuaweiSleepParity
import com.endurancevault.app.domain.BatPoint
import com.endurancevault.app.domain.WatchDock
import com.endurancevault.app.domain.WatchModel
import com.endurancevault.app.domain.WatchRaw
import com.endurancevault.app.domain.WatchWorkout
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant

/** Tes dock Jam: port dari tests/dock-jam.test.mjs (angka dan teks harus sama dengan versi web). */
class WatchDockTest {
    private val tz = 420
    private val now = Instant.parse("2026-10-17T03:00:00Z").epochSecond // 10:00 WIB
    private val mid = now - 10 * 3600

    private fun night(): HuaweiSleepParity.Night = HuaweiSleepParity.Night(
        date = "2026-10-17", start = now - 12 * 3600, end = now - 3 * 3600 - 2400, bed = "23:10", wake = "06:20",
        deep = 80, rem = 90, light = 230, awake = 30, unknown = 0, awakeCount = 0, awakeMinutes = 0, gapMinutes = 0,
        latencyMin = 0, sleepMinutes = 400, wakes = emptyList(), extras = emptyList(), extraMinutes = 0,
    )

    private fun workout() = WatchWorkout(
        start = now - 7200, end = now - 4200, sportType = 1, sportName = "Outdoor run", duration = 3000, distance = 8000,
        calories = 600, avgHr = 150, maxHr = 172, complete = true, recoveryHours = 0.0, gpsPoints = 0,
    )

    private fun status() = JSONObject("""{"state":"connected","battery":72,"device":{"name":"HUAWEI WATCH GT","model":"GT 4"}}""")

    private fun live(): JSONObject = JSONObject(
        """{"today":{"steps":6500,"calories":210000,"distance":5000,"hrAvg":78.4,"hrMin":52,"hrMax":141,"hrN":300,"spo2Avg":96.5,"spo2Min":94,"spo2N":5,"lastTs":${now - 120}},
            "latest":{"hrTs":${now - 120},"hr":88,"spo2Ts":${now - 3600},"spo2":97,"sampleTs":${now - 120}},
            "series":[{"t":$mid,"hr":55,"hrMin":52,"hrMax":60},{"t":${mid + 600},"hr":70,"hrMin":60,"hrMax":90},{"t":${mid + 1200},"hr":141,"hrMin":100,"hrMax":141}]}""",
    )

    private fun daily(): JSONObject = JSONObject(
        """{"days":[{"day":"2026-10-16","steps":9000,"rhrN":3,"rhrAvg":54.2},{"day":"2026-10-17","steps":6500,"rhrN":0}]}""",
    )

    private fun raw(status: JSONObject = status(), live: JSONObject = live(), daily: JSONObject = daily(), batLog: List<BatPoint> = emptyList()) =
        WatchRaw(status, live, daily, listOf(night()), emptyList(), 51.6, listOf(workout()), batLog)

    private fun build(r: WatchRaw = raw()): WatchModel = WatchDock.model(r, now, tz, 190)
    private fun tiles(m: WatchModel) = m.tiles.associateBy { it.k }

    // ---- murni ----

    @Test fun jarak_meterSentimeterDanTanpaData() {
        assertEquals(5000.0, WatchDock.distM(5000.0, 6500.0), 0.0)
        assertEquals(5000.0, WatchDock.distM(500000.0, 6500.0), 0.0)
        assertEquals(750.0, WatchDock.distM(0.0, 1000.0), 0.0)
        assertEquals(300.0, WatchDock.distM(300.0, 0.0), 0.0)
    }

    @Test fun kaloriFormatAngkaDanWaktu() {
        assertEquals(1235, WatchDock.kcal(1234567.0))
        assertEquals("321 kkal", WatchDock.kcalTxt(321.0)); assertEquals("4,6 kkal", WatchDock.kcalTxt(4.58)); assertEquals("0 kkal", WatchDock.kcalTxt(0.0))
        assertEquals(52, WatchDock.rhrOf(JSONObject("""{"rhrN":3,"rhrAvg":54.2,"rhrLast":52}""")))
        assertEquals(54, WatchDock.rhrOf(JSONObject("""{"rhrN":3,"rhrAvg":54.2}""")))
        assertEquals(0, WatchDock.rhrOf(JSONObject("""{"rhrN":1,"rhrAvg":250}""")))
        assertEquals("12.345", WatchDock.num(12345.0)); assertEquals("5,68", WatchDock.dec(5.678, 2))
        assertEquals("baru saja", WatchDock.ago(1000, 970)); assertEquals("10 mnt lalu", WatchDock.ago(1000, 400)); assertEquals("2 jam lalu", WatchDock.ago(100000, 100000 - 7200))
        assertEquals("7j 17m", WatchDock.hm(437))
    }

    @Test fun langkah7Hari_hariKosongNolDanHariIniDitandai() {
        val days = org.json.JSONArray("""[{"day":"2026-10-17","steps":4000},{"day":"2026-10-15","steps":11000}]""")
        val w = WatchDock.weekSteps(days, "2026-10-17", 7)
        assertEquals(7, w.size); assertTrue(w[6].now); assertEquals(4000.0, w[6].steps, 0.0); assertTrue(w[4].has); assertFalse(w[5].has); assertEquals("2026-10-11", w[0].d)
        assertEquals("Sab", w[6].l)
    }

    @Test fun ringkasanTidur_faseDanEfisiensi() {
        val s = WatchDock.sleepSummary(night())!!
        assertEquals(93, s.eff); assertEquals(4, s.stages.size); assertEquals(430, s.tot)
        assertNull(WatchDock.sleepSummary(null))
        val tanpaFase = night().copy(deep = 0, rem = 0, light = 0, awake = 0, sleepMinutes = 300)
        assertEquals(0, WatchDock.sleepSummary(tanpaFase)!!.stages.size)
    }

    // ---- model ----

    @Test fun model_delapanUbinTerisiDariDataJam() {
        val m = build(); val t = tiles(m)
        assertTrue(m.conn); assertTrue(m.ready)
        assertEquals("6.500", t.getValue("steps").value); assertEquals(65, t.getValue("steps").bar)
        assertEquals("88 bpm", t.getValue("hr").value); assertTrue(t.getValue("hr").live); assertEquals("2 mnt lalu", t.getValue("hr").sub)
        assertEquals("54 bpm", t.getValue("rhr").value); assertEquals("210 kkal", t.getValue("kcal").value); assertEquals("5,00 km", t.getValue("dist").value)
        assertEquals("97%", t.getValue("spo2").value); assertEquals("6j 40m", t.getValue("sleep").value)
        assertTrue(t.getValue("sleep").sub.contains("23:10–06:20 · HR 52"))
        assertEquals("72%", t.getValue("bat").value); assertEquals("HUAWEI WATCH GT · GT 4", m.device)
        assertEquals(52, m.hr!!.min); assertEquals(3, m.hr!!.series.size); assertEquals(mid, m.hr!!.t0)
    }

    @Test fun model_hrLamaBerlabelTerakhir_tanpaDataTidakReady() {
        val l = live(); l.getJSONObject("latest").put("hrTs", now - 3600)
        val t = tiles(build(raw(live = l))).getValue("hr")
        assertFalse(t.live); assertEquals("HR terakhir", t.label)
        val kosong = WatchRaw(JSONObject("""{"state":"disconnected"}"""), JSONObject("""{"today":{},"latest":{},"series":[]}"""), JSONObject("""{"days":[]}"""), emptyList(), emptyList(), 0.0, emptyList(), emptyList())
        val e = WatchDock.model(kosong, now, tz, 190)
        assertFalse(e.ready); assertFalse(e.conn)
    }

    @Test fun totalHarianResmiDipakaiBilaAda() {
        val l = live(); l.put("totals", JSONObject("""{"steps":8123,"calories":321,"distance":6100,"updatedAt":${now - 60}}"""))
        val m = build(raw(live = l)); val t = tiles(m)
        assertEquals("8.123", t.getValue("steps").value); assertTrue(t.getValue("steps").sub.contains("sinkron 1 mnt lalu"))
        assertEquals("321 kkal", t.getValue("kcal").value); assertEquals("6,10 km", t.getValue("dist").value)
        assertTrue(m.debug.rows.any { it.startsWith("Langkah: sampel 6.500 / total jam 8.123") })
    }

    @Test fun totalJamNolTidakMenimpaSampel_grafik7HariSamaDenganUbin() {
        val l = live(); l.put("today", JSONObject("""{"steps":176,"calories":4581,"distance":0,"hrN":10,"hrAvg":70,"hrMin":55,"hrMax":90,"lastTs":${now - 60}}"""))
        l.put("totals", JSONObject("""{"steps":0,"calories":0,"distance":0,"updatedAt":${now - 600}}"""))
        val d = JSONObject("""{"days":[{"day":"2026-10-16","steps":607,"rhrN":2,"rhrAvg":54,"rhrLast":54},{"day":"2026-10-17","steps":176,"rhrN":4,"rhrAvg":55.5,"rhrLast":54}]}""")
        val m = build(raw(live = l, daily = d)); val t = tiles(m)
        assertEquals("176", t.getValue("steps").value); assertEquals("4,6 kkal", t.getValue("kcal").value)
        assertEquals("0,13 km", t.getValue("dist").value); assertTrue(t.getValue("dist").sub.contains("perkiraan"))
        assertEquals("54 bpm", t.getValue("rhr").value); assertEquals("hari ini", t.getValue("rhr").sub)
        assertEquals(176.0, m.wk[6].steps, 0.0); assertEquals(607.0, m.wk[5].steps, 0.0)
        // total jam lebih besar dari sampel: dipakai, dan batang hari ini ikut
        l.put("totals", JSONObject("""{"steps":900,"calories":12,"distance":700,"updatedAt":${now - 30}}"""))
        val m2 = build(raw(live = l, daily = d)); val t2 = tiles(m2)
        assertEquals("900", t2.getValue("steps").value); assertEquals("12 kkal", t2.getValue("kcal").value); assertEquals("0,70 km", t2.getValue("dist").value)
        assertFalse(t2.getValue("dist").sub.contains("perkiraan")); assertEquals(900.0, m2.wk[6].steps, 0.0)
    }

    @Test fun ubinMengikutiBarisHarianBilaKueriLiveMasihNol() {
        val l = live(); l.put("today", JSONObject("""{"steps":0,"calories":0,"distance":0,"hrN":0,"lastTs":${now - 60}}"""))
        l.put("totals", JSONObject("""{"steps":0,"calories":0,"distance":0,"updatedAt":${now - 600}}""")); l.put("series", org.json.JSONArray())
        val d = JSONObject("""{"days":[{"day":"2026-10-17","steps":4200,"calories":150000,"distance":3100,"rhrN":0}]}""")
        val m = build(raw(live = l, daily = d)); val t = tiles(m)
        assertEquals("4.200", t.getValue("steps").value); assertEquals("150 kkal", t.getValue("kcal").value); assertEquals("3,10 km", t.getValue("dist").value)
        assertFalse(t.getValue("dist").sub.contains("perkiraan")); assertEquals(4200.0, m.wk[6].steps, 0.0)
        assertTrue(m.debug.rows.any { it == "Langkah: baris harian (sama dengan batang 7 hari) 4.200" })
    }

    @Test fun spo2Kosong_keteranganJelas_rincianMemuatIsiBingkai() {
        val l = live(); l.getJSONObject("latest").put("spo2", 0); l.getJSONObject("today").put("spo2N", 0)
        val s = status().put("frameStats", "240 step subcontainers (0 unparsed): SpO2 TV in 0 (measured 0)")
        val d = JSONObject("""{"days":[{"day":"2026-10-16","steps":9000,"rhrN":3,"rhrAvg":54.2},{"day":"2026-10-17","steps":6500,"rhrN":4,"rhrAvg":55.5,"rhrMin":53,"rhrLast":54}]}""")
        val m = build(raw(status = s, live = l, daily = d)); val t = tiles(m).getValue("spo2")
        assertEquals("–", t.value); assertTrue(t.sub.contains("belum dikirim jam"))
        assertTrue(m.debug.rows.any { it.contains("SpO2 TV in 0") })
        assertTrue(m.debug.rows.any { it.startsWith("HR istirahat hari ini: 4 sampel · terakhir 54 · min 53") })
    }

    @Test fun indikatorSinkron_penjagaanKoneksi() {
        val s = status().put("keepAlive", true).put("lastSyncAt", now - 120)
        val m = build(raw(status = s)); assertTrue(m.keepAlive)
        assertEquals(WatchDock.SyncState.OK, WatchDock.syncState(m, false, 0))
        assertEquals(WatchDock.SyncState.WARN, WatchDock.syncState(m.copy(lastSyncAt = m.now - 3600), false, 0))
        assertEquals(WatchDock.SyncState.SYNC, WatchDock.syncState(m, true, 0))
        assertEquals(WatchDock.SyncState.OFF, WatchDock.syncState(m.copy(conn = false), false, 0))
        assertFalse(build().keepAlive)
    }

    // ---- baterai ----

    @Test fun baterai_estimasiDariLajuTurunDanMengisi() {
        val log = listOf(BatPoint(now - 3000, 80), BatPoint(now - 1500, 78), BatPoint(now, 76))
        val e = WatchDock.batEst(log, now, 76, 0.0)
        assertNotNull(e.liveH); assertEquals(76.0 / (4 / (3000 / 3600.0)), e.liveH!!, 0.01)
        val mengisi = WatchDock.batEst(listOf(BatPoint(now - 600, 40), BatPoint(now - 60, 45)), now, 45, 0.0)
        assertTrue(mengisi.charging); assertEquals("Sedang mengisi", WatchDock.batTxt(mengisi, tz))
        assertNull(WatchDock.batEst(emptyList(), now, 0, 0.0).liveH)
        assertEquals(40.0, WatchDock.batEst(emptyList(), now, 80, 2.0).runH!!, 0.0)
    }

    @Test fun baterai_logTidakDuplikatDanBatasUsia() {
        val a = WatchDock.batAdd(emptyList(), 80, 1000)
        assertEquals(1, WatchDock.batAdd(a, 80, 1300).size) // sama dan < 10 menit: dilewati
        assertEquals(2, WatchDock.batAdd(a, 79, 1300).size)
        assertEquals(1, WatchDock.batAdd(a, 79, 500).size)  // mundur: ditolak
        assertEquals(1, WatchDock.batAdd(a, 150, 2000).size)
        assertEquals(1, WatchDock.batAdd(a, 70, 1000 + WatchDock.BAT_KEEP + 5).size) // yang lama dipangkas
    }

    @Test fun baterai_sesiLariMemakaiCuplikanDanMenolakJamDiisi() {
        val s = now - 7200; val e = now - 4200
        val ok = listOf(BatPoint(s - 60, 90), BatPoint(s + 1500, 88), BatPoint(e + 60, 85))
        val b = WatchDock.batSession(ok, s, e)!!
        assertEquals(5, b.used); assertFalse(b.ap); assertEquals(6.0, b.ph!!, 0.0)
        val diisi = listOf(BatPoint(s - 60, 50), BatPoint(s + 1500, 60), BatPoint(e + 60, 58))
        assertNull(WatchDock.batSession(diisi, s, e))
    }

    // ---- hipnogram dan grafik ----

    @Test fun hipnogram_infoBlokDiPosisiDanBlokTerdekat() {
        val bl = listOf(HuaweiSleepParity.Block(1000, 1600, "light"), HuaweiSleepParity.Block(1600, 2200, "deep"), HuaweiSleepParity.Block(3000, 3600, "rem"))
        val lb = WatchDock.hypLabels(null)
        assertEquals("deep", WatchDock.hypInfo(bl, 1700, lb, 0)!!.k)
        val celah = WatchDock.hypInfo(bl, 2900, lb, 0)!! // di jeda: blok terdekat
        assertEquals(2, celah.i); assertEquals("10 mnt", celah.dur)
        assertNull(WatchDock.hypInfo(emptyList(), 0, lb, 0))
    }

    @Test fun sumbuGrafik_membulatkanKeKelipatan() {
        assertEquals(2.0, WatchDock.nice(1.2), 0.0); assertEquals(5.0, WatchDock.nice(3.4), 0.0); assertEquals(100.0, WatchDock.nice(70.0), 0.0)
        assertEquals("12,3k", WatchDock.kShort(12345.0)); assertEquals("800", WatchDock.kShort(800.0))
        val (lo, hi) = WatchDock.hrAxis(52, 141); assertTrue(lo <= 50 && hi >= 145)
    }

    @Test fun jamDanZonaWaktu() {
        assertEquals("10:00", WatchDock.clock(now, tz)); assertEquals("2026-10-17", WatchDock.localDate(now, tz))
        val f = WatchDock.faceClock(now, tz); assertEquals("10:00:00", f.first); assertEquals("SAT 10/17", f.second)
    }

    @Test fun cuaca_kodeWmoKeJenisIkon() {
        assertEquals("sun", WatchDock.wxKind(0)); assertEquals("cloud", WatchDock.wxKind(3)); assertEquals("rain", WatchDock.wxKind(61)); assertEquals("rain", WatchDock.wxKind(95))
    }

    @Test fun latihan_paceDanKecepatan() {
        val lari = workout(); assertEquals("6:15", WatchDock.paceCell(lari).v); assertEquals("/km", WatchDock.paceCell(lari).u)
        val sepeda = lari.copy(sportType = 3, distance = 20000, duration = 3600); assertEquals("20,0", WatchDock.paceCell(sepeda).v); assertEquals("km/j", WatchDock.paceCell(sepeda).u)
        assertEquals("–", WatchDock.paceCell(lari.copy(distance = 0)).v)
        assertEquals("50:00", WatchDock.dur(3000)); assertEquals("1:05:07", WatchDock.dur(3907))
        assertTrue(WatchDock.savable(lari)); assertFalse(WatchDock.savable(lari.copy(complete = false)))
    }
}
