package com.endurancevault.app

import com.endurancevault.app.data.ActStore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.nio.file.Files

class ActStoreIntegrityTest {
    @Test fun writeReplacesDetailWithoutLeavingPartialJson() {
        val root = Files.createTempDirectory("ev-act-store").toFile()
        try {
            val store = ActStore(root)
            store.write("f_42.json", mapOf("nm" to "First", "km" to 5.0))
            store.write("f_42.json", mapOf("nm" to "Updated", "km" to 7.5))
            val detail = store.read("f_42.json")
            assertNotNull(detail)
            assertEquals("Updated", detail!!.name)
            assertEquals(7.5, detail.km, 0.0001)
            assertTrue(root.listFiles()!!.none { it.name.endsWith(".tmp") })
        } finally { root.deleteRecursively() }
    }

    @Test fun installingBackupSetKeepsOnlyCurrentBackupDetails() {
        val root = Files.createTempDirectory("ev-act-store-live").toFile()
        val staging = Files.createTempDirectory("ev-act-store-stage").toFile()
        try {
            val store = ActStore(root)
            File(root, "b_2026-11-01.json").writeText("{}")
            File(root, "f_7.json").writeText("{}")
            File(staging, "b_2026-11-05_f1.json").writeText("{\"nm\":\"run\"}")
            store.installBackupFiles(staging)
            assertTrue(File(root, "b_2026-11-05_f1.json").isFile)
            assertTrue(!File(root, "b_2026-11-01.json").exists())
            assertTrue(File(root, "f_7.json").isFile)
        } finally { root.deleteRecursively(); staging.deleteRecursively() }
    }
}
