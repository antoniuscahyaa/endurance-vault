package com.endurancevault.app

import com.endurancevault.app.domain.PWeek
import com.endurancevault.app.domain.PbConversion
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.PlanSettings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

/** Acuan: tests/pb-to-race.test.mjs di versi web (rencana-lari-apk-20). */
class PbConversionTest {
    private fun wk(km: Double, cut: Boolean = false) =
        PWeek(0, LocalDate.of(2026, 7, 6), LocalDate.of(2026, 7, 12), "build", cut, false, false, mutableListOf(), km)

    @Test fun weeksRun() {
        assertEquals(14, PbConversion.weeksRun(LocalDate.of(2026, 7, 6), LocalDate.of(2026, 10, 13)))
        assertEquals(14, PbConversion.weeksRun(LocalDate.of(2026, 7, 8), LocalDate.of(2026, 10, 18)))
        assertEquals(0, PbConversion.weeksRun(LocalDate.of(2026, 10, 12), LocalDate.of(2026, 10, 13)))
        assertEquals(0, PbConversion.weeksRun(LocalDate.of(2026, 11, 2), LocalDate.of(2026, 10, 13)))
    }

    @Test fun baseKm() {
        assertEquals(60, PbConversion.baseKm(listOf(wk(50.0), wk(60.0)), 1, 40.0))
        assertEquals(60, PbConversion.baseKm(listOf(wk(48.0, cut = true)), 0, 40.0))
        assertEquals(45, PbConversion.baseKm(emptyList(), 3, 45.0))
        assertEquals(10, PbConversion.baseKm(listOf(wk(0.0)), 0, 5.0))
    }

    @Test fun buildValidatesAndConverts() {
        val pb = PlanSettings(rtype = "pb", start = LocalDate.of(2026, 7, 6), base = 40.0, peak = 60.0, days = 6)
        val bad = PbConversion.build(pb, "pb", "2027-01-17", "", "", "", "", "65", 14, 60)
        assertEquals("Pilih jenis lomba.", bad.error)
        val noDate = PbConversion.build(pb, "hm", "", "", "", "", "", "65", 14, 60)
        assertEquals("Isi tanggal lomba.", noDate.error)
        val ok = PbConversion.build(pb, "hm", "2027-01-17", "", "", "", "", "65", 14, 60, LocalDate.of(2026, 10, 13))
        assertNull(ok.error)
        assertEquals(14, ok.settings!!.pbConv!!.wk)
        assertEquals(40.0, ok.settings!!.pbConv!!.b0, 0.0)
        assertTrue(ok.plan is PlanOutcome.Ok)
        val back = PbConversion.undo(ok.settings!!)!!
        assertEquals("pb", back.rtype); assertEquals(40.0, back.base, 0.0); assertEquals(60.0, back.peak, 0.0); assertNull(back.pbConv)
    }
}
