package com.endurancevault.app

import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.data.DailyEntity
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.domain.TrainingMetrics
import java.time.LocalDate
import org.junit.Assert.*
import org.junit.Test

class TrainingMetricsTest {
    private val today = LocalDate.of(2026, 11, 6)

    @Test fun noActivitiesReturnsEmptyLoadAndNoCrash() {
        val result = TrainingMetrics.calculate(PlanSettings(), emptyList(), emptyList(), PlanOutcome.Err("none"), today)
        assertTrue(result.days.isEmpty())
        assertEquals("Belum ada data", result.status)
    }

    @Test fun loadBuildsFitnessAndFatigueCurves() {
        val acts = (0..34).filter { it % 2 == 0 }.map { back ->
            ActivityEntity(dateIso = today.minusDays(back.toLong()).toString(), km = 8.0, durationSec = 48 * 60, avgHr = 145)
        }
        val result = TrainingMetrics.calculate(PlanSettings(), acts, emptyList(), PlanOutcome.Err("none"), today)
        assertEquals(35, result.days.size)
        assertTrue(result.weeklyLoad > 0)
        assertTrue(result.fitness > 0)
        assertTrue(result.fatigue >= 0)
        assertEquals(acts.size, result.sessions.size)
    }

    @Test fun heartRateHistogramEnablesAnaerobicEffect() {
        val activity = ActivityEntity(id = 42, dateIso = today.toString(), km = 10.0, durationSec = 3600, avgHr = 150)
        val hist = mapOf(42L to mapOf(150 to 1_800.0, 175 to 900.0))
        val result = TrainingMetrics.calculate(PlanSettings(), listOf(activity), emptyList(), PlanOutcome.Err("none"), today, hrHistByActivity = hist)
        val session = result.sessions.single()
        assertEquals("Histogram HR", session.source)
        assertNotNull(session.anaerobicEffect)
        assertTrue(session.anaerobicEffect!! > 0.0)
    }


    @Test fun watchTrainingEffectAndRecoveryOverrideEstimatesWhenPresent() {
        val activity = ActivityEntity(
            id = 99, dateIso = today.toString(), km = 10.0, durationSec = 3600, avgHr = 150,
            note = """{"source":"huawei-watch","recoveryHours":28.0,"workoutLoad":72,"aerobicEffect":3.7,"anaerobicEffect":2.2}""",
        )
        val session = TrainingMetrics.calculate(
            PlanSettings(), listOf(activity), emptyList(), PlanOutcome.Err("none"), today
        ).sessions.single()
        assertEquals("Huawei Watch", session.source)
        assertEquals(3.7, session.aerobicEffect, 0.001)
        assertEquals(2.2, session.anaerobicEffect!!, 0.001)
        assertEquals(28.0, session.recoveryHours, 0.001)
        assertEquals(72, session.watchLoad)
        assertTrue(session.fromWatch)
    }

    @Test fun readinessUsesDailyInputsAndReportsInsufficientBaselines() {
        val daily = listOf(DailyEntity(today.toString(), rhr = 62, hrv = 35, leg = 4, mood = 4, sleepH = 5.5))
        val acts = listOf(ActivityEntity(dateIso = today.toString(), km = 5.0, durationSec = 1800, avgHr = 145))
        val result = TrainingMetrics.calculate(PlanSettings(), acts, daily, PlanOutcome.Err("none"), today)
        assertNotNull(result.readiness)
        assertTrue(result.readiness!!.parts.any { it.key == "sl" })
        assertTrue(result.readiness!!.parts.any { it.key == "leg" })
        assertTrue(result.readiness!!.parts.any { it.key == "hrv" && it.score == null })
    }
}
