package com.endurancevault.app

import com.endurancevault.app.data.BackupException
import com.endurancevault.app.data.BackupParser
import com.endurancevault.app.domain.PlanEngine
import com.endurancevault.app.domain.PlanOutcome
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class BackupParserTest {
    private val sample = """
    {"app":"rencana-lari","v":1,"sv":2,"at":1767000000000,
     "s":{"name":"Half Semarang","rtype":"hm","start":"2026-11-02","race":"2027-02-21","raceKm":"","base":40,"peak":"65",
          "days":5,"rest":0,"rest2":4,"longDay":6,"hr":150,"thr":"164–172","pace":"6:30","bspd":20,"hrmax":"",
          "pbCycle":"3","pbFocus":"mix","goalT":"1:45:00","evOn":false,"evDate":"","orsKey":"rahasia"},
     "done":{"2026-11-03":1,"2026-11-05":1},
     "log":{"2026-11-03":{"km":5.2,"min":33.5,"hr":142,"hrMax":171,"feel":3,"note":"enak","st":"06:00","gain":40,"gear":"g1","name":"Pagi"},
            "2026-11-05~f1":{"km":8,"min":52,"type":"bike"},
            "rusak":{"km":3}},
     "daily":{"2026-11-03":{"sleep":7,"rhr":52,"hrv":64,"leg":2,"mood":9,"deep":80,"huaweiSleepSource":"watch"},"bukan-tanggal":{"rhr":1}},
     "mv":{"2026-11-04":{"t":"skip"}},"pr":{"2026-11-07":{"name":"Rute","km":12.5,"pts":[[-7.1,110.4]]}},
     "acts":{"2026-11-03":{"nm":"Pagi","trk":[[1,2],[3,4]]}},
     "gear":[{"id":"g1","name":"Sepatu","model":"Nimbus","km0":120.5,"limit":700,"def":true},{"id":"g2","name":"Lama","retired":true,"def":true},{"name":"tanpa id"}],
     "x":{"rl:p":"1","rl:q":"2","rl:r":"3"},
     "ck":"abc"}
    """.trimIndent()

    @Test fun membacaPengaturanDanCatatan() {
        val b = BackupParser.parse(sample.byteInputStream())
        val s = b.settings
        assertEquals("Half Semarang", s.name)
        assertEquals("hm", s.rtype)
        assertEquals(LocalDate.of(2027, 2, 21), s.race)
        assertNull(s.raceKm)
        assertEquals(40.0, s.base, 0.0)
        assertEquals(65.0, s.peak, 0.0)   // string "65" dari web
        assertEquals(5, s.days)
        assertEquals("1:45:00", s.goalT)
        assertNull(s.hrMax)

        assertEquals(2, b.activities.size)   // kunci "rusak" bukan tanggal, dilewati
        val a = b.activities.first { it.srcKey == "2026-11-03" }
        assertEquals(5.2, a.km, 0.0001)
        assertEquals(2010, a.durationSec)
        assertEquals(142, a.avgHr); assertEquals(171, a.maxHr); assertEquals(3, a.feel)
        assertEquals("06:00", a.startTime); assertEquals(40, a.gain); assertEquals("g1", a.gearId)
        val f = b.activities.first { it.srcKey == "2026-11-05~f1" }
        assertEquals("2026-11-05", f.dateIso)
        assertEquals("bike", f.type)

        assertEquals(2, b.doneDays)
        assertEquals(1, b.detailCount)
        assertEquals(3, b.extraKeys)
        assertEquals(1767000000000L, b.exportedAt)
    }

    @Test fun membacaHarianGearDanDataPendamping() {
        val b = BackupParser.parse(sample.byteInputStream())
        assertEquals(1, b.daily.size)               // kunci bukan tanggal dilewati
        val d = b.daily[0]
        assertEquals("2026-11-03", d.dateIso)
        assertEquals(52, d.rhr); assertEquals(64, d.hrv); assertEquals(2, d.leg)
        assertNull(d.mood)                          // mood 9 di luar 1..5
        assertEquals(7.0, d.sleepH!!, 0.0)
        assertTrue(d.raw.contains("\"deep\":80") && d.raw.contains("huaweiSleepSource"))   // field lain tidak hilang

        assertEquals(2, b.gear.size)                // entri tanpa id dilewati
        val g1 = b.gear.first { it.id == "g1" }
        assertEquals("Nimbus", g1.model); assertEquals(120.5, g1.km0, 0.0); assertEquals(700.0, g1.limitKm, 0.0)
        assertTrue(g1.isDefault)
        val g2 = b.gear.first { it.id == "g2" }
        assertTrue(g2.retired); assertTrue(!g2.isDefault)   // gear pensiun tidak bisa jadi bawaan

        assertEquals(setOf("done", "mv", "pr"), b.kv.keys)
        assertEquals("{\"2026-11-03\":1,\"2026-11-05\":1}", b.kv["done"])
        assertEquals("{\"2026-11-04\":{\"t\":\"skip\"}}", b.kv["mv"])
        assertTrue(b.kv["pr"]!!.contains("\"km\":12.5") && b.kv["pr"]!!.contains("[[-7.1,110.4]]"))
    }

    @Test fun pengaturanHasilImporBisaMembuatRencana() {
        val s = BackupParser.parse(sample.byteInputStream()).settings
        val r = PlanEngine.plan(s, LocalDate.of(2026, 11, 5))
        assertTrue(r is PlanOutcome.Ok)
        assertEquals(16, (r as PlanOutcome.Ok).weeks.size)
    }

    @Test fun cadanganLamaTanpaFieldBaruMemakaiBawaan() {
        // sample tidak punya method, qSess, sLeg, sAnk, sUp: strength menyala seperti di web (kosong = nyala)
        val s = BackupParser.parse(sample.byteInputStream()).settings
        assertEquals("default", s.method)
        assertEquals("1", s.qSess)
        assertTrue(s.sLeg); assertTrue(s.sAnk)
        assertEquals("auto", s.sUp)
    }

    @Test fun membacaMetodeLatihanSesiKeduaDanStrength() {
        val json = sample.replace("\"orsKey\":\"rahasia\"",
            "\"method\":\"pyramidal\",\"qSess\":2,\"sLeg\":false,\"sAnk\":true,\"sUp\":\"2\"")
        val s = BackupParser.parse(json.byteInputStream()).settings
        assertEquals("pyramidal", s.method)
        assertEquals("2", s.qSess)        // angka 2 dari web menjadi teks "2"
        assertEquals(false, s.sLeg); assertTrue(s.sAnk)
        assertEquals("2", s.sUp)
        // metode tak dikenal jatuh ke bawaan
        val bad = BackupParser.parse(sample.replace("\"orsKey\":\"rahasia\"", "\"method\":\"aneh\"").byteInputStream()).settings
        assertEquals("default", bad.method)
    }

    @Test fun menolakBerkasBukanCadangan() {
        try { BackupParser.parse("""{"app":"lain","v":1}""".byteInputStream()); fail() } catch (e: BackupException) { }
        try { BackupParser.parse("[1,2]".byteInputStream()); fail() } catch (e: BackupException) { }
    }

    @Test fun menolakBerkasTerpotong() {
        try { BackupParser.parse(sample.take(sample.length / 2).byteInputStream()); fail() } catch (e: BackupException) { }
    }
}
