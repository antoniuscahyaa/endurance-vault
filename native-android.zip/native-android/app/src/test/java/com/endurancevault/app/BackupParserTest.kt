package com.endurancevault.app

import com.endurancevault.app.data.BackupException
import com.endurancevault.app.data.BackupParser
import com.endurancevault.app.domain.PlanEngine
import com.endurancevault.app.domain.PlanOutcome
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class BackupParserTest {
    private val sample = """
    {"app":"rencana-lari","v":1,"sv":2,"at":1767000000000,
     "s":{"name":"Half Semarang","rtype":"hm","start":"2026-11-02","race":"2027-02-21","raceKm":"","base":40,"peak":"65",
          "days":5,"rest":0,"rest2":4,"longDay":6,"hr":150,"thr":"164–172","pace":"6:30","bspd":20,"hrmax":"",
          "pbCycle":"3","pbFocus":"mix","goalT":"1:45:00","evOn":false,"evDate":"","orsKey":"rahasia"},
     "done":{"2026-11-03":1,"2026-11-05":1},
     "log":{"2026-11-03":{"km":5.2,"min":33.5,"hr":142,"hrMax":171,"feel":3,"note":"enak","st":"06:00","gain":40,"gear":"g1","name":"Pagi"},
            "2026-11-05~f1":{"km":8,"min":52,"type":"bike"},
            "rusak":{"km":3}},
     "daily":{"2026-11-03":{"sleep":7}},
     "acts":{"2026-11-03":{"nm":"Pagi","trk":[[1,2],[3,4]]}},
     "gear":[{"id":"g1","name":"Sepatu"}],
     "x":{"rl:p":"1","rl:q":"2","rl:r":"3"},
     "ck":"abc"}
    """.trimIndent()

    @Test fun membacaPengaturanDanCatatan() {
        val b = BackupParser.parse(sample.byteInputStream())
        val s = b.settings
        assertEquals("Half Semarang", s.name)
        assertEquals("hm", s.rtype)
        assertEquals(LocalDate.of(2027, 2, 21), s.race)
        assertNull(s.raceKm)
        assertEquals(40.0, s.base, 0.0)
        assertEquals(65.0, s.peak, 0.0)   // string "65" dari web
        assertEquals(5, s.days)
        assertEquals("1:45:00", s.goalT)
        assertNull(s.hrMax)

        assertEquals(2, b.activities.size)   // kunci "rusak" bukan tanggal, dilewati
        val a = b.activities.first { it.srcKey == "2026-11-03" }
        assertEquals(5.2, a.km, 0.0001)
        assertEquals(2010, a.durationSec)
        assertEquals(142, a.avgHr); assertEquals(171, a.maxHr); assertEquals(3, a.feel)
        assertEquals("06:00", a.startTime); assertEquals(40, a.gain); assertEquals("g1", a.gearId)
        val f = b.activities.first { it.srcKey == "2026-11-05~f1" }
        assertEquals("2026-11-05", f.dateIso)
        assertEquals("bike", f.type)

        assertEquals(2, b.doneDays)
        assertEquals(1, b.detailCount)
        assertEquals(3, b.extraKeys)
        assertEquals(1767000000000L, b.exportedAt)
    }

    @Test fun pengaturanHasilImporBisaMembuatRencana() {
        val s = BackupParser.parse(sample.byteInputStream()).settings
        val r = PlanEngine.plan(s, LocalDate.of(2026, 11, 5))
        assertTrue(r is PlanOutcome.Ok)
        assertEquals(16, (r as PlanOutcome.Ok).weeks.size)
    }

    @Test fun menolakBerkasBukanCadangan() {
        try { BackupParser.parse("""{"app":"lain","v":1}""".byteInputStream()); fail() } catch (e: BackupException) { }
        try { BackupParser.parse("[1,2]".byteInputStream()); fail() } catch (e: BackupException) { }
    }

    @Test fun menolakBerkasTerpotong() {
        try { BackupParser.parse(sample.take(sample.length / 2).byteInputStream()); fail() } catch (e: BackupException) { }
    }
}
