package com.endurancevault.app

import com.endurancevault.app.domain.ActWeather
import com.endurancevault.app.domain.EffortPace
import com.endurancevault.app.domain.FeelCheck
import com.endurancevault.app.domain.ZoneCuts
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class EffortPaceTest {
    private val heat = EffortPace.Heat(EffortPace.DEFAULT_K, false, 0)

    @Test fun noCorrectionAtOrBelowNeutral() {
        val r = EffortPace.compute(6.5, ActWeather(tempC = 14.0), null, heat)!!
        assertEquals(6.5, r.pace, 1e-9)
    }

    @Test fun heatMakesEffortPaceFasterThanGap() {
        val gap = 391.0 / 60.0 // 6:31
        val r = EffortPace.compute(gap, ActWeather(tempC = 25.0), null, heat)!!
        assertTrue(r.pace < gap)
        assertEquals(1.3, r.heatPct, 0.05)
    }

    @Test fun missingGapGivesNull() {
        assertNull(EffortPace.compute(null, ActWeather(tempC = 25.0), null, heat))
    }

    @Test fun calibrationFallsBackWithoutHistory() {
        val h = EffortPace.calibrate(emptyList(), 170)
        assertFalse(h.personal)
        assertEquals(EffortPace.DEFAULT_K, h.k, 0.0)
    }

    @Test fun verticalSpeedOnlyWhenClimbIsAtLeast15PercentOfDistance() {
        assertFalse(com.endurancevault.app.domain.ActInsights.showVerticalSpeed(150, 10.0))
        assertTrue(com.endurancevault.app.domain.ActInsights.showVerticalSpeed(151, 10.0))
        assertFalse(com.endurancevault.app.domain.ActInsights.showVerticalSpeed(29, 13.0))
        assertFalse(com.endurancevault.app.domain.ActInsights.showVerticalSpeed(null, 10.0))
    }

    private val cuts = ZoneCuts("lthr", listOf(0, 145, 153, 162, 170), 190, lthr = 170)

    @Test fun feelMatchingZoneIsEfficient() {
        val r = FeelCheck.evaluate(3, 149, cuts)
        assertNotNull(r)
        assertEquals("ok", r!!.level)
        assertEquals(2, r.zone)
    }

    @Test fun feelHarderThanHrWarns() {
        assertEquals("warn", FeelCheck.evaluate(8, 149, cuts)!!.level)
    }

    @Test fun feelEasierThanHrIsInfo() {
        assertEquals("info", FeelCheck.evaluate(1, 160, cuts)!!.level)
    }

    @Test fun noFeelNoCheck() {
        assertNull(FeelCheck.evaluate(null, 149, cuts))
    }
}
