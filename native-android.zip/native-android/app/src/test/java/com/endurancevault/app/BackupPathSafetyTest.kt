package com.endurancevault.app

import com.endurancevault.app.data.BackupParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test
import java.nio.file.Files

class BackupPathSafetyTest {
    @Test fun extractActsSkipsKeysThatCouldEscapeStagingDirectory() {
        val staging = Files.createTempDirectory("ev-backup-stage").toFile()
        try {
            val json = """{"app":"rencana-lari","v":1,"acts":{"../../escape":{"nm":"bad"},"2026-11-05~f1":{"nm":"good"}}}"""
            val keys = BackupParser.extractActs(json.byteInputStream(), staging)
            assertEquals(listOf("2026-11-05~f1"), keys)
            assertEquals(1, staging.listFiles()!!.size)
            assertFalse(java.io.File(staging.parentFile, "escape.json").exists())
        } finally { staging.deleteRecursively() }
    }
}
