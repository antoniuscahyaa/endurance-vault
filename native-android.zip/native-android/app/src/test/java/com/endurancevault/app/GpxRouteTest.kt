package com.endurancevault.app

import com.endurancevault.app.domain.CourseStrategy.Pt
import com.endurancevault.app.domain.GpxRoute
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class GpxRouteTest {
    private fun gpx(name: String?, pts: List<Triple<Double, Double, Double?>>, tag: String = "trkpt") =
        "<?xml version=\"1.0\"?><gpx xmlns=\"http://www.topografix.com/GPX/1/1\">" +
            (if (name != null) "<metadata><name>$name</name></metadata>" else "") +
            (if (tag == "trkpt") "<trk><trkseg>" else "<rte>") +
            pts.joinToString("") { (la, lo, e) -> "<$tag lat=\"$la\" lon=\"$lo\">" + (if (e != null) "<ele>$e</ele>" else "") + "</$tag>" } +
            (if (tag == "trkpt") "</trkseg></trk>" else "</rte>") + "</gpx>"

    private val line = (0..40).map { Triple(-6.0 + it * 0.001, 106.0, 100.0 + it * 2.0) }

    @Test fun parseTrkptDanNamaDariMetadata() {
        val p = GpxRoute.preview(gpx("Bukit Cinta", line), "x.gpx")
        assertEquals("Bukit Cinta", p.name)
        assertEquals(41, p.total)
        assertTrue(p.km > 4.3 && p.km < 4.6)
        assertTrue(p.stats.hasEle)
        assertEquals(80, p.stats.up)
    }

    @Test fun rteptDipakaiBilaTidakAdaTrkptDanNamaDariBerkas() {
        val p = GpxRoute.preview(gpx(null, line, "rtept"), "rute-pagi.gpx")
        assertEquals("rute-pagi", p.name)
        assertEquals(41, p.total)
    }

    @Test fun kurangDariDuaTitikDitolak() {
        try { GpxRoute.preview(gpx("A", listOf(Triple(-6.0, 106.0, 1.0))), "a.gpx"); fail() } catch (e: GpxRoute.Err) { assertTrue(e.message!!.contains("minimal 2 titik")) }
        try { GpxRoute.preview("bukan xml", "a.gpx"); fail() } catch (e: GpxRoute.Err) { assertTrue(e.message!!.contains("tidak bisa dibaca")) }
    }

    @Test fun doctypeDitolakAgarAmanDariXxe() {
        val evil = "<?xml version=\"1.0\"?><!DOCTYPE gpx [<!ENTITY x SYSTEM \"file:///etc/passwd\">]><gpx><trk><trkseg></trkseg></trk></gpx>"
        try { GpxRoute.preview(evil, "e.gpx"); fail() } catch (e: GpxRoute.Err) { }
    }

    @Test fun payloadMembuangTitikKembarDanMenjarangkan() {
        val dup = listOf(Pt(-6.0, 106.0, 1.0), Pt(-6.0, 106.0, 1.0), Pt(-6.001, 106.0, null))
        val (json, n) = GpxRoute.payload("R", dup)!!
        assertEquals(2, n)
        val pts = JSONObject(json).getJSONArray("points")
        assertTrue(pts.getJSONArray(1).isNull(2))
        val many = (0 until 3000).map { Pt(-6.0 + it * 0.0001, 106.0, 10.0) }
        assertEquals(1000, GpxRoute.payload("R", many)!!.second)
        assertNull(GpxRoute.payload("R", listOf(Pt(-6.0, 106.0, 1.0), Pt(-6.0, 106.0, 2.0))))
    }

    @Test fun namaDipotongSampai60Byte() {
        val n = GpxRoute.routeName("é".repeat(50))
        assertTrue(n.toByteArray(Charsets.UTF_8).size <= 60)
        assertEquals("Rute", GpxRoute.routeName("   "))
    }

    @Test fun statistikAbaikanDerauKurangDari3m() {
        val pts = (0..10).map { Pt(-6.0 + it * 0.0005, 106.0, 100.0 + (if (it % 2 == 0) 0.0 else 2.0)) }
        val st = GpxRoute.stats(pts)
        assertEquals(0, st.up); assertEquals(0, st.down)
        assertFalse(GpxRoute.stats(listOf(Pt(0.0, 0.0, null), Pt(0.0, 0.01, null))).hasEle)
    }

    @Test fun paceCourseSatuLangkahPerRuasDenganRentangPace() {
        val pts = (0..320).map { i ->
            val d = 16.0 * i / 320
            val e = when { d < 3 -> 100.0; d < 6 -> 100.0 + (d - 3) / 3 * 300; d < 10 -> 400.0; d < 13 -> 400.0 - (d - 10) / 3 * 300; else -> 100.0 }
            Pt(-6.0 + d / 111.19, 106.0, e)
        }
        val r = com.endurancevault.app.domain.CourseStrategy.pacing(pts, "2:00:00", "even", "norm").result!!
        val json = GpxRoute.paceCourse("Bukit Cinta", r, "ev-pace-1")!!
        val course = JSONObject(json).getJSONArray("courses").getJSONObject(0)
        assertEquals("ev-pace-1", course.getString("id"))
        val steps = course.getJSONArray("blocks").getJSONObject(0).getJSONArray("steps")
        assertTrue(steps.length() in 1..100)
        var meters = 0; var secs = 0.0
        for (i in 0 until steps.length()) {
            val st = steps.getJSONObject(i)
            assertEquals("distance", st.getString("target")); assertEquals("pace", st.getString("intensity"))
            val lo = st.getInt("low"); val hi = st.getInt("high")
            assertTrue(lo in 60..900 && hi in 60..900 && lo <= hi)
            meters += st.getInt("value"); secs += (lo + hi) / 2.0 * st.getInt("value") / 1000.0
        }
        assertEquals(r.km * 1000, meters.toDouble(), 100.0)       // jarak total ikut rute
        assertEquals(7200.0, secs, 7200.0 * 0.03)                  // total waktu tetap ~ target
    }
}
