package com.endurancevault.app

import com.endurancevault.app.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

class InjuryPreventionTest {
    @Test fun groupedPainAlertsMatchLegacyThreeOfFourOrAcuteRule() {
        val d = LocalDate.parse("2026-11-07")
        val entries = listOf(0L, 1L, 3L).map { PainReadinessEntry(d.minusDays(it), "betis", 2, "k", "sl") }
        assertEquals(1, InjuryPrevention.alerts(entries, d).size)
        assertEquals("betis", InjuryPrevention.alerts(entries, d).single().area)
    }
    @Test fun severePainInLastTwoDaysTriggersAlertAndBikeEligibility() {
        val d = LocalDate.parse("2026-11-07")
        val entries = listOf(PainReadinessEntry(d, "lutut", 4, "r", "sa"))
        assertTrue(InjuryPrevention.alerts(entries, d).single().acute)
        assertTrue(InjuryPrevention.shouldOfferBikeSwap(entries, d))
    }
    @Test fun prehabIsAreaSpecific() {
        val d = LocalDate.parse("2026-11-07")
        val advice = InjuryPrevention.prehab(listOf(PainReadinessEntry(d, "achilles", 4)), d)!!
        assertEquals("achilles", advice.area)
        assertTrue(advice.exercises.any { it.contains("isometrik") })
    }
    @Test fun bikeConversionIsCappedAndUsesZoneTwo() {
        val plan = InjuryPrevention.bikeReplacement(240, "quality", 170..185, 140..150, 55, 190, bikeSpeedKmh = 20.0)!!
        assertTrue(plan.minutes in 20..300)
        assertTrue(plan.capped || plan.minutes <= 300)
        assertTrue(plan.replacesQuality)
        assertTrue(plan.estimatedKm > 0)
    }
    @Test fun bikeCalibrationMovesOffsetInTwoBpmSteps() {
        val eval = BikeSessionEvaluation(50, 60, .9, 145, false, "ok")
        val result = InjuryPrevention.calibrateBikeOffset(List(4) { eval to 4 }, 8)
        assertEquals(10, result.suggestedOffset)
        assertEquals(4, result.heavy)
    }
    @Test fun returnToRunUsesLegacyThreePhases() {
        val start = LocalDate.parse("2026-10-01")
        assertEquals(65, InjuryPrevention.returnRunPhase(start, start)!!.percent)
        assertEquals(80, InjuryPrevention.returnRunPhase(start, start.plusDays(7))!!.percent)
        assertEquals(90, InjuryPrevention.returnRunPhase(start, start.plusDays(14))!!.percent)
        assertNull(InjuryPrevention.returnRunPhase(start, start.plusDays(21)))
    }
}
