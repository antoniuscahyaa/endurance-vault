package com.endurancevault.app

import com.endurancevault.app.domain.EasyPace
import com.endurancevault.app.domain.EasyPace.Run
import com.endurancevault.app.domain.ZoneChecks
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class ZoneChecksTest {
    @Test fun paceFormat() {
        assertNull(ZoneChecks.pace("6:30"))
        assertNull(ZoneChecks.pace(" 7:05 "))
        assertNotNull(ZoneChecks.pace("6.30"))
        assertNotNull(ZoneChecks.pace("6:75"))
        assertNotNull(ZoneChecks.pace("2:10"))
        assertNotNull(ZoneChecks.pace("13:00"))
        assertNotNull(ZoneChecks.pace(""))
    }

    @Test fun thrRange() {
        assertNull(ZoneChecks.thrRange("164–172"))
        assertNull(ZoneChecks.thrRange("164-172"))
        assertNotNull(ZoneChecks.thrRange("172–164"))
        assertNotNull(ZoneChecks.thrRange("172"))
        assertNotNull(ZoneChecks.thrRange("abc"))
    }

    @Test fun easyHr() {
        assertNull(ZoneChecks.easyHr("154"))
        assertNotNull(ZoneChecks.easyHr("40"))
        assertNotNull(ZoneChecks.easyHr(""))
    }

    @Test fun pctIssuesUrutanDanBatas() {
        val l = listOf("Z2", "Z3", "Z4", "Z5")
        assertEquals(listOf<String?>(null, null, null, null), ZoneChecks.pctIssues(listOf(85.0, 90.0, 95.0, 100.0), l, 150.0))
        val r = ZoneChecks.pctIssues(listOf(85.0, 80.0, 95.0, null), l, 150.0)
        assertNull(r[0])
        assertEquals("Z3: harus lebih besar dari Z2 (85%)", r[1])
        assertNull(r[2])
        assertEquals("Z5: isi angka", r[3])
        assertEquals("Z2: maksimal 150%", ZoneChecks.pctIssues(listOf(160.0), listOf("Z2"), 150.0)[0])
    }

    @Test fun rataRataLariEasyTerakhir() {
        val runs = listOf(
            Run("2026-11-06", 10.0, 70.0, 140),                // 7:00
            Run("2026-11-05", 5.0, 30.0, 145),                 // 6:00
            Run("2026-11-04", 8.0, 40.0, 170),                 // HR di atas batas, tidak ikut
            Run("2026-11-03", 12.0, 60.0, 140, type = "bike"), // sepeda, tidak ikut
            Run("2026-11-02", 5.0, 25.0, 140, gain = 150),     // terlalu menanjak, tidak ikut
            Run("2026-11-01", 5.0, 35.0, 135),                 // 7:00
            Run("2026-10-20", 5.0, 20.0, 130),                 // 4:00, di luar 3 lari terakhir
        )
        val r = EasyPace.recentAverage(runs, 150, n = 3)!!
        assertEquals(3, r.n)
        assertEquals(20.0, r.km, 1e-9)
        assertEquals(135.0 / 20.0, r.pace, 1e-9)
        assertEquals("2026-11-01", r.firstDate)
        assertEquals("2026-11-06", r.lastDate)
        assertNull(EasyPace.recentAverage(listOf(Run("2026-11-06", 5.0, 25.0, 170)), 150))
    }
}
