package com.endurancevault.app

import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.data.DailyEntity
import com.endurancevault.app.domain.Kinds
import com.endurancevault.app.domain.PDay
import com.endurancevault.app.domain.PWeek
import com.endurancevault.app.domain.Phases
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.domain.TrainingMetrics
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TrainingReadinessTest {
    private val today = LocalDate.of(2026, 11, 6)

    @Test fun sleepScoreIncludesNapAwakeningsAndSleepStages() {
        val daily = DailyEntity(
            dateIso = today.toString(),
            sleepH = 6.0,
            raw = """{"sleep":6,"nap":30,"wkN":2,"wks":[{"m":20,"g":false}],"deep":90,"rem":90,"light":180}"""
        )
        val result = TrainingMetrics.calculate(
            PlanSettings(), emptyList(), listOf(daily), PlanOutcome.Err("no plan"), today
        )
        val sleep = result.readiness!!.parts.first { it.key == "sl" }
        assertEquals(6.5, sleep.detail.substringBefore(" jam").toDouble(), 0.01)
        assertTrue(sleep.score!! in 60..70)
        assertTrue(sleep.detail.contains("2× terbangun"))
        assertTrue(sleep.detail.contains("20 menit terjaga"))
    }

    @Test fun readinessCanRecommendSwappingQualityWhenScoreIsLow() {
        val workout = PDay(today, 3, Kinds.QUALITY, "q", "Sesi kualitas", 10.0, "quality")
        val week = PWeek(0, today.minusDays(1), today.plusDays(5), Phases.BUILD, false, false, false, mutableListOf(workout), 35.0)
        val plan = PlanOutcome.Ok(listOf(week), today.minusDays(1), today.plusDays(60), 9, false, false, true, 0, 0)
        val daily = DailyEntity(today.toString(), leg = 5, mood = 5, sleepH = 4.0, raw = """{"sleep":4}""")
        val result = TrainingMetrics.calculate(PlanSettings(), emptyList(), listOf(daily), plan, today)
        assertNotNull(result.readiness)
        assertTrue(result.readiness!!.score < 50)
        assertNotNull(result.planAdjustment)
        assertEquals("swap", result.planAdjustment!!.action)
        assertTrue(result.planAdjustment!!.suggestedKm in 3.0..6.0)
    }

    @Test fun noAdjustmentWhenReadinessIsHighOrRestDay() {
        val rest = PDay(today, 3, Kinds.REST, "rest", "Istirahat", 0.0, "")
        val week = PWeek(0, today.minusDays(1), today.plusDays(5), Phases.BUILD, false, false, false, mutableListOf(rest), 30.0)
        val plan = PlanOutcome.Ok(listOf(week), today.minusDays(1), today.plusDays(60), 9, false, false, true, 0, 0)
        val daily = DailyEntity(today.toString(), leg = 1, mood = 1, sleepH = 8.0, raw = """{"sleep":8}""")
        val result = TrainingMetrics.calculate(PlanSettings(), emptyList(), listOf(daily), plan, today)
        assertNull(result.planAdjustment)
    }
    @Test fun manualReadinessWeightsChangeTheCompositeScore() {
        val daily = DailyEntity(today.toString(), leg = 5, mood = 1, sleepH = 8.0, raw = """{"sleep":8}""")
        val standard = TrainingMetrics.calculate(PlanSettings(), emptyList(), listOf(daily), PlanOutcome.Err("no plan"), today).readiness!!
        val weighted = TrainingMetrics.calculate(
            PlanSettings(), emptyList(), listOf(daily), PlanOutcome.Err("no plan"), today,
            readinessConfig = com.endurancevault.app.domain.ReadinessConfig(weights = mapOf("leg" to 50.0))
        ).readiness!!
        assertTrue(weighted.score < standard.score)
    }

    @Test fun customSleepNeedChangesSevenDayDebt() {
        val days = (0..2).map { offset ->
            val date = today.minusDays(offset.toLong())
            DailyEntity(date.toString(), sleepH = 6.0, raw = """{"sleep":6}""")
        }
        val standard = TrainingMetrics.calculate(PlanSettings(), emptyList(), days, PlanOutcome.Err("no plan"), today).readiness!!
        val custom = TrainingMetrics.calculate(PlanSettings(), emptyList(), days, PlanOutcome.Err("no plan"), today,
            readinessConfig = com.endurancevault.app.domain.ReadinessConfig(sleepNeedHours = 9.0)).readiness!!
        val standardDebt = standard.parts.first { it.key == "debt" }.score!!
        val customDebt = custom.parts.first { it.key == "debt" }.score!!
        assertTrue(customDebt < standardDebt)
    }

    @Test fun recentPainIsIncludedAndRecurringPainReducesScore() {
        val entries = listOf(
            com.endurancevault.app.domain.PainReadinessEntry(today, "Betis", 3),
            com.endurancevault.app.domain.PainReadinessEntry(today.minusDays(1), "Betis", 2),
            com.endurancevault.app.domain.PainReadinessEntry(today.minusDays(2), "Betis", 2),
        )
        val result = TrainingMetrics.calculate(PlanSettings(), emptyList(), emptyList(), PlanOutcome.Err("no plan"), today,
            readinessConfig = com.endurancevault.app.domain.ReadinessConfig(painEntries = entries)).readiness!!
        val pain = result.parts.first { it.key == "pain" }
        assertEquals(45, pain.score)
        assertTrue(pain.detail.contains("berulang"))
    }

    @Test fun readinessConfigKeepsThresholdOrderingValid() {
        val config = com.endurancevault.app.domain.ReadinessConfig(swapThreshold = 90, lightThreshold = 30, easyThreshold = 70).safe()
        assertTrue(config.swapThreshold in 20..80)
        assertTrue(config.lightThreshold > config.swapThreshold)
        assertTrue(config.easyThreshold <= config.swapThreshold)
    }

    @Test fun latestManualConditionRowDoesNotHidePriorNightSleepOrWatchVitals() {
        val days = listOf(
            DailyEntity(today.minusDays(4).toString(), rhr = 50, hrv = 80, raw = """{"shr":45}"""),
            DailyEntity(today.minusDays(3).toString(), rhr = 50, hrv = 82, raw = """{"shr":46}"""),
            DailyEntity(today.minusDays(2).toString(), rhr = 51, hrv = 81, raw = """{"shr":45}"""),
            DailyEntity(today.minusDays(1).toString(), rhr = 49, hrv = 78, sleepH = 6.5, raw = """{"sleep":6.5,"shr":46,"deep":80,"rem":90,"light":220}"""),
            // Today's manual leg/mood check has no sleep or sensor values.
            DailyEntity(today.toString(), leg = 2, mood = 1, raw = """{"source":"manual"}"""),
        )
        val result = TrainingMetrics.calculate(PlanSettings(), emptyList(), days, PlanOutcome.Err("no plan"), today).readiness!!
        assertTrue(result.parts.any { it.key == "sl" })
        assertTrue(result.parts.any { it.key == "hrv" && it.score != null })
        assertTrue(result.parts.any { it.key == "rhr" && it.score != null })
        assertTrue(result.parts.any { it.key == "shr" && it.score != null })
    }


    @Test fun noDataGapsFromTheWatchAreNotAwakeTimeEvenWhenFlaggedAsNumber() {
        val daily = DailyEntity(today.toString(), sleepH = 7.0,
            raw = """{"sleep":7,"wks":[{"a":"02:00","b":"02:25","m":25,"g":1},{"a":"04:00","b":"04:10","m":10,"g":0}],"wkN":1}""")
        val sleep = TrainingMetrics.calculate(PlanSettings(), emptyList(), listOf(daily), PlanOutcome.Err("no plan"), today)
            .readiness!!.parts.first { it.key == "sl" }
        // 10 awake minutes + 1 wake-up: base 86, penalty 6 + 1 -> 79
        assertEquals(79, sleep.score)
        assertTrue(sleep.detail.contains("10 menit terjaga"))
    }

    @Test fun manualAwakeSpanNeedsToLieBetweenBedAndWakeTime() {
        fun score(wk: String, re: String) = TrainingMetrics.calculate(PlanSettings(), emptyList(),
            listOf(DailyEntity(today.toString(), sleepH = 7.0, raw = """{"sleep":7,"bed":"23:00","wake":"06:00","wkAt":"$wk","reAt":"$re"}""")),
            PlanOutcome.Err("no plan"), today).readiness!!.parts.first { it.key == "sl" }.score!!
        assertEquals(79, score("03:00", "03:10")) // base 86, one wake-up (-6), 10 awake minutes (-1)
        assertEquals(86, score("07:00", "07:30")) // span lies outside bed..wake: ignored
    }

    @Test fun readinessRecoveryFactorDoesNotCountMorningConditionTwice() {
        fun run(todayRhr: Int): Pair<Int, Int> {
            val daily = (1..4).map { DailyEntity(today.minusDays(it.toLong()).toString(), rhr = 50, raw = "{}") } +
                DailyEntity(today.toString(), rhr = todayRhr, raw = "{}")
            val act = ActivityEntity(id = 7, dateIso = today.toString(), km = 10.0, durationSec = 3600, avgHr = 150,
                note = """{"source":"huawei-watch","recoveryHours":90.0}""")
            val r = TrainingMetrics.calculate(PlanSettings(), listOf(act), daily, PlanOutcome.Err("no plan"), today)
            return r.morningPts to r.readiness!!.parts.first { it.key == "rec" }.score!!
        }
        val (ptsHigh, recHigh) = run(62)
        val (ptsNormal, recNormal) = run(50)
        assertTrue(ptsHigh > 0); assertEquals(0, ptsNormal)
        assertEquals(recNormal, recHigh)
    }
}
