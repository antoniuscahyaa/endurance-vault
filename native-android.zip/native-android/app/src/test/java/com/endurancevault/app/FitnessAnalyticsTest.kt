package com.endurancevault.app

import com.endurancevault.app.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

class FitnessAnalyticsTest {
    private val today = LocalDate.parse("2026-11-04") // Rabu
    private fun d(s: String) = LocalDate.parse(s)

    private fun split(k: Double, pace: Double, hr: Int?, gain: Int = 0, loss: Int = 0, gap: Double? = null, partial: Boolean = false) =
        Split(k, pace, hr, gain, loss, null, gap, partial)

    private fun detail(date: String, splits: List<Split>, km: Double = splits.lastOrNull()?.k ?: 0.0, bike: Boolean = false) = ActDetail(
        date = date, startTime = "06:00", name = "Run", bike = bike, kind = null, km = km, movingMin = km * 6, elapsedMin = km * 6,
        gain = null, loss = null, hr = null, hrMax = null, cad = null, gapPace = null, splits = splits, segments = emptyList(),
        route = emptyList(), routeW = 0, routeH = 0, profile = emptyList(), paceSeries = emptyList(), hrSeries = emptyList(),
        cadSeries = emptyList(), hrHist = emptyMap(),
    )

    @Test fun labelsFollowWebThresholds() {
        assertEquals("Elit", FitnessAnalytics.raiLabel(60.0))
        assertEquals("Berkembang", FitnessAnalytics.raiLabel(35.9))
        assertEquals("Sedang", FitnessAnalytics.fitLabel(40))
        assertEquals("Sangat rendah", FitnessAnalytics.fitLabel(19))
        assertEquals("Segar", FitnessAnalytics.fatLabel(14))
        assertEquals("Sangat lelah", FitnessAnalytics.fatLabel(80))
        assertEquals("Pulih", FitnessAnalytics.recoveryText(1))
        assertEquals("30 jam", FitnessAnalytics.recoveryText(30))
        assertEquals("2,5 hari", FitnessAnalytics.recoveryText(60))
    }

    @Test fun paceZonesMatchLegacyFormula() {
        // zona yang lebih berat selalu lebih cepat (menit/km lebih kecil)
        val vd = 50.0
        val easyLo = FitnessAnalytics.paceAtFrac(vd, .62)
        val easyHi = FitnessAnalytics.paceAtFrac(vd, .74)
        val vo2 = FitnessAnalytics.paceAtFrac(vd, 1.0)
        assertTrue(easyLo > easyHi)
        assertTrue(easyHi > vo2)
        // VO2 = 50 pada 100%: v ≈ 260,8 m/menit atau sekitar 3:50 /km
        assertEquals(3.835, vo2, 0.02)
        assertEquals(4, FitnessAnalytics.PACE_ZONES.size)
    }

    @Test fun aerobicEfficiencyUsesOnlyKilometresNearTargetHr() {
        val sp = (1..6).map { split(it.toDouble(), 6.0, 140) } + listOf(split(7.0, 5.0, 170))
        val p = FitnessAnalytics.aeRun(detail("2026-10-20", sp), 140, 4)
        assertNotNull(p)
        assertEquals(6.0, p!!.pace, 1e-9)
        assertEquals(6.0, p.km, 1e-9)
        // HR target jauh dari data: tidak ada titik
        assertNull(FitnessAnalytics.aeRun(detail("2026-10-20", sp), 120, 4))
        // sepeda diabaikan
        assertNull(FitnessAnalytics.aeRun(detail("2026-10-20", sp, bike = true), 140, 4))
        // kurang dari 1,5 km di rentang
        assertNull(FitnessAnalytics.aeRun(detail("2026-10-20", listOf(split(1.0, 6.0, 140))), 140, 4))
    }

    @Test fun aerobicEfficiencyPrefersGapAndSkipsHillyKilometresWithoutGap() {
        val sp = listOf(
            split(1.0, 6.0, 140, gain = 40), split(2.0, 6.0, 140, gain = 5, loss = 5),
            split(3.0, 6.0, 140, gap = 5.5), split(4.0, 6.0, 140),
        )
        val p = FitnessAnalytics.aeRun(detail("2026-10-20", sp), 140, 4)!!
        // km 1 (menanjak 40 m, tanpa GAP) dilewati; sisanya: 6.0, 5.5, 6.0
        assertEquals(3.0, p.km, 1e-9)
        assertEquals((6.0 + 5.5 + 6.0) / 3, p.pace, 1e-9)
    }

    @Test fun aerobicSeriesRangeSummaryAndBest() {
        fun run(date: String, pace: Double) = detail(date, (1..4).map { split(it.toDouble(), pace, 141) })
        val details = listOf(run("2026-05-01", 6.5), run("2026-08-01", 6.3), run("2026-09-15", 6.1), run("2026-10-20", 5.9), run("2025-01-01", 7.0))
        val s6 = FitnessAnalytics.aeSeries(details, 140, 4, 6, today)
        assertEquals(3, s6.size)            // 2026-05-01 dan 2025-01-01 di luar 6 bulan (batas 2026-05-04)
        assertEquals(5, FitnessAnalytics.aeSeries(details, 140, 4, 0, today).size)
        val sum = FitnessAnalytics.aeSummary(s6)!!
        assertTrue(sum.deltaSec > 0)         // lebih cepat
        assertTrue(FitnessAnalytics.aeSummaryText(sum, 140).contains("Kebugaran aerobik membaik"))
        val best = FitnessAnalytics.aeBest(details)
        assertNotNull(best)
        assertTrue(kotlin.math.abs(best!!.hr - 141) <= 4)   // jendela ±4 bpm memuat HR 141
        assertEquals(20, best.count)
        val sm = FitnessAnalytics.aeSmooth(s6)
        assertEquals(s6.size, sm.size)
    }

    @Test fun driftNeedsEnoughSplitsAndSkipsQualityDays() {
        // 10 km, efisiensi menurun di paruh kedua (HR naik pada pace sama)
        val sp = (1..10).map { split(it.toDouble(), 6.0, if (it <= 5) 140 else 152) }
        val dd = detail("2026-10-25", sp, km = 10.0)
        val r = FitnessAnalytics.driftOf(dd, "long", false)
        assertNotNull(r)
        assertTrue(r!!.pct > 5)
        assertEquals(10.0, r.km, 1e-9)
        assertNull(FitnessAnalytics.driftOf(dd, "quality", false))
        assertNull(FitnessAnalytics.driftOf(dd, "easy", true))                 // bench
        assertNull(FitnessAnalytics.driftOf(detail("2026-10-25", sp.take(8)), "easy", false))
        assertEquals("baik", FitnessAnalytics.driftLabel(2.9))
        assertEquals("sedang", FitnessAnalytics.driftLabel(4.0))
        assertEquals("tinggi", FitnessAnalytics.driftLabel(5.0))
    }

    @Test fun driftMessageComparesLastThreeWithPreviousThree() {
        assertNull(FitnessAnalytics.driftMessage(listOf(3.0, 4.0, 5.0)))
        assertTrue(FitnessAnalytics.driftMessage(listOf(6.0, 6.0, 6.0, 3.0, 3.0, 3.0))!!.startsWith("Drift membaik"))
        assertTrue(FitnessAnalytics.driftMessage(listOf(3.0, 3.0, 3.0, 6.0, 6.0, 6.0))!!.startsWith("Drift naik"))
        assertTrue(FitnessAnalytics.driftMessage(listOf(4.0, 4.0, 4.0, 4.2, 4.1, 4.0))!!.startsWith("Drift stabil"))
    }

    private fun ez(id: Long, date: String, verdict: String, pct: Double?, eval: Double = 40.0, over: Double = 2.0, score: Int? = 80, kind: String = "easy") =
        EasyRunResult(id, d(date), kind, pct, score, verdict, null, null, null, null, eval, over, false)

    @Test fun easyTrendWeeksStreaksAndScores() {
        val cfg = EasyRunConfig()
        val results = listOf(
            ez(1, "2026-10-12", "good", 97.0, score = 90),
            ez(2, "2026-10-27", "hard", 70.0, over = 12.0, score = 50),
            ez(3, "2026-10-29", "hard", 65.0, over = 14.0, score = 45),
            ez(4, "2026-11-03", "ok", 90.0, over = 4.0, score = 78, kind = "long"),
            ez(5, "2026-11-02", "na", null),
        )
        val rows = FitnessAnalytics.ezRows(results)
        assertEquals(4, rows.size)                               // verdict na dibuang
        val weeks = FitnessAnalytics.ezWeeks(rows, 8, today, cfg)
        assertEquals(8, weeks.size)
        assertEquals(d("2026-11-02"), weeks.last().start)
        assertEquals(1, weeks.last().n)
        assertEquals(90.0, weeks.last().pct!!, 1e-9)             // (40-4)/40
        assertEquals(cfg.longPass.toDouble(), weeks.last().pass!!, 1e-9)
        assertEquals("good", FitnessAnalytics.ezWeekVerdict(weeks.last()))   // 90 >= long pass 85
        assertNull(weeks[0].pct)                                  // minggu kosong
        assertEquals("na", FitnessAnalytics.ezWeekVerdict(weeks[0]))
        // minggu 27 Okt: 2 sesi, (28+26)/80 = 67,5%
        val w27 = weeks.first { it.start == d("2026-10-26") }
        assertEquals(67.5, w27.pct!!, 1e-9)
        assertEquals("hard", FitnessAnalytics.ezWeekVerdict(w27))

        val st = FitnessAnalytics.ezStreaks(rows)
        assertEquals(0, st.cur)                                   // sesi terakhir "ok"
        assertEquals(2, st.max)
        val sc = FitnessAnalytics.ezScores(rows, 3)
        assertEquals(listOf(50, 45, 78), sc.map { it.score })
        val sum = FitnessAnalytics.ezScoreSum(sc)!!
        assertEquals(78, sum.last)
        assertEquals(1, sum.k)
        assertEquals("up", sum.dir)
        assertEquals("ok", FitnessAnalytics.ezStreakAdvice(st, "ok").key)
        assertEquals("w", FitnessAnalytics.ezStreakAdvice(streak(3), "hard").key)
        assertEquals("gray", FitnessAnalytics.ezStreakAdvice(streak(1), "hard").key)
    }

    private fun streak(cur: Int) = FitnessAnalytics.EzStreak(cur, cur)
}
