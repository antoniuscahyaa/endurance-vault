package com.endurancevault.app

import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.domain.ActDetail
import com.endurancevault.app.domain.IntervalAnalysis
import com.endurancevault.app.domain.PDay
import com.endurancevault.app.domain.PWeek
import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.domain.SegKind
import com.endurancevault.app.domain.Segment
import com.endurancevault.app.domain.StickerPrefs
import com.endurancevault.app.domain.StickerWeeks
import com.endurancevault.app.domain.Stickers
import com.endurancevault.app.domain.Zones
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import java.time.LocalDate
import org.junit.Test

class StickerIntervalWeekTest {
    private val zc = Zones.cuts(PlanSettings(thr = "164–172"))

    private fun seg(d: Double, min: Double, hr: Int? = null, type: String? = null, label: String? = null) =
        Segment(0.0, d, min, if (d > 0) min / d else 0.0, hr, 0, 0, null, "", type, label)

    private fun detail(segments: List<Segment> = emptyList(), pace: List<Pair<Double, Double>> = emptyList()) = ActDetail(
        date = "2026-11-03", startTime = "06:00", name = "Run", bike = false, kind = null, km = 8.0, movingMin = 48.0, elapsedMin = 50.0,
        gain = 40, loss = 38, hr = 150, hrMax = 170, cad = null, gapPace = null, splits = emptyList(), segments = segments,
        route = emptyList(), routeW = 1000, routeH = 600, profile = emptyList(), paceSeries = pace, hrSeries = emptyList(),
        cadSeries = emptyList(), hrHist = emptyMap(),
    )

    private fun entity(id: Long, date: String, km: Double, min: Int, hr: Int? = null, gain: Int? = null, src: String = "", type: String = "run") =
        ActivityEntity(id = id, dateIso = date, km = km, durationSec = min * 60, avgHr = hr, gain = gain, srcKey = src, type = type, name = "x")

    @Test fun intervalBerlabelRepetisiMenjadiSumber() {
        val reps = listOf(4.0, 4.05, 4.1, 4.2).mapIndexed { i, p -> seg(0.4, 0.4 * p, hr = 150 + i * 3 + (if (i == 3) 1 else 0), type = SegKind.REPETITION, label = "Repetisi") }
        val sg = listOf(seg(1.0, 6.5)) + reps + listOf(seg(1.0, 6.5))
        val r = IntervalAnalysis.analyze(detail(sg))!!
        assertEquals("tipe", r.src)
        assertEquals(4, r.stats.n)
        assertEquals(4.0, r.stats.best, 1e-9); assertEquals(0, r.stats.bestI)
        assertEquals(11.7, r.stats.fade, 1e-6)
        val m = Stickers.forActivity(entity(1, "2026-11-03", 8.0, 48), detail(sg), emptyMap(), zc)!!
        assertEquals("4×400", m.num("rep")!!.value); assertEquals("m", m.num("rep")!!.unit)
        assertEquals("+12", m.num("fade")!!.value); assertEquals("dtk/km", m.num("fade")!!.unit)
        assertEquals("150→160", m.num("hrr")!!.value)
        assertNull(m.graphWhy("pace-repetisi"))
    }

    @Test fun intervalDariLapTanpaLabel() {
        val sg = ArrayList<Segment>()
        sg.add(seg(1.0, 6.5))
        repeat(4) { sg.add(seg(0.4, 1.6)); sg.add(seg(0.2, 1.4)) }
        sg.add(seg(1.0, 6.5))
        val (src, reps) = IntervalAnalysis.detect(detail(sg))!!
        assertEquals("lap", src)
        assertEquals(listOf(1, 3, 5, 7), reps.map { it.from })
        assertEquals(4.0, reps[0].p, 1e-9)
    }

    @Test fun lariSteadyTidakDianggapInterval() {
        val sg = listOf(5.5, 5.55, 5.6, 5.5, 5.65, 5.5).map { seg(1.0, it) }
        assertNull(IntervalAnalysis.detect(detail(sg)))
        assertNull(IntervalAnalysis.analyze(null))
    }

    @Test fun intervalDariKurvaPaceBilaTanpaLap() {
        val ps = ArrayList<Double>()
        repeat(15) { ps.add(6.5) }
        repeat(4) { repeat(4) { ps.add(4.0) }; repeat(3) { ps.add(7.0) } }
        repeat(10) { ps.add(6.5) }
        val series = ps.mapIndexed { i, p -> (i + 1) * 0.1 to p }
        val (src, reps) = IntervalAnalysis.detect(detail(emptyList(), series))!!
        assertEquals("kurva", src)
        assertEquals(4, reps.size)
        assertEquals(0.4, reps[0].d, 1e-9)
    }

    private fun weeks(): List<PWeek> {
        fun week(i: Int, start: LocalDate): PWeek {
            val kinds = listOf("easy" to 8.0, "rest" to 0.0, "quality" to 10.0, "easy" to 6.0, "rest" to 0.0, "easy" to 5.0, "long" to 16.0)
            val days = kinds.mapIndexed { d, (k, km) -> PDay(start.plusDays(d.toLong()), d, k, "", "", km, "") }.toMutableList()
            return PWeek(i, start, start.plusDays(6), "base", false, false, false, days, kinds.sumOf { it.second })
        }
        return listOf(week(0, LocalDate.of(2026, 10, 26)), week(1, LocalDate.of(2026, 11, 2)))
    }

    private fun input() = StickerWeeks.inputOf(
        weeks(),
        listOf(
            entity(1, "2026-11-02", 8.0, 48, hr = 150, gain = 50),
            entity(2, "2026-11-04", 10.0, 50, hr = 160),
            entity(3, "2026-11-05", 20.0, 40, type = "bike"),
            entity(4, "2026-11-07", 5.0, 30, src = "2026-11-07~f1"),
            entity(5, "2026-11-02", 3.0, 20),
            entity(6, "2026-10-26", 8.0, 50),
        ),
        emptySet(),
    ) { a -> if (a.id == 1L) mapOf(150 to 1800.0) else null }

    @Test fun ringkasanMingguMengikutiWeekSummaryWeb() {
        val inp = input()
        val ctx = StickerWeeks.contextOf(LocalDate.of(2026, 11, 3), inp, zc)!!
        assertEquals(1, ctx.pos)
        val ws = ctx.summary
        assertEquals(26.0, ws.km, 1e-9)           // 8 + 10 (log hari) + 5 + 3 (Free Run), sepeda tidak dihitung
        assertEquals(148.0, ws.min, 1e-9)
        assertEquals(50.0, ws.gain, 1e-9)
        assertEquals(5, ws.nPlan); assertEquals(3, ws.nDone); assertEquals(2, ws.nFree)
        assertEquals(98.0 / 16.0, ws.pace!!, 1e-9)  // easy hari rencana + semua Free Run
        assertEquals(150.0, ws.hr!!, 1e-9)
        assertEquals(1800.0, ws.zones!!.total, 1e-9)
        assertEquals(listOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min"), ws.days.map { it.label })
        assertEquals(listOf(11.0, 0.0, 10.0, 0.0, 0.0, 5.0, 0.0), ws.days.map { it.act })
        assertEquals(8.0, ws.days[0].plan, 1e-9)
    }

    @Test fun tanggalDiLuarRencanaTidakPunyaKonteksMinggu() {
        assertNull(StickerWeeks.contextOf(LocalDate.of(2027, 1, 1), input(), zc))
    }

    @Test fun trenPaceButuhDuaMinggu() {
        val inp = input()
        val ctx = StickerWeeks.contextOf(LocalDate.of(2026, 11, 3), inp, zc)!!
        val t = StickerWeeks.trend(ctx, inp, zc, 8)!!
        assertEquals(listOf(0, 1), t.map { it.index })
        assertEquals(6.25, t[0].pace, 1e-9)
        assertTrue(t[1].cur)
        // hanya satu minggu yang cukup dilihat (n = 1) -> kurang dari dua titik
        assertNull(StickerWeeks.trend(ctx, inp, zc, 1))
    }

    @Test fun angkaMingguDanKetersediaanGrafikMingguan() {
        val m = Stickers.forActivity(entity(9, "2026-11-03", 8.0, 48), detail(), emptyMap(), zc, input())!!
        assertEquals("26,0", m.numWk("jarak")!!.value)
        assertEquals("Jarak minggu", m.numWk("jarak")!!.label)
        assertEquals("2:28:00".length, m.numWk("waktu")!!.value.length)
        assertEquals("50", m.numWk("elev")!!.value)
        val sesi = m.numWk("sesi")!!
        assertEquals("5", sesi.value); assertEquals("/ 5", sesi.unit)
        assertEquals("150", m.numWk("hr")!!.value)
        assertNull(m.graphWhy("target-minggu")); assertNull(m.graphWhy("tren-pace")); assertNull(m.graphWhy("zona-hr-minggu"))
        assertTrue("wk-all" in Stickers.allIds(m, StickerPrefs()))
        assertEquals("trainingplan-angka-minggu-2026-11-03.png", Stickers.fileName("wk-all", m))
        assertNotNull(m.graphWhy("pace-repetisi"))
    }

    @Test fun tanpaRencanaStikerMingguanTidakTersedia() {
        val m = Stickers.forActivity(entity(9, "2026-11-03", 8.0, 48), detail(), emptyMap(), zc, null)!!
        assertNull(m.numWk("jarak"))
        assertEquals(emptyList<String>(), m.keysWk(StickerPrefs().wk))
        listOf("target-minggu", "tren-pace", "zona-hr-minggu").forEach { assertNotNull(it, m.graphWhy(it)) }
        assertTrue("wk-all" !in Stickers.allIds(m, StickerPrefs()))
    }

    @Test fun sepedaTidakMasukMinggu() {
        val m = Stickers.forActivity(entity(9, "2026-11-03", 8.0, 48, type = "bike"), detail(), emptyMap(), zc, input())!!
        assertNull(m.wkCtx)
    }

    @Test fun pengaturanBaruBolakBalikDanDibersihkan() {
        val p = StickerPrefs(wk = listOf("pace", "xx", "pace", "sesi"), trendWeeks = 6, weekColor = "#3FA9F5", order = listOf("rep", "fade", "zzz")).sanitized()
        assertEquals(listOf("pace", "sesi"), p.wk); assertEquals(6, p.trendWeeks); assertEquals("#3fa9f5", p.weekColor)
        assertEquals(listOf("rep", "fade"), p.order)
        assertEquals(p, StickerPrefs.fromJson(p.toJson()))
        val bad = StickerPrefs(trendWeeks = 5, weekColor = "biru").sanitized()
        assertEquals(8, bad.trendWeeks); assertEquals("", bad.weekColor)
    }

    @Test fun selisihPaceBertanda() {
        assertEquals("+0:12", Stickers.dPace(0.2))
        assertEquals("\u22120:05", Stickers.dPace(-5.0 / 60))
        assertEquals("±0:00", Stickers.dPace(0.0))
        assertEquals("+1:05", Stickers.dPace(65.0 / 60))
    }
}
