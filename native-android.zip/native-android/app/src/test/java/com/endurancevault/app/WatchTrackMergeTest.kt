package com.endurancevault.app

import com.endurancevault.app.data.ActStore
import com.endurancevault.app.data.WatchTrackMerge
import com.endurancevault.app.domain.ActBuilder
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.nio.file.Files

class WatchTrackMergeTest {
    private val t0 = 1_762_500_000L

    private fun gps(ts: Long, lat: Double, lon: Double, alt: Double? = null) = JSONObject()
        .put("ts", ts).put("lat", lat).put("lon", lon)
        .put("alt", alt ?: JSONObject.NULL).put("hr", JSONObject.NULL).put("cad", JSONObject.NULL)

    private fun sample(ts: Long, alt: Double?, hr: Int?, cad: Int?) = JSONObject()
        .put("ts", ts).put("lat", JSONObject.NULL).put("lon", JSONObject.NULL)
        .put("alt", alt ?: JSONObject.NULL).put("hr", hr ?: JSONObject.NULL).put("cad", cad ?: JSONObject.NULL)

    /** Bentuk data yang benar-benar disimpan jam: sampel tanpa GPS tiap 5 dtk, titik GPS tiap 1 dtk tanpa HR. */
    private fun watchRun(seconds: Int = 600, gpsAlt: Boolean = false): JSONArray {
        val rows = JSONArray()
        for (s in 0..seconds) {
            // ~3,3 m/dtk ke utara; 0,00003 derajat lintang ≈ 3,3 m
            rows.put(gps(t0 + s, -6.2 + s * 0.00003, 106.8, if (gpsAlt) 20.0 else null))
            if (s % 5 == 0) rows.put(sample(t0 + s, 20.0 + (s / 60) * 2.0, 140 + (s / 60), 170))
        }
        return rows
    }

    @Test fun gpsPointsReceiveHeartRateCadenceAndBarometricAltitude() {
        val pts = WatchTrackMerge.merge(watchRun())
        assertEquals(601, pts.size)
        assertTrue(pts.all { !it.h.isNaN() && !it.c.isNaN() && !it.e.isNaN() })
        assertEquals(140.0, pts.first().h, 0.0)
        assertEquals(170.0, pts[300].c, 0.0)
        // sampel baro: 20 m pada menit 0, naik 2 m tiap menit, 40 m pada detik 600
        assertEquals(20.0, pts.first().e, 0.01)
        assertEquals(40.0, pts.last().e, 0.01)
        assertEquals((t0 * 1000).toDouble(), pts.first().t, 0.0)
    }

    @Test fun altitudeIsInterpolatedBetweenSamples() {
        val rows = JSONArray()
        for (s in 0..60) rows.put(gps(t0 + s, -6.2 + s * 0.00003, 106.8))
        // sampel tiap 5 dtk (13 sampel, cukup untuk dipakai sebagai sumber baro); altitude naik 1 m per detik
        for (s in 0..60 step 5) rows.put(sample(t0 + s, 100.0 + s, 150, 170))
        val pts = WatchTrackMerge.merge(rows)
        for (k in 0..60) assertEquals(100.0 + k, pts[k].e, 1e-9) // termasuk detik di antara dua sampel
    }

    @Test fun samplesFarFromAGpsPointAreNotCopiedOver() {
        val rows = JSONArray()
        for (s in 0..200) rows.put(gps(t0 + s, -6.2 + s * 0.00003, 106.8))
        // HR hanya ada pada 20 detik pertama; setelah +15 dtk titik GPS harus tetap kosong
        for (s in 0..20 step 2) rows.put(sample(t0 + s, null, 150, null))
        val pts = WatchTrackMerge.merge(rows)
        assertEquals(150.0, pts[10].h, 0.0)
        assertEquals(150.0, pts[30].h, 0.0)   // 10 dtk dari sampel terakhir (t0+20)
        assertTrue(pts[100].h.isNaN())
        assertTrue(pts[100].c.isNaN())
    }

    @Test fun gpsAltitudeIsUsedWhenThereAreTooFewBarometricSamples() {
        val rows = JSONArray()
        for (s in 0..60) rows.put(gps(t0 + s, -6.2 + s * 0.00003, 106.8, 55.0))
        for (s in 0..20 step 10) rows.put(sample(t0 + s, 999.0, 150, 170)) // hanya 3 sampel baro
        val pts = WatchTrackMerge.merge(rows)
        assertTrue(pts.all { it.e == 55.0 })
    }

    @Test fun routeWithoutTwoGpsPointsGivesNoTrack() {
        val rows = JSONArray().put(gps(t0, -6.2, 106.8)).put(sample(t0, 20.0, 150, 170))
        assertTrue(WatchTrackMerge.merge(rows).isEmpty())
        assertTrue(WatchTrackMerge.merge(JSONArray()).isEmpty())
    }

    @Test fun invalidCoordinatesAndRowsAreIgnored() {
        val rows = JSONArray()
        rows.put(gps(t0, 95.0, 106.8))           // lintang di luar rentang
        rows.put(gps(0L, -6.2, 106.8))            // tanpa waktu
        for (s in 1..30) rows.put(gps(t0 + s, -6.2 + s * 0.00003, 106.8))
        val pts = WatchTrackMerge.merge(rows)
        assertEquals(30, pts.size)
    }

    @Test fun actBuilderNowProducesHeartRateElevationAndCadenceForAWatchRun() {
        val act = ActBuilder.build(WatchTrackMerge.merge(watchRun()), "running", "Huawei Watch Run")
        assertEquals(true, (act["hr"] as Double) in 140.0..150.0)
        assertNotNull(act["hrMax"])
        assertEquals(170.0, act["cad"] as Double, 0.0)
        assertTrue((act["gain"] as Double) >= 10.0)          // naik ~18 m pada baro
        assertTrue((act["pf"] as List<*>).isNotEmpty())       // profil elevasi
        assertTrue((act["hs"] as List<*>).isNotEmpty())       // grafik HR
        assertTrue((act["cs"] as List<*>).isNotEmpty())       // grafik kadens
        val tl = act["tl"] as Map<*, *>
        assertTrue((tl["h"] as List<*>).any { (it as Int) > 0 })
        assertTrue((tl["e"] as List<*>).any { it != null })
    }

    @Test fun cyclingIsBuiltAsBikeWhenSportIsPassed() {
        val act = ActBuilder.build(WatchTrackMerge.merge(watchRun()), "biking", "Cycling")
        assertEquals(true, act["bike"])
    }

    @Test fun watchVersionReadsOnlyWatchBuiltDetailFiles() {
        val root = Files.createTempDirectory("ev-watch-version").toFile()
        try {
            val store = ActStore(root)
            store.write("f_1.json", mapOf("nm" to "FIT manual", "km" to 5.0))                       // tanpa kunci watch
            store.write("f_2.json", mapOf("nm" to "Jam lama", "km" to 5.0, "watch" to "{}"))        // tanpa wv
            store.write("f_3.json", mapOf("nm" to "Jam baru", "km" to 5.0, "watch" to "{}", "wv" to WatchTrackMerge.VERSION))
            assertEquals(-1, store.watchVersion("f_1.json"))
            assertEquals(0, store.watchVersion("f_2.json"))
            assertEquals(WatchTrackMerge.VERSION, store.watchVersion("f_3.json"))
            assertEquals(-1, store.watchVersion("f_missing.json"))
        } finally { root.deleteRecursively() }
    }
}
