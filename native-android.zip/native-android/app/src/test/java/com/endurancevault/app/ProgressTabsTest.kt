package com.endurancevault.app

import com.endurancevault.app.domain.ProgressTabs
import org.junit.Assert.*
import org.junit.Test

class ProgressTabsTest {
    @Test fun acwrZonesFollowCommonThresholds() {
        assertEquals("Rendah", ProgressTabs.acwrZone(0.79))
        assertEquals("Optimal", ProgressTabs.acwrZone(0.8))
        assertEquals("Optimal", ProgressTabs.acwrZone(1.3))
        assertEquals("Waspada", ProgressTabs.acwrZone(1.31))
        assertEquals("Waspada", ProgressTabs.acwrZone(1.5))
        assertEquals("Tinggi", ProgressTabs.acwrZone(1.51))
        assertTrue(ProgressTabs.acwrOk(1.0))
        assertFalse(ProgressTabs.acwrOk(1.4))
    }

    @Test fun tempBandsSplitAt24And28() {
        assertEquals(0, ProgressTabs.tempBand(23.9))
        assertEquals(1, ProgressTabs.tempBand(24.0))
        assertEquals(1, ProgressTabs.tempBand(27.9))
        assertEquals(2, ProgressTabs.tempBand(28.0))
        assertEquals(3, ProgressTabs.BAND_LABELS.size)
    }

    @Test fun intensityAdviceFlagsTooMuchZ3First() {
        assertEquals(1, ProgressTabs.intensityAdvice(70.0, 20.0).first)
        assertEquals(1, ProgressTabs.intensityAdvice(74.0, 10.0).first)
        assertEquals(0, ProgressTabs.intensityAdvice(82.0, 8.0).first)
        // Z3 menang atas Z1–2 rendah: pesan Z3 yang muncul
        assertTrue(ProgressTabs.intensityAdvice(60.0, 25.0).second.contains("Z3"))
    }

    @Test fun resampleInterpolatesLinearly() {
        val out = ProgressTabs.resample(listOf(0.0 to 100.0, 1.0 to 110.0, 2.0 to 100.0), 5)
        assertEquals(listOf(100f, 105f, 110f, 105f, 100f), out)
    }

    @Test fun resampleSortsAndRejectsDegenerateInput() {
        assertTrue(ProgressTabs.resample(listOf(0.0 to 1.0), 10).isEmpty())
        assertTrue(ProgressTabs.resample(listOf(0.0 to 1.0, 0.0 to 2.0), 10).isEmpty())
        val out = ProgressTabs.resample(listOf(2.0 to 4.0, 0.0 to 0.0), 3)
        assertEquals(listOf(0f, 2f, 4f), out)
    }

    @Test fun trendFitsLineAndCorrelation() {
        val t = ProgressTabs.trend(listOf(20.0 to 5.0, 25.0 to 5.5, 30.0 to 6.0))!!
        assertEquals(0.1, t.slope, 1e-9)
        assertEquals(3.0, t.intercept, 1e-9)
        assertEquals(1.0, t.r!!, 1e-9)
    }

    @Test fun trendNeedsEnoughVariedPoints() {
        assertNull(ProgressTabs.trend(listOf(20.0 to 5.0, 25.0 to 5.5)))
        assertNull(ProgressTabs.trend(listOf(20.0 to 5.0, 20.0 to 5.5, 20.0 to 6.0)))
        val flat = ProgressTabs.trend(listOf(20.0 to 5.0, 25.0 to 5.0, 30.0 to 5.0))!!
        assertEquals(0.0, flat.slope, 1e-9)
        assertNull(flat.r)
    }
}
