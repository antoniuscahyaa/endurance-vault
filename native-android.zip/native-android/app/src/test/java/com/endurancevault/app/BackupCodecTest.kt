package com.endurancevault.app

import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.data.BackupCodec
import com.endurancevault.app.data.DailyEntity
import com.endurancevault.app.data.GearEntity
import com.endurancevault.app.data.KvEntity
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class BackupCodecTest {
    @Test fun activityRoundTripKeepsIdAndDetailFile() {
        val a = ActivityEntity(
            id = 7, dateIso = "2026-11-03", km = 10.5, durationSec = 3600, avgHr = 150, feel = 3, note = "x",
            srcKey = "2026-11-03~f1", name = "Lari", gain = 120, startTime = "06:10", maxHr = 175, type = "bike",
            gearId = "g1", detailFile = "b_2026-11-03_f1.json",
        )
        val back = BackupCodec.activityFromJson(JSONObject(BackupCodec.activityToJson(a).toString()))
        assertEquals(a, back)
        val bare = ActivityEntity(id = 8, dateIso = "2026-11-04", km = 0.0, durationSec = 0)
        assertEquals(bare, BackupCodec.activityFromJson(JSONObject(BackupCodec.activityToJson(bare).toString())))
    }

    @Test fun companionRowsRoundTrip() {
        val d = DailyEntity("2026-11-05", 50, 60, 2, null, 7.25, "{\"sleep\":7.25}")
        assertEquals(d, BackupCodec.dailyFromJson(JSONObject(BackupCodec.dailyToJson(d).toString())))
        val g = GearEntity("g1", "Shoe", "M", 12.0, 800.0, retired = true, isDefault = false)
        assertEquals(g, BackupCodec.gearFromJson(JSONObject(BackupCodec.gearToJson(g).toString())))
        val k = KvEntity("done", "{\"2026-11-01\":1}")
        assertEquals(k, BackupCodec.kvFromJson(JSONObject(BackupCodec.kvToJson(k).toString())))
    }

    @Test fun prefsKeepTypesAndSkipPhotoUri() {
        val all = mapOf("s" to "hi", "i" to 3, "l" to 5_000_000_000L, "f" to 1.5f, "b" to true, "ss" to setOf("x", "y"), "photo_uri" to "content://old/device")
        val back = BackupCodec.prefsFromJson(JSONObject(BackupCodec.prefsToJson(all, setOf("photo_uri")).toString()))
        assertEquals(all - "photo_uri", back)
        assertEquals(5_000_000_000L, back["l"])
    }

    @Test fun classifyRejectsUnsafeAndSecretEntries() {
        assertNull(BackupCodec.classify("../../etc/passwd"))
        assertNull(BackupCodec.classify("acts/../x.json"))
        assertNull(BackupCodec.classify("acts/sub/x.json"))
        assertNull(BackupCodec.classify("prefs/ev_secure.json"))
        assertNull(BackupCodec.classify("prefs/huawei_wear_AABBCC.json"))
        assertNull(BackupCodec.classify("watch/Step;DROP.jsonl"))
        assertNull(BackupCodec.classify("room/other.jsonl"))
    }

    @Test fun classifyAcceptsKnownEntries() {
        assertEquals("acts", BackupCodec.classify("acts/b_2026-11-03_f1.json")!!.dir)
        assertEquals("plan_settings.json", BackupCodec.classify("prefs/plan_settings.json")!!.file)
        assertEquals("watch", BackupCodec.classify("watch/sleep_segments.jsonl")!!.dir)
        assertEquals("activity.jsonl", BackupCodec.classify("room/activity.jsonl")!!.file)
        assertEquals("web", BackupCodec.classify("web/cadangan-web-20261107-101500.json")!!.dir)
        assertNotNull(BackupCodec.classify("manifest.json"))
        assertNotNull(BackupCodec.classify("profile/photo.bin"))
    }
}
