package com.endurancevault.app

import com.endurancevault.app.domain.GreetAtmosphere
import com.endurancevault.app.domain.GreetInput
import com.endurancevault.app.domain.GreetTime
import com.endurancevault.app.domain.GreetingEngine
import com.endurancevault.app.domain.GreetingPools
import com.endurancevault.app.domain.Wx
import com.endurancevault.app.domain.WxKind
import com.endurancevault.app.domain.WxScene
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GreetingWeatherTest {
    @Test fun periodAndWord() {
        val m = mapOf(4 to "pagi", 10 to "pagi", 11 to "siang", 14 to "siang", 15 to "sore", 17 to "sore", 18 to "malam", 23 to "malam", 0 to "malam", 3 to "malam")
        m.forEach { (h, p) -> assertEquals("jam $h", p, GreetingEngine.period(h)) }
        assertEquals("SELAMAT SORE", GreetingEngine.word("sore"))
    }

    @Test fun poolsAreLargeAndHaveNoDuplicates() {
        var total = 0
        GreetingPools.id.forEach { (k, v) -> total += v.size; assertEquals("duplikat di $k", v.size, v.toSet().size) }
        assertTrue("total $total", total >= 150)
        assertTrue(GreetingPools.id.keys.containsAll(listOf("todo", "done", "rest", "none", "care", "load", "mood", "sleep", "heat", "storm", "race3", "race14", "lazy", "streak")))
    }

    @Test fun lowReadinessAlwaysUsesCarePool() {
        val care = GreetingPools.id.getValue("care")
        listOf(GreetInput("todo", readiness = 25), GreetInput("todo", care = true), GreetInput("done", care = true, raceDays = 2)).forEach { o ->
            for (s in 0 until 12) assertTrue(care.contains(GreetingEngine.pick(o, s, "pagi")))
        }
    }

    @Test fun contextKeys() {
        assertTrue(GreetingEngine.pick(GreetInput("todo", raceDays = 2), 0, "pagi").contains("2 hari"))
        assertEquals("race14", GreetingEngine.key(GreetInput("todo", raceDays = 10)))
        assertEquals("lazy", GreetingEngine.key(GreetInput("todo", gap = 4)))
        assertEquals("todo", GreetingEngine.key(GreetInput("todo", gap = 2)))
        assertEquals("streak", GreetingEngine.key(GreetInput("done", streak = 9)))
        assertEquals("rest", GreetingEngine.key(GreetInput("rest")))
        assertEquals("none", GreetingEngine.key(GreetInput()))
        assertEquals("load", GreetingEngine.key(GreetInput("todo", acwr = 1.6)))
        assertEquals("mood", GreetingEngine.key(GreetInput("todo", mood = 4)))
        assertEquals("sleep", GreetingEngine.key(GreetInput("todo", sleepDebt = 4.5)))
        assertEquals("storm", GreetingEngine.key(GreetInput("todo", wxCode = 95, wxFeels = 25.0)))
        assertEquals("heat", GreetingEngine.key(GreetInput("todo", wxCode = 1, wxFeels = 33.0)))
        // Cuaca hanya berpengaruh untuk sesi yang belum selesai.
        assertEquals("done", GreetingEngine.key(GreetInput("done", wxCode = 95, wxFeels = 40.0)))
    }

    @Test fun periodPoolJoinsTodoOnly() {
        val seen = (0 until 400).map { GreetingEngine.pick(GreetInput("todo"), it, "malam") }.toSet()
        assertTrue(seen.any { GreetingPools.id.getValue("malam").contains(it) })
        assertFalse(seen.any { GreetingPools.id.getValue("pagi").contains(it) })
    }

    @Test fun sameSeedSameQuoteAndNoPlaceholderLeft() {
        val o = GreetInput("todo", raceDays = 12, readiness = 70)
        assertEquals(GreetingEngine.pick(o, 7, "sore"), GreetingEngine.pick(o, 7, "sore"))
        listOf(o, GreetInput("todo", gap = 5), GreetInput("done", streak = 8), GreetInput("todo", acwr = 1.62), GreetInput("todo", sleepDebt = 4.5), GreetInput("todo", wxCode = 1, wxFeels = 33.4))
            .forEach { x -> for (s in 0 until 60) { val q = GreetingEngine.pick(x, s, "pagi"); assertTrue(q.isNotBlank()); assertFalse(q, q.contains("{n}")) } }
        // Desimal memakai koma (format Indonesia).
        assertTrue((0 until 4).map { GreetingEngine.pick(GreetInput("todo", acwr = 1.62), it, "pagi") }.any { it.contains("1,62") })
    }

    @Test fun atmosphereAndTimeOfDay() {
        assertEquals(GreetAtmosphere.RECOVERY, GreetingEngine.atmosphere(GreetInput("todo", readiness = 30)))
        assertEquals(GreetAtmosphere.PEAK, GreetingEngine.atmosphere(GreetInput("done", readiness = 80)))
        assertEquals(GreetAtmosphere.CLEAR, GreetingEngine.atmosphere(GreetInput("todo", readiness = 85)))
        assertEquals(GreetAtmosphere.STREAK, GreetingEngine.atmosphere(GreetInput("todo", streak = 8)))
        assertEquals(GreetAtmosphere.REST, GreetingEngine.atmosphere(GreetInput("rest")))
        assertEquals(GreetAtmosphere.RACE, GreetingEngine.atmosphere(GreetInput("todo", raceDays = 10)))
        assertEquals(GreetAtmosphere.CALM, GreetingEngine.atmosphere(GreetInput("todo")))
        assertEquals(GreetTime.MORNING, GreetingEngine.timeOfDay(5)); assertEquals(GreetTime.DAY, GreetingEngine.timeOfDay(11))
        assertEquals(GreetTime.EVENING, GreetingEngine.timeOfDay(16)); assertEquals(GreetTime.NIGHT, GreetingEngine.timeOfDay(19))
        assertEquals(GreetTime.NIGHT, GreetingEngine.timeOfDay(3))
    }

    @Test fun weatherKindsAndLabels() {
        assertEquals(WxKind.CLEAR, Wx.kind(0)); assertEquals(WxKind.PARTLY, Wx.kind(2)); assertEquals(WxKind.CLOUD, Wx.kind(3))
        assertEquals(WxKind.FOG, Wx.kind(45)); assertEquals(WxKind.RAIN, Wx.kind(63)); assertEquals(WxKind.RAIN, Wx.kind(81))
        assertEquals(WxKind.SNOW, Wx.kind(73)); assertEquals(WxKind.STORM, Wx.kind(95))
        assertEquals(WxScene.STORM, Wx.scene(99)); assertEquals(WxScene.CLEAR, Wx.scene(0)); assertNull(Wx.scene(10))
        assertEquals("Hujan", Wx.label(63)); assertEquals("–", Wx.label(12345))
    }

    @Test fun moonPhaseMatchesWebFormula() {
        // Bulan baru acuan: 2000-01-06 18:14 UTC.
        val newMoon = java.time.LocalDateTime.of(2000, 1, 6, 18, 14).toInstant(java.time.ZoneOffset.UTC).toEpochMilli()
        assertEquals("Bulan baru", Wx.moon(newMoon).second)
        assertEquals("Purnama", Wx.moon(newMoon + (14.77 * 86_400_000).toLong()).second)
    }

    @Test fun clockAndNight() {
        assertEquals("05:41", Wx.clock("2026-11-07T05:41")); assertEquals("—", Wx.clock(null)); assertEquals("—", Wx.clock("x"))
        assertTrue(Wx.isNight("2026-11-07T02:00", "2026-11-07T05:41", "2026-11-07T17:52"))
        assertTrue(Wx.isNight("2026-11-07T19:00", "2026-11-07T05:41", "2026-11-07T17:52"))
        assertFalse(Wx.isNight("2026-11-07T12:00", "2026-11-07T05:41", "2026-11-07T17:52"))
    }

    @Test fun parseForecastBuildsSnapshot() {
        val times = (0 until 48).map { "2026-11-07T%02d:00".format(it % 24).let { t -> if (it < 24) t else t.replace("11-07", "11-08") } }
        val hourly = JSONObject()
            .put("time", org.json.JSONArray(times))
            .put("temperature_2m", org.json.JSONArray(times.indices.map { 25 + it % 5 }))
            .put("weather_code", org.json.JSONArray(times.indices.map { if (it == 15) 63 else 1 }))
            .put("precipitation_probability", org.json.JSONArray(times.indices.map { if (it == 15) 70 else 5 }))
        val daily = JSONObject()
            .put("time", org.json.JSONArray(listOf("2026-11-07", "2026-11-08")))
            .put("temperature_2m_max", org.json.JSONArray(listOf(32.0, 31.0))).put("temperature_2m_min", org.json.JSONArray(listOf(23.0, 22.5)))
            .put("weather_code", org.json.JSONArray(listOf(63, 2))).put("precipitation_probability_max", org.json.JSONArray(listOf(80, 20)))
            .put("sunrise", org.json.JSONArray(listOf("2026-11-07T05:41", "2026-11-08T05:41"))).put("sunset", org.json.JSONArray(listOf("2026-11-07T17:52", "2026-11-08T17:52")))
        val current = JSONObject().put("time", "2026-11-07T14:00").put("temperature_2m", 29.4).put("apparent_temperature", 33.1)
            .put("weather_code", 61).put("relative_humidity_2m", 70).put("wind_speed_10m", 8.5)
        val forecast = JSONObject().put("current", current).put("hourly", hourly).put("daily", daily)
        val air = JSONObject().put("us_aqi", 52).put("pm2_5", 17.6)

        val s = Wx.parse(forecast, air, -6.99, 110.42, "Ungaran", 1_000L)
        assertEquals(29.4, s.temp, 0.001); assertEquals(33.1, s.feels, 0.001); assertEquals(61, s.code)
        assertEquals(52, s.usAqi); assertEquals(17.6, s.pm25!!, 0.001)
        assertEquals("05:41", Wx.clock(s.sunrise)); assertEquals("17:52", Wx.clock(s.sunset))
        // Per jam dimulai dari jam sekarang (14:00), maksimal 24 entri.
        assertEquals("2026-11-07T14:00", s.hours.first().time); assertEquals(24, s.hours.size)
        assertEquals(63, s.hours[1].code); assertEquals(70, s.hours[1].pop)
        assertEquals(2, s.days.size); assertEquals(32.0, s.days[0].hi, 0.001); assertEquals(80, s.days[0].pop)
    }

    @Test fun parseWithoutAirOrHourlyStillWorks() {
        val f = JSONObject().put("current", JSONObject().put("time", "2026-11-07T14:00").put("temperature_2m", 20.0).put("weather_code", 0))
        val s = Wx.parse(f, null, 1.0, 2.0, "X", 0L)
        assertNull(s.usAqi); assertNull(s.pm25); assertTrue(s.hours.isEmpty()); assertTrue(s.days.isEmpty())
        assertEquals(20.0, s.feels, 0.001)
        assertNotNull(s.currentTime)
    }

    @Test(expected = IllegalStateException::class) fun parseRejectsEmptyPayload() {
        Wx.parse(JSONObject(), null, 0.0, 0.0, "", 0L)
    }
}
