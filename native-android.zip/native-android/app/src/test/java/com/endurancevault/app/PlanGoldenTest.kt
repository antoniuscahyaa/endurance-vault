package com.endurancevault.app

import com.endurancevault.app.domain.PbAk
import com.endurancevault.app.domain.PbConv
import com.endurancevault.app.domain.PbPost
import com.endurancevault.app.domain.PDay
import com.endurancevault.app.domain.PlanEngine
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.PlanSettings
import java.time.LocalDate
import org.json.JSONObject
import org.junit.Assert.fail
import org.junit.Test

/**
 * Mencocokkan keluaran PlanEngine dengan data acuan yang dihasilkan plan() versi web
 * (tools/golden-plan.mjs, gSmooth=false, tanpa strength). Tiap ketidakcocokan menyebut skenario, minggu, hari, dan field.
 */
class PlanGoldenTest {
    private val today = LocalDate.of(2026, 11, 5)

    private fun settings(j: JSONObject): PlanSettings {
        fun str(k: String) = if (j.has(k) && !j.isNull(k)) j.get(k).toString() else ""
        fun dbl(k: String): Double? = str(k).takeIf { it.isNotBlank() }?.toDoubleOrNull()
        fun date(k: String): LocalDate? = str(k).takeIf { it.isNotBlank() }?.let { LocalDate.parse(it.take(10)) }
        return PlanSettings(
            name = str("name"), rtype = str("rtype"), start = date("start")!!, race = date("race"),
            raceKm = dbl("raceKm"), raceGain = dbl("raceGain"), goalT = str("goalT"),
            base = dbl("base")!!, peak = dbl("peak")!!, days = j.getInt("days"), rest = j.getInt("rest"),
            rest2 = j.getInt("rest2"), longDay = j.getInt("longDay"), hr = j.getInt("hr"), thr = str("thr"),
            pace = str("pace"), hrMax = str("hrmax").toIntOrNull(), bspd = dbl("bspd") ?: 20.0,
            pbCycle = str("pbCycle"), pbFocus = str("pbFocus"),
            pbPost = j.optJSONObject("pbPost")?.let { PbPost(it.getDouble("rec"), it.getDouble("lvl")) },
            pbConv = j.optJSONObject("pbConv")?.let { PbConv(it.getInt("wk"), it.getDouble("b0"), it.getDouble("p0")) },
            pbAk = j.optJSONObject("pbAk")?.let { PbAk(LocalDate.parse(it.getString("wk")), it.getDouble("km")) },
            evOn = j.optBoolean("evOn", false), evDate = date("evDate"), evKm = dbl("evKm") ?: 0.0, evGain = dbl("evGain") ?: 0.0,
        )
    }

    private fun checkDay(tag: String, e: JSONObject, a: PDay, errs: MutableList<String>) {
        fun eq(f: String, exp: Any?, act: Any?) { if (exp != act) errs.add("$tag.$f\n   web   : $exp\n   kotlin: $act") }
        eq("date", e.getString("date"), a.date.toString())
        eq("kind", e.getString("kind"), a.kind)
        eq("role", e.optString("role", "").ifEmpty { null }, a.role)
        eq("grp", e.getString("grp"), a.grp)
        eq("title", e.getString("title"), a.title)
        if (kotlin.math.abs(e.getDouble("km") - a.km) > 0.051) errs.add("$tag.km web=${e.getDouble("km")} kotlin=${a.km}")
        eq("detail", e.getString("detail"), a.detail)
        eq("gain", if (e.has("gain")) e.getInt("gain") else null, a.gain)
        eq("b2b", if (e.has("b2b")) e.getInt("b2b") else null, a.b2b)
        eq("qk", e.optString("qk", "").ifEmpty { null }, a.qk)
        if (e.has("qMin")) { if (a.qMin == null || kotlin.math.abs(e.getDouble("qMin") - a.qMin!!) > 0.01) errs.add("$tag.qMin web=${e.getDouble("qMin")} kotlin=${a.qMin}") }
        else if (a.qMin != null) errs.add("$tag.qMin web=null kotlin=${a.qMin}")
        eq("trail", if (e.has("trail")) e.getInt("trail") else null, a.trail)
        eq("sim", e.has("sim"), a.sim)
        eq("bench", e.has("bench"), a.bench)
        eq("xtra", if (e.has("xtra")) e.getInt("xtra") else null, a.xtra)
        eq("altMins", if (e.has("altMins")) e.getInt("altMins") else null, a.altMins)
    }

    @Test fun cocokDenganVersiWeb() {
        val text = javaClass.getResourceAsStream("/golden/plan-golden.json")!!.bufferedReader().readText()
        val root = JSONObject(text)
        val errs = mutableListOf<String>()
        root.keys().forEach { name ->
            val sc = root.getJSONObject(name)
            val exp = sc.getJSONObject("result")
            val out = PlanEngine.plan(settings(sc.getJSONObject("settings")), today)
            if (exp.has("err")) {
                if (out !is PlanOutcome.Err) errs.add("[$name] seharusnya galat: ${exp.getString("err")}")
                else if (out.message != exp.getString("err")) errs.add("[$name] pesan galat\n   web   : ${exp.getString("err")}\n   kotlin: ${out.message}")
                return@forEach
            }
            if (out !is PlanOutcome.Ok) { errs.add("[$name] galat tak terduga: ${(out as PlanOutcome.Err).message}"); return@forEach }
            val ew = exp.getJSONArray("weeks")
            if (ew.length() != out.weeks.size) { errs.add("[$name] jumlah minggu web=${ew.length()} kotlin=${out.weeks.size}"); return@forEach }
            for (wi in 0 until ew.length()) {
                val e = ew.getJSONObject(wi); val a = out.weeks[wi]
                val wt = "[$name] minggu ${wi + 1}"
                if (e.getString("phase") != a.phase) errs.add("$wt phase web=${e.getString("phase")} kotlin=${a.phase}")
                if (e.getBoolean("cut") != a.cut) errs.add("$wt cut web=${e.getBoolean("cut")} kotlin=${a.cut}")
                if (e.getBoolean("rec") != a.rec) errs.add("$wt rec")
                if (e.getBoolean("race") != a.race) errs.add("$wt race")
                if (kotlin.math.abs(e.getDouble("km") - a.km) > 0.051) errs.add("$wt km web=${e.getDouble("km")} kotlin=${a.km}")
                val ed = e.getJSONArray("days")
                if (ed.length() != a.days.size) { errs.add("$wt jumlah hari web=${ed.length()} kotlin=${a.days.size}"); continue }
                for (di in 0 until ed.length()) checkDay("$wt hari ${di + 1}", ed.getJSONObject(di), a.days[di], errs)
            }
        }
        if (errs.isNotEmpty()) {
            // Kelompokkan agar satu pola yang berulang tidak menutupi pola lain.
            val groups = errs.groupBy { e ->
                e.lineSequence().first().replace(Regex("minggu \\d+"), "minggu N").replace(Regex("hari \\d+"), "hari N")
            }
            val msg = StringBuilder("${errs.size} ketidakcocokan dengan versi web, ${groups.size} pola:\n")
            groups.entries.take(40).forEach { (k, v) -> msg.append("\n(x${v.size}) contoh:\n").append(v.first()).append("\n") }
            fail(msg.toString())
        }
    }
}
