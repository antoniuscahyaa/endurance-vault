package com.endurancevault.app

import com.endurancevault.app.domain.DatedHist
import com.endurancevault.app.domain.LoadDay
import com.endurancevault.app.domain.LoadView
import com.endurancevault.app.domain.ZoneCuts
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

class LoadViewTest {
    private val monday = LocalDate.of(2026, 11, 9)

    private fun day(d: LocalDate, load: Double) = LoadDay(d, load, 0.0, 0.0, 0.0, if (load > 0) 1 else 0)

    @Test fun weeklyStrainUsesFullWeeksBeforeCurrentWeek() {
        val days = (0 until 14).map { day(LocalDate.of(2026, 10, 26).plusDays(it.toLong()), 10.0 * (it % 7 + 1)) }
        val w = LoadView.weeklyStrain(days, monday, 2)
        assertEquals(LocalDate.of(2026, 11, 2), w[0].start)
        assertEquals(LocalDate.of(2026, 11, 8), w[0].end)
        assertEquals(LocalDate.of(2026, 10, 26), w[1].start)
        assertEquals(280.0, w[0].load, 1e-9)
        // load 10..70: rerata 40, simpangan baku 20 -> monotony 2, strain 560
        assertEquals(2.0, w[0].monotony!!, 1e-9)
        assertEquals(560.0, w[0].strain, 1e-9)
    }

    @Test fun weeklyStrainWithoutLoadIsZeroAndHasNoMonotony() {
        val w = LoadView.weeklyStrain(emptyList(), monday, 3)
        assertEquals(3, w.size)
        assertTrue(w.all { it.strain == 0.0 && it.monotony == null })
    }

    private val zc = ZoneCuts("lthr", listOf(0, 139, 154, 162, 172), 190, lthr = 172)

    @Test fun zonePeriodsGroupByMondayWeekAndMonth() {
        val items = listOf(
            DatedHist(LocalDate.of(2026, 11, 4), mapOf(120 to 600.0, 145 to 1200.0)),
            DatedHist(LocalDate.of(2026, 11, 2), mapOf(158 to 300.0)),
            DatedHist(LocalDate.of(2026, 10, 30), mapOf(150 to 1000.0)),
        )
        val weeks = LoadView.zonePeriods(items, zc, LocalDate.of(2026, 11, 9), false, 3)
        assertFalse(weeks[0].hasData)                       // pekan 9 Nov masih kosong
        assertEquals(2, weeks[1].sessions)
        assertEquals(600.0, weeks[1].secs[0], 1e-9)
        assertEquals(1200.0, weeks[1].secs[1], 1e-9)
        assertEquals(300.0, weeks[1].secs[2], 1e-9)
        assertEquals(1000.0, weeks[2].secs[1], 1e-9)
        val months = LoadView.zonePeriods(items, zc, LocalDate.of(2026, 11, 9), true, 2)
        assertEquals(2100.0, months[0].total, 1e-9)
        assertEquals(1000.0, months[1].total, 1e-9)
        val d = weeks[1].distribution()!!
        assertEquals(2100.0 / 2100.0 * 100, d.z1z2 + d.z3 + d.z4z5, 1e-9)
        assertEquals(300.0 / 2100.0 * 100, d.z3, 1e-9)
        assertNull(weeks[0].distribution())
    }

    @Test fun phaseRunsMergeConsecutiveWeeks() {
        val d = LocalDate.of(2026, 9, 21)
        val runs = LoadView.phaseRuns(listOf(
            Triple(d.plusDays(14), d.plusDays(20), "build"),
            Triple(d, d.plusDays(6), "base"),
            Triple(d.plusDays(7), d.plusDays(13), "base"),
            Triple(d.plusDays(21), d.plusDays(27), "build"),
        ))
        assertEquals(2, runs.size)
        assertEquals("base", runs[0].phase)
        assertEquals(d.plusDays(13), runs[0].end)
        assertEquals(d.plusDays(27), runs[1].end)
    }

    @Test fun axisTicksAreRoundAndCoverMax() {
        assertEquals(listOf(0, 50, 100, 150, 200, 250), LoadView.axisTicks(228.0))
        assertEquals(listOf(0, 5), LoadView.axisTicks(0.0))
        assertTrue(LoadView.axisTicks(1234.0).last() >= 1234)
        assertTrue(LoadView.axisTicks(1234.0).size <= 6)
    }

    @Test fun durationAndClockFormats() {
        assertEquals("1h 45m", LoadView.duration(105 * 60 + 3.0))
        assertEquals("45m", LoadView.duration(45 * 60.0))
        assertEquals("27:48", LoadView.clock(27 * 60 + 48.0))
        assertEquals("1:12:29", LoadView.clock(3600 + 12 * 60 + 29.0))
    }

    @Test fun monotonyLevelsAndMessages() {
        assertEquals(0, LoadView.monotonyLevel(1.4))
        assertEquals(1, LoadView.monotonyLevel(1.5))
        assertEquals(2, LoadView.monotonyLevel(2.0))
        assertEquals("OK", LoadView.monotonyLabel(0.4))
        assertTrue(LoadView.acwrMessage(0.31).contains("0,31"))
        assertTrue(LoadView.acwrMessage(1.0).contains("optimal"))
        assertTrue(LoadView.acwrMessage(null).contains("Belum"))
        assertTrue(LoadView.monotonyMessage(0.4).contains("0,4"))
    }

    @Test fun intensityAdviceFollowsMethodTarget() {
        // pyramidal: Z3 target 12–28%, Z3 hanya 4% -> perlu perhatian dan menyebut targetnya
        val low = LoadView.intensityAdvice("pyramidal", 88.0, 4.0, 8.0)
        assertEquals(1, low.first)
        assertTrue(low.second.startsWith("Z3 hanya 4%"))
        assertTrue(low.second.contains("Pyramidal"))
        assertTrue(low.second.contains("12–28%"))
        // di dalam semua rentang target -> sesuai
        assertEquals(0, LoadView.intensityAdvice("pyramidal", 70.0, 20.0, 10.0).first)
        // metode bawaan memakai saran 80/20 lama
        assertEquals(1, LoadView.intensityAdvice("default", 70.0, 20.0, 10.0).first)
        assertEquals(0, LoadView.intensityAdvice("default", 82.0, 8.0, 10.0).first)
    }
}
