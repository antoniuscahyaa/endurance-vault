package com.endurancevault.app

import com.endurancevault.app.domain.RouteAnalytics
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class RouteAnalyticsTest {
    @Test fun elevationSummaryAndGradeUseDistanceInMeters() {
        val result = RouteAnalytics.summarize(listOf(
            0.0 to 100.0,
            0.1 to 120.0,
            0.2 to 110.0,
        ))!!
        assertEquals(100.0, result.minMeters, 1e-9)
        assertEquals(120.0, result.maxMeters, 1e-9)
        assertEquals(20.0, result.rangeMeters, 1e-9)
        assertEquals(20.0, result.steepestUpPercent!!, 1e-9)
        assertEquals(-10.0, result.steepestDownPercent!!, 1e-9)
    }

    @Test fun shortAndInvalidSegmentsDoNotProduceGrade() {
        val result = RouteAnalytics.summarize(listOf(
            0.0 to 100.0,
            0.01 to 120.0,
            0.02 to Double.NaN,
        ))!!
        assertNull(result.steepestUpPercent)
        assertNull(result.steepestDownPercent)
    }

    @Test fun requiresAtLeastTwoValidElevationPoints() {
        assertNull(RouteAnalytics.summarize(listOf(0.0 to 100.0, 0.1 to Double.NaN)))
    }
}
