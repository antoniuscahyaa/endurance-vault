package com.endurancevault.app

import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.domain.ActDetail
import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.domain.SegKind
import com.endurancevault.app.domain.Segment
import com.endurancevault.app.domain.Split
import com.endurancevault.app.domain.StickerModel
import com.endurancevault.app.domain.StickerPrefs
import com.endurancevault.app.domain.Stickers
import com.endurancevault.app.domain.Zones
import com.endurancevault.app.ui.sticker.PhotoPlan
import com.endurancevault.app.ui.sticker.StickerIo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class StickerModelTest {
    private val zc = Zones.cuts(PlanSettings(thr = "164–172"))

    private fun seg(d: Double, min: Double, hr: Int? = null, type: String? = null, label: String? = null) =
        Segment(0.0, d, min, if (d > 0) min / d else 0.0, hr, 0, 0, null, "", type, label)

    private fun split(k: Double, pace: Double, partial: Boolean = false) = Split(k, pace, null, 0, 0, null, null, partial)

    private fun detail(
        segments: List<Segment> = emptyList(), splits: List<Split> = emptyList(), route: List<Pair<Int, Int>> = emptyList(),
        profile: List<Pair<Double, Double>> = emptyList(), hist: Map<Int, Double> = emptyMap(), cad: Int? = null,
    ) = ActDetail(
        date = "2026-11-03", startTime = "06:00", name = "Run", bike = false, kind = null, km = 5.0, movingMin = 30.0, elapsedMin = 31.0,
        gain = 40, loss = 38, hr = 150, hrMax = 170, cad = cad, gapPace = null, splits = splits, segments = segments,
        route = route, routeW = 1000, routeH = 600, profile = profile, paceSeries = emptyList(), hrSeries = emptyList(),
        cadSeries = emptyList(), hrHist = hist,
    )

    private fun entity(km: Double = 5.0, sec: Int = 1800, hr: Int? = 150, gain: Int? = 40, type: String = "run") =
        ActivityEntity(dateIso = "2026-11-03", km = km, durationSec = sec, avgHr = hr, gain = gain, type = type, name = "Easy")

    private fun model(d: ActDetail? = detail(), e: ActivityEntity = entity()): StickerModel = Stickers.forActivity(e, d, emptyMap(), zc)!!

    @Test fun jarakNolTidakMenghasilkanModel() {
        assertNull(Stickers.forActivity(entity(km = 0.0), null, emptyMap(), zc))
    }

    @Test fun angkaMengikutiFormatWeb() {
        val m = model(detail(cad = 172))
        assertEquals("5,00", m.num("jarak")!!.value)
        assertEquals("6:00", m.num("pace")!!.value)
        assertEquals("30:00", m.num("waktu")!!.value)
        assertEquals("40", m.num("elev")!!.value)
        assertEquals("150", m.num("hr")!!.value)
        assertEquals("172", m.num("kad")!!.value)
        assertEquals("km", m.num("jarak")!!.unit)
        assertEquals("/km", m.num("pace")!!.unit)
        assertEquals("", m.num("waktu")!!.unit)
    }

    @Test fun dataKosongTidakMuncul() {
        val m = Stickers.forActivity(entity(hr = null, gain = null), null, emptyMap(), zc)!!
        assertNull(m.num("hr")); assertNull(m.num("elev")); assertNull(m.num("kad")); assertNull(m.num("gap"))
        assertEquals(listOf("jarak", "pace"), m.keys(listOf("jarak", "hr", "pace", "kad")))
    }

    @Test fun duaDesimalDibulatkanSepertiJs() {
        assertEquals("5,02", Stickers.km2(5.016))
        assertEquals("10,00", Stickers.km2(9.999))
    }

    @Test fun pengaturanBolakBalikDanDibersihkan() {
        val p = StickerPrefs(ink = "l", cols = 4, mode = "pisah", order = listOf("pace", "hr", "pace", "xx"), accent = "#E5484D", panel = "strong", pack = listOf("map"))
            .sanitized()
        assertEquals(listOf("pace", "hr"), p.order)
        assertEquals("#e5484d", p.accent)
        assertEquals(p, StickerPrefs.fromJson(p.toJson()))
        val bad = StickerPrefs(ink = "z", cols = 9, hz = "?", panel = "?", accent = "merah").sanitized()
        assertEquals("w", bad.ink); assertEquals(3, bad.cols); assertEquals("both", bad.hz); assertEquals("off", bad.panel); assertEquals("", bad.accent)
        assertEquals(StickerPrefs(), StickerPrefs.fromJson("bukan json"))
        assertEquals(StickerPrefs(), StickerPrefs.fromJson(null))
    }

    @Test fun grafikHanyaTersediaBilaDataAda() {
        val kosong = model(detail())
        listOf("tabel-segmen", "bar-segmen", "pace-segmen", "split-km", "elevasi", "zona-hr-sesi", "zona-hr-tumpuk").forEach { assertNotNull(it, kosong.graphWhy(it)) }
        assertNotNull(kosong.graphWhy("tidak-ada"))

        val penuh = model(
            detail(
                segments = listOf(seg(1.0, 6.0), seg(1.0, 5.5)), splits = listOf(split(1.0, 6.0), split(2.0, 5.9)),
                profile = listOf(0.0 to 100.0, 5.0 to 140.0), hist = mapOf(150 to 1200.0, 170 to 300.0),
            ),
        )
        listOf("tabel-segmen", "bar-segmen", "pace-segmen", "split-km", "elevasi", "zona-hr-sesi", "zona-hr-tumpuk").forEach { assertNull(it, penuh.graphWhy(it)) }
    }

    @Test fun splitDiluarBatasWajarDibuang() {
        val m = model(detail(splits = listOf(split(1.0, 6.0), split(2.0, 0.0), split(3.0, 45.0), split(3.4, 5.5, partial = true))))
        assertEquals(listOf(1.0, 3.4), m.splitRows.map { it.k })
        assertTrue(m.splitRows.last().partial)
    }

    @Test fun barisSegmenMemakaiLabelDanTanpaLabel() {
        val m = model(
            detail(segments = listOf(seg(1.0, 6.0, type = SegKind.REPETITION, label = "Repetisi"), seg(0.5, 3.0, label = "Jogging pelan"), seg(1.0, 5.0))),
        )
        val r = m.segRows
        assertEquals(listOf("Repetisi", "Jogging pelan", "Tanpa label"), r.map { it.name })
        assertEquals(SegKind.REPETITION, r[0].kind); assertFalse(r[0].custom)
        assertNull(r[1].kind); assertTrue(r[1].custom)
        assertNull(r[2].kind); assertFalse(r[2].custom)
        assertEquals(0xEA5F0A, Stickers.segRgb(r[0].kind, r[0].custom))
        assertEquals(0x9B7FD1, Stickers.segRgb(r[1].kind, r[1].custom))
        assertNull(Stickers.segRgb(r[2].kind, r[2].custom))
    }

    @Test fun daftarIdDanPaket() {
        val m = model(
            detail(
                route = listOf(0 to 0, 500 to 300, 1000 to 600), segments = listOf(seg(1.0, 6.0), seg(1.0, 5.5)),
                splits = listOf(split(1.0, 6.0), split(2.0, 5.9)),
            ),
        )
        val gabung = StickerPrefs()
        assertEquals(listOf("n-all", "map", "tabel-segmen", "bar-segmen", "pace-segmen", "split-km"), Stickers.allIds(m, gabung))
        val pisah = StickerPrefs(mode = "pisah")
        assertEquals(listOf("n-jarak", "n-pace", "n-waktu", "map"), Stickers.allIds(m, pisah).take(4))
        // paket bawaan: kartu angka, peta, bar pace per segmen
        assertEquals(listOf("n-all", "map", "pace-segmen"), Stickers.packSel(Stickers.allIds(m, gabung), gabung))
        // pilihan tersimpan memotong id yang tidak tersedia
        assertEquals(listOf("map"), Stickers.packSel(Stickers.allIds(m, gabung), gabung.copy(pack = listOf("map", "zona-hr-sesi"))))
        // tanpa pilihan dan tanpa id bawaan: dua stiker pertama
        assertEquals(listOf("split-km"), Stickers.packSel(listOf("split-km"), gabung))
    }

    @Test fun namaBerkasDanNomorUrut() {
        val m = model()
        assertEquals("trainingplan-angka-2026-11-03.png", Stickers.fileName("n-all", m))
        assertEquals("trainingplan-pace-2026-11-03.png", Stickers.fileName("n-pace", m))
        assertEquals("trainingplan-02-pace-segmen-2026-11-03.png", Stickers.fileName("pace-segmen", m, 2))
    }

    @Test fun geometriFotoMemotongSesuaiRasio() {
        val land = PhotoPlan(4000, 3000, ar = "9:16", co = 0.0)
        val g = StickerIo.geom(land)
        assertTrue(g.free)
        assertEquals(0.0, g.sx, 1e-6); assertEquals(3000.0, g.sh, 1e-6); assertEquals(3000 * 9.0 / 16, g.sw, 1e-6)
        val asli = StickerIo.geom(PhotoPlan(4000, 3000))
        assertFalse(asli.free); assertEquals(4000.0, asli.sw, 1e-6)
        val tall = StickerIo.geom(PhotoPlan(3000, 4000, ar = "1:1", co = 1.0))
        assertEquals(3000.0, tall.sh, 1e-6); assertEquals(1000.0, tall.sy, 1e-6)
    }

    @Test fun tempelOtomatisKeTepiDanTengah() {
        // dekat tepi kiri (4%): menempel ke 4 dan memberi garis bantu
        val a = StickerIo.snap(5.0, 40.0, 40.0, 20.0, 400.0, 400.0)
        assertEquals(4.0, a.x, 1e-9); assertEquals(4.0, a.gx!!, 1e-9)
        // jauh dari semua garis: tidak berubah
        val b = StickerIo.snap(20.0, 20.0, 20.0, 10.0, 400.0, 400.0)
        assertEquals(20.0, b.x, 1e-9); assertNull(b.gx)
        // tengah horizontal: x + w/2 = 50
        val c = StickerIo.snap(29.0, 40.0, 40.0, 20.0, 400.0, 400.0)
        assertEquals(30.0, c.x, 1e-9); assertEquals(50.0, c.gx!!, 1e-9)
    }

    @Test fun tambahStikerMaksimalLimaDanMemilihIdBelumDipakai() {
        var q = PhotoPlan(1000, 1000)
        val ids = listOf("a", "b", "c")
        repeat(7) { q = StickerIo.addSticker(q, ids) }
        assertEquals(5, q.items.size)
        assertEquals(listOf("a", "b", "c", "a", "a"), q.items.map { it.id })
        assertEquals(60.0, q.items[0].s, 1e-9); assertEquals(44.0, q.items[1].s, 1e-9)
        assertEquals(q.nu, q.sel)
    }

    @Test fun namaHurufKustomDibersihkan() {
        assertEquals("Anton-Regular.ttf", Stickers.fontName("Anton-Regular.ttf"))
        assertEquals("Bebas_Neue.otf", Stickers.fontName("Bebas_Neue.otf"))
        assertEquals("", Stickers.fontName("../../etc/passwd"))
        assertEquals("", Stickers.fontName("huruf.woff"))
        assertEquals("", Stickers.fontName("dalam folder/huruf.ttf"))
        assertEquals("", Stickers.fontName(null))
        val p = StickerPrefs(fontNum = "Anton-Regular.ttf", fontBody = "../x.ttf").sanitized()
        assertEquals("Anton-Regular.ttf", p.fontNum); assertEquals("", p.fontBody)
        assertEquals(p, StickerPrefs.fromJson(p.toJson()))
    }

    @Test fun kolomEnamUkuranDanWarnaTeksKustom() {
        assertEquals(6, StickerPrefs(cols = 6).sanitized().cols)
        assertEquals(3, StickerPrefs(cols = 7).sanitized().cols)
        assertEquals(3, StickerPrefs(cols = 1).sanitized().cols)
        assertEquals(50, StickerPrefs(scale = 10).sanitized().scale)
        assertEquals(300, StickerPrefs(scale = 999).sanitized().scale)
        assertEquals(150, StickerPrefs(scale = 150).sanitized().scale)
        val p = StickerPrefs(cols = 6, scale = 175, inkCustom = "#FF8800").sanitized()
        assertEquals("#ff8800", p.inkCustom)
        assertEquals(p, StickerPrefs.fromJson(p.toJson()))
        assertEquals("", StickerPrefs(inkCustom = "oranye").sanitized().inkCustom)
        assertEquals(100, StickerPrefs.fromJson("{}").scale)
    }
}
