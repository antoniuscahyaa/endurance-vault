package com.rencanalari.huaweiwatch

import com.joyodigitama.huaweiwear.CourseBlock
import com.joyodigitama.huaweiwear.CourseIntensity
import com.joyodigitama.huaweiwear.CourseProtobuf
import com.joyodigitama.huaweiwear.CourseStep
import com.joyodigitama.huaweiwear.CourseStepKind
import com.joyodigitama.huaweiwear.CourseTarget
import com.joyodigitama.huaweiwear.DeviceCaps
import com.joyodigitama.huaweiwear.ErrorCodes
import com.joyodigitama.huaweiwear.FileUploader
import com.joyodigitama.huaweiwear.FitnessCourseService
import com.joyodigitama.huaweiwear.LogDirection
import com.joyodigitama.huaweiwear.P2pRoute
import com.joyodigitama.huaweiwear.RunningCourse
import com.joyodigitama.huaweiwear.UploadFile
import com.joyodigitama.huaweiwear.WearEvents
import com.joyodigitama.huaweiwear.WearException
import com.joyodigitama.huaweiwear.WearLink
import com.joyodigitama.huaweiwear.toHex
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import nodomain.freeyourgadget.gadgetbridge.service.devices.huawei.HuaweiP2PManager
import nodomain.freeyourgadget.gadgetbridge.service.devices.huawei.p2p.utils.HuaweiP2PSubMsg
import org.json.JSONArray
import org.json.JSONObject

/*
 * Kirim kursus lari (sesi latihan terstruktur) ke aplikasi kebugaran jam lewat P2P. Berkas milik proyek TrainingPlan.
 *
 * Isi paket dan alurnya meniru P2pController.pushCourse milik JoyoFit (CourseProtobuf + FitnessCourseService + FileUploader),
 * yang memang ditandai EKSPERIMENTAL dan belum pernah teruji di jam. Karena itu tiap langkah dicatat ke log dan hasil tiap kursus
 * (status unggah dan jawaban jam) dikembalikan apa adanya ke JS, supaya penolakan jam bisa dibaca penyebabnya.
 * Berbeda dari JoyoFit: ExpandCapability 41/169 yang tidak ada hanya dicatat sebagai peringatan, pengiriman tetap dicoba.
 */
internal class CoursePusher(
  private val link: WearLink,
  private val events: WearEvents,
  private val manager: () -> HuaweiP2PManager?,
) {
  private fun log(message: String) {
    events.log(LogDirection.INFO, null, null, null, message)
  }

  /**
   * Teks JSON `{"courses":[{"id","name","blocks":[{"repeat","steps":[{"kind","target","value","intensity","low","high"}]}]}]}`.
   * `kind`: warmup/run/walk/rest/cooldown; `target`: time (detik)/distance (meter)/none; `intensity`: none/pace (detik per km)/
   * hrPercent/cadence. Melempar WearException(INVALID_ARGUMENT) bila bentuknya salah.
   */
  fun parse(json: String): List<RunningCourse> {
    fun bad(what: String): Nothing = throw WearException(ErrorCodes.INVALID_ARGUMENT, what)
    val root = try {
      JSONObject(json)
    } catch (e: org.json.JSONException) {
      bad("Daftar kursus tidak terbaca")
    }
    val list = root.optJSONArray("courses") ?: bad("Daftar kursus kosong")
    if (list.length() == 0) bad("Daftar kursus kosong")
    val out = ArrayList<RunningCourse>()
    for (i in 0 until list.length()) {
      val c = list.optJSONObject(i) ?: bad("Kursus ${i + 1} tidak terbaca")
      val blocks = ArrayList<CourseBlock>()
      val bl = c.optJSONArray("blocks") ?: JSONArray()
      for (b in 0 until bl.length()) {
        val block = bl.optJSONObject(b) ?: bad("Blok ${b + 1} tidak terbaca")
        val steps = ArrayList<CourseStep>()
        val sl = block.optJSONArray("steps") ?: JSONArray()
        for (s in 0 until sl.length()) {
          val step = sl.optJSONObject(s) ?: bad("Langkah ${s + 1} tidak terbaca")
          steps.add(
            CourseStep(
              kind = CourseStepKind.of(step.optString("kind")) ?: bad("Jenis langkah '${step.optString("kind")}' tidak dikenal"),
              target = CourseTarget.of(step.optString("target", "none")) ?: bad("Target '${step.optString("target")}' tidak dikenal"),
              targetValue = step.optInt("value", 0),
              intensity = CourseIntensity.of(step.optString("intensity", "none")) ?: bad("Intensitas '${step.optString("intensity")}' tidak dikenal"),
              low = step.optInt("low", 0),
              high = step.optInt("high", 0),
            ),
          )
        }
        blocks.add(CourseBlock(block.optInt("repeat", 1), steps))
      }
      val id = c.optString("id", "").trim()
      if (id.isEmpty() || id.length > 40) bad("Kursus ${i + 1} butuh id (1 sampai 40 karakter)")
      val course = RunningCourse(id, c.optString("name", "").trim(), blocks)
      CourseProtobuf.validate(course)
      out.add(course)
    }
    return out
  }

  /** Kirim semua kursus berurutan. Kegagalan satu kursus tidak menghentikan yang lain, kecuali tautan putus. */
  suspend fun pushAll(courses: List<RunningCourse>): JSONObject {
    val results = JSONArray()
    var sent = 0
    var failed = 0
    for (course in courses) {
      val row = JSONObject().put("id", course.id).put("name", course.name)
      try {
        val r = push(course)
        for ((k, v) in r) row.put(k, v ?: JSONObject.NULL)
        row.put("ok", true)
        sent++
      } catch (e: CancellationException) {
        throw e
      } catch (e: WearException) {
        row.put("ok", false).put("error", e.message ?: e.errorCode).put("code", e.errorCode)
        failed++
        results.put(row)
        if (e.errorCode == ErrorCodes.NOT_CONNECTED || e.errorCode == ErrorCodes.DISCONNECTED) break
        continue
      } catch (e: Exception) {
        row.put("ok", false).put("error", e.message ?: e.javaClass.simpleName).put("code", "ERR_UNKNOWN")
        failed++
      }
      results.put(row)
    }
    return JSONObject().put("results", results).put("sent", sent).put("failed", failed)
  }

  private suspend fun push(course: RunningCourse): Map<String, Any?> {
    val handle = link.handle() ?: throw WearException(ErrorCodes.NOT_CONNECTED, "Jam belum terhubung")
    val p2p = manager() ?: throw WearException(ErrorCodes.UNSUPPORTED, "Jam ini tidak mencantumkan layanan P2P (34/01)")
    val gate41 = DeviceCaps.expandCapability(41)
    val gate169 = DeviceCaps.expandCapability(169)
    log("Courses: gates ExpandCapability 41=$gate41 169=$gate169 (Huawei Health: salah satu)")
    if (!gate41 && !gate169) log("Courses: peringatan, jam tidak menyatakan ExpandCapability 41 atau 169; tetap dicoba")

    var service = p2p.getRegisteredService(FitnessCourseService.MODULE) as? FitnessCourseService
    if (service == null) {
      service = FitnessCourseService(p2p, events)
      service.register()
    }
    val registered: FitnessCourseService = service
    val ready = withTimeoutOrNull(PING_WAIT_MS) {
      while (registered.pingCode == null) delay(100)
      true
    }
    log("Courses: ping ${FitnessCourseService.PACKAGE} -> ${registered.pingCode?.let { "0x%02x".format(it and 0xFF) } ?: "tidak dijawab dalam $PING_WAIT_MS ms"}")
    if (ready != true) log("Courses: aplikasi kebugaran jam tidak menjawab ping; unggahan mungkin ditolak")

    val messageId = HuaweiP2PSubMsg.getNext()
    val updateTime = (System.currentTimeMillis() / 1000).toInt()
    val payload = CourseProtobuf.encode(course, updateTime)
    val file = CourseProtobuf.message(CourseProtobuf.BUSINESS_CUSTOM_COURSE, messageId, payload)
    val fileName = CourseProtobuf.fileName(messageId)
    log("Courses: ${course.name}: ${course.actionCount} langkah, CourseStorageInfo ${payload.size} byte, $fileName ${file.size} byte")

    val answer = registered.expectAnswer(messageId)
    try {
      val outcome = handle.operationLock.withLock {
        val route = P2pRoute(FitnessCourseService.MODULE, FitnessCourseService.PACKAGE, registered.localFingerprint, FitnessCourseService.FINGERPRINT)
        FileUploader(handle.session, events, { bytes, total -> events.uploadProgress(bytes, total) })
          .upload(UploadFile(fileName, FILE_TYPE_P2P, file, route))
      }
      val reply = withTimeoutOrNull(ANSWER_WAIT_MS) { answer.await() }
      log(
        "Courses: unggah selesai, status jam=${outcome.resultStatus ?: "tidak ada"}; jawaban " +
          (reply?.let { "body ${it.toHex().ifEmpty { "(kosong)" }}" } ?: "tidak ada dalam ${ANSWER_WAIT_MS / 1000} dtk"),
      )
      return mapOf(
        "messageId" to messageId,
        "fileName" to fileName,
        "bytes" to file.size,
        "uploadStatus" to outcome.resultStatus,
        "answered" to (reply != null),
        "answerHex" to reply?.toHex(),
        "pingCode" to registered.pingCode,
      )
    } finally {
      registered.forget(messageId)
    }
  }

  private companion object {
    const val PING_WAIT_MS = 4_000L
    const val ANSWER_WAIT_MS = 10_000L

    /** GB memakai tipe berkas 7 untuk semua berkas P2P. */
    const val FILE_TYPE_P2P: Byte = 7
  }
}
