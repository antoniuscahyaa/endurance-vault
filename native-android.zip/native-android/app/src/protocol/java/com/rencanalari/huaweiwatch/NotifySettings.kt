package com.rencanalari.huaweiwatch

import android.content.Context
import android.content.SharedPreferences

/**
 * Pengaturan tambahan notifikasi ke jam yang tidak ada di WearSettings milik JoyoFit (berkas itu disalin persis dari vendor/ dan
 * tidak boleh diubah): jam tenang, hanya saat layar mati, dan daftar aplikasi yang pernah memposting notifikasi. Saklar utama dan
 * pilihan per aplikasi tetap di WearSettings (notificationsEnabled, appChoice, setAppChoice).
 */
internal class NotifySettings(context: Context) {
  private val prefs: SharedPreferences =
    context.applicationContext.getSharedPreferences("rencana_notify", Context.MODE_PRIVATE)

  /** Jam tenang: tidak ada notifikasi ke jam dari [quietStartMin] sampai [quietEndMin] (menit sejak 00:00; boleh melewati tengah malam). */
  var quietEnabled: Boolean
    get() = prefs.getBoolean(KEY_QUIET_ON, false)
    set(value) = prefs.edit().putBoolean(KEY_QUIET_ON, value).apply()

  var quietStartMin: Int
    get() = prefs.getInt(KEY_QUIET_START, 22 * 60)
    set(value) = prefs.edit().putInt(KEY_QUIET_START, value.coerceIn(0, 1439)).apply()

  var quietEndMin: Int
    get() = prefs.getInt(KEY_QUIET_END, 6 * 60)
    set(value) = prefs.edit().putInt(KEY_QUIET_END, value.coerceIn(0, 1439)).apply()

  /** Teruskan hanya saat layar ponsel mati (saat layar menyala, notifikasi sudah terlihat di ponsel). */
  var onlyScreenOff: Boolean
    get() = prefs.getBoolean(KEY_SCREEN_OFF, false)
    set(value) = prefs.edit().putBoolean(KEY_SCREEN_OFF, value).apply()

  /** Mencatat aplikasi yang memposting notifikasi (paket dan nama), supaya daftar pilihan tidak butuh izin membaca semua aplikasi. */
  @Synchronized
  fun noteSeenApp(packageName: String, label: String) {
    val cur = prefs.getStringSet(KEY_SEEN_APPS, emptySet())!!
    if (cur.any { it.substringBefore(SEP) == packageName }) return
    val next = HashSet(cur)
    next.add(packageName + SEP + label.replace(SEP, ' '))
    val trimmed = if (next.size > MAX_SEEN_APPS) next.toList().takeLast(MAX_SEEN_APPS).toHashSet() else next
    prefs.edit().putStringSet(KEY_SEEN_APPS, trimmed).apply()
  }

  fun seenApps(): List<Pair<String, String>> =
    prefs.getStringSet(KEY_SEEN_APPS, emptySet())!!
      .map { entry -> entry.substringBefore(SEP) to entry.substringAfter(SEP, entry) }
      .sortedBy { pair -> pair.second.lowercase() }

  private companion object {
    const val SEP = '\u0001'
    const val MAX_SEEN_APPS = 80
    const val KEY_QUIET_ON = "quiet_on"
    const val KEY_QUIET_START = "quiet_start"
    const val KEY_QUIET_END = "quiet_end"
    const val KEY_SCREEN_OFF = "only_screen_off"
    const val KEY_SEEN_APPS = "seen_apps"
  }
}
