package com.rencanalari.huaweiwatch

import com.joyodigitama.huaweiwear.LogDirection
import com.joyodigitama.huaweiwear.ProfileSender
import com.joyodigitama.huaweiwear.WearEvents
import com.joyodigitama.huaweiwear.WearLink
import com.joyodigitama.huaweiwear.WearSettings
import java.util.ArrayList
import java.util.Calendar
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import nodomain.freeyourgadget.gadgetbridge.devices.huawei.packets.Notifications

/** Satu notifikasi Android yang sudah disaring oleh penerimanya (flag ongoing, ringkasan grup, dan notifikasi sendiri dibuang di sana). */
internal class PhoneNotification(
  val packageName: String,
  val appLabel: String,
  val key: String,
  val id: Int,
  val channelId: String,
  val title: String,
  val text: String,
  val postedAtMs: Long,
  /** Layar ponsel menyala saat notifikasi datang. */
  val screenOn: Boolean,
)

/** Hasil satu percobaan teruskan, untuk log dan status di tab Jam. */
internal enum class ForwardResult(val wire: String) {
  SENT("sent"),
  OFF("off"),
  NOT_CONNECTED("not-connected"),
  APP_BLOCKED("app-blocked"),
  QUIET("quiet"),
  SCREEN_ON("screen-on"),
  DUPLICATE("duplicate"),
  UNSUPPORTED("unsupported"),
  EMPTY("empty"),
  BUSY("busy"),
  FAILED("failed"),
}

/**
 * Meneruskan notifikasi ponsel ke jam lewat paket notifikasi Huawei (service 0x02, perintah 0x01, kelas
 * `Notifications.NotificationActionRequest` dari Gadgetbridge). Alurnya mengikuti GB `SendNotificationRequest`:
 * judul dan isi sebagai elemen teks, `sourceAppId` berisi nama paket, dan kolom tambahan (kunci notifikasi, stempel waktu)
 * hanya bila jam menyatakan mendukungnya. EKSPERIMENTAL: belum diuji di jam fisik; log menyimpan keputusan tiap notifikasi.
 *
 * Kebijakan, berurutan: fitur menyala, jam terhubung dan mendukung notifikasi, aplikasi dipilih pengguna (atau termasuk daftar pesan
 * bawaan), bukan jam tenang, bukan saat layar menyala (bila opsi itu dipilih), bukan duplikat, lalu kirim.
 */
internal class NotificationForwarder(
  private val link: WearLink,
  private val settings: WearSettings,
  private val notifyCfg: NotifySettings,
  private val events: WearEvents,
) {
  @Volatile var lastResult: String? = null
    private set
  @Volatile var lastPackage: String? = null
    private set
  @Volatile var lastAtMs: Long = 0L
    private set
  @Volatile var sentCount: Int = 0
    private set
  @Volatile var lastError: String? = null
    private set

  private var msgId = 1
  private val recent = LinkedHashMap<String, Pair<Long, String>>()

  /** Aplikasi pesan yang diteruskan bila pengguna belum memilih apa pun untuknya (pilihan eksplisit selalu menang). */
  fun defaultAllowed(pkg: String): Boolean = pkg in DEFAULT_APPS

  fun appAllowed(pkg: String): Boolean = settings.appChoice(pkg) ?: defaultAllowed(pkg)

  fun inQuietHours(nowMin: Int): Boolean {
    if (!notifyCfg.quietEnabled) return false
    val s = notifyCfg.quietStartMin
    val e = notifyCfg.quietEndMin
    return if (s == e) false else if (s < e) nowMin in s until e else nowMin >= s || nowMin < e
  }

  private fun nowMinutes(): Int {
    val c = Calendar.getInstance()
    return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
  }

  /** Teruskan satu notifikasi; tidak melempar galat. */
  suspend fun forward(n: PhoneNotification): ForwardResult {
    val result = try {
      decideAndSend(n)
    } catch (e: kotlinx.coroutines.CancellationException) {
      throw e
    } catch (e: Throwable) {
      lastError = e.message ?: e.javaClass.simpleName
      events.log(LogDirection.ERROR, null, null, null, "Notif ke jam gagal: ${lastError}")
      ForwardResult.FAILED
    }
    lastResult = result.wire
    lastPackage = n.packageName
    lastAtMs = System.currentTimeMillis()
    if (result != ForwardResult.SENT && result != ForwardResult.OFF) {
      events.log(LogDirection.INFO, null, null, null, "Notif ${n.packageName}: dilewati (${result.wire})")
    }
    return result
  }

  private suspend fun decideAndSend(n: PhoneNotification): ForwardResult {
    if (!settings.notificationsEnabled) return ForwardResult.OFF
    val title = n.title.trim()
    val body = n.text.trim()
    if (title.isEmpty() && body.isEmpty()) return ForwardResult.EMPTY
    val handle = link.handle() ?: return ForwardResult.NOT_CONNECTED
    val state = handle.notificationState
    if (!state.supportsNotificationAlert) return ForwardResult.UNSUPPORTED
    if (!appAllowed(n.packageName)) return ForwardResult.APP_BLOCKED
    if (inQuietHours(nowMinutes())) return ForwardResult.QUIET
    if (notifyCfg.onlyScreenOff && n.screenOn) return ForwardResult.SCREEN_ON
    if (isDuplicate(n, title, body)) return ForwardResult.DUPLICATE

    val limit = textLimit(state.contentLength)
    val encoding = state.contentFormat.toByte()
    val content = ArrayList<Notifications.NotificationActionRequest.TextElement>()
    if (title.isNotEmpty()) {
      content.add(Notifications.NotificationActionRequest.TextElement(Notifications.TextType.title.toByte(), encoding, clip(title, MAX_TITLE)))
    }
    if (body.isNotEmpty()) {
      content.add(Notifications.NotificationActionRequest.TextElement(Notifications.TextType.text.toByte(), encoding, clip(body, limit)))
    }
    val extra = Notifications.NotificationActionRequest.AdditionalParams().apply {
      supportsRepeatedNotify = state.supportsNotificationsRepeatedNotify
      supportsRemoveSingle = state.supportsNotificationsRemoveSingle
      supportsTimestamp = state.supportsNotificationsAddIconTimestamp
      notificationKey = n.key
      notificationId = n.id
      channelId = n.channelId
    }
    val packet = Notifications.NotificationActionRequest(
      handle.session.params,
      nextMsgId(),
      typeFor(n.packageName),
      content,
      n.packageName,
      extra,
    )
    // Satu paket pendek: tunggu sebentar bila sinkron sedang memakai sesi, tetapi jangan menahan notifikasi lebih dari ini.
    val sent = withTimeoutOrNull(LOCK_WAIT_MS) {
      handle.operationLock.withLock { handle.session.send(packet, "Notification") }
      true
    }
    if (sent != true) return ForwardResult.BUSY
    sentCount++
    lastError = null
    events.log(LogDirection.INFO, null, null, null, "Notif ke jam: ${n.packageName} (${n.appLabel}), judul ${title.length} huruf, isi ${body.length} huruf")
    return ForwardResult.SENT
  }

  /** Kirim notifikasi uji tanpa melewati pemilihan aplikasi, jam tenang, atau pemeriksaan layar. */
  suspend fun sendTest(appName: String): ForwardResult {
    val handle = link.handle() ?: return ForwardResult.NOT_CONNECTED
    val state = handle.notificationState
    if (!state.supportsNotificationAlert) return ForwardResult.UNSUPPORTED
    val encoding = state.contentFormat.toByte()
    val content = ArrayList<Notifications.NotificationActionRequest.TextElement>()
    content.add(Notifications.NotificationActionRequest.TextElement(Notifications.TextType.title.toByte(), encoding, appName))
    content.add(Notifications.NotificationActionRequest.TextElement(Notifications.TextType.text.toByte(), encoding, "Tes notifikasi / Notification test"))
    val packet = Notifications.NotificationActionRequest(
      handle.session.params, nextMsgId(), Notifications.NotificationType.generic, content, "com.rencanalari.app", null,
    )
    val ok = withTimeoutOrNull(LOCK_WAIT_MS) {
      handle.operationLock.withLock { handle.session.send(packet, "NotificationTest") }
      true
    }
    return if (ok == true) {
      events.log(LogDirection.INFO, null, null, null, "Notif uji dikirim ke jam")
      ForwardResult.SENT
    } else {
      ForwardResult.BUSY
    }
  }

  /** Nyalakan atau matikan saklar notifikasi di sisi jam sekarang (saat terhubung); nilai awal dikirim saat inisialisasi tautan. */
  suspend fun applySwitch(enabled: Boolean): Boolean {
    val handle = link.handle() ?: return false
    return try {
      withTimeoutOrNull(LOCK_WAIT_MS) {
        handle.operationLock.withLock { ProfileSender.sendNotificationSwitch(handle.session, events, enabled) }
      } ?: false
    } catch (e: kotlinx.coroutines.CancellationException) {
      throw e
    } catch (e: Throwable) {
      lastError = e.message ?: e.javaClass.simpleName
      false
    }
  }

  @Synchronized
  private fun nextMsgId(): Short {
    msgId = if (msgId >= Short.MAX_VALUE.toInt()) 1 else msgId + 1
    return msgId.toShort()
  }

  /** Aplikasi pesan memakai jenis umum; SMS dan email punya jenis sendiri di protokol, jadi tampil dengan ikon yang sesuai. */
  private fun typeFor(pkg: String): Byte = when (pkg) {
    in SMS_APPS -> Notifications.NotificationType.sms
    in EMAIL_APPS -> Notifications.NotificationType.email
    else -> Notifications.NotificationType.generic
  }

  /**
   * WhatsApp memperbarui notifikasi yang sama tiap pesan baru; yang dianggap duplikat hanya isi yang persis sama dengan yang terakhir
   * dikirim untuk kunci itu dalam [DUP_WINDOW_MS]. Pesan beruntun berisi sama dari pengirim yang sama tetap lolos setelah jendelanya lewat.
   */
  @Synchronized
  private fun isDuplicate(n: PhoneNotification, title: String, body: String): Boolean {
    val now = System.currentTimeMillis()
    val fp = title + "\u0001" + body
    val prev = recent[n.key]
    recent.entries.removeAll { now - it.value.first > DUP_WINDOW_MS * 4 }
    if (prev != null && prev.second == fp && now - prev.first <= DUP_WINDOW_MS) return true
    recent[n.key] = now to fp
    while (recent.size > 60) recent.remove(recent.keys.first())
    return false
  }

  companion object {
    private const val LOCK_WAIT_MS = 8_000L
    private const val DUP_WINDOW_MS = 4_000L
    private const val MAX_TITLE = 60
    private const val DEFAULT_TEXT_LIMIT = 160

    /** Batas teks dari jam bila masuk akal (nilai kecil di bawah 32 bukan batas huruf yang bisa dipercaya); selain itu bawaan. */
    fun textLimit(reported: Int): Int = if (reported >= 32) minOf(reported, 400) else DEFAULT_TEXT_LIMIT

    /** Potong tanpa memecah pasangan surrogat (emoji), tambah elipsis bila terpotong. */
    fun clip(s: String, max: Int): String {
      if (s.length <= max) return s
      var end = max - 1
      if (end > 0 && Character.isHighSurrogate(s[end - 1])) end--
      return s.substring(0, maxOf(end, 0)).trimEnd() + "…"
    }

    val DEFAULT_APPS = setOf(
      "com.whatsapp",
      "com.whatsapp.w4b",
      "org.telegram.messenger",
      "org.thoughtcrime.securesms",
      "com.google.android.apps.messaging",
      "com.samsung.android.messaging",
      "com.android.mms",
    )
    val SMS_APPS = setOf("com.google.android.apps.messaging", "com.samsung.android.messaging", "com.android.mms")
    val EMAIL_APPS = setOf("com.google.android.gm", "com.microsoft.office.outlook", "com.google.android.apps.gmail")
  }
}
