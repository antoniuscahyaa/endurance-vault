package com.rencanalari.huaweiwatch

import com.joyodigitama.huaweiwear.DeviceCaps
import com.joyodigitama.huaweiwear.HealthSensors
import com.joyodigitama.huaweiwear.HuaweiSession
import com.joyodigitama.huaweiwear.LinkState
import com.joyodigitama.huaweiwear.LogDirection
import com.joyodigitama.huaweiwear.WearEvents
import com.joyodigitama.huaweiwear.WearException
import com.joyodigitama.huaweiwear.WearLink
import com.joyodigitama.huaweiwear.WearSettings
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import nodomain.freeyourgadget.gadgetbridge.devices.huawei.HuaweiPacket
import nodomain.freeyourgadget.gadgetbridge.devices.huawei.HuaweiTLV
import nodomain.freeyourgadget.gadgetbridge.devices.huawei.packets.FitnessData
import org.json.JSONObject

/** Paket dari TLV siap pakai, terenkripsi seperti paket pasca-autentikasi lain (bentuknya sama dengan RawPacket JoyoFit). */
internal class LiveRawPacket(params: HuaweiPacket.ParamsProvider, service: Int, command: Int, content: HuaweiTLV) : HuaweiPacket(params) {
  init {
    serviceId = service.toByte()
    commandId = command.toByte()
    tlv = content
    isEncrypted = true
    complete = true
  }
}

/**
 * HR live dari jam untuk layar Live sepeda. Selama layar menginginkannya ([setActive]) dan jam terhubung, jam diminta
 * mengirim HR realtime (FitnessData 07/1C, GB EnableRealtimeHeartRate) dan laporan HR 19/01 (balasan masuk sebagai 19/03).
 * Setiap bacaan disimpan sebagai bacaan terakhir; JS membacanya lewat [status]. Saat layar ditutup, mode realtime
 * dimatikan dan HR otomatis jam dikembalikan ke pengaturan pengguna (GB memakai satu boolean untuk keduanya).
 * Tidak ada yang ditulis ke basis data: ini hanya tampilan langsung, bukan aktivitas.
 * Logikanya mengikuti LiveHeartRate.kt JoyoFit (vendor/); belum diuji di jam.
 */
internal class LiveHeartRateFeed(
  private val link: WearLink,
  private val settings: WearSettings,
  private val events: WearEvents,
  private val scope: CoroutineScope,
) {
  private val lock = Any()
  private var attached: HuaweiSession? = null
  private var subscription: AutoCloseable? = null
  private var noticeSubscription: AutoCloseable? = null
  private var running: HuaweiSession? = null

  @Volatile private var wanted = false
  @Volatile private var lastBpm = 0
  @Volatile private var lastAtMs = 0L
  private val stateMutex = Mutex()
  private val undecoded = AtomicInteger()
  private val readings = AtomicInteger()

  private fun log(message: String) = events.log(LogDirection.INFO, null, null, null, message)

  /** {active, running, supported, bpm, ageMs}; bpm 0 dan ageMs -1 bila belum ada bacaan sejak diaktifkan. */
  fun status(): JSONObject {
    val at = lastAtMs
    val ok = DeviceCaps.supports(HR_SERVICE, HR_SWITCH) || DeviceCaps.supports(FITNESS, REALTIME)
    return JSONObject()
      .put("active", wanted)
      .put("running", synchronized(lock) { running != null })
      .put("supported", ok)
      .put("bpm", if (at > 0) lastBpm else 0)
      .put("ageMs", if (at > 0) System.currentTimeMillis() - at else -1)
  }

  fun setActive(active: Boolean) {
    wanted = active
    if (active) {
      lastBpm = 0
      lastAtMs = 0L
    }
    // Sesi bisa sudah ada sebelum layar dibuka: pasang langganan dari tautan yang sedang hidup.
    if (active) onLinkState(LinkState.CONNECTED)
    scope.launch { if (wanted) start() else stop() }
  }

  /** Dipanggil pada tiap perubahan keadaan tautan: berlangganan di sesi baru, melepas semuanya saat tautan putus. */
  fun onLinkState(state: LinkState) {
    when (state) {
      LinkState.CONNECTED, LinkState.SYNCING -> {
        val session = link.handle()?.session ?: return
        val isNew = synchronized(lock) {
          if (session === attached) {
            false
          } else {
            subscription?.close()
            noticeSubscription?.close()
            attached = session
            subscription = session.subscribe(HealthSensors.REALTIME_SERVICE, HealthSensors.REALTIME_COMMAND, "realtime heart rate") { onPacket(it) }
            noticeSubscription = session.subscribe(HR_SERVICE.toByte(), HR_NOTICE.toByte(), "heart rate report") { onNotice(it) }
            running = null
            true
          }
        }
        if (isNew && wanted) scope.launch { start() }
      }
      LinkState.DISCONNECTED -> synchronized(lock) {
        subscription?.close()
        subscription = null
        noticeSubscription?.close()
        noticeSubscription = null
        attached = null
        running = null
      }
      else -> Unit
    }
  }

  private suspend fun start() {
    stateMutex.withLock {
      if (!wanted) return
      val handle = link.handle() ?: return
      if (synchronized(lock) { running === handle.session }) return
      if (DeviceCaps.supports(HR_SERVICE, HR_SWITCH)) {
        try {
          handle.session.send(
            LiveRawPacket(handle.session.params, HR_SERVICE, HR_SWITCH, HuaweiTLV().put(0x01, 1.toByte()).put(0x02, 2.toByte())),
            "HeartRateReport on",
          )
        } catch (e: CancellationException) {
          throw e
        } catch (e: Exception) {
          events.log(LogDirection.ERROR, null, null, null, "Laporan HR tidak dibuka: ${e.message}")
        }
      } else {
        log("HR live: jam tidak mencantumkan 19/01")
      }
      if (!DeviceCaps.supports(FITNESS, REALTIME)) {
        synchronized(lock) { running = handle.session }
        return
      }
      try {
        handle.operationLock.withLock {
          HealthSensors.send(handle.session, events, listOf(HealthSensors.realtimeRequest(true)))
        }
        synchronized(lock) { running = handle.session }
      } catch (e: CancellationException) {
        throw e
      } catch (e: WearException) {
        events.log(LogDirection.ERROR, null, null, null, "HR live tidak dimulai: ${e.message}")
      }
    }
  }

  private suspend fun stop() {
    stateMutex.withLock {
      if (wanted) return
      val handle = link.handle() ?: return
      if (synchronized(lock) { running !== handle.session }) return
      try {
        if (DeviceCaps.supports(HR_SERVICE, HR_SWITCH)) {
          handle.session.send(
            LiveRawPacket(handle.session.params, HR_SERVICE, HR_SWITCH, HuaweiTLV().put(0x01, 2.toByte()).put(0x02, 2.toByte())),
            "HeartRateReport off",
          )
        }
        handle.operationLock.withLock {
          val restore = ArrayList<com.joyodigitama.huaweiwear.SensorRequest>()
          restore += HealthSensors.realtimeRequest(false)
          if (DeviceCaps.supports(FITNESS, AUTOMATIC)) {
            restore += HealthSensors.automaticHeartRateRequest(settings.healthSensors.automaticHeartRate)
          }
          HealthSensors.send(handle.session, events, restore)
        }
        synchronized(lock) { running = null }
      } catch (e: CancellationException) {
        throw e
      } catch (e: WearException) {
        events.log(LogDirection.ERROR, null, null, null, "HR live tidak dimatikan: ${e.message}")
      }
    }
  }

  private fun store(bpm: Int) {
    lastBpm = bpm
    lastAtMs = System.currentTimeMillis()
  }

  /** Jalan di thread baca: urai lalu simpan. */
  private fun onPacket(packet: HuaweiPacket) {
    val bpm = HealthSensors.decodeRealtime(packet.tlv)
    if (bpm == null) {
      if (undecoded.getAndIncrement() % UNDECODED_LOG_EVERY == 0) log("HR live: paket tanpa bacaan (${packet.tlv})")
      return
    }
    store(bpm)
  }

  /** `19/03`: `81{82{03 bpm, 04 waktu detik, 05 kredibilitas}}`, bisa beberapa. */
  private fun onNotice(packet: HuaweiPacket) {
    val tlv = packet.getTlv() ?: return
    var last: Int? = null
    for (outer in tlv.getObjects(0x81)) {
      for (inner in outer.getObjects(0x82)) {
        val bytes = inner.getBytes(0x03, null) ?: continue
        val bpm = unsigned(bytes) ?: continue
        if (bpm in 25..250) last = bpm
      }
    }
    val bpm = last
    if (bpm == null) {
      if (undecoded.getAndIncrement() % UNDECODED_LOG_EVERY == 0) log("HR live: laporan tanpa bacaan ($tlv)")
      return
    }
    if (readings.getAndIncrement() % READINGS_LOG_EVERY == 0) log("HR live: $bpm bpm (19/03)")
    store(bpm)
  }

  private fun unsigned(bytes: ByteArray): Int? {
    if (bytes.isEmpty() || bytes.size > 4) return null
    var n = 0L
    for (b in bytes) n = (n shl 8) or (b.toLong() and 0xFF)
    return n.toInt()
  }

  private companion object {
    val FITNESS = FitnessData.id.toInt()
    val REALTIME = HealthSensors.REALTIME_COMMAND.toInt()
    val AUTOMATIC = FitnessData.EnableAutomaticHeartrate.id.toInt()
    const val UNDECODED_LOG_EVERY = 10
    const val READINGS_LOG_EVERY = 12
    const val HR_SERVICE = 0x19
    const val HR_SWITCH = 0x01
    const val HR_NOTICE = 0x03
  }
}
