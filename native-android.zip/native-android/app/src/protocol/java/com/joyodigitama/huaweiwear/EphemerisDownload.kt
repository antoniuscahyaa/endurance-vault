package com.joyodigitama.huaweiwear

import android.content.Context
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/** A download the watch asked for failed (no network, HTTP error, unreadable body); the message goes to the log. */
internal class AgpsFetchException(message: String, cause: Throwable? = null) : IOException(message, cause)

/**
 * Where the LTO file comes from and how the last attempt went. [customUrl] is an https mirror the user runs (a plain proxy of the
 * Broadcom file); it is tried first and the public Broadcom URL stays the fallback. TrainingPlan addition, not in upstream JoyoFit.
 */
internal object AgpsSource {
  @Volatile var customUrl: String? = null

  @Volatile var lastOkAtMs = 0L

  @Volatile var lastBytes = 0

  /** `mirror` or `broadcom`: where the last successful download came from. */
  @Volatile var lastFrom: String? = null

  /** The last failure of the current attempt (kept when the fallback then worked), null after a clean success. */
  @Volatile var lastError: String? = null

  /** When the watch last finished pulling a file (1C/06), and the result code it reported. */
  @Volatile var lastDoneAtMs = 0L

  @Volatile var lastDoneResult: Long? = null

  val broadcomUrl: String get() = EphemerisNet.LTO_HOST + EphemerisNet.LTO_PATH

  /** Mirror first (only https), then Broadcom. */
  fun candidates(): List<String> {
    val mirror = customUrl?.trim().orEmpty()
    return if (mirror.startsWith("https://")) listOf(mirror, broadcomUrl) else listOf(broadcomUrl)
  }
}

/**
 * The HTTP side of the watch's ephemeris requests: blocking, so callers run it on the IO dispatcher. Only https, bodies capped
 * at [MAX_BYTES], a plain GET with no credentials and no app identification.
 */
internal object EphemerisNet {
  /** The public Broadcom LTO file (valid for 7 days) is the only thing downloaded. */
  const val LTO_HOST = "https://gllto.glpals.com"
  const val LTO_PATH = "/7day/v6/latest/lto.dat"

  private const val CONNECT_TIMEOUT_MS = 15_000
  private const val READ_TIMEOUT_MS = 30_000
  private const val MAX_BYTES = 8 * 1024 * 1024

  fun get(url: String): ByteArray {
    if (!url.startsWith("https://")) throw AgpsFetchException("refusing non-https url")
    val connection = try {
      URL(url).openConnection() as HttpURLConnection
    } catch (e: IOException) {
      throw AgpsFetchException("bad url: ${e.message}", e)
    }
    try {
      connection.connectTimeout = CONNECT_TIMEOUT_MS
      connection.readTimeout = READ_TIMEOUT_MS
      connection.requestMethod = "GET"
      val status = connection.responseCode
      if (status != 200) {
        val reason = try {
          connection.errorStream?.use { stream ->
            val buffer = ByteArray(256)
            String(buffer, 0, stream.read(buffer).coerceAtLeast(0), Charsets.UTF_8).take(120)
          }
        } catch (e: IOException) {
          null
        }
        throw AgpsFetchException("HTTP $status${if (reason.isNullOrBlank()) "" else ": $reason"}")
      }
      return connection.inputStream.use { readCapped(it, MAX_BYTES) }
    } catch (e: AgpsFetchException) {
      throw e
    } catch (e: IOException) {
      throw AgpsFetchException("${e.javaClass.simpleName}: ${e.message}", e)
    } finally {
      connection.disconnect()
    }
  }

  private fun readCapped(input: InputStream, limit: Int): ByteArray {
    val out = ByteArrayOutputStream()
    val buffer = ByteArray(8192)
    while (true) {
      val n = input.read(buffer)
      if (n < 0) break
      if (out.size() + n > limit) throw AgpsFetchException("response larger than $limit bytes")
      out.write(buffer, 0, n)
    }
    return out.toByteArray()
  }

  /** SHA-256 of the watch address without colons, lowercase hex: part of the stored file name the watch's protocol expects. */
  fun addressDigest(address: String): String =
    MessageDigest.getInstance("SHA-256").digest(address.replace(":", "").toByteArray(Charsets.UTF_8)).toHex().lowercase()
}

/**
 * Downloads kept in the app's files so the watch's repeated requests (it asks again every ~20 s while it is locating) do not
 * refetch. Keyed by URL; the age is the file's modification time.
 */
internal class EphemerisCache(context: Context) {
  private val dir = File(context.applicationContext.filesDir, "agps")

  private fun file(url: String): File {
    val key = MessageDigest.getInstance("SHA-256").digest(url.toByteArray(Charsets.UTF_8)).toHex().lowercase().take(32)
    return File(dir, "$key.bin")
  }

  /** The cached body of [url] when it is younger than [maxAgeMs]. */
  fun read(url: String, maxAgeMs: Long): ByteArray? {
    val f = file(url)
    if (!f.isFile || System.currentTimeMillis() - f.lastModified() > maxAgeMs) return null
    return try {
      f.readBytes().takeIf { it.isNotEmpty() }
    } catch (e: IOException) {
      null
    }
  }

  fun write(url: String, data: ByteArray) {
    try {
      if (!dir.isDirectory && !dir.mkdirs()) return
      val target = file(url)
      val tmp = File(dir, target.name + ".tmp")
      tmp.writeBytes(data)
      if (!tmp.renameTo(target)) tmp.delete()
      prune()
    } catch (e: IOException) {
      // A cache that cannot be written only costs a refetch.
    }
  }

  private fun prune() {
    val cutoff = System.currentTimeMillis() - PRUNE_AGE_MS
    dir.listFiles()?.forEach { if (it.lastModified() < cutoff) it.delete() }
  }

  private companion object {
    const val PRUNE_AGE_MS = 24L * 60 * 60 * 1000
  }
}
