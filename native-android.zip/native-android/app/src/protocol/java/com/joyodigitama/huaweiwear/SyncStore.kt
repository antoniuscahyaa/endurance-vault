package com.joyodigitama.huaweiwear

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import java.io.File
import org.json.JSONArray

/** Re-request this much already-stored history on every sync; upserts make the overlap idempotent. */
internal const val SYNC_OVERLAP_SEC = 3600L

/** One request chain covers at most this much of a long pull, so a full history never becomes a single endless request. */
internal const val SYNC_SLICE_SEC = 14 * 24 * 3600L

/** History older than this is requested as one slice by [syncSlices]. */
internal const val SYNC_HEAD_SEC = 8 * 7 * 24 * 3600L

/**
 * Start of the next sync window, unix seconds: 0 (everything the watch still holds) on the first sync, else 1 h before
 * the last one.
 */
internal fun syncWindowStart(lastSyncSec: Long?): Long =
  if (lastSyncSec == null) 0L else maxOf(0L, lastSyncSec - SYNC_OVERLAP_SEC)

/**
 * Consecutive `[from, to]` slices from [fromSec] up to [nowSec], oldest first. Everything older than [SYNC_HEAD_SEC]
 * is one slice (the watch pages it itself, and an empty stretch costs one count request, not hundreds), the recent
 * part is cut into [SYNC_SLICE_SEC] pieces.
 */
internal fun syncSlices(fromSec: Long, nowSec: Long): List<Pair<Long, Long>> {
  val slices = ArrayList<Pair<Long, Long>>()
  var start = fromSec
  val headEnd = nowSec - SYNC_HEAD_SEC
  if (start < headEnd) {
    slices.add(start to headEnd)
    start = headEnd
  }
  while (start < nowSec - SYNC_SLICE_SEC) {
    slices.add(start to start + SYNC_SLICE_SEC)
    start += SYNC_SLICE_SEC
  }
  slices.add(start to nowSec)
  return slices
}

/** What one stored sync reports to JS (`SyncSummary` in `HuaweiWear.types.ts`). */
internal class SyncSummary(
  val from: Long,
  val to: Long,
  val samples: Int,
  val sleep: Int,
  val totalSteps: Int,
  val totalCalories: Int,
  val totalDistance: Int,
  /** Workouts written (new or completed) by this sync's workout phase. */
  val workouts: Int = 0,
) {
  fun withWorkouts(count: Int) =
    SyncSummary(from, to, samples, sleep, totalSteps, totalCalories, totalDistance, count)

  fun toJs(): Map<String, Any?> = mapOf(
    "from" to from,
    "to" to to,
    "samples" to samples,
    "workouts" to workouts,
    "sleep" to sleep,
    "totals" to mapOf(
      "steps" to totalSteps,
      "calories" to totalCalories,
      "distance" to totalDistance,
    ),
  )
}

/**
 * Writes sync results into the database the JS side reads with expo-sqlite: `joyofit.db` in
 * `<filesDir>/SQLite` (expo-sqlite's `defaultDatabaseDirectory` + the name `_layout.tsx` opens).
 * Schema and migrations come from the same JSON asset JS imports
 * (`modules/huawei-wear/schema/joyofit-db-migrations.json`); `PRAGMA user_version` counts applied
 * migrations in both. Upserts are the ones `src/db/queries.ts` used to run from JS.
 */
internal class SyncStore(context: Context) {
  private val appContext = context.applicationContext
  private val file = File(File(appContext.filesDir, "SQLite"), DATABASE_NAME)
  private var database: SQLiteDatabase? = null

  @Synchronized
  internal fun db(): SQLiteDatabase {
    database?.let { return it }
    file.parentFile?.mkdirs()
    val opened = SQLiteDatabase.openDatabase(
      file.path,
      null,
      SQLiteDatabase.OPEN_READWRITE or SQLiteDatabase.CREATE_IF_NECESSARY or SQLiteDatabase.ENABLE_WRITE_AHEAD_LOGGING,
    )
    try {
      // The framework default is 2.5 s. JS may hold the file briefly (its own migration), so wait longer.
      opened.rawQuery("PRAGMA busy_timeout = $BUSY_TIMEOUT_MS", null).use { it.moveToFirst() }
      migrate(opened, loadMigrations())
    } catch (e: Exception) {
      opened.close()
      throw e
    }
    database = opened
    return opened
  }

  private fun loadMigrations(): List<List<String>> {
    val json = appContext.assets.open(MIGRATIONS_ASSET).use { String(it.readBytes(), Charsets.UTF_8) }
    val all = JSONArray(json)
    return List(all.length()) { i ->
      val statements = all.getJSONArray(i)
      List(statements.length()) { statements.getString(it) }
    }
  }

  /** `migrate()` in `src/db/migrations.ts`: entry `i` upgrades `user_version` i to i + 1. */
  private fun migrate(db: SQLiteDatabase, migrations: List<List<String>>) {
    val current = db.version
    if (current > migrations.size) {
      throw SQLiteException("Database schema v$current is newer than this app supports (v${migrations.size})")
    }
    for (version in current until migrations.size) {
      db.beginTransaction()
      try {
        // JS may have applied this step between the read above and taking the write lock.
        if (db.version <= version) {
          for (statement in migrations[version]) db.execSQL(statement)
          db.version = version + 1
        }
        db.setTransactionSuccessful()
      } finally {
        db.endTransaction()
      }
    }
  }

  /** Menutup koneksi milik instans ini (untuk instans sementara, mis. cadangan/pemulihan). */
  @Synchronized
  fun close() {
    database?.close()
    database = null
  }

  /** Runs [block] against the open database; the Health Connect export reads stored rows through this. */
  fun <T> read(block: (SQLiteDatabase) -> T): T = block(db())

  fun lastSync(address: String): Long? =
    db().rawQuery("SELECT last_sync FROM device WHERE address = ?", arrayOf(address)).use { cursor ->
      if (cursor.moveToFirst() && !cursor.isNull(0)) cursor.getLong(0) else null
    }

  /** `upsertDevice` of the old JS queries: keeps `last_sync` of an existing row. */
  fun upsertDevice(address: String, name: String, productModel: String?, softwareVersion: String?) {
    // Tanpa UPSERT (klausa konflik): butuh SQLite 3.24, sedangkan Android 10 ke bawah membawa versi lebih lama.
    val d = db()
    d.compileStatement("UPDATE device SET name = ?, product_model = ?, software_version = ? WHERE address = ?").use { u ->
      u.bindString(1, name)
      if (productModel != null) u.bindString(2, productModel) else u.bindNull(2)
      if (softwareVersion != null) u.bindString(3, softwareVersion) else u.bindNull(3)
      u.bindString(4, address)
      if (u.executeUpdateDelete() == 0) {
        d.execSQL(
          "INSERT INTO device (address, name, product_model, software_version, last_sync) VALUES (?, ?, ?, ?, NULL)",
          arrayOf(address, name, productModel, softwareVersion),
        )
      }
    }
  }

  /** Persists one sync in a single transaction and advances `device.last_sync` to `result.to`. */
  fun save(address: String, result: SyncResult): SyncSummary {
    val db = db()
    db.beginTransaction()
    try {
      // UPDATE lebih dulu, INSERT bila belum ada baris (pengganti UPSERT, lihat upsertDevice).
      val sampleUpd = db.compileStatement(
        "UPDATE step_samples SET steps = ?, calories = ?, distance = ?, heart_rate = ?, spo2 = ?, resting_heart_rate = ?, imported = 0 WHERE timestamp = ?",
      )
      val sampleIns = db.compileStatement(
        "INSERT INTO step_samples (steps, calories, distance, heart_rate, spo2, resting_heart_rate, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)",
      )
      val segmentUpd = db.compileStatement("UPDATE sleep_segments SET end = ?, stage = ?, imported = 0 WHERE start = ? AND type = ?")
      val segmentIns = db.compileStatement("INSERT INTO sleep_segments (end, stage, start, type) VALUES (?, ?, ?, ?)")
      try {
        for (s in result.samples) {
          for (st in listOf(sampleUpd, sampleIns)) {
            st.clearBindings()
            st.bindLong(1, s.steps.toLong())
            st.bindLong(2, s.calories.toLong())
            st.bindLong(3, s.distance.toLong())
            s.heartRate?.let { st.bindLong(4, it.toLong()) } ?: st.bindNull(4)
            s.spo2?.let { st.bindLong(5, it.toLong()) } ?: st.bindNull(5)
            s.restingHeartRate?.let { st.bindLong(6, it.toLong()) } ?: st.bindNull(6)
            st.bindLong(7, s.timestamp)
            if (st === sampleUpd) { if (st.executeUpdateDelete() > 0) break } else st.executeInsert()
          }
        }
        // Segmen tidur lama yang tumpang tindih dengan unduhan baru dibuang dulu: jam menganalisis ulang malam yang sama
        // (awal/akhir fase bergeser), dan segmen lama dengan batas berbeda tidak tertimpa lewat kunci (start, type).
        if (result.sleep.isNotEmpty()) {
          val lo = result.sleep.minOf { it.start }
          val hi = result.sleep.maxOf { it.end }
          db.execSQL("DELETE FROM sleep_segments WHERE end > ? AND start < ?", arrayOf<Any>(lo, hi))
        }
        for (s in result.sleep) {
          for (st in listOf(segmentUpd, segmentIns)) {
            st.clearBindings()
            st.bindLong(1, s.end)
            s.stage?.let { st.bindString(2, it) } ?: st.bindNull(2)
            st.bindLong(3, s.start)
            st.bindLong(4, s.type.toLong())
            if (st === segmentUpd) { if (st.executeUpdateDelete() > 0) break } else st.executeInsert()
          }
        }
      } finally {
        sampleUpd.close(); sampleIns.close(); segmentUpd.close(); segmentIns.close()
      }
      for (s in result.sleepScores) {
        db.compileStatement("UPDATE sleep_scores SET end = ?, score = ?, efficiency = ?, avg_spo2 = ?, avg_resp = ? WHERE start = ?").use { u ->
          u.bindLong(1, s.end.toLong()); u.bindLong(2, s.score.toLong())
          s.efficiency?.let { u.bindLong(3, it.toLong()) } ?: u.bindNull(3)
          s.avgSpo2?.let { u.bindLong(4, it.toLong()) } ?: u.bindNull(4)
          s.avgResp?.let { u.bindLong(5, it.toLong()) } ?: u.bindNull(5)
          u.bindLong(6, s.start.toLong())
          if (u.executeUpdateDelete() == 0) {
            db.execSQL("INSERT INTO sleep_scores (start, end, score, efficiency, avg_spo2, avg_resp) VALUES (?, ?, ?, ?, ?, ?)", arrayOf<Any?>(s.start, s.end, s.score, s.efficiency, s.avgSpo2, s.avgResp))
          }
        }
      }
      // HRV malam menurut jam sendiri (ringkasan tidur, "Avg HRV" di layar Sleep health jam). Disimpan sebagai source 'watch';
      // pembaca memakainya lebih dulu daripada rata-rata RMSSD catatan stres ('night'), yang bisa jauh lebih rendah.
      for (s in result.sleepScores) {
        val h = s.avgHrv ?: continue
        db.execSQL("DELETE FROM hrv_readings WHERE source = 'watch' AND start <= ? AND end >= ?", arrayOf<Any?>(s.end, s.start))
        db.execSQL(
          "INSERT OR REPLACE INTO hrv_readings (start, end, source, rmssd, sdnn, mean_rr, beats) VALUES (?, ?, 'watch', ?, NULL, NULL, 0)",
          arrayOf<Any?>(s.start, s.end, h.toDouble()),
        )
      }
      if (result.totalsFromWatch && result.midnight > 0) {
        // Total harian resmi dari jam (FitnessTotals): kalori dalam kkal, jarak dalam meter. Jumlah sampel per menit bisa kurang.
        val now = System.currentTimeMillis() / 1000
        db.compileStatement("UPDATE day_totals SET steps = ?, calories = ?, distance = ?, updated_at = ? WHERE midnight = ?").use { u ->
          u.bindLong(1, result.totalSteps.toLong()); u.bindLong(2, result.totalCalories.toLong()); u.bindLong(3, result.totalDistance.toLong())
          u.bindLong(4, now); u.bindLong(5, result.midnight)
          if (u.executeUpdateDelete() == 0) {
            db.execSQL(
              "INSERT INTO day_totals (midnight, steps, calories, distance, updated_at) VALUES (?, ?, ?, ?, ?)",
              arrayOf<Any>(result.midnight, result.totalSteps, result.totalCalories, result.totalDistance, now),
            )
          }
        }
      }
      db.execSQL("UPDATE device SET last_sync = ? WHERE address = ?", arrayOf(result.to, address))
      db.setTransactionSuccessful()
    } finally {
      db.endTransaction()
    }
    return SyncSummary(
      from = result.from,
      to = result.to,
      samples = result.samples.size,
      sleep = result.sleep.size,
      totalSteps = result.totalSteps,
      totalCalories = result.totalCalories,
      totalDistance = result.totalDistance,
    )
  }

  private companion object {
    /** Must match `DATABASE_NAME` in `src/app/_layout.tsx`. */
    const val DATABASE_NAME = "joyofit.db"
    const val MIGRATIONS_ASSET = "joyofit-db-migrations.json"
    const val BUSY_TIMEOUT_MS = 10_000
  }
}
