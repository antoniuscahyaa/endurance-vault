package com.joyodigitama.huaweiwear

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Writes workouts into the shared database (`workouts`, `workout_points`; migration 3 in
 * `schema/joyofit-db-migrations.json`) through [SyncStore]'s connection. A workout is replaced as a whole in one
 * transaction: the row is upserted by `start` (the id stays), its old points are deleted and the new ones inserted.
 */
internal class WorkoutStore(private val store: SyncStore) : WorkoutSink {
  override suspend fun isComplete(start: Long, end: Long): Boolean = withContext(Dispatchers.IO) {
    store.db().rawQuery(
      "SELECT 1 FROM workouts WHERE start = ? AND end = ? AND complete = 1",
      arrayOf(start.toString(), end.toString()),
    ).use { it.moveToFirst() }
  }

  override suspend fun save(record: WorkoutRecord): Boolean = withContext(Dispatchers.IO) {
    val db = store.db()
    db.beginTransaction()
    try {
      val wasComplete = db.rawQuery("SELECT complete FROM workouts WHERE start = ?", arrayOf(record.start.toString())).use {
        if (it.moveToFirst()) it.getInt(0) == 1 else null
      }
      // Tanpa UPSERT (SQLite lama di Android 10 ke bawah): UPDATE dulu, INSERT bila belum ada.
      val vals = arrayOf<Any?>(
        record.number, record.end, record.sportType, record.sportName, record.duration, record.distance,
        record.calories, record.avgHr, record.maxHr, record.steps, record.summaryJson, if (record.complete) 1 else 0, record.start,
      )
      if (wasComplete != null) {
        db.execSQL(
          """UPDATE workouts SET workout_number = ?, end = ?, sport_type = ?, sport_name = ?, duration = ?, distance = ?,
               calories = ?, avg_hr = ?, max_hr = ?, steps = ?, summary_json = ?, complete = ?, imported = 0 WHERE start = ?""",
          vals,
        )
      } else {
        db.execSQL(
          """INSERT INTO workouts (workout_number, end, sport_type, sport_name, duration, distance, calories, avg_hr, max_hr, steps, summary_json, complete, start)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
          vals,
        )
      }
      val id = db.rawQuery("SELECT id FROM workouts WHERE start = ?", arrayOf(record.start.toString())).use {
        it.moveToFirst()
        it.getLong(0)
      }
      db.execSQL("DELETE FROM workout_points WHERE workout_id = ?", arrayOf(id))
      val insert = db.compileStatement("INSERT INTO workout_points (workout_id, ts, lat, lon, alt, hr, cad) VALUES (?, ?, ?, ?, ?, ?, ?)")
      try {
        for (p in record.points) {
          insert.clearBindings()
          insert.bindLong(1, id)
          insert.bindLong(2, p.ts)
          p.lat?.let { insert.bindDouble(3, it) } ?: insert.bindNull(3)
          p.lon?.let { insert.bindDouble(4, it) } ?: insert.bindNull(4)
          p.alt?.let { insert.bindDouble(5, it) } ?: insert.bindNull(5)
          p.hr?.let { insert.bindLong(6, it.toLong()) } ?: insert.bindNull(6)
          p.cad?.let { insert.bindLong(7, it.toLong()) } ?: insert.bindNull(7)
          insert.executeInsert()
        }
      } finally {
        insert.close()
      }
      db.setTransactionSuccessful()
      wasComplete != true
    } finally {
      db.endTransaction()
    }
  }

  /**
   * Start of the next workout window, unix seconds: everything after the newest stored workout (from 2000-01-01, so
   * everything the watch holds, when there is none); the start of the oldest incomplete workout wins over that so it
   * is downloaded again. [fullHistory] always starts from 2000-01-01; stored workouts upsert by start.
   */
  suspend fun syncStart(fullHistory: Boolean = false): Int = withContext(Dispatchers.IO) {
    if (fullHistory) return@withContext DEFAULT_START_SEC.toInt()
    val db = store.db()
    // Workouts imported from a Huawei export say nothing about what the watch still holds.
    val newestEnd = db.rawQuery("SELECT MAX(end) FROM workouts WHERE imported = 0", null).use {
      if (it.moveToFirst() && !it.isNull(0)) it.getLong(0) else null
    }
    val oldestIncomplete = db.rawQuery("SELECT MIN(start) FROM workouts WHERE complete = 0", null).use {
      if (it.moveToFirst() && !it.isNull(0)) it.getLong(0) else null
    }
    val start = when {
      newestEnd == null -> DEFAULT_START_SEC
      oldestIncomplete != null -> minOf(oldestIncomplete, newestEnd + 1)
      else -> newestEnd + 1
    }
    minOf(start, Int.MAX_VALUE.toLong()).toInt()
  }

  companion object {
    /** 2000-01-01 00:00:00 UTC; GB's own fallback (2022-06-10) is an app-imposed limit this app does not keep. */
    const val DEFAULT_START_SEC = 946684800L
  }
}
