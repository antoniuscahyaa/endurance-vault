package com.joyodigitama.huaweiwear

import nodomain.freeyourgadget.gadgetbridge.devices.huawei.HuaweiPacket
import nodomain.freeyourgadget.gadgetbridge.devices.huawei.HuaweiTLV

/*
 * Pengganti BuildConfig dan R untuk berkas JoyoFit yang disalin apa adanya (Distribution.kt, MorningSummary.kt).
 * Di JoyoFit keduanya dibuat Gradle; di plugin ini namespace-nya berbeda, jadi paket com.joyodigitama.huaweiwear
 * tidak punya keduanya. Berkas ini milik proyek TrainingPlan, bukan salinan JoyoFit.
 */

/** Build sideload: tidak memakai izin SMS, log panggilan, atau kontak (plugin ini juga tidak mendeklarasikannya). */
internal object BuildConfig {
  const val DISTRIBUTION = "sideload"
}

internal object R {
  object drawable {
    const val ic_stat_joyofit: Int = android.R.drawable.stat_notify_sync
  }
  object color {
    const val joyofit_notification_accent: Int = android.R.color.holo_blue_dark
  }
}

/**
 * Paket dari TLV siap pakai, terenkripsi seperti paket pasca-autentikasi lain. Di JoyoFit ini ada di WorkoutLink.kt, yang tidak ikut
 * disalin; Ephemeris.kt (A-GPS) memakainya. Isinya sama dengan JoyoFit.
 */
internal class RawPacket(params: HuaweiPacket.ParamsProvider, service: Int, command: Int, content: HuaweiTLV) : HuaweiPacket(params) {
  init {
    serviceId = service.toByte()
    commandId = command.toByte()
    tlv = content
    isEncrypted = true
    complete = true
  }
}
