# EnduranceVault Native 0.5.54: penyusun sesi untuk editor segmen

Versi 0.5.54, version code 68.

## Perubahan
- **Editor segmen kini dibuka di "Susun sesi"** untuk aktivitas yang belum punya segmen: grafik kecepatan dengan blok kerja berwarna dan label tiap blok (mis. `15:00`, `3 × 8:00 / 2:00`, `10:00`), jumlah segmen, dan total susunan.
- Tiga kartu bawaan: **Pemanasan**, **Ulangi** (jumlah putaran, kerja, istirahat, "Istirahat setelah putaran terakhir" Ya/Tidak), dan **Pendinginan**. Setiap panjang bisa dalam **Waktu (m:ss)** atau **Jarak (m)**; ganti satuan mengonversi isian lewat kecepatan rata-rata sesi.
- **+ Segmen biasa** dan **+ Blok ulangi** menambah blok; menu ⋯ di tiap kartu untuk menaikkan, menurunkan, atau menghapus.
- **Selisih sesi aktual** dengan susunan (mis. jam mencatat 55:12 untuk susunan 55:00) masuk ke segmen terakhir, dengan catatan jelas di layar. Susunan yang lebih panjang dari sesi ditolak dengan pesan.
- **Terapkan N segmen** langsung menyimpan. **Segmen hasilnya tanpa label**: repetisi, stride, atau progresif diisi sendiri lewat pill setelah segmen jadi, tidak pernah otomatis.
- **Atur batas manual (mode lanjutan)** membuka editor lama dengan susunan yang sedang dibuat sebagai titik awal. Aktivitas yang sudah punya segmen (mis. lap jam) tetap dibuka di editor manual, yang kini punya tombol "Susun sesi" untuk berpindah.
- Susunan awal 15:00 + 3 × (8:00 / 2:00) + 10:00; otomatis diperkecil bila sesi lebih pendek dari 55 menit.

## Teknis
- `domain/SessionBuilder.kt` (baru): `resolve` mengubah blok menjadi `SegmentSplit.Draft` (kind selalu null), rentang nomor segmen tiap blok, dan lama tiap blok.
- `ui/screens/SessionBuilderUi.kt` (baru): `SessionBuilderPanel`.
- `SegmentEditorUi.kt`: `SegmentEditor` menjadi pembungkus; editor lama menjadi `ManualSegmentEditor`; `SegmentStrip` mendapat versi dengan batas dan warna dari pemanggil.
- Tes: `SessionBuilderTest`.

## Catatan
- Belum dikompilasi dan tes belum dijalankan di lingkungan ini. Jalankan CI.
