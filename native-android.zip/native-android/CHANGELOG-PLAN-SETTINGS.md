# Pengaturan rencana (tab Profil → Pengaturan → Rencana)

Berkas berubah:
- app/src/main/java/com/endurancevault/app/ui/screens/PlanSettingsPanel.kt (baru)
- app/src/main/java/com/endurancevault/app/ui/screens/ProfileScreen.kt (cabang "Rencana")

Isi: header collapsible "Plan settings", kartu ringkasan gelap (chip jenis, hari/minggu, km awal → puncak,
panjang rencana, total volume, grafik bar Build / Recovery week / Taper), tab Race / Volume / Week / Target / Strength,
dropdown Performance build cycle dan Block goal (pbCycle, pbFocus), tombol "Got a race?" (event lomba evOn/evDate/evKm/evGain)
dan "Recalculate plan N weeks • X km". Ringkasan dan grafik dihitung ulang langsung dari isian (pratinjau) sebelum disimpan.

## Audit perhitungan rencana terhadap rencana-lari-apk-20 (versi web)
- plan() Kotlin vs web: 54 skenario acuan (tools/golden-plan.mjs dijalankan ulang dari zip 20) identik dengan data acuan Kotlin; 0 beda.
- Perbaikan input plan() (padanan planRaw web): HR easy dan rentang threshold sesi diturunkan dari zona HR, pace dari pace easy log,
  HR maks dari log (PlanRaw.kt, RaceConfig.hrMaxEst/ltBand, MainViewModel). Sebelumnya native memakai angka manual lama.
- "Got a race?" kini alur konversi PB → rencana lomba (PbConversion.kt, port 24d), bukan event lomba.
