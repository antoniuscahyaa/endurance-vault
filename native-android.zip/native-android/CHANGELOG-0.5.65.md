# Warna grafik plan di dock jadwal = pengaturan plan

Berkas berubah:
- app/src/main/java/com/endurancevault/app/ui/screens/PlanSettingsPanel.kt (planBarColor / planBarBuild / planBarRecovery bersama, BarTaper internal)
- app/src/main/java/com/endurancevault/app/ui/screens/PlanOverviewScreen.kt (batang kartu hero memakai planBarColor, barColor abu-abu dihapus)

Build = warna primary tema, Recovery week = onSurfaceVariant 55%, Taper/race = #FFB27A.
