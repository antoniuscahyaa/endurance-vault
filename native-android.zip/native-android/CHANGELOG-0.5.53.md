# EnduranceVault Native 0.5.53: GPX Strava akurat dari jejak GPS asli

Versi 0.5.53, version code 67.

## Masalah
Unduh GPX di detail lari dibangun dari rute sederhana (±140 titik) dan deret per detik **tanpa koordinat**. Posisi tiap detik ditaksir dengan menempatkan jarak per detik pada garis rute itu, jadi tikungan kecil hilang, jarak dari koordinat bisa lebih pendek dari jarak aplikasi, dan jeda (elapsed) tidak muncul di Strava.

## Perubahan
- **Jejak GPS asli per detik kini disimpan saat impor dan autosync jam** (kunci baru `gt` di berkas detail): lintang/bujur resolusi 1e-6 (±0,11 m) dan **jam dinding** tiap detik. Disimpan sejajar indeks dengan deret 1 Hz (`tl`), dengan format selisih (sekitar 10 byte per detik).
- **Ekspor GPX memakai jejak itu langsung**: bentuk rute persis, jarak dari koordinat hampir sama dengan di aplikasi, dan **jeda ikut terbawa lewat stempel waktu** (peringatan elapsed hanya muncul untuk data lama).
- Pesan setelah menyimpan GPX menyebut sumbernya: "jejak GPS asli" atau "rute ditaksir".
- **Data lama tanpa `gt`** tetap bisa diekspor lewat jalur lama, kini dengan peringatan bahwa posisinya ditaksir dan cara memperbaikinya.
- **Autosync jam melengkapi detail lama**: tiap sinkron, detail hasil jam yang belum punya `gt` dilengkapi dari titik workout di database jam, **tanpa membangun ulang berkas** (cuaca, anotasi, dan edit tetap utuh). Dilengkapi hanya bila lintasan hasil bangun ulang sejajar dengan `tl` yang tersimpan (jumlah detik sama, jarak akhir selisih <= 1 m); bila tidak, berkas diberi `gt` kosong sebagai tanda "sudah dicoba". Maksimal 30 aktivitas per putaran sinkron; sisanya menyusul di sinkron berikutnya. "Sinkron riwayat penuh" menjangkau lebih banyak aktivitas lama. Sesi yang sudah di-crop dilewati.
- **Impor ulang berkas FIT/GPX/TCX** untuk aktivitas yang sudah punya detail tanpa `gt`: bila lintasannya sama, jejak GPS ditambahkan (sebelumnya impor ulang hanya "sudah ada"). Pesan impor menampilkan jumlahnya.
- **Crop** ikut memotong `gt` dengan indeks yang sama dengan `tl`; waktu tetap relatif terhadap `t0` asli, jadi GPX hasil crop mulai pada jam yang benar. Bila panjang hasil bangun ulang tak sama dengan potongan (jarang), `gt` dibuang dan ekspor memakai jalur lama beserta peringatan.

## Teknis
- `domain/GpsTrack.kt` (baru): `GpsTrack`, `GpsTrackCodec` (`encode`, `decode`, `slice`, `toMap`, `alignedWith`).
- `ActBuilder`: `Row` membawa `la`/`lo`/`w` (detik jam dinding sejak titik pertama); `gt` dibangun bersama `tl` hanya bila ada >= 2 titik GPS. Posisi dan jam diinterpolasi pada detik gerak yang sama dengan `tl`; titik tanpa posisi diisi dari titik terdekat. Waktu dibuat naik tegas.
- `ActDetail.gpsTrack` (dibaca di `ActStore.fromMap` hanya bila panjang sama dengan `timeSeries`); `ActStore.hasGpsTrackKey`.
- `GpxExport`: `buildExact` / `buildApproximate`; `Result.exact`.
- `MainViewModel`: `backfillGpsTrack`, `upgradeGpsTrack`, `GPS_BACKFILL_PER_SYNC`. `WatchTrackMerge.VERSION` **tidak** dinaikkan, supaya tidak ada pembangunan ulang penuh yang menimpa cuaca/anotasi.
- Tes: `GpxExportTest` (jalur akurat vs cadangan, jeda, crop, codec, tanpa GPS); `ActGoldenTest` mengabaikan kunci `gt` (hanya ada di versi native).

## Catatan
- **Aktivitas hasil impor manual lama tidak bisa diperbaiki otomatis**: berkas FIT/GPX aslinya tidak pernah disimpan. Impor ulang berkas aslinya (lihat di atas). Aktivitas hasil jam diperbaiki lewat sinkron.
- Titik workout di database jam bisa saja sudah dibersihkan untuk aktivitas yang sangat lama; untuk itu `gt` kosong dan GPX tetap lewat jalur cadangan.
- Ukuran berkas detail bertambah sekitar 100 KB per lari 3 jam (cadangan ikut membesar).
- Jarak dari koordinat Strava tetap bisa sedikit berbeda dari angka aplikasi (Strava menghitung ulang, dan pada FIT jarak aplikasi memakai sensor jam). Peringatan >2% tetap ada.
- Belum dikompilasi dan tes belum dijalankan di lingkungan ini (tidak ada Gradle/Kotlin). Jalankan CI.
