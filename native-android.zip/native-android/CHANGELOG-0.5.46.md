# EnduranceVault Native 0.5.46: tab Fitness disamakan dengan Kebugaran di rencana lari

Versi 0.5.46, version code 60.

- Sub-tab **Fitness** (Profile > Progress) kini berisi enam kartu yang sama dengan grup `fit` ("Kebugaran") di rencana lari, dengan urutan yang sama:
  Kebugaran lari, Personal record, Zona pace dari RAI, Efisiensi aerobik, Cardiac drift, Tren easy run.
- Kartu **Tren easy run** (waktu di zona per minggu, skor per sesi, sesi Terlalu keras berturut-turut) baru di native.
- **Efisiensi aerobik** baru di native: pace pada HR tetap, rentang 3 bln / 6 bln / 1 th / Semua, HR target dapat diubah, saran HR bila data kurang.
- **Cardiac drift** baru di native: rata-rata drift, tren 3 lari terakhir vs 3 sebelumnya, daftar 8 lari terakhir.
- Kartu native lama yang tidak ada di tab Kebugaran web dihapus dari sub-tab ini: Training load (masih ada di sub-tab Load), Morning signal trend, Easy-run compliance, Aerobic efficiency & cardiac drift versi lama.
- Komponen kartu Rekap (`RcCard`, `RcInner`, `RcBig`, `RcStats`, dll.) dibuat `internal` agar dipakai ulang; tampilan Rekap tidak berubah.
- Belum dikompilasi di lingkungan ini (tidak ada compiler Kotlin/Gradle); jalankan CI.
