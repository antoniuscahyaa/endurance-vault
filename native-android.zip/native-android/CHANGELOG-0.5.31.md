# EnduranceVault Native 0.5.31

## Build fix
- Added `openSettings` and `onSettingsOpened` parameters to `ProfileScreen` where the `LaunchedEffect` consumes them.
- Removed those misplaced arguments from the separate `ProgressScreen` call in `AppRoot`.
- Kept the settings request arguments on the `ProfileScreen` invocation.
- Version code 45; version name 0.5.31.

## Validation
- Checked that the ProgressScreen call no longer receives ProfileScreen-only parameters.
- Checked ProfileScreen declaration and invocation parameter alignment at source level.
- ZIP integrity checked. Android Gradle build has not been run in this environment.
