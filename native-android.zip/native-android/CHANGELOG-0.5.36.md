# EnduranceVault Native 0.5.36: zona HR default dengan dua tombol

Versi 0.5.36, version code 50.

## Perubahan
- Panel "Zona HR · Default": dropdown "Metode zona default" dan tombol "Kirim zona ke jam" diganti dua tombol, LTHR dan HRR.
- Ketuk 1x: tombol itu jadi metode default (tersimpan) dan tabel zonanya tampil (kolom HR istirahat untuk HRR atau LTHR manual, tabel persen yang bisa diedit, tombol "Kembalikan persen ke awal"). Ketuk tombol yang sama lagi untuk menutup tabel.
- Tekan lama: metode dipilih, zona dikirim ke jam, dan tabel menutup. Ada getaran singkat saat tombol terdeteksi ditahan.
- Keterangan kecil di bawah tombol: "Tahan tombol untuk kirim zona ke jam".
- Status kirim di bawah keterangan: "Mengirim zona HR ke jam…", hijau bila terkirim, merah bila gagal, tidak valid, atau jam belum terhubung.
- Zona yang diedit tidak otomatis dikirim; muncul "Zona berubah. Tahan tombol … untuk kirim ulang agar jam ikut."
- Panel "Zona HR · LTHR" dan "Zona HR · HRR (Karvonen)" dihapus karena isinya pindah ke tabel di bawah tombol. Panel "Patokan sesi" dan "HR lomba per kategori" tidak berubah.
- `MainViewModel.syncWatchHrZones` mengisi status "Mengirim zona HR ke jam…" sebelum kirim, supaya status lama tidak terbaca sebagai hasil terbaru.

## Berkas
- `ui/screens/HrZoneSettings.kt`, `ui/MainViewModel.kt`, `app/build.gradle.kts`.
- Tanda tangan `HrZoneSettings` tidak berubah, jadi Profil dan layar Watch tidak perlu disentuh.

## Validasi
- Keseimbangan kurung dicek di sumber. Gradle Android belum dijalankan di lingkungan ini; jalankan CI untuk memastikan kompilasi.
