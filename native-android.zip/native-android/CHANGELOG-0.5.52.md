# EnduranceVault Native 0.5.52: prediksi waktu 3 intensitas di strategi pacing

Versi 0.5.52, version code 66. Sudah termasuk perubahan peta 0.5.51 (CHANGELOG-0.5.51.md).

## Perubahan
- Di dialog **Preview rute GPX**, **target waktu manual diganti tiga kartu prediksi**: **Ringan**, **Sedang**, **Berat**. Tiap kartu menampilkan total waktu, pace rata-rata per km rute, dan sifat usahanya (santai, stabil, usaha lomba).
- Kartu terpilih (bawaan **Sedang**) langsung dipakai untuk pembagian pace per ruas, profil elevasi berwarna, dan sesi pace yang dikirim ke jam. Totalnya sama dengan waktu di kartu.
- Isian **Target waktu** hanya muncul di lembar pengaturan bila **belum ada data performa** (kurang dari 3 lari >= 3 km dengan HR). Pengaturan strategi (Rata / Negative split / Hati-hati) dan permukaan turunan tetap ada.

## Cara menghitung
1. **Performa saat ini** = indeks kemampuan (setara VO2max/VDOT) dari `ProgressAnalytics.runningAbility`: median pace dan HR lari 4 minggu terakhir. Angka yang sama dengan kartu Prediksi lomba di tab Progres.
2. **Medan jadi jarak datar setara**: tiap ruas rute dikali bobot GAP Minetti, hukuman turunan curam (menurut permukaan), dan beban turunan kumulatif, yaitu bobot yang sama dengan yang dipakai membagi pace per ruas. Jumlahnya = km datar setara. Contoh: 32 km dengan D+ 1.250 m setara kira-kira 38 sampai 40 km datar.
3. **Waktu** = waktu lari km datar setara itu pada kurva VDOT (`RecapAnalytics.raceTimeV`) untuk indeks kemampuan dikali: Berat 100% (usaha lomba), Sedang 93%, Ringan 86%.
4. **Perlambatan jarak jauh**: bila waktu lebih dari 3 jam, ditambah 3% per jam di atas 3 jam (kurva VDOT cenderung terlalu optimis untuk durasi panjang). Ini heuristik, bukan hasil kalibrasi dari datamu.
5. Cuaca, panas, dan kondisi hari itu belum diperhitungkan.

## Kode
- `CourseStrategy`: `enum Effort`, `forecast(pts, ability, surf)`, `forecastMinutes(flatKm, ability, f)`, `pacingMin(pts, minutes, strat, surf)` (`pacing` kini memanggilnya).
- `GpxPreviewDialog(p, ability, onSend, onDismiss)`: komponen `EffortOptions`; `AppRoot` menghitung `ability` saat dialog terbuka.
- Tes baru di `CourseStrategyTest`: urutan 3 intensitas, medan menambah jarak datar setara, total strategi = waktu prediksi, perlambatan hanya di atas 3 jam, null tanpa elevasi atau indeks tak masuk akal.

## Catatan
- Persentase 86/93/100 dan 3% per jam adalah titik awal; kalau hasil terasa terlalu cepat atau lambat dibanding lari trail sungguhan, ubah `Effort.f` dan `FADE_PER_HOUR` di `CourseStrategy.kt`.
- Belum dikompilasi dan tes belum dijalankan di lingkungan ini (tidak ada Gradle/Kotlin). Jalankan CI.
