# EnduranceVault Native 0.5.47: peta pada rute aktivitas

Versi 0.5.47, version code 61.

- Detail aktivitas kini menampilkan **rute di atas peta OpenStreetMap** (garis oranye dengan tepi putih, titik Mulai hijau dan Selesai merah), menggantikan garis polos tanpa latar.
- Koordinat asli dipulihkan dari bingkai `ge` yang sudah tersimpan di setiap aktivitas, jadi **aktivitas lama tidak perlu diimpor ulang**. Tanpa `ge`, tampilan lama (garis offline) tetap dipakai.
- Ubin peta di-cache di disk (`cacheDir/osm-tiles`, kedaluwarsa 14 hari) dan memori. Rute yang pernah dibuka tetap bermap saat offline; bila belum pernah dimuat dan offline, garis rute tetap tampil dengan catatan.
- Peta bisa dicubit (zoom) dan digeser. Cubit dua jari selalu aktif; geser satu jari hanya saat peta sudah diperbesar, supaya halaman tetap bisa di-scroll. Tombol "Reset" muncul untuk kembali ke tampilan pas-rute.
- Atribusi "© OpenStreetMap" tetap ada, dalam huruf kecil (7 sp) di sudut kanan bawah.
- Berkas baru: `domain/RouteGeo.kt`, `data/MapTiles.kt`, `ui/screens/RouteMapView.kt`, `RouteGeoTest.kt`. Tidak ada dependensi baru dan tidak ada kunci API; izin INTERNET sudah ada di manifest.
- Privasi: membuka peta mengirim nomor ubin (kira-kira area lari) ke tile.openstreetmap.org.
- Catatan: server ubin OSM publik ditujukan untuk pemakaian ringan. Bila aplikasi dirilis luas, pindahkan ke penyedia ubin sendiri/berbayar (ubah URL di `MapTiles.download`).
- Belum dikompilasi di lingkungan ini (tidak ada compiler Kotlin/Gradle); jalankan CI.
