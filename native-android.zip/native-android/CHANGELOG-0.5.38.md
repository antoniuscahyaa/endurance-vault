# EnduranceVault Native 0.5.38: persen zona digeser di bar

Versi 0.5.38, version code 52.

## Perubahan
- Panel "Zona HR · Default": kotak isian persen di tabel diganti garis batas yang digeser langsung di bar Z1–Z5 (LTHR: batas Z2–Z5; HRR: batas Z1–Z5). Langkah 1%, tiap garis dibatasi tetangganya sehingga urutan zona tidak mungkin salah.
- Saat menggeser, keterangan di bawah bar menampilkan "Z3 mulai di 90% · 155 bpm" dan tabel di bawahnya ikut berubah langsung. Disimpan saat jari diangkat; jam tidak dikirim otomatis (tetap ditahan di tombol), jadi peringatan "Zona berubah sejak dikirim terakhir" muncul seperti sebelumnya.
- Tabel zona tetap ada tetapi hanya-baca (persen sebagai teks), lengkap dengan kolom "Dipakai untuk". Header kolom terakhir diberi jarak agar tidak menempel ke "HR (bpm)".
- Aksesibilitas: tiap garis punya aksi "Naikkan 1 persen" dan "Turunkan 1 persen" untuk TalkBack.
- Bila zona tersimpan berurutan salah (data lama), bar menampilkan nilai awal; geseran pertama menulis ulang semua persen dari nilai awal itu.
- Tombol "Kembalikan persen ke awal" tetap ada.
- Petunjuk "Tahan tombol untuk kirim zona ke jam" tanpa ikon.

## Kode
- `ui/screens/HrZoneSettings.kt`: `ZonePctBar` dan `DragReadout` baru; `PctField`, `IssueText`, dan `ZoneBar` dihapus. `ZoneChecks.pctIssues` (domain, bertes) tidak lagi dipakai UI tetapi dipertahankan.

## Validasi
- Keseimbangan kurung dicek di sumber. Gradle Android dan uji sentuh (geser, TalkBack) belum dijalankan di lingkungan ini; jalankan CI dan coba di perangkat.
