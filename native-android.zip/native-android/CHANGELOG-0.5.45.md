# 0.5.45: susunan Rekap

- Ulasan mingguan dipindah ke samping Progres (dua kolom); Log bulanan selebar layar.
