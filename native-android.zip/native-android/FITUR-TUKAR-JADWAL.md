# Port tukar / bagi jadwal dari rencana-lari

Sumber logika: `rencana-lari` `03-perencana-gear-statistik.js` (swapDays, swLists, spDist, spApply, adjust), `14b-libur-dadakan-panel.js`, `14-editor-foto-latar-video.js` (dayRow).

## Berkas
- `domain/SessionAdjust.kt` (baru): logika murni, tanpa Android. Tukar hari, libur dadakan, geser/lewati sesi terlewat, penyelesaian sesi.
- `data/MvStore.kt` (baru): baca/tulis `mv` dan `done` (format web, tabel kv, ikut cadangan) + migrasi sekali jalan dari `week_adjustments_v1`.
- `domain/PlanModels.kt`: PDay/PWeek/StrengthBlock menampung penanda penyesuaian.
- `ui/MainViewModel.kt`: `UiState.mv/done`, plan diproses `SessionAdjust.apply` sebelum `ProfilePlanAdjustments`, `setMv()`, `setDone()`.
- `ui/screens/ScheduleScreen.kt`: ditulis ulang.
- `ui/screens/RecapTab.kt`: pengecualian kepatuhan membaca `state.mv`.
- `test/.../SessionAdjustTest.kt` (baru).

## Perilaku
- Tukar hari: minggu yang sama, 14 hari ke depan, boleh dengan hari libur, belum selesai dan belum punya penyesuaian lain. Peringatan bila melahirkan dua sesi berat berurutan. Batalkan kapan saja.
- Libur dadakan: km dibagi ke easy/long lain (+40% / +25%, min +2 km), opsi sisa ke easy minggu depan (maks +10%), pengaman kondisi (nyeri, kesiapan, alasan), nilai manual kelipatan 0,5 km.
- Sesi terlewat: quality digeser ke easy berikutnya, long run ke hari libur berikutnya, atau pilih Geser ke / Tukar libur / Lewati / Pilih hari lain. Minggu berikutnya -20% bila terlewat banyak.
- Penanda selesai: otomatis dari lari tercatat (termasuk lari dari jam dan input manual, bukan hanya cadangan web), centang manual, dan centang per blok strength/ankle/upper (otomatis dari Free Strength jam).
