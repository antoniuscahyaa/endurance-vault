# EnduranceVault Native 0.5.44: rapikan kepala kartu Rekap

Versi 0.5.44, version code 58.

- Label kepala kartu setengah lebar tidak lagi terpotong (huruf 9sp, label mengisi ruang, padding dikurangi).
- Pil kepatuhan dipersingkat jadi "Jalur · Sesuai/Pantau/Waspada".
- Belum dikompilasi di lingkungan ini; jalankan CI.
