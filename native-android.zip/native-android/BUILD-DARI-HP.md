# Membangun APK dari HP (tanpa PC)

1. Buat akun di github.com, lalu repositori baru (Private), mis. `endurancevault`.
2. Buka github.com di browser HP dengan mode "Situs desktop". Ekstrak `native-android.zip` dulu di HP (aplikasi File/Files by Google),
   lalu di repositori pilih Add file → Upload files, dan unggah isi folder `native-android` (termasuk folder `.github`, `app`, dan file Gradle).
   Bila folder tersembunyi `.github` sulit diunggah, buat file `.github/workflows/android.yml` lewat Add file → Create new file,
   ketik nama lengkap dengan garis miring, lalu tempel isinya.
3. Tab Actions → "Build APK" → Run workflow. Tunggu sekitar 5–10 menit.
4. Buka run yang selesai, bagian Artifacts: unduh `EnduranceVault-debug-apk` (zip berisi `app-debug.apk`) dan `laporan-tes`.
5. Ekstrak zip, ketuk APK untuk memasang (izinkan "Pasang dari sumber ini").
