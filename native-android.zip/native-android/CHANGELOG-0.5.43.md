# EnduranceVault Native 0.5.43: layout tab Rekap mengikuti referensi

Versi 0.5.43, version code 57.

## Tampilan
- Kartu Rekap berkepala ikon bulat + label mono huruf besar + chevron. Urutan tutup: Kepatuhan rencana, Progres (setengah lebar), Grafik mingguan, Ulasan mingguan + Log bulanan (dua kolom), Kalender konsistensi, Heatmap tahunan.
- Saat dibuka, kartu melebar penuh (pasangan setengah lebar ikut turun), ringkasan diganti isi, kepala diberi garis pemisah dan keterangan di kanan.
- Kontrol: segmen pil oranye (Jarak/Waktu/..., Bar/Line, Jarak/Load), tombol bulat ‹ ›, pil "Minggu lalu"/"Bulan ini"/"Bagikan", tombol "i" untuk catatan.
- Kepatuhan: border emas saat ada saran geser, pil "Sinyal jalur", cincin, batang mingguan.
- Progres terbuka: tabel mono, bagian bersarang Prediksi lomba, Prediksi dari PR, Beban vertikal, Riwayat pace easy (sumbu 15 dtk, lebih tinggi = lebih cepat), Ringkasan akhir siklus (loop 6,3 km).
- Log bulanan: sel hari hijau dengan km, titik biru sepeda, garis merah strength, hari ini berbingkai tebal.
- Kalender konsistensi: delta di bawah angka; heatmap tanpa label hari, legenda di kanan.
- Chip tab bawah: pil oranye untuk tab aktif; header "REKAP" dihapus.

## Domain
- `RecapAnalytics`: `adhSignal`, `verticalLoad` (EWMA 7/28 hari), `cycleSummary`; `RecapPlanWeek.cut` dan `RecapPlanDay.bench`. 3 tes baru (10/10 lulus di JVM).

## Validasi
- Domain dikompilasi dan diuji dengan kompiler Kotlin. UI Compose hanya dicek keseimbangan kurung; jalankan CI dan cek di perangkat.
