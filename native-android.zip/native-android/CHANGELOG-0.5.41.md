# EnduranceVault Native 0.5.41: dock Minggu mengikuti layout Week

Versi 0.5.41, version code 55.

## Perubahan
- Dock Minggu disusun ulang mengikuti dock Week di rencana-lari: judul besar "Minggu" dihapus; tombol This week / History berupa pil oranye dan menempel di atas saat daftar digulir.
- Kartu rencana: judul (mis. "Performance Build · 3:1 · Threshold focus"), chip fase, "Week 3 of 18 · 2–8 Nov", bar "17% of plan". Ketuk untuk membuka Total / Peak / Done.
- Tombol Import (impor berkas FIT/GPX/TCX, sama dengan di Progress) dan Share (bagikan ringkasan pekan sebagai teks).
- Kartu statistik pekan: Distance (Target vs Actual + "Down 38% from last week", target pekan ini dibanding capaian pekan lalu), Training load (target = estimasi dari rencana, actual = jumlah load harian), Elevation gain, dan HR zone distribution (Z1–Z5, waktu dan persen dari histogram HR aktivitas pekan itu). Ketuk untuk membuka; "Set as main" memilih metrik yang tampil saat tertutup (tersimpan).
- Kartu hari bergaya sama dengan Jadwal: bar aksen, chip "Logged · …", tombol Detail dan Share, status "✓ On plan", judul dicoret bila sesi dibatalkan, lingkaran selesai oranye. Tombol aksi (geser, tukar, libur dadakan, tandai selesai) tetap muncul saat kartu diketuk.
- Aktivitas di luar jadwal (sepeda, lari bebas, lari di hari libur) tampil sebagai kartu "Outside schedule" di hari terkait.
- Kartu strength memakai gaya yang sama (See sets · N exercises).

## Kode
- Baru: `ui/screens/WeekDock.kt` (komponen dan perhitungan angka pekan). `ScheduleScreen.kt` memakainya; parameter baru `onImportTracks` dan `trackMsg` disambung dari `AppRoot.kt`.
- `TrainingMetrics.plannedWeekLoad()` baru: estimasi beban rencana satu pekan.

## Validasi
- Belum dikompilasi di lingkungan ini; jalankan CI dan cek di perangkat. Angka target load adalah estimasi dan bisa berbeda dari versi web.
