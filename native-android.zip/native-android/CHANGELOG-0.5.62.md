# EnduranceVault Native 0.5.62: Tab Body mengikuti tampilan aplikasi lama

Version code 76.

## Berubah (Progress → Body)
- **Sleep and condition** (terbuka secara bawaan), isinya berurutan seperti aplikasi lama:
  - **7-day sleep debt**: batang Mon sampai Sun (7 hari berakhir hari ini), angka jam di atas tiap batang, "-" bila malam itu belum tercatat. Batang di bawah kebutuhan berwarna merah-oranye, yang memenuhi oranye tua. Di kanan judul: `Debt N h`.
  - Bila malam tercatat kurang dari 3, kanan judul tampil `–` dan baris Average diganti `Needs sleep data for at least 3 of the last 7 nights (n so far).` Skala batang tetap (minimal 9 jam).
  - Baris mono `Average X of N h · k/7 nights logged` dan `Watch data last applied HH:mm (just now)` (diambil dari waktu sinkron jam terbaru).
  - **Sleep need (hours per night)**: kolom isian 5 sampai 10 jam, langsung tersimpan; tombol "i" menjelaskan cara hitung. Memakai kunci yang sama dengan dialog Readiness (`readiness_settings` / `sleep_need_hours`).
  - **Sleep** (hari terakhir yang punya data): jam tidur, total besar, jam bangun, bilah fase (Deep/REM/Light) dengan legenda, Time to fall asleep, Average sleep HR, Avg SpO₂ dan Avg respiratory rate; lalu tiap `Nap · mulai–selesai` dan `Nap total · n×`.
  - **▶ Sleep history, 7 days**: tabel 7 hari (Sleep, Nap, RHR, HRV, Leg, Mood), dibuka dengan ketukan.
  - Baris metrik dengan sparkline 7 hari: Resting HR, Sleep HR, HRV, Sleep SpO₂, Sleep respiration, Sleep duration, Nap.
- **Strength progress**: ringkasan saat tertutup kini angka besar + pil `▼/▲ %` + `sessions · 7 days`, dan dua batang pembanding (7 hari ini dibanding 7 hari sebelumnya). Jam tidak menyimpan set, jadi yang dihitung adalah jumlah sesi, bukan set.
- **Strength balance**: teks dan label diseragamkan (bahasa Inggris, durasi `Xh YYm`); logikanya tidak berubah.
- Grafik gabungan 14 hari (tombol Tidur / HR istirahat / HRV) dan grafik Rasa kaki & Mood 14 hari diganti oleh tampilan di atas. Data Leg dan Mood tetap ada di tabel Sleep history.

## Teknis
- `TrainingMetrics`: `effectiveSleepHours(day)` dan `sleepDebtOf(effective, need)` dibuat publik; perhitungan utang tidur kartu Readiness kini memakai fungsi yang sama dengan Body, jadi angkanya selalu sama.
- `BodyTab.kt` ditulis ulang: `BdDay` mengurai `DailyEntity.raw` (`shr`, `ssp`, `srr`, `nap`, `naps`, `bed`, `wake`, `deep`, `rem`, `light`, `watch.syncedAt`).
- Belum dikompilasi di lingkungan pembuatnya; periksa hasil CI.
