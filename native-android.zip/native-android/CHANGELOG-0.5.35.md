# EnduranceVault Native 0.5.35: istilah Elevation Gain/Loss dan kalibrasi elevasi dengan jam

## Istilah
"D+", "D−", "Tanjakan", dan "Turunan" (untuk total elevasi) diganti di seluruh UI:
- Detail aktivitas: kelompok **Elevasi** memakai "Elev. Gain" dan "Elev. Loss".
- Tabel per km: satu kolom "D+ / D−" dipecah menjadi dua kolom "Elev. Gain" dan "Elev. Loss" (bobot kolom disesuaikan
  supaya muat di layar 360 dp tanpa terpotong; judul satu baris).
- Riwayat ("ELEV. GAIN"), Progress, Recap (chip grafik mingguan, kartu pekan, keterangan), Profil
  ("Elevation Gain lomba (m)").
- "Tanjakan tercuram" dan "Turunan tercuram" tetap: itu kemiringan (%), bukan total elevasi.

## Kalibrasi dengan jam (`data/ElevationCalibration.kt`)
Aplikasi menghitung elevasi dari altitude rute dengan ambang histeresis, jam memakai algoritmanya sendiri sehingga angkanya
bisa berbeda. Sekarang:
- Elevation Gain/Loss aktivitas = total resmi jam (sama dengan layar jam). Hitungan aplikasi disimpan di `gainRaw`/`lossRaw`.
- Elev. Gain/Loss tiap km diskalakan dengan rasio total jam / hitungan aplikasi, supaya jumlah per km sejalan dengan total.
- Rute tanpa altitude memakai angka jam apa adanya.
- Jam hanya menandai sebagian angka sebagai resmi. `WorkoutRecord` kini menyimpan `elevationGainSource` dan
  `elevationLossSource` ("watch" = total jam, "samples" = jumlah sampel mentah yang cenderung membengkak karena derau).
  Angka "samples" atau tanpa penanda (workout lama) hanya dipakai bila rasionya 0,6 sampai 1,6; di luar itu hitungan
  aplikasi dipertahankan.
- Profil elevasi (grafik ketinggian) tidak diubah. Aktivitas tanpa rute menampilkan Elev. Loss dari jam (disimpan di catatan).
- Versi detail jam naik ke 3, sehingga **Sinkron** berikutnya membangun ulang detail jam yang lama dengan kalibrasi ini.
- Tes baru `ElevationCalibrationTest` (8 tes). Versi 0.5.35, version code 49.

## Validasi
Kode belum dikompilasi dan tes belum dijalankan di lingkungan ini (tidak ada Kotlin/Gradle). Jalankan CI.
Workout lama yang disimpan sebelum versi ini belum punya penanda sumber, jadi kalibrasinya memakai batas rasio di atas.
