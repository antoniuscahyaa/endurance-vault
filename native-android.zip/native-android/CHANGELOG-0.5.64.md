# EnduranceVault 0.5.64

- Mengisi sub-tab Profil > Timeline dengan daftar aktivitas tersimpan dari basis data aktivitas, diurutkan terbaru.
- Kartu aktivitas lebar mengikuti area konten dengan margin, menampilkan judul, tanggal/waktu, dan ringkasan metrik sesuai jenis olahraga.
- Menampilkan peta rute OpenStreetMap pada kartu ketika detail aktivitas memiliki koordinat GPS.
- Mengetuk area judul/ringkasan kartu membuka halaman detail aktivitas melalui navigasi yang sudah ada.
