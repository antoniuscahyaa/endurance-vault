# EnduranceVault Native 0.5.33: detail aktivitas setara rencana-lari

Layar detail aktivitas dibangun ulang dari `openAct()` di rencana-lari dan disesuaikan dengan data native
(load, recovery, TE dari `TrainingMetrics`; data jam di `note`). Versi 0.5.33, version code 47.

## Tiga halaman (chip di atas konten)
**Ringkasan**
- Hero: jarak, waktu gerak (ketuk ⇄ untuk waktu total, tampil bila selisih ≥ 10 dtk, plus jeda), pace atau kecepatan, chip "Sesuai rencana".
- Kelompok statistik: Pace (GAP, km tercepat, segmen tercepat), Jantung (HR rata-rata dengan % LTHR, HR maks), Elevasi (D+, D−, vertical speed), Teknik (kadens, panjang langkah).
- Baterai jam terpakai, catatan pengguna, pilihan gear (sepatu) yang disimpan ke aktivitas.
- Rute, profil elevasi dengan ringkasan (tertinggi, terendah, tanjakan/turunan tercuram).
- Grafik sesi interaktif: HR, kadens, elevasi, pace, vertical speed; tiap deret bisa dimatikan, sentuh atau geser untuk membaca nilai. Sumbu waktu bila ada data 1 Hz, selain itu sumbu jarak.
- Cuaca saat lari (suhu, terasa, kelembapan, angin, hujan, kondisi, sensor jam) bila ada di berkas aktivitas.
- Komentar otomatis: intensitas terhadap LTHR, pace dan GAP, konsistensi (paruh kedua, variasi), HR drift, load dan TE dibanding 10 sesi lari sebelumnya.

**Zona & beban**
- Zona HR dari histogram.
- Training effect aerobik dan anaerob (dari jam bila ada, selain itu perkiraan aplikasi).
- Training load: load sesi, load jam, serta fitness (CTL), fatigue (ATL), dan form pada hari itu.
- Recovery: waktu recovery, waktu pulih penuh, sisa sekarang (angka jam menggantikan rumus aplikasi, sama seperti pil Recovery di header).
- Recovery heart rate dari jam (HR akhir, menit ke-1, turun 1 dan 2 menit) dengan kurvanya.
- Evaluasi easy run (skor, kepatuhan HR, drift, stabilitas) untuk sesi yang bertanda easy/long.

**Per km**
- Cek terhadap rencana (jarak, tanjakan, HR terhadap batas easy, menit di zona untuk sesi kualitas).
- Perbandingan paruh, HR drift, tabel per km dengan bar pace, GAP, kadens, panjang langkah, D+/D−.
- Tabel per segmen (lap FIT atau jam).

## Perubahan kode
- `domain/ActInsights.kt` (baru, tanpa dependensi Android): semua logika di atas. Dicocokkan dengan fungsi JS asli (`driftOf`, `gapAct`, `gapSplit`, `strideLen`).
- `domain/ActDetail.kt`: tambahan `weather`, `vam`, `battery`, `vertSpeedSeries`, `startEpochMs` (default kosong, tidak merusak pemanggil lama).
- `data/ActStore.kt`: membaca `wx`, `vam`, `bat`, `vs`, `t0` dari berkas aktivitas.
- `data/Db.kt` dan `MainViewModel`: `setGear` / `setActivityGear`.
- `ui/screens/ActivityDetailScreen.kt` ditulis ulang, `ActivityDetailParts.kt` baru (grafik, kartu, zona).
- `AppRoot.kt`: detail menerima `trainingMetrics` dan aksi gear.
- Tes baru `ActInsightsTest` (12 tes).

## Belum dimigrasi (menyusul)
- Bagikan aktivitas (kartu, video peta, HUD, Strava), peta dasar OpenStreetMap, zoom cubit pada rute.
- Rute serupa dan perbandingan year-over-year, komentar "rute sama dengan lari…".
- Pengambilan cuaca otomatis (hanya menampilkan cuaca yang sudah ada di berkas), effort pace, VO2max estimasi.
- Analisis interval (`ivBlock`), pengeditan tipe segmen, potong aktivitas, hapus impor, pengingat easy-run/flBlock.
- Cek rencana untuk sesi berbasis durasi (trail/ultra) memakai jarak rencana, bukan menit.

## Validasi
- Logika domain dan pembacaan berkas dikompilasi dan dites di JVM (12 tes lulus).
- Kode Compose (`ActivityDetailScreen`, `ActivityDetailParts`) ditinjau di tingkat sumber saja; Gradle Android belum dijalankan di lingkungan ini.
