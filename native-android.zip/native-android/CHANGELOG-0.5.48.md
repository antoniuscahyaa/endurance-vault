# EnduranceVault Native 0.5.48: crop, edit, dan hapus aktivitas

Versi 0.5.48, version code 62.

## Perubahan
- Detail aktivitas punya menu ⋮ di kanan atas: **Edit aktivitas**, **Potong (crop)**, **Hapus aktivitas**.
- **Crop** (seperti Strava): dua gagang pada profil elevasi (atau HR bila tanpa altitude) untuk membuang bagian awal/akhir, tombol ±5 dtk untuk penyetelan halus, dan pratinjau jarak/waktu/pace hasilnya. Setelah disimpan, jarak, waktu, pace, GAP, HR, kadens, D+/D−, split, zona HR, profil, grafik sesi, dan rute dihitung ulang dari bagian yang dipertahankan. Ada konfirmasi karena crop tidak bisa dibatalkan.
  - Butuh data per detik (aktivitas hasil sinkron jam atau impor FIT/GPX/TCX). Aktivitas dari cadangan web lama tidak punya data ini; menunya menjelaskan hal itu.
  - Jam mulai aktivitas tidak berubah. Training effect, load, recovery, recovery HR, D+/D− resmi, dan baterai dari jam dibuang dari sesi yang di-crop (jam menghitungnya untuk sesi utuh); aplikasi memperkirakan ulang, dan sinkron jam berikutnya tidak memasangnya kembali.
- **Edit**: nama, deskripsi, tipe (lari/sepeda), tanggal, jam mulai. Mengubah tipe ke sepeda melepas gear sepatu. Gear dan rasa tetap diubah di halaman detail.
- **Hapus**: dialog konfirmasi, lalu baris aktivitas dan berkas detail (rute, grafik) dihapus. Tombol hapus di daftar Progres memakai jalur yang sama, jadi berkas detail tidak lagi tertinggal.
  - Aktivitas yang berasal dari jam dicatat di daftar "sudah dihapus" (kv `deleted`, ikut cadangan lengkap) supaya sinkron jam berikutnya tidak memunculkannya lagi. Aktivitas manual atau impor berkas tidak diblokir.
- Sinkron jam kini mengenali baris lewat `srcKey` atau `watchStart` di catatan, bukan hanya tanggal/jam/jarak, sehingga baris yang sudah di-crop atau disunting tidak terduplikasi.
- Nama aktivitas tampil di halaman Ringkasan.

## Kode
- `domain/ActCrop.kt` (baru): potong deret 1 Hz lalu bangun ulang lewat `ActBuilder.build`; rute dipotong menurut proporsi panjang garis.
- `domain/ActEdit.kt` (baru): `ActEdit` (catatan, validasi, terapkan ke berkas detail) dan `ActTombstones`.
- `domain/ActBuilder.kt`: parameter opsional `cadScale` (crop memakai 1 agar kadens tidak digandakan lagi).
- `data/ActStore.kt`: `readMap`. `data/Db.kt`: `bySrcKey`, `byNoteLike`.
- `ui/MainViewModel.kt`: `deleteActivity` (membersihkan berkas + penanda), `cropActivity`, `editActivity`; `importWatchData` melewati aktivitas yang sudah dihapus; `mergeWatchNote` menyimpan `watchStart` dan menghormati `cropped`.
- `ui/screens/ActivityEditUi.kt` (baru): `CropEditor`, `EditActivityDialog`, `ConfirmDeleteDialog`. `ActivityDetailHeader.kt`: menu ⋮. `ActivityDetailScreen.kt` dan `AppRoot.kt`: penyambungan.
- Tes baru: `ActEditCropTest.kt`.

## Batasan
- Rute tidak punya waktu per titik, jadi pemotongan rute memakai proporsi jarak; ketelitiannya setara resolusi rute tersimpan (±1/1000 rentang rute).
- Waktu total (termasuk jeda) setelah crop dihitung sama dengan waktu bergerak karena jeda per detik tidak tersimpan.
- Baris gabungan jam lama tanpa berkas detail dan tanpa `watchStart` bisa terduplikasi bila tanggal/jam/tipenya diedit lalu jam disinkron; pakai "Cari duplikat".

## Validasi
- Gradle Android dan Kotlin tidak tersedia di lingkungan ini (tanpa jaringan), jadi kode belum dikompilasi dan tes JVM belum dijalankan. Jalankan CI dan coba di perangkat: crop, edit, hapus, lalu sinkron jam.
