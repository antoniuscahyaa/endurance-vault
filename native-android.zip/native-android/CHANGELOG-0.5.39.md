# EnduranceVault Native 0.5.39: tab Jadwal padat dalam satu kartu

## Perubahan
- Tab Jadwal (`PlanOverviewScreen`) ditulis ulang agar muat dalam satu kartu utama tanpa gulir vertikal.
- Hero gelap dipadatkan: chip PERFORMANCE BUILD / "6 D/MGG", panjang rencana dan total volume (20sp), pilihan Km/Hours/Climb/Descent satu baris, strip minggu terpilih, grafik batang 74dp (isi = sudah dilari, segitiga = lonjakan >10%), dan chip lonjakan satu baris yang bisa digeser.
- Daftar minggu digeser horizontal per blok 4 minggu (BASE 1/1, BUILD 1/3, ...). Tinggi baris minggu menyesuaikan sisa layar (34-46dp) sehingga selalu ada celah kecil di atas dock.
- Titik halaman dan dock fase Base/Build/Peak/Taper di bawah: dock mengikuti halaman, ketuk fase untuk lompat; ketuk batang atau chip lonjakan untuk membuka halaman minggunya.
- Ketuk baris minggu membuka sheet dari bawah berisi kartu hari (Logged, Detail, On plan / Needs attention / Missed) dan blok strength.
- `AppRoot.kt`: `PlanOverviewScreen` menerima `onOpenActivity`.

## Catatan
- Rencana hanya menyimpan D+; Descent memakai angka Climb. Hours = km rencana x pace pengaturan.
- Belum dikompilasi di lingkungan ini; jalankan CI / Gradle dan cek di perangkat.
