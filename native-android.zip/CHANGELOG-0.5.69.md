# Splash: outline gelap pada huruf E di area oranye

- Huruf E pada logo splash diberi outline gelap `#0B0C0F` setebal 3,5 px (px referensi layar 324, diskalakan `lebar layar / 324`), senada dengan halo gelap di sekitar V dan panah.
- Outline hanya tampil di bagian E yang menempel pada latar oranye (di atas garis siluet). Di area gelap outline menyatu dengan latar, jadi tidak terlihat.
- Tebal outline diatur lewat `E_OUTLINE_REF_PX` di `SplashOverlay.kt`.

Berkas berubah:
- app/src/main/java/com/endurancevault/app/ui/SplashOverlay.kt
