# EnduranceVault Native 0.5.59: Stiker data tahap 2 (mingguan, interval, warna kustom)

Version code 73. Lanjutan 0.5.58, masih port dari `10c-stiker-data.js`.

## Baru
- **Angka interval** (chip "Dari analisis interval" di Baris angka, muncul bila pola interval terdeteksi): Repetisi (mis. `4×400 m`), Pace interval, Tercepat, Fade (dtk/km), HR awal→akhir.
- **Pace per repetisi**: bar per repetisi (hijau bila lebih cepat dari rata-rata, oranye bila lebih lambat), garis putus-putus rata-rata.
- **Angka minggu** (kartu terpisah, jumlah kolom ikut Baris angka): jarak, waktu, elevasi naik, sesi (`selesai / rencana`), pace rata-rata, HR rata-rata.
- **Zona HR minggu**, **Target minggu** (bar rencana vs aktual per hari, persen dan sisa km), **Tren pace mingguan** (4, 6, atau 8 minggu; selisih terhadap minggu sebelumnya).
- **Warna kustom** (slider RGB atau kode hex) untuk **warna aksen** dan untuk **warna bar mingguan** (zona HR minggu dan target minggu), di samping tujuh warna cepat.
- Port analisis interval ke Kotlin: `domain/IntervalAnalysis.kt` (`ivDetect`, `ivStats`, mode auto). Sumber berurutan: segmen berlabel Repetisi, lap tanpa label (dua kelompok cepat/lambat, pola cepat-lambat-cepat), lalu kurva pace bila tidak ada lap.
- Ringkasan minggu: `domain/StickerWeeks.kt` (`weekSummary`, `weekZones`, `stkTrend`).

## Penyesuaian terhadap versi native
- **Interval dari label**: web memakai tipe Interval ('w'); native memakai label **Repetisi**. Pada deteksi lap, web melewati lap warm-up/cool-down/tempo; native melewati lap berlabel **Stride** dan **Progresif**. Mode "Lap FIT" dan "Manual" di web belum ada.
- **Free Run**: di web berkunci `tanggal~fN`. Di native, baris dengan `srcKey` berisi `~f` dianggap Free Run; bila satu tanggal punya beberapa baris tanpa `~f`, baris pertama (id terkecil) dianggap log hari rencana dan sisanya Free Run. Free Run ikut total minggu, grafik harian, hitungan sesi, dan pace/HR rata-rata, sama seperti web.
- **Sesi selesai**: hari rencana dihitung selesai bila ada log dengan jarak (termasuk sepeda) atau dicentang manual (`done`), seperti `isDone` di web.
- **Pace/HR minggu**: dari hari easy/short terjadwal ditambah semua Free Run (bukan rata-rata semua lari seperti `weekStats` di tab Rekap); ini mengikuti `weekSummary` web.
- Sepeda tidak punya stiker mingguan. Sesi di luar minggu rencana mana pun tidak punya stiker mingguan.

## Masih belum diport
Training effect dan Training load (angka), Vs PR, Vs rute serupa, pemilih sesi di dalam layar, jalan masuk dari Profil.

## Teknis
- Baru: `IntervalAnalysis.kt`, `StickerWeeks.kt`, `StickerIntervalWeekTest.kt`.
- Diubah: `Stickers.kt` (pengaturan `wk`, `trendWeeks`, `weekColor`; angka interval dan minggu; id `wk-all`, `pace-repetisi`, `tren-pace`, `zona-hr-minggu`, `target-minggu`), `StickerRenderer.kt` (5 penggambar baru), `StickerScreen.kt` (chip interval, bagian Angka minggu, opsi tren, `ColorChoice` dan dialog warna).
- Tes baru: deteksi interval dari label/lap/kurva, lari steady tidak terdeteksi, ringkasan minggu (km, waktu, sesi, pace, HR, zona, hari), konteks minggu, tren, angka minggu, pengaturan, `dPace`.

## Catatan
- **Belum dikompilasi dan tes belum dijalankan** di lingkungan pembuatnya (tanpa Kotlin/Gradle). Jalankan `./gradlew testDebugUnitTest`, bangun APK, dan cek tampilan stiker di perangkat. Penggambar Canvas belum dites otomatis.
