# 0.5.102

**Bagikan statistik digabung ke Stiker data.** Kartu statistik berdesain tetap (11 template, Feed/Story, judul kartu) dihapus.
Datanya sekarang jadi item stiker di menu ⋮ → **Stiker data**, bagian **Statistik periode**, supaya bisa dipadukan manual
dengan stiker lain di foto (tempel sampai 5, seret, ubah ukuran, rasio 9:16 / 4:5 / 1:1).

## Statistik periode
- **Periode:** Harian (sesi yang dibuka), Mingguan (Senin sampai Minggu), Bulanan (tanggal 1 sampai akhir bulan). Satu pilihan berlaku untuk semua item periode.
- **Angka periode** (`p-angka`): jarak, waktu, pace, elevasi, sesi, hari aktif, HR, terpanjang. Dipilih dan diurutkan lewat ketukan; jumlah kolom ikut Baris angka.
- **Angka besar periode** (`p-hero`): km raksasa dengan rentang tanggal.
- **Kalender periode** (`p-kalender`): mingguan = tujuh sel bernilai km, bulanan = kalender panas mulai tanggal 1. Tidak untuk harian.
- **Kurva jarak harian** (`p-kurva`): garis dan area jarak per hari, hari terjauh diberi angka. Tidak untuk harian.
- **Cincin target** (`p-cincin`): hanya bila ada jarak rencana pada periode itu.
- **Banding periode** (`p-banding`): selisih terhadap minggu lalu, bulan lalu, atau rata-rata per lari 28 hari (harian); selisih durasi, pace, elevasi.
- Warna teks, aksen, panel latar, ukuran PNG, dan huruf kustom mengikuti pengaturan stiker yang sudah ada. Semua PNG transparan.
- Paket sesi, Simpan semua, dan Pratinjau di foto otomatis ikut mencakup item baru.

## Dihapus
- Layar `ShareStatsScreen`, rute `sharestats/{id}`, item menu **Bagikan statistik**, parameter `onOpenShareStats`.
- `ShareTemplates`, `ShareCardRenderer`, `ShareBrandIo` (judul kartu dan ikon di kartu), `ShareSegments` (grafik segmen harian sudah ada di stiker Bar pace per segmen).
- Tes `ShareSegmentsTest` dan `ShareTitleTest`.
- Ukuran Feed/Story dan latar Solid/Foto/Transparan khusus kartu tidak ada lagi: ukuran ditentukan di Pratinjau di foto, latar selalu transparan.

## Teknis
- Baru: `domain/StickerPeriods.kt` (`PeriodData`), tes `StickerPeriodTest`.
- Diubah: `domain/Stickers.kt` (`StickerPrefs.per/pf`, `StickerModel.periods/numPer/keysPer`, id `p-*`), `ui/sticker/StickerRenderer.kt` (`pHero`, `pCalendar`, `pCurve`, `pRing`, `pCompare`), `ui/screens/StickerScreen.kt`, `ui/AppRoot.kt`, `ui/screens/ActivityDetailScreen.kt`.
- `PeriodStats` dan `PeriodStatsTest` tetap dipakai.
- **Belum dijalankan di lingkungan ini:** build Gradle, uji unit, dan tampilan di perangkat. Cek di HP: tiap periode × tiap palet (putih, hitam, lime, kustom), minggu lintas bulan, Februari, sesi sepeda (periode kosong), tanpa rencana (Cincin hilang), dan Pratinjau di foto dengan item baru.
