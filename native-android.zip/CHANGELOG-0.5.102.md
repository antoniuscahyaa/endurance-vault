# 0.5.102

**Bagikan statistik digabung ke Stiker data.** Kartu statistik berdesain tetap (11 template, Feed/Story, judul kartu) dihapus.
Datanya sekarang jadi item stiker di menu ⋮ → **Stiker data**, bagian **Statistik periode**, supaya bisa dipadukan manual
dengan stiker lain di foto (tempel sampai 5, seret, ubah ukuran, rasio 9:16 / 4:5 / 1:1).

## Statistik periode
- **Periode:** Harian (sesi yang dibuka), Mingguan (Senin sampai Minggu), Bulanan (tanggal 1 sampai akhir bulan). Satu pilihan berlaku untuk semua item periode.
- **Angka periode** (`p-angka`): jarak, waktu, pace, elevasi, sesi, hari aktif, HR, terpanjang. Dipilih dan diurutkan lewat ketukan; jumlah kolom ikut Baris angka.
- **Angka besar periode** (`p-hero`): km raksasa dengan rentang tanggal.
- **Kalender periode** (`p-kalender`): mingguan = tujuh sel bernilai km, bulanan = kalender panas mulai tanggal 1. Tidak untuk harian.
- **Kurva jarak harian** (`p-kurva`): garis dan area jarak per hari, hari terjauh diberi angka. Tidak untuk harian.
- **Cincin target** (`p-cincin`): hanya bila ada jarak rencana pada periode itu.
- **Banding periode** (`p-banding`): selisih terhadap minggu lalu, bulan lalu, atau rata-rata per lari 28 hari (harian); selisih durasi, pace, elevasi.
- Warna teks, aksen, panel latar, ukuran PNG, dan huruf kustom mengikuti pengaturan stiker yang sudah ada. Semua PNG transparan.
- Paket sesi, Simpan semua, dan Pratinjau di foto otomatis ikut mencakup item baru.

## Layar Stiker data
- **Viewer terpaku di atas, geser horizontal.** Semua stiker yang tersedia untuk sesi (angka, peta, minggu, periode, grafik) ada di satu pager; geser kiri-kanan untuk berpindah. Di bawahnya tampil nama stiker, nomor halaman, nama berkas, dan tombol **Simpan** untuk stiker yang sedang tampil. Pesan hasil simpan juga muncul di bawah viewer, tidak ikut tergulir.
- **Pengaturan umum di atas viewer.** Sesi, warna teks, warna aksen, panel latar, ukuran, dan huruf ada di panel **Pengaturan umum** (terlipat secara bawaan; ketuk untuk membuka, tinggi dibatasi dan bisa digulir).
- **Pengaturan di bawah viewer mengikuti stiker yang tampil.** Hanya seksi stiker itu yang muncul: Baris angka untuk stiker angka sesi, Template peta untuk peta, Angka minggu, Statistik periode (periode, data angka, dan jumlah kolom untuk Angka periode), dan Bar dan grafik. Di Bar dan grafik, tiap stiker hanya menampilkan pengaturannya sendiri (mis. zona HR: tampilan zona; tren pace: jumlah minggu; zona HR minggu dan target minggu: warna bar; bar pace per segmen: sorot dan garis HR); stiker tanpa pengaturan khusus diberi keterangan. Jumlah kolom (Angka per baris) ikut tampil di semua stiker angka. Setelah itu, Paket sesi, Pratinjau di foto, dan Simpan semua tetap di bawah.
- Pratinjau per seksi dihapus karena digantikan viewer. Posisi halaman dipertahankan saat data diubah (mis. memilih angka lain).
- Terjemahan EN untuk teks baru ditambahkan di `assets/i18n/en.tsv`.

## Penyempurnaan viewer dan gaya
- **Banding yang adil untuk periode berjalan.** Bila minggu atau bulan masih berjalan, pembandingnya dipotong sejumlah hari yang sama sejak awal periode sebelumnya (bukan satu periode penuh), dan rentang kedua sisi ditampilkan di label bar (mis. "Minggu ini · 9–11 Nov" vs "Minggu lalu · 2–4 Nov"). Periode yang sudah selesai tetap dibandingkan penuh.
- **Tempel ke foto langsung dari viewer.** Tombol **Tempel** menambahkan stiker yang tampil ke foto (maksimal 5) dan menggulir ke Pratinjau di foto. Bila belum ada foto, galeri dibuka dulu lalu stiker itu yang ditempel pertama.
- **Latar viewer bisa diganti:** Palet, Gelap, Terang, atau Foto (bila sudah ada foto). Hanya tampilan viewer; PNG yang disimpan tetap transparan.
- **Chip lompat** Angka, Peta, Minggu, Periode, Grafik di atas viewer (hanya jenis yang tersedia) untuk melompat ke stiker pertama jenis itu.
- **Preset gaya:** simpan kombinasi warna teks, aksen, panel, ukuran, kedua huruf, dan gaya angka dengan nama (maksimal 8, nama maksimal 20 huruf); ketuk untuk memakai, tombol Hapus muncul saat preset aktif.
- **Gaya angka dan judul "Miring tebal":** angka dan judul dimiringkan dan ditebalkan di semua stiker; huruf kustom ikut ditebalkan. Pilihannya "Standar" atau "Miring tebal".
- Tinggi viewer 200 dp (turun dari 220) supaya area pengaturan lebih lega.

## Splash
- `SplashOverlay` (splash tahap 2) diganti dengan versi baru: lingkaran gelap muncul di tengah, bagian logo masuk bergiliran, huruf V digambar dari kiri sebagai panah bergerak, kepala panah menyentak sebentar, lalu memudar (total sekitar 2,2 detik). Tahap 1 (splash sistem warna aksen) dan pemanggilan di `MainActivity` tidak berubah.
- Jadwal animasi ada di konstanta di awal file (`CIRCLE_MS`, `PIECE_MS`, `V_START_MS`, `V_DRAW_MS`, `KICK_MS`, `HOLD_MS`, `FADE_MS`).

## Dihapus
- Layar `ShareStatsScreen`, rute `sharestats/{id}`, item menu **Bagikan statistik**, parameter `onOpenShareStats`.
- `ShareTemplates`, `ShareCardRenderer`, `ShareBrandIo` (judul kartu dan ikon di kartu), `ShareSegments` (grafik segmen harian sudah ada di stiker Bar pace per segmen).
- Tes `ShareSegmentsTest` dan `ShareTitleTest`.
- Ukuran Feed/Story dan latar Solid/Foto/Transparan khusus kartu tidak ada lagi: ukuran ditentukan di Pratinjau di foto, latar selalu transparan.

## Teknis
- Baru: `domain/StickerPeriods.kt` (`PeriodData`), tes `StickerPeriodTest` (periode berjalan, preset, dan gaya angka ikut dites).
- `PeriodStats.previous(..., today)` dan `summarizeIn`; `StickerPrefs.numStyle/presets`, `StickerPreset`; `StickerPalette.slant`; `StickerIo.addSticker(prefer)`.
- Diubah: `domain/Stickers.kt` (`StickerPrefs.per/pf`, `StickerModel.periods/numPer/keysPer`, id `p-*`), `ui/sticker/StickerRenderer.kt` (`pHero`, `pCalendar`, `pCurve`, `pRing`, `pCompare`), `ui/screens/StickerScreen.kt`, `ui/AppRoot.kt`, `ui/screens/ActivityDetailScreen.kt`.
- `PeriodStats` dan `PeriodStatsTest` tetap dipakai.
- **Belum dijalankan di lingkungan ini:** build Gradle, uji unit, dan tampilan di perangkat. Cek di HP: tiap periode × tiap palet (putih, hitam, lime, kustom), minggu lintas bulan, Februari, sesi sepeda (periode kosong), tanpa rencana (Cincin hilang), dan Pratinjau di foto dengan item baru.
