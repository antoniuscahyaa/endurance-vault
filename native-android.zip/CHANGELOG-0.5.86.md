# AI Coach: buat sesi dan kirim ke jam; gear di Edit aktivitas

## AI Coach → kirim workout ke jam
- Tool baru `send_workout_to_watch` (domain/CoachActions.kt): pemanasan → N × (lari + recovery) → pendinginan. Contoh: "Buatkan threshold 3×10 menit zona 4 dan kirim ke jam."
- Seperti aksi coach lain, hanya usulan: muncul di kartu konfirmasi dan baru dikirim setelah **Terapkan**.
- Target intensitas berupa **zona HR 1..5** atau rentang pace m:ss/km. Model tidak menulis angka bpm: zona dikonversi aplikasi dari HR maks dan batas zona Pengaturan (`StructuredWorkout.zoneTarget`), sama dengan form Structured workout. Zona dan pace untuk langkah lari tidak boleh dicampur.
- Batas: pemanasan/recovery/pendinginan 0–60 mnt, repetisi 1–20, lari 1–180 mnt, nama maks 36 karakter; tool call di luar batas ditolak dengan alasan.
- Hasil (terkirim/gagal/jam tidak menjawab dalam 60 dtk) tampil di baris hasil kartu. Jalur kirim sama dengan `pushStructuredWorkout`.
- Prompt coach diperbarui: sesi hanya dari permintaan pengguna atau rencana yang tersedia.

## Gear di Edit aktivitas (titik tiga → Edit aktivitas)
- Dropdown **Gear** (muncul untuk aktivitas lari bila sudah ada gear): Tanpa gear atau gear aktif; gear pensiun yang sedang terpasang tetap tampil. Disimpan bersama tombol Simpan. Mengubah tipe ke sepeda tetap melepas gear.

Tes: `CoachActionsTest` (parse, validasi, konversi zona). Belum dikompilasi dan belum diuji di jam.
