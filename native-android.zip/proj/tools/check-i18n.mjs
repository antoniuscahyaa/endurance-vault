// Pemeriksa kamus bahasa (heuristik, tanpa dependensi). Jalankan dari folder proyek native:
//   node tools/check-i18n.mjs              -> gagal (exit 1) bila ada teks BARU yang belum punya terjemahan
//   node tools/check-i18n.mjs --list       -> tampilkan semua temuan, termasuk yang sudah ada di baseline
//   node tools/check-i18n.mjs --update     -> simpan temuan saat ini sebagai baseline (tools/i18n-baseline.json)
// Cara kerja: mengambil literal string dari kode UI, menebak bahasanya (Indonesia/Inggris) dari kata umum, lalu
// mencocokkan ke assets/i18n/en.tsv (Indonesia -> Inggris, untuk mode English) dan id.tsv (Inggris -> Indonesia, mode Indonesia).
// Hasilnya perkiraan: teks yang disusun saat aplikasi berjalan bisa lolos, dan istilah latihan (pace, easy run, ...) sengaja dibiarkan.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const main = path.join(root, 'app/src/main');
const baselineFile = path.join(here, 'i18n-baseline.json');
const args = new Set(process.argv.slice(2));

const PH = /\{\d*\}|%(?:\.\d+)?[sdf]/;
const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const unesc = (s) => s.replace(/\\n/g, '\n').replace(/\\t/g, '\t').replace(/\\\\/g, '\\');

function loadDict(file) {
  const ex = new Map(); const tp = [];
  for (const line of fs.readFileSync(file, 'utf8').split('\n')) {
    const t = line.indexOf('\t'); if (t <= 0) continue;
    const k = unesc(line.slice(0, t)); const v = line.slice(t + 1);
    if (PH.test(k)) {
      const parts = k.split(new RegExp(PH.source, 'g'));
      tp.push({ re: new RegExp('^' + parts.map(esc).join('([\\s\\S]*?)') + '$'), w: parts.reduce((a, x) => a + x.length, 0) });
    } else ex.set(k, v);
  }
  tp.sort((a, b) => b.w - a.w);
  return { ex, tp };
}
const EN = loadDict(path.join(main, 'assets/i18n/en.tsv'));
const ID = loadDict(path.join(main, 'assets/i18n/id.tsv'));

const SEPS = ['\n', ' · ', ' | ', '. ', '; '];
function covered(d, s, depth = 0) {
  if (d.ex.has(s)) return true;
  for (const t of d.tp) if (t.re.test(s)) return true;
  const tr = s.trim();
  if (tr && tr !== s && covered(d, tr, depth)) return true;
  if (depth < 2) for (const sep of SEPS) if (s.includes(sep)) {
    const parts = s.split(sep);
    return parts.every((p, i) => {
      if (!/[A-Za-z]/.test(p)) return true;
      if (covered(d, p, depth + 1)) return true;
      return sep === '. ' && i < parts.length - 1 && covered(d, p + '.', depth + 1);
    });
  }
  return false;
}

const IDW = new Set('yang dan untuk dengan tidak ini dari pada akan bisa sudah belum atau lebih dalam adalah ke di jika saat hanya semua tiap setiap lalu sampai agar karena sedang tersedia pilih atur simpan hapus tambah ubah buka tutup mulai selesai batal jam menit hari minggu pekan bulan tahun lari sesi jarak kecepatan detak jantung tidur latihan beban istirahat berikutnya sebelumnya aktif nonaktif kosong gagal berhasil memuat ada izin akses data berkas rute peta tema font ukuran teks kami kamu anda saya'.split(' '));
const ENW = new Set('the and for with your you to of is this that no not or are be from on at in by as can will has have use set add edit delete remove save open close start stop done cancel loading error failed none empty enable disable show hide select choose week month day year run runs pace heart rate sleep load zone zones training plan activity activities route map settings theme language data file files'.split(' '));
function lang(s) {
  const w = (s.toLowerCase().match(/[a-z]+/g)) || [];
  if (!w.length) return null;
  const i = w.filter((x) => IDW.has(x)).length, e = w.filter((x) => ENW.has(x)).length;
  if (!i && !e) return null;
  return i > e ? 'id' : e > i ? 'en' : 'mixed';
}

function walk(dir, out = []) {
  for (const f of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, f.name);
    if (f.isDirectory()) walk(p, out); else if (f.name.endsWith('.kt')) out.push(p);
  }
  return out;
}
// Dilewati: kamus itu sendiri, prompt AI, dan kode yang bukan teks layar.
const SKIP_PATH = /\/i18n\/|\/ai\/|Prompt|\/video\/|Sql|Query/;
const SKIP_LINE = /Log\.|Regex\(|getString\(|putString\(|const val|SharedPreferences|SELECT |http/;
const LIT = /"((?:[^"\\\n]|\\.)*)"/g;

const found = new Map();
for (const f of walk(path.join(main, 'java'))) {
  const rel = path.relative(main, f);
  if (SKIP_PATH.test('/' + rel)) continue;
  fs.readFileSync(f, 'utf8').split('\n').forEach((line, idx) => {
    const st = line.trim();
    if (st.startsWith('//') || st.startsWith('*') || st.startsWith('/*') || st.startsWith('import ')) return;
    if (SKIP_LINE.test(line)) return;
    for (const m of line.matchAll(LIT)) {
      const s0 = unesc(m[1]).replace(/\\"/g, '"');
      if (s0.length < 3 || !/[A-Za-z]{3}/.test(s0)) continue;
      if (/^[\w./:_-]+$/.test(s0) && !s0.includes(' ') && !/^[A-Z]/.test(s0)) continue;
      const s = s0.replace(/\$\{[^}]*\}|\$\w+/g, '{}');
      const L = lang(s);
      let key = null;
      if (L === 'en' && !covered(ID, s)) key = 'id-mode|' + s;      // Inggris yang bocor di mode Indonesia
      if (L === 'id' && !covered(EN, s)) key = 'en-mode|' + s;      // Indonesia yang bocor di mode English
      if (key && !found.has(key)) found.set(key, `${rel}:${idx + 1}`);
    }
  });
}

const baseline = new Set(fs.existsSync(baselineFile) ? JSON.parse(fs.readFileSync(baselineFile, 'utf8')) : []);
if (args.has('--update')) {
  fs.writeFileSync(baselineFile, JSON.stringify([...found.keys()].sort(), null, 1) + '\n');
  console.log(`Baseline diperbarui: ${found.size} temuan.`);
  process.exit(0);
}
const fresh = [...found].filter(([k]) => !baseline.has(k));
const show = args.has('--list') ? [...found] : fresh;
for (const [k, where] of show) {
  const [mode, s] = [k.slice(0, k.indexOf('|')), k.slice(k.indexOf('|') + 1)];
  const file = mode === 'id-mode' ? 'id.tsv (Inggris -> Indonesia)' : 'en.tsv (Indonesia -> Inggris)';
  console.log(`${baseline.has(k) ? '[lama] ' : '[BARU] '}${where}\n    ${JSON.stringify(s)}\n    tambahkan ke ${file}:  ${s.replace(/\n/g, '\\n')}\t<terjemahan>`);
}
console.log(`\nTemuan: ${found.size}, baru sejak baseline: ${fresh.length}.`);
if (fresh.length) { console.log('Tambahkan terjemahan di assets/i18n/*.tsv, atau jalankan --update bila memang sengaja dibiarkan.'); process.exit(1); }
