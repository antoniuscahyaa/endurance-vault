# 0.5.108 — Pratinjau widget + pemeriksa bahasa

## Pratinjau widget (Profil > Tampilan > "Pratinjau widget")
- Menampilkan ketiga widget (Hari ini, Sesi berikutnya, Progres mingguan) dengan renderer yang sama dengan widget sebenarnya dan data aktual aplikasi.
- Berubah langsung saat aksen, warna sendiri, mode terang/gelap, atau ukuran teks diganti. Tidak perlu memasang widget dulu.

## Pemeriksa bahasa: `node tools/check-i18n.mjs`
- Memindai literal string di kode UI, menebak bahasanya, lalu mengecek ke assets/i18n/en.tsv (Indonesia → Inggris) dan id.tsv (Inggris → Indonesia).
- Gagal (exit 1) hanya untuk teks BARU yang belum ada terjemahannya; temuan lama dicatat di tools/i18n-baseline.json (245 temuan, sebagian besar prompt AI dan fragmen kalimat, bukan teks layar).
- Mencetak baris TSV yang tinggal diisi terjemahannya. Opsi: `--list` (semua temuan), `--update` (jadikan kondisi sekarang sebagai baseline).
- Heuristik: teks yang disusun saat aplikasi berjalan bisa lolos; istilah latihan (pace, easy run, ...) sengaja dibiarkan Inggris.
- Disarankan dijalankan sebelum build rilis. Tidak dipasang ke Gradle agar build tidak gagal oleh temuan heuristik.
