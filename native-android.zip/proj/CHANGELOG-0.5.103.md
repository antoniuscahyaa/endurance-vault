# 0.5.103

**Perbaikan Stiker data dan 11 stiker baru.** Catatan: perubahan ini belum dikompilasi atau dijalankan (tanpa Android SDK); build dan jalankan `StickerExtrasTest` dulu.

## Perbaikan
- **Data basi saat berpindah sesi.** `loaded`, data tambahan, dan hasil gambar kini diberi cap id/model sesi, jadi hasil sesi lama tidak tampil di sesi baru (`produceState` tidak mereset nilainya saat kunci berubah).
- **Hemat memori.** Stiker digambar hanya bila dibutuhkan (yang tampil, dipilih untuk paket, dan item rencana foto). `renderAll` berhenti bila layar ditutup, dan OOM atau galat per stiker ditangkap sehingga satu stiker gagal tidak menggagalkan yang lain. Stiker yang gagal menampilkan pesan "Gagal digambar (memori kurang?)".
- **Thread-safety.** Akses `trendCache` kini `synchronized`.
- **Simpan semua** ditolak selama gambar belum selesai (mencegah paket tidak lengkap).
- **Stiker foto** dengan id yang tidak valid lagi diganti ke stiker pertama, dengan pesan.
- **Slider ukuran** juga membatasi posisi y agar stiker tidak keluar bingkai.
- `StickerIo.addSticker` memakai `Stickers.MAX_PHOTO_STICKERS` (bukan angka 5 tetap).
- Label "Elevation Gain" menjadi "Elevasi naik".

## Stiker sesi baru
- **MAF / Aerobik** (`maf`): HR rata-rata terhadap batas MAF, bar zona Z1/Z2/Z3+, drift HR, pace.
- **Vert / Tanjakan** (`vert`): profil elevasi, VAM, naik, turun.
- **Rute berwarna** (`peta-warna`): rute diwarnai menurut pace atau HR (pilihan di pengaturan), dengan legenda.
- **Cuaca** (`cuaca`): suhu, terasa, lembap, angin, hujan; kolom bisa diatur.
- **Best effort** (`best-effort`): waktu tercepat 1/5/10 km di dalam satu lari.
- **Vs PR** (`vs-pr`): jarak terpanjang yang punya PR dibanding hari ini.
- **Vs rute serupa** (`vs-rute`): pace sesi ini terhadap sampai 5 lari lain di rute yang sama.

## Stiker minggu dan tahun baru
- **Hitung mundur** (`hitung-mundur`): sisa hari ke lomba target dari rencana (tersembunyi bila tanggal lomba sudah lewat).
- **Training load** (`training-load`): rasio beban 7 hari dan delapan pekan terakhir.
- **Tahun** (`tahun`, kategori baru **Tahun**): km, elevasi, hari aktif, dan kalender panas 53 pekan.
- **Streak** (`streak`): hari dan pekan beruntun, rekor, tujuh hari terakhir.

## Teknis
- File baru `domain/StickerExtras.kt` (`StickerExtrasCalc`) menghitung data tambahan di thread Default; memakai ulang `ProgressAnalytics.personalBests/similarRoutes` dan `TrainingMetrics.calculate`.
- `StickerPrefs.mapColor` (kunci JSON `mc`, nilai `pace` atau `hr`).
- Terjemahan EN: 24 entri baru di `assets/i18n/en.tsv`.
- Tes baru: `StickerExtrasTest`.

## Belum ditangani
- Skop harian: km dari entitas dan km dari detail bisa sedikit berbeda.
- Pengomposisian foto belum dijaga oleh `sheetDone`.
