# 0.5.112 — Perbaikan tampilan, Timeline lebih cepat, rumus plan tanpa nama daerah

## Perbaikan
- Kartu Running: angka **Moving time** dan **Pace** kini sejajar (satuan disejajarkan lewat baseline, bukan padding).
- Kartu Huawei Watch: teks "Jam belum dihubungkan." tidak lagi muncul saat status sudah Connected.
- **Timeline** memakai `LazyColumn`: hanya kartu yang terlihat yang dirender (sebelumnya semua kartu, tiap kartu dengan peta dan ubin, dirender sekaligus). Urutan aktivitas di-`remember`.
- Sticker disimpan ke album **EnduranceVault** (sebelumnya "TrainingPlan"); hasil `Bitmap.compress` kini dicek dan galat penulisan dilaporkan.

## Rumus plan
- **Uji kebugaran** di minggu recovery (Base/Build) memakai metode umum: pemanasan 10–15 menit lalu blok 30 menit dengan HR dikunci di batas easy, rute yang sama tiap siklus. Tanda `bench` tetap ada (Recap/Fitness tetap membandingkan antar siklus). Jarak minimum sesi tetap 6,3 km.
- **Turunan** memakai rumus umum: D− per ulangan (±55 m awal, ±112 m penuh), panjang turunan ≈ D− ÷ kemiringan 6–8% (0,7–0,9 km atau 1,4–1,9 km), ditulis sebagai estimasi target. Total turun tetap menjadi target elevasi.
- Nama daerah dihapus dari rumus: "Long run · Jalan", "Turunan", tanpa Ambarawa/Kebonsari/Panjang.
- Kalimat "Pilih rute bergelombang." kini punya terjemahan (sebelumnya tercampur bahasa di mode English).

## Lokasi cuaca
- Lokasi bawaan tidak lagi "Ungaran, Indonesia" (-6.99, 110.42). Bawaannya "Lokasi saya" tanpa koordinat: bila izin lokasi ada, GPS dipakai otomatis; bila tidak, kartu menampilkan ajakan **Atur lokasi** dan widget melewati cuaca.
- Peta Explore tanpa lokasi tersimpan dibuka di Jakarta sebagai titik awal netral.
- Teks bawaan widget "Jakarta Selatan" diganti "Lokasi saya".

## Berkas
- Baru: `PlanGenericLabelsTest.kt`, `CHANGELOG-0.5.112.md`.
- Diubah: `ActivityDetailHeader.kt`, `HuaweiWatchSection.kt`, `ProfileScreen.kt`, `StickerIo.kt`, `PlanEngine.kt`, `RecapTab.kt`, `MainViewModel.kt`, `AppRoot.kt`, `GreetingWeatherCard.kt`, `GlanceWidgetWorker.kt`, `GlanceWidgetRenderer.kt`, `TrailTarget.kt`, `ev_widget_glance.xml`, `en.tsv`, `PlanGoldenTest.kt`, `i18n-baseline.json`, `build.gradle.kts`.

## Catatan
- Belum dibangun dan dijalankan di lingkungan ini (tanpa Gradle); jalankan build dan tes (`PlanGoldenTest`, `PlanGenericLabelsTest`, `I18nCoverageTest`) sebelum rilis.
- `plan-golden.json` berasal dari versi web (belum diperbarui): `PlanGoldenTest` memetakan judul lama ke judul baru dan melewati pembandingan detail untuk sesi uji kebugaran dan turunan.
- Kunci ganda "Per segmen" di `en.tsv` dibersihkan (terjemahan yang berlaku di runtime tetap "By segment").
- Pesan cuaca di tab Hari ini kini bisa menampilkan ajakan Atur lokasi pada instalasi baru atau setelah data dihapus.
