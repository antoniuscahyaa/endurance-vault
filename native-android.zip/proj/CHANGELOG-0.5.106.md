# 0.5.106 — Tema aksen tambahan + font + ukuran teks

Profil > Tampilan sekarang punya: Pratinjau langsung, Warna aksen, Font, Ukuran teks. Tema Default tidak berubah.

- **Warna aksen**: Default (orange), Pelangi Pastel (ungu, kartu pastel, tombol gradien), Warna sendiri (10 swatch + slider rona; pastel, gradien, dan zona HR dihitung otomatis). Terang dan gelap.
- **Pastel di lebih banyak layar**: kartu Tidur/Kesiapan/Zona HR, kartu sapaan, kartu Progress (Load/Fitness/Recap), tile metrik. Warna zona HR Z1-Z5 ikut tema aksen (default tetap palet lama).
- **Tombol** memakai `EvButton` (ui/theme/EvButton.kt): di tema default memanggil Button Material3 biasa.
- **Font**: 16 pilihan (5 font sistem + 11 dibundel di res/font, semua berlisensi terbuka, sekitar +3 MB APK).
- **Ukuran teks**: 85%-130%, hanya mengubah sp (teks), bukan dp (tata letak).
- Tetap orange: garis rute/peta. Tidak ikut font/ukuran: teks yang digambar lewat Canvas/Paint (video, stiker).

Berkas baru: ui/theme/AppFonts.kt, ui/theme/EvButton.kt, ui/screens/AppearanceSettings.kt, res/font/*.
