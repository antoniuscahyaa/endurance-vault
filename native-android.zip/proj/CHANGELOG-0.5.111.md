# 0.5.111 — Sesi strength live dengan animasi pemandu

## Fitur
- Kartu **Strength Progress** (Progres → Body) kini punya blok **Sesi live**: rekomendasi strength/upper/ankle berikutnya dari rencana (hari ini sampai 6 hari ke depan, yang belum selesai) dengan tombol **Mulai live**. Saat kartu dibuka tersedia sesi terjadwal lain dan sesi bebas (Strength A, B, Upper, Ankle) mengikuti fase minggu ini.
- Sesi layar penuh: pemandu animasi manekin ramping (23 jenis gerakan; lengan menyusul badan, napas dan getar halus, bayangan, tiap repetisi sedikit berbeda), hitungan repetisi otomatis menurut tempo gerakan, hitung mundur untuk gerakan tahan/jarak, jeda 5 dtk pindah sisi untuk gerakan per kaki/sisi, istirahat antar set (dibaca dari catatan blok, mis. 90 dtk; bisa +15 dtk atau dilewati), pratinjau gerakan berikutnya saat istirahat, jeda, kembali, dan Selesai set manual. Layar tetap menyala.
- Selesai (atau diakhiri lebih awal dengan Simpan): tercatat di riwayat strength (`swo`, jenis 140) dengan lama sesi sebenarnya. Sesi dari rencana tertaut ke harinya dan otomatis ditandai selesai di jadwal; sesi bebas bertipe Free.

## Berkas
- Baru: `domain/StrengthSession.kt`, `ui/screens/StrengthGuide.kt`, `ui/screens/StrengthLiveSession.kt`, `StrengthSessionTest.kt`.
- Diubah: `BodyTab.kt`, `ProgressScreen.kt`, `AppRoot.kt`, `MainViewModel.kt` (`saveLiveStrength`), `en.tsv`.

## Catatan
- Belum dibangun dan dijalankan di lingkungan ini (tanpa Gradle); jalankan build dan `StrengthSessionTest` sebelum rilis.
- `s` pada `swo` ditulis dalam detik epoch; sesuaikan bila data lama memakai milidetik.
- Denyut jantung/kalori tidak ikut tercatat karena sesi tidak membaca sensor jam.
- Gerak manekin berbasis rumus yang meniru karakter rekaman manusia (`GuideMotion`), bukan data mocap sungguhan.
- Animasi gerakan lateral (band walk, side plank) ditampilkan dari samping, jadi isyarat teksnya yang menjelaskan arahnya.
