# 0.5.107 — Widget layar utama + rapikan bahasa

## Widget (baru, 3 jenis, 4x2, bisa diubah ukuran)
- **EnduranceVault · Hari ini**: sesi hari ini + ring kesiapan (nilai sama dengan kartu Today).
- **EnduranceVault · Sesi berikutnya**: 3 sesi terjadwal berikutnya (Besok, Lusa, hari).
- **EnduranceVault · Progres mingguan**: km pekan ini vs target + batang 7 hari.
- Mengikuti tema aplikasi: aksen Default / Pelangi Pastel / Warna sendiri (pastel + gradien), mode terang/gelap, bahasa ID/EN.
- Digambar sebagai gambar (Canvas) agar warna tema persis sama. Font widget = font sistem (widget Android tidak mendukung font kustom). Ukuran teks aplikasi ikut, dibatasi 90–115%.
- Diperbarui otomatis tiap 30 menit, saat aplikasi ditutup/ditinggalkan, dan saat tema diubah. Perubahan mode gelap sistem baru terlihat di pembaruan berikutnya atau setelah membuka aplikasi.
- Ketuk widget membuka aplikasi. Kode: widget/ (WidgetData, WidgetRenderer, Widgets), res/xml/widget_*.xml, receiver di AndroidManifest.

## Bahasa
- Mode Indonesia: label Inggris yang bocor diterjemahkan lewat id.tsv: Light/Dark (pilihan tema), cuaca (Clear, Overcast, Snow, ...), tabel Body (Date, Nap, Leg, Type, Planned), Load (Fatigue, Aerobic, Anaerobic, Optimal range, Phase), pengaturan rencana (… focus), "✓ On plan/Marked done/Done", "On track", "AM I ON TRACK?", "TRAINING READINESS", "Set as main", "Month", "{} km/week", dll.
- Mode English: semua teks baru (widget, Pratinjau, Warna aksen, Font, Ukuran teks, nama dan deskripsi font) ditambahkan ke en.tsv.
- Istilah latihan yang umum dipakai pelari tetap berbahasa Inggris (pace, easy run, long run, interval, tempo, threshold, Training Load, ACWR, base/build/peak/taper).
