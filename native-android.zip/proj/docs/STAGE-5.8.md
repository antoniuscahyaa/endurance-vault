# Stage 5.8 — Release QA Gate & Artifact Integrity

## Tujuan
Memperketat pipeline agar APK release tidak diterbitkan jika unit test gagal, konfigurasi signing salah, atau sertifikat APK tidak cocok dengan keystore lama.

## Perubahan
- Unit test `testDebugUnitTest` sekarang wajib berhasil; `continue-on-error` dihapus.
- Menambahkan pemeriksaan awal untuk applicationId `com.endurancevault.app`, release signing config, dan file keystore persisten.
- Memperjelas validasi lokasi Android SDK dan pencarian `apksigner`.
- Tetap membangun varian `release` dan memverifikasi SHA-256 sertifikat APK terhadap keystore yang didekode dari satu secret `KEYSTORE_BASE64`.
- Menghasilkan file checksum SHA-256 untuk APK dan mengunggahnya bersama APK sebagai artefak build.
- Version code dinaikkan menjadi 7 dan version name menjadi 0.4.3.

## Yang tidak diubah
- Package name tetap `com.endurancevault.app`.
- Algoritma readiness, CTL/ATL/TSB, Training Effect, dan perhitungan latihan tidak diubah.
- Data aktivitas dan database tidak disentuh oleh perubahan pipeline.
- Protokol Bluetooth langsung turunan Gadgetbridge dan fitur forget/reconnect Stage 5.7 dipertahankan.

## Verifikasi
- Pemeriksaan statis workflow dan konfigurasi Gradle dilakukan saat paket disusun.
- Build Gradle, unit test, dan pemeriksaan sertifikat harus dikonfirmasi oleh GitHub Actions pada repository pengguna.
- Pengujian forget/reconnect, reconnect latar, dan sinkronisasi Watch Fit 4 tetap membutuhkan perangkat fisik.
