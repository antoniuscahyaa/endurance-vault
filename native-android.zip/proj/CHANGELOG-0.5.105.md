# 0.5.105 (bahasa: sapaan English, dua kamus, AI Coach, video)

## Sapaan (greeting)
- Salam English mengikuti jam, bukan terjemahan harfiah: 04-11 GOOD MORNING, 12-17 GOOD AFTERNOON, sisanya GOOD EVENING. Sebelumnya malam menjadi "GOOD NIGHT" (itu ucapan perpisahan) dan sore menjadi "GOOD EVENING" terlalu dini. Mode Indonesia tidak berubah. `GreetingEngine.word(period, hour)` dan `wordEn`; `TodayScreen` meneruskan jam.

## Kamus kebalikan untuk mode Indonesia (`assets/i18n/id.tsv`)
- Banyak kalimat dan label di kode ditulis dalam bahasa Inggris (tab Body, WeekDock, FeelCheck, Readiness, header detail aktivitas, Plan overview, dsb.), jadi muncul Inggris di mode Indonesia. `Translator` kini punya dua kamus dengan mesin sama (`DictTranslator`): `en.tsv` (Indonesia -> Inggris, mode English) dan `id.tsv` (Inggris -> Indonesia, mode Indonesia). `Lang.tr` memilih sesuai bahasa; `Lang.load` memuat kamus yang sesuai.
- ±220 entri awal. Istilah lazim seperti Easy run, Long run, Pace, Fitness, Load, GAP, HR sengaja tidak diterjemahkan.
- Tambah kalimat Inggris baru di kode? Daftarkan di `id.tsv`; atau tulis sumbernya dalam Indonesia dan daftarkan di `en.tsv`.

## AI Coach
- Prompt sistem selalu meminta "Jawab Bahasa Indonesia", jadi di mode English balasan tetap Indonesia. Kini `coachReplyLanguage()` meminta balasan penuh dalam bahasa aplikasi.
- Ringkasan aksi pada kartu konfirmasi ("Tambah lari…", "Kirim workout…", "Catat nyeri…", "Ubah pengaturan…") dirakit dengan `tf()` sehingga potongannya ikut diterjemahkan (sebelumnya campuran). Label pengaturan ikut diterjemahkan.

## Video HUD / Trail / Rute 3D
- Teks yang digambar di kanvas video (`TrailPainter.text`, `HudPainter.text`, `RouteVideoOverlay.txt`) kini lewat `Lang.tr`, jadi label seperti WAKTU, DENYUT, NAIK, MNT, JAM, KEC. RATA2 mengikuti bahasa aplikasi.

## Kamus English
- ±105 entri baru: label video, legenda stiker (Cepat, Curam, Naik, Turun, Lebih cepat), pesan simpan zona HR, teks Recap (streak), Explore (Tobler, matahari terbit, cuaca), Trail (arah mata angin, bentuk base), validasi workout, cek log zona LTHR, dan lainnya. Entri yang mirip dengan terjemahan 0.5.104 tidak ditimpa.

## Perbaikan build (GitHub Actions gagal di compileDebugKotlin)
- 29 error "experimental API" semuanya di `ui/screens/StickerScreen.kt`: `@OptIn(ExperimentalLayoutApi, ExperimentalFoundationApi)` terpasang pada kelas `StickerSheet` (terselip di antara anotasi dan fungsi), bukan pada `StickerScreen`. Anotasi dipindah tepat di atas `@Composable fun StickerScreen`.

## Tes
- `GreetingLanguageTest`: salam English per jam, salam Indonesia tidak berubah, format `id.tsv`, contoh terjemahan Inggris -> Indonesia.

## Belum dikompilasi/dijalankan di sini
- Cek di HP: mode English: Hari ini (pagi, siang, malam), video HUD, ringkasan aksi AI Coach. Mode Indonesia: tab Body, Week, Readiness, detail aktivitas tidak lagi berbahasa Inggris.
- Teks baru yang dirakit dari potongan literal bisa tetap bercampur; kirim screenshot bila ada.
