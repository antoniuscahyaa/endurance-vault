Google Sans bersifat proprietary (tidak boleh dibundel sembarangan). Jika Anda punya lisensinya,
taruh file berikut di folder ini agar dipakai di dalam aplikasi pada perangkat non-Pixel:

  GoogleSans-Regular.ttf
  GoogleSans-Medium.ttf   (opsional)
  GoogleSans-Bold.ttf

Tanpa file ini, aplikasi memakai font sistem "google-sans" bila perangkat punya (Pixel dan beberapa ROM),
atau jatuh kembali ke Roboto.
