package com.endurancevault.app.widget

import android.app.PendingIntent
import android.app.WallpaperManager
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Build
import android.view.View
import android.widget.RemoteViews
import androidx.core.graphics.ColorUtils
import com.endurancevault.app.MainActivity
import com.endurancevault.app.R
import com.endurancevault.app.domain.Wx
import com.endurancevault.app.domain.WxKind
import com.endurancevault.app.ui.i18n.AppLang
import com.endurancevault.app.ui.i18n.Lang
import com.endurancevault.app.ui.screens.shortPlaceName
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.floor
import kotlin.math.roundToInt

/** Menyusun RemoteViews widget: hari + tanggal, lokasi + cuaca, divider, sesi hari ini (jadwal atau saran). */
object GlanceWidgetRenderer {
    private const val WEATHER_MAX_AGE_MS = 6 * 60 * 60_000L
    private const val ALERT_MAX_AGE_MS = 90 * 60_000L

    fun updateAll(ctx: Context) {
        val app = ctx.applicationContext
        val mgr = AppWidgetManager.getInstance(app)
        val ids = mgr.getAppWidgetIds(ComponentName(app, GlanceWidgetProvider::class.java))
        if (ids.isEmpty()) return
        mgr.updateAppWidget(ids, build(app))
    }

    private class Line(val icon: Int, val title: String, val meta: String, val outdoor: Boolean)

    fun build(ctx: Context): RemoteViews {
        Lang.load(ctx) // widget bisa digambar tanpa Activity (worker/receiver), jadi muat bahasa pilihan dulu
        val rv = RemoteViews(ctx.packageName, R.layout.ev_widget_glance)
        val now = System.currentTimeMillis()
        val today = LocalDate.now()

        rv.setTextViewText(R.id.ev_w_date, today.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", locale(ctx))))
        rv.setTextViewText(R.id.ev_w_place, placeLabel(ctx))

        val wx = GlanceWidgetStore.loadWeather(ctx)?.takeIf { (now - it.fetchedAtMs) in 0 until WEATHER_MAX_AGE_MS }
        if (wx != null) {
            val cond = Wx.label(wx.code).takeIf { it != "–" }?.let { Lang.tr(it) }.orEmpty()
            rv.setTextViewText(R.id.ev_w_temp, "${wx.temp.roundToInt()}° $cond".trim())
            val icon = weatherIcon(wx.code, wx.night)
            if (icon != null) { rv.setImageViewResource(R.id.ev_w_wx_icon, icon); rv.setViewVisibility(R.id.ev_w_wx_icon, View.VISIBLE) }
            else rv.setViewVisibility(R.id.ev_w_wx_icon, View.GONE)
            rv.setViewVisibility(R.id.ev_w_wx_group, View.VISIBLE)
        } else rv.setViewVisibility(R.id.ev_w_wx_group, View.GONE)

        val line = sessionLine(sessionFor(ctx, today))
        rv.setImageViewResource(R.id.ev_w_sess_icon, line.icon)
        rv.setTextViewText(R.id.ev_w_sess_title, line.title)
        if (line.meta.isBlank()) rv.setViewVisibility(R.id.ev_w_sess_meta, View.GONE)
        else { rv.setTextViewText(R.id.ev_w_sess_meta, line.meta); rv.setViewVisibility(R.id.ev_w_sess_meta, View.VISIBLE) }

        // Peringatan cuaca hanya untuk sesi yang masih akan dijalani, dan hanya bila data cuaca masih segar.
        val warn = if (line.outdoor && wx != null && (now - wx.fetchedAtMs) in 0 until ALERT_MAX_AGE_MS) alertText(wx.alert) else null
        if (warn != null) { rv.setTextViewText(R.id.ev_w_warn, warn); rv.setViewVisibility(R.id.ev_w_warn_row, View.VISIBLE) }
        else rv.setViewVisibility(R.id.ev_w_warn_row, View.GONE)

        applyPalette(ctx, rv)

        // Ketukan: tanggal/cuaca -> Hari ini; baris sesi dan peringatan -> Jadwal bila sesi dari rencana, selain itu Hari ini.
        val session = sessionFor(ctx, today)
        val sessionRoute = if (session?.source == "plan") "schedule" else "today"
        val whole = openIntent(ctx, 0, "today")
        rv.setOnClickPendingIntent(R.id.ev_w_root, whole)
        rv.setOnClickPendingIntent(R.id.ev_w_date, whole)
        rv.setOnClickPendingIntent(R.id.ev_w_info_row, whole)
        val sessPi = openIntent(ctx, 1, sessionRoute)
        rv.setOnClickPendingIntent(R.id.ev_w_sess_row, sessPi)
        rv.setOnClickPendingIntent(R.id.ev_w_warn_row, sessPi)
        return rv
    }

    private fun openIntent(ctx: Context, code: Int, route: String): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
            .setAction(WidgetNav.ACTION)
            .putExtra(WidgetNav.EXTRA_ROUTE, route)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        return PendingIntent.getActivity(ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private class Palette(val primary: Int, val secondary: Int, val divider: Int, val warn: Int)

    private val DARK_TEXT = Palette(0xFF1C1B1F.toInt(), 0xFF3C4043.toInt(), 0x66000000, 0xFF8A4B00.toInt())
    private val LIGHT_TEXT = Palette(0xFFFFFFFF.toInt(), 0xFFE3E6EA.toInt(), 0x66FFFFFF, 0xFFFFC266.toInt())

    /**
     * Widget transparan, jadi warna teks harus mengikuti wallpaper (bukan tema sistem): wallpaper gelap/biru -> teks putih,
     * wallpaper terang -> teks gelap. Tanpa info wallpaper, jatuh kembali ke tema sistem.
     */
    private fun wantsDarkText(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            val c = runCatching { WallpaperManager.getInstance(ctx).getWallpaperColors(WallpaperManager.FLAG_SYSTEM) }.getOrNull()
            if (c != null) {
                return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    (c.colorHints and android.app.WallpaperColors.HINT_SUPPORTS_DARK_TEXT) != 0
                } else {
                    ColorUtils.calculateLuminance(c.primaryColor.toArgb()) > 0.5
                }
            }
        }
        val night = ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES
        return !night
    }

    private fun paletteFor(ctx: Context): Palette = when (WidgetTextPrefs.mode(ctx)) {
        WidgetTextPrefs.Mode.LIGHT -> LIGHT_TEXT
        WidgetTextPrefs.Mode.DARK -> DARK_TEXT
        WidgetTextPrefs.Mode.CUSTOM -> {
            val c = WidgetTextPrefs.customColor(ctx) or 0xFF000000.toInt()
            // Peringatan tetap oranye; pilih versi gelap/terang menurut kecerahan warna teks yang dipilih.
            val warn = if (ColorUtils.calculateLuminance(c) > 0.5) LIGHT_TEXT.warn else DARK_TEXT.warn
            Palette(c, ColorUtils.setAlphaComponent(c, 0xE0), ColorUtils.setAlphaComponent(c, 0x66), warn)
        }
        WidgetTextPrefs.Mode.AUTO -> if (wantsDarkText(ctx)) DARK_TEXT else LIGHT_TEXT
    }

    private fun applyPalette(ctx: Context, rv: RemoteViews) {
        val p = paletteFor(ctx)
        for (id in intArrayOf(R.id.ev_w_date, R.id.ev_w_sess_title)) rv.setTextColor(id, p.primary)
        for (id in intArrayOf(R.id.ev_w_place, R.id.ev_w_dot, R.id.ev_w_temp, R.id.ev_w_sess_meta)) rv.setTextColor(id, p.secondary)
        rv.setTextColor(R.id.ev_w_warn, p.warn)
        rv.setInt(R.id.ev_w_sess_icon, "setColorFilter", p.primary)
        for (id in intArrayOf(R.id.ev_w_pin_icon, R.id.ev_w_wx_icon)) rv.setInt(id, "setColorFilter", p.secondary)
        rv.setInt(R.id.ev_w_warn_icon, "setColorFilter", p.warn)
        rv.setInt(R.id.ev_w_divider, "setBackgroundColor", p.divider)
    }

    /** Sesi untuk hari ini: data terbaru dari layar Hari ini, atau (setelah lewat tengah malam) dari rencana yang sudah disimpan. */
    private fun sessionFor(ctx: Context, today: LocalDate): WidgetSession? {
        val (s, upcoming) = GlanceWidgetStore.loadSession(ctx) ?: return null
        val iso = today.toString()
        if (s.dateIso == iso) return s
        val u = upcoming.firstOrNull { it.dateIso == iso } ?: return null
        return WidgetSession(iso, "plan", if (u.rest) "rest" else "todo", u.title, u.km, null, u.hrLimit, false)
    }

    /** Teks widget mengikuti bahasa aplikasi (id/en). */
    private fun t(id: String, en: String) = if (Lang.current == AppLang.EN) en else id

    private fun sessionLine(s: WidgetSession?): Line = when {
        s == null -> Line(R.drawable.ic_widget_bulb, t("Buka aplikasi untuk saran hari ini", "Open the app for today's suggestion"), "", false)
        s.state == "rest" -> Line(R.drawable.ic_widget_bed, t("Hari istirahat", "Rest day"), "· " + label(s), false)
        s.state == "done" -> Line(
            R.drawable.ic_widget_check, Lang.tr(s.title.ifBlank { "Sesi selesai" }),
            if (s.source == "rec") "" else "· " + Lang.tr("Tercatat"), false,
        )
        s.state == "none" -> Line(R.drawable.ic_widget_run, Lang.tr(s.title.ifBlank { "Tidak ada sesi terjadwal" }), "", false)
        else -> {
            val parts = ArrayList<String>()
            parts += label(s)
            if (s.km > 0) parts += fmtKm(s.km) + " km" else s.minutes?.let { parts += "≈ $it " + t("mnt", "min") }
            s.hrLimit?.let { parts += "HR ≤ $it" }
            Line(
                if (s.source == "rec") R.drawable.ic_widget_bulb else R.drawable.ic_widget_run,
                Lang.tr(s.title.ifBlank { t("Latihan", "Workout") }), "· " + parts.joinToString(" · "), true,
            )
        }
    }

    private fun label(s: WidgetSession) =
        if (s.source == "rec") t("Saran", "Suggested") else t("Jadwal", "Planned")

    private fun alertText(key: String): String? = when (key) {
        "storm" -> t("Badai petir, pertimbangkan indoor", "Thunderstorm, consider training indoors")
        "rain" -> t("Hujan, pertimbangkan indoor", "Rain, consider training indoors")
        "heat" -> t("Panas, hindari tengah hari", "Hot, avoid midday")
        else -> null
    }

    private fun fmtKm(km: Double): String =
        if (km == floor(km)) km.toInt().toString() else String.format(Lang.locale, "%.1f", km)

    private fun weatherIcon(code: Int, night: Boolean): Int? = when (Wx.kind(code)) {
        WxKind.CLEAR -> if (night) R.drawable.ic_wx_moon else R.drawable.ic_wx_clear
        WxKind.PARTLY -> R.drawable.ic_wx_partly
        WxKind.CLOUD -> R.drawable.ic_wx_cloud
        WxKind.FOG -> R.drawable.ic_wx_fog
        WxKind.RAIN -> R.drawable.ic_wx_rain
        WxKind.STORM -> R.drawable.ic_wx_storm
        WxKind.SNOW -> R.drawable.ic_wx_snow
        WxKind.NONE -> null
    }

    /** Lokasi yang dipakai kartu cuaca di aplikasi (prefs weather_loc), dipendekkan jadi nama sebelum koma. */
    private fun placeLabel(ctx: Context): String {
        val p = ctx.getSharedPreferences("weather_loc", Context.MODE_PRIVATE)
        val place = p.getString("place", null) ?: "Ungaran, Indonesia"
        val gps = place.isBlank() || place.trim().equals("Lokasi saya", true) || place.trim().equals("My location", true)
        val label = if (gps) p.getString("pn_n", null) ?: "Lokasi saya" else place
        return shortPlaceName(label) ?: Lang.tr("Lokasi saya")
    }

    private fun locale(ctx: Context): Locale =
        if (ctx.getSharedPreferences("app_language", Context.MODE_PRIVATE).getString("lang", null) == "en") Locale.US else Locale("id", "ID")
}
