package com.endurancevault.app.widget

import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Tujuan navigasi dari ketukan widget. Dibaca MainActivity, lalu dijalankan AppRoot sekali. */
object WidgetNav {
    const val ACTION = "com.endurancevault.app.OPEN_FROM_WIDGET"
    const val EXTRA_ROUTE = "ev_route"

    /** Rute tab tujuan, atau null bila tidak ada. */
    var pending by mutableStateOf<String?>(null)

    fun consume(intent: Intent?) {
        if (intent?.action == ACTION) {
            pending = intent.getStringExtra(EXTRA_ROUTE)
            intent.action = null // jangan diproses ulang saat Activity dibuat ulang
        }
    }
}
