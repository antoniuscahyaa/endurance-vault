package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.i18n.Text
import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import com.endurancevault.app.ui.floating.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.domain.ActDetail
import com.endurancevault.app.domain.Js
import com.endurancevault.app.domain.PeriodData
import com.endurancevault.app.domain.SwDay
import com.endurancevault.app.domain.SwWeek
import java.time.LocalDate
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.StickerExtras
import com.endurancevault.app.domain.StickerExtrasCalc
import com.endurancevault.app.domain.StickerWeeks
import com.endurancevault.app.domain.StickerModel
import com.endurancevault.app.domain.StickerPrefs
import com.endurancevault.app.domain.Stickers
import com.endurancevault.app.domain.Zones
import com.endurancevault.app.ui.UiState
import com.endurancevault.app.ui.sticker.PhotoPlan
import com.endurancevault.app.ui.sticker.StickerFontStore
import com.endurancevault.app.ui.sticker.StickerFonts
import com.endurancevault.app.ui.sticker.StickerIo
import com.endurancevault.app.ui.sticker.StickerPalettes
import com.endurancevault.app.ui.sticker.StickerPrefsStore
import com.endurancevault.app.ui.sticker.StickerRenderer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Stiker data (port `10c-stiker-data.js`): PNG transparan satu data per gambar untuk ditempel di foto.
 * Dibuka dari menu detail aktivitas. Belum ada: TE dan Training load, Vs PR, Vs rute serupa (lihat CHANGELOG).
 */
@OptIn(ExperimentalLayoutApi::class, ExperimentalFoundationApi::class)
/** Hasil gambar untuk model [m]; [done] false selama penggambaran berjalan. */
private class StickerSheet(val m: StickerModel?, val map: Map<String, Bitmap>, val done: Boolean)

@Composable
fun StickerScreen(state: UiState, id: Long, load: suspend (ActivityEntity) -> ActDetail?, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val store = remember { StickerPrefsStore(ctx.applicationContext) }
    var prefs by remember { mutableStateOf(store.load()) }
    fun update(p: StickerPrefs) { prefs = p.sanitized(); store.save(prefs) }
    var msg by remember { mutableStateOf("") }
    var photo by remember { mutableStateOf<Bitmap?>(null) }
    var plan by remember { mutableStateOf<PhotoPlan?>(null) }
    var guide by remember { mutableStateOf<Pair<Double?, Double?>>(null to null) }
    val choices = remember(state.activities) {
        state.activities.filter { it.km > 0 }.sortedWith(compareByDescending<ActivityEntity> { it.dateIso }.thenByDescending { it.id })
    }
    var selId by remember { mutableStateOf(id) }
    val e = choices.firstOrNull { it.id == selId } ?: choices.firstOrNull()
    val fontStore = remember { StickerFontStore(ctx.applicationContext) }
    var fontList by remember { mutableStateOf(fontStore.list()) }
    var importSlot by remember { mutableStateOf("num") }
    var inkDlg by remember { mutableStateOf(false) }
    val fontPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val r = withContext(Dispatchers.IO) { fontStore.import(uri) }
            r.onSuccess { name ->
                fontList = fontStore.list()
                update(if (importSlot == "num") prefs.copy(fontNum = name) else prefs.copy(fontBody = name))
                msg = "Huruf $name diimpor."
            }.onFailure { msg = it.message ?: "Impor huruf gagal." }
        }
    }
    val fonts = remember(prefs.fontNum, prefs.fontBody, fontList) {
        StickerFonts(fontStore.typeface(prefs.fontNum), fontStore.typeface(prefs.fontBody))
    }

    Column(
        Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹ Kembali") }
            Text("Stiker data", style = MaterialTheme.typography.titleLarge)
        }
        if (e == null) { Text("Belum ada aktivitas dengan jarak, jadi belum ada yang bisa dibuat menjadi stiker."); return@Column }
        // produceState tidak mengosongkan nilai saat kunci berubah, jadi hasil dicap dengan id sesi dan hasil sesi lain dibuang.
        val loaded by produceState<Pair<Long?, ActDetail?>>(null to null, e.id, e.detailFile, e.km, e.durationSec, e.type) { value = e.id to load(e) }
        if (loaded.first != e.id) { CircularProgressIndicator(); return@Column }
        val zc = remember(state.settings) { Zones.cuts(state.settings) }
        val hist = state.hrHistByActivity[e.id].orEmpty()
        val weekInput = remember(state.plan, state.activities, state.done, state.hrHistByActivity, state.detailsByActivity) {
            StickerWeeks.inputOf((state.plan as? PlanOutcome.Ok)?.weeks.orEmpty(), state.activities, state.done) { a ->
                state.hrHistByActivity[a.id] ?: state.detailsByActivity[a.id]?.hrHist
            }
        }
        val periods = remember(e, state.activities, state.plan) {
            val weeks = (state.plan as? PlanOutcome.Ok)?.weeks.orEmpty().map { w -> SwWeek(w.i, w.days.map { SwDay(it.date, it.kind, it.km) }, w.km) }
            runCatching { LocalDate.parse(e.dateIso.take(10)) }.getOrNull()?.let { PeriodData.of(state.activities, e, it, weeks) }
        }
        val extrasState by produceState<Pair<Long?, StickerExtras?>>(
            null to null, e.id, loaded, state.activities, state.detailsByActivity, state.settings, state.daily, state.plan, state.hrHistByActivity,
        ) {
            val det = loaded.second
            val r = withContext(Dispatchers.Default) {
                runCatching {
                    val details = if (det != null) state.detailsByActivity + (e.id to det) else state.detailsByActivity
                    StickerExtrasCalc.build(e, state.activities, details, state.settings, state.daily, state.plan, state.hrHistByActivity)
                }.getOrNull()
            }
            value = e.id to r
        }
        val extras = if (extrasState.first == e.id) extrasState.second else null
        val m = remember(e, loaded, zc, hist, weekInput, periods, extras) { Stickers.forActivity(e, loaded.second, hist, zc, weekInput, periods, extras) }
        if (m == null) { Text("Sesi ini tidak punya jarak, jadi belum ada yang bisa dibuat menjadi stiker."); return@Column }

        val ids = Stickers.allIds(m, prefs)
        var scopeSel by remember { mutableStateOf("day") }
        val shown = ids.filter { Stickers.scopeOf(it) == scopeSel }
        // Hanya stiker yang mungkin dipakai yang digambar: kategori yang tampil, paket bawaan, dan isi foto.
        val need = shown.toSet() + Stickers.packSel(ids, prefs) + plan?.items.orEmpty().map { it.id }
        val sheetState by produceState(StickerSheet(null, emptyMap(), false), m, prefs, fonts, need) {
            value = StickerSheet(m, if (value.m === m) value.map else emptyMap(), false)
            val r = withContext(Dispatchers.Default) { StickerRenderer.renderAll(m, prefs, fonts, need) { isActive } }
            value = StickerSheet(m, r, true)
        }
        val sheet: Map<String, Bitmap> = if (sheetState.m === m) sheetState.map else emptyMap()
        val sheetDone = sheetState.m === m && sheetState.done
        val pal = StickerPalettes.of(prefs)
        val bg = Color(pal.bg)
        // Sesi lain bisa tidak punya stiker yang sama: isi foto yang id-nya hilang diganti stiker pertama yang tersedia.
        LaunchedEffect(ids) {
            val q = plan
            if (q != null && ids.isNotEmpty() && q.items.any { it.id !in ids }) {
                plan = q.copy(items = q.items.map { if (it.id in ids) it else it.copy(id = ids.first()) })
                msg = "Stiker di foto disesuaikan dengan sesi ini."
            }
        }

        fun saveIds(list: List<String>, seq: Boolean) {
            if (!sheetDone) { msg = "Stiker belum siap, coba lagi sebentar."; return }
            val items = list.filter { sheet[it] != null }
            if (items.isEmpty()) { msg = "Stiker belum siap, coba lagi sebentar."; return }
            msg = "Menyimpan ${items.size} file…"
            scope.launch {
                val results = withContext(Dispatchers.IO) {
                    items.mapIndexed { i, sid -> StickerIo.saveToGallery(ctx, Stickers.fileName(sid, m, if (seq) i + 1 else 0), sheet.getValue(sid)) }
                }
                val ok = results.count { it.isSuccess }
                val where = results.firstOrNull { it.isSuccess }?.getOrNull()
                msg = if (ok == items.size) "Tersimpan $ok file ke $where. Transparansi tetap utuh."
                else "Menyimpan gagal (${results.firstOrNull { it.isFailure }?.exceptionOrNull()?.message ?: "galat tak dikenal"}). Coba lagi."
            }
        }

        // ---- viewer terpaku: geser kiri-kanan antar stiker; pengaturan di bawahnya menyesuaikan stiker yang tampil ----
        val pager = rememberPagerState(pageCount = { shown.size })
        var curId by remember { mutableStateOf<String?>(null) }
        val shownNow by rememberUpdatedState(shown)
        LaunchedEffect(pager) { snapshotFlow { pager.settledPage }.collect { curId = shownNow.getOrNull(it) } }
        LaunchedEffect(shown) {
            val i = shown.indexOf(curId)
            if (i >= 0) { if (i != pager.currentPage) pager.scrollToPage(i) } else if (shown.isNotEmpty()) pager.scrollToPage(0)
        }
        val curSid = shown.getOrNull(pager.currentPage)
        val curSec = secOf(curSid)

        var pendingId by remember { mutableStateOf<String?>(null) }
        var vbg by remember { mutableStateOf("palet") }
        var nameDlg by remember { mutableStateOf(false) }
        val photoReq = remember { BringIntoViewRequester() }
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) scope.launch {
                val b = withContext(Dispatchers.IO) { StickerIo.decodePhoto(ctx, uri) }
                if (b == null) msg = "Foto tidak bisa dibuka."
                else {
                    photo = b
                    val first = pendingId; pendingId = null
                    val base = plan?.copy(nw = b.width, nh = b.height) ?: PhotoPlan(b.width, b.height)
                    plan = if (base.items.isEmpty()) StickerIo.addSticker(base, ids, first) else base
                    msg = if (first != null) "Foto dipilih, stiker ditempel. Atur posisinya di Pratinjau di foto." else ""
                    if (first != null) scope.launch { kotlinx.coroutines.delay(200); photoReq.bringIntoView() }
                }
            }
        }
        /** Tempel stiker yang tampil ke foto; bila belum ada foto, buka galeri dulu. */
        fun pasteToPhoto(sid: String) {
            val q = plan
            if (q == null || photo == null) { pendingId = sid; picker.launch("image/*"); return }
            if (q.items.size >= Stickers.MAX_PHOTO_STICKERS) { msg = "Foto sudah berisi ${Stickers.MAX_PHOTO_STICKERS} stiker. Hapus satu dulu di Pratinjau di foto."; return }
            plan = StickerIo.addSticker(q, ids, sid)
            msg = "Ditempel ke foto (${q.items.size + 1}/${Stickers.MAX_PHOTO_STICKERS}). Atur posisinya di Pratinjau di foto."
            scope.launch { kotlinx.coroutines.delay(150); photoReq.bringIntoView() }
        }

        var general by remember { mutableStateOf(false) }
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .5f)).clickable { general = !general }.padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
        ) {
            Text("Pengaturan umum", style = MaterialTheme.typography.titleSmall)
            Text(if (general) "▾" else "▸", style = MaterialTheme.typography.titleMedium)
        }
        if (general) Column(
            Modifier.fillMaxWidth().heightIn(max = 300.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
        SLabel("Preset gaya (warna, aksen, panel, ukuran, huruf, gaya angka)")
        val activePre = prefs.presets.firstOrNull { prefs.matches(it) }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            prefs.presets.forEach { pr -> SChip(pr.name, pr == activePre) { update(prefs.withPreset(pr)) } }
            if (prefs.presets.size < 8) SChip("+ Simpan gaya ini", false) { nameDlg = true }
            if (activePre != null) SChip("Hapus ${activePre.name}", false) { update(prefs.copy(presets = prefs.presets - activePre)) }
        }
        SLabel("Sesi")
        SessionPicker(choices, e) { selId = it; msg = "" }

        // ---- tampilan umum ----
        SLabel("Warna teks, berlaku untuk semua stiker")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("w" to "Putih", "k" to "Hitam", "l" to "Lime").forEach { (k, t) ->
                SChip(t, prefs.inkCustom.isEmpty() && prefs.ink == k) { update(prefs.copy(ink = k, inkCustom = "")) }
            }
            SChip(if (prefs.inkCustom.isNotEmpty()) "Kustom ${prefs.inkCustom}" else "Kustom…", prefs.inkCustom.isNotEmpty()) { inkDlg = true }
        }
        if (inkDlg) ColorDialog(prefs.inkCustom, onDismiss = { inkDlg = false }) { update(prefs.copy(inkCustom = it)); inkDlg = false }
        if (nameDlg) NameDialog(onDismiss = { nameDlg = false }) { n ->
            update(prefs.copy(presets = (prefs.presets.filter { it.name != n } + prefs.asPreset(n)).takeLast(8))); nameDlg = false
        }
        SLabel("Warna aksen, untuk semua stiker (sorotan, titik awal rute, bar target)")
        ColorChoice(prefs.accent) { update(prefs.copy(accent = it)) }
        SLabel("Panel latar di belakang stiker, agar terbaca di foto terang")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("off" to "Mati", "soft" to "Tipis", "strong" to "Tebal").forEach { (k, t) -> SChip(t, prefs.panel == k) { update(prefs.copy(panel = k)) } }
        }
        SLabel("Gaya angka dan judul")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("std" to "Standar", "sport" to "Miring tebal").forEach { (k, t) -> SChip(t, prefs.numStyle == k) { update(prefs.copy(numStyle = k)) } }
        }

        var sizeDraft by remember(prefs.scale) { mutableStateOf(prefs.scale.toFloat()) }
        SLabel("Ukuran stiker: ${sizeDraft.roundToInt()}% (100% = standar; sisi terpanjang PNG dibatasi 4096 px)")
        Slider(
            value = sizeDraft, valueRange = Stickers.MIN_SCALE.toFloat()..Stickers.MAX_SCALE.toFloat(),
            onValueChange = { sizeDraft = it }, onValueChangeFinished = { update(prefs.copy(scale = sizeDraft.roundToInt())) },
        )
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(50, 75, 100, 150, 200).forEach { n -> SChip("$n%", prefs.scale == n) { update(prefs.copy(scale = n)) } }
        }
        SLabel("Huruf angka dan judul (huruf kustom dari berkas .ttf atau .otf)")
        FontChoice(
            prefs.fontNum, fontList, fontStore::label,
            onPick = { update(prefs.copy(fontNum = it)) }, onImport = { importSlot = "num"; fontPicker.launch(arrayOf("*/*")) },
            onDelete = { n -> fontStore.delete(n); fontList = fontStore.list(); update(prefs.copy(fontNum = if (prefs.fontNum == n) "" else prefs.fontNum, fontBody = if (prefs.fontBody == n) "" else prefs.fontBody)) },
        )
        SLabel("Huruf teks isi")
        FontChoice(
            prefs.fontBody, fontList, fontStore::label,
            onPick = { update(prefs.copy(fontBody = it)) }, onImport = { importSlot = "body"; fontPicker.launch(arrayOf("*/*")) },
            onDelete = { n -> fontStore.delete(n); fontList = fontStore.list(); update(prefs.copy(fontNum = if (prefs.fontNum == n) "" else prefs.fontNum, fontBody = if (prefs.fontBody == n) "" else prefs.fontBody)) },
        )

        }

        StickerViewer(
            pager, shown, sheet, bg, vbg, photo, scopeSel, m, msg, sheetDone,
            onScope = { scopeSel = it },
            onBgMode = { vbg = when (vbg) { "palet" -> "gelap"; "gelap" -> "terang"; "terang" -> if (photo != null) "foto" else "palet"; else -> "palet" } },
            onSave = { sid -> saveIds(listOf(sid), false) },
            onPaste = { sid -> pasteToPhoto(sid) },
        )

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // ---- baris angka ----
        if (curSec == "angka") SSection("Baris angka", null) {
            val ks = m.keys(prefs.order)
            SLabel("Data, urutan sesuai ketukan")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Stickers.NUM_KEYS.filter { m.num(it) != null }.forEach { k ->
                    val i = ks.indexOf(k)
                    SChip((if (i > -1) "${i + 1}. " else "") + m.num(k)!!.label, i > -1) {
                        update(prefs.copy(order = if (i > -1) prefs.order - k else prefs.order + k))
                    }
                }
            }
            if (m.iv != null) {
                SLabel("Dari analisis interval")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stickers.IV_KEYS.filter { m.num(it) != null }.forEach { k ->
                        val i = ks.indexOf(k)
                        SChip((if (i > -1) "${i + 1}. " else "") + m.num(k)!!.label, i > -1) {
                            update(prefs.copy(order = if (i > -1) prefs.order - k else prefs.order + k))
                        }
                    }
                }
            }
            ColsChips(prefs.cols) { update(prefs.copy(cols = it)) }
            SLabel("Format")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SChip("Satu kartu", prefs.mode == "gabung") { update(prefs.copy(mode = "gabung")) }
                SChip("Satu per satu", prefs.mode == "pisah") { update(prefs.copy(mode = "pisah")) }
            }
            if (ks.isEmpty()) Text("Pilih minimal satu data.", style = MaterialTheme.typography.bodySmall)
        }

        // ---- template peta ----
        if (curSec == "peta") SSection("Template peta", null) {
            if (!m.hasRoute) Text("Sesi ini tidak punya data rute GPS.", style = MaterialTheme.typography.bodySmall)
            else {
                SLabel("Data di peta")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stickers.MAP_KEYS.filter { m.num(it) != null }.forEach { k ->
                        val lab = when (k) { "pace" -> "Pace"; "jarak" -> "Jarak"; "elev" -> "Elevasi naik"; "hr" -> "HR"; else -> "Total waktu" }
                        SChip(lab, k in prefs.mapFields) { update(prefs.copy(mapFields = if (k in prefs.mapFields) prefs.mapFields - k else prefs.mapFields + k)) }
                    }
                }
                SLabel("Tata letak")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SChip("Data di bawah", prefs.lay == "bawah") { update(prefs.copy(lay = "bawah")) }
                    SChip("Data di samping", prefs.lay == "kiri") { update(prefs.copy(lay = "kiri")) }
                }
            }
        }

        // ---- angka minggu ----
        if (curSec == "minggu") SSection("Angka minggu", null) {
            if (m.wkCtx == null) Text(
                if (m.bike) "Sepeda tidak masuk ringkasan minggu." else "Sesi ini tidak masuk minggu rencana mana pun, jadi belum ada angka minggu.",
                style = MaterialTheme.typography.bodySmall,
            ) else {
                val wks = m.keysWk(prefs.wk)
                SLabel("Data minggu ini, urutan sesuai ketukan")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stickers.WK_KEYS.filter { m.numWk(it) != null }.forEach { k ->
                        val i = wks.indexOf(k)
                        SChip((if (i > -1) "${i + 1}. " else "") + m.numWk(k)!!.label, i > -1) {
                            update(prefs.copy(wk = if (i > -1) prefs.wk - k else prefs.wk + k))
                        }
                    }
                }
                ColsChips(prefs.cols) { update(prefs.copy(cols = it)) }
                if (wks.isEmpty()) Text("Pilih minimal satu data.", style = MaterialTheme.typography.bodySmall)
            }
        }

        // ---- statistik periode ----
        if (curSec == "periode") SSection("Statistik periode", "Total harian, mingguan, atau bulanan di sekitar sesi ini. Tiap item satu PNG yang bisa ditempel di foto dan dipadukan dengan stiker lain.") {
            val cp = Stickers.perOfId(curSid ?: "") ?: "week"
            val pks = m.keysPer(prefs.pf, cp)
            SLabel("Data angka periode, urutan sesuai ketukan")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Stickers.PERIOD_KEYS.filter { m.numPer(it, cp) != null }.forEach { k ->
                    val i = pks.indexOf(k)
                    SChip((if (i > -1) "${i + 1}. " else "") + m.numPer(k, cp)!!.label, i > -1) {
                        update(prefs.copy(pf = if (i > -1) prefs.pf - k else prefs.pf + k))
                    }
                }
            }
            if (Stickers.kindOfId(curSid ?: "") == "angka") ColsChips(prefs.cols) { update(prefs.copy(cols = it)) }
            if (pks.isEmpty()) Text("Pilih minimal satu data.", style = MaterialTheme.typography.bodySmall)
            Stickers.PERIOD_KINDS.filter { it.first != "angka" && (cp == "month" || it.first !in setOf("pekan", "rekor")) }.forEach { (kind, title) ->
                val why = m.graphWhy(Stickers.periodId(cp, kind))
                if (why != null) Text("$title: $why", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        // ---- bar dan grafik: pengaturan hanya untuk stiker yang memakainya ----
        if (curSec == "grafik") SSection(Stickers.idLabel(curSid ?: "", m), null) {
            val sid = curSid ?: ""
            when (sid) {
                "pace-segmen" -> {
                    SLabel("Bar pace per segmen")
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SChip("Sorot tercepat dan rata-rata", prefs.highlight) { update(prefs.copy(highlight = !prefs.highlight)) }
                        SChip("Garis HR", prefs.hrLine) { update(prefs.copy(hrLine = !prefs.hrLine)) }
                    }
                }
                "zona-hr-sesi", "zona-hr-tumpuk", "zona-hr-minggu" -> {
                    SLabel("Zona HR tampil sebagai")
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("both" to "Durasi dan persen", "dur" to "Durasi", "pct" to "Persen").forEach { (k, t) -> SChip(t, prefs.hz == k) { update(prefs.copy(hz = k)) } }
                    }
                }
                "peta-warna" -> {
                    SLabel("Warna garis rute menurut")
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SChip("Pace", prefs.mapColor == "pace") { update(prefs.copy(mapColor = "pace")) }
                        SChip("HR", prefs.mapColor == "hr") { update(prefs.copy(mapColor = "hr")) }
                    }
                }
                "cuaca", "best-effort" -> ColsChips(prefs.cols) { update(prefs.copy(cols = it)) }
                "tren-pace" -> {
                    SLabel("Tren pace: jumlah minggu")
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(8, 6, 4).forEach { n -> SChip("$n minggu", prefs.trendWeeks == n) { update(prefs.copy(trendWeeks = n)) } }
                    }
                }
            }
            if (sid == "zona-hr-minggu" || sid == "target-minggu") {
                SLabel("Warna bar mingguan (zona HR minggu dan target minggu)")
                ColorChoice(prefs.weekColor) { update(prefs.copy(weekColor = it)) }
            }
            if (sid !in setOf("pace-segmen", "zona-hr-sesi", "zona-hr-tumpuk", "zona-hr-minggu", "tren-pace", "target-minggu", "peta-warna", "cuaca", "best-effort")) {
                Text("Stiker ini tidak punya pengaturan khusus. Pengaturan umum ada di bagian atas.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        // ---- pratinjau di foto ----
        Box(Modifier.bringIntoViewRequester(photoReq)) {
        SSection("Pratinjau di foto", "Pilih foto dari galeri, atur rasio, tempel sampai ${Stickers.MAX_PHOTO_STICKERS} stiker, seret dan ubah ukurannya, lalu simpan atau bagikan hasilnya sebagai PNG. Foto asli tidak diubah.") {
            val q = plan; val ph = photo
            if (q == null || ph == null || q.items.isEmpty()) {
                OutlinedButton(onClick = { picker.launch("image/*") }) { Text("Pilih foto") }
                if (ids.isEmpty()) Text("Belum ada stiker yang tersedia: pilih minimal satu angka di Baris angka.", style = MaterialTheme.typography.bodySmall)
            } else {
                val g = StickerIo.geom(q)
                val sel = q.items.firstOrNull { it.u == q.sel } ?: q.items.first()
                val planNow = rememberUpdatedState(plan)
                fun upd(u: Int, f: (com.endurancevault.app.ui.sticker.PhotoSticker) -> com.endurancevault.app.ui.sticker.PhotoSticker) {
                    plan = planNow.value?.let { p -> p.copy(items = p.items.map { if (it.u == u) f(it) else it }) }
                }
                SLabel("Rasio hasil")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("asli" to "Asli", "9:16" to "9:16 Story", "4:5" to "4:5", "1:1" to "1:1").forEach { (k, t) -> SChip(t, q.ar == k) { plan = q.copy(ar = k) } }
                }
                if (g.free) {
                    SLabel("Geser bingkai pada foto")
                    Slider(value = q.co.toFloat(), onValueChange = { plan = q.copy(co = it.toDouble()) })
                }
                val dens = LocalDensity.current
                BoxWithConstraints(Modifier.fillMaxWidth().aspectRatio(g.r.toFloat()).clip(RoundedCornerShape(8.dp)).background(Color.Black)) {
                    val wPx = with(dens) { maxWidth.toPx() }; val hPx = with(dens) { maxHeight.toPx() }
                    val photoImg = remember(ph) { ph.asImageBitmap() }
                    Canvas(Modifier.fillMaxSize()) {
                        drawImage(
                            photoImg, srcOffset = IntOffset(g.sx.roundToInt(), g.sy.roundToInt()), srcSize = IntSize(g.sw.roundToInt(), g.sh.roundToInt()),
                            dstSize = IntSize(size.width.roundToInt(), size.height.roundToInt()),
                        )
                    }
                    q.items.forEach { it ->
                        val bmp = sheet[it.id] ?: return@forEach
                        key(it.u) {
                            val img = remember(bmp) { bmp.asImageBitmap() }
                            val wP = it.s / 100 * wPx; val hP = wP * bmp.height / bmp.width
                            val u = it.u
                            Image(
                                img, contentDescription = null, contentScale = ContentScale.FillWidth,
                                modifier = Modifier
                                    .offset { IntOffset((it.x / 100 * wPx).roundToInt(), (it.y / 100 * hPx).roundToInt()) }
                                    .width(with(dens) { wP.toFloat().toDp() })
                                    .then(if (it.u == q.sel && q.items.size > 1) Modifier.border(1.5.dp, Color.White.copy(alpha = .8f)) else Modifier)
                                    .pointerInput(u, wPx, hPx) {
                                        var ox = 0.0; var oy = 0.0; var ax = 0f; var ay = 0f
                                        detectDragGestures(
                                            onDragStart = {
                                                val cur = planNow.value?.items?.firstOrNull { s -> s.u == u } ?: return@detectDragGestures
                                                ox = cur.x; oy = cur.y; ax = 0f; ay = 0f
                                                planNow.value?.let { p -> plan = p.copy(sel = u) }
                                            },
                                            onDragEnd = { guide = null to null },
                                            onDragCancel = { guide = null to null },
                                        ) { change, drag ->
                                            change.consume(); ax += drag.x; ay += drag.y
                                            val cur = planNow.value?.items?.firstOrNull { s -> s.u == u } ?: return@detectDragGestures
                                            val w = cur.s; val bmpH = sheet[cur.id]?.let { b -> b.height.toDouble() / b.width } ?: 1.0
                                            val h = cur.s / 100 * wPx * bmpH / hPx * 100
                                            var nx = ox + ax / wPx * 100; var ny = oy + ay / hPx * 100
                                            if (prefs.snap) {
                                                val sn = StickerIo.snap(nx, ny, w, h, wPx.toDouble(), hPx.toDouble())
                                                nx = sn.x; ny = sn.y; guide = sn.gx to sn.gy
                                            } else guide = null to null
                                            nx = max(0.0, min(max(0.0, 100 - w), nx)); ny = max(0.0, min(max(0.0, 100 - h), ny))
                                            upd(u) { s -> s.copy(x = nx, y = ny) }
                                        }
                                    },
                            )
                        }
                    }
                    guide.first?.let { gx -> Box(Modifier.offset { IntOffset((gx / 100 * wPx).roundToInt(), 0) }.width(1.dp).fillMaxHeight().background(Color.Cyan)) }
                    guide.second?.let { gy -> Box(Modifier.offset { IntOffset(0, (gy / 100 * hPx).roundToInt()) }.fillMaxWidth().height(1.dp).background(Color.Cyan)) }
                }
                SLabel("Stiker di foto (${q.items.size}/${Stickers.MAX_PHOTO_STICKERS})")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    q.items.forEachIndexed { i, it -> SChip("${i + 1}. ${Stickers.idLabel(it.id, m)}", it.u == sel.u) { plan = q.copy(sel = it.u) } }
                    if (q.items.size < Stickers.MAX_PHOTO_STICKERS) SChip("+ Tambah", false) { plan = StickerIo.addSticker(q, ids) }
                }
                SLabel("Isi stiker terpilih")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ids.forEach { sid -> SChip(Stickers.idLabel(sid, m), sid == sel.id) { upd(sel.u) { s -> s.copy(id = sid) } } }
                }
                SLabel("Ukuran stiker terpilih")
                Slider(
                    value = sel.s.toFloat(), valueRange = 15f..100f,
                    onValueChange = { v ->
                        val bh = sheet[sel.id]?.let { b -> b.height.toDouble() / b.width } ?: 1.0
                        val hp = v * bh * g.r
                        upd(sel.u) { s -> s.copy(s = v.toDouble(), x = min(s.x, max(0.0, 100 - v.toDouble())), y = min(s.y, max(0.0, 100 - hp))) }
                    },
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SChip("Tempel otomatis", prefs.snap) { update(prefs.copy(snap = !prefs.snap)) }
                    if (q.items.size > 1) SChip("Hapus stiker ini", false) {
                        val left = q.items.filter { it.u != q.sel }; plan = q.copy(items = left, sel = left.last().u)
                    }
                }
                Text("Seret stiker di foto untuk memindahkannya.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { picker.launch("image/*") }) { Text("Ganti foto") }
                    OutlinedButton(onClick = { photo = null; plan = null }) { Text("Hapus foto") }
                }
                val photoName = "trainingplan-foto-" + q.items.first().id.filter { it.isLetterOrDigit() || it == '-' } +
                    (if (q.items.size > 1) "-plus${q.items.size - 1}" else "") + "-${m.date}.png"
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(modifier = Modifier.weight(1f), onClick = {
                        msg = "Menyimpan…"
                        scope.launch {
                            val r = withContext(Dispatchers.IO) { StickerIo.compose(ph, q, sheet)?.let { StickerIo.saveToGallery(ctx, photoName, it) } }
                            msg = when {
                                r == null -> "Foto atau stiker belum siap, coba lagi sebentar."
                                r.isSuccess -> "Foto dan stiker tersimpan ke ${r.getOrNull()}."
                                else -> "Menyimpan gagal (${r.exceptionOrNull()?.message}). Coba lagi."
                            }
                        }
                    }) { Text("Simpan foto dengan stiker") }
                    OutlinedButton(onClick = {
                        scope.launch {
                            val r = withContext(Dispatchers.IO) { StickerIo.compose(ph, q, sheet)?.let { b -> b to photoName } }
                            if (r == null) msg = "Foto atau stiker belum siap, coba lagi sebentar."
                            else StickerIo.share(ctx, r.second, r.first).onFailure { msg = "Berbagi gagal (${it.message}). Coba tombol Simpan." }.onSuccess { msg = "" }
                        }
                    }) { Text("Bagikan") }
                }
            }
        }
        }

        Button(modifier = Modifier.fillMaxWidth(), onClick = { saveIds(shown, false) }, enabled = shown.isNotEmpty()) { Text("Simpan semua di kategori ini") }
        }
    }
}

@Composable
private fun SLabel(t: String) = Text(t, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

@Composable
private fun SChip(t: String, on: Boolean, onClick: () -> Unit) = FilterChip(selected = on, onClick = onClick, label = { Text(t) })

@Composable
private fun SSection(title: String, sub: String?, content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .5f)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        content()
    }
}

/** Seksi pengaturan yang relevan dengan stiker yang sedang tampil di viewer; seksi lain disembunyikan. */
private fun secOf(id: String?): String = when {
    id == null -> ""
    id.startsWith("n-") -> "angka"
    id == "map" -> "peta"
    id == "wk-all" -> "minggu"
    Stickers.perOfId(id) != null -> "periode"
    else -> "grafik"
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ColsChips(cols: Int, onPick: (Int) -> Unit) {
    SLabel("Angka per baris")
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { (2..Stickers.MAX_COLS).forEach { n -> SChip(n.toString(), cols == n) { onPick(n) } } }
}

/**
 * Viewer terpaku di atas layar: pill kategori (Sesi, Minggu, Bulan) dan latar yang bisa diganti (palet, gelap, terang, foto terpilih),
 * geser horizontal antar stiker dalam kategori itu, nama dan nomor halaman, tombol Tempel (ke foto) dan Simpan untuk stiker yang tampil.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun StickerViewer(
    pager: PagerState, ids: List<String>, sheet: Map<String, Bitmap>, palBg: Color, bgMode: String, photo: Bitmap?, scope: String,
    m: StickerModel, msg: String, done: Boolean, onScope: (String) -> Unit, onBgMode: () -> Unit, onSave: (String) -> Unit, onPaste: (String) -> Unit,
) {
    val mode = if (bgMode == "foto" && photo == null) "palet" else bgMode
    val bgColor = when (mode) { "gelap" -> Color(0xFF111111); "terang" -> Color(0xFFF2F2F2); else -> palBg }
    val bgLabel = when (mode) { "gelap" -> "Gelap"; "terang" -> "Terang"; "foto" -> "Foto"; else -> "Palet" }
    val photoImg = remember(photo) { photo?.asImageBitmap() }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Stickers.SCOPES.forEach { (k, t) -> SChip(t, scope == k) { onScope(k) } }
            SChip("Latar: $bgLabel", false) { onBgMode() }
        }
        if (ids.isEmpty()) {
            Text("Belum ada stiker untuk kategori ini.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            val page = pager.currentPage.coerceIn(0, ids.size - 1)
            val sid = ids[page]
            HorizontalPager(
                state = pager, pageSpacing = 12.dp,
                modifier = Modifier.fillMaxWidth().height(200.dp).clip(RoundedCornerShape(12.dp)).background(bgColor),
            ) { i ->
                val bmp = sheet[ids[i]]
                Box(Modifier.fillMaxSize()) {
                    if (mode == "foto" && photoImg != null) Image(photoImg, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    Box(Modifier.fillMaxSize().padding(10.dp), contentAlignment = androidx.compose.ui.Alignment.Center) {
                        if (bmp == null && done) Text("Gagal digambar (memori kurang?). Kecilkan ukuran PNG di Pengaturan umum.", style = MaterialTheme.typography.bodySmall, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        else if (bmp == null) CircularProgressIndicator(Modifier.size(24.dp))
                        else {
                            val img = remember(bmp) { bmp.asImageBitmap() }
                            Image(img, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("${Stickers.idLabel(sid, m)}  ·  ${page + 1}/${ids.size}", style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(Stickers.fileName(sid, m), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                OutlinedButton(onClick = { onPaste(sid) }, enabled = sheet[sid] != null) { Text("Tempel") }
                OutlinedButton(onClick = { onSave(sid) }, enabled = sheet[sid] != null) { Text("Simpan") }
            }
        }
        if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodySmall)
    }
}

/** Minta nama untuk preset gaya yang akan disimpan. */
@Composable
private fun NameDialog(onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Simpan gaya") },
        text = { OutlinedTextField(value = name, singleLine = true, label = { Text("Nama gaya (maksimal 20 huruf)") }, onValueChange = { name = it.take(20) }) },
        confirmButton = {
            val ok = name.trim().isNotEmpty()
            TextButton(onClick = { if (ok) onSave(name.trim()) }, enabled = ok) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
    )
}

/** Pilihan warna: bawaan, tujuh warna cepat, dan Kustom (kode hex atau slider RGB). [current] kosong = bawaan. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ColorChoice(current: String, onPick: (String) -> Unit) {
    var dlg by remember { mutableStateOf(false) }
    val custom = current.isNotEmpty() && current !in Stickers.ACCENTS
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        SChip("Bawaan", current.isEmpty()) { onPick("") }
        Stickers.ACCENTS.forEach { hex ->
            val on = current == hex
            Box(
                Modifier.size(36.dp).clip(CircleShape).background(Color(android.graphics.Color.parseColor(hex)))
                    .border(if (on) 3.dp else 1.dp, if (on) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outlineVariant, CircleShape)
                    .clickable { onPick(hex) },
            )
        }
        SChip(if (custom) "Kustom $current" else "Kustom…", custom) { dlg = true }
    }
    if (dlg) ColorDialog(current, onDismiss = { dlg = false }) { onPick(it); dlg = false }
}

@Composable
private fun ColorDialog(initial: String, onDismiss: () -> Unit, onApply: (String) -> Unit) {
    val start = Stickers.hex(initial).ifEmpty { Stickers.ACCENTS[0] }
    fun ch(h: String, i: Int) = Integer.parseInt(h.substring(1 + i * 2, 3 + i * 2), 16).toFloat()
    var r by remember { mutableStateOf(ch(start, 0)) }
    var g by remember { mutableStateOf(ch(start, 1)) }
    var b by remember { mutableStateOf(ch(start, 2)) }
    var hex by remember { mutableStateOf(start) }
    fun fromRgb() { hex = String.format(java.util.Locale.ROOT, "#%02x%02x%02x", r.toInt(), g.toInt(), b.toInt()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Warna kustom") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(Modifier.fillMaxWidth().height(40.dp).clip(RoundedCornerShape(8.dp)).background(Color(r / 255f, g / 255f, b / 255f)))
                Slider(value = r, onValueChange = { r = it; fromRgb() }, valueRange = 0f..255f)
                Slider(value = g, onValueChange = { g = it; fromRgb() }, valueRange = 0f..255f)
                Slider(value = b, onValueChange = { b = it; fromRgb() }, valueRange = 0f..255f)
                OutlinedTextField(
                    value = hex, singleLine = true, label = { Text("Kode hex #rrggbb") },
                    onValueChange = { t ->
                        hex = t
                        val h = Stickers.hex(t)
                        if (h.isNotEmpty()) { r = ch(h, 0); g = ch(h, 1); b = ch(h, 2) }
                    },
                )
            }
        },
        confirmButton = {
            val ok = Stickers.hex(hex).isNotEmpty()
            TextButton(onClick = { if (ok) onApply(Stickers.hex(hex)) }, enabled = ok) { Text("Pakai") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
    )
}

private fun sessionLabel(a: ActivityEntity): String = "${a.dateIso.take(10)} · ${a.name.ifBlank { if (a.type == "bike") "Sepeda" else "Lari" }} · ${Js.fmtKm(a.km)} km"

/** Pemilih sesi: daftar aktivitas ber-jarak, terbaru di atas (maksimal 200). */
@Composable
private fun SessionPicker(choices: List<ActivityEntity>, current: ActivityEntity, onPick: (Long) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth()) {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text(sessionLabel(current), maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            Text("▾")
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            choices.take(200).forEach { a ->
                DropdownMenuItem(text = { Text(sessionLabel(a), maxLines = 1, overflow = TextOverflow.Ellipsis) }, onClick = { open = false; onPick(a.id) })
            }
        }
    }
}

/** Pilihan huruf: bawaan sistem, huruf yang sudah diimpor, dan impor baru. [current] kosong = bawaan. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FontChoice(
    current: String, fonts: List<String>, label: (String) -> String,
    onPick: (String) -> Unit, onImport: () -> Unit, onDelete: (String) -> Unit,
) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SChip("Bawaan", current.isEmpty() || current !in fonts) { onPick("") }
        fonts.forEach { f -> SChip(label(f), current == f) { onPick(f) } }
        SChip("+ Impor huruf", false) { onImport() }
    }
    if (current.isNotEmpty() && current in fonts) TextButton(onClick = { onDelete(current) }) { Text("Hapus huruf ${label(current)}") }
}
