package com.endurancevault.app.ui.video

import android.content.Context
import com.endurancevault.app.domain.RouteVideoPrefs

/** Penyimpanan pengaturan video rute 3D (termasuk posisi dan ukuran tiap panel). */
class RouteVideoPrefsStore(ctx: Context, private val key: String = "json") {
    private val sp = ctx.getSharedPreferences("route_video_prefs", Context.MODE_PRIVATE)
    /** Sudah pernah disimpan? Dipakai video segmen 3D untuk memberi pengaturan awal sendiri. */
    fun has(): Boolean = sp.contains(key)
    fun load(): RouteVideoPrefs = RouteVideoPrefs.fromJson(sp.getString(key, null))
    fun save(p: RouteVideoPrefs) { sp.edit().putString(key, p.sanitized().toJson()).apply() }
}
