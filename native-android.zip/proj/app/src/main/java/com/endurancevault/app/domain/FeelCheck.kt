package com.endurancevault.app.domain

/**
 * Cocokkan rasa (1..10) dengan zona HR rata-rata. Rasa 1–2 = Z1, 3–4 = Z2, 5–6 = Z3, 7–8 = Z4, 9–10 = Z5 dari zona pribadi (Zones.cuts).
 * [pct] = HR rata-rata sebagai persen batas atas zona yang sesuai dengan rasa; ≤ 100 berarti masih di dalam batas rasa itu.
 */
object FeelCheck {
    data class Result(val level: String, val text: String, val zone: Int, val pct: Double)

    /**
     * HR bagian kerja sesi terstruktur (interval/threshold). [source] = "reps" (repetisi terdeteksi) atau "top" (35% waktu dengan HR
     * tertinggi, untuk sesi kualitas tanpa lap yang bisa dikenali). Rata-rata seluruh sesi ikut menghitung pemanasan, jeda, dan
     * pendinginan sehingga jauh di bawah usaha sebenarnya; rasa lari (RPE) dinilai terhadap bagian kerja ini.
     */
    class Work(val hr: Int, val source: String, val reps: Int = 0)

    private const val TOP_SHARE = 0.35
    private const val MIN_HIST_SEC = 600.0

    fun workEffort(d: ActDetail?, hist: Map<Int, Double>, quality: Boolean): Work? {
        val iv = IntervalAnalysis.analyze(d)
        if (iv != null && iv.reps.size >= IntervalAnalysis.MIN_REPS && (iv.src != "kurva" || iv.reps.size >= 4)) {
            val w = iv.reps.filter { (it.h ?: 0) > 0 && it.tm > 0 }
            val t = w.sumOf { it.tm }
            if (w.isNotEmpty() && t > 0) return Work(Js.roundI(w.sumOf { it.h!! * it.tm } / t), "reps", iv.reps.size)
        }
        if (!quality) return null
        val total = hist.values.sum()
        if (total < MIN_HIST_SEC) return null
        var need = total * TOP_SHARE; var acc = 0.0; var weighted = 0.0
        for ((bpm, sec) in hist.entries.filter { it.key > 0 }.sortedByDescending { it.key }) {
            val take = minOf(sec, need - acc)
            if (take <= 0) break
            acc += take; weighted += bpm * take
        }
        return if (acc > 0) Work(Js.roundI(weighted / acc), "top") else null
    }

    fun zoneOfFeel(feel10: Int): Int = (feel10 + 1) / 2

    private fun evaluateWork(feel10: Int, avgHr: Int, cuts: ZoneCuts, w: Work): Result {
        val fz = zoneOfFeel(feel10)
        val wz = Zones.zoneOf(w.hr, cuts.lo) + 1
        val top = if (wz < 5) cuts.lo[wz] - 1 else cuts.maxHr
        val pct = if (top > 0) w.hr * 100.0 / top else 0.0
        val what = if (w.source == "reps") "work segments (${w.reps} reps)" else "hardest part of the session"
        val whole = "The whole-session average ($avgHr) includes warm-up and rests."
        // RPE sesi merata-ratakan kerja dan jeda, jadi satu zona di bawah zona kerja masih wajar.
        return when {
            fz == wz || fz == wz - 1 -> Result("ok", "Quality session: HR in the $what is Zone $wz (${w.hr} bpm), so a feel of $feel10 fits. $whole", wz, pct)
            fz > wz -> Result("warn", "HR in the $what is only Zone $wz (${w.hr} bpm), yet it felt $feel10. Check heat, sleep or fatigue.", wz, pct)
            else -> Result("info", "HR in the $what is Zone $wz (${w.hr} bpm), higher than a feel of $feel10 suggests. Fitness may be ahead of the effort.", wz, pct)
        }
    }

    fun evaluate(feel10: Int?, avgHr: Int?, cuts: ZoneCuts, work: Work? = null): Result? {
        if (feel10 == null || feel10 !in 1..10 || avgHr == null || avgHr <= 0) return null
        if (work != null && work.hr >= avgHr) return evaluateWork(feel10, avgHr, cuts, work)
        val fz = zoneOfFeel(feel10)
        val zone = Zones.zoneOf(avgHr, cuts.lo) + 1
        val top = if (fz < 5) cuts.lo[fz] - 1 else cuts.maxHr
        val pct = if (top > 0) avgHr * 100.0 / top else 0.0
        val p = String.format(java.util.Locale.ROOT, "%.1f", pct)
        return when {
            fz == zone -> Result("ok", "HR: Efficient ($p%). A feel of $feel10 matches HR.", zone, pct)
            fz > zone -> Result("warn", "HR: Zone $zone only ($p%), yet it felt $feel10. Check heat, sleep or fatigue.", zone, pct)
            else -> Result("info", "HR: Zone $zone ($p%), higher than a feel of $feel10 suggests. Fitness may be ahead of the effort.", zone, pct)
        }
    }
}
