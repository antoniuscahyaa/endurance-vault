package com.endurancevault.app.ui.video

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.endurancevault.app.R
import kotlin.math.roundToInt
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Foreground service yang hanya menampilkan notifikasi progres selama [RouteVideoJobs] merender, lalu berhenti sendiri. */
class RouteVideoService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var watcher: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ensureChannel()
        val first = build("Video rute 3D", "Menyiapkan render…", -1)
        if (Build.VERSION.SDK_INT >= 29) startForeground(ID, first, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(ID, first)
        watcher?.cancel()
        watcher = scope.launch {
            RouteVideoJobs.state.collect { s ->
                val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                when (s) {
                    is RenderState.Running -> nm.notify(ID, build("Membuat video rute 3D", s.label, (s.progress * 100).roundToInt()))
                    is RenderState.Done -> { finish(nm, "Video rute 3D siap", s.label); stop() }
                    is RenderState.Failed -> { finish(nm, "Video rute 3D gagal", s.message); stop() }
                    RenderState.Idle -> stop()
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun finish(nm: NotificationManager, title: String, text: String) {
        nm.notify(ID + 1, base(title, text).setAutoCancel(true).setOngoing(false).build())
    }

    private fun stop() {
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun base(title: String, text: String): NotificationCompat.Builder {
        val open = packageManager.getLaunchIntentForPackage(packageName)?.let {
            PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_ev)
            .setContentTitle(com.endurancevault.app.ui.i18n.Lang.tr(title)).setContentText(com.endurancevault.app.ui.i18n.Lang.tr(text))
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
    }

    private fun build(title: String, text: String, percent: Int): Notification {
        val b = base(title, text).setOngoing(true).setCategory(NotificationCompat.CATEGORY_PROGRESS)
        if (percent >= 0) b.setProgress(100, percent, false) else b.setProgress(0, 0, true)
        return b.build()
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Render video rute 3D", NotificationManager.IMPORTANCE_LOW))
        }
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }

    private companion object {
        const val CHANNEL = "route_video"
        const val ID = 4721
    }
}
