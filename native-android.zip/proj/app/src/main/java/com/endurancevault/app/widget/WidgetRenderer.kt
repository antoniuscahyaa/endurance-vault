package com.endurancevault.app.widget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.TextPaint
import android.text.TextUtils
import androidx.compose.ui.graphics.toArgb
import com.endurancevault.app.ui.i18n.Lang
import com.endurancevault.app.ui.theme.cardTint
import com.endurancevault.app.ui.theme.onCardTint
import com.endurancevault.app.ui.theme.resolveThemeForWidget
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

enum class WidgetKind { TODAY, NEXT, WEEK }

/**
 * Menggambar widget sebagai gambar (Canvas), supaya aksen tema, warna sendiri, pastel, gradien tombol, dan mode gelap
 * bisa persis seperti di aplikasi tanpa bergantung pada RemoteViews. Font memakai font sistem (widget tidak mendukung font kustom).
 */
object WidgetRenderer {
    private class C(
        val bg: Int, val fg: Int, val muted: Int, val border: Int, val accent: Int, val onAccent: Int,
        val track: Int, val tones: List<Pair<Int, Int>>, val gradient: IntArray?,
    )

    private fun colors(ctx: Context): Pair<C, Float> {
        val t = resolveThemeForWidget(ctx)
        val cs = t.scheme
        val p = t.palette
        val tones = p?.tones?.map { it.container.toArgb() to it.content.toArgb() }
            ?: List(3) { cs.cardTint.toArgb() to cs.onCardTint.toArgb() }
        val c = C(
            bg = cs.background.toArgb(), fg = cs.onSurface.toArgb(), muted = cs.onSurfaceVariant.toArgb(),
            border = cs.outlineVariant.toArgb(), accent = if (p == null) cs.onCardTint.toArgb() else cs.primary.toArgb(),
            onAccent = cs.onPrimary.toArgb(), track = cs.outlineVariant.toArgb(), tones = tones,
            gradient = p?.gradient?.map { it.toArgb() }?.toIntArray(),
        )
        return c to t.fontScale
    }

    /** [wDp] x [hDp] dalam dp; hasilnya bitmap seukuran piksel layar. */
    fun render(ctx: Context, kind: WidgetKind, snap: WidgetSnapshot, wDp: Int, hDp: Int): Bitmap {
        val d = ctx.resources.displayMetrics.density
        val (c, fs) = colors(ctx)
        var w = (wDp * d).roundToInt().coerceAtLeast(1)
        var h = (hDp * d).roundToInt().coerceAtLeast(1)
        // Batas ukuran bitmap RemoteViews: jaga di bawah ~1,5 juta piksel.
        val maxPx = 1_500_000f
        val k = if (w.toFloat() * h > maxPx) kotlin.math.sqrt(maxPx / (w.toFloat() * h)) else 1f
        val bw = max(1, (w * k).roundToInt()); val bh = max(1, (h * k).roundToInt())
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        cv.scale(k, k)
        w = w.coerceAtLeast(1); h = h.coerceAtLeast(1)

        val radius = 22f * d
        val rect = RectF(0f, 0f, w.toFloat(), h.toFloat())
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = c.bg }
        cv.drawRoundRect(rect, radius, radius, bgPaint)
        val bd = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = c.border; style = Paint.Style.STROKE; strokeWidth = 1f * d }
        cv.drawRoundRect(RectF(0.5f * d, 0.5f * d, w - 0.5f * d, h - 0.5f * d), radius, radius, bd)

        val pad = 14f * d
        val ctxD = Ctx(cv, c, d, fs, pad, w.toFloat(), h.toFloat())
        when (kind) {
            WidgetKind.TODAY -> today(ctxD, snap)
            WidgetKind.NEXT -> next(ctxD, snap)
            WidgetKind.WEEK -> week(ctxD, snap)
        }
        return bmp
    }

    private class Ctx(val cv: Canvas, val c: C, val d: Float, val fs: Float, val pad: Float, val w: Float, val h: Float)

    private fun tp(x: Ctx, color: Int, sp: Float, bold: Boolean = false, spacing: Float = 0f): TextPaint =
        TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            textSize = sp * x.fs * x.d
            typeface = if (bold) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.DEFAULT
            letterSpacing = spacing
        }

    /** Teks satu baris yang dipotong dengan elipsis bila melebihi [maxW]; y = garis dasar. */
    private fun text(x: Ctx, s: String, px: Float, y: Float, p: TextPaint, maxW: Float, alignRight: Boolean = false) {
        if (s.isEmpty() || maxW <= 0f) return
        val t = TextUtils.ellipsize(s, p, maxW, TextUtils.TruncateAt.END).toString()
        val xx = if (alignRight) px - p.measureText(t) else px
        x.cv.drawText(t, xx, y, p)
    }

    private fun pill(x: Ctx, label: String, left: Float, top: Float) {
        val p = tp(x, x.c.onAccent, 11f, bold = true)
        val padX = 12f * x.d
        val wText = p.measureText(label)
        val r = RectF(left, top, left + wText + padX * 2, top + 26f * x.d)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        val g = x.c.gradient
        if (g != null) fill.shader = LinearGradient(r.left, r.top, r.right, r.bottom, g, null, Shader.TileMode.CLAMP)
        else fill.color = x.c.accent
        x.cv.drawRoundRect(r, r.height() / 2, r.height() / 2, fill)
        x.cv.drawText(label, r.left + padX, r.centerY() + p.textSize * 0.35f, p)
    }

    private fun ring(x: Ctx, cx: Float, cy: Float, dia: Float, frac: Float, color: Int, center: String) {
        val sw = dia * 0.11f
        val rc = RectF(cx - dia / 2 + sw / 2, cy - dia / 2 + sw / 2, cx + dia / 2 - sw / 2, cy + dia / 2 - sw / 2)
        val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = x.c.track; style = Paint.Style.STROKE; strokeWidth = sw }
        x.cv.drawArc(rc, 0f, 360f, false, track)
        val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color; style = Paint.Style.STROKE; strokeWidth = sw; strokeCap = Paint.Cap.ROUND
        }
        if (frac > 0f) x.cv.drawArc(rc, -90f, 360f * frac.coerceIn(0f, 1f), false, arc)
        val tpt = tp(x, color, 15f, bold = true)
        val tw = tpt.measureText(center)
        x.cv.drawText(center, cx - tw / 2, cy + tpt.textSize * 0.35f, tpt)
    }

    // ---- Hari ini ----
    private fun today(x: Ctx, s: WidgetSnapshot) {
        val ringDia = min(64f * x.d, x.h * 0.48f)
        val rightW = ringDia + 8f * x.d
        val leftW = x.w - x.pad * 2 - rightW
        val lab = tp(x, x.c.accent, 10f, bold = true, spacing = 0.08f)
        var y = x.pad + lab.textSize
        text(x, s.dateLabel, x.pad, y, lab, leftW)
        val title = tp(x, x.c.fg, 20f, bold = true)
        y += title.textSize * 1.15f
        text(x, s.todayTitle, x.pad, y, title, leftW)
        val sub = tp(x, x.c.muted, 12f)
        if (s.todaySub.isNotEmpty()) { y += sub.textSize * 1.5f; text(x, s.todaySub, x.pad, y, sub, leftW) }
        val pillTop = x.h - x.pad - 26f * x.d
        if (pillTop > y + 4f * x.d) pill(x, Lang.tr(if (s.todayDone) "Buka detail" else "Lihat sesi"), x.pad, pillTop)

        val cx = x.w - x.pad - ringDia / 2
        val cy = x.pad + ringDia / 2 + 2f * x.d
        val tone = x.c.tones.getOrNull(1)?.second ?: x.c.accent
        val score = s.readiness
        ring(x, cx, cy, ringDia, (score ?: 0) / 100f, tone, score?.toString() ?: "–")
        val kl = tp(x, x.c.muted, 9.5f, bold = true, spacing = 0.06f)
        val label = Lang.tr("KESIAPAN")
        val lw = min(kl.measureText(label), rightW + x.pad)
        text(x, label, cx - lw / 2, cy + ringDia / 2 + kl.textSize * 1.5f, kl, rightW + x.pad)
    }

    // ---- Sesi berikutnya ----
    private fun next(x: Ctx, s: WidgetSnapshot) {
        val lab = tp(x, x.c.accent, 10f, bold = true, spacing = 0.08f)
        var y = x.pad + lab.textSize
        text(x, Lang.tr("SESI BERIKUTNYA"), x.pad, y, lab, x.w - x.pad * 2)
        val top = y + 8f * x.d
        val avail = x.h - x.pad - top
        if (s.next.isEmpty()) {
            val m = tp(x, x.c.muted, 12f)
            text(x, Lang.tr("Belum ada sesi terjadwal"), x.pad, top + m.textSize * 1.6f, m, x.w - x.pad * 2)
            return
        }
        val gap = 5f * x.d
        val maxRows = if (avail >= 3 * 30f * x.d + 2 * gap) 3 else 2
        val rows = s.next.take(maxRows)
        val rowH = min(34f * x.d, (avail - gap * (rows.size - 1)) / rows.size)
        val whenP = tp(x, x.c.fg, 12f, bold = true)
        val titleP = tp(x, x.c.fg, 12f)
        val kmP = tp(x, x.c.muted, 12f)
        rows.forEachIndexed { i, r ->
            val (bg, fgc) = x.c.tones[i % x.c.tones.size]
            val t0 = top + i * (rowH + gap)
            val rr = RectF(x.pad, t0, x.w - x.pad, t0 + rowH)
            x.cv.drawRoundRect(rr, rowH / 2.2f, rowH / 2.2f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = bg })
            val base = rr.centerY() + whenP.textSize * 0.35f
            val inner = 12f * x.d
            whenP.color = fgc
            val wl = whenP.measureText(r.whenLabel)
            x.cv.drawText(r.whenLabel, rr.left + inner, base, whenP)
            val kmW = if (r.km.isEmpty()) 0f else kmP.measureText(r.km) + 8f * x.d
            text(x, "· " + r.title, rr.left + inner + wl + 4f * x.d, base, titleP, rr.width() - inner * 2 - wl - 4f * x.d - kmW)
            if (r.km.isNotEmpty()) text(x, r.km, rr.right - inner, base, kmP, kmW, alignRight = true)
        }
    }

    // ---- Progres mingguan ----
    private fun week(x: Ctx, s: WidgetSnapshot) {
        val lab = tp(x, x.c.accent, 10f, bold = true, spacing = 0.08f)
        var y = x.pad + lab.textSize
        text(x, Lang.tr("PEKAN INI"), x.pad, y, lab, x.w - x.pad * 2)
        val big = tp(x, x.c.fg, 20f, bold = true)
        y += big.textSize * 1.15f
        fun f(v: Double) = if (v == Math.floor(v)) v.toLong().toString() else String.format(java.util.Locale.US, "%.1f", v).let {
            if (Lang.current == com.endurancevault.app.ui.i18n.AppLang.ID) it.replace('.', ',') else it
        }
        val head = if (s.weekTarget > 0) "${f(s.weekDone)} / ${f(s.weekTarget)} km" else "${f(s.weekDone)} km"
        text(x, head, x.pad, y, big, x.w - x.pad * 2)
        val sub = tp(x, x.c.muted, 12f)
        if (s.weekTarget > 0) {
            y += sub.textSize * 1.5f
            val pct = (s.weekDone / s.weekTarget * 100).roundToInt()
            text(x, "$pct% " + Lang.tr("dari target"), x.pad, y, sub, x.w - x.pad * 2)
        }
        // Batang 7 hari
        val labH = 12f * x.d
        val barsTop = y + 8f * x.d
        val barsBottom = x.h - x.pad - labH
        val chartH = barsBottom - barsTop
        if (chartH < 14f * x.d) return
        val maxKm = max(s.dayKm.maxOrNull() ?: 0.0, 1.0)
        val gap = 6f * x.d
        val bw = (x.w - x.pad * 2 - gap * 6) / 7f
        val lp = tp(x, x.c.muted, 9f)
        for (i in 0..6) {
            val left = x.pad + i * (bw + gap)
            val km = s.dayKm[i]
            val future = i > s.todayIdx
            val hBar = if (km > 0) max(4f * x.d, (km / maxKm).toFloat() * chartH) else 3f * x.d
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            paint.color = if (km > 0) (if (i == s.todayIdx) x.c.accent else x.c.accent and 0x00FFFFFF or (0xB3 shl 24)) else x.c.track
            if (future && km <= 0) paint.alpha = 140
            val rr = RectF(left, barsBottom - hBar, left + bw, barsBottom)
            x.cv.drawRoundRect(rr, 4f * x.d, 4f * x.d, paint)
            val ch = s.dayLabels.getOrNull(i) ?: ""
            val cw = lp.measureText(ch)
            x.cv.drawText(ch, left + bw / 2 - cw / 2, barsBottom + labH - 1f * x.d, lp)
        }
    }
}
