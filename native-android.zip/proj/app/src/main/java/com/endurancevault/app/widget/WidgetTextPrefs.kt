package com.endurancevault.app.widget

import android.content.Context

/** Pilihan warna teks widget "Hari ini". AUTO = ikut wallpaper (terang/gelap), selain itu dipaksa. */
object WidgetTextPrefs {
    enum class Mode(val key: String) { AUTO("auto"), LIGHT("light"), DARK("dark"), CUSTOM("custom") }

    private const val FILE = "ev_widget_text"
    const val DEFAULT_CUSTOM = 0xFFFFD54F.toInt()

    fun mode(ctx: Context): Mode {
        val k = ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString("mode", null)
        return Mode.values().firstOrNull { it.key == k } ?: Mode.AUTO
    }

    fun customColor(ctx: Context): Int =
        ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE).getInt("color", DEFAULT_CUSTOM)

    fun setMode(ctx: Context, m: Mode) {
        ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("mode", m.key).apply()
        GlanceWidgetRenderer.updateAll(ctx)
    }

    /** Menyimpan warna sendiri dan langsung mengaktifkannya. */
    fun setCustom(ctx: Context, argb: Int) {
        ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString("mode", Mode.CUSTOM.key).putInt("color", argb or 0xFF000000.toInt()).apply()
        GlanceWidgetRenderer.updateAll(ctx)
    }
}
