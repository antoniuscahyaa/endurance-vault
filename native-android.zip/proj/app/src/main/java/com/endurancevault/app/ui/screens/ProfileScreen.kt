package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.theme.EvButton

import com.endurancevault.app.ui.i18n.Text
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import com.endurancevault.app.ui.theme.cardTint
import com.endurancevault.app.ui.theme.onCardTint
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.domain.PbConversion
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.PainReadinessEntry
import com.endurancevault.app.domain.InjuryPrevention
import com.endurancevault.app.domain.TrainingMethod
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import com.endurancevault.app.ui.ImportUi
import com.endurancevault.app.ui.BackupUi
import com.endurancevault.app.ui.UiState
import com.endurancevault.app.data.DailyEntity
import com.endurancevault.app.data.GearEntity
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.endurancevault.app.ui.floating.AlertDialog
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.TextButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import java.time.LocalDate
import kotlin.math.roundToInt

private val TYPES = listOf(
    "5k" to "5K", "10k" to "10K", "hm" to "Half marathon", "fm" to "Marathon",
    "ultra" to "Trail", "ultrar" to "Ultra road", "pb" to "Performance Build", "none" to "No Race",
)

/** Ringkasan rencana aktif (nama rencana, atau jenis lomba); dipakai kartu Rencana di sidebar. */
internal fun planSummaryOf(name: String, rtype: String): String =
    name.trim().ifBlank { TYPES.firstOrNull { it.first == rtype }?.second ?: rtype }

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileScreen(
    state: UiState,
    onSave: (PlanSettings) -> Unit,
    importUi: ImportUi,
    onImport: (Uri) -> Unit,
    onConfirmImport: () -> Unit,
    onDismissImport: () -> Unit,
    onMergeDuplicates: () -> Unit,
    onScanDuplicates: () -> Unit,
    duplicateStatus: String,
    onSaveDaily: (DailyEntity) -> Unit,
    onSaveGear: (GearEntity) -> Unit,
    onDeleteGear: (String) -> Unit,
    watchMessage: String,
    onConnectWatch: (String) -> Unit,
    onDisconnectWatch: () -> Unit,
    onForgetAndReconnectWatch: (String) -> Unit,
    onSyncWatch: (Boolean) -> Unit,
    watchSyncing: Boolean,
    watchAdvancedMessage: String,
    liveHr: org.json.JSONObject,
    onRefreshLiveHr: () -> Unit,
    onSetLiveHr: (Boolean) -> Unit,
    onSyncHrZones: (PlanSettings) -> Unit,
    onPushWorkout: (String, Int, Int, Int, Int, Int, com.endurancevault.app.domain.WorkoutTargets) -> Unit,
    onPushRoute: (Uri) -> Unit,
    weatherMessage: String, weatherBusy: Boolean, weatherLat: String, weatherLon: String,
    onFetchWeather: (Double,Double,String) -> Unit, onSearchWeatherCity: (String) -> Unit, onUseWeatherLocation: () -> Unit, onWeatherToWatch: (Double,Double,String) -> Unit,
    weatherWatchStatus: String, agpsStatus: String, onAgps: (Boolean,String) -> Unit, onTestAgps: () -> Unit,
    notifyStatus: String, onNotify: (Boolean,Boolean,Int,Int,Boolean,Map<String,Boolean>) -> Unit, onTestNotify: () -> Unit,
    aiStatus: String, onAiKey: (String) -> Unit,
    onDeleteActivity: (Long) -> Unit, onOpenActivity: (Long) -> Unit,
    onImportTracks: (List<Uri>) -> Unit, trackMsg: String?,
    onImportHuaweiZip: (Uri, String) -> Unit = { _, _ -> },
    settingsMode: Boolean = false,
    onBack: () -> Unit = {},
    backupUi: BackupUi = BackupUi.Idle,
    backupFileName: () -> String = { "EnduranceVault-cadangan.zip" },
    onExportBackup: (Uri) -> Unit = {},
    onStartRestore: (Uri) -> Unit = {},
    onConfirmRestore: () -> Unit = {},
    onDismissBackup: () -> Unit = {},
    onOpenStickers: () -> Unit = {},
    onOpenProgressDock: (String) -> Unit = {},
    profileName: String = "",
    profilePhotoUri: String? = null,
    onEditProfileName: () -> Unit = {},
    onPickProfilePhoto: () -> Unit = {},
    settingsExtra: @Composable () -> Unit = {},
    /** Bagian Pengaturan yang langsung dibuka (mis. "Rencana" dari sidebar). null = mulai dari menu Pengaturan. */
    initialSection: String? = null,
    /** Sub-tab beranda Profil yang dibuka dari sidebar: "Profile" atau "Timeline". */
    initialHomeTab: String = "Profile",
    initialHomeTabNonce: Int = 0,
    aiKeySet: Boolean = false,
    aiModel: String = "", aiModels: List<Pair<String,String>> = emptyList(), onAiModel: (String) -> Unit = {},
    weatherSnapshot: com.endurancevault.app.domain.WxSnapshot? = null,
    weatherPlaceLabel: String = "",
    weatherError: String? = null,
    weatherNotice: String? = null,
    weatherWatchBusy: Boolean = false,
    weatherWatchNote: String = "",
    onRefreshWeather: () -> Unit = {},
) {
    var showDuplicateConfirm by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) onImport(uri) }
    val exportBackupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri -> if (uri != null) onExportBackup(uri) }
    val restoreBackupPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) onStartRestore(uri) }
    val trackPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> if (uris.isNotEmpty()) onImportTracks(uris) }
    // Impor zip ekspor Huawei Health: pilih zip, isi kata sandi (bila ada), lalu impor. lastHuaweiZip disimpan agar bisa coba kata sandi lain.
    var huaweiZipPick by remember { mutableStateOf<Uri?>(null) }
    var lastHuaweiZip by remember { mutableStateOf<Uri?>(null) }
    var huaweiZipPw by remember { mutableStateOf("") }
    val huaweiZipPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { huaweiZipPw = ""; huaweiZipPick = uri; lastHuaweiZip = uri }
    }
    val hostContext = LocalContext.current
    val s = state.settings
    // Zona HR tersimpan otomatis oleh HrZoneSettings; jangan reset isian form lain saat zona berubah.
    // hr/thr/pace punya kunci sendiri agar simpan otomatis dari tab Zona HR tidak mereset isian tab Rencana.
    val formKey = s.copy(logHrMax = 0, thrSrc = null, zm = "lthr", lthr = null, rhr = null, zl = com.endurancevault.app.domain.Zones.ZLD, zr = com.endurancevault.app.domain.Zones.ZRD, hr = 0, thr = "", pace = "")
    var rtype by remember(formKey) { mutableStateOf(s.rtype) }
    var name by remember(formKey) { mutableStateOf(s.name) }
    var start by remember(formKey) { mutableStateOf(s.start.toString()) }
    var race by remember(formKey) { mutableStateOf(s.race?.toString() ?: "") }
    var raceKm by remember(formKey) { mutableStateOf(s.raceKm?.let { fmtKmUi(it) } ?: "") }
    var raceGain by remember(formKey) { mutableStateOf(s.raceGain?.let { fmtKmUi(it) } ?: "") }
    var goal by remember(formKey) { mutableStateOf(s.goalT) }
    var base by remember(formKey) { mutableStateOf(fmtKmUi(s.base)) }
    var peak by remember(formKey) { mutableStateOf(fmtKmUi(s.peak)) }
    var days by remember(formKey) { mutableStateOf(s.days) }
    var longDay by remember(formKey) { mutableStateOf(s.longDay.toString()) }
    var restDay by remember(formKey) { mutableStateOf(s.rest) }
    var restDay2 by remember(formKey) { mutableStateOf(s.rest2) }
    var hr by remember(s.hr) { mutableStateOf(s.hr.toString()) }
    var thr by remember(s.thr) { mutableStateOf(s.thr) }
    var pace by remember(s.pace) { mutableStateOf(s.pace) }
    var method by remember(formKey) { mutableStateOf(s.method) }
    var qSess by remember(formKey) { mutableStateOf(s.qSess) }
    var sLeg by remember(formKey) { mutableStateOf(s.sLeg) }
    var sAnk by remember(formKey) { mutableStateOf(s.sAnk) }
    var sUp by remember(formKey) { mutableStateOf(s.sUp) }
    var pbCycle by remember(formKey) { mutableStateOf(s.pbCycle) }
    var pbFocus by remember(formKey) { mutableStateOf(s.pbFocus) }
    var evOn by remember(formKey) { mutableStateOf(s.evOn) }
    var evDate by remember(formKey) { mutableStateOf(s.evDate?.toString() ?: "") }
    var evKm by remember(formKey) { mutableStateOf(if (s.evKm > 0) fmtKmUi(s.evKm) else "") }
    var evGain by remember(formKey) { mutableStateOf(if (s.evGain > 0) fmtKmUi(s.evGain) else "") }
    var planOpen by remember { mutableStateOf(true) }
    var planTab by remember { mutableStateOf("Race") }
    var showRaceDialog by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }
    var profileSection by remember { mutableStateOf(if (settingsMode) (initialSection ?: SETTINGS_HOME) else "Hari ini") }
    // Dibuka langsung ke satu bagian (dari sidebar): Kembali menutup Pengaturan, bukan ke menu Pengaturan.
    val directEntry = settingsMode && initialSection != null
    androidx.activity.compose.BackHandler(enabled = settingsMode && !directEntry && profileSection != SETTINGS_HOME) { profileSection = SETTINGS_HOME }
    var profileHomeTab by remember(initialHomeTabNonce) { mutableStateOf(initialHomeTab) }
    var timelineSearch by remember { mutableStateOf("") }
    fun draftSettings(): PlanSettings? {
        fun d(t: String) = runCatching { LocalDate.parse(t.trim()) }.getOrNull()
        fun n(t: String) = t.replace(',', '.').toDoubleOrNull()
        val st = d(start)
        val rc = if (race.isBlank()) null else d(race)
        val b = n(base); val p = n(peak); val h = hr.toIntOrNull(); val ld = longDay.toIntOrNull()
        if (st == null || (race.isNotBlank() && rc == null) || b == null || p == null || h == null || ld == null) return null
        val safeLong = ld.coerceIn(0, 6)
        val safeRest = if (restDay == safeLong) (0..6).first { it != safeLong } else restDay
        val safeRest2 = if (days == 5) (if (restDay2 == safeRest || restDay2 == safeLong) (0..6).first { it != safeRest && it != safeLong } else restDay2) else safeRest
        return s.copy(
            name = name.trim(), rtype = rtype, start = st, race = if (rtype == "pb" || rtype == "none") null else rc,
            raceKm = n(raceKm), raceGain = n(raceGain), goalT = goal.trim(),
            base = b, peak = p, days = days, rest = safeRest, rest2 = safeRest2, longDay = ld, hr = h, thr = thr.trim(), pace = pace.trim(),
            method = method, qSess = qSess, sLeg = sLeg, sAnk = sAnk, sUp = sUp,
            pbCycle = pbCycle, pbFocus = pbFocus,
            evOn = evOn && d(evDate) != null && (n(evKm) ?: 0.0) > 0.0,
            evDate = d(evDate), evKm = n(evKm) ?: 0.0, evGain = n(evGain) ?: 0.0,
        )
    }
    val num = KeyboardOptions(keyboardType = KeyboardType.Number)
    val full = Modifier.fillMaxWidth()

    if (profileHomeTab == "Timeline" && !settingsMode) {
        val sortedActivities = state.activities
            .sortedWith(compareByDescending<com.endurancevault.app.data.ActivityEntity> { it.dateIso }.thenByDescending { it.startTime ?: "" })
        val query = timelineSearch.trim()
        val filteredActivities = remember(sortedActivities, query) {
            if (query.isBlank()) sortedActivities else sortedActivities.filter { activity ->
                val title = activity.name.ifBlank { activity.type }
                val dateIso = activity.dateIso
                val parsedDate = runCatching { java.time.LocalDate.parse(dateIso) }.getOrNull()
                val dateDisplay = parsedDate?.format(
                    java.time.format.DateTimeFormatter.ofPattern("dd MMM yyyy", com.endurancevault.app.ui.i18n.Lang.locale)
                ) ?: dateIso
                val dateNumeric = parsedDate?.format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy")) ?: dateIso
                title.contains(query, ignoreCase = true) ||
                    activity.type.contains(query, ignoreCase = true) ||
                    dateIso.contains(query, ignoreCase = true) ||
                    dateDisplay.contains(query, ignoreCase = true) ||
                    dateNumeric.contains(query, ignoreCase = true)
            }
        }
        Column(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            ProfileHomeTabs(profileHomeTab) { tab -> profileHomeTab = tab; if (tab == "Profile") profileSection = "Hari ini" }
            OutlinedTextField(
                value = timelineSearch,
                onValueChange = { timelineSearch = it },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                textStyle = MaterialTheme.typography.bodyMedium,
                placeholder = { Text("Cari aktivitas atau tanggal") },
                leadingIcon = {
                    androidx.compose.material3.Icon(
                        Icons.Default.Search,
                        contentDescription = com.endurancevault.app.ui.i18n.Lang.tr("Cari"),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                },
                trailingIcon = if (timelineSearch.isNotEmpty()) ({
                    androidx.compose.material3.IconButton(onClick = { timelineSearch = "" }) {
                        androidx.compose.material3.Icon(
                            Icons.Default.Close,
                            contentDescription = com.endurancevault.app.ui.i18n.Lang.tr("Hapus pencarian"),
                        )
                    }
                }) else null,
            )
            when {
                state.activities.isEmpty() -> {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text("Belum ada riwayat aktivitas yang tersinkron.", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                filteredActivities.isEmpty() -> {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text("Tidak ada aktivitas yang cocok dengan pencarian.", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                else -> {
                    Column(
                        Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        filteredActivities.forEach { activity ->
                            TimelineActivityCard(
                                activity = activity,
                                detail = state.detailsByActivity[activity.id],
                                onClick = { onOpenActivity(activity.id) },
                            )
                        }
                    }
                }
            }
        }
    } else Column(
        Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(11.dp),
    ) {
        if (settingsMode) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                androidx.compose.material3.IconButton(onClick = { if (profileSection != SETTINGS_HOME && !directEntry) profileSection = SETTINGS_HOME else onBack() }) {
                    androidx.compose.material3.Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = com.endurancevault.app.ui.i18n.Lang.tr("Kembali"))
                }
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("PENGATURAN", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    Text(if (profileSection == SETTINGS_HOME) "Pengaturan" else profileSection, style = MaterialTheme.typography.headlineMedium)
                }
            }
        } else ProfileHomeTabs(profileHomeTab) { tab -> profileHomeTab = tab; if (tab == "Profile") profileSection = "Hari ini" }
        if (profileSection != "Hari ini" && !settingsMode) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("PROFIL", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                Text("Profil dan pengaturan", style = MaterialTheme.typography.headlineMedium)
                Text("Pengaturan yang tersedia di aplikasi native", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (!settingsMode && profileSection != "Hari ini") {
            EvPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!settingsMode) Text("PENGATURAN", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("Rencana", "Kondisi", "Nyeri & cedera", "Cuaca", "AI Coach", "Cadangan", "Tampilan").forEach { section ->
                            FilterChip(selected = profileSection == section, onClick = { profileSection = section }, label = { Text(section) })
                        }
                    }
                }
            }
        }
        if (settingsMode && profileSection == SETTINGS_HOME) {
            ProfileIdentityCard(profileName, profilePhotoUri, onOpen = { profileSection = "Profil" })
            settingsExtra()
            SettingsHomeGrid(
                tiles = listOf(
                    SettingsTile("Kondisi", settingsIcon("Kondisi"), "Leg feel dan mood harian"),
                    SettingsTile("Nyeri & cedera", settingsIcon("Nyeri & cedera"), "Catatan area nyeri"),
                    SettingsTile("Cuaca", settingsIcon("Cuaca"), weatherSnapshot?.let { "${weatherPlaceLabel.ifBlank { it.place }} · ${Math.round(it.temp)}°" } ?: "Lokasi dan prakiraan cuaca"),
                    SettingsTile("AI Coach", settingsIcon("AI Coach"), if (aiKeySet) "${aiModels.firstOrNull { it.first == aiModel }?.second ?: aiModel} · API key tersimpan" else "API key dan pilihan model"),
                    SettingsTile("Cadangan", settingsIcon("Cadangan"), "Ekspor dan impor data"),
                    SettingsTile("Tampilan", settingsIcon("Tampilan"), com.endurancevault.app.ui.theme.ThemePrefs.mode.label),
                ),
                onOpen = { profileSection = it },
            )
        }
        when (profileSection) {
            "Hari ini" -> {
                ProfileTodaySection(
                    state = state,
                    onSaveDaily = onSaveDaily,
                    onSaveSettings = onSave,
                    onOpenProgress = { tab -> onOpenProgressDock(tab) },
                )
            }
            "Rencana" -> {
            val draft = draftSettings()
            val preview: PlanOutcome? = remember(draft) {
                draft?.let {
                    runCatching {
                        val dx = it.copy(logHrMax = s.logHrMax)
                        val rd = restHrFrom(state.daily).first
                        com.endurancevault.app.domain.PlanRaw.plan(dx, easyPace = com.endurancevault.app.ui.easyPaceOf(dx, state.activities, rd), restDefault = rd)
                    }.getOrNull()
                }
            } ?: state.plan
            val previewOk = preview as? PlanOutcome.Ok
            PlanSettingsPanel(open = planOpen, onToggle = { planOpen = !planOpen }) {
                PlanHeroCard(
                    outcome = preview,
                    typeLabel = TYPES.firstOrNull { it.first == rtype }?.second ?: rtype,
                    days = days, base = base, peak = peak,
                )
                PlanSubTabs(planTab) { planTab = it }
                when (planTab) {
                    "Race" -> {
                        PlanPillFlow { TYPES.forEach { (k, label) -> PlanPill(label, rtype == k, { rtype = k }) } }
                        if (rtype == "pb") {
                            PlanDropdown(
                                "Performance build cycle",
                                PB_CYCLE_OPTIONS.firstOrNull { it.first == pbCycle }?.second ?: PB_CYCLE_OPTIONS[1].second,
                                PB_CYCLE_OPTIONS,
                            ) { pbCycle = it }
                            PlanDropdown(
                                "Block goal",
                                PB_FOCUS_OPTIONS.firstOrNull { it.first == pbFocus }?.second ?: PB_FOCUS_OPTIONS[0].second,
                                PB_FOCUS_OPTIONS,
                            ) { pbFocus = it }
                        }
                        OutlinedTextField(name, { name = it }, label = { Text("Nama lomba") }, singleLine = true, modifier = full)
                        OutlinedTextField(start, { start = it }, label = { Text("Mulai (yyyy-MM-dd)") }, singleLine = true, modifier = full)
                        if (rtype != "pb" && rtype != "none") {
                            OutlinedTextField(race, { race = it }, label = { Text("Tanggal lomba (yyyy-MM-dd)") }, singleLine = true, modifier = full)
                        }
                        if (rtype == "ultra" || rtype == "ultrar") {
                            OutlinedTextField(raceKm, { raceKm = it }, label = { Text("Jarak lomba (km)") }, keyboardOptions = num, singleLine = true, modifier = full)
                            OutlinedTextField(raceGain, { raceGain = it }, label = { Text("Elevation Gain lomba (m)") }, keyboardOptions = num, singleLine = true, modifier = full)
                        }
                    }
                    "Volume" -> {
                        Text("Atur perkembangan jarak mingguan", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(base, { base = it }, label = { Text("Km awal / minggu") }, keyboardOptions = num, singleLine = true, modifier = Modifier.weight(1f))
                            OutlinedTextField(peak, { peak = it }, label = { Text("Km puncak / minggu") }, keyboardOptions = num, singleLine = true, modifier = Modifier.weight(1f))
                        }
                    }
                    "Week" -> {
                        Text("Hari lari per minggu", style = MaterialTheme.typography.labelLarge)
                        PlanPillFlow {
                            PlanPill("5 hari lari", days == 5, { days = 5 })
                            PlanPill("6 hari lari", days == 6, { days = 6 })
                        }
                        Text("Hari long run", style = MaterialTheme.typography.labelLarge)
                        PlanPillFlow {
                            listOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min").forEachIndexed { idx, dn ->
                                PlanPill(dn, longDay == idx.toString(), { longDay = idx.toString() })
                            }
                        }
                        Text(if (days == 5) "Hari istirahat (pilih 2)" else "Hari istirahat", style = MaterialTheme.typography.labelLarge)
                        PlanPillFlow {
                            listOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min").forEachIndexed { idx, dn ->
                                val selected = idx == restDay || (days == 5 && idx == restDay2)
                                val blocked = idx == (longDay.toIntOrNull() ?: s.longDay)
                                PlanPill(dn, selected, {
                                    if (!blocked) {
                                        if (idx == restDay) {
                                            if (days == 5 && restDay2 != idx) { restDay = restDay2; restDay2 = idx }
                                        } else if (days == 6) restDay = idx
                                        else if (idx == restDay2) { restDay2 = restDay; restDay = idx }
                                        else { restDay2 = restDay; restDay = idx }
                                    }
                                })
                            }
                        }
                        Text("Sesi kualitas per minggu", style = MaterialTheme.typography.labelLarge)
                        PlanPillFlow {
                            PlanPill("1 sesi", qSess == "1", { qSess = "1" })
                            PlanPill("2 sesi", qSess == "2", { qSess = "2" })
                        }
                        if (qSess == "2") {
                            Text(
                                "Sesi kedua hanya muncul di fase Bangun dan Puncak untuk 5K, 10K, Half, Marathon, dan Performance Build dengan 6 hari lari, saat hari easy pendek jatuh dua hari sebelum long run. Dosisnya naik bertahap dan dibatasi sekitar 20% waktu lari mingguan.",
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    "Target" -> {
                        if (rtype != "pb" && rtype != "none") {
                            OutlinedTextField(goal, { goal = it }, label = { Text("Target waktu (h:mm:ss, opsional)") }, singleLine = true, modifier = full)
                        }
                        Text("Metode latihan", style = MaterialTheme.typography.labelLarge)
                        PlanPillFlow {
                            TrainingMethod.KEYS.forEach { k -> PlanPill(TrainingMethod.name(k), method == k, { method = k }) }
                        }
                        Text(TrainingMethod.info(method), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    "Strength" -> {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Switch(checked = sLeg, onCheckedChange = { sLeg = it }); Text("Kaki dan panggul (Strength A dan B)")
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Switch(checked = sAnk, onCheckedChange = { sAnk = it }); Text("Ankle dan stabilitas")
                        }
                        PlanPillFlow {
                            listOf("auto" to "Upper otomatis", "off" to "Upper mati", "1" to "Upper 1×", "2" to "Upper 2×").forEach { (k, label) ->
                                PlanPill(label, sUp == k, { sUp = k })
                            }
                        }
                    }
                }
                err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                if (s.rtype != "pb" && (s.pbConv?.wk ?: 0) > 0) {
                    PlanConvInfo(wk = s.pbConv!!.wk, onUndo = { PbConversion.undo(s)?.let { onSave(it) } })
                }
                PlanActionRow(
                    weeks = previewOk?.weeks?.size,
                    km = previewOk?.weeks?.sumOf { it.km },
                    showRace = s.rtype == "pb" && rtype == "pb",
                    onRace = { showRaceDialog = true },
                    onRecalc = {
                        val dd = draftSettings()
                        if (dd == null) err = "Periksa format tanggal dan angka."
                        else { err = null; onSave(dd) }
                    },
                )
            }
            if (showRaceDialog) {
                PlanPbRaceDialog(
                    settings = s,
                    onDismiss = { showRaceDialog = false },
                    onApply = { n -> showRaceDialog = false; onSave(n) },
                )
            }

            }
            "Tampilan" -> {
                DisplaySection(androidx.compose.ui.platform.LocalContext.current, onOpenStickers)
            }
            "Profil" -> {
                ProfilePage(
                    state = state,
                    profileName = profileName, profilePhotoUri = profilePhotoUri,
                    onEditName = onEditProfileName, onPickPhoto = onPickProfilePhoto,
                    onSave = onSave, onSyncHrZones = onSyncHrZones,
                    watchStatus = watchAdvancedMessage, watchSyncing = watchSyncing,
                    onSaveGear = onSaveGear, onDeleteGear = onDeleteGear,
                    onOpenFitness = { onOpenProgressDock("Fitness") },
                    onOpenPlan = { profileSection = "Rencana" },
                )
            }
            "Kondisi" -> {
            CompanionDataSection(
                daily = state.daily,
                onSaveDaily = onSaveDaily,
            )

            }
            "Nyeri & cedera" -> {
                PainInjurySettingsSection()
            }
            "Cuaca" -> {
            WeatherSettingsSection(
                snapshot = weatherSnapshot, placeLabel = weatherPlaceLabel, busy = weatherBusy, error = weatherError, notice = weatherNotice,
                message = weatherMessage, lat = weatherLat, lon = weatherLon, watchStatus = weatherWatchStatus, watchBusy = weatherWatchBusy, watchNote = weatherWatchNote,
                onRefresh = onRefreshWeather, onApplyCoords = onFetchWeather, onSearchCity = onSearchWeatherCity, onUseLocation = onUseWeatherLocation, onWeatherToWatch = onWeatherToWatch,
            )
            }
            "AI Coach" -> {
            AiCoachSettingsSection(aiStatus = aiStatus, onAiKey = onAiKey, aiModel = aiModel, aiModels = aiModels, onAiModel = onAiModel)
            }
            "Cadangan" -> {
            Text("Cadangan", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 16.dp))
            Text("Cadangan data lengkap", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 4.dp))
            Text(
                "Simpan semua data aplikasi ke satu berkas .zip: aktivitas beserta rute dan grafik, data jam (tidur, langkah, HR, HRV, workout), catatan harian, gear, pengaturan, dan foto profil. API key AI Coach dan kunci pairing jam tidak ikut disimpan karena berkasnya tidak terenkripsi; masukkan ulang dan pasangkan jam lagi setelah pindah ponsel.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            EvButton(
                modifier = full,
                enabled = backupUi !is BackupUi.Working,
                onClick = { exportBackupLauncher.launch(backupFileName()) },
            ) { Text("Cadangkan data") }
            OutlinedButton(
                modifier = full,
                enabled = backupUi !is BackupUi.Working,
                onClick = { restoreBackupPicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) },
            ) { Text("Pulihkan dari cadangan") }
            when (backupUi) {
                is BackupUi.Working -> {
                    Text(backupUi.label, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                }
                is BackupUi.Done -> {
                    Text(backupUi.message, color = MaterialTheme.colorScheme.primary)
                    if (backupUi.restored) {
                        Text(
                            "Muat ulang tampilan agar semua layar membaca data hasil pemulihan. Bila ada yang belum berubah, tutup aplikasi sepenuhnya lalu buka lagi.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        EvButton(modifier = full, onClick = {
                            onDismissBackup()
                            generateSequence(hostContext) { (it as? android.content.ContextWrapper)?.baseContext }
                                .filterIsInstance<android.app.Activity>().firstOrNull()?.recreate()
                        }) { Text("Muat ulang tampilan") }
                    } else {
                        TextButton(onClick = onDismissBackup) { Text("Tutup") }
                    }
                }
                is BackupUi.Failed -> {
                    Text(backupUi.message, color = MaterialTheme.colorScheme.error)
                    TextButton(onClick = onDismissBackup) { Text("Tutup") }
                }
                else -> {}
            }
            Text("Pemeliharaan aktivitas", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp))
            Text("Cari aktivitas ganda pada tanggal dan jenis olahraga yang sama. Penggabungan mempertahankan detail jam/rute dan catatan manual bila tersedia.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(modifier = full, onClick = { onScanDuplicates(); showDuplicateConfirm = true }) { Text("Periksa aktivitas ganda") }
            if (duplicateStatus.isNotBlank()) Text(duplicateStatus, color = MaterialTheme.colorScheme.primary)
            Text("Impor aktivitas dari berkas", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp))
            Text(
                "Tambahkan aktivitas lama dari berkas FIT, GPX, atau TCX (boleh pilih banyak berkas sekaligus). Tanggal dan jam diambil dari isi berkas, jadi aktivitas masuk ke tanggal aslinya beserta rute dan grafik. Berkas yang sudah ada dilewati.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            val trackBusy = trackMsg?.startsWith("Membaca") == true
            OutlinedButton(
                modifier = full,
                enabled = !trackBusy,
                onClick = { trackPicker.launch(arrayOf("*/*")) },
            ) { Text(if (trackBusy) "Membaca berkas…" else "Impor FIT / GPX / TCX") }
            Text(
                "Punya ekspor data dari Huawei Health (HUAWEI_HEALTH_….zip dari Pusat Privasi Huawei)? Pilih zip-nya langsung, tanpa perlu diekstrak. Yang dibaca hanya folder Motion path detail data: lari, sepeda, dan hiking GPS masuk ke tanggal aslinya beserta rute, HR, dan ketinggian. Zip yang dienkripsi butuh kata sandi dari Huawei.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedButton(
                modifier = full,
                enabled = !trackBusy,
                onClick = { huaweiZipPicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream", "*/*")) },
            ) { Text(if (trackBusy) "Membaca berkas…" else "Impor zip Huawei Health") }
            if (!trackMsg.isNullOrBlank()) Text(trackMsg, color = if (trackMsg.contains("Gagal")) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
            if (trackMsg?.contains("kata sandi") == true && lastHuaweiZip != null && !trackBusy) {
                TextButton(onClick = { huaweiZipPw = ""; huaweiZipPick = lastHuaweiZip }) { Text("Coba kata sandi lain") }
            }
            Text("Impor cadangan versi web", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp))
            Text(
                "Impor berkas cadangan dari versi web (.json) untuk memulihkan pengaturan rencana dan catatan lari.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedButton(
                modifier = full,
                enabled = importUi !is ImportUi.Working,
                onClick = { picker.launch(arrayOf("application/json", "text/plain", "application/octet-stream")) },
            ) { Text(if (importUi is ImportUi.Working) "Membaca berkas…" else "Impor cadangan web") }
            when (importUi) {
                is ImportUi.Done -> Text(importUi.message, color = MaterialTheme.colorScheme.primary)
                is ImportUi.Failed -> Text(importUi.message, color = MaterialTheme.colorScheme.error)
                else -> {}
            }            }
        }

    }

    huaweiZipPick?.let { zipUri ->
        AlertDialog(
            onDismissRequest = { huaweiZipPick = null },
            title = { Text("Impor zip Huawei Health") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Masukkan kata sandi zip dari Huawei (dikirim lewat SMS atau email saat ekspor). Kosongkan bila zip tidak berkata sandi.")
                    OutlinedTextField(
                        value = huaweiZipPw, onValueChange = { huaweiZipPw = it },
                        label = { Text("Kata sandi zip") }, singleLine = true,
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = { TextButton(onClick = { val pw = huaweiZipPw; huaweiZipPick = null; huaweiZipPw = ""; onImportHuaweiZip(zipUri, pw) }) { Text("Impor") } },
            dismissButton = { TextButton(onClick = { huaweiZipPick = null; huaweiZipPw = "" }) { Text("Batal") } },
        )
    }

    if (showDuplicateConfirm) AlertDialog(
        onDismissRequest = { showDuplicateConfirm = false },
        title = { Text("Hasil pemeriksaan aktivitas ganda") },
        text = {
            Text(
                (duplicateStatus.ifBlank { "Pemeriksaan sedang berjalan…" }) +
                    "\\n\\nAturan aplikasi lama: tanggal dan jenis olahraga harus sama; waktu mulai berbeda maksimal 1 menit (presisi native), atau tanpa waktu mulai jarak berbeda kurang dari 0,1 km dan durasi kurang dari 2 menit. Aktivitas dengan detail jam/rute diprioritaskan. Pastikan pasangan yang ditampilkan memang sesi yang sama sebelum menggabungkan."
            )
        },
        confirmButton = {
            TextButton(
                enabled = duplicateStatus.startsWith("Ditemukan "),
                onClick = { showDuplicateConfirm = false; onMergeDuplicates() }
            ) { Text("Gabungkan kandidat") }
        },
        dismissButton = { TextButton(onClick = { showDuplicateConfirm = false }) { Text("Tutup") } },
    )

    if (importUi is ImportUi.Confirm) {
        val b = importUi.backup
        AlertDialog(
            onDismissRequest = onDismissImport,
            title = { Text("Pulihkan cadangan?") },
            text = {
                Text(
                    "Ditemukan ${b.activities.size} catatan lari, ${b.doneDays} hari selesai, ${b.daily.size} catatan harian, ${b.gear.size} gear, dan pengaturan rencana" +
                        (if (b.settings.name.isNotBlank()) " \"${b.settings.name}\"" else "") + ".\n\nPengaturan rencana saat ini akan ditimpa, begitu juga catatan hasil impor sebelumnya. Catatan yang Anda buat di aplikasi ini tidak diubah." +
                        (if (b.detailCount > 0) "\n\n${b.detailCount} detail aktivitas (rute GPS) ikut tersimpan di berkas dan akan dibaca pada tahap berikutnya." else ""),
                )
            },
            confirmButton = { TextButton(onClick = onConfirmImport) { Text("Pulihkan") } },
            dismissButton = { TextButton(onClick = onDismissImport) { Text("Batal") } },
        )
    }

    if (backupUi is BackupUi.Confirm) {
        val b = backupUi.summary
        val whenText = if (b.createdAt > 0) java.text.SimpleDateFormat("d MMM yyyy, HH:mm", com.endurancevault.app.ui.i18n.Lang.locale).format(java.util.Date(b.createdAt)) else "tidak diketahui"
        AlertDialog(
            onDismissRequest = onDismissBackup,
            title = { Text("Pulihkan cadangan?") },
            text = {
                Text(
                    "Cadangan dibuat $whenText" + (if (b.appVersion.isNotBlank()) " (aplikasi ${b.appVersion})" else "") + ".\n\nIsi: ${b.activities} aktivitas (${b.activityDetails} dengan rute dan grafik), ${b.sleepSegments} segmen tidur, ${b.stepSamples} sampel langkah/HR, ${b.watchWorkouts} workout jam, ${b.daily} catatan harian, ${b.gear} gear, pengaturan" + (if (b.hasPhoto) ", dan foto profil" else "") + ".\n\nSEMUA data saat ini akan diganti dengan isi cadangan ini. Sebelumnya aplikasi otomatis menyimpan salinan pengaman dari data sekarang (2 salinan terakhir disimpan di penyimpanan aplikasi).",
                )
            },
            confirmButton = { TextButton(onClick = onConfirmRestore) { Text("Ganti data & pulihkan") } },
            dismissButton = { TextButton(onClick = onDismissBackup) { Text("Batal") } },
        )
    }
}


@Composable
private fun TimelineActivityCard(
    activity: com.endurancevault.app.data.ActivityEntity,
    detail: com.endurancevault.app.domain.ActDetail?,
    onClick: () -> Unit,
) {
    val type = activity.type.lowercase()
    val title = activity.name.ifBlank {
        when (type) {
            "bike", "cycling", "cycle" -> "Bersepeda"
            "strength", "workout", "gym" -> "Strength"
            "swim", "swimming" -> "Renang"
            "hike", "walking", "walk" -> "Hiking"
            else -> "Lari"
        }
    }
    val duration = activity.durationSec.coerceAtLeast(0)
    val timeText = "${duration / 3600}:${(duration % 3600 / 60).toString().padStart(2, '0')}:${(duration % 60).toString().padStart(2, '0')}"
    val isBike = type in listOf("bike", "cycling", "cycle")
    val isStrength = type in listOf("strength", "workout", "gym")
    val isSwim = type in listOf("swim", "swimming")
    val avgHrText = (detail?.hr ?: activity.avgHr)?.let { "$it bpm" } ?: "—"
    val gainMeters = detail?.gain ?: activity.gain
    val paceOrSpeed = when {
        isBike -> if (duration > 0 && activity.km > 0) "${String.format(java.util.Locale.US, "%.1f", activity.km / (duration / 3600.0))} km/j" else "—"
        isSwim -> if (activity.km > 0 && duration > 0) {
            val sec100 = duration / (activity.km * 10.0)
            "${(sec100 / 60).toInt()}:${(sec100 % 60).toInt().toString().padStart(2, '0')} /100 m"
        } else "—"
        else -> if (activity.km > 0 && duration > 0) {
            val secKm = duration / activity.km
            "${(secKm / 60).toInt()}:${(secKm % 60).toInt().toString().padStart(2, '0')} /km"
        } else "—"
    }
    // Ambang elevasi: 15 meter per kilometer. Tepat pada ambang masih menampilkan pace.
    val showElevationInsteadOfPace = !isBike && !isSwim && !isStrength &&
        activity.km > 0 && gainMeters != null && gainMeters > activity.km * 15.0
    val thirdLabel = when {
        isBike -> "Speed"
        showElevationInsteadOfPace -> "Elevation gain"
        else -> "Pace"
    }
    val thirdValue = if (showElevationInsteadOfPace) "${gainMeters} m" else paceOrSpeed
    val metrics = when {
        isStrength -> listOf("Time" to timeText, "Avg HR" to avgHrText)
        else -> listOf(
            "Time" to timeText,
            "Distance" to "${String.format(java.util.Locale.US, "%.2f", activity.km)} km",
            thirdLabel to thirdValue,
            "Avg HR" to avgHrText,
        )
    }
    androidx.compose.material3.Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
    ) {
        Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                val readableDate = runCatching { java.time.LocalDate.parse(activity.dateIso.take(10)).format(java.time.format.DateTimeFormatter.ofPattern("d MMMM yyyy", com.endurancevault.app.ui.i18n.Lang.locale)) }.getOrDefault(activity.dateIso)
                val wx = detail?.weather
                val wxText = wx?.let {
                    val condition = when (it.code) { 0 -> "Clear"; 1 -> "Mostly clear"; 2 -> "Partly cloudy"; 3 -> "Overcast"; 45, 48 -> "Fog"; 51, 53, 55, 61, 63, 65, 80, 81, 82 -> "Rain"; 71, 73, 75, 77, 85, 86 -> "Snow"; 95, 96, 99 -> "Thunderstorm"; else -> "" }
                    val glyph = when (it.code) { 0, 1 -> "☀"; 2, 3, 45, 48 -> "☁"; 71, 73, 75, 77, 85, 86 -> "❄"; 95, 96, 99 -> "⛈"; else -> "🌧" }
                    " $glyph ${it.tempC.toInt()}°C $condition"
                }?.trimEnd()
                Text(listOf(readableDate, activity.startTime.orEmpty()).filter { it.isNotBlank() }.joinToString(" · ") + (if (!wxText.isNullOrBlank()) " $wxText" else ""), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                metrics.forEach { (label, value) ->
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
            if (detail?.hasMap == true) {
                androidx.compose.material3.HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f))
                DRouteMapView(detail)
            }
        }
    }
}

@Composable
private fun ProfileHomeTabs(selected: String, onSelect: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 2.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("Profile", "Timeline").forEach { tab ->
            val active = selected == tab
            androidx.compose.material3.Surface(
                modifier = Modifier.weight(1f).height(42.dp).clickable { onSelect(tab) },
                shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
                color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                border = if (active) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            ) { Box(contentAlignment = Alignment.Center) { Text(tab, color = if (active) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.titleSmall) } }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ProfileTodaySection(
    state: UiState,
    onSaveDaily: (DailyEntity) -> Unit,
    onSaveSettings: (PlanSettings) -> Unit,
    onOpenProgress: (String) -> Unit,
) {
    val today = LocalDate.now()
    val context = LocalContext.current
    val readinessHistory = remember(context, state.daily, state.activities) { com.endurancevault.app.data.ReadinessHistoryStore.load(context).takeLast(7) }
    val metrics = remember(state.settings, state.activities, state.daily, state.plan, state.hrHistByActivity) {
        com.endurancevault.app.domain.TrainingMetrics.calculate(
            state.settings, state.activities, state.daily, state.plan, today,
            hrHistByActivity = state.hrHistByActivity,
        )
    }
    val readiness = metrics.readiness
    val todayPlan = (state.plan as? com.endurancevault.app.domain.PlanOutcome.Ok)
        ?.weeks?.asSequence()?.flatMap { it.days.asSequence() }?.firstOrNull { it.date == today }
    val nextStrengthDay = (state.plan as? com.endurancevault.app.domain.PlanOutcome.Ok)
        ?.weeks?.asSequence()?.flatMap { it.days.asSequence() }
        ?.filter { !it.date.isBefore(today) && listOfNotNull(it.str, it.ank, it.up).isNotEmpty() }
        ?.minByOrNull { it.date }
    val strengthDay = todayPlan?.takeIf { listOfNotNull(it.str, it.ank, it.up).isNotEmpty() } ?: nextStrengthDay
    var suggestionExpanded by remember { mutableStateOf(true) }
    var morningExpanded by remember { mutableStateOf(false) }
    var strengthExpanded by remember { mutableStateOf(false) }
    var morningDateText by remember { mutableStateOf(today.toString()) }
    val morningDate = remember(morningDateText) { runCatching { LocalDate.parse(morningDateText) }.getOrNull() }
    val selectedDaily = state.daily.firstOrNull { it.dateIso == (morningDate?.toString() ?: today.toString()) }
    var legFeel by remember(morningDateText, selectedDaily?.leg) {
        mutableStateOf(selectedDaily?.leg?.toString() ?: "")
    }
    var mood by remember(morningDateText, selectedDaily?.mood) {
        mutableStateOf(selectedDaily?.mood?.toString() ?: "")
    }
    var morningError by remember { mutableStateOf<String?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OnTrackCard(state, metrics, onOpenProgress)
        EvGroupTitle("TODAY", today.format(java.time.format.DateTimeFormatter.ofPattern("EEE, d MMM", java.util.Locale.ENGLISH)))
        EvPanel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    when {
                        readiness == null -> "Training readiness belum tersedia"
                        readiness.score >= 80 -> "Today: continue as planned"
                        readiness.score >= 60 -> "Today: keep the effort controlled"
                        else -> "Today: prioritize recovery"
                    },
                    style = MaterialTheme.typography.titleMedium,
                )
                if (readiness != null) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text(readiness.score.toString(), style = MaterialTheme.typography.displaySmall, color = MaterialTheme.colorScheme.tertiary)
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("${readiness.tier.uppercase()} · ${readiness.parts.count { it.score != null }} faktor", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.tertiary)
                            Text(readiness.advice, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    if (readinessHistory.isNotEmpty()) {
                        val avg = readinessHistory.map { it.score }.average().roundToInt()
                        val previous = readinessHistory.dropLast(1).lastOrNull()?.score
                        val delta = previous?.let { readiness.score - it }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            androidx.compose.foundation.Canvas(Modifier.weight(1f).height(28.dp)) {
                                val values = readinessHistory.map { it.score.toFloat() } + readiness.score.toFloat()
                                val lo = (values.minOrNull() ?: 0f) - 5f; val hi = (values.maxOrNull() ?: 100f) + 5f
                                val step = if (values.size > 1) size.width / (values.size - 1) else 0f
                                val points = values.mapIndexed { i, v -> androidx.compose.ui.geometry.Offset(i * step, size.height - ((v - lo) / (hi - lo).coerceAtLeast(1f)) * size.height) }
                                for (i in 1 until points.size) drawLine(Color(0xFF388765), points[i-1], points[i], strokeWidth = 2.dp.toPx())
                                points.forEach { drawCircle(Color(0xFF388765), radius = 3.dp.toPx(), center = it) }
                            }
                            Text("7-day trend · average $avg${delta?.let { " · today ${if (it >= 0) "+" else ""}$it" } ?: ""}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    readiness.parts.filter { it.score != null }.take(7).forEach { part ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(part.label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("${part.score}/100", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                } else {
                    Text("Isi kondisi pagi atau catat aktivitas agar readiness dapat dihitung dari data yang tersedia.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }


        if (strengthDay != null) {
            val blocks = listOfNotNull(strengthDay.str, strengthDay.ank, strengthDay.up)
            val title = when {
                blocks.size > 1 -> "Strength Session"
                else -> blocks.first().title
            }
            EvPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("STRENGTH RECOMMENDATION", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    Text(title, style = MaterialTheme.typography.titleLarge)
                    if (strengthDay.date != today) {
                        Text("Jadwal berikutnya · ${strengthDay.date}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(blocks.joinToString("  ·  ") { "${it.title} · ${it.mins} mnt" }, style = MaterialTheme.typography.bodyMedium)
                    TextButton(onClick = { strengthExpanded = !strengthExpanded }, contentPadding = PaddingValues(0.dp)) {
                        Text(if (strengthExpanded) "Sembunyikan gerakan" else "Lihat set · ${blocks.sumOf { it.lines.size }} gerakan")
                    }
                    if (strengthExpanded) blocks.forEach { block ->
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(block.title, style = MaterialTheme.typography.titleSmall)
                            Text(block.note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            block.lines.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                }
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("SUGGESTIONS", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            EvPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        Modifier.fillMaxWidth().clickable { suggestionExpanded = !suggestionExpanded },
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(if (suggestionExpanded) "▾ Saran latihan" else "▸ Saran latihan", style = MaterialTheme.typography.titleSmall)
                        Text(if (suggestionExpanded) "Tutup" else "Buka", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    }
                    if (suggestionExpanded) {
                        val weekStart = today.with(java.time.DayOfWeek.MONDAY)
                        val weekKm = state.activities.filter { it.type != "bike" && it.km > 0 && it.dateIso >= weekStart.toString() && it.dateIso <= today.toString() }.sumOf { it.km }
                        val weekPlan = (state.plan as? com.endurancevault.app.domain.PlanOutcome.Ok)?.weeks?.firstOrNull { it.start == weekStart }
                        Text("Penyesuaian beban yang mengikuti rencana latihan aktif.", style = MaterialTheme.typography.bodyMedium)
                        Text("Jarak minggu ini: ${fmtKmUi(weekKm)} km${weekPlan?.let { " / ${fmtKmUi(it.km)} km rencana" } ?: ""}.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        val lightActive = state.settings.weekScale < .999 && state.settings.weekScaleWeek == weekStart
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            androidx.compose.material3.OutlinedButton(onClick = { onSaveSettings(state.settings.copy(weekScale = if (lightActive) 1.0 else .7, weekScaleWeek = if (lightActive) null else weekStart)) }) {
                                Text(if (lightActive) "Batalkan minggu ringan" else "Light week (70%)")
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            androidx.compose.material3.OutlinedButton(onClick = {
                                val active = state.settings.sickUntil?.let { !it.isBefore(today) } == true
                                onSaveSettings(state.settings.copy(sickUntil = if (active) null else today.plusDays(2), weekScale = 1.0, weekScaleWeek = null))
                            }) { Text(if (state.settings.sickUntil?.let { !it.isBefore(today) } == true) "Batalkan mode sakit" else "Sick/injured: rest 3 days") }
                        }
                        Text("Mode sakit menjadikan tiga hari ke depan sebagai istirahat dan mengurangi 20% sesi tersisa setelahnya. Minggu ringan mengurangi sesi yang belum selesai menjadi 70%.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.weight(1f)) { Text("Auto-adjust", style = MaterialTheme.typography.titleSmall); Text("Sesi easy berikutnya diringankan setelah lari dadakan atau lari jauh melebihi rencana. Kualitas dan long run tidak diubah.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                            Switch(checked = state.settings.autoAdjust, onCheckedChange = { onSaveSettings(state.settings.copy(autoAdjust = it)) })
                        }
                        if (metrics.planAdjustment != null) Text(metrics.planAdjustment.reason, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }

        EvPanel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    Modifier.fillMaxWidth().clickable { morningExpanded = !morningExpanded },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("MORNING CONDITION", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        Text("Kondisi pagi", style = MaterialTheme.typography.titleLarge)
                    }
                    Text(if (morningExpanded) "⌃" else "⌄", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                val latest = state.daily.firstOrNull { it.dateIso == today.toString() } ?: state.daily.maxByOrNull { it.dateIso }
                if (latest == null) {
                    Text("Data tidur akan muncul setelah sinkronisasi jam.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    val raw = remember(latest.raw) { runCatching { org.json.JSONObject(latest.raw) }.getOrDefault(org.json.JSONObject()) }
                    val watchRaw = raw.optJSONObject("watch") ?: org.json.JSONObject()
                    fun rawValue(key: String): String {
                        val number = raw.optDouble(key, Double.NaN).takeIf { it.isFinite() && it > 0 }
                            ?: when (key) {
                                "ssp" -> watchRaw.optDouble("sleepSpo2", Double.NaN).takeIf { it.isFinite() && it > 0 }
                                "srr" -> watchRaw.optDouble("sleepResp", Double.NaN).takeIf { it.isFinite() && it > 0 }
                                else -> null
                            }
                        return number?.let { if (it == kotlin.math.floor(it)) it.toInt().toString() else "%.1f".format(it) } ?: "–"
                    }
                    val priorDaily = state.daily.filter { it.dateIso < latest.dateIso }.sortedBy { it.dateIso }.takeLast(28)
                    fun averageOf(values: List<Double>): String? = values.filter { it.isFinite() && it > 0 }.takeIf { it.isNotEmpty() }?.average()?.let { "avg ${"%.1f".format(it)}" }
                    val rhrAvg = averageOf(priorDaily.mapNotNull { it.rhr?.toDouble() })
                    val sleepAvg = averageOf(priorDaily.mapNotNull { it.sleepH })
                    val hrvAvg = averageOf(priorDaily.mapNotNull { it.hrv?.toDouble() })
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MorningValue("RESTING HR", latest.rhr?.toString() ?: rawValue("rhr"), "bpm", rhrAvg)
                        MorningValue("SLEEP", latest.sleepH?.let { "%.1f".format(it) } ?: rawValue("sleep"), "h", sleepAvg)
                        MorningValue("HRV", latest.hrv?.toString() ?: rawValue("hrv"), "ms", hrvAvg)
                    }
                    val sleepHr = raw.optDouble("shr", Double.NaN).takeIf { it.isFinite() && it > 0 }
                        ?: watchRaw.optDouble("sleepHr", Double.NaN).takeIf { it.isFinite() && it > 0 }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MorningValue("SLEEP HR", sleepHr?.toInt()?.toString() ?: "–", "bpm")
                        MorningValue("NAP", rawValue("nap"), "min")
                        MorningValue("SLEEP SpO₂", rawValue("ssp"), "%")
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MorningValue("SLEEP RESP.", rawValue("srr"), "br/min")
                        MorningValue("LEG FEEL", latest.leg?.toString() ?: "–", "/5")
                        MorningValue("MOOD", latest.mood?.toString() ?: "–", "/5")
                    }
                }
                if (morningExpanded) {
                OutlinedTextField(
                    value = morningDateText, onValueChange = { morningDateText = it.take(10) },
                    label = { Text("DATE · yyyy-MM-dd") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                Text("LEG FEEL THIS MORNING", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    listOf("Segar", "Baik", "Normal", "Berat", "Sangat berat").forEachIndexed { index, label ->
                        val selected = legFeel == (index + 1).toString()
                        androidx.compose.material3.Surface(
                            modifier = Modifier.height(48.dp).clickable { legFeel = (index + 1).toString() },
                            shape = RoundedCornerShape(16.dp),
                            color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                        ) {
                            Box(Modifier.padding(horizontal = 18.dp), contentAlignment = Alignment.Center) {
                                Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold,
                                    color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
                Text("STRESS / MOOD THIS MORNING", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("😄", "🙂", "😐", "😟", "😣").forEachIndexed { index, emoji ->
                        val selected = mood == (index + 1).toString()
                        androidx.compose.material3.Surface(
                            modifier = Modifier.weight(1f).height(68.dp).clickable { mood = (index + 1).toString() },
                            shape = RoundedCornerShape(16.dp),
                            color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                Text(emoji, fontSize = 28.sp, lineHeight = 32.sp)
                                Text((index + 1).toString(), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
                morningError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                EvButton(
                    onClick = {
                        val legValue = legFeel.toIntOrNull()
                        val moodValue = mood.toIntOrNull()
                        if (morningDate == null) {
                            morningError = "Tanggal harus berformat yyyy-MM-dd."
                        } else if (legValue == null || legValue !in 1..5 || moodValue == null || moodValue !in 1..5) {
                            morningError = "Isi Leg feel dan Mood dengan angka 1 sampai 5."
                        } else {
                            morningError = null
                            val existing = selectedDaily
                            onSaveDaily(
                                DailyEntity(
                                    dateIso = morningDate.toString(),
                                    rhr = existing?.rhr,
                                    hrv = existing?.hrv,
                                    leg = legValue,
                                    mood = moodValue,
                                    sleepH = existing?.sleepH,
                                    raw = existing?.raw ?: "{}",
                                )
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Simpan kondisi pagi") }
                } else {
                    TextButton(onClick = { morningExpanded = true }, contentPadding = PaddingValues(0.dp)) { Text("Add data") }
                }
            }
        }
    }
}

@Composable
private fun OnTrackCard(state: UiState, metrics: com.endurancevault.app.domain.TrainingMetricsResult, onOpenProgress: (String) -> Unit) {
    val today = LocalDate.now()
    val plan = state.plan as? com.endurancevault.app.domain.PlanOutcome.Ok
    val monday = today.with(java.time.DayOfWeek.MONDAY)
    val week = plan?.weeks?.firstOrNull { it.start == monday }
    val actualKm = state.activities.filter { it.type != "bike" && it.km > 0 && it.dateIso >= monday.toString() && it.dateIso <= today.toString() }.sumOf { it.km }
    val volumePct = week?.km?.takeIf { it > 0 }?.let { actualKm / it * 100.0 }
    val planned = plan?.weeks?.flatMap { it.days }?.filter { it.date <= today && it.kind !in setOf("rest", "race", "event") }.orEmpty()
    val done = planned.count { day -> state.activities.any { it.type != "bike" && it.dateIso == day.date.toString() } }
    val consistency = if (planned.size >= 3) done * 100.0 / planned.size else null
    val currentFitness = metrics.fitness.toDouble()
    val oldFitness = metrics.days.lastOrNull { !it.date.isAfter(today.minusDays(28)) }?.fitness?.toDouble()
    val fitDelta = oldFitness?.let { currentFitness - it }
    val acwr = com.endurancevault.app.domain.ProgressAnalytics.acuteChronic(metrics.days, today)
    val ratio = acwr?.ratio?.takeIf { it.isFinite() && it > 0 }
    data class Signal(val name: String, val value: String, val pct: Float, val level: Int, val tab: String)
    val signals = buildList {
        volumePct?.let { val level = if (it in 85.0..125.0) 0 else if (it >= 70) 1 else 2; add(Signal("Volume", "${it.roundToInt()}% dari rencana", (it/100).coerceIn(0.03,1.0).toFloat(), level, "Rekap")) }
        consistency?.let { val level = if (it >= 85) 0 else if (it >= 70) 1 else 2; add(Signal("Consistency", "$done dari ${planned.size} sesi", (it/100).coerceIn(0.03,1.0).toFloat(), level, "Rekap")) }
        fitDelta?.let { val rel = if (oldFitness != null && oldFitness > 0) it / oldFitness else 0.0; val level = if (rel >= -.03) 0 else if (rel >= -.10) 1 else 2; add(Signal("Fitness", (if (it >= 0) "naik " else "turun ") + "${kotlin.math.abs(it).roundToInt()} poin", (currentFitness/100).coerceIn(0.03,1.0).toFloat(), level, "Fitness")) }
        ratio?.let { val level = if (it < .8 || it <= 1.3) 0 else if (it <= 1.5) 1 else 2; add(Signal("Training load", "ACWR ${"%.2f".format(it)} · ${when { it < .8 -> "Low"; it <= 1.3 -> "Sweet spot"; it <= 1.5 -> "Caution"; else -> "Spike" }}", (it/1.6).coerceIn(0.03,1.0).toFloat(), level, "Load")) }
    }
    val red = signals.count { it.level == 2 }; val amber = signals.count { it.level == 1 }
    val verdict = when { signals.size < 2 -> "Belum cukup data"; red > 0 || amber >= 2 -> "Perlu penyesuaian"; amber == 1 -> "On track, satu hal dijaga"; else -> "On track" }
    val color = when { signals.size < 2 -> MaterialTheme.colorScheme.onSurfaceVariant; red > 0 || amber >= 2 -> MaterialTheme.colorScheme.error; amber == 1 -> MaterialTheme.colorScheme.tertiary; else -> Color(0xFF388765) }
    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("AM I ON TRACK?", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 1.4.sp)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.size(11.dp).clip(CircleShape).background(color))
                Text(verdict, style = MaterialTheme.typography.headlineSmall, color = color)
            }
            Text(
                when { signals.size < 2 -> "Aktifkan rencana dan catat beberapa sesi agar status dapat dinilai."; red > 0 || amber >= 2 -> "Ada beberapa indikator yang perlu diperhatikan. Jangan mengejar sesi yang terlewat sekaligus."; amber == 1 -> "Sebagian besar indikator masih baik. Jaga faktor yang belum ideal."; else -> "Kamu berada di jalur rencana. Volume, konsistensi, fitness, dan beban latihan masih seimbang." },
                style = MaterialTheme.typography.bodyMedium,
            )
            signals.forEach { sig ->
                Column(Modifier.fillMaxWidth().clickable { onOpenProgress(sig.tab) }.padding(vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(9.dp).clip(CircleShape).background(if (sig.level == 0) Color(0xFF388765) else if (sig.level == 1) Color(0xFFE0A33B) else MaterialTheme.colorScheme.error))
                        Text(sig.name, modifier = Modifier.weight(1f).padding(start = 10.dp), style = MaterialTheme.typography.titleSmall)
                        Text(sig.value, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("  ›", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    LinearProgressIndicator(progress = { sig.pct }, modifier = Modifier.fillMaxWidth().padding(start = 20.dp), color = if (sig.level == 0) Color(0xFF388765) else if (sig.level == 1) Color(0xFFE0A33B) else MaterialTheme.colorScheme.error, trackColor = MaterialTheme.colorScheme.surfaceVariant)
                }
                androidx.compose.material3.HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf("Rekap", "Fitness", "Load", "Routes", "Body").forEach { tab ->
                    FilterChip(selected = false, onClick = { onOpenProgress(tab) }, label = { Text(when(tab) { "Rekap" -> "Recap"; "Routes" -> "Routes & conditions"; else -> tab }) })
                }
            }
        }
    }
}

@Composable
private fun RowScope.MorningValue(label: String, value: String, unit: String, average: String? = null) {
    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(value, style = MaterialTheme.typography.titleLarge)
            if (unit.isNotBlank()) Text(unit, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        average?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}


@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PainInjurySettingsSection() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("readiness_settings", android.content.Context.MODE_PRIVATE) }
    fun readEntries(): List<PainReadinessEntry> = runCatching {
        val arr = org.json.JSONArray(prefs.getString("pain_entries", "[]"))
        (0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i)?.let { o ->
            val rawArea = o.optString("area", "")
            val area = mapOf("Betis" to "betis", "Tulang kering" to "tibia", "Ankle" to "ankle", "Achilles" to "achilles", "Tumit" to "tumit", "Plantar" to "plantar", "Punggung kaki" to "pkaki", "Lutut" to "lutut", "IT band" to "itband", "Paha depan" to "pahad", "Paha belakang" to "pahab", "Pangkal paha" to "groin", "Glute" to "glute", "Punggung bawah" to "pbawah", "Bahu" to "bahu").entries.firstOrNull { it.key.equals(rawArea, true) }?.value ?: rawArea.lowercase()
            val rawSide = o.optString("side", "b")
            val side = mapOf("Kiri" to "k", "Kanan" to "r", "Keduanya" to "b").entries.firstOrNull { it.key.equals(rawSide, true) }?.value ?: rawSide
            PainReadinessEntry(LocalDate.parse(o.getString("date")), area, o.optInt("severity", 1), side, o.optString("when", "sl"))
        } }
    }.getOrDefault(emptyList())
    var entries by remember { mutableStateOf(readEntries()) }
    var area by remember { mutableStateOf("") }
    var side by remember { mutableStateOf("k") }
    var severity by remember { mutableStateOf(3) }
    var moment by remember { mutableStateOf("sl") }
    val today = LocalDate.now()
    fun persist(next: List<PainReadinessEntry>) {
        entries = next.takeLast(300)
        val arr = org.json.JSONArray()
        entries.forEach { e -> arr.put(org.json.JSONObject().put("date", e.date.toString()).put("area", e.area).put("severity", e.severity).put("side", e.side).put("when", e.whenTag)) }
        prefs.edit().putString("pain_entries", arr.toString()).apply()
    }
    LaunchedEffect(Unit) { entries = readEntries() }
    EvGroupTitle("Nyeri dan cedera", "Catat lokasi, sisi, tingkat, dan kapan nyeri muncul. Data ini digunakan oleh Training Readiness dan pencegahan cedera.")
    InjuryPrevention.groups.forEach { group ->
        Text(group.title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            group.areas.forEach { (id, label) -> FilterChip(selected = area == id, onClick = { area = if (area == id) "" else id }, label = { Text(label) }) }
        }
    }
    Text("Sisi", style = MaterialTheme.typography.labelMedium)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        InjuryPrevention.sides.forEach { (id, label) -> FilterChip(selected = side == id, onClick = { side = id }, label = { Text(label) }) }
    }
    Text("Tingkat nyeri · 1 ringan sampai 5 berat", style = MaterialTheme.typography.labelMedium)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { (1..5).forEach { v -> FilterChip(selected = severity == v, onClick = { severity = v }, label = { Text("$v") }) } }
    Text("Muncul saat", style = MaterialTheme.typography.labelMedium)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        InjuryPrevention.moments.forEach { (id, label) -> FilterChip(selected = moment == id, onClick = { moment = id }, label = { Text(label) }) }
    }
    EvButton(onClick = {
        val entry = PainReadinessEntry(today, area, severity, side, moment)
        persist(entries.filterNot { it.date == today && it.area == area && it.side == side } + entry)
        area = ""
    }, enabled = area.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Simpan catatan") }
    val alerts = InjuryPrevention.alerts(entries, today)
    if (alerts.isNotEmpty()) {
        EvGroupTitle("Peringatan berulang", "Area dengan nyeri ≥2 pada 3 dari 4 hari, atau ≥4 dalam dua hari terakhir")
        alerts.forEach { Text("${InjuryPrevention.areaName(it.area)} · ${it.days}/4 hari · puncak ${it.maxSeverity}/5", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
    }
    InjuryPrevention.prehab(entries, today)?.let { advice ->
        EvGroupTitle("Saran prehab · ${InjuryPrevention.areaName(advice.area)}", "Saran umum sesuai area yang paling perlu diperhatikan")
        advice.exercises.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
        Text(advice.caution, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    EvGroupTitle("Riwayat nyeri", "Enam catatan terakhir")
    entries.sortedByDescending { it.date }.take(6).forEach { e ->
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(InjuryPrevention.areaName(e.area), style = MaterialTheme.typography.bodyMedium)
                Text("${e.date} · ${InjuryPrevention.sideName(e.side)} · ${e.severity}/5 · ${InjuryPrevention.momentName(e.whenTag)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = { persist(entries - e) }) { Text("Hapus") }
        }
    }
    Text("Catatan nyeri membantu penyesuaian latihan, bukan diagnosis. Hentikan aktivitas yang memperburuk nyeri dan minta penilaian tenaga kesehatan bila nyeri berat, menetap, atau membatasi fungsi.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}
