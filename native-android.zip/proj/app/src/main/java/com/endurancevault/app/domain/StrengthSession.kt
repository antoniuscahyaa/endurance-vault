package com.endurancevault.app.domain

import org.json.JSONObject
import java.time.LocalDate
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sin

/**
 * Sesi strength live: mengubah blok strength rencana (judul, catatan, daftar baris gerakan) menjadi urutan
 * langkah yang bisa dijalankan satu per satu (set kerja, ganti sisi, istirahat) dengan animasi pemandu.
 * Tanpa Android dan tanpa Compose supaya bisa dites langsung di JVM.
 */

/** Gerakan yang punya animasi pemandu, beserta tempo satu repetisi dan tiga isyarat teknik singkat. */
enum class GuideMove(val tempoMs: Int, val cues: List<String>) {
    SQUAT(4000, listOf("Dada tegak, turun sampai paha hampir sejajar lantai", "Lutut searah jari kaki, tumit tetap menapak", "Dorong lantai untuk berdiri")),
    HINGE(4000, listOf("Dorong pinggul ke belakang, punggung tetap lurus", "Beban dekat paha dan tulang kering", "Rasakan tarikan di belakang paha")),
    SL_RDL(4000, listOf("Kaki belakang dan badan satu garis", "Pinggul tetap rata, jangan membuka", "Lutut tumpu sedikit menekuk")),
    LUNGE(4000, listOf("Kaki belakang di bangku, badan tegak", "Turun lurus, lutut depan tidak masuk ke dalam", "Dorong dengan tumit kaki depan")),
    STEP(5000, listOf("Turun pelan, sekitar 3 detik", "Lutut searah jari kaki", "Panggul tetap rata, tidak jatuh ke sisi")),
    CALF(4000, listOf("Naik setinggi mungkin lalu tahan sebentar", "Turun pelan sampai tumit lebih rendah dari tepi", "Gerak dari pergelangan, bukan memantul")),
    PLANK(4000, listOf("Tubuh satu garis dari kepala sampai tumit", "Kencangkan perut dan bokong", "Napas teratur, jangan menahan")),
    SIDE_PLANK(4000, listOf("Panggul terangkat, tubuh satu garis", "Siku tepat di bawah bahu", "Jangan memutar badan ke depan atau belakang")),
    PUSH(3000, listOf("Tubuh lurus, siku sekitar 45 derajat dari badan", "Turun sampai dada hampir menyentuh lantai", "Dorong kuat sampai lengan lurus")),
    ROW(3000, listOf("Punggung rata, tarik siku ke arah pinggul", "Jangan memutar badan", "Turunkan beban pelan sampai lengan lurus")),
    PRESS(3000, listOf("Perut kencang, punggung bawah jangan melengkung", "Dorong lurus ke atas, dekat telinga", "Turun terkendali sampai setinggi bahu")),
    BRIDGE(3000, listOf("Dorong lewat tumit, angkat panggul", "Tahan sebentar di atas, kencangkan bokong", "Tulang rusuk turun, punggung bawah tidak melengkung")),
    BAND_WALK(3000, listOf("Setengah jongkok, lutut tidak masuk ke dalam", "Langkah ke samping, karet tetap tegang", "Badan tetap tegak, tidak miring")),
    TIBIALIS(3000, listOf("Punggung bersandar di dinding, tumit sedikit di depan", "Angkat ujung kaki setinggi mungkin", "Turun pelan dan terkendali")),
    BAND_ANKLE(3000, listOf("Gerak pelan, hanya dari pergelangan kaki", "Lutut diam, karet tetap tegang", "Berhenti bila terasa nyeri")),
    BALANCE(4000, listOf("Tatap satu titik di depan", "Lutut sedikit menekuk", "Goyang itu wajar, jangan menurunkan kaki")),
    HOP(1500, listOf("Lompat kecil dari pergelangan kaki", "Lutut hampir lurus, mendarat ringan", "Tumit nyaris tidak menyentuh lantai")),
    CARRY(2000, listOf("Bahu turun, dada terbuka", "Langkah pendek dan stabil", "Genggam kuat, badan tidak miring")),
    DEADBUG(4000, listOf("Punggung bawah menempel lantai", "Gerakkan tangan dan kaki yang berlawanan", "Pelan sambil membuang napas")),
    PALLOF(3000, listOf("Berdiri tegak, jangan ikut berputar", "Dorong tangan lurus ke depan", "Tahan sebentar, kembali pelan")),
    FACEPULL(3000, listOf("Tarik ke arah dahi, siku tinggi", "Rapatkan tulang belikat", "Kembali pelan, bahu tetap turun")),
    PULL(4000, listOf("Turunkan bahu dulu, lalu tarik siku ke bawah", "Dada naik ke arah beban", "Naik pelan sampai lengan lurus")),
    GENERIC(4000, listOf("Gerak pelan dan terkendali", "Napas teratur", "Berhenti bila terasa nyeri")),
}

/**
 * Satu baris gerakan dari blok strength.
 * @param reps target repetisi (batas atas bila rentang); null untuk gerakan tahan/jarak atau baris yang tak terbaca.
 * @param repsLabel teks repetisi seperti di rencana ("10", "6–8"); null bila bukan repetisi.
 * @param holdSec lama tahan dalam detik; untuk jarak (m) dihitung 1 detik per meter.
 * @param unit "dtk", "m", atau null.
 * @param perSide true bila dikerjakan di tiap sisi (per kaki / per sisi).
 */
class LiveExercise(
    val name: String, val move: GuideMove, val sets: Int,
    val reps: Int?, val repsLabel: String?, val holdSec: Int?, val unit: String?,
    val perSide: Boolean, val sideWord: String?, val tempoMs: Int, val raw: String,
) {
    val timed: Boolean get() = holdSec != null
    /** Target ringkas untuk tampilan, mis. "10", "6–8", "40 dtk", "30 m". */
    val targetText: String get() = when {
        holdSec != null && unit == "m" -> "$holdSec m"
        holdSec != null -> "$holdSec dtk"
        repsLabel != null -> repsLabel
        else -> ""
    }
    fun sideLabel(side: Int?): String? = when {
        side == null || sideWord == null -> null
        sideWord == "kaki" -> if (side == 0) "Kaki kiri" else "Kaki kanan"
        else -> if (side == 0) "Sisi kiri" else "Sisi kanan"
    }
}

sealed interface LiveStep {
    /** Satu set kerja. [side] 0 = kiri, 1 = kanan, null = tanpa sisi. */
    class Work(val ex: Int, val set: Int, val setCount: Int, val side: Int?) : LiveStep
    /** Istirahat; [switchSide] true untuk jeda singkat berpindah sisi dalam set yang sama. [nextEx] = indeks gerakan berikutnya. */
    class Rest(val seconds: Int, val switchSide: Boolean, val nextEx: Int) : LiveStep
}

class LivePlan(val exercises: List<LiveExercise>, val steps: List<LiveStep>, val restSec: Int) {
    val workCount: Int = steps.count { it is LiveStep.Work }
}

/** Hasil sesi yang disimpan ke riwayat (kunci "swo" dan, bila terkait rencana, centang "done"). */
class LiveResult(val startEpochSec: Long, val dateIso: String, val minutes: Int, val key: String?)

/** Sesi yang siap dijalankan: blok, kunci rencana ("tanggal:s|a|u", null untuk sesi bebas), dan label. */
class LiveLaunch(val block: StrengthBlock, val key: String?, val label: String)

/** Rekomendasi dari rencana: blok strength/ankle/upper yang belum selesai pada hari tertentu. */
class StrengthSuggestion(val date: LocalDate, val key: String, val tag: String, val block: StrengthBlock)

object StrengthLive {
    const val SWITCH_SEC = 5
    const val LEAD_MS = 3000L
    private const val SPORT_STRENGTH = 140

    private val LINE = Regex("""^(.*?)\s+(\d+)\s*[×x]\s*(\d+)(?:[–-](\d+))?\s*(dtk|m)?(?:\s+per\s+(kaki|sisi))?(?:,\s*turun\s+(\d+)\s*dtk)?\s*$""")
    private val REST = Regex("""Istirahat\s+(\d+)\s*dtk""")

    /** Mengenali gerakan dari namanya. Urutan pemeriksaan penting (side plank sebelum plank, pallof sebelum press, dst). */
    fun classify(name: String): GuideMove {
        val n = name.lowercase()
        return when {
            "side plank" in n -> GuideMove.SIDE_PLANK
            "plank" in n -> GuideMove.PLANK
            "single-leg rdl" in n || "single leg rdl" in n -> GuideMove.SL_RDL
            "romanian" in n || "rdl" in n || "deadlift" in n -> GuideMove.HINGE
            "bulgarian" in n || "split squat" in n -> GuideMove.LUNGE
            "step-up" in n || "step-down" in n || "step up" in n || "step down" in n -> GuideMove.STEP
            "squat" in n -> GuideMove.SQUAT
            "hip thrust" in n || "bridge" in n -> GuideMove.BRIDGE
            "calf" in n -> GuideMove.CALF
            "push-up" in n || "push up" in n -> GuideMove.PUSH
            "pulldown" in n || "pull-up" in n || "pull up" in n -> GuideMove.PULL
            "face pull" in n || "reverse fly" in n -> GuideMove.FACEPULL
            "pallof" in n -> GuideMove.PALLOF
            "row" in n -> GuideMove.ROW
            "press" in n -> GuideMove.PRESS
            "band walk" in n -> GuideMove.BAND_WALK
            "tibialis" in n -> GuideMove.TIBIALIS
            "eversi" in n || "inversi" in n || "dorsifleksi" in n -> GuideMove.BAND_ANKLE
            "keseimbangan" in n -> GuideMove.BALANCE
            "pogo" in n || "hop" in n -> GuideMove.HOP
            "farmer" in n || "carry" in n -> GuideMove.CARRY
            "dead bug" in n -> GuideMove.DEADBUG
            else -> GuideMove.GENERIC
        }
    }

    /**
     * Membaca satu baris seperti "Bulgarian split squat 3×8 per kaki" atau "Plank 3×40 dtk".
     * Baris yang tak cocok pola tetap jadi gerakan 1 set tanpa target (dikerjakan manual), tidak pernah gagal.
     */
    fun parseLine(line: String): LiveExercise {
        val m = LINE.matchEntire(line.trim())
        if (m == null) {
            return LiveExercise(line.trim(), classify(line), 1, null, null, null, null, false, null, classify(line).tempoMs, line)
        }
        val name = m.groupValues[1].trim()
        val sets = m.groupValues[2].toInt().coerceIn(1, 10)
        val lo = m.groupValues[3].toInt()
        val hi = m.groupValues[4].toIntOrNull()
        val unit = m.groupValues[5].ifEmpty { null }
        val sideWord = m.groupValues[6].ifEmpty { null }
        val slowDown = m.groupValues[7].toIntOrNull()
        val move = classify(name)
        val target = hi ?: lo
        val label = if (hi != null) "$lo–$hi" else "$lo"
        // "turun 3 dtk": fase turun lambat, jadi satu repetisi memakan waktu lebih lama dari bawaan gerakan
        val tempo = if (slowDown != null) slowDown * 1000 + 1500 else move.tempoMs
        return if (unit != null) {
            LiveExercise(name, move, sets, null, null, target, unit, sideWord != null, sideWord, tempo, line)
        } else {
            LiveExercise(name, move, sets, target, label, null, null, sideWord != null, sideWord, tempo, line)
        }
    }

    /** Istirahat antar set: dari catatan blok ("Istirahat 90 dtk"), kalau tak ada pakai bawaan sesuai jenis sesi. */
    fun restSeconds(b: StrengthBlock): Int {
        REST.find(b.note)?.groupValues?.get(1)?.toIntOrNull()?.let { return it.coerceIn(15, 300) }
        return when {
            b.title.startsWith("Strength ankle") -> 40
            b.note.startsWith("Ringan") -> 45
            else -> 60
        }
    }

    /** Menyusun urutan langkah. Per kaki/sisi: kiri, jeda 5 dtk, kanan; istirahat penuh hanya setelah set lengkap. */
    fun build(b: StrengthBlock): LivePlan {
        val exs = b.lines.map(::parseLine)
        val rest = restSeconds(b)
        val steps = ArrayList<LiveStep>()
        exs.forEachIndexed { ei, ex ->
            for (set in 1..ex.sets) {
                val sides = if (ex.perSide) listOf(0, 1) else listOf<Int?>(null)
                sides.forEachIndexed { si, side ->
                    steps += LiveStep.Work(ei, set, ex.sets, side)
                    if (si < sides.size - 1) steps += LiveStep.Rest(SWITCH_SEC, true, ei)
                }
                val last = ei == exs.size - 1 && set == ex.sets
                if (!last) steps += LiveStep.Rest(rest, false, if (set == ex.sets) ei + 1 else ei)
            }
        }
        return LivePlan(exs, steps, rest)
    }

    /** Jeda persiapan sebelum set pertama dimulai (hitung mundur); set berikutnya sudah didahului istirahat. */
    fun leadMs(stepIndex: Int): Long = if (stepIndex == 0) LEAD_MS else 0L

    /**
     * Rekomendasi dari rencana untuk hari ini sampai [horizon] hari ke depan, yang belum selesai (centang manual
     * atau tertaut sesi jam, lewat [doneKeys]). Urut tanggal, lalu strength, upper, ankle.
     */
    fun suggest(plan: PlanOutcome, doneKeys: Set<String>, today: LocalDate, horizon: Int = 6): List<StrengthSuggestion> {
        val ok = plan as? PlanOutcome.Ok ?: return emptyList()
        val end = today.plusDays(horizon.toLong())
        val out = ArrayList<StrengthSuggestion>()
        ok.weeks.flatMap { it.days }.filter { !it.date.isBefore(today) && !it.date.isAfter(end) }.sortedBy { it.date }.forEach { d ->
            listOf(Triple(d.str, "s", "GYM"), Triple(d.up, "u", "UPPER"), Triple(d.ank, "a", "ANKLE")).forEach { (blk, suffix, tag) ->
                val key = "${d.date}:$suffix"
                if (blk != null && key !in doneKeys && blk.adj?.type != "skip" && blk.adj?.type != "out") {
                    out += StrengthSuggestion(d.date, key, tag, blk)
                }
            }
        }
        return out
    }

    /** Fase minggu ini (untuk sesi bebas yang mengikuti beban fase); BASE bila rencana kosong atau di luar rentang. */
    fun currentPhase(plan: PlanOutcome, today: LocalDate): String {
        val ok = plan as? PlanOutcome.Ok ?: return Phases.BASE
        return ok.weeks.firstOrNull { !today.isBefore(it.start) && !today.isAfter(it.end) }?.phase ?: Phases.BASE
    }

    /** Sesi bebas (tidak terkait rencana): Strength A dan B, upper, dan ankle, mengikuti fase saat ini. */
    fun freeOptions(plan: PlanOutcome, today: LocalDate): List<LiveLaunch> {
        val ph = currentPhase(plan, today)
        return listOf(
            LiveLaunch(strengthFor("A", ph, false), null, "Strength A"),
            LiveLaunch(strengthFor("B", ph, false), null, "Strength B"),
            LiveLaunch(upperFor(1, ph, false), null, "Upper"),
            LiveLaunch(ankleFor(ph), null, "Ankle"),
        )
    }

    /** Baris riwayat "swo": tertaut rencana (k) bila ada kunci, selain itu sesi bebas (f). Jenis olahraga 140 = strength. */
    fun entryJson(r: LiveResult): JSONObject = JSONObject().apply {
        put("s", r.startEpochSec)
        put("d", r.dateIso)
        put("m", r.minutes)
        put("t", SPORT_STRENGTH)
        if (r.key != null) put("k", r.key) else put("f", true)
    }
}

/**
 * Profil gerak manekin dalam satu repetisi: turun lambat, tahan sebentar, naik lebih cepat dengan dorongan awal.
 * Tiap repetisi sedikit berbeda (kedalaman, saat berhenti turun, lama tahan) dari benih indeks repetisi, jadi
 * hasilnya selalu sama untuk waktu yang sama (bisa dites) tetapi tidak terkesan mesin. Panjang siklus tetap [tempoMs]
 * supaya selaras dengan hitungan repetisi sesi.
 */
object GuideMotion {
    private fun frac(x: Double): Float = (abs(x) % 1.0).toFloat()
    private fun smooth(x: Float): Float { val c = x.coerceIn(0f, 1f); return c * c * (3f - 2f * c) }

    /** 0 = pose awal, 1 = pose akhir; selalu kembali ke 0 di batas repetisi. */
    fun phase(tMs: Long, tempoMs: Int): Float {
        if (tMs < 0L || tempoMs <= 0) return 0f
        val rep = (tMs / tempoMs).toInt()
        val c = (tMs % tempoMs).toFloat() / tempoMs
        val r1 = frac(sin(rep * 12.9898) * 43758.5453)
        val r2 = frac(sin(rep * 78.233) * 12345.6)
        val depth = 0.9f + 0.1f * r2
        val down = 0.42f + 0.04f * r1
        val hold = down + 0.07f + 0.05f * r2
        val end = 0.95f
        return when {
            c < down -> smooth(c / down).pow(1.15f) * depth
            c < hold -> depth
            c < end -> {
                val x = (c - hold) / (end - hold)
                depth * (1f - (x.pow(0.7f) * 0.5f + smooth(x) * 0.5f))
            }
            else -> 0f
        }
    }
}
