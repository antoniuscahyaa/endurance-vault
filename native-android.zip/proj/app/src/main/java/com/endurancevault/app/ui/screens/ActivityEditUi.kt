package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.i18n.Text
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.Icon
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import com.endurancevault.app.ui.floating.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.data.GearEntity
import com.endurancevault.app.domain.ActCrop
import com.endurancevault.app.domain.ActEdit
import com.endurancevault.app.domain.ActInsights
import com.endurancevault.app.domain.ActivityTimeSeries
import com.endurancevault.app.domain.Js
import com.endurancevault.app.ui.theme.Ember
import kotlinx.coroutines.launch

/** Konfirmasi hapus. Aktivitas dari jam tidak akan diimpor lagi pada sinkron berikutnya. */
@Composable
internal fun ConfirmDeleteDialog(e: ActivityEntity, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    val fromWatch = e.srcKey.startsWith("watch:") || ActEdit.isWatchNote(e.note)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Hapus aktivitas ini?") },
        text = {
            Text(
                "${trimNum(e.km, 2)} km · ${e.dateIso}" + (e.startTime?.let { " · $it" } ?: "") + "\n\nAktivitas beserta rute dan grafiknya dihapus permanen dan tidak bisa dikembalikan. Statistik pekan, beban latihan, dan jarak sepatu ikut dihitung ulang." +
                    if (fromWatch) "\n\nAktivitas ini berasal dari jam dan tidak akan diimpor lagi saat sinkron." else "",
            )
        },
        confirmButton = { TextButton(onClick = onConfirm) { Text("Hapus", color = MaterialTheme.colorScheme.error) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
    )
}

/** Edit ala Strava: nama, deskripsi, tipe, tanggal, jam mulai. */
@Composable
internal fun EditActivityDialog(
    e: ActivityEntity,
    onSave: suspend (name: String, description: String, type: String, dateIso: String, startTime: String) -> String?,
    onDismiss: () -> Unit,
    gear: List<GearEntity> = emptyList(),
    onSetGear: (Long, String?) -> Unit = { _, _ -> },
    onAddGear: ((GearEntity) -> Unit)? = null,
) {
    var name by remember { mutableStateOf(e.name) }
    var desc by remember { mutableStateOf(ActEdit.userNote(e.note)) }
    var type by remember { mutableStateOf(if (e.type == "bike") "bike" else "run") }
    var date by remember { mutableStateOf(e.dateIso.take(10)) }
    var time by remember { mutableStateOf(e.startTime.orEmpty()) }
    var gearId by remember { mutableStateOf(e.gearId) }
    var gearOpen by remember { mutableStateOf(false) }
    // sepatu yang baru ditambah dari dialog ini; ditampilkan segera walau daftar [gear] dari database belum menyusul
    var addedGear by remember { mutableStateOf(emptyList<GearEntity>()) }
    var addingGear by remember { mutableStateOf(false) }
    var newGearName by remember { mutableStateOf("") }
    var newGearLimit by remember { mutableStateOf("800") }
    val allGear = gear + addedGear.filter { a -> gear.none { it.id == a.id } }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("Edit aktivitas") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nama") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(desc, { desc = it }, label = { Text("Deskripsi") }, minLines = 2, maxLines = 5, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = type == "run", onClick = { type = "run" }, label = { Text("Lari") })
                    FilterChip(selected = type == "bike", onClick = { type = "bike" }, label = { Text("Sepeda") })
                }
                OutlinedTextField(date, { date = it }, label = { Text("Tanggal (yyyy-MM-dd)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(time, { time = it }, label = { Text("Jam mulai (HH:mm)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                if (type == "run") {
                    // Selalu tampil untuk lari (dulu disembunyikan bila belum ada gear); tampilan sama dengan isian lain.
                    val current = allGear.firstOrNull { it.id == gearId }
                    val shown = when {
                        current != null -> current.name + if (current.retired) " (pensiun)" else ""
                        allGear.isEmpty() -> "Belum ada sepatu"
                        else -> "Tanpa gear"
                    }
                    Box {
                        OutlinedTextField(
                            shown, {}, readOnly = true, singleLine = true, enabled = allGear.isNotEmpty(),
                            label = { Text("Gear sepatu") },
                            trailingIcon = { Icon(Icons.Filled.ArrowDropDown, null) },
                            modifier = Modifier.fillMaxWidth(),
                        )
                        if (allGear.isNotEmpty()) Box(Modifier.matchParentSize().clickable { gearOpen = true })
                        DropdownMenu(expanded = gearOpen, onDismissRequest = { gearOpen = false }) {
                            DropdownMenuItem(text = { Text("Tanpa gear") }, onClick = { gearOpen = false; gearId = null })
                            allGear.filter { !it.retired || it.id == e.gearId }.forEach { g ->
                                DropdownMenuItem(text = { Text(g.name + if (g.retired) " (pensiun)" else "") }, onClick = { gearOpen = false; gearId = g.id })
                            }
                        }
                    }
                    if (onAddGear != null) {
                        if (!addingGear) {
                            TextButton(onClick = { addingGear = true }) { Text("+ Tambah sepatu baru") }
                        } else {
                            val limit = newGearLimit.replace(',', '.').toDoubleOrNull()
                            OutlinedTextField(newGearName, { newGearName = it }, label = { Text("Nama sepatu") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(
                                newGearLimit, { newGearLimit = it }, label = { Text("Batas km (0=tanpa)") }, singleLine = true,
                                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal),
                                modifier = Modifier.fillMaxWidth(),
                            )
                            Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                                TextButton(onClick = { addingGear = false; newGearName = "" }) { Text("Batal") }
                                TextButton(
                                    enabled = newGearName.isNotBlank() && limit != null && limit >= 0,
                                    onClick = {
                                        val g = GearEntity(java.util.UUID.randomUUID().toString(), newGearName.trim(), "", 0.0, limit ?: 0.0)
                                        onAddGear(g)
                                        addedGear = addedGear + g
                                        gearId = g.id
                                        addingGear = false; newGearName = ""; newGearLimit = "800"
                                    },
                                ) { Text("Tambah") }
                            }
                        }
                    }
                }
                Text(
                    "Gear dan rasa setelah lari juga bisa diubah langsung di halaman detail. Mengubah tipe ke sepeda melepas gear sepatu.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(
                enabled = !busy,
                onClick = {
                    busy = true; error = null
                    scope.launch {
                        val err = onSave(name, desc, type, date, time)
                        // gear disimpan setelah data lain tersimpan (editActivity menulis ulang baris aktivitas); sepeda tidak punya gear
                        if (err == null && type == "run" && gearId != e.gearId) onSetGear(e.id, gearId)
                        busy = false
                        if (err == null) onDismiss() else error = err
                    }
                },
            ) { Text(if (busy) "Menyimpan…" else "Simpan") }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("Batal") } },
    )
}

/** Profil elevasi (atau HR bila tanpa altitude) dengan bagian yang akan dibuang diredupkan. */
@Composable
private fun CropProfile(ts: ActivityTimeSeries, startSec: Float, endSec: Float) {
    val series = remember(ts) { cropProfileSeries(ts) }
    val maxSec = ts.seconds.last().coerceAtLeast(1).toFloat()
    val muted = MaterialTheme.colorScheme.outline
    val shade = MaterialTheme.colorScheme.onSurface.copy(alpha = .14f)
    Canvas(Modifier.fillMaxWidth().height(96.dp).padding(horizontal = 10.dp)) {
        val w = size.width; val h = size.height
        if (series.size >= 2) {
            val lo = series.minOf { it.second }
            val span = (series.maxOf { it.second } - lo).coerceAtLeast(1f)
            val pad = 6.dp.toPx()
            fun at(p: Pair<Float, Float>) = Offset(p.first / maxSec * w, h - pad - (p.second - lo) / span * (h - 2 * pad))
            fun line(points: List<Pair<Float, Float>>): Path {
                val path = Path()
                points.forEachIndexed { i, p -> val o = at(p); if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y) }
                return path
            }
            drawPath(line(series), muted, style = Stroke(width = 2.dp.toPx()))
            val kept = series.filter { it.first >= startSec && it.first <= endSec }
            if (kept.size >= 2) drawPath(line(kept), Ember, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        val xs = (startSec / maxSec * w).coerceIn(0f, w)
        val xe = (endSec / maxSec * w).coerceIn(0f, w)
        drawRect(shade, Offset(0f, 0f), Size(xs, h))
        drawRect(shade, Offset(xe, 0f), Size(w - xe, h))
    }
}

private fun cropProfileSeries(ts: ActivityTimeSeries): List<Pair<Float, Float>> {
    val elev = ts.seconds.indices.mapNotNull { i -> ts.elevationMeters[i]?.let { ts.seconds[i].toFloat() to it.toFloat() } }
    val hr = ts.seconds.indices.filter { ts.heartRateBpm[it] > 0 }.map { ts.seconds[it].toFloat() to ts.heartRateBpm[it].toFloat() }
    val raw = if (elev.size >= 2) elev else hr
    if (raw.size <= 240) return raw
    val step = raw.size / 240.0
    return (0 until 240).map { raw[(it * step).toInt()] } + raw.last()
}

/**
 * Editor crop: dua gagang (awal dan akhir) pada sumbu waktu bergerak, pratinjau jarak/waktu/pace hasilnya,
 * lalu simpan lewat [onSave] (detik awal, detik akhir) yang mengembalikan null bila berhasil atau pesan galat.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun CropEditor(
    ts: ActivityTimeSeries, bike: Boolean,
    onSave: suspend (startSec: Int, endSec: Int) -> String?,
    onClose: () -> Unit,
) {
    val maxSec = ts.seconds.last()
    var range by remember(ts) { mutableStateOf(0f..maxSec.toFloat()) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val startSec = Math.round(range.start)
    val endSec = Math.round(range.endInclusive)
    val w = ActCrop.window(ts, startSec, endSec)
    val totalM = ts.distanceMeters.last() - ts.distanceMeters.first()
    val changed = startSec > 0 || endSec < maxSec

    fun nudge(startDelta: Float, endDelta: Float) {
        val s = (range.start + startDelta).coerceIn(0f, maxSec.toFloat())
        val e = (range.endInclusive + endDelta).coerceIn(0f, maxSec.toFloat())
        if (e - s >= 1f) range = s..e
    }

    Text("Crop aktivitas", style = MaterialTheme.typography.titleMedium)
    Text(
        "Geser gagang untuk membuang bagian awal atau akhir (misalnya menunggu lampu merah atau berjalan ke mobil). Bagian oranye yang dipertahankan.",
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(vertical = 12.dp, horizontal = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            CropProfile(ts, range.start, range.endInclusive)
            RangeSlider(
                value = range, onValueChange = { range = it }, valueRange = 0f..maxSec.toFloat(),
                modifier = Modifier.fillMaxWidth(),
            )
            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Awal ${Js.durStr(startSec / 60.0)}", style = MaterialTheme.typography.labelMedium)
                Text("Akhir ${Js.durStr(endSec / 60.0)}", style = MaterialTheme.typography.labelMedium)
            }
        }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton({ nudge(-5f, 0f) }, Modifier.weight(1f)) { Text("Awal −5 dtk", maxLines = 1) }
        OutlinedButton({ nudge(5f, 0f) }, Modifier.weight(1f)) { Text("Awal +5 dtk", maxLines = 1) }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton({ nudge(0f, -5f) }, Modifier.weight(1f)) { Text("Akhir −5 dtk", maxLines = 1) }
        OutlinedButton({ nudge(0f, 5f) }, Modifier.weight(1f)) { Text("Akhir +5 dtk", maxLines = 1) }
    }

    if (w != null) {
        val pace = ActCrop.previewPace(w)
        EvMetricRow(
            listOf(
                "Jarak" to trimNum(w.meters / 1000.0, 2) + " km",
                "Waktu" to Js.durStr(w.seconds / 60.0),
                (if (bike) "Kecepatan" else "Pace") to
                    (pace?.let { if (bike) ActInsights.dec(60 / it) + " km/j" else Js.paceStr(it) + "/km" } ?: "–"),
            ),
        )
        val before = ts.distanceMeters[w.i0] - ts.distanceMeters.first()
        val after = ts.distanceMeters.last() - ts.distanceMeters[w.i1]
        DCaption("Dibuang: ${Math.round(before)} m di awal dan ${Math.round(after)} m di akhir dari total ${trimNum(totalM / 1000.0, 2)} km.")
        if (!w.valid) Text("Hasil crop minimal 1 menit dan 200 m.", color = MaterialTheme.colorScheme.error)
    }
    DCaption(
        "Jarak, waktu, pace, GAP, HR, kadens, elevasi, split, dan zona dihitung ulang dari bagian yang dipertahankan. Angka training effect, recovery, dan baterai dari jam dibuang karena dihitung jam untuk sesi utuh; aplikasi memperkirakan ulang. Jam mulai aktivitas tidak berubah. Crop tidak bisa dibatalkan.",
    )
    error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = onClose, enabled = !busy, modifier = Modifier.weight(1f)) { Text("Batal") }
        Button(
            onClick = { confirm = true }, enabled = !busy && changed && w?.valid == true, modifier = Modifier.weight(1f),
        ) { Text(if (busy) "Menyimpan…" else "Simpan crop") }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Simpan crop?") },
            text = { Text("Bagian yang dibuang hilang permanen dari aktivitas ini dan tidak bisa dikembalikan.") },
            confirmButton = {
                TextButton(onClick = {
                    confirm = false; busy = true; error = null
                    scope.launch {
                        val err = onSave(startSec, endSec)
                        busy = false
                        if (err == null) onClose() else error = err
                    }
                }) { Text("Simpan") }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Batal") } },
        )
    }
}
