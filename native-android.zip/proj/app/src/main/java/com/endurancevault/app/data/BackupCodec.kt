package com.endurancevault.app.data

import org.json.JSONArray
import org.json.JSONObject

/**
 * Bagian murni (tanpa Android) dari cadangan lengkap native: pengodean baris Room ke JSON, pengodean
 * SharedPreferences bertipe, dan validasi nama entri zip. Dipisah agar bisa diuji di JVM.
 */
object BackupCodec {
    const val FORMAT = "endurancevault-backup"
    const val VERSION = 1

    /**
     * SharedPreferences yang ikut dicadangkan. Daftar putih, bukan daftar hitam: berkas lain
     * (terutama `ev_secure` berisi API key AI, serta `huawei_wear_*` berisi kunci pairing jam) tidak pernah ikut,
     * dan berkas cadangan yang dibuat orang lain tidak bisa menimpanya saat dipulihkan.
     */
    val PREF_ALLOWLIST: List<String> = listOf(
        "plan_settings", "readiness_history", "readiness_settings", "week_adjustments_v1",
        "profile_identity", "weather_loc", "rencana_notify", "rl_agps",
        "watch_workout_alerts", "watch_keepalive", "watch_settings",
    )

    /** Nama lama pengaturan jam di cadangan yang dibuat sebelum diganti nama; dipetakan ke nama baru saat dipulihkan. */
    private val LEGACY_PREF_NAMES: Map<String, String> = mapOf("joyofit_settings" to "watch_settings")

    /** Tabel database jam yang tidak dicadangkan (pembukuan sinkronisasi cloud, bisa memuat token akun). */
    val WATCH_EXCLUDED: Set<String> = setOf("cloud_state", "cloud_cursor")

    /** Kunci pengaturan yang ditangani terpisah (foto profil disimpan sebagai berkas, bukan URI perangkat lama). */
    const val PHOTO_PREF = "profile_identity"
    const val PHOTO_KEY = "photo_uri"

    /** Lokasi entri di dalam zip → direktori dan nama berkas di folder staging. */
    class EntryRef(val dir: String, val file: String)

    private val ROOM = Regex("^room/(activity|daily|gear|kv)\\.jsonl$")
    private val ACTS = Regex("^acts/([A-Za-z0-9._-]{1,120}\\.json)$")
    private val WATCH = Regex("^watch/([a-z0-9_]{1,64})\\.jsonl$")
    private val PREFS = Regex("^prefs/([a-z0-9_]{1,64})\\.json$")
    private val WEB = Regex("^web/(cadangan-web-[0-9-]{1,32}\\.json)$")

    /**
     * Kembalikan tujuan aman untuk satu entri zip, atau null bila entri tidak dikenal.
     * Nama berkas tidak pernah diambil mentah dari zip: hanya grup yang cocok pola ketat (tanpa `/`) yang dipakai.
     */
    fun classify(name: String): EntryRef? {
        if (name == "manifest.json") return EntryRef("", "manifest.json")
        if (name == "profile/photo.bin") return EntryRef("profile", "photo.bin")
        ROOM.matchEntire(name)?.let { return EntryRef("room", it.groupValues[1] + ".jsonl") }
        ACTS.matchEntire(name)?.let { return EntryRef("acts", it.groupValues[1]) }
        WATCH.matchEntire(name)?.let { return EntryRef("watch", it.groupValues[1] + ".jsonl") }
        PREFS.matchEntire(name)?.let { m ->
            val raw = m.groupValues[1]
            val n = LEGACY_PREF_NAMES[raw] ?: raw
            return if (n in PREF_ALLOWLIST) EntryRef("prefs", "$n.json") else null
        }
        WEB.matchEntire(name)?.let { return EntryRef("web", it.groupValues[1]) }
        return null
    }

    /* ---------- baris Room ---------- */

    private fun JSONObject.intOrNull(k: String): Int? = if (has(k) && !isNull(k)) optInt(k) else null
    private fun JSONObject.strOrNull(k: String): String? = if (has(k) && !isNull(k)) optString(k) else null
    private fun JSONObject.dblOrNull(k: String): Double? = if (has(k) && !isNull(k)) optDouble(k).takeIf { it.isFinite() } else null
    private fun fin(d: Double) = if (d.isFinite()) d else 0.0

    fun activityToJson(a: ActivityEntity): JSONObject = JSONObject()
        .put("id", a.id).put("dateIso", a.dateIso).put("km", fin(a.km)).put("durationSec", a.durationSec)
        .putOpt("avgHr", a.avgHr).putOpt("feel", a.feel).putOpt("feel10", a.feel10).put("note", a.note).put("srcKey", a.srcKey)
        .put("name", a.name).putOpt("gain", a.gain).putOpt("startTime", a.startTime).putOpt("maxHr", a.maxHr)
        .put("type", a.type).putOpt("gearId", a.gearId).putOpt("detailFile", a.detailFile)

    fun activityFromJson(o: JSONObject): ActivityEntity = ActivityEntity(
        id = o.getLong("id"), dateIso = o.getString("dateIso"),
        km = o.optDouble("km", 0.0).let { fin(it) }, durationSec = o.optInt("durationSec", 0),
        avgHr = o.intOrNull("avgHr"), feel = o.intOrNull("feel"), feel10 = o.intOrNull("feel10"), note = o.optString("note", ""),
        srcKey = o.optString("srcKey", ""), name = o.optString("name", ""),
        gain = o.intOrNull("gain"), startTime = o.strOrNull("startTime"), maxHr = o.intOrNull("maxHr"),
        type = o.optString("type", "run").ifEmpty { "run" }, gearId = o.strOrNull("gearId"),
        detailFile = o.strOrNull("detailFile"),
    )

    fun dailyToJson(d: DailyEntity): JSONObject = JSONObject()
        .put("dateIso", d.dateIso).putOpt("rhr", d.rhr).putOpt("hrv", d.hrv).putOpt("leg", d.leg)
        .putOpt("mood", d.mood).putOpt("sleepH", d.sleepH?.takeIf { it.isFinite() }).put("raw", d.raw)

    fun dailyFromJson(o: JSONObject): DailyEntity = DailyEntity(
        dateIso = o.getString("dateIso"), rhr = o.intOrNull("rhr"), hrv = o.intOrNull("hrv"),
        leg = o.intOrNull("leg"), mood = o.intOrNull("mood"), sleepH = o.dblOrNull("sleepH"),
        raw = o.optString("raw", "{}").ifEmpty { "{}" },
    )

    fun gearToJson(g: GearEntity): JSONObject = JSONObject()
        .put("id", g.id).put("name", g.name).put("model", g.model).put("km0", fin(g.km0))
        .put("limitKm", fin(g.limitKm)).put("retired", g.retired).put("isDefault", g.isDefault)

    fun gearFromJson(o: JSONObject): GearEntity = GearEntity(
        id = o.getString("id"), name = o.getString("name"), model = o.optString("model", ""),
        km0 = fin(o.optDouble("km0", 0.0)), limitKm = fin(o.optDouble("limitKm", 0.0)),
        retired = o.optBoolean("retired", false), isDefault = o.optBoolean("isDefault", false),
    )

    fun kvToJson(k: KvEntity): JSONObject = JSONObject().put("key", k.key).put("json", k.json)
    fun kvFromJson(o: JSONObject): KvEntity = KvEntity(o.getString("key"), o.getString("json"))

    /* ---------- SharedPreferences bertipe ---------- */

    /** Nilai pengaturan hasil dekode: String, Int, Long, Float, Boolean, atau Set<String>. */
    fun prefsToJson(all: Map<String, *>, skip: Set<String> = emptySet()): JSONObject {
        val out = JSONObject()
        for ((k, v) in all) {
            if (k in skip) continue
            val e = JSONObject()
            when (v) {
                is String -> e.put("t", "s").put("v", v)
                is Int -> e.put("t", "i").put("v", v)
                is Long -> e.put("t", "l").put("v", v)
                is Float -> { if (!v.isFinite()) continue; e.put("t", "f").put("v", v.toDouble()) }
                is Boolean -> e.put("t", "b").put("v", v)
                is Set<*> -> e.put("t", "ss").put("v", JSONArray(v.filterIsInstance<String>().sorted()))
                else -> continue
            }
            out.put(k, e)
        }
        return out
    }

    fun prefsFromJson(json: JSONObject): Map<String, Any> {
        val out = LinkedHashMap<String, Any>()
        for (k in json.keys()) {
            val e = json.optJSONObject(k) ?: continue
            val value: Any = when (e.optString("t")) {
                "s" -> e.optString("v", "")
                "i" -> e.optInt("v")
                "l" -> e.optLong("v")
                "f" -> e.optDouble("v").toFloat()
                "b" -> e.optBoolean("v")
                "ss" -> {
                    val arr = e.optJSONArray("v") ?: JSONArray()
                    (0 until arr.length()).map { arr.optString(it) }.toSet()
                }
                else -> continue
            }
            out[k] = value
        }
        return out
    }
}
