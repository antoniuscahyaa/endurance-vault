package com.endurancevault.app.ui.screens

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.BrightnessAuto
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.endurancevault.app.ui.i18n.AppLang
import com.endurancevault.app.ui.i18n.Lang
import com.endurancevault.app.ui.i18n.Text
import com.endurancevault.app.ui.theme.AccentTheme
import com.endurancevault.app.ui.theme.AppFont
import com.endurancevault.app.ui.theme.EvButton
import com.endurancevault.app.ui.theme.ThemeMode
import com.endurancevault.app.ui.theme.ThemePrefs
import com.endurancevault.app.ui.theme.cardTint
import com.endurancevault.app.ui.theme.onCardTint
import com.endurancevault.app.ui.theme.previewPalette
import com.endurancevault.app.widget.WidgetTextPrefs
import kotlin.math.roundToInt

private const val PREVIEW_W_DP = 300
private const val PREVIEW_H_DP = 130

/**
 * Halaman Tampilan versi ringkas: bahasa dan tema dalam satu panel (segmen), sedangkan pilihan visual
 * (tema warna, pratinjau, font) berupa slider horizontal supaya halaman tidak panjang.
 */
@Composable
internal fun DisplaySection(ctx: Context, onOpenStickers: () -> Unit) {
    val cs = MaterialTheme.colorScheme

    // 1) Stiker data: satu baris
    EvPanel(Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(start = 14.dp, end = 10.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Column(Modifier.weight(1f)) {
                Text("Stiker data", style = MaterialTheme.typography.titleSmall)
                Text("Stiker PNG transparan dari data sesi, untuk ditempel di foto", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
            OutlinedButton(onClick = onOpenStickers, contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp)) { Text("Buka") }
        }
    }

    // 2) Bahasa + Tema: dua segmen dalam satu panel
    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Bahasa / Language", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
            val langs = AppLang.values()
            Segmented(langs.map { it.nativeName }, langs.indexOf(Lang.current)) { i ->
                Lang.activityOf(ctx)?.let { a -> Lang.set(a, langs[i]) }
            }
            Spacer(Modifier.height(2.dp))
            Text("Tema", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
            val modes = ThemeMode.values()
            val icons: List<ImageVector?> = modes.map {
                when (it) { ThemeMode.SYSTEM -> Icons.Outlined.BrightnessAuto; ThemeMode.LIGHT -> Icons.Outlined.LightMode; ThemeMode.DARK -> Icons.Outlined.DarkMode }
            }
            Segmented(modes.map { it.label }, modes.indexOf(ThemePrefs.mode), icons) { i -> ThemePrefs.set(ctx, modes[i]) }
        }
    }

    // 3) Tema warna: slider kartu visual
    AccentCarousel(ctx)

    // 4) Pratinjau: slider aplikasi + widget
    PreviewCarousel(ctx)

    // 5) Warna teks widget: chip visual
    WidgetTextColorRow(ctx)

    // 6) Font: slider kartu "Aa"
    FontCarousel(ctx)

    // 7) Ukuran teks: satu panel padat
    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(start = 14.dp, end = 14.dp, top = 6.dp, bottom = 4.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Ukuran teks", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                Text("${(ThemePrefs.fontScale * 100).roundToInt()}%", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                TextButton(onClick = { ThemePrefs.setFontScale(ctx, 1f) }, enabled = ThemePrefs.fontScale != 1f, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp)) { Text("Atur ulang") }
            }
            Slider(
                value = ThemePrefs.fontScale,
                onValueChange = { ThemePrefs.setFontScale(ctx, ((it * 20f).roundToInt() / 20f)) },
                valueRange = 0.85f..1.3f,
                steps = 8,
            )
        }
    }
}

/** Pilihan segmen satu baris; [icons] opsional untuk visualisasi. */
@Composable
private fun Segmented(options: List<String>, selected: Int, icons: List<ImageVector?>? = null, onSelect: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(12.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(cs.surface).border(BorderStroke(0.8.dp, cs.outlineVariant), shape).padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
    ) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            Row(
                Modifier.weight(1f).clip(RoundedCornerShape(9.dp))
                    .background(if (on) cs.primaryContainer else Color.Transparent)
                    .clickable { onSelect(i) }.padding(vertical = 9.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                icons?.getOrNull(i)?.let {
                    Icon(it, contentDescription = null, modifier = Modifier.size(16.dp), tint = if (on) cs.onCardTint else cs.onSurfaceVariant)
                    Spacer(Modifier.width(6.dp))
                }
                Text(label, style = MaterialTheme.typography.labelLarge, color = if (on) cs.onCardTint else cs.onSurface, maxLines = 1)
            }
        }
    }
}

@Composable
private fun AccentCarousel(ctx: Context) {
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < 0.5f
    EvGroupTitle("Tema warna", "Geser untuk melihat pilihan")
    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 2.dp)) {
        items(AccentTheme.values().toList()) { a ->
            AccentCard(a, ThemePrefs.accent == a, dark, ThemePrefs.customColor) { ThemePrefs.setAccent(ctx, a) }
        }
    }
    if (ThemePrefs.accent == AccentTheme.CUSTOM) CustomColorPicker(ThemePrefs.customColor) { ThemePrefs.setCustom(ctx, it) }
}

/** Kartu pilihan tema: miniatur layar (kartu pastel, ring, tombol) memakai palet tema itu. */
@Composable
private fun AccentCard(a: AccentTheme, on: Boolean, dark: Boolean, custom: Int, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val p = previewPalette(a, custom, dark)
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier.width(132.dp).clip(shape).background(cs.surfaceVariant)
            .border(if (on) BorderStroke(2.dp, p.primary) else BorderStroke(0.8.dp, cs.outlineVariant), shape)
            .clickable(onClick = onClick).padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp),
    ) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(cs.background).padding(6.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp),
        ) {
            Box(Modifier.fillMaxWidth().height(30.dp).clip(RoundedCornerShape(7.dp)).background(p.container)) {
                Column(Modifier.padding(start = 7.dp, top = 6.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Box(Modifier.width(46.dp).height(4.dp).clip(CircleShape).background(p.onContainer))
                    Box(Modifier.width(70.dp).height(5.dp).clip(CircleShape).background(p.onContainer.copy(alpha = 0.55f)))
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                p.tones.take(3).forEach { t ->
                    Box(Modifier.weight(1f).height(26.dp).clip(RoundedCornerShape(7.dp)).background(t.container), contentAlignment = Alignment.Center) {
                        Box(Modifier.size(13.dp).border(2.5.dp, t.content, CircleShape))
                    }
                }
            }
            Box(Modifier.fillMaxWidth().height(16.dp).clip(RoundedCornerShape(8.dp)).background(Brush.horizontalGradient(p.gradient)))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(a.label, style = MaterialTheme.typography.labelLarge, color = if (on) cs.onCardTint else cs.onSurface, maxLines = 1, modifier = Modifier.weight(1f))
            if (on) Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(16.dp), tint = p.primary)
        }
    }
}

/** Isi pratinjau aplikasi (kartu sapaan, tiga ring, tombol) dengan tema yang sedang aktif. */
@Composable
private fun AppPreviewContent() {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(cs.cardTint).padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Text("SELAMAT MALAM", style = MaterialTheme.typography.labelMedium, color = cs.onCardTint)
            Text("Besok: Easy run 8 km", style = MaterialTheme.typography.titleMedium)
            Text("Zona 2 · 52 menit", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PreviewRing("TIDUR", 0.82f, "82", 0, Modifier.weight(1f))
            PreviewRing("KESIAPAN", 0.64f, "64", 1, Modifier.weight(1f))
            PreviewRing("ZONA HR", 0.78f, "78%", 2, Modifier.weight(1f))
        }
        EvButton(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("Mulai sesi") }
    }
}

/** Gambar widget gambar (Hari ini / Berikutnya / Pekan) dari renderer yang sama dengan widget asli. */
@Composable
private fun rememberWidgetPreviewImages(ctx: Context): List<ImageBitmap>? {
    val snap by produceState<com.endurancevault.app.widget.WidgetSnapshot?>(null, ctx) {
        value = runCatching {
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                com.endurancevault.app.widget.WidgetData.load(ctx, initLang = false)
            }
        }.getOrNull()
    }
    val systemDark = androidx.compose.foundation.isSystemInDarkTheme()
    return remember(snap, ThemePrefs.accent, ThemePrefs.customColor, ThemePrefs.mode, ThemePrefs.fontScale, systemDark) {
        snap?.let { sn ->
            com.endurancevault.app.widget.WidgetKind.values().map {
                com.endurancevault.app.widget.WidgetRenderer.render(ctx, it, sn, PREVIEW_W_DP, PREVIEW_H_DP).asImageBitmap()
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PreviewCarousel(ctx: Context) {
    val cs = MaterialTheme.colorScheme
    val images = rememberWidgetPreviewImages(ctx)
    val state = rememberLazyListState()
    val pages = 1 + (images?.size ?: 1)
    EvGroupTitle("Pratinjau", "Geser untuk melihat aplikasi dan widget")
    LazyRow(state = state, flingBehavior = rememberSnapFlingBehavior(state), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        item { EvPanel(Modifier.width(290.dp)) { AppPreviewContent() } }
        if (images == null) {
            item { EvPanel(Modifier.width(290.dp)) { Text("Memuat pratinjau…", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, modifier = Modifier.padding(14.dp)) } }
        } else {
            items(images) { img ->
                EvPanel(Modifier.width(290.dp)) {
                    Box(Modifier.padding(8.dp)) {
                        Image(bitmap = img, contentDescription = null, modifier = Modifier.fillMaxWidth().aspectRatio(PREVIEW_W_DP.toFloat() / PREVIEW_H_DP))
                    }
                }
            }
        }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
        val cur = state.firstVisibleItemIndex.coerceIn(0, pages - 1)
        repeat(pages) { i ->
            Box(Modifier.padding(horizontal = 3.dp).size(if (i == cur) 7.dp else 5.dp).clip(CircleShape).background(if (i == cur) cs.primary else cs.outlineVariant))
        }
    }
}

/** Warna teks widget Hari ini: chip bulat (Otomatis, Putih, Gelap, Warna sendiri). */
@Composable
private fun WidgetTextColorRow(ctx: Context) {
    val cs = MaterialTheme.colorScheme
    var mode by remember { mutableStateOf(WidgetTextPrefs.mode(ctx)) }
    var custom by remember { mutableStateOf(WidgetTextPrefs.customColor(ctx)) }
    EvGroupTitle("Warna teks widget", "Hanya mengubah warna font widget Hari ini di layar utama")
    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                listOf(
                    WidgetTextPrefs.Mode.AUTO to "Otomatis",
                    WidgetTextPrefs.Mode.LIGHT to "Putih",
                    WidgetTextPrefs.Mode.DARK to "Gelap",
                    WidgetTextPrefs.Mode.CUSTOM to "Warna sendiri",
                ).forEach { (m, label) ->
                    val on = mode == m
                    Column(
                        Modifier.width(72.dp).clip(RoundedCornerShape(12.dp)).clickable { mode = m; WidgetTextPrefs.setMode(ctx, m) }.padding(vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(5.dp),
                    ) {
                        Box(
                            Modifier.size(40.dp).clip(CircleShape).border(if (on) BorderStroke(2.5.dp, cs.primary) else BorderStroke(0.8.dp, cs.outline), CircleShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            when (m) {
                                WidgetTextPrefs.Mode.AUTO -> Canvas(Modifier.size(40.dp)) {
                                    drawRect(Color.White, size = Size(size.width / 2f, size.height))
                                    drawRect(Color(0xFF1C1B1F), topLeft = androidx.compose.ui.geometry.Offset(size.width / 2f, 0f), size = Size(size.width / 2f, size.height))
                                }
                                WidgetTextPrefs.Mode.LIGHT -> Box(Modifier.size(40.dp).background(Color.White))
                                WidgetTextPrefs.Mode.DARK -> Box(Modifier.size(40.dp).background(Color(0xFF1C1B1F)))
                                WidgetTextPrefs.Mode.CUSTOM -> Box(Modifier.size(40.dp).background(Color(custom)))
                            }
                            if (on) Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(18.dp), tint = if (m == WidgetTextPrefs.Mode.LIGHT || (m == WidgetTextPrefs.Mode.CUSTOM && Color(custom).luminance() > 0.5f)) Color(0xFF1C1B1F) else Color.White)
                        }
                        Text(label, style = MaterialTheme.typography.labelSmall, color = if (on) cs.onCardTint else cs.onSurfaceVariant, textAlign = TextAlign.Center, maxLines = 2)
                    }
                }
            }
            if (mode == WidgetTextPrefs.Mode.CUSTOM) CustomColorPicker(custom) { c -> custom = c; WidgetTextPrefs.setCustom(ctx, c) }
        }
    }
}

@Composable
private fun FontCarousel(ctx: Context) {
    val cs = MaterialTheme.colorScheme
    EvGroupTitle("Font", "Geser untuk melihat pilihan")
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 2.dp)) {
        items(AppFont.values().toList()) { f ->
            val on = ThemePrefs.font == f
            val shape = RoundedCornerShape(14.dp)
            Column(
                Modifier.width(96.dp).clip(shape).background(cs.surfaceVariant)
                    .border(if (on) BorderStroke(2.dp, cs.primary) else BorderStroke(0.8.dp, cs.outlineVariant), shape)
                    .clickable { ThemePrefs.setFont(ctx, f) }.padding(vertical = 10.dp, horizontal = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Text("Aa", fontFamily = f.family, fontSize = 28.sp, fontWeight = FontWeight.Medium, color = if (on) cs.onCardTint else cs.onSurface)
                Text(f.label, fontFamily = f.family, style = MaterialTheme.typography.labelMedium, color = if (on) cs.onCardTint else cs.onSurfaceVariant, maxLines = 1, textAlign = TextAlign.Center)
            }
        }
    }
}
