package com.endurancevault.app.domain

import com.google.gson.JsonElement
import com.google.gson.JsonObject
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Tata letak bernama: susunan judul/grafik/data dan pilihan tampilan yang menyertainya. */
data class LayoutPreset(
    val name: String,
    val layout: RouteVideoLayout = RouteVideoLayout(),
    val live: Boolean = true,
    val lineMode: String = "solid",
    val kmMarkers: Boolean = true,
    val flagEnds: Boolean = true,
    val flagPeak: Boolean = true,
    val flagSteep: Boolean = true,
    val flagFast: Boolean = true,
    val flagHrMax: Boolean = true,
) {
    fun sanitized(): LayoutPreset = copy(
        name = name.trim().take(24),
        layout = layout.sanitized(),
        lineMode = if (lineMode in RouteVideoColors.MODES) lineMode else "solid",
    )

    fun toJsonObject(): JsonObject = JsonObject().also {
        it.addProperty("n", name); it.add("ly", layout.toJson())
        it.addProperty("live", live); it.addProperty("lm", lineMode)
        it.addProperty("km", kmMarkers)
        it.addProperty("fe", flagEnds); it.addProperty("fp", flagPeak); it.addProperty("fs", flagSteep)
        it.addProperty("ff", flagFast); it.addProperty("fh", flagHrMax)
    }

    companion object {
        /** Membaca preset; preset lama (grid panel: "p" dan "ink") dimigrasi ke susunan baru. */
        fun fromJson(e: JsonElement): LayoutPreset? {
            val o = e.takeIf { it.isJsonObject }?.asJsonObject ?: return null
            val name = o.get("n")?.takeIf { it.isJsonPrimitive }?.asString ?: return null
            fun str(k: String, d: String) = o.get(k)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isString }?.asString ?: d
            fun bool(k: String, d: Boolean) = o.get(k)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isBoolean }?.asBoolean ?: d
            val layout = o.get("ly")?.takeIf { it.isJsonObject }?.let { RouteVideoLayout.fromJson(it.asJsonObject) }
                ?: o.get("p")?.takeIf { it.isJsonArray }?.let { RouteVideoLayout.fromLegacy(it.asJsonArray, str("ink", "w")) }
                ?: return null
            val legacy = bool("lb", true)
            return LayoutPreset(
                name, layout, bool("live", true), str("lm", "solid"), bool("km", true),
                bool("fe", legacy), bool("fp", legacy), bool("fs", legacy), bool("ff", true), bool("fh", true),
            ).sanitized()
        }
    }
}

fun RouteVideoPrefs.withPreset(p: LayoutPreset): RouteVideoPrefs = copy(
    layout = p.layout, live = p.live,
    lineMode = p.lineMode, kmMarkers = p.kmMarkers, flagEnds = p.flagEnds, flagPeak = p.flagPeak, flagSteep = p.flagSteep,
    flagFast = p.flagFast, flagHrMax = p.flagHrMax,
).sanitized()

fun RouteVideoPrefs.asPreset(name: String): LayoutPreset = LayoutPreset(
    name, layout, live, lineMode, kmMarkers, flagEnds, flagPeak, flagSteep, flagFast, flagHrMax,
).sanitized()

object RouteVideoPresets {
    val BUILT_IN: List<LayoutPreset> = listOf(
        LayoutPreset(
            "Minimal",
            RouteVideoLayout(stats = listOf("jarak", "waktu", "pace"), showChart = false).sanitized(),
            live = true, lineMode = "solid", kmMarkers = false,
            flagEnds = false, flagPeak = false, flagSteep = false, flagFast = false, flagHrMax = false,
        ),
        LayoutPreset(
            "Lengkap",
            RouteVideoLayout(stats = RouteVideoKeys.STAT, statRows = 2, chartH = 150).sanitized(),
            live = true, lineMode = "hr", kmMarkers = true,
            flagEnds = true, flagPeak = true, flagSteep = true, flagFast = true, flagHrMax = true,
        ),
        LayoutPreset(
            "Gaya Coros",
            RouteVideoLayout(stats = listOf("jarak", "waktu", "pace", "hr")).sanitized(),
            live = true, lineMode = "pace", kmMarkers = true,
            flagEnds = false, flagPeak = false, flagSteep = false, flagFast = false, flagHrMax = false,
        ),
    )

    fun isBuiltIn(name: String) = BUILT_IN.any { it.name == name }
}

/** Ukuran keluaran per rasio dan kualitas. Dimensi genap; panel diskalakan menurut sisi pendek bingkai. */
object RouteVideoFormat {
    val ASPECTS = listOf("9:16", "4:5", "1:1", "16:9")

    fun size(aspect: String, quality: String): Pair<Int, Int> {
        val hd = quality != "sd"
        return when (aspect) {
            "4:5" -> if (hd) 1080 to 1350 else 720 to 900
            "1:1" -> if (hd) 1080 to 1080 else 720 to 720
            "16:9" -> if (hd) 1920 to 1080 else 1280 to 720
            else -> if (hd) 1080 to 1920 else 720 to 1280
        }
    }

    /** Ukuran pratinjau: setengah dari ukuran HD, rasio sama. */
    fun previewSize(aspect: String): Pair<Int, Int> = size(aspect, "hd").let { it.first / 2 to it.second / 2 }

    fun ratio(aspect: String): Float = size(aspect, "hd").let { it.first.toFloat() / it.second }
}

/** Warna garis rute menurut data: rampa biru (rendah) - hijau - kuning - merah (tinggi). */
object RouteVideoColors {
    val MODES = listOf("solid", "hr", "pace", "grade", "segmen")

    fun modeName(m: String): String = when (m) {
        "hr" -> "Detak jantung"; "pace" -> "Pace"; "grade" -> "Gradien"; "segmen" -> "Per segmen"; else -> "Satu warna"
    }

    private val STOPS = intArrayOf(0xFF2F80ED.toInt(), 0xFF2ECC71.toInt(), 0xFFF2C94C.toInt(), 0xFFEB4D4B.toInt())
    private const val NEUTRAL = 0xFFB0B0B0.toInt()

    /** Warna ARGB untuk [t] di 0..1. */
    fun ramp(t: Double): Int {
        val x = t.coerceIn(0.0, 1.0) * 3.0
        val i = min(2, x.toInt()); val f = x - i
        val a = STOPS[i]; val b = STOPS[i + 1]
        fun ch(shift: Int): Int = ((((a shr shift) and 255) * (1 - f)) + (((b shr shift) and 255) * f)).roundToInt().coerceIn(0, 255)
        return (0xFF shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }

    /** Nilai per sampel, rentang rampa, dan teks legenda. */
    class Info(val values: DoubleArray, val lo: Double, val hi: Double, val title: String, val loText: String, val hiText: String)

    private fun pct(v: DoubleArray): Pair<Double, Double> {
        val f = v.filter { it.isFinite() }.sorted()
        if (f.isEmpty()) return 0.0 to 1.0
        val lo = f[(f.size * 0.05).toInt()]
        val hi = f[min(f.size - 1, (f.size * 0.95).toInt())]
        return if (hi - lo < 1e-9) (lo - 1.0) to (hi + 1.0) else lo to hi
    }

    private fun paceText(speedMs: Double): String = if (speedMs > 0.1) Js.paceStr(1000.0 / speedMs / 60.0) else "–"

    /** Null untuk mode "solid". Hasil disimpan di cache jejak. */
    fun info(t: RouteVideoTrack, mode: String): Info? {
        if (mode !in MODES || mode == "solid" || mode == "segmen") return null
        return t.cache.getOrPut("col:$mode") { build(t, mode) } as Info
    }

    private fun build(t: RouteVideoTrack, mode: String): Info {
        val n = t.n
        return when (mode) {
            "hr" -> {
                val v = RouteVideoTrack.smooth(DoubleArray(n) { if (t.hr[it] >= 30) t.hr[it].toDouble() else Double.NaN }, 5)
                val (lo, hi) = pct(v)
                Info(v, lo, hi, "DETAK JANTUNG", "${lo.roundToInt()} bpm", "${hi.roundToInt()} bpm")
            }
            "pace" -> {
                val sp = DoubleArray(n) { i ->
                    val k = max(0, i - 10); val j = min(n - 1, i + 10)
                    val dd = t.dist[j] - t.dist[k]; val dt = (t.sec[j] - t.sec[k]).toDouble()
                    if (dd >= 8.0 && dt > 0) dd / dt else Double.NaN
                }
                val v = RouteVideoTrack.smooth(sp, 5)
                val (lo, hi) = pct(v)
                if (t.bike) Info(v, lo, hi, "KECEPATAN", String.format(java.util.Locale.US, "%.1f km/j", lo * 3.6).replace('.', ','), String.format(java.util.Locale.US, "%.1f km/j", hi * 3.6).replace('.', ','))
                else Info(v, lo, hi, "PACE", paceText(lo), paceText(hi))
            }
            else -> Info(t.gradeS, -10.0, 10.0, "GRADIEN", "-10%", "+10%")
        }
    }

    fun colorOf(mode: String, v: Double, info: Info): Int {
        if (!v.isFinite()) return NEUTRAL
        if (mode == "grade") {
            val t = if (v >= 0) 0.33 + 0.67 * min(v / 10.0, 1.0) else 0.33 - 0.33 * min(-v / 10.0, 1.0)
            return ramp(t)
        }
        return ramp((v - info.lo) / (info.hi - info.lo))
    }

    /** Warna per titik rute (menurut [fracs], bagian jarak). Mode "solid" memberi [accent] di semua titik. */
    fun colors(t: RouteVideoTrack, mode: String, accent: Int, fracs: FloatArray): IntArray {
        if (mode == "segmen" && t.segments.isNotEmpty()) {
            return IntArray(fracs.size) { SegmentVideoPlan.colorAt(t.segments, fracs[it] * t.totalM) }
        }
        val info = info(t, mode) ?: return IntArray(fracs.size) { accent }
        return IntArray(fracs.size) { colorOf(mode, info.values[t.indexAtDist(fracs[it] * t.totalM)], info) }
    }

    /** [steps] warna dari rendah (kiri) ke tinggi (kanan) untuk batang legenda. */
    fun legendColors(mode: String, steps: Int): IntArray {
        val dummy = Info(DoubleArray(0), 0.0, 1.0, "", "", "")
        return IntArray(steps) { i ->
            val x = i.toDouble() / (steps - 1).coerceAtLeast(1)
            if (mode == "grade") colorOf(mode, -10.0 + 20.0 * x, dummy) else ramp(x)
        }
    }
}

/** Titik penting di rute yang diberi bendera di peta 3D. [kind]: start, finish, km, peak, steep, fast, hrmax. */
class Anchor(val kind: String, val idx: Int, val frac: Double, val km: Int = 0, val value: Double = Double.NaN)

/** Jarak antar bendera km: 1 km, atau 2/5/10 km untuk rute panjang (maksimal ±20 bendera). */
fun RouteVideoTrack.kmStep(): Int {
    val km = totalM / 1000.0
    return when { km <= 20 -> 1; km <= 45 -> 2; km <= 110 -> 5; else -> 10 }
}

fun RouteVideoTrack.allAnchors(): List<Anchor> {
    val out = ArrayList<Anchor>()
    out += Anchor("start", 0, 0.0)
    out += Anchor("finish", n - 1, 1.0)
    val step = kmStep()
    var k = step
    while (k * 1000.0 <= totalM - 300.0) {
        val i = indexAtDist(k * 1000.0)
        out += Anchor("km", i, dist[i] / totalM, km = k)
        k += step
    }
    if (hasEle) {
        var pk = -1
        for (i in 0 until n) if (eleS[i].isFinite() && (pk < 0 || eleS[i] > eleS[pk])) pk = i
        val lo = eleS.filter { it.isFinite() }.minOrNull() ?: 0.0
        if (pk >= 0 && eleS[pk] - lo >= 15.0) out += Anchor("peak", pk, dist[pk] / totalM, value = eleS[pk])
        var bestG = 0.0; var bestMid = -1
        for (i in 0 until n step 5) {
            val j = indexAtDist(dist[i] + 100.0)
            val dd = dist[j] - dist[i]
            if (dd < 80.0) continue
            val g = (eleS[j] - eleS[i]) / dd * 100.0
            if (g.isFinite() && g > bestG) { bestG = g; bestMid = (i + j) / 2 }
        }
        if (bestMid >= 0 && bestG >= 4.0) out += Anchor("steep", bestMid, dist[bestMid] / totalM, value = bestG)
    }
    if (totalM >= 1500.0) {
        // 1 km tercepat: jendela 1000 m dengan waktu terpendek; bendera di ujung jendela.
        var bestPace = Double.MAX_VALUE; var bestEnd = -1
        for (i in 0 until n step 5) {
            val j = indexAtDist(dist[i] + 1000.0)
            if (j <= i) continue
            val dd = dist[j] - dist[i]; val dt = (sec[j] - sec[i]).toDouble()
            if (dd < 950.0 || dt <= 0.0) continue
            val pace = dt / 60.0 / (dd / 1000.0)
            if (pace < bestPace) { bestPace = pace; bestEnd = j }
        }
        if (bestEnd >= 0 && bestPace in 1.0..25.0) out += Anchor("fast", bestEnd, dist[bestEnd] / totalM, value = bestPace)
    }
    // Batas antar segmen (WS1, WS2, ...) untuk video segmen 3D; hanya tampil bila garis diwarnai per segmen.
    for (i in 0 until segments.size - 1) {
        val idx = indexAtDist(segments[i].endM)
        out += Anchor("seg", idx, dist[idx] / totalM, km = i + 1, value = segments[i].endM / 1000.0)
    }
    val hs = RouteVideoTrack.smooth(DoubleArray(n) { if (hr[it] >= 30) hr[it].toDouble() else Double.NaN }, 5)
    var mi = -1
    for (i in 0 until n) if (hs[i].isFinite() && (mi < 0 || hs[i] > hs[mi])) mi = i
    if (mi >= 0 && hs[mi] >= 80.0) out += Anchor("hrmax", mi, dist[mi] / totalM, value = hs[mi])
    return out
}

/** Pace (menit/km) pada [Anchor] km: rata-rata [kmStep] km terakhir. */
fun RouteVideoTrack.kmPace(a: Anchor): Double? {
    val step = kmStep()
    val i0 = if (a.km - step <= 0) 0 else indexAtDist((a.km - step) * 1000.0)
    val dd = dist[a.idx] - dist[i0]; val dt = (sec[a.idx] - sec[i0]).toDouble()
    return if (dd > 50.0 && dt > 0) dt / 60.0 / (dd / 1000.0) else null
}

/** Balapan dengan ghost: kemajuan dihitung menurut waktu gerak yang sama, bukan menurut jarak. */
class RouteVideoRace(val main: RouteVideoTrack, val ghost: RouteVideoTrack) {
    val tMax: Double = max(main.totalSec, ghost.totalSec).toDouble().coerceAtLeast(1.0)

    /** (bagian jarak utama, bagian jarak ghost) saat [r] (0..1) dari total waktu balapan. */
    fun fractions(r: Double): Pair<Double, Double> {
        val t = r.coerceIn(0.0, 1.0) * tMax
        return main.fracAtTime(t) to ghost.fracAtTime(t)
    }

    /** Selisih detik pada jarak yang sama; positif = aktivitas utama unggul (lebih cepat tiba). */
    fun gapSeconds(mainFrac: Double): Double {
        val i = main.indexAtDist(mainFrac.coerceIn(0.0, 1.0) * main.totalM)
        return ghost.timeAtDist(main.dist[i]) - main.sec[i]
    }
}

class GhostInfo(val name: String, val gapSec: Double)

/** Arah lari (derajat kompas, 0 = utara, searah jarum jam) di bagian jarak [frac], dari titik ±120 m di sekitarnya. */
fun RouteVideoTrack.bearingAt(frac: Double): Double {
    val m = frac.coerceIn(0.0, 1.0) * totalM
    val i0 = indexAtDist(max(0.0, m - 120.0)); val i1 = indexAtDist(min(totalM, m + 120.0))
    if (i1 <= i0) return 0.0
    val dLat = lat[i1] - lat[i0]
    val dLon = (lon[i1] - lon[i0]) * cos(Math.toRadians((lat[i0] + lat[i1]) / 2))
    if (dLat == 0.0 && dLon == 0.0) return 0.0
    return (Math.toDegrees(atan2(dLon, dLat)) + 360.0) % 360.0
}

/** Deret [values] (satu nilai per sampel) tersampel merata sepanjang jarak, NaN diisi nilai sebelumnya; hasil di-cache. */
fun RouteVideoTrack.seriesSamples(key: String, values: DoubleArray, count: Int = 180): DoubleArray =
    cache.getOrPut("ser:$key:$count") {
        val f = RouteVideoTrack.fillForward(values)
        DoubleArray(count) { f[indexAtDist(totalM * it / (count - 1).coerceAtLeast(1))] }
    } as DoubleArray

/**
 * Linimasa video: [RouteVideoPrefs.durationSec] detik utama, lalu (bila [RouteVideoPrefs.summary]) beberapa detik kartu ringkasan
 * di atas bingkai terakhir. [at] menerjemahkan posisi 0..1 pada seluruh linimasa menjadi posisi kamera dan kepekatan kartu.
 */
object RouteVideoTimeline {
    const val SUMMARY_SEC = 3.0
    const val FADE_SEC = 0.6

    class Point(val p: Double, val summaryAlpha: Double)

    fun totalSec(prefs: RouteVideoPrefs): Double = prefs.durationSec + if (prefs.summary) SUMMARY_SEC else 0.0

    fun frames(prefs: RouteVideoPrefs, fps: Int): Int = (totalSec(prefs) * fps).roundToInt().coerceAtLeast(2)

    fun at(pos: Double, prefs: RouteVideoPrefs): Point {
        val total = totalSec(prefs); val dur = prefs.durationSec.toDouble()
        val t = pos.coerceIn(0.0, 1.0) * total
        val p = (t / dur).coerceIn(0.0, 1.0)
        val a = if (!prefs.summary || t <= dur) 0.0 else {
            val x = ((t - dur) / FADE_SEC).coerceIn(0.0, 1.0)
            x * x * (3 - 2 * x)
        }
        return Point(p, a)
    }
}
