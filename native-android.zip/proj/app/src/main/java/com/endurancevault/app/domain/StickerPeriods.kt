package com.endurancevault.app.domain

import com.endurancevault.app.data.ActivityEntity
import java.time.LocalDate

/**
 * Ringkasan harian, mingguan, dan bulanan di sekitar satu sesi, untuk stiker statistik periode.
 * [prev] = pembanding (minggu lalu, bulan lalu, atau rata-rata per lari 28 hari untuk harian), [target] = jarak rencana
 * pada rentang itu. Murni, tanpa Android.
 */
class PeriodData(
    val cur: Map<SharePeriod, PeriodSummary>,
    val prev: Map<SharePeriod, PeriodSummary?>,
    val target: Map<SharePeriod, Double?>,
    /** Km per minggu dalam bulan sesi (stiker bulanan). */
    val monthWeeks: List<MonthWeek> = emptyList(),
    /** Rekor bulan sesi; null bila tidak ada lari. */
    val records: MonthRecords? = null,
) {
    companion object {
        /** [session] = sesi yang dibuka (dasar periode harian); [anchor] = tanggalnya; [planWeeks] = rencana untuk target;
        *  [today] menentukan apakah periode masih berjalan (pembanding dipotong sejumlah hari yang sama). */
        fun of(acts: List<ActivityEntity>, session: ActivityEntity, anchor: LocalDate, planWeeks: List<SwWeek>, today: LocalDate = LocalDate.now()): PeriodData {
            val cur = HashMap<SharePeriod, PeriodSummary>()
            val prev = HashMap<SharePeriod, PeriodSummary?>()
            val target = HashMap<SharePeriod, Double?>()
            SharePeriod.values().forEach { p ->
                val s = if (p == SharePeriod.DAY) PeriodStats.summarize(listOf(session), p, anchor) else PeriodStats.summarize(acts, p, anchor)
                cur[p] = s
                prev[p] = PeriodStats.previous(acts, p, anchor, today)
                target[p] = PeriodStats.planTarget(planWeeks, s.start, s.end)
            }
            return PeriodData(cur, prev, target, PeriodStats.monthWeeks(acts, anchor), PeriodStats.monthRecords(acts, anchor))
        }
    }
}
