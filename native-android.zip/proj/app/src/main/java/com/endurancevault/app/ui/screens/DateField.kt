package com.endurancevault.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.endurancevault.app.ui.i18n.Text
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

/**
 * Isian tanggal berupa pemilih kalender (bukan ketik manual). Nilai tetap string `yyyy-MM-dd` supaya kode pemanggil
 * yang sudah ada tidak berubah; string kosong = belum dipilih. [allowClear] menampilkan tombol hapus untuk isian opsional.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun DateField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    allowClear: Boolean = false,
) {
    var open by remember { mutableStateOf(false) }
    val clearable = allowClear && value.isNotBlank()
    Box(modifier) {
        OutlinedTextField(
            value = value,
            onValueChange = {},
            readOnly = true,
            singleLine = true,
            label = { Text(label) },
            trailingIcon = {
                Row {
                    if (clearable) {
                        IconButton(onClick = { onValueChange("") }) { Icon(Icons.Default.Close, contentDescription = null) }
                    }
                    IconButton(onClick = { open = true }) { Icon(Icons.Default.DateRange, contentDescription = null) }
                }
            },
            modifier = Modifier.fillMaxWidth(),
        )
        // Ketukan di badan field juga membuka kalender; sisi kanan dibiarkan untuk ikon.
        Box(Modifier.matchParentSize().padding(end = if (clearable) 96.dp else 48.dp).clickable { open = true })
    }
    if (open) {
        val initial = runCatching { LocalDate.parse(value.trim()) }.getOrNull() ?: LocalDate.now()
        val state = rememberDatePickerState(initialSelectedDateMillis = initial.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli())
        DatePickerDialog(
            onDismissRequest = { open = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { ms ->
                        onValueChange(Instant.ofEpochMilli(ms).atZone(ZoneOffset.UTC).toLocalDate().toString())
                    }
                    open = false
                }) { Text("Pilih") }
            },
            dismissButton = { TextButton(onClick = { open = false }) { Text("Batal") } },
        ) { DatePicker(state = state) }
    }
}
