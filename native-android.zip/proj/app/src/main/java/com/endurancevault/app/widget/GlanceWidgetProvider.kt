package com.endurancevault.app.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent

/** Widget "Hari ini" gaya At a Glance: satu ukuran (4x2), rata kiri, latar transparan. */
class GlanceWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetManager.updateAppWidget(appWidgetIds, GlanceWidgetRenderer.build(context))
        GlanceWidgetWorker.schedule(context)
        GlanceWidgetWorker.runOnce(context)
    }

    override fun onEnabled(context: Context) {
        GlanceWidgetWorker.schedule(context)
        GlanceWidgetWorker.runOnce(context)
    }

    override fun onDisabled(context: Context) {
        GlanceWidgetWorker.cancel(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            Intent.ACTION_DATE_CHANGED, Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED -> GlanceWidgetRenderer.updateAll(context)
        }
    }
}
