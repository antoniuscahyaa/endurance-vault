package com.endurancevault.app.ui.sticker

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import com.endurancevault.app.domain.Js
import com.endurancevault.app.domain.PeriodStats
import com.endurancevault.app.domain.PeriodSummary
import com.endurancevault.app.domain.SharePeriod
import com.endurancevault.app.domain.SegKind
import com.endurancevault.app.domain.StickerModel
import com.endurancevault.app.domain.StickerNum
import com.endurancevault.app.domain.StickerPrefs
import com.endurancevault.app.domain.Stickers
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Palet stiker (padanan `STK_INK`); [sh] = 0 berarti tanpa bayangan. */
class StickerPalette(
    val ink: Int, val ink2: Int, val line: Int, val hl: Int, val sh: Int, val bg: Int, val panelLight: Boolean,
    val fonts: StickerFonts = StickerFonts.NONE,
    /** Pengali ukuran piksel stiker (1 = standar). */
    val scale: Float = 1f,
    /** Kemiringan huruf angka dan judul (textSkewX); 0 = tegak. Bukan nol = gaya "Miring tebal" (angka dan judul juga ditebalkan). */
    val slant: Float = 0f,
)

private fun rgba(r: Int, g: Int, b: Int, a: Double): Int = Color.argb((a * 255).roundToInt(), r, g, b)

object StickerPalettes {
    private val W = StickerPalette(Color.WHITE, rgba(255, 255, 255, .84), rgba(255, 255, 255, .38), 0xFFC6F432.toInt(), rgba(0, 0, 0, .45), 0xFF2A3A33.toInt(), false)
    private val K = StickerPalette(0xFF111111.toInt(), rgba(17, 17, 17, .74), rgba(17, 17, 17, .3), 0xFF2F7D1F.toInt(), 0, 0xFFE9ECEA.toInt(), true)
    private val L = StickerPalette(0xFFC6F432.toInt(), rgba(227, 248, 160, .95), rgba(198, 244, 50, .42), Color.WHITE, rgba(0, 0, 0, .45), 0xFF2A3A33.toInt(), false)

    /** Palet menurut pilihan warna teks, dengan warna sorotan diganti aksen bila diisi (padanan `stkPal`). */
    fun of(p: StickerPrefs, fonts: StickerFonts = StickerFonts.NONE): StickerPalette {
        val b = if (p.inkCustom.isNotEmpty()) custom(p.inkCustom) else when (p.ink) { "k" -> K; "l" -> L; else -> W }
        val hl = if (p.accent.isEmpty()) b.hl else Color.parseColor(p.accent)
        return StickerPalette(b.ink, b.ink2, b.line, hl, b.sh, b.bg, b.panelLight, fonts, p.scale / 100f, if (p.numStyle == "sport") -0.2f else 0f)
    }

    /** Palet dari satu warna teks bebas: teks terang diberi bayangan dan latar pratinjau gelap, teks gelap sebaliknya (seperti Putih dan Hitam). */
    private fun custom(hex: String): StickerPalette {
        val c = Color.parseColor(hex)
        val r = Color.red(c); val g = Color.green(c); val bl = Color.blue(c)
        val light = (0.299 * r + 0.587 * g + 0.114 * bl) / 255.0 >= .5
        return if (light) StickerPalette(c, rgba(r, g, bl, .84), rgba(r, g, bl, .38), 0xFFC6F432.toInt(), rgba(0, 0, 0, .45), 0xFF2A3A33.toInt(), false)
        else StickerPalette(c, rgba(r, g, bl, .74), rgba(r, g, bl, .3), 0xFF2F7D1F.toInt(), 0, 0xFFE9ECEA.toInt(), true)
    }
}

/** Satu kanvas stiker: bitmap transparan, panel latar opsional, dan alat gambar kecil. Satuan piksel sama dengan versi web. */
private class Sk(w: Int, h: Int, val pal: StickerPalette, panelLevel: String) {
    /** Pengali ukuran; dibatasi agar sisi terpanjang bitmap tidak melebihi 4096 px. Semua gambar tetap memakai satuan logis [w] x [h]. */
    private val k: Float = min(pal.scale, 4096f / max(max(w, h), 1))
    val bmp: Bitmap = Bitmap.createBitmap(max(2, (w * k).roundToInt()), max(2, (h * k).roundToInt()), Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp).also { it.scale(k, k) }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        if (panelLevel == "soft" || panelLevel == "strong") {
            val a = if (panelLevel == "strong") .62 else .38
            val col = if (pal.panelLight) rgba(255, 255, 255, a + .14) else rgba(0, 0, 0, a)
            fillPaint(col, shadow = false)
            val r = min(48f, h / 4f)
            c.drawRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), r, r, p)
        }
    }

    private fun fillPaint(col: Int, alpha: Float = 1f, shadow: Boolean = true) {
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.FILL; p.color = withA(col, alpha)
        if (shadow && pal.sh != 0) p.setShadowLayer(12f, 0f, 3f, pal.sh) else p.clearShadowLayer()
    }

    private fun strokePaint(col: Int, width: Float, alpha: Float = 1f, shadow: Boolean = true) {
        fillPaint(col, alpha, shadow); p.style = Paint.Style.STROKE; p.strokeWidth = width
    }

    /** Huruf kustom bila dipilih (angka dan judul = [f] true), selain itu huruf sistem. Huruf kustom ditebalkan bila perlu untuk berat 600 ke atas. */
    private fun face(f: Boolean, wt: Int): Typeface {
        val custom = if (f) pal.fonts.num else pal.fonts.body
        val heavy = f && (wt >= 600 || pal.slant != 0f)
        if (custom != null) return if (heavy) Typeface.create(custom, Typeface.BOLD) else custom
        return if (f) Typeface.create("sans-serif-condensed", if (heavy) Typeface.BOLD else Typeface.NORMAL)
        else Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    /** Lebar teks. [f] true = huruf condensed (angka dan judul), false = huruf isi. */
    fun tw(t: String, px: Float, wt: Int, f: Boolean = false): Float {
        p.reset(); p.isAntiAlias = true; p.typeface = face(f, wt); p.textSize = px
        return p.measureText(com.endurancevault.app.ui.i18n.Lang.tr(t))
    }

    fun text(t: String, px: Float, wt: Int, col: Int, align: Paint.Align, x: Float, y: Float, f: Boolean = false) {
        fillPaint(col); p.typeface = face(f, wt); p.textSize = px; p.textAlign = align
        p.textSkewX = if (f) pal.slant else 0f
        c.drawText(com.endurancevault.app.ui.i18n.Lang.tr(t), x, y, p)
    }

    /** Potong dengan "…" sampai muat [maxW]. */
    fun ell(t: String, px: Float, wt: Int, maxW: Float, f: Boolean = false): String {
        if (tw(t, px, wt, f) <= maxW) return t
        var s = t
        while (s.length > 1 && tw("$s…", px, wt, f) > maxW) s = s.dropLast(1)
        return "$s…"
    }

    fun rr(x: Float, y: Float, w: Float, h: Float, r: Float, col: Int, alpha: Float = 1f) {
        val rad = max(0f, min(r, min(w / 2, h / 2)))
        fillPaint(col, alpha); c.drawRoundRect(RectF(x, y, x + w, y + h), rad, rad, p)
    }

    fun rect(x: Float, y: Float, w: Float, h: Float, col: Int, alpha: Float = 1f) { fillPaint(col, alpha); c.drawRect(x, y, x + w, y + h, p) }
    fun circle(x: Float, y: Float, r: Float, col: Int, alpha: Float = 1f) { fillPaint(col, alpha); c.drawCircle(x, y, r, p) }

    fun line(x1: Float, y1: Float, x2: Float, y2: Float, col: Int, width: Float, alpha: Float = 1f, dash: FloatArray? = null) {
        strokePaint(col, width, alpha)
        if (dash != null) p.pathEffect = DashPathEffect(dash, 0f)
        c.drawLine(x1, y1, x2, y2, p)
    }

    fun strokeRect(x: Float, y: Float, w: Float, h: Float, col: Int, width: Float) { strokePaint(col, width); c.drawRect(x, y, x + w, y + h, p) }

    /** Garis lewat banyak titik, sudut dan ujung membulat. */
    fun poly(pts: List<Pair<Float, Float>>, col: Int, width: Float, alpha: Float = 1f) {
        if (pts.size < 2) return
        val path = Path(); pts.forEachIndexed { i, q -> if (i == 0) path.moveTo(q.first, q.second) else path.lineTo(q.first, q.second) }
        strokePaint(col, width, alpha); p.strokeJoin = Paint.Join.ROUND; p.strokeCap = Paint.Cap.ROUND
        c.drawPath(path, p)
    }

    /** Isi area di bawah grafik tanpa bayangan (padanan blok save/restore pada grafik elevasi). */
    fun fillArea(pts: List<Pair<Float, Float>>, baseY: Float, col: Int) {
        val path = Path(); path.moveTo(pts.first().first, baseY)
        pts.forEach { path.lineTo(it.first, it.second) }
        path.lineTo(pts.last().first, baseY); path.close()
        fillPaint(col, shadow = false); c.drawPath(path, p)
    }

    /** Teks diputar -90 derajat (naik), titik awal di ([x],[y]). */
    fun textUp(t: String, px: Float, wt: Int, col: Int, x: Float, y: Float, f: Boolean = false) {
        c.save(); c.translate(x, y); c.rotate(-90f)
        text(t, px, wt, col, Paint.Align.LEFT, 0f, 0f, f)
        c.restore()
    }

    fun head(left: String, right: String, w: Int, pad: Int) {
        text(left, 34f, 500, pal.ink2, Paint.Align.LEFT, pad.toFloat(), pad + 34f)
        if (right.isNotEmpty()) text(right, 38f, 700, pal.ink, Paint.Align.RIGHT, (w - pad).toFloat(), pad + 36f, true)
    }
}

private fun withA(col: Int, a: Float): Int = if (a >= 1f) col else (col and 0x00FFFFFF) or ((Color.alpha(col) * a).roundToInt() shl 24)
private fun rgb(v: Int): Int = 0xFF000000.toInt() or v
private val ORANGE = 0xFFE8873A.toInt()
private val GREEN = 0xFF4CAF7D.toInt()
private val RED = 0xFFE5484D.toInt()

private fun f(x: Double) = x.toFloat()
private fun L() = Paint.Align.LEFT
private fun R() = Paint.Align.RIGHT
private fun C() = Paint.Align.CENTER
private fun zn(i: Int) = "Z${i + 1}"

private val MON_FULL_ID = arrayOf("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember")
private val MON_FULL_EN = arrayOf("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")
private val MON_SHORT_ID = arrayOf("Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des")
private val MON_SHORT_EN = arrayOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
private val DAY_SHORT_ID = arrayOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min")
private val DAY_SHORT_EN = arrayOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
private val idLang get() = com.endurancevault.app.ui.i18n.Lang.current == com.endurancevault.app.ui.i18n.AppLang.ID
// Nama bulan dan hari mengikuti bahasa aplikasi (stiker digambar di kanvas, tidak lewat Text yang diterjemahkan).
private val MON_FULL get() = if (idLang) MON_FULL_ID else MON_FULL_EN
private val MON_SHORT get() = if (idLang) MON_SHORT_ID else MON_SHORT_EN
private val DAY_SHORT get() = if (idLang) DAY_SHORT_ID else DAY_SHORT_EN

/** Teks rentang periode: "Rab, 11 Nov 2026", "9–15 Nov 2026", "November 2026". */
private fun perText(s: PeriodSummary): String = when (s.period) {
    SharePeriod.DAY -> "${DAY_SHORT[s.start.dayOfWeek.value - 1]}, ${s.start.dayOfMonth} ${MON_SHORT[s.start.monthValue - 1]} ${s.start.year}"
    SharePeriod.WEEK -> {
        val a = s.start; val b = s.end
        if (a.monthValue == b.monthValue) "${a.dayOfMonth}–${b.dayOfMonth} ${MON_SHORT[b.monthValue - 1]} ${b.year}"
        else "${a.dayOfMonth} ${MON_SHORT[a.monthValue - 1]}–${b.dayOfMonth} ${MON_SHORT[b.monthValue - 1]} ${b.year}"
    }
    SharePeriod.MONTH -> "${MON_FULL[s.start.monthValue - 1]} ${s.start.year}"
}

private fun spanText(a: java.time.LocalDate, b: java.time.LocalDate): String =
    if (a == b) "${a.dayOfMonth} ${MON_SHORT[a.monthValue - 1]}"
    else if (a.monthValue == b.monthValue) "${a.dayOfMonth}–${b.dayOfMonth} ${MON_SHORT[b.monthValue - 1]}"
    else "${a.dayOfMonth} ${MON_SHORT[a.monthValue - 1]}–${b.dayOfMonth} ${MON_SHORT[b.monthValue - 1]}"

private class RecRow(val label: String, val value: String, val unit: String, val sub: String, val date: java.time.LocalDate?)

private fun perNoun(s: PeriodSummary): String = when (s.period) { SharePeriod.DAY -> "Lari ini"; SharePeriod.WEEK -> "Minggu ini"; SharePeriod.MONTH -> "Bulan ini" }

/** Gradasi lime (0) ke kuning ke oranye (1) untuk rute berwarna. */
private fun heatColor(t: Double): Int {
    val x = t.coerceIn(0.0, 1.0)
    val (a, b, u) = if (x < .5) Triple(0xC6F432, 0xFFD23F, x / .5) else Triple(0xFFD23F, 0xE8873A, (x - .5) / .5)
    fun ch(sh: Int) = ((((a shr sh) and 255) * (1 - u) + ((b shr sh) and 255) * u)).roundToInt()
    return Color.rgb(ch(16), ch(8), ch(0))
}

private fun heroKm(s: PeriodSummary): String = if (s.period == SharePeriod.DAY) Stickers.km2(s.km) else Stickers.km1(s.km)

/** Warna teks yang terbaca di atas isian [col]. */
private fun onFill(col: Int): Int {
    val lum = (0.299 * Color.red(col) + 0.587 * Color.green(col) + 0.114 * Color.blue(col)) / 255.0
    return if (lum > .55) 0xFF111111.toInt() else Color.WHITE
}

/** Penggambar semua stiker yang sudah diport. Semua fungsi mengembalikan bitmap ARGB transparan. */
object StickerRenderer {

    /**
     * Gambar stiker yang tersedia untuk [m], kunci = id (urutan sama dengan [Stickers.allIds]). [only] membatasi ke id tertentu
     * (null = semua); [active] false menghentikan penggambaran lebih awal (mis. coroutine dibatalkan). Stiker yang gagal digambar
     * (termasuk kehabisan memori) dilewati.
     */
    fun renderAll(
        m: StickerModel, prefs: StickerPrefs, fonts: StickerFonts = StickerFonts.NONE,
        only: Set<String>? = null, active: () -> Boolean = { true },
    ): LinkedHashMap<String, Bitmap> {
        val out = LinkedHashMap<String, Bitmap>()
        val pal = StickerPalettes.of(prefs, fonts)
        val ks = m.keys(prefs.order)
        for (id in Stickers.allIds(m, prefs)) {
            if (!active()) break
            if (only != null && id !in only) continue
            val bmp: Bitmap? = try {
                when {
                    id == "n-all" -> nums(ks.mapNotNull { m.num(it) }, pal, prefs.panel, prefs.cols)
                    id.startsWith("n-") -> m.num(id.removePrefix("n-"))?.let { num1(it, pal, prefs.panel) }
                    id == "map" -> map(m, pal, prefs)
                    id == "wk-all" -> nums(m.keysWk(prefs.wk).mapNotNull { m.numWk(it) }, pal, prefs.panel, prefs.cols)
                    Stickers.perOfId(id) != null -> {
                        val per = Stickers.perOfId(id)!!
                        when (Stickers.kindOfId(id)) {
                            "angka" -> nums(m.keysPer(prefs.pf, per).mapNotNull { m.numPer(it, per) }, pal, prefs.panel, prefs.cols)
                            "hero" -> pHero(m, pal, prefs, per)
                            "kalender" -> pCalendar(m, pal, prefs, per)
                            "kurva" -> pCurve(m, pal, prefs, per)
                            "cincin" -> pRing(m, pal, prefs, per)
                            "banding" -> pCompare(m, pal, prefs, per)
                            "pekan" -> pWeeks(m, pal, prefs, per)
                            "rekor" -> pRecords(m, pal, prefs, per)
                            else -> null
                        }
                    }
                    id == "pace-repetisi" -> rep(m, pal, prefs)
                    id == "tren-pace" -> trend(m, pal, prefs)
                    id == "zona-hr-minggu" -> zoneWk(m, pal, prefs)
                    id == "target-minggu" -> target(m, pal, prefs)
                    id == "tabel-segmen" -> segTable(m, pal, prefs)
                    id == "bar-segmen" -> segBar(m, pal, prefs)
                    id == "pace-segmen" -> segPace(m, pal, prefs)
                    id == "split-km" -> split(m, pal, prefs)
                    id == "elevasi" -> elev(m, pal, prefs)
                    id == "zona-hr-sesi" -> zone(m, pal, prefs)
                    id == "zona-hr-tumpuk" -> zoneStack(m, pal, prefs)
                    id == "maf" -> maf(m, pal, prefs)
                    id == "vert" -> vert(m, pal, prefs)
                    id == "peta-warna" -> map(m, pal, prefs, colored = true)
                    id == "cuaca" -> nums(m.wxNums, pal, prefs.panel, prefs.cols)
                    id == "best-effort" -> nums(m.bestNums, pal, prefs.panel, prefs.cols)
                    id == "vs-pr" -> vsPr(m, pal, prefs)
                    id == "vs-rute" -> vsRoute(m, pal, prefs)
                    id == "hitung-mundur" -> countdown(m, pal, prefs)
                    id == "training-load" -> training(m, pal, prefs)
                    id == "tahun" -> yearSticker(m, pal, prefs)
                    id == "streak" -> streakSticker(m, pal, prefs)
                    else -> null
                }
            } catch (_: OutOfMemoryError) { null } catch (_: Exception) { null }
            if (bmp != null) out[id] = bmp
        }
        return out
    }

    /** Baris angka: [items] label/nilai/satuan, [cols] 1..6 (dibatasi jumlah item). */
    fun nums(items: List<StickerNum>, pal: StickerPalette, panel: String, cols: Int): Bitmap {
        val n = items.size
        val cc = max(1, min(cols, n))
        val colW = when (cc) { 1 -> 520; 2 -> 400; 3 -> 330; 4 -> 270; 5 -> 232; else -> 204 }
        val vp = when { cc <= 2 -> 120; cc == 3 -> 100; cc == 4 -> 80; cc == 5 -> 72; else -> 64 }
        val lp = if (cc >= 5) 26f else 30f
        val pad = 40
        val rows = ceil(n / cc.toDouble()).toInt()
        val rh = vp + 94
        val s = Sk(pad * 2 + cc * colW, pad * 2 + rows * rh - 30, pal, panel)
        items.forEachIndexed { i, it ->
            val r = i / cc; val k = i % cc
            val x0 = f((pad + k * colW + (if (k > 0) 26 else 0)).toDouble()); val y0 = f((pad + r * rh).toDouble())
            val maxW = f((colW - (if (k > 0) 26 else 0) - 26).toDouble())
            var px = vp.toFloat(); var up = 0f; var vw = 0f; var uw = 0f
            fun meas() { up = (px * .4f).roundToInt().toFloat(); vw = s.tw(it.value, px, 700, true); uw = if (it.unit.isNotEmpty()) s.tw(it.unit, up, 500) + 10 else 0f }
            meas(); while (px > 40 && vw + uw > maxW) { px -= 4; meas() }
            s.text(s.ell(it.label, lp, 500, maxW), lp, 500, pal.ink2, L(), x0, y0 + 30)
            s.text(it.value, px, 700, pal.ink, L(), x0, y0 + 36 + px, true)
            if (it.unit.isNotEmpty()) s.text(it.unit, up, 500, pal.ink2, L(), x0 + vw + 10, y0 + 36 + px)
            if (k > 0) s.rect(f((pad + k * colW - 1).toDouble()), y0 + 2, 3f, f((vp + 44).toDouble()), pal.line)
        }
        return s.bmp
    }

    /** Satu angka satu gambar. */
    fun num1(it: StickerNum, pal: StickerPalette, panel: String): Bitmap {
        val pad = 44; val px = 132f; val up = (px * .4f).roundToInt().toFloat()
        val m = Sk(10, 10, pal, "off")
        val vw = m.tw(it.value, px, 700, true); val uw = if (it.unit.isNotEmpty()) m.tw(it.unit, up, 500) + 12 else 0f
        val lw = m.tw(it.label, 34f, 500)
        val w = ceil(max(lw, vw + uw) + pad * 2).toInt(); val h = (pad * 2 + 36 + px + 8).toInt()
        val s = Sk(w, h, pal, panel)
        s.text(it.label, 34f, 500, pal.ink2, L(), pad.toFloat(), pad + 30f)
        s.text(it.value, px, 700, pal.ink, L(), pad.toFloat(), pad + 36 + px, true)
        if (it.unit.isNotEmpty()) s.text(it.unit, up, 500, pal.ink2, L(), pad + vw + 12, pad + 36 + px)
        return s.bmp
    }

    /** Template peta: garis rute (tanpa tile peta, tetap transparan) dengan data di bawah atau di samping. */
    fun map(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs, colored: Boolean = false): Bitmap {
        val d = m.detail!!; val rt = d.route
        val mnx = rt.minOf { it.first }.toDouble(); val mxx = rt.maxOf { it.first }.toDouble()
        val mny = rt.minOf { it.second }.toDouble(); val mxy = rt.maxOf { it.second }.toDouble()
        val rw = max(1.0, mxx - mnx); val rh = max(1.0, mxy - mny)
        val fields = Stickers.MAP_KEYS.filter { it in prefs.mapFields }.mapNotNull { m.num(it) }
        val side = prefs.lay == "kiri"
        val pad = 44; val bw = if (side) 500 else 900; val bh = if (side) 500 else 560
        val sc = min((bw - 40) / rw, (bh - 40) / rh); val dw = rw * sc; val dh = rh * sc
        val cellH = 170
        val w: Int; val h: Int; val ox: Double; val oy: Double; val statX: Double; val statY: Double; val cellW: Double; val cols: Int
        if (side) {
            cols = 1; val body = max(bh, fields.size * cellH)
            w = pad * 2 + bw + 40 + 400; h = pad * 2 + body
            ox = pad + (bw - dw) / 2; oy = pad + (body - dh) / 2
            statX = (pad + bw + 40).toDouble(); statY = pad + (body - fields.size * cellH) / 2.0; cellW = 400.0
        } else {
            cols = 2; w = pad * 2 + bw
            val rowsN = ceil(fields.size / 2.0).toInt()
            h = (pad * 2 + dh + 40 + rowsN * cellH).toInt()
            ox = pad + (bw - dw) / 2; oy = pad + 20.0; statX = pad.toDouble(); statY = pad + dh + 60; cellW = bw / 2.0
        }
        val norm = if (colored) m.routeNorm(prefs.mapColor) else null
        val s = Sk(w, h + (if (norm != null) 110 else 0), pal, prefs.panel)
        val rp = rt.map { f(ox + (it.first - mnx) * sc) to f(oy + (it.second - mny) * sc) }
        if (norm == null) s.poly(rp, pal.ink, 14f)
        else {
            for (i in 1 until rp.size) s.poly(listOf(rp[i - 1], rp[i]), heatColor((norm[i - 1] + norm[i]) / 2), 14f)
            val ly = (h - pad + 30).toFloat(); val lw = 360f; val steps = 24
            for (k in 0 until steps) s.rect(pad + k * lw / steps, ly, lw / steps + 1f, 18f, heatColor(k / (steps - 1.0)))
            val hr = prefs.mapColor == "hr" && m.detail!!.hrSeries.size >= 2
            s.text(if (hr) "HR rendah" else "Cepat", 26f, 500, pal.ink2, L(), pad.toFloat(), ly + 48f)
            s.text(if (hr) "HR tinggi" else "Lambat", 26f, 500, pal.ink2, R(), pad + lw, ly + 48f)
        }
        val p0 = rt.first(); val p1 = rt.last()
        s.circle(f(ox + (p0.first - mnx) * sc), f(oy + (p0.second - mny) * sc), 19f, pal.hl)
        s.circle(f(ox + (p1.first - mnx) * sc), f(oy + (p1.second - mny) * sc), 19f, pal.ink)
        fields.forEachIndexed { i, it ->
            val r = i / cols; val k = i % cols
            val x = f(statX + k * cellW); val y = f(statY + r * cellH); val maxW = f(cellW - 30)
            var px = 84f; var up = 34f
            var vw = s.tw(it.value, px, 700, true); var uw = if (it.unit.isNotEmpty()) s.tw(it.unit, up, 500) + 10 else 0f
            while (px > 44 && vw + uw > maxW) {
                px -= 4; up = (px * .4f).roundToInt().toFloat()
                vw = s.tw(it.value, px, 700, true); uw = if (it.unit.isNotEmpty()) s.tw(it.unit, up, 500) + 10 else 0f
            }
            s.text(it.label, 30f, 500, pal.ink2, L(), x, y + 30)
            s.text(it.value, px, 700, pal.ink, L(), x, y + 36 + px, true)
            if (it.unit.isNotEmpty()) s.text(it.unit, up, 500, pal.ink2, L(), x + vw + 10, y + 36 + px)
        }
        return s.bmp
    }

    /** Tabel segmen (maks. 22 baris). */
    fun segTable(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs): Bitmap {
        val all = m.segRows; val cap = 22; val rows = all.take(cap); val more = all.size - rows.size
        val w = 1000; val pad = 44; val hd = 78; val th = 48; val rh = 62
        val h = pad * 2 + hd + th + rows.size * rh + (if (more > 0) 54 else 0)
        val s = Sk(w, h, pal, prefs.panel)
        val cHr = (w - pad).toFloat(); val cPc = cHr - 110; val cTm = cPc - 170; val cKm = cTm - 170
        val nameX = pad + 38f; val nameMax = cKm - 150 - nameX
        s.head("Per segmen", "", w, pad)
        val y0 = (pad + hd).toFloat()
        s.text("km", 28f, 500, pal.ink2, R(), cKm, y0 + 26); s.text("Waktu", 28f, 500, pal.ink2, R(), cTm, y0 + 26)
        s.text("Pace", 28f, 500, pal.ink2, R(), cPc, y0 + 26); s.text("HR", 28f, 500, pal.ink2, R(), cHr, y0 + 26)
        rows.forEachIndexed { i, r ->
            val y = y0 + th + i * rh
            s.circle(pad + 12f, y + 30, 12f, Stickers.segRgb(r.kind, r.custom)?.let { rgb(it) } ?: pal.ink2)
            s.text(s.ell(r.name, 36f, 500, nameMax), 36f, 500, pal.ink, L(), nameX, y + 42)
            s.text(if (r.d > 0) Stickers.km2(r.d) else "–", 36f, 500, pal.ink2, R(), cKm, y + 42)
            s.text(if (r.min > 0) Js.durStr(r.min) else "–", 38f, 700, pal.ink, R(), cTm, y + 42, true)
            s.text(if (r.pace > 0) Js.paceStr(r.pace) else "–", 42f, 700, pal.ink, R(), cPc, y + 44, true)
            s.text(r.hr?.takeIf { it > 0 }?.toString() ?: "–", 36f, 500, pal.ink2, R(), cHr, y + 42)
        }
        if (more > 0) s.text("+$more segmen lain", 30f, 500, pal.ink2, L(), pad.toFloat(), y0 + th + rows.size * rh + 34)
        return s.bmp
    }

    /** Bar segmen: urutan waktu, warna per label. */
    fun segBar(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs): Bitmap {
        val sg = m.detail!!.segments.filter { it.min > 0 }; val n = sg.size
        val tot = sg.sumOf { it.min }
        val w = 1000; val pad = 44; val bh = 86; val avail = w - pad * 2 - 3 * (n - 1)
        val meter = Sk(10, 10, pal, "off")
        class Lg(val name: String, val rgb: Int?, val x: Float, val y: Int)
        val names = ArrayList<Triple<String, Int?, Unit>>()
        val seen = HashSet<String>()
        sg.forEach { s ->
            val kind = SegKind.normalize(s.type); val text = SegKind.displayLabel(s.label, s.type)
            val nm = text ?: "Tanpa label"
            if (seen.add(nm)) names.add(Triple(nm, Stickers.segRgb(kind, kind == null && text != null), Unit))
        }
        var lx = pad.toFloat(); var ly = 0; val legend = ArrayList<Lg>()
        names.forEach { (nm, col, _) ->
            val lw = meter.tw(nm, 30f, 500) + 44
            if (lx + lw > w - pad) { lx = pad.toFloat(); ly += 46 }
            legend.add(Lg(nm, col, lx, ly)); lx += lw + 24
        }
        val h = pad * 2 + 78 + bh + 30 + ly + 46
        val s = Sk(w, h, pal, prefs.panel)
        s.head("Bar segmen", Js.durStr(tot), w, pad)
        var x = pad.toFloat(); val by = (pad + 78).toFloat()
        sg.forEach { g ->
            val kind = SegKind.normalize(g.type); val text = SegKind.displayLabel(g.label, g.type)
            val bw = max(4f, f(g.min / tot * avail))
            s.rr(x, by, bw, bh.toFloat(), 6f, Stickers.segRgb(kind, kind == null && text != null)?.let { rgb(it) } ?: pal.ink)
            x += bw + 3
        }
        legend.forEach { g ->
            val y = by + bh + 30 + g.y
            s.circle(g.x + 12, y + 22, 12f, g.rgb?.let { rgb(it) } ?: pal.ink)
            s.text(g.name, 30f, 500, pal.ink2, L(), g.x + 34, y + 32)
        }
        return s.bmp
    }

    /**
     * Bar pace per segmen (gaya Bagikan sesi): lebar bar = jarak, tinggi = pace (makin cepat makin tinggi).
     * Bila ada segmen berlabel bawaan, hanya Repetisi dan Progresif yang penuh; sisanya dipudarkan.
     * Opsi: sorot tercepat dan garis rata-rata ([StickerPrefs.highlight]), garis HR ([StickerPrefs.hrLine]).
     */
    fun segPace(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs): Bitmap {
        val sg = m.paceSegments; val n = sg.size; val bike = m.bike
        val tot = sg.sumOf { it.d }
        val kinds = sg.map { SegKind.normalize(it.type) }
        val typed = kinds.any { it != null }
        fun isWork(i: Int) = !typed || kinds[i] == SegKind.REPETITION || kinds[i] == SegKind.PROGRESSIVE
        val vals = sg.map { if (bike) 60 / it.pace else it.pace }
        val mn = vals.min(); val mx = vals.max()
        val sp = max(mx - mn, mn * .04)
        val blo = if (bike) mn - sp * .35 else mn; val bhi = if (bike) mx else mx + sp * .35
        fun fr(v: Double): Double = max(.06, min(1.0, if (bike) (v - blo) / (bhi - blo) else (bhi - v) / (bhi - blo)))
        val w = 1000; val pad = 44; val hd = 78; val ph = 320; val topRoom = 48
        val pool = sg.indices.filter { isWork(it) }
        var best = -1
        pool.forEach { i -> if (best < 0 || (if (bike) vals[i] > vals[best] else vals[i] < vals[best])) best = i }
        val hlOn = prefs.highlight && pool.size >= 2 && best >= 0
        var avgV = 0.0
        if (hlOn) {
            var sd = 0.0; var sp2 = 0.0
            pool.forEach { i -> sd += sg[i].d; sp2 += sg[i].d * sg[i].pace }
            avgV = if (bike) 60 / (sp2 / sd) else sp2 / sd
        }
        val hrs = sg.map { (it.hr ?: 0).toDouble().coerceAtLeast(0.0) }
        val hrOn = prefs.hrLine && hrs.count { it > 0 } >= 2
        // legenda hanya bila ada label bawaan
        val meter = Sk(10, 10, pal, "off")
        class Lg(val name: String, val strong: Boolean, val x: Float, val y: Int)
        val legend = ArrayList<Lg>()
        var lx = pad.toFloat(); var ly = 0
        if (typed) {
            val seen = HashSet<String>()
            sg.forEachIndexed { i, s ->
                val nm = SegKind.displayLabel(s.label, s.type) ?: "Tanpa label"
                if (!seen.add(nm)) return@forEachIndexed
                val lw = meter.tw(nm, 28f, 500) + 44
                if (lx + lw > w - pad) { lx = pad.toFloat(); ly += 42 }
                legend.add(Lg(nm, isWork(i), lx, ly)); lx += lw + 22
            }
        }
        val legH = if (legend.isNotEmpty()) ly + 54 else 0
        val hb = if (hrOn) 118 else 0; val ft = hlOn || hrOn
        val y0 = pad + hd + legH; val bb = y0 + hb + ph
        val h = bb + (if (ft) 136 else 88) + pad
        val s = Sk(w, h, pal, prefs.panel)
        s.head(
            if (bike) "Kecepatan per segmen" else "Pace per segmen",
            m.pace?.let { if (bike) "${(60 / it).roundToInt()} km/j" else Js.paceStr(it) + "/km" } ?: "", w, pad,
        )
        legend.forEach { g ->
            val y = (pad + hd + g.y).toFloat()
            s.rr(g.x, y + 6f, 22f, 22f, 4f, pal.ink, if (g.strong) .95f else .45f)
            s.text(g.name, 28f, 500, pal.ink2, L(), g.x + 32, y + 27)
        }
        val cw = (w - pad * 2).toDouble(); var pk = 0.0; val hmax = ph - topRoom
        class Geo(val x0: Double, val bw: Double, val h: Int, val wide: Boolean, val isB: Boolean)
        val geo = ArrayList<Geo>()
        sg.forEachIndexed { i, g ->
            val x0 = pad + pk / tot * cw; val bw = g.d / tot * cw; pk += g.d
            val gp = min(6.0, bw * .12); val bh = max(6, (fr(vals[i]) * hmax).roundToInt()); val wide = bw > 86
            val bx = x0 + gp / 2; val bwd = max(2.0, bw - gp); val isB = hlOn && i == best
            geo.add(Geo(x0, bw, bh, wide, isB))
            val alpha = if (isB) 1f else if (typed && !isWork(i)) .45f else .95f
            s.rr(f(bx), f((bb - bh).toDouble()), f(bwd), bh.toFloat(), 6f, if (isB) pal.hl else pal.ink, alpha)
        }
        if (hlOn) {
            val ay = f(bb - (fr(avgV) * hmax).roundToInt().toDouble())
            s.line(pad.toFloat(), ay, (w - pad).toFloat(), ay, pal.ink, 3f, .75f, floatArrayOf(14f, 10f))
        }
        sg.forEachIndexed { i, g ->
            val q = geo[i]
            val vt = if (bike) vals[i].roundToInt().toString() else Js.paceStr(g.pace)
            val col = if (q.isB) pal.hl else pal.ink
            val cx = f(q.x0 + q.bw / 2); val top = f((bb - q.h - 14).toDouble())
            if (q.wide) s.text(vt, f(min(40.0, max(28.0, q.bw / 3.4))), 700, col, C(), cx, top, true)
            else s.textUp(vt, 30f, 700, col, cx + 11, top, true)
            if (q.wide || n <= 10 || i % 2 == 0) {
                val nm = SegKind.displayLabel(g.label, g.type) ?: (i + 1).toString()
                val px = if (q.wide) 26f else 22f
                s.text(s.ell(nm, px, 500, max(q.bw.toFloat(), 60f)), px, 500, pal.ink2, C(), cx, bb + 36f)
            }
            if (q.wide) s.text(Js.fmtKm(g.d) + " km", 24f, 500, pal.ink2, C(), cx, bb + 68f)
        }
        if (hrOn) {
            val hv = hrs.filter { it > 0 }; val hlo = hv.min(); val hhi = hv.max(); val top = y0 + 34; val hh = hb - 62
            class Pt(val x: Float, val y: Float, val v: Int)
            val pts = ArrayList<Pt>()
            sg.indices.forEach { i ->
                if (hrs[i] > 0) pts.add(Pt(f(geo[i].x0 + geo[i].bw / 2), f(top + (if (hhi > hlo) 1 - (hrs[i] - hlo) / (hhi - hlo) else .5) * hh), hrs[i].roundToInt()))
            }
            s.poly(pts.map { it.x to it.y }, RED, 5f)
            var maxI = 0; pts.forEachIndexed { i, q -> if (q.v > pts[maxI].v) maxI = i }
            pts.forEachIndexed { i, q ->
                s.circle(q.x, q.y, 8f, RED)
                if (pts.size <= 8 || i == maxI) s.text(q.v.toString(), 26f, 700, pal.ink, C(), q.x, q.y - 16, true)
            }
        }
        if (ft) {
            val fy = (bb + 120).toFloat(); var fx = pad.toFloat()
            class It(val k: String, val t: String)
            val items = ArrayList<It>()
            if (hlOn) items.add(It("avg", (if (typed) "rata-rata kerja " else "rata-rata ") + (if (bike) "${avgV.roundToInt()} km/j" else Js.paceStr(avgV))))
            if (hlOn) items.add(It("best", "tercepat " + (if (bike) "${vals[best].roundToInt()} km/j" else Js.paceStr(sg[best].pace))))
            if (hrOn) items.add(It("hr", "HR bpm"))
            items.forEach { it ->
                val sw = 40f
                when (it.k) {
                    "avg" -> s.line(fx, fy - 9, fx + sw, fy - 9, pal.ink, 3f, .75f, floatArrayOf(10f, 7f))
                    "best" -> s.rr(fx + 8, fy - 24, 24f, 24f, 4f, pal.hl)
                    else -> s.line(fx, fy - 9, fx + sw, fy - 9, RED, 5f)
                }
                s.text(it.t, 26f, 500, pal.ink2, L(), fx + sw + 10, fy)
                fx += sw + 10 + s.tw(it.t, 26f, 500) + 30
            }
        }
        return s.bmp
    }

    /** Split per km. */
    fun split(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs): Bitmap {
        val rows = m.splitRows; val n = rows.size
        val w = 980; val pad = 44; val hd = 78; val rh = 56
        val s = Sk(w, pad * 2 + hd + n * rh, pal, prefs.panel)
        val lo = rows.minOf { it.pace }; val hi = rows.maxOf { it.pace }
        s.head("Split per km", "", w, pad)
        val bx = (pad + 86).toFloat(); val bmax = (w - pad * 2 - 86 - 150).toDouble()
        rows.forEachIndexed { i, r ->
            val y = (pad + hd + i * rh).toFloat()
            val bw = if (hi > lo) (bmax * (.38 + .62 * (hi - r.pace) / (hi - lo))).roundToInt() else (bmax * .7).roundToInt()
            val lab = if (r.partial) (Js.round(r.k * 10) / 10).toString().let { if (com.endurancevault.app.domain.ActInsights.decimalComma) it.replace('.', ',') else it } else Js.round(r.k).toInt().toString()
            s.text(lab, 32f, 500, pal.ink2, L(), pad.toFloat(), y + 34)
            s.rr(bx, y + 6, bw.toFloat(), 32f, 6f, if (r.pace == lo) pal.hl else pal.ink)
            s.text(Js.paceStr(r.pace), 38f, 700, pal.ink, R(), (w - pad).toFloat(), y + 37, true)
        }
        return s.bmp
    }

    /** Grafik elevasi. */
    fun elev(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs): Bitmap {
        val pf = m.detail!!.profile
        val w = 1000; val pad = 44; val gh = 300; val hd = 78
        val s = Sk(w, pad * 2 + hd + gh + 60, pal, prefs.panel)
        val mn = pf.minOf { it.second }; val mx = pf.maxOf { it.second }
        val rg = max(10.0, mx - mn); val kmMax = pf.last().first.takeIf { it > 0 } ?: 1.0
        val gx = pad.toDouble(); val gw = (w - pad * 2).toDouble(); val gy = (pad + hd).toDouble()
        fun X(k: Double) = f(gx + k / kmMax * gw)
        fun Y(e: Double) = f(gy + gh - (e - mn) / rg * gh)
        s.head("Elevasi naik", m.gain?.let { "$it m" } ?: "", w, pad)
        val pts = pf.map { X(it.first) to Y(it.second) }
        s.fillArea(pts, f(gy + gh), withA(pal.ink, .25f))
        s.poly(pts, pal.ink, 8f)
        s.text("${mn.roundToInt()} m", 30f, 500, pal.ink2, L(), pad.toFloat(), f(gy + gh + 46))
        s.text("puncak ${mx.roundToInt()} m", 30f, 500, pal.ink2, R(), (w - pad).toFloat(), f(gy + gh + 46))
        return s.bmp
    }

    /** Zona HR sesi: satu bar per zona; [StickerPrefs.hz] memilih durasi, persen, atau keduanya. */
    fun zone(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs): Bitmap {
        val sc = m.zoneSecs; val t = sc.sum().takeIf { it > 0 } ?: 1.0; val bd = m.zc.bands(); val hz = prefs.hz
        val w = 980; val pad = 44; val hd = 78; val rh = 84
        val s = Sk(w, pad * 2 + hd + 5 * rh, pal, prefs.panel)
        val mxv = sc.max().takeIf { it > 0 } ?: 1.0
        val bx = (pad + 300).toFloat(); val tail = if (hz == "both") 250 else if (hz == "dur") 200 else 150
        val bmax = (w - pad * 2 - 300 - tail).toDouble()
        s.head("Zona HR", Js.durStr(t / 60), w, pad)
        sc.forEachIndexed { i, v ->
            val y = (pad + hd + i * rh).toFloat()
            s.text(zn(i), 40f, 700, pal.ink, L(), pad.toFloat(), y + 46, true)
            s.text("${bd[i]} bpm", 26f, 500, pal.ink2, L(), pad + 82f, y + 44)
            if (v > 0) s.rr(bx, y + 10, max(6.0, (bmax * v / mxv).roundToInt().toDouble()).toFloat(), 44f, 6f, rgb(Stickers.ZONE_RGB[i]))
            val dTxt = if (v > 0) Js.durStr(v / 60) else "–"; val pTxt = "${(v / t * 100).roundToInt()}%"
            when (hz) {
                "dur" -> s.text(dTxt, 40f, 700, pal.ink, R(), (w - pad).toFloat(), y + 46, true)
                "pct" -> s.text(if (v > 0) pTxt else "–", 40f, 700, pal.ink, R(), (w - pad).toFloat(), y + 46, true)
                else -> { s.text(dTxt, 38f, 700, pal.ink, R(), (w - pad - 100).toFloat(), y + 46, true); s.text(pTxt, 30f, 500, pal.ink2, R(), (w - pad).toFloat(), y + 46) }
            }
        }
        return s.bmp
    }

    /** Zona HR sebagai satu bar horizontal bertumpuk; label yang berdempetan digeser dan diberi garis penuntun. */
    fun zoneStack(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs): Bitmap {
        val sc = m.zoneSecs; val t = sc.sum().takeIf { it > 0 } ?: 1.0; val hz = prefs.hz
        val w = 980; val pad = 44; val hd = 78; val bh = 76; val gap = 4; val by = pad + hd
        class Sg(val i: Int, val v: Double) { var w = 0.0; var x = 0.0; var cx = 0.0; var pc = ""; var du = "" }
        val segs = sc.toList().mapIndexedNotNull { i, v -> if (v > 0) Sg(i, v) else null }
        val cw = w - pad * 2 - gap * max(0, segs.size - 1)
        val meter = Sk(10, 10, pal, "off")
        var x = pad.toDouble(); var lw = 0f
        segs.forEach { g ->
            g.w = g.v / t * cw; g.x = x; g.cx = x + g.w / 2; x += g.w + gap
            val pc = (g.v / t * 100).roundToInt(); g.pc = (if (pc < 1) "<1" else pc.toString()) + "%"; g.du = Js.durStr(g.v / 60)
            lw = max(lw, max(meter.tw(zn(g.i), 36f, 700, true), max(meter.tw(g.pc, 32f, 700, true), if (hz == "pct") 0f else meter.tw(g.du, 28f, 500))))
        }
        lw += 18
        val lx = segs.map { it.cx }.toDoubleArray()
        for (a in lx.indices) lx[a] = max(lx[a], if (a > 0) lx[a - 1] + lw else pad + lw / 2.0)
        for (b in lx.indices.reversed()) lx[b] = min(lx[b], if (b < lx.size - 1) lx[b + 1] - lw else w - pad - lw / 2.0)
        val h = by + bh + (if (hz == "both") 134 else 96) + pad
        val s = Sk(w, h, pal, prefs.panel)
        s.head("Zona HR", Js.durStr(t / 60), w, pad)
        segs.forEachIndexed { k, g ->
            s.rr(f(g.x), by.toFloat(), max(4f, f(g.w)), bh.toFloat(), 8f, rgb(Stickers.ZONE_RGB[g.i]))
            val cx = f(lx[k])
            if (abs(cx - g.cx) > 6) s.line(f(g.cx), (by + bh + 6).toFloat(), cx, (by + bh + 24).toFloat(), pal.ink2, 2f)
            s.text(zn(g.i), 36f, 700, pal.ink, C(), cx, (by + bh + 58).toFloat(), true)
            if (hz == "dur") s.text(g.du, 30f, 700, pal.ink2, C(), cx, (by + bh + 96).toFloat(), true)
            else {
                s.text(g.pc, 32f, 700, pal.ink2, C(), cx, (by + bh + 96).toFloat(), true)
                if (hz == "both") s.text(g.du, 28f, 500, pal.ink2, C(), cx, (by + bh + 130).toFloat())
            }
        }
        return s.bmp
    }

    /** Pace per repetisi interval: bar hijau bila lebih cepat dari rata-rata, oranye bila lebih lambat; garis putus-putus = rata-rata. */
    fun rep(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs): Bitmap {
        val iv = m.iv!!; val reps = iv.reps; val st = iv.stats; val n = reps.size
        val w = 1000; val pad = 44; val gh = 300; val hd = 78
        val s = Sk(w, pad * 2 + hd + gh, pal, prefs.panel)
        val pt = 52; val pb = 48; val gy = pad + hd
        val lo = st.best - .04 * st.avg; val hi = st.worst + .06 * st.avg
        val span = (hi - lo).takeIf { it != 0.0 && !it.isNaN() } ?: 1.0
        fun y(p: Double) = gy + pt + (p - lo) / span * (gh - pt - pb)
        s.head("Pace per repetisi", "rata-rata " + Js.paceStr(st.avg) + "/km", w, pad)
        val bw = (w - pad * 2).toDouble() / n; val gap = min(14.0, bw * .25); val lab = n <= 12
        reps.forEachIndexed { i, r ->
            val x = pad + i * bw + gap / 2; val bwd = max(4.0, bw - gap); val top = y(r.p)
            s.rr(f(x), f(top), f(bwd), f(gy + gh - pb - top), 6f, if (r.p <= st.avg) GREEN else ORANGE, if (i == st.bestI) 1f else .8f)
            if (lab) s.text(Js.paceStr(r.p), 30f, 700, Color.WHITE, C(), f(x + bwd / 2), f((gy + gh - pb - 16).toDouble()), true)
            if (lab || i % 2 == 0) s.text((i + 1).toString(), 28f, 500, pal.ink2, C(), f(x + bwd / 2), (gy + gh - 10).toFloat())
        }
        if (!lab) {
            val bi = st.bestI; val bx = pad + bi * bw + bw / 2
            s.text(Js.paceStr(reps[bi].p), 30f, 700, pal.ink, C(), f(bx), f(y(reps[bi].p) - 10), true)
        }
        val ay = f(y(st.avg))
        s.line(pad.toFloat(), ay, (w - pad).toFloat(), ay, pal.ink, 3f, 1f, floatArrayOf(14f, 10f))
        return s.bmp
    }

    /** Tren pace mingguan: garis pace rata-rata tiap minggu (makin cepat makin tinggi), minggu ini disorot dengan warna aksen. */
    fun trend(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs): Bitmap {
        val pts = m.trend(prefs.trendWeeks)!!; val n = pts.size; val cur = pts[n - 1]; val prev = if (n > 1) pts[n - 2] else null
        val w = 980; val pad = 44; val hd = 78; val sub = 64; val gh = 320
        val s = Sk(w, pad * 2 + hd + sub + gh + 96, pal, prefs.panel)
        s.head("Tren pace", Js.paceStr(cur.pace) + "/km", w, pad)
        val gy = pad + hd + sub
        val lo = pts.minOf { it.pace }; val hi = pts.maxOf { it.pace }
        val rg = max(hi - lo, .15); val top = gy + 56; val ph = gh - 56 - 14
        fun px(i: Int) = pad + 70 + i * (w - 2 * (pad + 70)).toDouble() / (n - 1)
        fun py(p: Double) = top + (p - lo) / rg * ph
        val line = "Minggu ${cur.index + 1}"
        val ty = (pad + hd + 34).toFloat()
        if (prev != null) {
            val d = cur.pace - prev.pace
            val col = if (abs(d) * 60 < 1) pal.ink2 else if (d < 0) pal.hl else ORANGE
            s.text("$line · ", 34f, 500, pal.ink2, L(), pad.toFloat(), ty)
            val lw = s.tw("$line · ", 34f, 500)
            s.text(Stickers.dPace(d) + " /km vs minggu M${prev.index + 1}", 34f, 700, col, L(), pad + lw, ty)
        } else s.text(line, 34f, 500, pal.ink2, L(), pad.toFloat(), ty)
        s.poly(pts.mapIndexed { i, q -> f(px(i)) to f(py(q.pace)) }, pal.ink, 5f, .9f)
        var bi = 0; pts.forEachIndexed { i, q -> if (q.pace < pts[bi].pace) bi = i }
        pts.forEachIndexed { i, q ->
            val x = f(px(i)); val y = f(py(q.pace))
            s.circle(x, y, if (q.cur) 17f else 10f, if (q.cur) pal.hl else pal.ink)
            if (n <= 6 || q.cur || i == bi || i == 0)
                s.text(Js.paceStr(q.pace), if (q.cur) 38f else 30f, 700, if (q.cur) pal.hl else pal.ink, C(), x, y - (if (q.cur) 28f else 22f), true)
            s.text("M${q.index + 1}", 28f, if (q.cur) 700 else 500, if (q.cur) pal.ink else pal.ink2, C(), x, (gy + gh + 52).toFloat())
        }
        return s.bmp
    }

    /** Zona HR minggu: lima bar vertikal; [StickerPrefs.hz] memilih durasi/persen, [StickerPrefs.weekColor] mewarnai semua bar satu warna. */
    fun zoneWk(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs): Bitmap {
        val ws = m.wkCtx!!.summary; val z = ws.zones!!; val sc = z.secs; val hz = prefs.hz
        val tt = z.total.takeIf { it > 0 } ?: 1.0
        val w = 980; val pad = 44; val gh = 300; val hd = 78
        val s = Sk(w, pad * 2 + hd + gh + 110 + (if (hz == "both") 38 else 0), pal, prefs.panel)
        val mx = sc.max().takeIf { it > 0 } ?: 1.0
        val colW = (w - pad * 2) / 5.0; val bw = colW - 40; val gy = pad + hd
        val wc = if (prefs.weekColor.isNotEmpty()) Color.parseColor(prefs.weekColor) else 0
        s.head("Zona HR minggu ${ws.index + 1}", Js.durStr(z.total / 60), w, pad)
        sc.forEachIndexed { i, v ->
            val x = pad + i * colW + 20; val h = max(if (v > 0) 8 else 0, Js.round(v / mx * gh).toInt()); val cx = f(x + bw / 2)
            val pTxt = if (v > 0) "${Js.round(v / tt * 100).toInt()}%" else "–"; val dTxt = if (v > 0) Js.durStr(v / 60) else "–"
            if (h > 0) s.rr(f(x), (gy + gh - h).toFloat(), f(bw), h.toFloat(), 8f, if (wc != 0) wc else rgb(Stickers.ZONE_RGB[i]))
            s.text(zn(i), 36f, 700, pal.ink, C(), cx, (gy + gh + 44).toFloat(), true)
            if (hz == "pct") s.text(pTxt, 32f, 700, pal.ink2, C(), cx, (gy + gh + 86).toFloat())
            else {
                s.text(dTxt, 28f, 500, pal.ink2, C(), cx, (gy + gh + 84).toFloat())
                if (hz == "both") s.text(pTxt, 28f, 500, pal.ink2, C(), cx, (gy + gh + 122).toFloat())
            }
        }
        return s.bmp
    }

    /** Target minggu: bar rencana (garis) dan aktual (isi) per hari. Km tiap hari di atas bar; teks atas memuat persen dan sisa km. */
    fun target(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs): Bitmap {
        val ws = m.wkCtx!!.summary; val days = ws.days
        val w = 980; val pad = 44; val gh = 240; val hd = 78
        val s = Sk(w, pad * 2 + hd + 120 + gh + 70 + 34, pal, prefs.panel)
        var mx = 1.0; days.forEach { mx = max(mx, max(it.plan, it.act)) }
        s.head("Target minggu ${ws.index + 1}", "", w, pad)
        val vs = String.format(java.util.Locale.ROOT, "%.1f", Js.round(ws.km * 10) / 10).let { if (com.endurancevault.app.domain.ActInsights.decimalComma) it.replace('.', ',') else it }
        val vw = s.tw(vs, 110f, 700, true); val by = pad + hd + 100
        s.text(vs, 110f, 700, pal.ink, L(), pad.toFloat(), by.toFloat(), true)
        val left = ws.planKm - ws.km
        val tx = "/ " + Js.fmtKm(ws.planKm) + " km" + (if (ws.planKm > 0) " · ${Js.round(ws.km / ws.planKm * 100).toInt()}%" else "") +
            (if (left > 0.05) " · sisa " + Js.fmtKm(left) + " km" else "")
        s.text(tx, 38f, 500, pal.ink2, L(), pad + vw + 16, by.toFloat())
        val colW = (w - pad * 2) / 7.0; val bw = colW - 26; val gy = by + 74
        val fillC = if (prefs.weekColor.isNotEmpty()) Color.parseColor(prefs.weekColor) else pal.hl
        fun num1d(v: Double): String { val r = Js.round(v * 10) / 10; return if (r == Math.floor(r)) r.toLong().toString() else r.toString().let { if (com.endurancevault.app.domain.ActInsights.decimalComma) it.replace('.', ',') else it } }
        days.forEachIndexed { i, d ->
            val x = pad + i * colW + 13; val ph = Js.round(d.plan / mx * gh).toInt(); val ah = Js.round(min(d.act, mx) / mx * gh).toInt()
            if (d.plan > 0) s.strokeRect(f(x + 2), (gy + gh - ph + 2).toFloat(), f(bw - 4), max(0, ph - 4).toFloat(), pal.ink, 4f)
            else s.line(f(x), (gy + gh - 2).toFloat(), f(x + bw), (gy + gh - 2).toFloat(), pal.ink, 4f, 1f, floatArrayOf(10f, 8f))
            if (ah > 0) s.rect(f(x + 4), (gy + gh - ah).toFloat(), f(bw - 8), (ah - 2).toFloat(), fillC)
            val lv = if (d.act > 0) d.act else d.plan
            if (lv > 0) s.text(num1d(lv), 28f, 700, if (d.act > 0) pal.ink else pal.ink2, C(), f(x + bw / 2), (gy + gh - max(ph, ah) - 12).toFloat(), true)
            s.text(d.label, 30f, 500, pal.ink2, C(), f(x + bw / 2), (gy + gh + 44).toFloat())
        }
        return s.bmp
    }

    // ---- statistik periode: harian, mingguan, bulanan (dulu kartu "Bagikan statistik") ----

    /** Angka km besar untuk periode terpilih, tanggal periode di bawahnya. */
    fun pHero(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs, per: String): Bitmap {
        val sm = m.periodSummary(per)!!
        val t = heroKm(sm)
        val w = 900; val pad = 44
        val probe = Sk(10, 10, pal, "off")
        var px = 300f
        while (px > 140f && probe.tw(t, px, 700, true) + probe.tw("km", px * .28f, 500) + 24f > (w - pad * 2).toFloat()) px -= 10f
        val up = px * .28f
        val vw = probe.tw(t, px, 700, true)
        val base = pad + 76f + px * .85f
        val s = Sk(w, (base + 70f + pad).toInt(), pal, prefs.panel)
        s.text(m.numPer("jarak", per)?.label ?: "Jarak", 34f, 500, pal.ink2, L(), pad.toFloat(), pad + 34f)
        s.text(t, px, 700, pal.ink, L(), pad.toFloat(), base, true)
        s.text("km", up, 500, pal.ink2, L(), pad + vw + 14f, base)
        s.text(perText(sm), 38f, 500, pal.ink2, L(), pad.toFloat(), base + 64f)
        return s.bmp
    }

    /** Kalender panas: mingguan = tujuh sel bernilai km, bulanan = kalender mulai tanggal 1 (kolom Senin sampai Minggu). */
    fun pCalendar(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs, per: String): Bitmap {
        val sm = m.periodSummary(per)!!
        val week = sm.period == SharePeriod.WEEK
        val offset = sm.start.dayOfWeek.value - 1
        val n = sm.dailyKm.size
        val rows = (offset + n + 6) / 7
        val w = 980; val pad = 44; val hd = 78; val gap = 12f
        val cw = (w - pad * 2 - gap * 6) / 7f
        val ch = if (week) cw * 1.5f else cw * .9f
        val top = pad + hd + 40f
        val s = Sk(w, (top + rows * (ch + gap) + pad).toInt(), pal, prefs.panel)
        s.head(perText(sm), heroKm(sm) + " km", w, pad)
        for (i in 0 until 7) s.text(DAY_SHORT[i].take(1), 28f, 500, pal.ink2, C(), pad + i * (cw + gap) + cw / 2f, top - 10f)
        sm.dailyKm.forEachIndexed { i, v ->
            val pos = offset + i
            val x = pad + (pos % 7) * (cw + gap); val y = top + (pos / 7) * (ch + gap)
            val a = when { v < 6.5 -> .4f; v < 10.0 -> .65f; v < 15.0 -> .85f; else -> 1f }
            if (v > 0.0) s.rr(x, y, cw, ch, 14f, pal.hl, a) else s.rr(x, y, cw, ch, 14f, pal.ink, .12f)
            val tc = if (v > 0.0) onFill(pal.hl) else pal.ink2
            if (week) { if (v > 0.0) s.text(Stickers.km1(v), 32f, 700, tc, C(), x + cw / 2f, y + ch / 2f + 11f, true) }
            else s.text("${sm.start.dayOfMonth + i}", 22f, 500, tc, L(), x + 10f, y + 28f)
        }
        return s.bmp
    }

    /** Kurva jarak per hari dengan area di bawahnya; hari terjauh diberi angka. */
    fun pCurve(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs, per: String): Bitmap {
        val sm = m.periodSummary(per)!!
        val v = sm.dailyKm; val n = v.size
        val w = 980; val pad = 44; val hd = 78; val gh = 280
        val s = Sk(w, pad * 2 + hd + gh + 120, pal, prefs.panel)
        s.head(perText(sm), heroKm(sm) + " km", w, pad)
        val gx = pad + 12f; val gw = w - pad * 2 - 24f
        val base = (pad + hd + 60 + gh).toFloat()
        val mx = max(1.0, v.maxOrNull() ?: 1.0)
        val pts = v.mapIndexed { i, k -> (gx + i * gw / (n - 1)) to (base - (k / mx * (gh - 40)).toFloat()) }
        s.fillArea(pts, base, withA(pal.hl, .25f))
        s.poly(pts, pal.hl, 8f)
        s.line(gx, base, gx + gw, base, pal.line, 3f)
        if (n <= 14) pts.forEach { s.circle(it.first, it.second, 8f, pal.hl) }
        var bi = 0
        v.forEachIndexed { i, k -> if (k > v[bi]) bi = i }
        if (v[bi] > 0.0) {
            s.circle(pts[bi].first, pts[bi].second, 12f, pal.ink)
            s.text(Stickers.km1(v[bi]), 30f, 700, pal.ink, C(), pts[bi].first.coerceIn(gx + 30f, gx + gw - 30f), pts[bi].second - 22f, true)
        }
        v.indices.forEach { i ->
            val week = sm.period == SharePeriod.WEEK
            if (week || i % 7 == 0) s.text(if (week) DAY_SHORT[i] else "${sm.start.dayOfMonth + i}", 28f, 500, pal.ink2, C(), gx + i * gw / (n - 1), base + 44f)
        }
        return s.bmp
    }

    /** Cincin jarak terhadap target rencana pada periode itu. */
    fun pRing(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs, per: String): Bitmap {
        val sm = m.periodSummary(per)!!
        val target = m.periods?.target?.get(sm.period) ?: 1.0
        val frac = if (target > 0.0) sm.km / target else 0.0
        val size = 760; val cx = size / 2f; val cy = 380f; val r = 270f; val sw = 56f
        val s = Sk(size, 840, pal, prefs.panel)
        val box = RectF(cx - r, cy - r, cx + r, cy + r)
        val ap = Paint(Paint.ANTI_ALIAS_FLAG)
        ap.style = Paint.Style.STROKE; ap.strokeWidth = sw; ap.strokeCap = Paint.Cap.ROUND
        if (pal.sh != 0) ap.setShadowLayer(12f, 0f, 3f, pal.sh)
        ap.color = withA(pal.ink, .15f); s.c.drawArc(box, 0f, 360f, false, ap)
        if (frac > 0.0) { ap.color = pal.hl; s.c.drawArc(box, -90f, (min(1.0, frac) * 360.0).toFloat().coerceAtLeast(2f), false, ap) }
        val t = heroKm(sm)
        var px = 170f; val inner = (r - sw) * 2 - 70f
        while (px > 80f && s.tw(t, px, 700, true) > inner) px -= 6f
        s.text(t, px, 700, pal.ink, C(), cx, cy + 20f, true)
        s.text("dari ${Stickers.km1(target)} km rencana", 36f, 500, pal.ink2, C(), cx, cy + 82f)
        s.text("${Js.round(frac * 100).toInt()}%", 64f, 700, pal.hl, C(), cx, cy + 166f, true)
        s.text(perText(sm), 32f, 500, pal.ink2, C(), cx, 810f)
        return s.bmp
    }

    /** Selisih terhadap periode sebelumnya (minggu lalu, bulan lalu, atau rata-rata per lari 28 hari untuk harian). */
    fun pCompare(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs, per: String): Bitmap {
        val sm = m.periodSummary(per)!!
        val prev = m.periods!!.prev[sm.period]!!
        val w = 980; val pad = 44; val hd = 78
        val pct = if (prev.km > 0.0) ((sm.km - prev.km) / prev.km * 100).roundToInt() else 0
        val up = pct >= 0
        val col = if (up) GREEN else ORANGE
        val dDur = sm.durationSec - prev.durationSec
        val pc = sm.avgPace; val pp = prev.avgPace
        val dPace = if (pc != null && pp != null) ((pc - pp) * 60).roundToInt() else null
        val dGain = sm.gain - prev.gain
        fun sgn(n: Int) = if (n >= 0) "+" else "\u2212"
        val rows = listOf(
            Triple("Durasi", sgn(dDur) + Js.durStr(abs(dDur) / 60.0), pal.ink),
            Triple("Pace", if (dPace == null) "–" else sgn(dPace) + abs(dPace) + " dtk/km", if (dPace == null) pal.ink else if (dPace <= 0) GREEN else ORANGE),
            Triple("Elevasi", sgn(dGain) + abs(dGain) + " m", pal.ink),
        )
        val y1 = pad + hd + 10f
        val barsTop = y1 + 150f
        val deltaTop = barsTop + 250f
        val s = Sk(w, (deltaTop + 24f + rows.size * 82f + pad).toInt(), pal, prefs.panel)
        s.head(perText(sm), "", w, pad)
        val big = (if (up) "+" else "\u2212") + abs(pct) + "%"
        val bw = s.tw(big, 110f, 700, true)
        s.text(big, 110f, 700, col, L(), pad.toFloat(), y1 + 100f, true)
        s.text("dari ${PeriodStats.previousLabel(sm.period)}", 38f, 500, pal.ink2, L(), pad + bw + 18f, y1 + 100f)
        val mx = max(sm.km, prev.km).coerceAtLeast(0.1)
        val full = w - pad * 2f
        fun bar(y: Float, label: String, km: Double, c: Int, a: Float) {
            s.text(label, 32f, 500, pal.ink2, L(), pad.toFloat(), y + 30f)
            s.text(Stickers.km1(km) + " km", 36f, 700, pal.ink, R(), (w - pad).toFloat(), y + 32f, true)
            s.rr(pad.toFloat(), y + 48f, max(24f, (full * (km / mx)).toFloat()), 44f, 22f, c, a)
        }
        // Periode berjalan: pembanding hanya sejumlah hari yang sama, dan rentangnya ditampilkan.
        val partial = sm.period != SharePeriod.DAY && prev.end.isBefore(PeriodStats.range(sm.period, prev.start).second)
        val curLabel = if (partial) perNoun(sm) + " · " + spanText(sm.start, sm.start.plusDays((prev.dailyKm.size - 1).toLong())) else perNoun(sm)
        val prevName = PeriodStats.previousLabel(sm.period).replaceFirstChar { it.uppercase() }
        bar(barsTop, curLabel, sm.km, pal.hl, 1f)
        bar(barsTop + 120f, if (partial) prevName + " · " + spanText(prev.start, prev.end) else prevName, prev.km, pal.ink, .45f)
        s.line(pad.toFloat(), deltaTop, (w - pad).toFloat(), deltaTop, pal.line, 2f)
        rows.forEachIndexed { i, (label, value, c) ->
            val y = deltaTop + 66f + i * 82f
            s.text(label, 38f, 500, pal.ink2, L(), pad.toFloat(), y)
            s.text(value, 48f, 700, c, R(), (w - pad).toFloat(), y, true)
        }
        return s.bmp
    }

    /** Bar km per minggu dalam bulan; minggu terjauh disorot penuh. */
    fun pWeeks(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs, per: String): Bitmap {
        val sm = m.periodSummary(per)!!
        val wk = m.periods?.monthWeeks.orEmpty()
        val w = 980; val pad = 44; val hd = 78; val rh = 84f
        val s = Sk(w, (pad * 2 + hd + 30 + wk.size * rh).toInt(), pal, prefs.panel)
        s.head(perText(sm), heroKm(sm) + " km", w, pad)
        val top = pad + hd + 30f
        val bx = pad + 270f
        val bw = w - pad - 190f - bx
        val mx = max(1.0, wk.maxOfOrNull { it.km } ?: 1.0)
        val best = wk.indices.maxByOrNull { wk[it].km } ?: 0
        wk.forEachIndexed { i, k ->
            val y = top + i * rh
            s.text(spanText(k.start, k.end), 34f, 500, pal.ink2, L(), pad.toFloat(), y + 46f)
            if (k.km > 0.0) s.rr(bx, y + 14f, max(18f, (bw * (k.km / mx)).toFloat()), 44f, 22f, pal.hl, if (i == best) 1f else .55f)
            else s.rr(bx, y + 14f, 18f, 44f, 22f, pal.ink, .15f)
            s.text(Stickers.km1(k.km) + " km", 36f, 700, pal.ink, R(), (w - pad).toFloat(), y + 48f, true)
        }
        return s.bmp
    }

    /** Rekor bulan: lari terpanjang, pace tercepat (minimal 3 km), dan tanjakan terbanyak, masing-masing dengan tanggalnya. */
    fun pRecords(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs, per: String): Bitmap {
        val sm = m.periodSummary(per)!!
        val r = m.periods?.records!!
        val rows = listOfNotNull(
            RecRow("Lari terpanjang", Stickers.km2(r.longestKm), "km", "", r.longestDate),
            r.fastestPace?.let { RecRow("Pace tercepat (≥ 3 km)", Js.paceStr(it), "/km", Stickers.km2(r.fastestKm ?: 0.0) + " km", r.fastestDate) },
            if (r.topGain > 0) RecRow("Elevasi terbanyak", r.topGain.toString(), "m", "", r.topGainDate) else null,
        )
        val w = 980; val pad = 44; val hd = 78; val rh = 150f
        val s = Sk(w, (pad * 2 + hd + 20 + rows.size * rh).toInt(), pal, prefs.panel)
        s.head(perText(sm), "Rekor bulan", w, pad)
        val top = pad + hd + 20f
        rows.forEachIndexed { i, row ->
            val y = top + i * rh
            if (i > 0) s.line(pad.toFloat(), y, (w - pad).toFloat(), y, pal.line, 2f)
            s.text(row.label, 32f, 500, pal.ink2, L(), pad.toFloat(), y + 44f)
            if (row.sub.isNotEmpty()) s.text(row.sub, 30f, 500, pal.ink2, R(), (w - pad).toFloat(), y + 44f)
            val vw = s.tw(row.value, 84f, 700, true)
            s.text(row.value, 84f, 700, pal.ink, L(), pad.toFloat(), y + 126f, true)
            s.text(row.unit, 40f, 500, pal.ink2, L(), pad + vw + 12f, y + 126f)
            row.date?.let { d -> s.text("${d.dayOfMonth} ${MON_SHORT[d.monthValue - 1]}", 38f, 500, pal.ink2, R(), (w - pad).toFloat(), y + 126f) }
        }
        return s.bmp
    }

    // ---- stiker tambahan: aerobik, vert, vs PR, vs rute serupa, hitung mundur, beban, tahun, streak ----

    /** Stiker MAF / Aerobik: HR rata-rata, porsi waktu per zona, drift HR (efisiensi paruh pertama dan kedua), dan pace. */
    fun maf(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs): Bitmap {
        val mi = m.maf!!
        val w = 980; val pad = 44; val hd = 78
        val s = Sk(w, 640, pal, prefs.panel)
        s.head("MAF · Aerobik", mi.easy?.let { "easy ≤ $it" } ?: "", w, pad)
        val y0 = (pad + hd).toFloat()
        s.text("HR rata-rata", 30f, 500, pal.ink2, L(), pad.toFloat(), y0 + 30f)
        val hv = mi.hr.toString(); val vw = s.tw(hv, 120f, 700, true)
        s.text(hv, 120f, 700, pal.ink, L(), pad.toFloat(), y0 + 156f, true)
        s.text("bpm", 48f, 500, pal.ink2, L(), pad + vw + 12f, y0 + 156f)
        val by = y0 + 190f; val cw = (w - pad * 2).toFloat()
        val parts = listOf(
            Triple("Z1", mi.z1, rgb(Stickers.ZONE_RGB[0])), Triple("Z2", mi.z12 - mi.z1, rgb(Stickers.ZONE_RGB[1])),
            Triple("Z3", mi.z3, rgb(Stickers.ZONE_RGB[2])), Triple("Z4–5", mi.z45, rgb(Stickers.ZONE_RGB[3])),
        ).filter { it.second >= .5 }
        var x = pad.toFloat()
        parts.forEach { (_, v, col) -> val bw = max(6f, f(v / 100.0 * cw) - 3f); s.rr(x, by, bw, 40f, 8f, col); x += bw + 3f }
        var lx = pad.toFloat(); val ly = by + 84f
        parts.forEach { (name, v, col) ->
            val t = "$name ${v.roundToInt()}%"
            s.rr(lx, ly - 22f, 22f, 22f, 4f, col)
            s.text(t, 28f, 500, pal.ink2, L(), lx + 32f, ly)
            lx += 32f + s.tw(t, 28f, 500) + 28f
        }
        val stats = ArrayList<Triple<String, String, String>>()
        mi.drift?.let { d -> val r = (Js.round(d * 10) / 10); stats.add(Triple("Drift HR", (if (r > 0) "+" else if (r < 0) "−" else "") + String.format(java.util.Locale.ROOT, "%.1f", abs(r)).replace('.', ','), "%")) }
        mi.pace?.let { stats.add(Triple("Pace rata-rata", Js.paceStr(it), "/km")) }
        val sy = ly + 76f; val colW = cw / max(1, stats.size)
        stats.forEachIndexed { i, (lab, v, u) ->
            val sx = pad + i * colW
            s.text(lab, 30f, 500, pal.ink2, L(), sx, sy + 30f)
            val tw = s.tw(v, 72f, 700, true)
            s.text(v, 72f, 700, pal.ink, L(), sx, sy + 108f, true)
            s.text(u, 30f, 500, pal.ink2, L(), sx + tw + 8f, sy + 108f)
        }
        return s.bmp
    }

    /** Stiker Vert: elevasi naik, profil berwarna menurut kemiringan, VAM, GAP, dan elevasi turun. */
    fun vert(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs): Bitmap {
        val d = m.detail!!; val pf = d.profile
        val w = 1000; val pad = 44; val hd = 78; val gh = 220
        val step = max(1, pf.size / 120)
        val pts0 = pf.filterIndexed { i, _ -> i % step == 0 || i == pf.lastIndex }
        val mn = pts0.minOf { it.second }; val mx = pts0.maxOf { it.second }
        val rg = max(10.0, mx - mn); val kmMax = pf.last().first.takeIf { it > 0 } ?: 1.0
        val y0 = (pad + hd).toFloat(); val gy = y0 + 170f; val gx = pad.toDouble(); val gw = (w - pad * 2).toDouble()
        val stats = ArrayList<Triple<String, String, String>>()
        d.vam?.avg?.takeIf { it > 0 }?.let { stats.add(Triple("VAM rata-rata", Js.idn(it), "m/j")) }
        m.gapPace?.takeIf { it > 0 }?.let { stats.add(Triple("GAP", Js.paceStr(it), "/km")) }
        d.loss?.takeIf { it > 0 }?.let { stats.add(Triple("Turun", Js.idn(it), "m")) }
        val h = (gy + gh + 62f + (if (stats.isEmpty()) 0f else 120f) + pad).toInt()
        val s = Sk(w, h, pal, prefs.panel)
        s.head("Vert", "", w, pad)
        s.text("Elevasi naik", 30f, 500, pal.ink2, L(), pad.toFloat(), y0 + 30f)
        val gv = Js.idn(m.gain ?: 0); val vw = s.tw(gv, 110f, 700, true)
        s.text(gv, 110f, 700, pal.ink, L(), pad.toFloat(), y0 + 146f, true)
        s.text("m", 44f, 500, pal.ink2, L(), pad + vw + 12f, y0 + 146f)
        fun X(k: Double) = f(gx + k / kmMax * gw)
        fun Y(e: Double) = f(gy + gh - (e - mn) / rg * gh)
        val pts = pts0.map { X(it.first) to Y(it.second) }
        s.fillArea(pts, f(gy + gh.toDouble()), withA(pal.ink, .2f))
        for (i in 1 until pts0.size) {
            val dk = (pts0[i].first - pts0[i - 1].first) * 1000.0
            val grade = if (dk > 0) (pts0[i].second - pts0[i - 1].second) / dk * 100 else 0.0
            val col = when { grade >= 8 -> RED; grade >= 3 -> ORANGE; grade <= -3 -> GREEN; else -> pal.ink }
            s.poly(listOf(pts[i - 1], pts[i]), col, 7f)
        }
        var lx = pad.toFloat(); val ly = gy + gh + 44f
        listOf("Curam ≥ 8%" to RED, "Naik 3–8%" to ORANGE, "Turun ≥ 3%" to GREEN, "Datar" to pal.ink).forEach { (t, c) ->
            s.circle(lx + 9f, ly - 8f, 9f, c)
            s.text(t, 24f, 500, pal.ink2, L(), lx + 26f, ly)
            lx += 26f + s.tw(t, 24f, 500) + 26f
        }
        val colW = (w - pad * 2).toFloat() / max(1, stats.size); val sy = ly + 34f
        stats.forEachIndexed { i, (lab, v, u) ->
            val sx = pad + i * colW
            s.text(lab, 28f, 500, pal.ink2, L(), sx, sy + 28f)
            val tw = s.tw(v, 62f, 700, true)
            s.text(v, 62f, 700, pal.ink, L(), sx, sy + 90f, true)
            s.text(u, 26f, 500, pal.ink2, L(), sx + tw + 8f, sy + 90f)
        }
        return s.bmp
    }

    private fun dmy(iso: String): String {
        val d = runCatching { java.time.LocalDate.parse(iso.take(10)) }.getOrNull() ?: return iso
        return "${d.dayOfMonth} ${MON_SHORT[d.monthValue - 1]} ${d.year}"
    }

    /** Stiker Vs PR: waktu hari ini, PR, selisih, dan dua bar (yang lebih cepat lebih panjang). */
    fun vsPr(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs): Bitmap {
        val c = m.prCmp!!
        val w = 980; val pad = 44; val hd = 78
        val s = Sk(w, 560, pal, prefs.panel)
        s.head("Vs PR", c.label, w, pad)
        val y0 = (pad + hd).toFloat(); val d = c.todayMin - c.prMin
        val delta: Triple<String, String, Int> = when {
            c.isPr && d < -1e-9 -> Triple("Lebih cepat", "−" + Js.durStr(-d), GREEN)
            c.isPr -> Triple("Hasil", "PR!", pal.hl)
            else -> Triple("Selisih", "+" + Js.durStr(d), ORANGE)
        }
        val cols = listOf(Triple("Hari ini", Js.durStr(c.todayMin), pal.ink), Triple("PR", Js.durStr(c.prMin), pal.ink), delta)
        cols.forEachIndexed { i, (lab, v, col) ->
            val x = pad + i * 320f
            s.text(lab, 30f, 500, pal.ink2, L(), x, y0 + 30f)
            s.text(v, 84f, 700, col, L(), x, y0 + 130f, true)
        }
        val full = (w - pad * 2).toFloat(); val fast = min(c.todayMin, c.prMin)
        fun bar(y: Float, label: String, t: Double, col: Int, a: Float) {
            s.text(label, 30f, 500, pal.ink2, L(), pad.toFloat(), y + 30f)
            s.rr(pad.toFloat(), y + 46f, max(24f, f(full * fast / t)), 40f, 20f, col, a)
        }
        bar(y0 + 190f, "Hari ini · " + dmy(m.date), c.todayMin, pal.hl, 1f)
        bar(y0 + 310f, "PR · " + dmy(c.prDate), c.prMin, pal.ink, .45f)
        return s.bmp
    }

    /** Stiker Vs rute serupa: selisih pace terhadap lari lain di rute yang sama dan titik pace tiap lari. */
    fun vsRoute(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs): Bitmap {
        val rc = m.extras!!.sameRoute!!; val pts = rc.points; val n = pts.size
        val w = 980; val pad = 44; val hd = 78; val gh = 200
        val s = Sk(w, pad * 2 + hd + 150 + gh + 90, pal, prefs.panel)
        s.head("Vs rute serupa", "$n lari", w, pad)
        val y0 = (pad + hd).toFloat(); val d = rc.deltaMin
        val col = if (abs(d) * 60 < 1) pal.ink2 else if (d < 0) pal.hl else ORANGE
        val big = Stickers.dPace(d); val bw = s.tw(big, 110f, 700, true)
        s.text("Pace hari ini", 30f, 500, pal.ink2, L(), pad.toFloat(), y0 + 30f)
        s.text(big, 110f, 700, col, L(), pad.toFloat(), y0 + 146f, true)
        s.text("/km vs rata-rata lari lain", 36f, 500, pal.ink2, L(), pad + bw + 16f, y0 + 146f)
        val lo = pts.minOf { it.pace }; val hi = pts.maxOf { it.pace }; val rg = max(hi - lo, .15)
        val top = y0 + 230f; val ph = gh - 60f
        fun px(i: Int) = f(pad + 60 + i * (w - 2 * (pad + 60)).toDouble() / (n - 1))
        fun py(p: Double) = f(top + (p - lo) / rg * ph)
        val ay = py(rc.avgOthers)
        s.line((pad).toFloat(), ay, (w - pad).toFloat(), ay, pal.ink2, 3f, .8f, floatArrayOf(14f, 10f))
        s.poly(pts.mapIndexed { i, q -> px(i) to py(q.pace) }, pal.ink, 5f, .7f)
        pts.forEachIndexed { i, q ->
            val x = px(i); val y = py(q.pace)
            s.circle(x, y, if (q.current) 17f else 10f, if (q.current) pal.hl else pal.ink)
            s.text(Js.paceStr(q.pace), if (q.current) 34f else 28f, 700, if (q.current) pal.hl else pal.ink, C(), x, y - 26f, true)
            s.text(spanText(q.date, q.date), 24f, 500, pal.ink2, C(), x, top + gh + 30f)
        }
        return s.bmp
    }

    /** Stiker hitung mundur lomba, dengan posisi minggu rencana dan jarak minggu itu bila diketahui. */
    fun countdown(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs): Bitmap {
        val r = m.extras!!.race!!
        val days = java.time.temporal.ChronoUnit.DAYS.between(java.time.LocalDate.parse(m.date), r.date).toInt()
        val ws = m.wkCtx?.summary; val total = m.weekInput?.weeks?.size ?: 0
        val w = 980; val pad = 44; val hd = 78
        val s = Sk(w, if (ws != null) 660 else 430, pal, prefs.panel)
        s.head("Hitung mundur", s.ell(r.name, 38f, 700, 520f, true), w, pad)
        val y0 = (pad + hd).toFloat()
        val big = if (days == 0) "Hari H" else "H-$days"; val bw = s.tw(big, 150f, 700, true)
        s.text(big, 150f, 700, pal.ink, L(), pad.toFloat(), y0 + 130f, true)
        if (days > 0) s.text("hari", 48f, 500, pal.ink2, L(), pad + bw + 14f, y0 + 130f)
        s.text(dmy(r.date.toString()) + " · " + Js.fmtKm(r.km) + " km", 36f, 500, pal.ink2, L(), pad.toFloat(), y0 + 190f)
        if (ws != null) {
            val pos = (m.wkCtx?.pos ?: 0) + 1
            val y1 = y0 + 250f
            s.line(pad.toFloat(), y1, (w - pad).toFloat(), y1, pal.line, 2f)
            s.text("Minggu $pos" + (if (total > 0) " dari $total" else ""), 34f, 500, pal.ink2, L(), pad.toFloat(), y1 + 54f)
            val tx = Stickers.km1(ws.km) + (if (ws.planKm > 0) " / " + Js.fmtKm(ws.planKm) else "") + " km"
            s.text(tx, 38f, 700, pal.ink, R(), (w - pad).toFloat(), y1 + 56f, true)
            val full = (w - pad * 2).toFloat()
            s.rr(pad.toFloat(), y1 + 76f, full, 22f, 11f, pal.ink, .18f)
            if (ws.planKm > 0 && ws.km > 0) s.rr(pad.toFloat(), y1 + 76f, max(22f, f(full * min(1.0, ws.km / ws.planKm))), 22f, 11f, pal.hl)
            if (ws.gain > 0) s.text("Elevasi minggu ini " + Js.idn(Js.round(ws.gain).toInt()) + " m", 32f, 500, pal.ink2, L(), pad.toFloat(), y1 + 160f)
        }
        return s.bmp
    }

    /** Stiker training load: rasio beban 7 hari terhadap kebiasaan, pengukur zona, dan beban delapan pekan. */
    fun training(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs): Bitmap {
        val l = m.extras!!.load!!
        val w = 980; val pad = 44; val hd = 78
        val s = Sk(w, 660, pal, prefs.panel)
        s.head("Training load", "", w, pad)
        val y0 = (pad + hd).toFloat()
        val rt = String.format(java.util.Locale.ROOT, "%.2f", l.ratio).replace('.', ',')
        val col = when { l.ratio < .8 -> rgb(Stickers.ZONE_RGB[0]); l.ratio <= 1.3 -> GREEN; l.ratio <= 1.5 -> rgb(Stickers.ZONE_RGB[2]); else -> ORANGE }
        s.text("Beban 7 hari / kebiasaan", 30f, 500, pal.ink2, L(), pad.toFloat(), y0 + 30f)
        val vw = s.tw(rt, 120f, 700, true)
        s.text(rt, 120f, 700, pal.ink, L(), pad.toFloat(), y0 + 156f, true)
        s.text(l.status, 40f, 700, col, L(), pad + vw + 20f, y0 + 156f, true)
        val cw = (w - pad * 2).toFloat(); val gy = y0 + 210f
        val zones = listOf(.4 to rgb(Stickers.ZONE_RGB[0]), .25 to GREEN, .1 to rgb(Stickers.ZONE_RGB[2]), .25 to ORANGE)
        var x = pad.toFloat()
        zones.forEach { (fr, c) -> val bw = f(fr * cw) - 3f; s.rr(x, gy, bw, 24f, 8f, c); x += bw + 3f }
        val mx = pad + f(min(1.0, l.ratio / 2.0) * cw)
        s.rr(mx - 4f, gy - 12f, 8f, 48f, 4f, pal.ink)
        val ty = gy + 66f
        s.text("Turun < 0,8", 24f, 500, pal.ink2, L(), pad.toFloat(), ty)
        s.text("Ideal 0,8–1,3", 24f, 500, pal.ink2, C(), pad + f(.525 * cw), ty)
        s.text("Naik cepat > 1,5", 24f, 500, pal.ink2, R(), (w - pad).toFloat(), ty)
        val loads = l.weekLoads; val mxL = max(1.0, loads.maxOrNull() ?: 1.0)
        val base = ty + 160f; val gap = 12f; val bw = (cw - gap * (loads.size - 1)) / loads.size
        loads.forEachIndexed { i, v ->
            val bh = max(6f, f(v / mxL * 110.0)); val last = i == loads.lastIndex
            s.rr(pad + i * (bw + gap), base - bh, bw, bh, 6f, if (last) pal.hl else pal.ink, if (last) 1f else .45f)
        }
        s.text("Beban per minggu, ${loads.size} minggu terakhir", 26f, 500, pal.ink2, L(), pad.toFloat(), base + 44f)
        return s.bmp
    }

    /** Stiker Tahun: km, elevasi, hari aktif, dan kalender panas setahun (kolom = minggu, baris = Senin sampai Minggu). */
    fun yearSticker(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs): Bitmap {
        val y = m.extras!!.year!!
        val weeks = (y.offset + y.cells.size + 6) / 7
        val w = 1100; val pad = 44; val hd = 78; val gap = 3f
        val cell = (w - pad * 2 - gap * (weeks - 1)) / weeks
        val top = (pad + hd + 170).toFloat()
        val h = (top + 7 * (cell + gap) + 70f + pad).toInt()
        val s = Sk(w, h, pal, prefs.panel)
        s.head("Tahun ${y.year}", "sampai " + spanText(java.time.LocalDate.parse(m.date), java.time.LocalDate.parse(m.date)), w, pad)
        val y0 = (pad + hd).toFloat()
        s.text("Jarak", 30f, 500, pal.ink2, L(), pad.toFloat(), y0 + 30f)
        val kv = Js.idn(Js.round(y.km).toInt()); val vw = s.tw(kv, 110f, 700, true)
        s.text(kv, 110f, 700, pal.ink, L(), pad.toFloat(), y0 + 146f, true)
        s.text("km", 40f, 500, pal.ink2, L(), pad + vw + 12f, y0 + 146f)
        val stats = listOf(Triple("Elevasi naik", Js.idn(y.gain), "m"), Triple("Hari aktif", y.activeDays.toString(), "hari"), Triple("Sesi", y.sessions.toString(), ""))
        stats.forEachIndexed { i, (lab, v, u) ->
            val x = w - pad - (stats.size - i) * 200f
            s.text(lab, 26f, 500, pal.ink2, L(), x, y0 + 30f)
            val tw = s.tw(v, 56f, 700, true)
            s.text(v, 56f, 700, pal.ink, L(), x, y0 + 100f, true)
            if (u.isNotEmpty()) s.text(u, 24f, 500, pal.ink2, L(), x + tw + 6f, y0 + 100f)
        }
        y.cells.forEachIndexed { i, v ->
            val pos = y.offset + i
            val cx = pad + (pos / 7) * (cell + gap); val cy = top + (pos % 7) * (cell + gap)
            when {
                v < 0.0 -> s.rr(cx, cy, cell, cell, 3f, pal.ink, .06f)
                v == 0.0 -> s.rr(cx, cy, cell, cell, 3f, pal.ink, .12f)
                else -> s.rr(cx, cy, cell, cell, 3f, pal.hl, when { v < 6.5 -> .4f; v < 10.0 -> .65f; v < 15.0 -> .85f; else -> 1f })
            }
        }
        for (mo in 1..12) {
            val idx = (y.offset + java.time.LocalDate.of(y.year, mo, 1).dayOfYear - 1) / 7
            s.text(MON_SHORT[mo - 1], 22f, 500, pal.ink2, L(), pad + idx * (cell + gap), top + 7 * (cell + gap) + 34f)
        }
        return s.bmp
    }

    /** Stiker streak: hari berturut-turut, tujuh hari terakhir, minggu beruntun, dan rekor. */
    fun streakSticker(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs): Bitmap {
        val st = m.extras!!.streak!!
        val w = 900; val pad = 44; val hd = 78
        val s = Sk(w, 600, pal, prefs.panel)
        s.head("Streak", "", w, pad)
        val y0 = (pad + hd).toFloat()
        s.text("Lari berturut-turut", 30f, 500, pal.ink2, L(), pad.toFloat(), y0 + 30f)
        val dv = st.days.toString(); val vw = s.tw(dv, 170f, 700, true)
        s.text(dv, 170f, 700, pal.hl, L(), pad.toFloat(), y0 + 206f, true)
        s.text("hari", 48f, 500, pal.ink2, L(), pad + vw + 14f, y0 + 206f)
        val dw = (w - pad * 2) / 7f; val cy = y0 + 276f
        st.last7.forEachIndexed { i, (letter, done) ->
            val cx = pad + i * dw + dw / 2f
            s.circle(cx, cy, 30f, if (done) pal.hl else pal.ink, if (done) 1f else .15f)
            s.text(letter, 28f, 700, if (done) onFill(pal.hl) else pal.ink2, C(), cx, cy + 10f, true)
        }
        val sy = cy + 70f
        listOf("Minggu beruntun" to st.weeks.toString(), "Rekor streak" to "${st.bestDays} hari").forEachIndexed { i, (lab, v) ->
            val x = pad + i * 420f
            s.text(lab, 28f, 500, pal.ink2, L(), x, sy + 28f)
            s.text(v, 64f, 700, pal.ink, L(), x, sy + 94f, true)
        }
        return s.bmp
    }
}
