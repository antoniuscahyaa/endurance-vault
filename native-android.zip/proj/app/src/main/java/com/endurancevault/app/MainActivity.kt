package com.endurancevault.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.endurancevault.app.ui.AppRoot
import com.endurancevault.app.ui.SplashOverlay
import com.endurancevault.app.ui.i18n.Lang
import com.endurancevault.app.ui.theme.EnduranceVaultTheme
import com.endurancevault.app.ui.theme.ThemePrefs

class MainActivity : ComponentActivity() {
    // Terapkan bahasa pilihan sedini mungkin (sebelum UI dibuat) agar locale dan kamus terjemahan siap.
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onStop() {
        super.onStop()
        // Muat ulang widget layar utama saat aplikasi ditinggalkan: data atau tema mungkin berubah.
        com.endurancevault.app.widget.WidgetUpdater.updateAll(applicationContext)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen() // harus sebelum super.onCreate; mengembalikan tema ke Theme.EnduranceVault
        super.onCreate(savedInstanceState)
        ThemePrefs.load(applicationContext)
        enableEdgeToEdge()
        setContent {
            EnduranceVaultTheme {
                Box(Modifier.fillMaxSize()) {
                    AppRoot()
                    SplashOverlay()
                }
            }
        }
    }
}
