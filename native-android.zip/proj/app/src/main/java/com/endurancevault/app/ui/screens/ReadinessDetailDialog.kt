package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.theme.EvButton

import com.endurancevault.app.ui.i18n.Text
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.endurancevault.app.ui.floating.Dialog
import androidx.compose.ui.window.DialogProperties
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.data.DailyEntity
import com.endurancevault.app.data.ReadinessHistoryStore
import com.endurancevault.app.domain.*
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.roundToInt
import kotlin.math.abs

private val readinessBaseWeights = mapOf("rec" to 30.0, "load" to 20.0, "sl" to 20.0, "debt" to 15.0, "hrv" to 20.0, "rhr" to 10.0, "shr" to 5.0, "pain" to 15.0, "leg" to 15.0, "mood" to 10.0)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReadinessDetailDialog(
    score: ReadinessMetric,
    settings: PlanSettings,
    activities: List<ActivityEntity>,
    daily: List<DailyEntity>,
    plan: PlanOutcome,
    config: ReadinessConfig,
    onConfigChange: (ReadinessConfig) -> Unit,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("readiness_settings", android.content.Context.MODE_PRIVATE) }
    var swap by remember { mutableStateOf(config.swapThreshold.toString()) }
    var light by remember { mutableStateOf(config.lightThreshold.toString()) }
    var easy by remember { mutableStateOf(config.easyThreshold.toString()) }
    var sleepNeed by remember { mutableStateOf(config.sleepNeedHours.toString()) }
    var bikeOffset by remember { mutableStateOf(config.bikeHrOffset.toString()) }
    var bikeMode by remember { mutableStateOf(config.bikeModeFactor.toString()) }
    var normalizeBikeLoad by remember { mutableStateOf(config.normalizeBikeLoad) }
    var painArea by remember { mutableStateOf("") }
    var painSeverity by remember { mutableStateOf(3) }
    var painSide by remember { mutableStateOf("k") }
    var painMoment by remember { mutableStateOf("sl") }
    val persistedPainEntries = remember {
        if (!prefs.contains("pain_entries")) config.painEntries else runCatching {
            val arr = org.json.JSONArray(prefs.getString("pain_entries", "[]"))
            (0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i)?.let { o ->
                PainReadinessEntry(LocalDate.parse(o.getString("date")), o.optString("area", ""), o.optInt("severity", 1), o.optString("side", "b"), o.optString("when", "sl"))
            } }
        }.getOrDefault(config.painEntries)
    }
    var painEntries by remember { mutableStateOf(persistedPainEntries) }
    var weightMode by remember { mutableStateOf(prefs.getString("weight_mode", if (config.weights.isEmpty()) "default" else "manual") ?: "default") }
    var manualWeights by remember { mutableStateOf(readinessBaseWeights.mapValues { (k, v) -> config.weights[k] ?: v }) }
    var period by remember { mutableStateOf("week") }
    var autoThreshold by remember { mutableStateOf(prefs.getBoolean("threshold_auto", false)) }
    val today = LocalDate.now()
    var swappedDates by remember { mutableStateOf<Set<String>>(emptySet()) }
    fun saveBikeSwaps() {
        val arr = org.json.JSONArray()
        val days = (plan as? PlanOutcome.Ok)?.weeks?.flatMap { it.days }.orEmpty()
        days.filter { it.bikeReplacement != null }.forEach { d ->
            val b = d.bikeReplacement!!
            arr.put(org.json.JSONObject().put("date", d.date.toString()).put("kind", d.replacedRunKind)
                .put("title", d.replacedRunTitle).put("km", d.replacedRunKm).put("detail", d.replacedRunDetail)
                .put("mins", b.minutes).put("bikeKm", b.estimatedKm).put("k", b.multiplier)
                .put("hrLo", b.hrBand.first).put("hrHi", b.hrBand.last).put("capped", b.capped).put("quality", b.replacesQuality))
        }
        prefs.edit().putString("bike_swaps", arr.toString()).apply()
        swappedDates = days.filter { it.bikeReplacement != null }.map { it.date.toString() }.toSet()
        val activePain = InjuryPrevention.activeLegPain(painEntries, today)
        val returnFrom = prefs.getString("return_run_from", null)?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
        if (activePain.isNotEmpty()) prefs.edit().remove("return_run_from").apply()
        else if (returnFrom != null) InjuryPrevention.returnRunPhase(returnFrom, today)?.let { phase ->
            days.filter { !it.date.isBefore(today) }.forEach { InjuryPrevention.applyReturnRun(it, phase) }
        }
    }
    LaunchedEffect(plan) {
        val saved = runCatching { org.json.JSONArray(prefs.getString("bike_swaps", "[]")) }.getOrNull() ?: org.json.JSONArray()
        val days = (plan as? PlanOutcome.Ok)?.weeks?.flatMap { it.days }.orEmpty()
        for (i in 0 until saved.length()) {
            val o = saved.optJSONObject(i) ?: continue
            val d = days.firstOrNull { it.date.toString() == o.optString("date") } ?: continue
            if (d.bikeReplacement != null) continue
            val origKind = o.optString("kind", "easy"); val origTitle = o.optString("title", d.title)
            val origKm = o.optDouble("km", d.km); val origDetail = o.optString("detail", d.detail)
            val lo = o.optInt("hrLo", settings.hr - 8); val hi = o.optInt("hrHi", settings.hr)
            d.replacedRunKind = origKind; d.replacedRunTitle = origTitle; d.replacedRunKm = origKm; d.replacedRunDetail = origDetail
            d.bikeReplacement = BikePlan(o.optInt("mins", 20), o.optDouble("bikeKm", 0.0), o.optDouble("k", 1.0), lo..hi, o.optBoolean("capped"), o.optBoolean("quality"))
            d.kind = "bike"; d.title = "Sepeda zona 2 (pengganti $origTitle)"; d.km = 0.0
            d.detail = "Sepeda ${d.bikeReplacement!!.minutes} menit · sekitar ${d.bikeReplacement!!.estimatedKm} km · HR ${lo}–${hi} bpm. Rute datar, gigi ringan, kadens 85–95, tetap duduk. Berhenti bila nyeri naik."
        }
        swappedDates = days.filter { it.bikeReplacement != null }.map { it.date.toString() }.toSet()
        val activePain = InjuryPrevention.activeLegPain(painEntries, today)
        val returnFrom = prefs.getString("return_run_from", null)?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
        if (activePain.isNotEmpty()) prefs.edit().remove("return_run_from").apply()
        else if (returnFrom != null) InjuryPrevention.returnRunPhase(returnFrom, today)?.let { phase ->
            days.filter { !it.date.isBefore(today) }.forEach { InjuryPrevention.applyReturnRun(it, phase) }
        }
    }
    val history = remember(context, activities, daily) {
        ReadinessHistoryStore.load(context).map { Triple(it.date, it.score, it.factors) }
    }
    LaunchedEffect(Unit) {
        if (painEntries != config.painEntries) onConfigChange(config.copy(painEntries = painEntries))
    }
    LaunchedEffect(painEntries) {
        if (InjuryPrevention.activeLegPain(painEntries, today).isNotEmpty()) prefs.edit().remove("return_run_from").apply()
    }
    val trend = history.filter { !it.first.isBefore(today.minusDays(6)) }
    val avg = trend.takeIf { it.isNotEmpty() }?.map { it.second }?.average()?.roundToInt()
    val previous = trend.firstOrNull { it.first == today.minusDays(1) }?.second
    val delta = previous?.let { score.score - it }
    val morningDates = remember(context, daily) { ReadinessHistoryStore.load(context).filter { it.morning }.map { it.date }.toSet() }
    val pairs = activities.filter { it.type != "bike" && it.feel != null && it.km > 0 }
        .mapNotNull { a ->
            val date = runCatching { LocalDate.parse(a.dateIso.take(10)) }.getOrNull() ?: return@mapNotNull null
            val snapshot = history.lastOrNull { it.first == date } ?: return@mapNotNull null
            if (date !in morningDates) return@mapNotNull null
            Triple(date, snapshot.second, a.feel!!)
        }.distinctBy { it.first }.takeLast(28)
    val suggestion = remember(pairs) {
        if (pairs.size < 12 || ChronoUnit.DAYS.between(pairs.first().first, pairs.last().first) < 28) null
        else {
            fun pick(rate: Double): Int? = (20..80 step 5).filter { t ->
                val below = pairs.filter { it.second < t }
                below.size >= 3 && below.count { it.third >= 4 }.toDouble() / below.size >= rate
            }.maxOrNull()
            val sw = pick(.5); val li = pick(.3); val ea = pick(.7)
            if (sw == null && li == null && ea == null) null else Triple(sw, li, ea)
        }
    }
    LaunchedEffect(autoThreshold, suggestion) {
        if (autoThreshold && suggestion != null) {
            val sw = (suggestion.first ?: swap.toIntOrNull() ?: 50).coerceIn(20, 80)
            val li = (suggestion.second ?: light.toIntOrNull() ?: 65).coerceIn(sw + 1, 90)
            val ea = (suggestion.third ?: easy.toIntOrNull() ?: 35).coerceIn(5, sw)
            swap = sw.toString(); light = li.toString(); easy = ea.toString()
            prefs.edit().putInt("swap", sw).putInt("light", li).putInt("easy", ea).apply()
            onConfigChange(config.copy(swapThreshold = sw, lightThreshold = li, easyThreshold = ea))
        }
    }
    val effectiveWeights = when (weightMode) {
        "manual" -> manualWeights
        "auto" -> {
            val bad = pairs.filter { it.third >= 4 }.map { it.first }.toSet()
            val good = pairs.filter { it.third <= 3 }.map { it.first }.toSet()
            if (pairs.size >= 12 && bad.size >= 3 && good.size >= 3) {
                val factors = history.associate { it.first to it.third }
                readinessBaseWeights.mapValues { (key, base) ->
                    val all = pairs.mapNotNull { p -> factors[p.first]?.get(key) }
                    val b = pairs.filter { it.first in bad }.mapNotNull { factors[it.first]?.get(key) }
                    val g = pairs.filter { it.first in good }.mapNotNull { factors[it.first]?.get(key) }
                    if (all.size >= 6 && b.size >= 2 && g.size >= 2) {
                        val mean = all.average(); val sd = kotlin.math.sqrt(all.map { (it - mean) * (it - mean) }.average())
                        if (sd >= 1) base * (1 + ((g.average() - b.average()) / sd)).coerceIn(-.5, 1.0) else base
                    } else base
                }
            } else readinessBaseWeights
        }
        else -> readinessBaseWeights
    }
    val orderedParts = score.parts.sortedBy { listOf("rec", "load", "sl", "debt", "hrv", "rhr", "shr", "leg", "mood", "pain").indexOf(it.key).let { n -> if (n < 0) 99 else n } }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxWidth(.96f).fillMaxHeight(.92f), shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("TRAINING READINESS", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
                        Text("${score.parts.count { it.score != null }} / 10 faktor", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    TextButton(onClick = onDismiss) { Text("Tutup") }
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text("${score.score}", style = MaterialTheme.typography.displayMedium, color = readinessColor(score.score), fontWeight = FontWeight.Bold)
                        Text("/ 100 · ${score.tier.uppercase()}", style = MaterialTheme.typography.labelMedium)
                    }
                    Column(Modifier.weight(2f)) {
                        Text(score.advice, style = MaterialTheme.typography.bodyMedium)
                        Text("7-day trend · average ${avg ?: "—"}${delta?.let { " · today ${if (it >= 0) "+" else ""}$it" } ?: ""}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                if (trend.size >= 2) {
                    val chartColor = MaterialTheme.colorScheme.primary
                    Canvas(Modifier.fillMaxWidth().height(42.dp)) {
                        val minV = (trend.minOf { it.second } - 8).coerceAtLeast(0).toFloat(); val maxV = (trend.maxOf { it.second } + 8).coerceAtMost(100).toFloat()
                        val pts = trend.mapIndexed { i, p -> Offset(if (trend.size == 1) size.width / 2 else size.width * i / (trend.size - 1), size.height - ((p.second - minV) / (maxV - minV).coerceAtLeast(1f)) * size.height) }
                        for (i in 0 until pts.lastIndex) drawLine(chartColor, pts[i], pts[i + 1], 2.dp.toPx(), cap = StrokeCap.Round)
                        pts.forEach { drawCircle(chartColor, 3.dp.toPx(), it) }
                    }
                }
                HorizontalDivider()
                Text("FAKTOR KESIAPAN", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                orderedParts.forEach { part ->
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(part.label.uppercase(), Modifier.weight(1f), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(part.score?.toString() ?: "—", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(8.dp))
                            Text(part.detail, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        LinearProgressIndicator(progress = { (part.score ?: 0) / 100f }, Modifier.fillMaxWidth().height(7.dp), color = part.score?.let { readinessColor(it) } ?: MaterialTheme.colorScheme.outlineVariant, trackColor = MaterialTheme.colorScheme.surfaceVariant)
                    }
                }
                HorizontalDivider()
                Text("Advice thresholds (score)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                ThresholdField("Swap to short easy below", swap) { swap = it }
                ThresholdField("Ease by 20% below", light) { light = it }
                ThresholdField("Easy sessions eased below", easy) { easy = it }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { swap = "50"; light = "65"; easy = "35" }) { Text("Reset thresholds") }
                    EvButton(onClick = {
                        val sw = swap.toIntOrNull()?.coerceIn(20, 80) ?: 50
                        val li = (light.toIntOrNull() ?: 65).coerceIn(sw + 1, 90)
                        val ea = (easy.toIntOrNull() ?: 35).coerceIn(5, sw)
                        swap = sw.toString(); light = li.toString(); easy = ea.toString()
                        prefs.edit().putInt("swap", sw).putInt("light", li).putInt("easy", ea).apply()
                        onConfigChange(config.copy(swapThreshold = sw, lightThreshold = li, easyThreshold = ea))
                    }) { Text("Save thresholds") }
                }
                Text("Default 50, 65, and 35. Swap must remain below the ease threshold.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                HorizontalDivider()
                Text("Sleep need", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(sleepNeed, { sleepNeed = it.filter { c -> c.isDigit() || c == '.' }.take(4) }, Modifier.width(110.dp), label = { Text("Hours/night") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                    EvButton(onClick = {
                        val value = (sleepNeed.toDoubleOrNull() ?: 7.5).coerceIn(5.0, 10.0)
                        sleepNeed = value.toString()
                        prefs.edit().putFloat("sleep_need_hours", value.toFloat()).apply()
                        onConfigChange(config.copy(sleepNeedHours = value))
                    }) { Text("Save") }
                }
                Text("Dipakai untuk menghitung utang tidur 7 hari. Rentang 5–10 jam; default 7,5 jam.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                HorizontalDivider()
                val activeLegPainForSwap = InjuryPrevention.activeLegPain(painEntries, today)
                if (activeLegPainForSwap.isNotEmpty()) {
                    HorizontalDivider()
                    Text("Cegah cedera · pengganti sepeda", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Text("Nyeri kaki tingkat 3 ke atas terdeteksi. Sesi lari 7 hari ke depan dapat diganti satu sesi sepeda zona 2. Sesi kualitas tidak diubah menjadi interval sepeda; durasinya diperpanjang untuk mendekati beban TRIMP yang setara.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    val upcoming = (plan as? PlanOutcome.Ok)?.weeks?.flatMap { it.days }?.filter { !it.date.isBefore(today) && !it.date.isAfter(today.plusDays(6)) && (it.bikeReplacement != null || (it.km > 0 && it.kind in setOf("easy", "short", "medium", "long", "quality"))) }.orEmpty()
                    if (upcoming.isEmpty()) Text("Tidak ada sesi lari yang dapat diganti dalam 7 hari ke depan.", style = MaterialTheme.typography.bodySmall)
                    upcoming.forEach { day ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Column(Modifier.weight(1f)) {
                                Text("${day.date} · ${day.title}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                if (day.bikeReplacement != null) {
                                    val b = day.bikeReplacement!!
                                    Text("Sepeda ${b.minutes} mnt · ±${b.estimatedKm} km · Z2 HR ${b.hrBand.first}–${b.hrBand.last}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                } else Text("${"%.1f".format(day.km)} km · ${day.kind}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (day.bikeReplacement == null) {
                                TextButton(onClick = {
                                    val paceMin = Js.parsePaceStr(settings.pace).takeIf { it > 0 } ?: 6.5
                                    val runMins = (day.km * paceMin).roundToInt().coerceAtLeast(1)
                                    val zones = Zones.cuts(settings)
                                    val z2 = zones.lo[1]..(zones.lo[2] - 1)
                                    val hardBand = if (day.qk == "hike") zones.lo[2]..(zones.lo[3] - 1) else day.qBand?.let { it.first()..it.last() } ?: z2
                                    val b = InjuryPrevention.bikeReplacement(runMins, day.kind, hardBand, z2,
                                        zones.rest ?: (settings.rhr ?: 55.0).roundToInt(), zones.maxHr,
                                        bikeOffset = (bikeOffset.toIntOrNull() ?: 8).coerceIn(0, 20),
                                        modeFactor = (bikeMode.toDoubleOrNull() ?: 1.25).coerceIn(1.0, 1.6),
                                        bikeSpeedKmh = settings.bspd, qualityMinutes = (day.qMin ?: 0.0).roundToInt())
                                    if (b != null) {
                                        day.replacedRunKind = day.kind; day.replacedRunTitle = day.title; day.replacedRunKm = day.km; day.replacedRunDetail = day.detail
                                        day.bikeReplacement = b; day.kind = "bike"; day.title = "Sepeda zona 2 (pengganti ${day.replacedRunTitle})"; day.km = 0.0
                                        day.detail = "Pengganti ${day.replacedRunTitle}. Sepeda ${b.minutes} menit (sekitar ${b.estimatedKm} km), zona 2, HR ${b.hrBand.first}–${b.hrBand.last} bpm. ${if (b.replacesQuality) "Bagian kualitas diganti durasi zona 2 lebih panjang. " else ""}Rute datar, gigi ringan, kadens 85–95, tetap duduk. Berhenti bila nyeri naik."
                                        saveBikeSwaps()
                                    }
                                }) { Text("Ganti sepeda") }
                            } else {
                                TextButton(onClick = {
                                    day.kind = day.replacedRunKind ?: "easy"; day.title = day.replacedRunTitle ?: "Easy"
                                    day.km = day.replacedRunKm ?: 0.0; day.detail = day.replacedRunDetail ?: ""
                                    day.bikeReplacement = null; day.replacedRunKind = null; day.replacedRunTitle = null; day.replacedRunKm = null; day.replacedRunDetail = null
                                    saveBikeSwaps()
                                }) { Text("Kembalikan lari") }
                            }
                        }
                    }
                    val unswapped = upcoming.filter { it.bikeReplacement == null }
                    if (unswapped.size > 1) {
                        TextButton(onClick = {
                            unswapped.forEach { day ->
                                val paceMin = Js.parsePaceStr(settings.pace).takeIf { it > 0 } ?: 6.5
                                val runMins = (day.km * paceMin).roundToInt().coerceAtLeast(1)
                                val zones = Zones.cuts(settings)
                                val z2 = zones.lo[1]..(zones.lo[2] - 1)
                                val hardBand = if (day.qk == "hike") zones.lo[2]..(zones.lo[3] - 1) else day.qBand?.let { it.first()..it.last() } ?: z2
                                val b = InjuryPrevention.bikeReplacement(runMins, day.kind, hardBand, z2,
                                    zones.rest ?: (settings.rhr ?: 55.0).roundToInt(), zones.maxHr,
                                    bikeOffset = (bikeOffset.toIntOrNull() ?: 8).coerceIn(0, 20),
                                    modeFactor = (bikeMode.toDoubleOrNull() ?: 1.25).coerceIn(1.0, 1.6),
                                    bikeSpeedKmh = settings.bspd, qualityMinutes = (day.qMin ?: 0.0).roundToInt())
                                if (b != null) {
                                    day.replacedRunKind = day.kind; day.replacedRunTitle = day.title; day.replacedRunKm = day.km; day.replacedRunDetail = day.detail
                                    day.bikeReplacement = b; day.kind = "bike"; day.title = "Sepeda zona 2 (pengganti ${day.replacedRunTitle})"; day.km = 0.0
                                    day.detail = "Pengganti ${day.replacedRunTitle}. Sepeda ${b.minutes} menit (sekitar ${b.estimatedKm} km), zona 2, HR ${b.hrBand.first}–${b.hrBand.last} bpm. Rute datar, gigi ringan, kadens 85–95, tetap duduk. Berhenti bila nyeri naik."
                                }
                            }
                            saveBikeSwaps()
                        }) { Text("Ganti semua sesi yang tersedia (${unswapped.size})") }
                    }
                    val bikeSamples = upcoming.mapNotNull { day ->
                        val replacement = day.bikeReplacement ?: return@mapNotNull null
                        val activity = activities.mapNotNull { a ->
                            if (a.type != "bike" || a.feel == null || a.durationSec <= 0 || a.durationSec / 60.0 < replacement.minutes * .5) return@mapNotNull null
                            val date = runCatching { LocalDate.parse(a.dateIso.take(10)) }.getOrNull() ?: return@mapNotNull null
                            val gap = abs(ChronoUnit.DAYS.between(day.date, date))
                            if (gap > 2) null else a to gap
                        }.minByOrNull { it.second }?.first ?: return@mapNotNull null
                        val eval = InjuryPrevention.evaluateBikeSession(replacement,
                            if (activity.durationSec > 0) activity.durationSec / 60 else 0, activity.avgHr,
                            Zones.cuts(settings).rest ?: (settings.rhr ?: 55.0).roundToInt(), Zones.cuts(settings).maxHr)
                            ?: return@mapNotNull null
                        eval to activity.feel!!
                    }.sortedByDescending { it.first.actualMinutes }
                    bikeSamples.forEach { (evaluation, feel) ->
                        Text("Evaluasi sepeda ${evaluation.actualMinutes}/${evaluation.targetMinutes} menit · rasa ${feel}/5 · ${evaluation.averageHr?.let { "$it bpm" } ?: "HR tidak tersedia"} · ${evaluation.verdict}", style = MaterialTheme.typography.bodySmall)
                    }
                    val calibration = InjuryPrevention.calibrateBikeOffset(bikeSamples, config.bikeHrOffset)
                    if (calibration.count > 0) {
                        Text("Kalibrasi dari rasa usaha: ${calibration.count} sesi · ${calibration.heavy} terlalu berat · ${calibration.light} terlalu ringan · ${calibration.fit} sesuai.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        calibration.suggestedOffset?.let { suggested ->
                            Text("Selisih HR sepeda disarankan ${config.bikeHrOffset} → $suggested bpm.", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                            TextButton(onClick = {
                                bikeOffset = suggested.toString()
                                prefs.edit().putInt("bike_hr_offset", suggested).apply()
                                onConfigChange(config.copy(bikeHrOffset = suggested))
                            }) { Text("Pakai saran kalibrasi") }
                        }
                    }
                    Text("Pengaturan konversi", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(bikeOffset, { bikeOffset = it.filter(Char::isDigit).take(2) }, Modifier.weight(1f), label = { Text("Selisih HR (0–20 bpm)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                        OutlinedTextField(bikeMode, { bikeMode = it.filter { c -> c.isDigit() || c == '.' }.take(4) }, Modifier.weight(1f), label = { Text("Faktor (1,0–1,6)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Samakan Training Load sepeda dengan lari", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                        Switch(checked = normalizeBikeLoad, onCheckedChange = { normalizeBikeLoad = it })
                    }
                    EvButton(onClick = {
                        val off = (bikeOffset.toIntOrNull() ?: 8).coerceIn(0, 20)
                        val factor = (bikeMode.toDoubleOrNull() ?: 1.25).coerceIn(1.0, 1.6)
                        bikeOffset = off.toString(); bikeMode = factor.toString()
                        prefs.edit().putInt("bike_hr_offset", off).putFloat("bike_mode_factor", factor.toFloat()).putBoolean("normalize_bike_load", normalizeBikeLoad).apply()
                        onConfigChange(config.copy(bikeHrOffset = off, bikeModeFactor = factor, normalizeBikeLoad = normalizeBikeLoad))
                    }, modifier = Modifier.fillMaxWidth()) { Text("Simpan pengaturan sepeda") }
                    Text("Konversi memakai estimasi durasi dari pace rencana, bobot TRIMP, zona HR, dan batas 20–300 menit. Jarak sepeda hanya perkiraan. Bersepeda hanya jika tidak memicu nyeri.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    HorizontalDivider()
                }
                Text("Catatan nyeri dan cedera", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text("Pilih area tubuh sesuai kategori seperti di aplikasi lama.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                InjuryPrevention.groups.forEach { group ->
                    Text(group.title, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        group.areas.forEach { (id, label) -> FilterChip(selected = painArea == id, onClick = { painArea = if (painArea == id) "" else id }, label = { Text(label) }) }
                    }
                }
                Text("Sisi", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    InjuryPrevention.sides.forEach { (id, label) -> FilterChip(selected = painSide == id, onClick = { painSide = id }, label = { Text(label) }) }
                }
                Text("Tingkat nyeri (1 ringan · 5 berat)", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    (1..5).forEach { v -> FilterChip(selected = painSeverity == v, onClick = { painSeverity = v }, label = { Text("$v") }) }
                }
                Text("Muncul saat", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    InjuryPrevention.moments.forEach { (id, label) -> FilterChip(selected = painMoment == id, onClick = { painMoment = id }, label = { Text(label) }) }
                }
                EvButton(onClick = {
                    if (painArea.isNotBlank()) {
                        val entry = PainReadinessEntry(today, painArea, painSeverity, painSide, painMoment)
                        painEntries = (painEntries.filterNot { it.date == today && it.area == entry.area && it.side == entry.side } + entry).takeLast(300)
                        val arr = org.json.JSONArray()
                        painEntries.forEach { e -> arr.put(org.json.JSONObject().put("date", e.date.toString()).put("area", e.area).put("severity", e.severity).put("side", e.side).put("when", e.whenTag)) }
                        prefs.edit().putString("pain_entries", arr.toString()).apply()
                        onConfigChange(config.copy(painEntries = painEntries)); painArea = ""
                    }
                }, enabled = painArea.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Simpan catatan") }
                val painAlerts = InjuryPrevention.alerts(painEntries, today)
                if (painAlerts.isNotEmpty()) {
                    Text("Peringatan nyeri berulang", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                    painAlerts.forEach { alert -> Text("${InjuryPrevention.areaName(alert.area)} · ${alert.days}/4 hari · puncak ${alert.maxSeverity}/5", style = MaterialTheme.typography.bodySmall) }
                }
                val prehab = InjuryPrevention.prehab(painEntries, today)
                if (prehab != null) {
                    Text("Saran prehab: ${InjuryPrevention.areaName(prehab.area)}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    prehab.exercises.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                    Text(prehab.caution, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                val activeLegPain = InjuryPrevention.activeLegPain(painEntries, today)
                if (activeLegPain.isNotEmpty()) {
                    Surface(color = MaterialTheme.colorScheme.errorContainer, shape = RoundedCornerShape(12.dp)) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Cegah cedera: beban benturan lari perlu dikurangi", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer)
                            activeLegPain.forEach { Text("${InjuryPrevention.areaName(it.area)} · ${InjuryPrevention.sideName(it.side)} · ${it.severity}/5", color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodySmall) }
                            Text("Sesi lari dapat dipertimbangkan untuk diganti sepeda zona 2 bila bersepeda tidak memicu nyeri. Nyeri berat atau memburuk perlu dinilai tenaga kesehatan.", color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                Text("Riwayat catatan", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                painEntries.sortedByDescending { it.date }.take(6).forEach { entry ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${entry.date} · ${InjuryPrevention.areaName(entry.area)} · ${InjuryPrevention.sideName(entry.side)} · ${entry.severity}/5 · ${InjuryPrevention.momentName(entry.whenTag)}", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                        TextButton(onClick = {
                            painEntries = painEntries - entry
                            val arr = org.json.JSONArray()
                            painEntries.forEach { e -> arr.put(org.json.JSONObject().put("date", e.date.toString()).put("area", e.area).put("severity", e.severity).put("side", e.side).put("when", e.whenTag)) }
                            prefs.edit().putString("pain_entries", arr.toString()).apply()
                            onConfigChange(config.copy(painEntries = painEntries))
                        }) { Text("Hapus") }
                    }
                }
                val returnStart = prefs.getString("return_run_from", null)?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
                val returnGuide = if (InjuryPrevention.recovered(painEntries, today) && swappedDates.any { it >= today.minusDays(14).toString() } && returnStart != null)
                    InjuryPrevention.returnRunPhase(returnStart, today) else null
                if (returnGuide != null) {
                    Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(12.dp)) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Kembali ke lari bertahap · hari ke-${returnGuide.dayNumber}", fontWeight = FontWeight.Bold)
                            Text("Fase ${returnGuide.phase}: ${returnGuide.percent}% dari jarak rencana. ${when(returnGuide.phase) { 1 -> "Semua sesi easy; tanpa interval, tanjakan, atau long run panjang."; 2 -> "Long run kembali; sesi kualitas masih easy."; else -> "Sesi kualitas kembali secara bertahap." }}", style = MaterialTheme.typography.bodySmall)
                            Text("Hentikan bila nyeri naik. Panduan ini bukan pengganti pemeriksaan medis.", style = MaterialTheme.typography.bodySmall)
                            TextButton(onClick = { prefs.edit().remove("return_run_from").apply() }) { Text("Hentikan panduan") }
                        }
                    }
                } else if (InjuryPrevention.recovered(painEntries, today) && swappedDates.any { it >= today.minusDays(14).toString() }) {
                    Text("Nyeri kaki tercatat membaik selama dua hari. Kamu dapat memulai panduan kembali berlari bertahap 65% → 80% → 90%.", style = MaterialTheme.typography.bodySmall)
                    EvButton(onClick = {
                        prefs.edit().putString("return_run_from", today.toString()).apply()
                        InjuryPrevention.returnRunPhase(today, today)?.let { phase ->
                            (plan as? PlanOutcome.Ok)?.weeks?.flatMap { it.days }?.filter { !it.date.isBefore(today) }?.forEach { InjuryPrevention.applyReturnRun(it, phase) }
                        }
                    }) { Text("Mulai bertahap") }
                }
                HorizontalDivider()
                Text("Calibrate weights from your history", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text("${pairs.size} paired days with a readiness score and post-run feel. Automatic calibration needs at least 12 days, including 3 hard-feeling and 3 easier days.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("default" to "Default", "auto" to "Auto", "manual" to "Manual").forEach { (key, label) ->
                        FilterChip(selected = weightMode == key, onClick = {
                            weightMode = key; prefs.edit().putString("weight_mode", key).apply()
                            when (key) {
                                "default" -> onConfigChange(config.copy(weights = emptyMap()))
                                "manual" -> onConfigChange(config.copy(weights = manualWeights))
                                "auto" -> onConfigChange(config.copy(weights = effectiveWeights))
                            }
                        }, label = { Text(label) }, enabled = key != "auto" || (pairs.size >= 12 && pairs.count { it.third >= 4 } >= 3 && pairs.count { it.third <= 3 } >= 3))
                    }
                }
                if (weightMode == "auto") {
                    Text("Auto weights are bounded to 0.5×–2× the baseline and are applied to the score calculation.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else if (weightMode == "manual") {
                    readinessBaseWeights.forEach { (key, base) ->
                        val value = manualWeights[key] ?: base
                        Column {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(key.uppercase(), style = MaterialTheme.typography.labelSmall); Text("${value.roundToInt()}") }
                            Slider(value = value.toFloat(), onValueChange = { v -> manualWeights = manualWeights + (key to v.toDouble()) }, valueRange = 1f..50f, onValueChangeFinished = {
                                val updated = manualWeights + (key to (manualWeights[key] ?: base))
                                prefs.edit().putFloat("weight_$key", (updated[key] ?: base).toFloat()).apply()
                                onConfigChange(config.copy(weights = updated))
                            })
                        }
                    }
                }
                HorizontalDivider()
                Text("Calibrate thresholds from post-run feel", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text(if (suggestion == null) "Belum cukup pola: perlu minimal 12 hari dengan skor dan rasa setelah lari dalam rentang sekitar 4 minggu." else "Saran: swap < ${suggestion.first ?: swap}, ease < ${suggestion.second ?: light}, easy < ${suggestion.third ?: easy}. Berdasarkan sesi yang terasa berat (4–5/5).", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Automatic threshold calibration", style = MaterialTheme.typography.bodySmall)
                    Switch(checked = autoThreshold, onCheckedChange = { enabled ->
                        autoThreshold = enabled
                        prefs.edit().putBoolean("threshold_auto", enabled).apply()
                        if (enabled && suggestion != null) {
                            val sw = (suggestion.first ?: swap.toIntOrNull() ?: 50).coerceIn(20, 80)
                            val li = (suggestion.second ?: light.toIntOrNull() ?: 65).coerceIn(sw + 1, 90)
                            val ea = (suggestion.third ?: easy.toIntOrNull() ?: 35).coerceIn(5, sw)
                            swap = sw.toString(); light = li.toString(); easy = ea.toString()
                            prefs.edit().putInt("swap", sw).putInt("light", li).putInt("easy", ea).apply()
                            onConfigChange(config.copy(swapThreshold = sw, lightThreshold = li, easyThreshold = ea))
                        }
                    }, enabled = suggestion != null || !autoThreshold)
                }
                if (suggestion != null) EvButton(onClick = {
                    val sw = (suggestion.first ?: swap.toIntOrNull() ?: 50).coerceIn(20, 80)
                    val li = (suggestion.second ?: light.toIntOrNull() ?: 65).coerceIn(sw + 1, 90)
                    val ea = (suggestion.third ?: easy.toIntOrNull() ?: 35).coerceIn(5, sw)
                    prefs.edit().putInt("swap", sw).putInt("light", li).putInt("easy", ea).apply()
                    swap = sw.toString(); light = li.toString(); easy = ea.toString()
                    onConfigChange(config.copy(swapThreshold = sw, lightThreshold = li, easyThreshold = ea))
                }) { Text("Apply suggestion") }
                HorizontalDivider()
                Text("Readiness vs training", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = period == "week", onClick = { period = "week" }, label = { Text("Weekly") })
                    FilterChip(selected = period == "month", onClick = { period = "month" }, label = { Text("Monthly") })
                }
                val buckets = if (period == "week") history.groupBy { it.first.with(java.time.DayOfWeek.MONDAY) }.toSortedMap(compareByDescending { it }).entries.take(8) else history.groupBy { it.first.withDayOfMonth(1) }.toSortedMap(compareByDescending { it }).entries.take(6)
                buckets.forEach { (start, rows) ->
                    val average = rows.map { it.second }.average().roundToInt()
                    val loggedKm = activities.filter { a -> a.type != "bike" && a.km > 0 && runCatching { val d = LocalDate.parse(a.dateIso.take(10)); !d.isBefore(start) && d < if (period == "week") start.plusWeeks(1) else start.plusMonths(1) }.getOrDefault(false) }.sumOf { it.km }
                    val feel = activities.filter { a -> a.feel != null && runCatching { val d = LocalDate.parse(a.dateIso.take(10)); !d.isBefore(start) && d < if (period == "week") start.plusWeeks(1) else start.plusMonths(1) }.getOrDefault(false) }.mapNotNull { it.feel }
                    Surface(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .55f), shape = RoundedCornerShape(14.dp)) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("$average  ${if (period == "week") "Week of" else "Month"} ${start}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                            Text("${rows.size} days logged · ${rows.count { it.second < (swap.toIntOrNull() ?: 50) }} below threshold · feel ${feel.takeIf { it.isNotEmpty() }?.average()?.let { "%.1f".format(it) } ?: "—"} · ${"%.1f".format(loggedKm)} km", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                Text("Readiness is an estimate from available recovery, training load, sleep and daily-condition data. It is not medical advice.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable private fun ThresholdField(label: String, value: String, onChange: (String) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(value, onChange, Modifier.width(88.dp), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
    }
}

@Composable private fun readinessColor(score: Int) = when {
    score >= 60 -> MaterialTheme.colorScheme.tertiary
    score >= 40 -> MaterialTheme.colorScheme.secondary
    else -> MaterialTheme.colorScheme.error
}
