package com.endurancevault.app

import android.app.Application
import com.endurancevault.app.data.ActStore
import com.endurancevault.app.data.AppDb
import com.endurancevault.app.data.SettingsStore

class EnduranceVaultApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Pindahkan data jam dari nama lama (joyofit.db / joyofit_settings) ke nama baru sebelum ada yang membukanya.
        com.endurancevault.app.watch.LegacyWatchMigration.run(this)
        // Remove the short-lived fueling planner preference introduced in 0.4.8; the feature was removed.
        getSharedPreferences("fueling_log", MODE_PRIVATE).edit().clear().apply()
    }

    val db: AppDb by lazy { AppDb.create(this) }
    val settings: SettingsStore by lazy { SettingsStore(this) }
    val acts: ActStore by lazy { ActStore(java.io.File(filesDir, "acts")) }
}
