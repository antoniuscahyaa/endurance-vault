package com.endurancevault.app.ui.theme

import android.app.Activity
import android.content.Context
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat

// Tema flat: latar putih, semua kartu abu muda, aksen orange. Hanya kartu greeting memakai orange transparan (cardTint).
// Tanpa gradien dan tanpa shadow; pemisah visual hanya lewat garis tipis (outlineVariant).

// Aksen. Ember dan Fire sengaja satu warna (flat) agar kode lama yang memakainya tidak perlu diubah.
val Ember = Color(0xFFEA5F0A)
val Fire = Color(0xFFEA5F0A)
val EmberDark = Color(0xFFFF8A26)

// Palet netral
private val LightBg = Color(0xFFFFFFFF)
private val LightCard = Color(0xFFF4F4F5)
private val LightInk = Color(0xFF1C1C1E)
private val LightMute = Color(0xFF6E6E73)
private val LightLine = Color(0xFFE8E8EA)
private val LightLineStrong = Color(0xFFD4D4D8)
private val LightOrangeText = Color(0xFFC2410C)

private val DarkBg = Color(0xFF111112)
private val DarkCard = Color(0xFF1C1C1E)
private val DarkInk = Color(0xFFF5F5F7)
private val DarkMute = Color(0xFF9A9AA0)
private val DarkLine = Color(0xFF2C2C2F)
private val DarkLineStrong = Color(0xFF3A3A3E)

private val Dark = darkColorScheme(
    primary = EmberDark, onPrimary = Color(0xFF1A1005),
    primaryContainer = Color(0xFF321F11), onPrimaryContainer = Color(0xFFFFA45C),
    secondary = DarkMute, onSecondary = DarkBg,
    secondaryContainer = Color(0xFF321F11), onSecondaryContainer = Color(0xFFFFA45C),
    tertiary = Color(0xFF4CC38A), onTertiary = Color(0xFF062016),
    background = DarkBg, onBackground = DarkInk,
    surface = DarkBg, onSurface = DarkInk,
    surfaceVariant = DarkCard, onSurfaceVariant = DarkMute,
    surfaceTint = Color.Transparent,
    surfaceContainerLowest = DarkBg, surfaceContainerLow = DarkBg,
    surfaceContainer = DarkCard, surfaceContainerHigh = DarkCard, surfaceContainerHighest = DarkCard,
    outline = DarkLineStrong, outlineVariant = DarkLine,
    error = Color(0xFFF07070),
)

private val Light = lightColorScheme(
    primary = Ember, onPrimary = Color.White,
    primaryContainer = Color(0xFFFEF2E7), onPrimaryContainer = LightOrangeText,
    secondary = LightMute, onSecondary = Color.White,
    secondaryContainer = Color(0xFFFEF2E7), onSecondaryContainer = LightOrangeText,
    tertiary = Color(0xFF2E9E5B), onTertiary = Color.White,
    background = LightBg, onBackground = LightInk,
    surface = LightBg, onSurface = LightInk,
    surfaceVariant = LightCard, onSurfaceVariant = LightMute,
    surfaceTint = Color.Transparent,
    surfaceContainerLowest = LightBg, surfaceContainerLow = LightBg,
    surfaceContainer = LightCard, surfaceContainerHigh = LightBg, surfaceContainerHighest = LightCard,
    outline = LightLineStrong, outlineVariant = LightLine,
    error = Color(0xFFD64545),
)

// ---- Tema aksen opsional (Pelangi Pastel dan Warna sendiri) ----
// Hanya warna aksen yang berbeda; netral, bentuk, dan tipografi sama dengan tema default.
// Tema default (AccentTheme.DEFAULT) tidak memakai palet ini sama sekali.

/** Satu pasang warna kartu pastel: latar kartu dan warna isi (judul/ikon/ring). */
data class ToneColors(val container: Color, val content: Color)

/** Palet lengkap satu tema aksen untuk satu mode (terang atau gelap). */
class AccentPalette(
    val primary: Color, val onPrimary: Color,
    val container: Color, val onContainer: Color,
    val tones: List<ToneColors>,
    val gradient: List<Color>,
    val zones: List<Color>,
)

private val ZonesLight = listOf(Color(0xFF5B8DEF), Color(0xFF2EB872), Color(0xFFF5B731), Color(0xFFF2784B), Color(0xFFE0457B))
private val ZonesDark = listOf(Color(0xFF7FA6FF), Color(0xFF4FD08F), Color(0xFFFFCB55), Color(0xFFFF915F), Color(0xFFFF6B9A))

private val PelangiPaletteLight = AccentPalette(
    primary = Color(0xFF6D5AE6), onPrimary = Color.White,
    container = Color(0xFFEEEBFF), onContainer = Color(0xFF5B48D6),
    tones = listOf(
        ToneColors(Color(0xFFEEEBFF), Color(0xFF5B48D6)), // ungu
        ToneColors(Color(0xFFFFEEE3), Color(0xFFD9601A)), // peach
        ToneColors(Color(0xFFE2F7EC), Color(0xFF1E8E55)), // mint
        ToneColors(Color(0xFFE4F1FF), Color(0xFF2A7BD6)), // biru
    ),
    gradient = listOf(Color(0xFF8B5CF6), Color(0xFFEC4899), Color(0xFFF97316)),
    zones = ZonesLight,
)

private val PelangiPaletteDark = AccentPalette(
    primary = Color(0xFF9B8CFF), onPrimary = Color(0xFF14102E),
    container = Color(0xFF2A2450), onContainer = Color(0xFFBDB2FF),
    tones = listOf(
        ToneColors(Color(0xFF26214A), Color(0xFFBDB2FF)),
        ToneColors(Color(0xFF3A2416), Color(0xFFFFA877)),
        ToneColors(Color(0xFF14332A), Color(0xFF6FD6A3)),
        ToneColors(Color(0xFF172B44), Color(0xFF8DC2FF)),
    ),
    gradient = listOf(Color(0xFF8B6CF0), Color(0xFFD14FA0), Color(0xFFE8742A)),
    zones = ZonesDark,
)

private fun hsv(h: Float, s: Float, v: Float): Color {
    val hh = ((h % 360f) + 360f) % 360f
    return Color(android.graphics.Color.HSVToColor(floatArrayOf(hh, s.coerceIn(0f, 1f), v.coerceIn(0f, 1f))))
}

/** Palet dari satu warna pilihan: aksen, pastel (4 rona di sekitar warna itu), dan gradien. */
private fun customPalette(base: Color, dark: Boolean): AccentPalette {
    val arr = FloatArray(3)
    android.graphics.Color.colorToHSV(base.toArgb(), arr)
    val h = arr[0]
    val s = arr[1].coerceIn(0.45f, 0.9f)
    // Aksen terang harus cukup gelap agar teks putih terbaca di atasnya.
    var v = arr[2].coerceIn(0.5f, 0.95f)
    var primaryLight = hsv(h, s, v)
    var guard = 0
    while (primaryLight.luminance() > 0.2f && guard++ < 12) { v -= 0.04f; primaryLight = hsv(h, s, v) }
    val hues = floatArrayOf(h, h + 55f, h + 150f, h + 210f)
    return if (!dark) AccentPalette(
        primary = primaryLight, onPrimary = Color.White,
        container = hsv(h, 0.08f, 1f), onContainer = hsv(h, s, (v - 0.08f).coerceAtLeast(0.35f)),
        tones = hues.map { ToneColors(hsv(it, 0.11f, 1f), hsv(it, 0.8f, 0.6f)) },
        gradient = listOf(hsv(h - 30f, 0.72f, 0.93f), hsv(h + 20f, 0.72f, 0.93f), hsv(h + 65f, 0.78f, 0.97f)),
        zones = ZonesLight,
    ) else AccentPalette(
        primary = hsv(h, (s * 0.6f).coerceAtLeast(0.35f), 1f), onPrimary = hsv(h, 0.5f, 0.15f),
        container = hsv(h, 0.45f, 0.22f), onContainer = hsv(h, 0.3f, 1f),
        tones = hues.map { ToneColors(hsv(it, 0.5f, 0.2f), hsv(it, 0.4f, 1f)) },
        gradient = listOf(hsv(h - 30f, 0.6f, 0.9f), hsv(h + 20f, 0.6f, 0.85f), hsv(h + 65f, 0.7f, 0.9f)),
        zones = ZonesDark,
    )
}

/** Palet yang sedang aktif, atau null untuk tema default. */
@Composable
internal fun activePalette(dark: Boolean = MaterialTheme.colorScheme.background.luminance() < 0.5f): AccentPalette? =
    when (ThemePrefs.accent) {
        AccentTheme.DEFAULT -> null
        AccentTheme.PELANGI -> if (dark) PelangiPaletteDark else PelangiPaletteLight
        AccentTheme.CUSTOM -> remember(ThemePrefs.customColor, dark) { customPalette(Color(ThemePrefs.customColor), dark) }
    }

private fun ColorScheme.withPalette(p: AccentPalette): ColorScheme = copy(
    primary = p.primary, onPrimary = p.onPrimary,
    primaryContainer = p.container, onPrimaryContainer = p.onContainer,
    secondaryContainer = p.container, onSecondaryContainer = p.onContainer,
)

/** Warna kartu pastel ke-[i]; null pada tema default sehingga pemanggil memakai warna lama. */
@Composable
fun evTone(i: Int): ToneColors? {
    val p = activePalette() ?: return null
    return p.tones[((i % p.tones.size) + p.tones.size) % p.tones.size]
}

/** Warna zona HR Z1..Z5: tema default memakai palet lama, tema aksen memakai skala yang lebih cerah. */
@Composable
fun evZoneColors(): List<Color> = activePalette()?.zones ?: DefaultZoneColors

val DefaultZoneColors = listOf(Color(0xFF7F9CD6), Color(0xFF3F9E86), Color(0xFFD8B04A), Color(0xFFE8844F), Color(0xFFC84B3B))

/** Gradien tombol tema aksen; null pada tema default. */
@Composable
fun evGradient(): Brush? = activePalette()?.let { Brush.linearGradient(it.gradient) }

/** Aksen untuk elemen yang dulu memakai konstanta Ember: tetap Ember pada tema default. */
@Composable
fun evAccent(): Color = if (ThemePrefs.accent == AccentTheme.DEFAULT) Ember else MaterialTheme.colorScheme.primary

/** Kartu orange transparan: aksen 10% (light) atau 14% (dark) di atas latar, hasilnya warna solid. */
val ColorScheme.cardTint: Color
    get() {
        val dark = background.luminance() < 0.5f
        return primary.copy(alpha = if (dark) 0.14f else 0.10f).compositeOver(background)
    }

/** Teks orange di atas cardTint; lebih gelap di light agar kontras cukup. */
val ColorScheme.onCardTint: Color
    get() = onPrimaryContainer // default: oranye (#C2410C light / #FFA45C dark), sama seperti sebelumnya

enum class ThemeMode(val key: String, val label: String) {
    SYSTEM("system", "Ikuti sistem"), LIGHT("light", "Light"), DARK("dark", "Dark");
    companion object { fun from(k: String?) = values().firstOrNull { it.key == k } ?: SYSTEM }
}

enum class AccentTheme(val key: String, val label: String, val note: String) {
    DEFAULT("default", "Default", "Aksen orange (tema utama)"),
    PELANGI("pelangi", "Pelangi Pastel", "Aksen ungu, kartu pastel warna-warni, tombol gradien"),
    CUSTOM("custom", "Warna sendiri", "Pilih satu warna; pastel dan gradien mengikuti otomatis");
    companion object { fun from(k: String?) = values().firstOrNull { it.key == k } ?: DEFAULT }
}

/** Pilihan tema yang disimpan di SharedPreferences dan dibaca langsung oleh Compose. */
object ThemePrefs {
    private const val FILE = "ev_theme"
    private const val KEY = "mode"
    var mode by mutableStateOf(ThemeMode.SYSTEM)
        private set
    var accent by mutableStateOf(AccentTheme.DEFAULT)
        private set
    var font by mutableStateOf(AppFont.DEFAULT)
        private set
    /** Warna dasar tema "Warna sendiri" (ARGB). */
    var customColor by mutableStateOf(0xFF0E9F8E.toInt())
        private set
    /** Pengali ukuran teks (1.0 = normal). */
    var fontScale by mutableStateOf(1f)
        private set

    fun load(ctx: Context) {
        val sp = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        mode = ThemeMode.from(sp.getString(KEY, null))
        accent = AccentTheme.from(sp.getString("accent", null))
        font = AppFont.from(sp.getString("font", null))
        customColor = sp.getInt("custom_color", 0xFF0E9F8E.toInt())
        fontScale = sp.getFloat("font_scale", 1f).coerceIn(0.85f, 1.3f)
    }

    /** Menyimpan warna sendiri dan langsung mengaktifkan tema "Warna sendiri". */
    fun setCustom(ctx: Context, argb: Int) {
        customColor = argb; accent = AccentTheme.CUSTOM
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putInt("custom_color", argb).putString("accent", AccentTheme.CUSTOM.key).apply()
        com.endurancevault.app.widget.WidgetUpdater.updateAll(ctx)
    }

    fun setFontScale(ctx: Context, v: Float) {
        fontScale = v.coerceIn(0.85f, 1.3f)
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putFloat("font_scale", fontScale).apply()
        com.endurancevault.app.widget.WidgetUpdater.updateAll(ctx)
    }

    fun setAccent(ctx: Context, a: AccentTheme) {
        accent = a
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("accent", a.key).apply()
        com.endurancevault.app.widget.WidgetUpdater.updateAll(ctx)
    }

    fun setFont(ctx: Context, f: AppFont) {
        font = f
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("font", f.key).apply()
        com.endurancevault.app.widget.WidgetUpdater.updateAll(ctx)
    }


    fun set(ctx: Context, m: ThemeMode) {
        mode = m
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString(KEY, m.key).apply()
        com.endurancevault.app.widget.WidgetUpdater.updateAll(ctx)
    }
}

private val EvShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(26.dp),
    extraLarge = RoundedCornerShape(30.dp),
)

private fun evTypography(ff: FontFamily) = Typography(
    headlineLarge = TextStyle(fontFamily = ff, fontWeight = FontWeight.ExtraBold, fontSize = 30.sp, lineHeight = 36.sp, letterSpacing = (-0.8).sp),
    headlineMedium = TextStyle(fontFamily = ff, fontWeight = FontWeight.ExtraBold, fontSize = 25.sp, lineHeight = 31.sp, letterSpacing = (-0.5).sp),
    headlineSmall = TextStyle(fontFamily = ff, fontWeight = FontWeight.Bold, fontSize = 21.sp, lineHeight = 27.sp, letterSpacing = (-0.3).sp),
    titleLarge = TextStyle(fontFamily = ff, fontWeight = FontWeight.Bold, fontSize = 19.sp, lineHeight = 25.sp, letterSpacing = (-0.2).sp),
    titleMedium = TextStyle(fontFamily = ff, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp),
    titleSmall = TextStyle(fontFamily = ff, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp),
    bodyLarge = TextStyle(fontFamily = ff, fontWeight = FontWeight.Normal, fontSize = 15.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontFamily = ff, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontFamily = ff, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 17.sp),
    labelLarge = TextStyle(fontFamily = ff, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, letterSpacing = 0.2.sp),
    labelMedium = TextStyle(fontFamily = ff, fontWeight = FontWeight.Medium, fontSize = 11.sp, letterSpacing = 0.1.sp),
    labelSmall = TextStyle(fontFamily = ff, fontWeight = FontWeight.SemiBold, fontSize = 10.sp, letterSpacing = 0.2.sp),
)

@Composable
fun EnduranceVaultTheme(content: @Composable () -> Unit) {
    val dark = when (ThemePrefs.mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !dark
                isAppearanceLightNavigationBars = !dark
            }
        }
    }
    val base = if (dark) Dark else Light
    val palette = when (ThemePrefs.accent) {
        AccentTheme.DEFAULT -> null
        AccentTheme.PELANGI -> if (dark) PelangiPaletteDark else PelangiPaletteLight
        AccentTheme.CUSTOM -> remember(ThemePrefs.customColor, dark) { customPalette(Color(ThemePrefs.customColor), dark) }
    }
    val scheme = remember(base, palette) { if (palette == null) base else base.withPalette(palette) }
    // Skala teks: hanya mengubah ukuran sp (teks), tidak mengubah dp (tata letak).
    val outer = LocalDensity.current
    // Pada skala 1.0 pakai Density bawaan apa adanya (menjaga penskalaan font non-linear sistem).
    val scaled = remember(outer, ThemePrefs.fontScale) { Density(outer.density, outer.fontScale * ThemePrefs.fontScale) }
    val density = if (ThemePrefs.fontScale == 1f) outer else scaled
    CompositionLocalProvider(LocalDensity provides density) {
        MaterialTheme(
            colorScheme = scheme,
            typography = remember(ThemePrefs.font) { evTypography(ThemePrefs.font.family) },
            shapes = EvShapes,
            content = content,
        )
    }
}

/** Hasil pemetaan tema untuk komponen non-Compose (widget). */
internal class ResolvedTheme(val scheme: ColorScheme, val palette: AccentPalette?, val dark: Boolean, val fontScale: Float)

/**
 * Menentukan skema warna efektif langsung dari SharedPreferences tema (tanpa menyentuh state Compose),
 * sehingga widget memakai aksen, warna sendiri, dan mode terang/gelap yang sama dengan aplikasi.
 */
internal fun resolveThemeForWidget(ctx: Context): ResolvedTheme {
    val sp = ctx.getSharedPreferences("ev_theme", Context.MODE_PRIVATE)
    val mode = ThemeMode.from(sp.getString("mode", null))
    val accent = AccentTheme.from(sp.getString("accent", null))
    val custom = sp.getInt("custom_color", 0xFF0E9F8E.toInt())
    val sysDark = (ctx.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
        android.content.res.Configuration.UI_MODE_NIGHT_YES
    val dark = when (mode) { ThemeMode.DARK -> true; ThemeMode.LIGHT -> false; ThemeMode.SYSTEM -> sysDark }
    val palette = when (accent) {
        AccentTheme.DEFAULT -> null
        AccentTheme.PELANGI -> if (dark) PelangiPaletteDark else PelangiPaletteLight
        AccentTheme.CUSTOM -> customPalette(Color(custom), dark)
    }
    val base = if (dark) Dark else Light
    val scale = sp.getFloat("font_scale", 1f).coerceIn(0.9f, 1.15f) // widget: dibatasi agar teks tidak meluap
    return ResolvedTheme(if (palette == null) base else base.withPalette(palette), palette, dark, scale)
}
