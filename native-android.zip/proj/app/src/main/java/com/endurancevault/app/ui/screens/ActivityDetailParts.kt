package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.i18n.Text
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Switch
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.sp
import com.endurancevault.app.domain.RouteGeo
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import com.endurancevault.app.domain.ActDetail
import com.endurancevault.app.domain.ActInsights
import com.endurancevault.app.domain.ActInsights.SeriesKey
import com.endurancevault.app.domain.Js
import com.endurancevault.app.domain.Zones
import com.endurancevault.app.ui.UiState
import com.endurancevault.app.ui.theme.Ember
import kotlin.math.max
import kotlin.math.min

/** Warna zona HR Z1..Z5; mengikuti tema aksen (default: palet lama). Hanya untuk dipanggil dari fungsi @Composable. */
internal val DetailZoneColors: List<Color>
    @androidx.compose.runtime.Composable get() = com.endurancevault.app.ui.theme.evZoneColors()
internal val DetailGreen = Color(0xFF3F9E86)
internal val DetailAmber = Color(0xFFE0A41B)
internal val DetailRed = Color(0xFFC84B3B)
internal val DetailBlue = Color(0xFF7F9CD6)

@Composable internal fun DSection(title: String, subtitle: String? = null) = EvGroupTitle(title, subtitle)

@Composable
internal fun DCaption(text: String) =
    Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

@Composable
internal fun DStat(label: String, value: String, modifier: Modifier = Modifier, sub: String? = null) {
    Column(modifier) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.titleMedium)
        if (!sub.isNullOrBlank()) Text(sub, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Panel dengan judul kelompok dan sel statistik tiga kolom; sel tanpa nilai (null) dibuang. Kosong = tidak tampil. */
@Composable
internal fun DStatGroup(title: String, cells: List<Triple<String, String?, String?>>) {
    val shown = cells.filter { it.second != null }
    if (shown.isEmpty()) return
    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            shown.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth()) {
                    row.forEach { (label, value, sub) -> DStat(label, value ?: "–", Modifier.weight(1f), sub) }
                    repeat(3 - row.size) { Box(Modifier.weight(1f)) }
                }
            }
        }
    }
}

@Composable
internal fun DCheckList(items: List<ActInsights.Check>) {
    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items.forEach { c ->
                val color = when (c.level) { "ok" -> DetailGreen; "warn" -> DetailAmber; "bad" -> DetailRed; else -> DetailBlue }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
                    Box(Modifier.padding(top = 2.dp).size(18.dp).background(color, CircleShape), contentAlignment = Alignment.Center) {
                        Text(when (c.level) { "ok" -> "✓"; "info" -> "i"; else -> "!" }, color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    }
                    Text(c.text, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}

/** Baris training effect: nilai 0..5 dengan label dan bar. */
@Composable
internal fun DEffectRow(label: String, value: Double, color: Color) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
                Text(ActInsights.dec(value), style = MaterialTheme.typography.titleMedium)
                Text(ActInsights.teLabel(value), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Row(Modifier.fillMaxWidth().height(8.dp).background(MaterialTheme.colorScheme.surfaceVariant, androidx.compose.foundation.shape.RoundedCornerShape(4.dp))) {
            val f = (value / 5.0).coerceIn(0.0, 1.0).toFloat()
            if (f > 0f) Box(Modifier.weight(f).height(8.dp).background(color, androidx.compose.foundation.shape.RoundedCornerShape(4.dp)))
            if (f < 1f) Box(Modifier.weight(1f - f).height(8.dp))
        }
    }
}

/** Penanda kilometer di sepanjang rute: titik berada di antara titik rute [index] dan [index] + 1 pada fraksi [t]. */
internal class KmMark(val km: Int, val index: Int, val t: Float)

/** Jarak kumulatif antar titik rute (satuan bebas), untuk menempatkan penanda km. */
internal fun routeCumulative(pts: List<Pair<Double, Double>>): DoubleArray {
    val c = DoubleArray(pts.size)
    for (i in 1 until pts.size) c[i] = c[i - 1] + kotlin.math.hypot(pts[i].first - pts[i - 1].first, pts[i].second - pts[i - 1].second)
    return c
}

internal fun routeCumulativeGeo(pts: List<RouteGeo.LatLon>): DoubleArray {
    val c = DoubleArray(pts.size)
    for (i in 1 until pts.size) {
        val midLat = Math.toRadians((pts[i].lat + pts[i - 1].lat) / 2)
        val dx = (pts[i].lon - pts[i - 1].lon) * kotlin.math.cos(midLat) * 111.32
        val dy = (pts[i].lat - pts[i - 1].lat) * 110.57
        c[i] = c[i - 1] + kotlin.math.hypot(dx, dy)
    }
    return c
}

/**
 * Penanda tiap kilometer. Panjang rute dinormalkan ke [totalKm] aktivitas (rute disederhanakan, jadi
 * panjang gambarnya sedikit berbeda). Rute panjang diberi penanda lebih jarang supaya tidak menumpuk.
 */
internal fun kmMarks(cum: DoubleArray, totalKm: Double): List<KmMark> {
    if (cum.size < 2 || cum.last() <= 0.0 || totalKm < 1.0) return emptyList()
    val step = when { totalKm <= 15 -> 1; totalKm <= 30 -> 2; totalKm <= 60 -> 5; else -> 10 }
    val out = ArrayList<KmMark>()
    var i = 0
    var k = step
    while (k <= totalKm.toInt()) {
        if (totalKm - k < 0.15) break
        val target = k / totalKm * cum.last()
        while (i < cum.size - 2 && cum[i + 1] < target) i++
        val seg = cum[i + 1] - cum[i]
        out.add(KmMark(k, i, if (seg > 0) ((target - cum[i]) / seg).toFloat().coerceIn(0f, 1f) else 0f))
        k += step
    }
    return out
}

internal fun DrawScope.drawKmMarkers(measurer: TextMeasurer, marks: List<KmMark>, pos: (Int) -> Offset) {
    val r = 9.dp.toPx()
    val style = TextStyle(color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    marks.forEach { m ->
        val a = pos(m.index); val b = pos(m.index + 1)
        val c = Offset(a.x + (b.x - a.x) * m.t, a.y + (b.y - a.y) * m.t)
        drawCircle(Color.White, r + 1.5.dp.toPx(), c)
        drawCircle(Color(0xFF2B2B2B), r, c)
        val l = measurer.measure(m.km.toString(), style)
        drawText(l, topLeft = Offset(c.x - l.size.width / 2f, c.y - l.size.height / 2f))
    }
}

/** Butir legenda "penanda km" di bawah peta. */
@Composable
internal fun KmMarkerLegend() {
    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(9.dp).background(Color(0xFF2B2B2B), CircleShape))
        Text("Penanda km", style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
internal fun DRouteView(d: ActDetail) {
    val w = max(1, d.routeW); val h = max(1, d.routeH)
    val measurer = rememberTextMeasurer()
    val marks = remember(d) { kmMarks(routeCumulative(d.route.map { it.first.toDouble() to it.second.toDouble() }), d.km) }
    val ratio = (w.toFloat() / h).coerceIn(0.6f, 2.2f)
    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Canvas(Modifier.fillMaxWidth().aspectRatio(ratio)) {
                val sc = min(size.width / w, size.height / h)
                val ox = (size.width - w * sc) / 2; val oy = (size.height - h * sc) / 2
                fun pt(p: Pair<Int, Int>) = Offset(ox + p.first * sc, oy + p.second * sc)
                val path = Path()
                d.route.forEachIndexed { i, p -> val o = pt(p); if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y) }
                drawPath(path, Ember, style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                if (routeShowKm) drawKmMarkers(measurer, marks) { i -> pt(d.route[i]) }
                drawCircle(DetailGreen, 6.dp.toPx(), pt(d.route.first()))
                drawCircle(DetailRed, 6.dp.toPx(), pt(d.route.last()))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(9.dp).background(DetailGreen, CircleShape))
                    Text("Mulai", style = MaterialTheme.typography.labelSmall)
                }
                if (routeShowKm && marks.isNotEmpty()) KmMarkerLegend()
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(9.dp).background(DetailRed, CircleShape))
                    Text("Selesai", style = MaterialTheme.typography.labelSmall)
                }
            }
            if (marks.isNotEmpty()) Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Indikator km", style = MaterialTheme.typography.labelMedium)
                Switch(checked = routeShowKm, onCheckedChange = { routeShowKm = it })
            }
            Text(
                "Garis menunjukkan jejak GPS yang tersimpan; peta dasar tidak tersedia pada tampilan offline ini.",
                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/** Grafik garis sederhana. [invert]: nilai kecil di atas (untuk pace, makin cepat makin tinggi). */
@Composable
internal fun DLineChart(pts: List<Pair<Double, Double>>, color: Color, invert: Boolean) {
    EvPanel(Modifier.fillMaxWidth()) {
        Canvas(Modifier.fillMaxWidth().height(110.dp).padding(12.dp)) {
            val x0 = pts.first().first; val x1 = pts.last().first
            val lo = pts.minOf { it.second }; val hi = pts.maxOf { it.second }
            val dx = max(1e-9, x1 - x0); val dy = max(1e-9, hi - lo)
            fun pt(p: Pair<Double, Double>): Offset {
                val fx = ((p.first - x0) / dx).toFloat()
                val fy = ((p.second - lo) / dy).toFloat()
                return Offset(fx * size.width, (if (invert) fy else 1f - fy) * size.height)
            }
            val path = Path()
            pts.forEachIndexed { i, p -> val o = pt(p); if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y) }
            drawPath(path, color, style = Stroke(width = 2.dp.toPx(), join = StrokeJoin.Round))
        }
    }
}

/**
 * Grafik sesi interaktif (HR, kadens, elevasi, pace, vertical speed). Sentuh atau geser untuk membaca nilai di titik itu;
 * tiap deret bisa dimatikan. Tiap deret memakai skala sendiri; pace dibalik agar yang cepat ada di atas.
 */
@Composable
internal fun DSessionChart(model: ActInsights.ChartModel, bike: Boolean) {
    val defaults = remember(model) {
        listOf(SeriesKey.HR, SeriesKey.ELEV, SeriesKey.PACE).filter { model.get(it) != null }
            .ifEmpty { listOfNotNull(model.series.firstOrNull()?.key) }.toSet()
    }
    var on by remember(model) { mutableStateOf(defaults) }
    var cx by remember(model) { mutableStateOf<Float?>(null) }
    val grid = MaterialTheme.colorScheme.outlineVariant
    val ink = MaterialTheme.colorScheme.onSurface
    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SeriesKey.entries.forEach { k ->
                    val has = model.get(k) != null
                    FilterChip(
                        selected = has && k in on, enabled = has,
                        onClick = { on = if (k in on) on - k else on + k },
                        label = { Text(if (k == SeriesKey.PACE && bike) "Kecepatan" else k.label) },
                        leadingIcon = { Box(Modifier.size(9.dp).background(Color(k.color), CircleShape)) },
                    )
                }
            }
            val f = cx
            val x: Double? = f?.let { it * model.xMax }
            Text(
                buildAnnotatedString {
                    if (x == null) {
                        append("Sentuh atau geser grafik untuk melihat nilai di titik itu.")
                    } else {
                        withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(if (model.xIsTime) ActInsights.clock(x) else ActInsights.dec(x, 2) + " km") }
                        model.series.filter { it.key in on }.forEach { s ->
                            val v = s.at(x)
                            append("   ")
                            withStyle(SpanStyle(color = Color(s.key.color))) { append("● ") }
                            append(
                                when (s.key) {
                                    SeriesKey.HR -> "${Js.roundI(v)} bpm"
                                    SeriesKey.CAD -> "${Js.roundI(v)} spm"
                                    SeriesKey.ELEV -> "${ActInsights.dec(v)} m"
                                    SeriesKey.VERT -> "${Js.idn(Js.roundI(v))} m/j"
                                    SeriesKey.PACE -> if (bike) "${ActInsights.dec(v)} km/j" else Js.paceStr(v) + "/km"
                                },
                            )
                        }
                    }
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Canvas(
                Modifier.fillMaxWidth().height(190.dp)
                    .pointerInput(model) { detectTapGestures(onPress = { o -> cx = (o.x / size.width).coerceIn(0f, 1f) }) }
                    .pointerInput(model) {
                        detectHorizontalDragGestures(
                            onDragStart = { o -> cx = (o.x / size.width).coerceIn(0f, 1f) },
                            onHorizontalDrag = { change, _ -> cx = (change.position.x / size.width).coerceIn(0f, 1f); change.consume() },
                        )
                    },
            ) {
                val padX = 8.dp.toPx(); val padY = 10.dp.toPx()
                val w = size.width - 2 * padX; val h = size.height - 2 * padY
                for (i in 0..3) {
                    val y = padY + h * i / 3
                    drawLine(grid, Offset(padX, y), Offset(padX + w, y), 1.dp.toPx())
                }
                fun xOf(v: Double): Float = padX + (v / model.xMax).toFloat() * w
                model.series.filter { it.key in on }.forEach { s ->
                    val inv = s.key == SeriesKey.PACE && !bike
                    val c = Color(s.key.color)
                    fun yOf(v: Double): Float {
                        val fr = ((v - s.lo) / (s.hi - s.lo)).toFloat()
                        return padY + h * (if (inv) fr else 1f - fr)
                    }
                    val path = Path()
                    s.points.forEachIndexed { i, p -> val px = xOf(p.first); val py = yOf(p.second); if (i == 0) path.moveTo(px, py) else path.lineTo(px, py) }
                    if (s.key == SeriesKey.HR) {
                        val fill = Path()
                        fill.moveTo(xOf(s.points.first().first), padY + h)
                        s.points.forEach { p -> fill.lineTo(xOf(p.first), yOf(p.second)) }
                        fill.lineTo(xOf(s.points.last().first), padY + h)
                        fill.close()
                        drawPath(fill, c.copy(alpha = .18f))
                    }
                    drawPath(path, c, style = Stroke(width = 1.8.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
                if (f != null) {
                    val px = padX + f * w
                    drawLine(ink, Offset(px, padY), Offset(px, padY + h), 1.2.dp.toPx())
                    val xv: Double = f * model.xMax
                    model.series.filter { it.key in on }.forEach { s ->
                        val inv = s.key == SeriesKey.PACE && !bike
                        val fr = ((s.at(xv) - s.lo) / (s.hi - s.lo)).toFloat()
                        val py = padY + h * (if (inv) fr else 1f - fr)
                        drawCircle(Color.White, 5.dp.toPx(), Offset(px, py))
                        drawCircle(Color(s.key.color), 3.5.dp.toPx(), Offset(px, py))
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                val labels = listOf(0.0, model.xMax / 2, model.xMax).map { if (model.xIsTime) ActInsights.clock(it) else ActInsights.dec(it, 1) + " km" }
                labels.forEach { Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
        }
    }
}

/** Kurva recovery heart rate 2 menit setelah latihan. */
@Composable
internal fun DRecoveryHrChart(st: ActInsights.RecHr) {
    val grid = MaterialTheme.colorScheme.outlineVariant
    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Canvas(Modifier.fillMaxWidth().height(130.dp)) {
                val padX = 8.dp.toPx(); val padY = 12.dp.toPx()
                val w = size.width - 2 * padX; val h = size.height - 2 * padY
                val lo = (st.values.min().toDouble() - 6); val hi = (max(st.values.max(), st.base).toDouble() + 6)
                for (i in 0..2) { val y = padY + h * i / 2; drawLine(grid, Offset(padX, y), Offset(padX + w, y), 1.dp.toPx()) }
                fun pt(sec: Double, v: Double) = Offset(padX + (sec / 120.0).toFloat() * w, padY + h * (1f - ((v - lo) / (hi - lo)).toFloat()))
                val path = Path()
                val n = st.values.size
                if (n > 1) {
                    st.values.forEachIndexed { i, v -> val o = pt(i * st.stepSec, v.toDouble()); if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y) }
                    drawPath(path, DetailRed, style = Stroke(width = 2.2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
                drawCircle(DetailRed, 4.5.dp.toPx(), pt(0.0, st.base.toDouble()))
                st.h1?.let { drawCircle(Ember, 4.5.dp.toPx(), pt(60.0, it.toDouble())) }
                if (n > 1) drawCircle(DetailBlue, 4.5.dp.toPx(), pt(120.0, st.h2.toDouble()))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                listOf("0 dtk", "1 mnt", "2 mnt").forEach { Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
        }
    }
}

@Composable
internal fun DZoneBlock(state: UiState, hist: Map<Int, Double>) {
    val zc = Zones.cuts(state.settings)
    val secs = Zones.secs(hist, zc)
    val total = max(1.0, secs.sum())
    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth().height(14.dp)) {
                secs.forEachIndexed { i, v -> if (v > 0) Box(Modifier.weight((v / total).toFloat()).height(14.dp).background(DetailZoneColors[i])) }
            }
            val bands = zc.bands()
            secs.forEachIndexed { i, v ->
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).background(DetailZoneColors[i]))
                    Text("  Z${i + 1}  ${bands[i]} bpm", Modifier.weight(2f))
                    Text(if (v > 0) Js.durStr(v / 60) else "–", Modifier.weight(1f))
                    Text("${Math.round(v / total * 100)}%", Modifier.weight(.6f), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            DCaption("Batas zona: ${if (zc.mode == "hrr") "cadangan HR (HRR)" else "LTHR ${zc.lthr} bpm"}, HR maks ${zc.maxHr} bpm.")
        }
    }
}
