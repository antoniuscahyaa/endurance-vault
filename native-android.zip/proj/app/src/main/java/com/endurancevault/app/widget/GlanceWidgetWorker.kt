package com.endurancevault.app.widget

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.endurancevault.app.domain.Wx
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

/**
 * Menyegarkan cuaca widget tiap 15 menit (batas minimum WorkManager) dari lokasi tersimpan di aplikasi,
 * lalu menggambar ulang widget (sekaligus memperbarui tanggal bila sudah ganti hari).
 */
class GlanceWidgetWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val c = applicationContext
        try {
            withContext(Dispatchers.IO) { fetchWeather(c) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // Tanpa jaringan: tetap pakai cuaca terakhir.
        }
        GlanceWidgetRenderer.updateAll(c)
        return Result.success()
    }

    private fun fetchWeather(c: Context) {
        val p = c.getSharedPreferences("weather_loc", Context.MODE_PRIVATE)
        val lat = p.getString("lat", null)?.toDoubleOrNull() ?: -6.99
        val lon = p.getString("lon", null)?.toDoubleOrNull() ?: 110.42
        val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=${Wx.FORECAST_PARAMS_CURRENT}" +
            "&hourly=${Wx.FORECAST_PARAMS_HOURLY}&daily=${Wx.FORECAST_PARAMS_DAILY}&forecast_days=2&timezone=auto"
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 12000; conn.readTimeout = 15000; conn.requestMethod = "GET"
            conn.setRequestProperty("Accept", "application/json")
            if (conn.responseCode !in 200..299) return
            val j = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            GlanceWidgetStore.saveWeather(c, Wx.parse(j, null, lat, lon, "", System.currentTimeMillis()))
        } finally {
            conn.disconnect()
        }
    }

    companion object {
        private const val PERIODIC = "ev_glance_widget_periodic"
        private const val ONCE = "ev_glance_widget_once"

        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<GlanceWidgetWorker>(15, TimeUnit.MINUTES).build()
            WorkManager.getInstance(ctx.applicationContext).enqueueUniquePeriodicWork(PERIODIC, ExistingPeriodicWorkPolicy.KEEP, req)
        }

        fun runOnce(ctx: Context) {
            WorkManager.getInstance(ctx.applicationContext)
                .enqueueUniqueWork(ONCE, ExistingWorkPolicy.REPLACE, OneTimeWorkRequestBuilder<GlanceWidgetWorker>().build())
        }

        fun cancel(ctx: Context) {
            WorkManager.getInstance(ctx.applicationContext).cancelUniqueWork(PERIODIC)
        }
    }
}
