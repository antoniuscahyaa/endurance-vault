package com.endurancevault.app.ui.theme

import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.font.FontWeight
import com.endurancevault.app.R

/**
 * Pilihan font aplikasi. BAWAAN = perilaku lama (FontFamily.SansSerif), jadi tampilan default tidak berubah.
 * Lima pertama memakai font sistem Android (tanpa menambah ukuran APK); sisanya dibundel di res/font
 * (semua berlisensi terbuka: OFL / GUST / DejaVu). Google Sans (OFL) dibundel versi subset Latin (~60 KB per bobot).
 */
enum class AppFont(val key: String, val label: String, val note: String, val family: FontFamily) {
    DEFAULT("default", "Bawaan", "Sans-serif sistem (Roboto)", FontFamily.SansSerif),
    GOOGLE_SANS("google_sans", "Google Sans", "Bersih dan modern ala Google", FontFamily(Font(R.font.google_sans_regular, FontWeight.Normal), Font(R.font.google_sans_medium, FontWeight.Medium), Font(R.font.google_sans_bold, FontWeight.Bold))),
    CONDENSED("condensed", "Condensed", "Ramping, muat banyak angka", FontFamily(android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.NORMAL))),
    SYSTEM_SERIF("serif", "Serif sistem", "Klasik, nyaman untuk teks panjang", FontFamily.Serif),
    SYSTEM_MONO("mono", "Monospace", "Angka lurus, gaya dashboard", FontFamily.Monospace),
    CASUAL("casual", "Casual", "Santai dan bersahabat", FontFamily(android.graphics.Typeface.create("casual", android.graphics.Typeface.NORMAL))),
    INTER("inter", "Inter", "Modern, sangat terbaca di layar", FontFamily(Font(R.font.inter_regular, FontWeight.Normal), Font(R.font.inter_bold, FontWeight.Bold))),
    POPPINS("poppins", "Poppins", "Geometris, ramah, tegas", FontFamily(Font(R.font.poppins_regular, FontWeight.Normal), Font(R.font.poppins_medium, FontWeight.Medium), Font(R.font.poppins_bold, FontWeight.Bold))),
    CARLITO("carlito", "Carlito", "Humanis, mirip Calibri", FontFamily(Font(R.font.carlito_regular, FontWeight.Normal), Font(R.font.carlito_bold, FontWeight.Bold))),
    LORA("lora", "Lora", "Serif elegan bergaya editorial", loraFamily()),
    ADVENTOR("adventor", "Adventor", "Geometris bulat ala Avant Garde", FontFamily(Font(R.font.gyre_adventor_regular, FontWeight.Normal), Font(R.font.gyre_adventor_bold, FontWeight.Bold))),
    HEROS("heros", "Heros", "Netral ala Helvetica", FontFamily(Font(R.font.gyre_heros_regular, FontWeight.Normal), Font(R.font.gyre_heros_bold, FontWeight.Bold))),
    DEJAVU("dejavu", "DejaVu Sans", "Lebar dan lega, jelas di ukuran kecil", FontFamily(Font(R.font.dejavu_sans_regular, FontWeight.Normal), Font(R.font.dejavu_sans_bold, FontWeight.Bold))),
    PAGELLA("pagella", "Pagella", "Serif ala Palatino, hangat", FontFamily(Font(R.font.gyre_pagella_regular, FontWeight.Normal), Font(R.font.gyre_pagella_bold, FontWeight.Bold))),
    BONUM("bonum", "Bonum", "Serif tebal ala Bookman", FontFamily(Font(R.font.gyre_bonum_regular, FontWeight.Normal), Font(R.font.gyre_bonum_bold, FontWeight.Bold))),
    SCHOLA("schola", "Schola", "Serif lebar ala Century", FontFamily(Font(R.font.gyre_schola_regular, FontWeight.Normal), Font(R.font.gyre_schola_bold, FontWeight.Bold))),
    CALADEA("caladea", "Caladea", "Serif ringan, mirip Cambria", FontFamily(Font(R.font.caladea_regular, FontWeight.Normal), Font(R.font.caladea_bold, FontWeight.Bold)));

    companion object {
        fun from(k: String?) = values().firstOrNull { it.key == k } ?: DEFAULT
    }
}

@OptIn(ExperimentalTextApi::class)
private fun loraFamily(): FontFamily {
    fun f(w: FontWeight) = Font(R.font.lora_variable, w, variationSettings = FontVariation.Settings(FontVariation.weight(w.weight)))
    return FontFamily(f(FontWeight.Normal), f(FontWeight.Medium), f(FontWeight.SemiBold), f(FontWeight.Bold), f(FontWeight.ExtraBold))
}
