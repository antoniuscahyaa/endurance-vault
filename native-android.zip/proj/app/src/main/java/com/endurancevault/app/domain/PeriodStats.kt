package com.endurancevault.app.domain

import com.endurancevault.app.data.ActivityEntity
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters
import kotlin.math.roundToInt

/** Periode kartu statistik yang dibagikan. */
enum class SharePeriod { DAY, WEEK, MONTH }

/**
 * Ringkasan satu periode. [dailyKm] berisi satu angka per hari dari [start] sampai [end] (hari tanpa lari = 0).
 * [avgHr] dirata-rata berbobot durasi.
 */
class PeriodSummary(
    val period: SharePeriod, val start: LocalDate, val end: LocalDate,
    val km: Double, val durationSec: Int, val gain: Int, val sessions: Int,
    val avgHr: Int?, val longestKm: Double, val dailyKm: List<Double>,
) {
    /** Pace rata-rata (menit/km) dari total durasi dan total jarak; null bila belum ada lari. */
    val avgPace: Double? get() = if (km > 0 && durationSec > 0) durationSec / 60.0 / km else null
    val activeDays: Int get() = dailyKm.count { it > 0 }
}

/** Satu minggu (Senin sampai Minggu) di dalam sebuah bulan, dipotong pada batas bulan. */
class MonthWeek(val start: LocalDate, val end: LocalDate, val km: Double, val sessions: Int)

/** Rekor dalam satu bulan; pace tercepat hanya dihitung untuk lari sejauh [PeriodStats.MIN_PACE_KM] atau lebih. */
class MonthRecords(
    val longestKm: Double, val longestDate: LocalDate?,
    val fastestPace: Double?, val fastestDate: LocalDate?, val fastestKm: Double?,
    val topGain: Int, val topGainDate: LocalDate?,
)

object PeriodStats {
    /** Jarak minimum (km) agar sebuah lari dihitung untuk pace tercepat bulan itu. */
    const val MIN_PACE_KM = 3.0

    /** Rentang periode yang memuat [anchor]: minggu Senin sampai Minggu, bulan tanggal 1 sampai hari terakhir. */
    fun range(period: SharePeriod, anchor: LocalDate): Pair<LocalDate, LocalDate> = when (period) {
        SharePeriod.DAY -> anchor to anchor
        SharePeriod.WEEK -> {
            val mon = anchor.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            mon to mon.plusDays(6)
        }
        SharePeriod.MONTH -> anchor.withDayOfMonth(1) to anchor.with(TemporalAdjusters.lastDayOfMonth())
    }

    private fun dateOf(e: ActivityEntity): LocalDate? = runCatching { LocalDate.parse(e.dateIso.take(10)) }.getOrNull()

    /** Total jarak rencana (PWeek/SwDay) yang jatuh di [start]..[end]; null bila tidak ada rencana pada rentang itu. */
    fun planTarget(weeks: List<SwWeek>, start: LocalDate, end: LocalDate): Double? {
        val km = weeks.flatMap { it.days }.filter { !it.date.isBefore(start) && !it.date.isAfter(end) }.sumOf { it.km }
        return if (km > 0.0) km else null
    }

    /**
     * Pembanding untuk template Banding: minggu lalu (WEEK), bulan lalu (MONTH), atau rata-rata per lari dalam 28 hari
     * sebelum hari itu (DAY). Null bila pembandingnya kosong.
     */
    fun previous(acts: List<ActivityEntity>, period: SharePeriod, anchor: LocalDate, today: LocalDate? = null): PeriodSummary? = when (period) {
        SharePeriod.WEEK -> sameSpan(acts, period, anchor, anchor.minusWeeks(1), today)
        SharePeriod.MONTH -> sameSpan(acts, period, anchor, anchor.withDayOfMonth(1).minusMonths(1), today)
        SharePeriod.DAY -> baseline28(acts, anchor)
    }

    /**
     * Periode sebelumnya yang adil: bila periode [anchor] masih berjalan pada [today] (hari ini belum hari terakhirnya),
     * pembandingnya hanya jumlah hari yang sama sejak awal periode sebelumnya, bukan satu periode penuh. [today] null = selalu penuh.
     */
    private fun sameSpan(acts: List<ActivityEntity>, period: SharePeriod, anchor: LocalDate, prevAnchor: LocalDate, today: LocalDate?): PeriodSummary? {
        val (cs, ce) = range(period, anchor)
        val (ps, pe) = range(period, prevAnchor)
        val running = today != null && !today.isBefore(cs) && today.isBefore(ce)
        val cut = if (running && today != null) ps.plusDays(today.toEpochDay() - cs.toEpochDay()) else pe
        val end = if (cut.isAfter(pe)) pe else cut
        return summarizeIn(acts, period, ps, end).takeIf { it.km > 0.0 }
    }

    fun previousLabel(period: SharePeriod): String = when (period) {
        SharePeriod.DAY -> "rata-rata 28 hari"
        SharePeriod.WEEK -> "minggu lalu"
        SharePeriod.MONTH -> "bulan lalu"
    }

    /** Rata-rata per lari pada 28 hari sebelum [day] (tidak termasuk [day]); durasi/jarak/elevasi adalah rata-rata per lari. */
    fun baseline28(acts: List<ActivityEntity>, day: LocalDate): PeriodSummary? {
        val from = day.minusDays(28); val to = day.minusDays(1)
        val runs = acts.filter { a ->
            val d = dateOf(a)
            d != null && !d.isBefore(from) && !d.isAfter(to) && a.type != "bike" && a.km > 0.0
        }
        if (runs.isEmpty()) return null
        val n = runs.size
        var hrSum = 0.0; var hrSec = 0
        runs.forEach { a -> val hr = a.avgHr; if (hr != null && hr > 0 && a.durationSec > 0) { hrSum += hr.toDouble() * a.durationSec; hrSec += a.durationSec } }
        return PeriodSummary(
            SharePeriod.DAY, from, to, runs.sumOf { it.km } / n, runs.sumOf { it.durationSec } / n, runs.sumOf { it.gain ?: 0 } / n, n,
            if (hrSec > 0) (hrSum / hrSec).roundToInt() else null, runs.maxOf { it.km }, emptyList(),
        )
    }

    /** Km per minggu yang beririsan dengan bulan [anchor]; minggu pertama dan terakhir dipotong pada batas bulan. */
    fun monthWeeks(acts: List<ActivityEntity>, anchor: LocalDate): List<MonthWeek> {
        val (ms, me) = range(SharePeriod.MONTH, anchor)
        val out = ArrayList<MonthWeek>()
        var ws = ms.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        while (!ws.isAfter(me)) {
            val s = if (ws.isBefore(ms)) ms else ws
            val e0 = ws.plusDays(6)
            val e = if (e0.isAfter(me)) me else e0
            val sm = summarizeIn(acts, SharePeriod.WEEK, s, e)
            out.add(MonthWeek(s, e, sm.km, sm.sessions))
            ws = ws.plusDays(7)
        }
        return out
    }

    /** Lari terpanjang, pace tercepat (minimal [MIN_PACE_KM]), dan tanjakan terbanyak dalam bulan [anchor]; null bila tidak ada lari. */
    fun monthRecords(acts: List<ActivityEntity>, anchor: LocalDate): MonthRecords? {
        val (ms, me) = range(SharePeriod.MONTH, anchor)
        val runs = acts.mapNotNull { a ->
            val d = dateOf(a) ?: return@mapNotNull null
            if (a.type == "bike" || a.km <= 0.0 || d.isBefore(ms) || d.isAfter(me)) null else d to a
        }
        if (runs.isEmpty()) return null
        val longest = runs.maxByOrNull { it.second.km }!!
        val fast = runs.filter { it.second.km >= MIN_PACE_KM && it.second.durationSec > 0 }.minByOrNull { it.second.durationSec / it.second.km }
        val climb = runs.maxByOrNull { it.second.gain ?: 0 }!!
        val gain = climb.second.gain ?: 0
        return MonthRecords(
            longest.second.km, longest.first,
            fast?.let { it.second.durationSec / 60.0 / it.second.km }, fast?.first, fast?.second?.km,
            gain, if (gain > 0) climb.first else null,
        )
    }

    /** Hanya lari (bukan sepeda) dengan jarak > 0 yang dihitung. */
    fun summarize(acts: List<ActivityEntity>, period: SharePeriod, anchor: LocalDate): PeriodSummary {
        val (start, end) = range(period, anchor)
        return summarizeIn(acts, period, start, end)
    }

    /** Seperti [summarize] untuk rentang [start]..[end] yang ditentukan sendiri. */
    fun summarizeIn(acts: List<ActivityEntity>, period: SharePeriod, start: LocalDate, end: LocalDate): PeriodSummary {
        val nDays = (end.toEpochDay() - start.toEpochDay()).toInt() + 1
        val inRange = acts.mapNotNull { a ->
            val d = dateOf(a) ?: return@mapNotNull null
            if (a.type == "bike" || a.km <= 0.0 || d.isBefore(start) || d.isAfter(end)) null else d to a
        }
        val daily = DoubleArray(nDays)
        var km = 0.0; var sec = 0; var gain = 0; var longest = 0.0
        var hrSum = 0.0; var hrSec = 0
        inRange.forEach { (d, a) ->
            daily[(d.toEpochDay() - start.toEpochDay()).toInt()] += a.km
            km += a.km; sec += a.durationSec; gain += a.gain ?: 0
            if (a.km > longest) longest = a.km
            val hr = a.avgHr
            if (hr != null && hr > 0 && a.durationSec > 0) { hrSum += hr.toDouble() * a.durationSec; hrSec += a.durationSec }
        }
        val avgHr = if (hrSec > 0) (hrSum / hrSec).roundToInt() else null
        return PeriodSummary(period, start, end, km, sec, gain, inRange.size, avgHr, longest, daily.toList())
    }
}
