package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.theme.EvButton

import com.endurancevault.app.ui.i18n.Text
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import org.json.JSONArray
import org.json.JSONObject

/** A-GPS Huawei Watch (dipindah dari Pengaturan > Layanan ke halaman Pengaturan jam). */
@Composable
fun WatchAgpsSection(agpsStatus: String, onAgps: (Boolean, String) -> Unit, onTestAgps: () -> Unit) {
    val a = runCatching { JSONObject(agpsStatus) }.getOrNull()
    var mirror by remember(a?.optString("mirrorUrl")) { mutableStateOf(a?.optString("mirrorUrl")?.takeIf{it!="null"} ?: "") }
    var agpsOn by remember(a?.optBoolean("enabled") ?: false) { mutableStateOf(a?.optBoolean("enabled") ?: false) }
    val agpsMessage = a?.optString("lastError")?.takeIf { it != "null" }
        ?: if ((a?.optLong("lastOkAt") ?: 0L) > 0L) "Unduhan terakhir berhasil (${a?.optLong("lastBytes")} byte)" else "Belum diuji"
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Mengatur pengambilan data orbit satelit. Server mirror opsional; kosong berarti memakai sumber Broadcom bawaan.",style=MaterialTheme.typography.bodySmall)
        OutlinedTextField(mirror,{mirror=it},label={Text("HTTPS mirror URL (opsional)")},modifier=Modifier.fillMaxWidth(),singleLine=true)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { Switch(agpsOn,{agpsOn=it;onAgps(it,mirror)}); Text(if(agpsOn)"A-GPS aktif" else "A-GPS nonaktif") }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { OutlinedButton(onClick={onAgps(agpsOn,mirror)}){Text("Simpan")}; EvButton(onClick=onTestAgps){Text("Uji unduh A-GPS") } }
        Text("Status: $agpsMessage",style=MaterialTheme.typography.bodySmall)
    }
}

/** Notifikasi ponsel ke jam (dipindah dari Pengaturan > Layanan ke halaman Pengaturan jam). */
@Composable
fun WatchNotifySection(notifyStatus: String, onNotify: (Boolean, Boolean, Int, Int, Boolean, Map<String, Boolean>) -> Unit, onTestNotify: () -> Unit) {
    val ctx = LocalContext.current
    val n = runCatching { JSONObject(notifyStatus) }.getOrNull()
    var quietStart by remember { mutableStateOf("22:00") }
    var quietEnd by remember { mutableStateOf("06:00") }
    var notifyOn by remember(n?.optBoolean("enabled") ?: false) { mutableStateOf(n?.optBoolean("enabled") ?: false) }
    var quietOn by remember(n?.optBoolean("quietEnabled") ?: false) { mutableStateOf(n?.optBoolean("quietEnabled") ?: false) }
    var screenOff by remember(n?.optBoolean("onlyScreenOff") ?: false) { mutableStateOf(n?.optBoolean("onlyScreenOff") ?: false) }
    var appChoices by remember(n?.toString()) { mutableStateOf(buildMap { val apps=n?.optJSONArray("apps") ?: JSONArray(); for(i in 0 until apps.length()){val x=apps.optJSONObject(i)?:continue;put(x.optString("pkg"),x.optBoolean("on"))} }) }
    fun saveNotify(enabled:Boolean=notifyOn, quiet:Boolean=quietOn, screen:Boolean=screenOff) = onNotify(enabled,quiet,quietStart.toMinutesOrDefault(1320),quietEnd.toMinutesOrDefault(360),screen,appChoices)
    val notificationAccess = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Akses notifikasi Android harus diaktifkan manual. Isi notifikasi hanya diteruskan saat ada notifikasi baru; aplikasi tidak menyimpan isi pesan.",style=MaterialTheme.typography.bodySmall)
        OutlinedButton(onClick={ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))}){Text(if(notificationAccess)"Akses notifikasi sudah aktif · Kelola" else "Aktifkan akses notifikasi Android")}
        Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){Switch(notifyOn,{notifyOn=it;saveNotify(enabled=it)});Text("Teruskan notifikasi ke jam")}
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(quietStart,{quietStart=it},label={Text("Mulai tenang HH:mm")},modifier=Modifier.weight(1f),singleLine=true)
            OutlinedTextField(quietEnd,{quietEnd=it},label={Text("Selesai tenang HH:mm")},modifier=Modifier.weight(1f),singleLine=true)
        }
        Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){Switch(quietOn,{quietOn=it;saveNotify(quiet=it)});Text("Aktifkan jam tenang")}
        Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){Switch(screenOff,{screenOff=it;saveNotify(screen=it)});Text("Hanya saat layar ponsel mati")}
        Text("Aplikasi yang diteruskan",style=MaterialTheme.typography.titleMedium)
        appChoices.forEach { (pkg,on) ->
            Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically) {
                Switch(checked=on,onCheckedChange={v->appChoices=appChoices.toMutableMap().also{it[pkg]=v};saveNotify()})
                Text(pkg.substringAfterLast('.'),style=MaterialTheme.typography.bodyMedium)
            }
        }
        EvButton(onClick={saveNotify()}){Text("Simpan pengaturan notifikasi")}
        EvButton(onClick=onTestNotify){Text("Kirim notifikasi uji")}
        Text("Status: ${n?.optString("lastResult")?.takeIf{it!="null"} ?: "Belum ada pengiriman"} · terkirim ${n?.optInt("sentCount")?:0}",style=MaterialTheme.typography.bodySmall)
    }
}

private fun String.toMinutesOrDefault(fallback:Int):Int { val p=split(":"); if(p.size!=2)return fallback; val h=p[0].toIntOrNull()?:return fallback;val m=p[1].toIntOrNull()?:return fallback;return if(h in 0..23&&m in 0..59)h*60+m else fallback }
