package com.endurancevault.app.domain

import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.data.DailyEntity

/**
 * Acuan latihan otomatis: batas HR easy, rentang HR threshold, dan pace easy. Tidak ada isian manual.
 * - Batas HR easy = batas atas Z2 dan rentang threshold = Z4 dari zona HR aktif ([Zones.sessionRefs]).
 * - Pace easy = zona Easy dari RAI (sama dengan kartu "Zona pace dari RAI" di Fitness). Bila RAI belum bisa dihitung,
 *   memakai rata-rata [RECENT_RUNS] lari easy terakhir dengan margin ± [FALLBACK_MARGIN_SEC] detik.
 * Mesin rencana hanya membaca satu angka pace, jadi yang disimpan ke pengaturan adalah titik tengah rentang ([Refs.paceMid]).
 */
object TrainingRefs {
    enum class Source { RAI, EASY_RUNS, NONE }

    class Refs(
        val easyHr: Int,
        /** "164–172". */
        val thr: String,
        /** "m:ss" titik tengah untuk disimpan ke pengaturan; null bila belum ada data pace. */
        val paceMid: String?,
        /** "lambat–cepat" (urutan sama dengan Fitness), mis. "6:51–6:12"; null bila belum ada data pace. */
        val paceRange: String?,
        val source: Source,
    )

    const val RECENT_RUNS = 5
    const val FALLBACK_MARGIN_SEC = 10
    /** Pace tersimpan baru diganti bila selisihnya sedikitnya segini (detik/km); mencegah rencana dihitung ulang tiap pergeseran kecil. */
    const val PACE_SAVE_MIN_SEC = 5

    fun compute(s: PlanSettings, activities: List<ActivityEntity>, daily: List<DailyEntity>, restDefault: Int): Refs {
        val zc = Zones.cuts(s, restDefault)
        val (easyHr, thrZ) = Zones.sessionRefs(zc)
        val thr = "${thrZ.first}–${thrZ.last}"

        var slow: Double? = null
        var fast: Double? = null
        var src = Source.NONE
        val rai = runCatching { ProgressAnalytics.runningAbility(s, activities, daily)?.value }.getOrNull()
        val easy = FitnessAnalytics.PACE_ZONES.first { it.name == "Easy" }
        if (rai != null) {
            slow = FitnessAnalytics.paceAtFrac(rai, easy.lo)
            fast = FitnessAnalytics.paceAtFrac(rai, easy.hi)
            src = Source.RAI
        } else {
            val recent = EasyPace.recentAverage(
                activities.map { EasyPace.Run(it.dateIso, it.km, it.durationSec / 60.0, it.avgHr, it.type, it.gain) }, easyHr, RECENT_RUNS,
            )
            if (recent != null) {
                slow = recent.pace + FALLBACK_MARGIN_SEC / 60.0
                fast = recent.pace - FALLBACK_MARGIN_SEC / 60.0
                src = Source.EASY_RUNS
            }
        }
        val mid = if (slow != null && fast != null) Js.paceStr((slow + fast) / 2) else null
        // Nilai di luar batas validasi pace (3:00–12:00) dianggap belum ada data.
        if (mid == null || ZoneChecks.pace(mid) != null || slow == null || fast == null) return Refs(easyHr, thr, null, null, Source.NONE)
        return Refs(easyHr, thr, mid, "${Js.paceStr(slow)}–${Js.paceStr(fast)}", src)
    }

    /**
     * Pengaturan baru yang layak disimpan, atau null bila tidak perlu menyimpan.
     * HR easy dan rentang threshold disimpan begitu berubah (berasal dari zona, jadi stabil);
     * pace hanya bila selisih >= [PACE_SAVE_MIN_SEC] detik atau pace tersimpan tidak valid.
     */
    fun update(cur: PlanSettings, r: Refs): PlanSettings? {
        val np = r.paceMid
        val paceChanged = np != null && (
            ZoneChecks.pace(cur.pace) != null ||
                Math.abs(Js.parsePaceStr(cur.pace) - Js.parsePaceStr(np)) * 60 >= PACE_SAVE_MIN_SEC - 1e-6
            )
        // Tanpa LTHR sendiri, zona dihitung dari titik tengah rentang thr yang tersimpan ([Zones.cuts]). Menulis rentang Z4 hasil
        // zona itu kembali ke thr membuat umpan balik: tiap simpan menggeser titik tengah (sekitar -2,5%), efek ini terpicu lagi, dan
        // pengaturan tersimpan terus-menerus (field LTHR berkedip, isian hilang, aplikasi berat). Jadi thr hanya ditulis bila LTHR terisi,
        // saat zona tidak bergantung pada thr tersimpan.
        val thrWritable = (cur.lthr ?: 0.0) >= 100
        val newThr = if (thrWritable) r.thr else cur.thr
        if (r.easyHr == cur.hr && newThr == cur.thr && !paceChanged) return null
        return cur.copy(hr = r.easyHr, thr = newThr, pace = if (paceChanged) np!! else cur.pace)
    }
}
