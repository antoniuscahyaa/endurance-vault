package com.endurancevault.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.drawscope.DrawScope
import com.endurancevault.app.domain.GuideMotion
import com.endurancevault.app.domain.GuideMove
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Animasi pemandu gerakan strength: figur garis tampak samping (menghadap kanan) yang bergerak antara
 * pose A dan pose B. Koordinat dunia 0..100 (lantai di y = 92), kamera memakai x -5..105 dan y -14..96.
 *
 * Pose disusun dari sudut dan titik tumpu, bukan koordinat sendi mentah: panjang tulang selalu tetap dan
 * kaki/tangan yang menapak (IK dua tulang) tidak melayang saat pinggul naik turun.
 */

private const val T = 28f      // panjang torso
private const val UA = 13f     // lengan atas
private const val FA = 12f     // lengan bawah
private const val TH = 22f     // paha
private const val SH = 22f     // betis
private const val FT = 9f      // telapak kaki
private const val HEAD = 9f    // jarak pusat kepala dari leher

/**
 * Satu anggota gerak (lengan atau kaki).
 * fk: a = sudut paha/lengan atas, b = sudut betis/lengan bawah (derajat dari arah "bawah", + ke depan).
 * ik: a, b = titik tumpu (pergelangan kaki / tangan) di koordinat dunia; dir = arah tekuk sendi (+1 ke depan).
 * f = sudut telapak kaki dari horizontal (+ ke bawah); tidak dipakai lengan.
 */
internal class Limb(val ik: Boolean, val a: Float, val b: Float, val f: Float = 26f, val dir: Float = 1f)

/** Pinggul (hx, hy) di koordinat dunia, t = condong torso dari tegak (+ ke depan), lalu lengan dan dua kaki. */
internal class Pose(val hx: Float, val hy: Float, val t: Float, val arm: Limb, val leg1: Limb, val leg2: Limb)

internal sealed interface Prop {
    class Rect(val x1: Float, val y1: Float, val x2: Float, val y2: Float) : Prop
    class Wall(val x: Float) : Prop
    class BandHand(val ax: Float, val ay: Float) : Prop
    class BandFoot(val ax: Float, val ay: Float) : Prop
    data object BandKnees : Prop
    data object WeightHand : Prop
    data object WeightHip : Prop
    data object Cable : Prop
}

internal class GuideDef(val a: Pose, val b: Pose, val props: List<Prop>)

private fun fk(a: Float, b: Float, f: Float = 26f) = Limb(false, a, b, f)
private fun ik(x: Float, y: Float, f: Float = 26f, dir: Float = 1f) = Limb(true, x, y, f, dir)
private fun pose(hx: Float, hy: Float, t: Float, arm: Limb, l1: Limb, l2: Limb = l1) = Pose(hx, hy, t, arm, l1, l2)

// Hasil tabel pose; sumber tunggal ada di alat penyusun pose, jangan ubah angka tanpa merender ulang.
private val GUIDES: Map<GuideMove, GuideDef> = mapOf(
    GuideMove.SQUAT to GuideDef(
        pose(46f, 44f, 0f, fk(0f, 150f), ik(46f, 88f)),
        pose(34f, 64f, 40f, fk(0f, 150f), ik(46f, 88f)),
        listOf(Prop.WeightHand),
    ),
    GuideMove.HINGE to GuideDef(
        pose(48f, 44f, 0f, fk(-6f, -6f), ik(48f, 88f)),
        pose(34f, 52f, 78f, fk(-14f, -14f), ik(48f, 88f)),
        listOf(Prop.WeightHand),
    ),
    GuideMove.SL_RDL to GuideDef(
        pose(52f, 44f, 0f, fk(0f, 0f), ik(52f, 88f), fk(-8f, -30f, 40f)),
        pose(44f, 52f, 80f, fk(-6f, -6f), ik(52f, 88f), fk(-95f, -95f, 60f)),
        listOf(Prop.WeightHand),
    ),
    GuideMove.LUNGE to GuideDef(
        pose(46f, 46f, 0f, fk(0f, 0f), ik(64f, 88f), ik(26f, 73f, 170f)),
        pose(46f, 62f, 8f, fk(0f, 0f), ik(64f, 88f), ik(26f, 73f, 170f)),
        listOf(Prop.Rect(12f, 76f, 32f, 92f), Prop.WeightHand),
    ),
    GuideMove.STEP to GuideDef(
        pose(48f, 31f, 0f, fk(0f, 0f), ik(48f, 74f), ik(58f, 74f)),
        pose(44f, 48f, 14f, fk(0f, 0f), ik(48f, 74f), ik(62f, 88f)),
        listOf(Prop.Rect(30f, 78f, 66f, 92f), Prop.WeightHand),
    ),
    GuideMove.CALF to GuideDef(
        pose(50f, 44f, 0f, fk(0f, 0f), ik(50f, 88f)),
        pose(51f, 39f, 0f, fk(0f, 0f), ik(53f, 82f, 85f)),
        listOf(),
    ),
    GuideMove.PLANK to GuideDef(
        pose(50f, 79f, 84f, fk(0f, 90f), ik(8f, 85f, 40f)),
        pose(50f, 76f, 84f, fk(0f, 90f), ik(8f, 85f, 40f)),
        listOf(),
    ),
    GuideMove.SIDE_PLANK to GuideDef(
        pose(50f, 80f, 84f, fk(0f, 90f), ik(8f, 85f, 40f)),
        pose(50f, 72f, 84f, fk(0f, 90f), ik(8f, 85f, 40f)),
        listOf(),
    ),
    GuideMove.PUSH to GuideDef(
        pose(49f, 70f, 80f, ik(77f, 90f, 0f, -1f), ik(8f, 85f, 40f)),
        pose(49f, 82f, 84f, ik(77f, 90f, 0f, -1f), ik(8f, 85f, 40f)),
        listOf(),
    ),
    GuideMove.ROW to GuideDef(
        pose(36f, 54f, 65f, fk(0f, 0f), ik(46f, 88f)),
        pose(36f, 54f, 65f, fk(-115f, 0f), ik(46f, 88f)),
        listOf(Prop.WeightHand),
    ),
    GuideMove.PRESS to GuideDef(
        pose(50f, 46f, 0f, fk(10f, 170f), ik(50f, 88f)),
        pose(50f, 46f, 0f, fk(172f, 176f), ik(50f, 88f)),
        listOf(Prop.WeightHand),
    ),
    GuideMove.BRIDGE to GuideDef(
        pose(36f, 74f, -82f, fk(85f, 85f), ik(54f, 88f)),
        pose(36f, 58f, -115f, fk(85f, 85f), ik(54f, 88f)),
        listOf(Prop.Rect(0f, 74f, 24f, 92f), Prop.WeightHip),
    ),
    GuideMove.BAND_WALK to GuideDef(
        pose(48f, 56f, 25f, fk(60f, 90f), ik(46f, 88f), ik(54f, 88f)),
        pose(55f, 56f, 25f, fk(60f, 90f), ik(46f, 88f), ik(74f, 88f)),
        listOf(Prop.BandKnees),
    ),
    GuideMove.TIBIALIS to GuideDef(
        pose(36f, 48f, -6f, fk(0f, 0f), ik(52f, 88f)),
        pose(36f, 48f, -6f, fk(0f, 0f), ik(52f, 88f, -28f)),
        listOf(Prop.Wall(28f)),
    ),
    GuideMove.BAND_ANKLE to GuideDef(
        pose(26f, 86f, 0f, fk(0f, 0f), fk(90f, 90f, -55f)),
        pose(26f, 86f, 0f, fk(0f, 0f), fk(90f, 90f, 40f)),
        listOf(Prop.BandFoot(98f, 80f)),
    ),
    GuideMove.BALANCE to GuideDef(
        pose(50f, 44f, 0f, fk(30f, 40f), ik(50f, 88f), fk(15f, -40f, 40f)),
        pose(51f, 45f, 6f, fk(60f, 80f), ik(50f, 88f), fk(30f, -25f, 40f)),
        listOf(Prop.Rect(38f, 88f, 62f, 92f)),
    ),
    GuideMove.HOP to GuideDef(
        pose(50f, 48f, 0f, fk(5f, 5f), ik(50f, 88f)),
        pose(50f, 38f, 0f, fk(5f, 5f), ik(50f, 78f, 80f)),
        listOf(),
    ),
    GuideMove.CARRY to GuideDef(
        pose(50f, 47f, 0f, fk(0f, 0f), fk(25f, 10f, 0f), fk(-25f, -15f, 0f)),
        pose(50f, 47f, 0f, fk(0f, 0f), fk(-25f, -15f, 0f), fk(25f, 10f, 0f)),
        listOf(Prop.WeightHand),
    ),
    GuideMove.DEADBUG to GuideDef(
        pose(52f, 86f, -90f, fk(180f, 180f), fk(180f, 90f, -60f)),
        pose(52f, 86f, -90f, fk(270f, 270f), fk(180f, 90f, -60f), fk(100f, 95f, -60f)),
        listOf(),
    ),
    GuideMove.PALLOF to GuideDef(
        pose(50f, 48f, 0f, fk(20f, 110f), ik(46f, 88f), ik(54f, 88f)),
        pose(50f, 48f, 0f, fk(90f, 90f), ik(46f, 88f), ik(54f, 88f)),
        listOf(Prop.BandHand(4f, 34f)),
    ),
    GuideMove.FACEPULL to GuideDef(
        pose(50f, 46f, 0f, fk(90f, 90f), ik(46f, 88f), ik(54f, 88f)),
        pose(50f, 46f, 0f, fk(-80f, 120f), ik(46f, 88f), ik(54f, 88f)),
        listOf(Prop.BandHand(98f, 24f)),
    ),
    GuideMove.PULL to GuideDef(
        pose(46f, 66f, -5f, fk(175f, 175f), fk(88f, -3f)),
        pose(46f, 66f, -5f, fk(-10f, 160f), fk(88f, -3f)),
        listOf(Prop.Rect(34f, 67f, 60f, 71f), Prop.Cable),
    ),
    GuideMove.GENERIC to GuideDef(
        pose(50f, 44f, 0f, fk(5f, 10f), ik(50f, 88f)),
        pose(50f, 43f, 0f, fk(15f, 25f), ik(50f, 88f)),
        listOf(),
    ),
)

// ---------- kinematika ----------

private fun dirOf(deg: Float): Offset {
    val r = deg * (PI.toFloat() / 180f)
    return Offset(sin(r), cos(r))
}

/** Dua tulang dari akar [h] ke target [t]; mengembalikan (sendi tengah, ujung). */
private fun ik2(h: Offset, t: Offset, l1: Float, l2: Float, dirx: Float): Pair<Offset, Offset> {
    val dx = t.x - h.x
    val dy = t.y - h.y
    val raw = max(hypot(dx, dy), 0.001f)
    val dist = raw.coerceIn(abs(l1 - l2) + 0.5f, l1 + l2 - 0.3f)
    val ux = dx / raw
    val uy = dy / raw
    val a = (l1 * l1 - l2 * l2 + dist * dist) / (2f * dist)
    val hh = sqrt(max(0f, l1 * l1 - a * a))
    val bx = h.x + ux * a
    val by = h.y + uy * a
    val c1 = Offset(bx - uy * hh, by + ux * hh)
    val c2 = Offset(bx + uy * hh, by - ux * hh)
    val k = if ((c1.x - c2.x) * dirx >= 0f) c1 else c2
    return k to Offset(h.x + ux * dist, h.y + uy * dist)
}

private class LimbPts(val mid: Offset, val end: Offset, val toe: Offset)

private fun limbPts(root: Offset, l: Limb, l1: Float, l2: Float): LimbPts {
    val mid: Offset
    val end: Offset
    if (l.ik) {
        val r = ik2(root, Offset(l.a, l.b), l1, l2, l.dir)
        mid = r.first; end = r.second
    } else {
        val d1 = dirOf(l.a)
        mid = Offset(root.x + d1.x * l1, root.y + d1.y * l1)
        val d2 = dirOf(l.b)
        end = Offset(mid.x + d2.x * l2, mid.y + d2.y * l2)
    }
    val fr = l.f * (PI.toFloat() / 180f)
    return LimbPts(mid, end, Offset(end.x + FT * cos(fr), end.y + FT * sin(fr)))
}

private class Skel(
    val hip: Offset, val neck: Offset, val head: Offset, val elbow: Offset, val hand: Offset,
    val knee: Offset, val ankle: Offset, val toe: Offset, val knee2: Offset, val ankle2: Offset, val toe2: Offset,
)

private fun solve(p: Pose): Skel {
    val hip = Offset(p.hx, p.hy)
    val tr = p.t * (PI.toFloat() / 180f)
    val up = Offset(sin(tr), -cos(tr))
    val neck = Offset(hip.x + up.x * T, hip.y + up.y * T)
    val head = Offset(neck.x + up.x * HEAD, neck.y + up.y * HEAD)
    val arm = limbPts(neck, p.arm, UA, FA)
    val l1 = limbPts(hip, p.leg1, TH, SH)
    val l2 = limbPts(hip, p.leg2, TH, SH)
    return Skel(hip, neck, head, arm.mid, arm.end, l1.mid, l1.end, l1.toe, l2.mid, l2.end, l2.toe)
}

private fun lerp(a: Float, b: Float, p: Float) = a + (b - a) * p

private fun mixLimb(a: Limb, b: Limb, p: Float) = Limb(a.ik, lerp(a.a, b.a, p), lerp(a.b, b.b, p), lerp(a.f, b.f, p), a.dir)

/** [pArm] terpisah dari [p] supaya lengan bisa menyusul badan dengan jeda kecil (gerak sekunder). */
private fun mixPose(a: Pose, b: Pose, p: Float, pArm: Float) = Pose(
    lerp(a.hx, b.hx, p), lerp(a.hy, b.hy, p), lerp(a.t, b.t, p),
    mixLimb(a.arm, b.arm, pArm), mixLimb(a.leg1, b.leg1, p), mixLimb(a.leg2, b.leg2, p),
)

// ---------- gambar ----------

private fun DrawScope.cap(a: Offset, b: Offset, r1: Float, r2: Float, c: Color) {
    val dx = b.x - a.x
    val dy = b.y - a.y
    val l = max(hypot(dx, dy), 0.001f)
    val nx = -dy / l
    val ny = dx / l
    val path = Path().apply {
        moveTo(a.x + nx * r1, a.y + ny * r1)
        lineTo(b.x + nx * r2, b.y + ny * r2)
        lineTo(b.x - nx * r2, b.y - ny * r2)
        lineTo(a.x - nx * r1, a.y - ny * r1)
        close()
    }
    drawPath(path, c)
    drawCircle(c, r1, a)
    drawCircle(c, r2, b)
}

/** Selisih waktu lengan terhadap badan (ms); memberi kesan lengan menyusul, bukan bergerak serempak. */
private const val ARM_LAG_MS = 260L

/**
 * Manekin ramping bergerak mengikuti waktu sesi.
 * @param timeMs waktu sejak set mulai (ms); dibaca di fase gambar sehingga hanya kanvas yang digambar ulang.
 * @param tempoMs lama satu repetisi; @param leadMs jeda persiapan di awal (figur diam di pose awal).
 */
@Composable
internal fun StrengthGuide(move: GuideMove, timeMs: () -> Long, tempoMs: Int, leadMs: Long, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val body = cs.onSurface
    val far = cs.onSurface.copy(alpha = 0.32f).compositeOver(cs.surface)
    val arm = cs.primary
    val prop = cs.outline.copy(alpha = 0.35f)
    val floor = cs.outline
    val weight = cs.tertiary
    val band = cs.secondary
    val def = GUIDES[move] ?: GUIDES.getValue(GuideMove.GENERIC)
    Canvas(modifier) {
        val s = min(size.width, size.height) / 110f
        val ox = (size.width - 110f * s) / 2f + 5f * s
        val oy = (size.height - 110f * s) / 2f + 14f * s
        fun w(o: Offset) = Offset(ox + o.x * s, oy + o.y * s)
        fun wx(x: Float, y: Float) = w(Offset(x, y))

        val t = timeMs() - leadMs
        val p = GuideMotion.phase(t, tempoMs).coerceIn(0f, 1f)
        val pArm = GuideMotion.phase(t - ARM_LAG_MS, tempoMs).coerceIn(0f, 1f)
        val sec = max(0L, t) / 1000f
        // getar halus dan napas, hanya saat bergerak, supaya tidak terkesan mesin
        val tremor = (sin(sec * 9f) * 0.35f + sin(sec * 5.3f) * 0.25f) * p
        val breath = 1f + 0.04f * sin(sec * 2.2f)
        val base = mixPose(def.a, def.b, p, pArm)
        val k = solve(Pose(base.hx + tremor * 0.3f, base.hy + tremor * 0.2f, base.t, base.arm, base.leg1, base.leg2))

        // lantai dan bayangan yang melebar saat badan turun
        drawLine(floor, wx(-5f, 92f), wx(105f, 92f), strokeWidth = 1.5f * s, cap = StrokeCap.Round)
        drawOval(
            floor.copy(alpha = 0.28f),
            topLeft = wx(k.hip.x - (14f + 6f * p), 92f - 2.5f),
            size = Size((28f + 12f * p) * s, 5f * s),
        )
        def.props.forEach { pr ->
            when (pr) {
                is Prop.Rect -> drawRect(prop, topLeft = wx(pr.x1, pr.y1), size = Size((pr.x2 - pr.x1) * s, (pr.y2 - pr.y1) * s))
                is Prop.Wall -> drawLine(prop, wx(pr.x, -14f), wx(pr.x, 92f), strokeWidth = 2f * s)
                else -> {}
            }
        }
        val mid = Offset((k.hip.x + k.neck.x) / 2f, (k.hip.y + k.neck.y) / 2f)
        // kaki jauh, kaki dekat, badan, kepala, lengan
        cap(w(k.hip), w(k.knee2), 4.6f * s, 3.2f * s, far)
        cap(w(k.knee2), w(k.ankle2), 3.2f * s, 2f * s, far)
        cap(w(k.ankle2), w(k.toe2), 2f * s, 1.5f * s, far)
        cap(w(k.hip), w(k.knee), 5f * s, 3.4f * s, body)
        cap(w(k.knee), w(k.ankle), 3.4f * s, 2.1f * s, body)
        cap(w(k.ankle), w(k.toe), 2.1f * s, 1.6f * s, body)
        cap(w(k.hip), w(mid), 4.8f * s, 4.2f * s, body)
        cap(w(mid), w(k.neck), 4.2f * s * breath, 3.4f * s, body)
        cap(w(k.neck), w(k.head), 1.8f * s, 1.8f * s, body)
        drawCircle(body, 4.8f * s, w(k.head))
        cap(w(k.neck), w(k.elbow), 2.9f * s, 2.2f * s, arm)
        cap(w(k.elbow), w(k.hand), 2.2f * s, 1.8f * s, arm)
        // alat yang menempel pada figur
        def.props.forEach { pr ->
            when (pr) {
                is Prop.WeightHand -> drawCircle(weight, 3.8f * s, w(k.hand))
                is Prop.WeightHip -> drawCircle(weight, 4f * s, wx(k.hip.x, k.hip.y - 4f))
                is Prop.BandHand -> drawLine(band, wx(pr.ax, pr.ay), w(k.hand), strokeWidth = 1.4f * s)
                is Prop.BandFoot -> drawLine(band, wx(pr.ax, pr.ay), w(k.toe), strokeWidth = 1.4f * s)
                is Prop.BandKnees -> drawLine(band, w(k.knee), w(k.knee2), strokeWidth = 2f * s)
                is Prop.Cable -> {
                    drawLine(band, wx(k.hand.x, -14f), w(k.hand), strokeWidth = 1.2f * s)
                    drawLine(weight, wx(k.hand.x - 6f, k.hand.y), wx(k.hand.x + 6f, k.hand.y), strokeWidth = 2.4f * s, cap = StrokeCap.Round)
                }
                else -> {}
            }
        }
    }
}
