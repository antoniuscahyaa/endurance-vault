package com.endurancevault.app.domain

import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.data.DailyEntity
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters

/**
 * Data tambahan untuk stiker baru (vs PR, vs rute serupa, training load, hitung mundur lomba, tahun, streak).
 * Semuanya murni (tanpa Android) dan dihitung di luar thread UI lewat [StickerExtrasCalc.build].
 */

/** Perbandingan satu jarak dengan PR: [label] jarak ("5K"), [todayMin] dan [prMin] dalam menit, [isPr] bila sesi ini pemegang PR. */
class PrCompare(val label: String, val distanceKm: Double, val todayMin: Double, val prMin: Double, val prDate: String, val isPr: Boolean)

/** Satu lari di rute yang sama; [current] = sesi yang dibuka. */
class RoutePace(val date: LocalDate, val pace: Double, val current: Boolean)

/** Pace sesi ini terhadap lari lain di rute serupa. [deltaMin] = pace sesi ini dikurangi rata-rata lari lain (menit/km, negatif = lebih cepat). */
class RouteCompare(val points: List<RoutePace>, val deltaMin: Double, val avgOthers: Double)

/** Beban latihan: [ratio] = beban 7 hari / kebiasaan, [weekLoads] = delapan pekan (terlama dulu, pekan sesi di akhir). */
class LoadSnap(val ratio: Double, val status: String, val weekLoads: List<Double>)

/** Lomba target: [name], [date], [km]. */
class RaceSnap(val name: String, val date: LocalDate, val km: Double)

/** Ringkasan tahun berjalan sampai tanggal sesi. [cells] = km per hari dari 1 Januari (hari sesudah sesi = -1); [offset] = kolom Senin..Minggu hari pertama. */
class YearStats(val year: Int, val km: Double, val gain: Int, val activeDays: Int, val sessions: Int, val cells: List<Double>, val offset: Int)

/** Streak lari. [last7] = tujuh hari berakhir di tanggal sesi: (huruf hari, ada lari). */
class StreakStats(val days: Int, val weeks: Int, val bestDays: Int, val last7: List<Pair<String, Boolean>>)

class StickerExtras(
    val prs: List<PersonalBest> = emptyList(),
    val sameRoute: RouteCompare? = null,
    val load: LoadSnap? = null,
    val race: RaceSnap? = null,
    val year: YearStats? = null,
    val streak: StreakStats? = null,
)

object StickerExtrasCalc {
    /** Jarak patokan PR; sama dengan [ProgressAnalytics.personalBests]: label, jumlah km penuh, jarak. */
    private val PR_DEFS = listOf(Triple("1 km", 1, 1.0), Triple("5K", 5, 5.0), Triple("10K", 10, 10.0), Triple("Half marathon", 21, 21.0975))
    private val DAY_LETTER = listOf("S", "S", "R", "K", "J", "S", "M")

    /** Waktu tercepat (menit) untuk [count] km penuh berturut-turut, atau null bila sesi tidak cukup panjang atau split tidak wajar. */
    fun windowBest(d: ActDetail, count: Int, distance: Double): Double? {
        if (d.bike || d.km < distance - .005) return null
        val full = d.splits.takeWhile { !it.partial }
        if (full.size < count) return null
        var best: Double? = null
        for (start in 0..(full.size - count)) {
            val sel = full.subList(start, start + count)
            if (sel.any { it.pace !in 2.0..20.0 }) continue
            var minutes = sel.sumOf { it.pace }
            if (distance > count) {
                val next = full.getOrNull(start + count)?.pace?.takeIf { it in 2.0..20.0 } ?: (minutes / count)
                minutes += (distance - count) * next
            }
            if (best == null || minutes < best) best = minutes
        }
        return best
    }

    /** Best effort satu sesi untuk 1, 5, dan 10 km: label dan menit. */
    fun bestEfforts(d: ActDetail): List<Pair<String, Double>> =
        listOf("1 km" to 1, "5 km" to 5, "10 km" to 10).mapNotNull { (lab, n) -> windowBest(d, n, n.toDouble())?.let { lab to it } }

    /** Jarak terpanjang yang punya PR dan best effort sesi ini; null bila tidak ada. */
    fun prCompare(d: ActDetail, prs: List<PersonalBest>, activityId: Long): PrCompare? {
        for ((label, count, dist) in PR_DEFS.reversed()) {
            val pr = prs.firstOrNull { it.label == label } ?: continue
            val today = windowBest(d, count, dist) ?: continue
            return PrCompare(label, dist, today, pr.durationMinutes, pr.dateIso, pr.activityId == activityId || today <= pr.durationMinutes + 1e-9)
        }
        return null
    }

    /** Sesi ini dibanding lari lain di rute serupa (sampai tanggal sesi, paling banyak enam lari); null bila kurang dari dua lari. */
    fun sameRoute(e: ActivityEntity, acts: List<ActivityEntity>, details: Map<Long, ActDetail>): RouteCompare? {
        val byId = acts.associateBy { it.id }
        val cands = acts.filter { it.type != "bike" && it.km > 0 && it.durationSec > 0 }.mapNotNull { a ->
            val r = details[a.id]?.route ?: return@mapNotNull null
            if (r.size < 8) null else RouteActivity(a.id, a.dateIso, a.km, r)
        }
        val group = ProgressAnalytics.similarRoutes(cands).firstOrNull { g -> g.members.any { it.id == e.id } } ?: return null
        val upTo = group.members.filter { it.dateIso.take(10) <= e.dateIso.take(10) }.sortedWith(compareBy({ it.dateIso }, { it.id })).takeLast(6)
        val pts = upTo.mapNotNull { m ->
            val a = byId[m.id] ?: return@mapNotNull null
            val d = runCatching { LocalDate.parse(a.dateIso.take(10)) }.getOrNull() ?: return@mapNotNull null
            RoutePace(d, a.durationSec / 60.0 / a.km, a.id == e.id)
        }
        val cur = pts.firstOrNull { it.current } ?: return null
        val others = pts.filter { !it.current }
        if (others.isEmpty()) return null
        val avg = others.map { it.pace }.average()
        return RouteCompare(pts, cur.pace - avg, avg)
    }

    private fun runDates(acts: List<ActivityEntity>): Set<LocalDate> =
        acts.filter { it.type != "bike" && it.km > 0 }.mapNotNull { runCatching { LocalDate.parse(it.dateIso.take(10)) }.getOrNull() }.toSet()

    /** Tahun dari [date] sampai [date]; null bila belum ada lari di tahun itu. */
    fun year(acts: List<ActivityEntity>, date: LocalDate): YearStats? {
        val start = LocalDate.of(date.year, 1, 1)
        val n = start.lengthOfYear()
        val cells = DoubleArray(n) { if (start.plusDays(it.toLong()).isAfter(date)) -1.0 else 0.0 }
        var km = 0.0; var gain = 0; var sessions = 0
        acts.forEach { a ->
            if (a.type == "bike" || a.km <= 0.0) return@forEach
            val d = runCatching { LocalDate.parse(a.dateIso.take(10)) }.getOrNull() ?: return@forEach
            if (d.isBefore(start) || d.isAfter(date)) return@forEach
            cells[(d.toEpochDay() - start.toEpochDay()).toInt()] += a.km
            km += a.km; gain += a.gain ?: 0; sessions++
        }
        if (sessions == 0) return null
        return YearStats(date.year, km, gain, cells.count { it > 0 }, sessions, cells.toList(), start.dayOfWeek.value - 1)
    }

    /** Streak berakhir di [date]; hari dan pekan berturut-turut, plus rekor hari beruntun sampai [date]. */
    fun streak(acts: List<ActivityEntity>, date: LocalDate): StreakStats? {
        val dates = runDates(acts).filter { !it.isAfter(date) }.toSet()
        if (dates.isEmpty()) return null
        var days = 0; var c = date
        while (c in dates) { days++; c = c.minusDays(1) }
        val mondays = dates.map { it.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)) }.toSet()
        var weeks = 0; var w = date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        while (w in mondays) { weeks++; w = w.minusWeeks(1) }
        var best = 0; var run = 0; var prev: LocalDate? = null
        dates.sorted().forEach { d ->
            run = if (prev != null && prev!!.plusDays(1) == d) run + 1 else 1
            if (run > best) best = run
            prev = d
        }
        val last7 = (6 downTo 0).map { k -> val d = date.minusDays(k.toLong()); DAY_LETTER[d.dayOfWeek.value - 1] to (d in dates) }
        return StreakStats(days, weeks, best, last7)
    }

    /** Beban 7 hari terhadap kebiasaan dan delapan pekan terakhir (Senin sampai Minggu, pekan sesi di akhir). */
    fun load(settings: PlanSettings, acts: List<ActivityEntity>, daily: List<DailyEntity>, plan: PlanOutcome, date: LocalDate, hist: Map<Long, Map<Int, Double>>): LoadSnap? {
        val r = TrainingMetrics.calculate(settings, acts, daily, plan, date, hrHistByActivity = hist)
        if (r.status == "Data belum cukup") return null
        val thisMonday = date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val weeks = (7 downTo 0).map { k ->
            val s = thisMonday.minusWeeks(k.toLong()); val e = s.plusDays(6)
            r.days.filter { !it.date.isBefore(s) && !it.date.isAfter(e) && !it.date.isAfter(date) }.sumOf { it.load }
        }
        return LoadSnap(r.ratio, r.status, weeks)
    }

    fun race(settings: PlanSettings): RaceSnap? {
        val d = settings.race ?: return null
        val km = raceKmOf(settings)
        return RaceSnap(settings.name.ifBlank { rcOf(settings).nm }, d, km)
    }

    /** Perbandingan rute serupa saja (bagian paling berat), supaya bisa dihitung terpisah dari data tambahan lain. */
    fun routeOf(e: ActivityEntity, acts: List<ActivityEntity>, details: Map<Long, ActDetail>): RouteCompare? =
        runCatching { sameRoute(e, acts, details) }.getOrNull()

    /** Semua data tambahan untuk sesi [e]. [details] harus memuat detail sesi ini bila ada. Tiap bagian gagal sendiri-sendiri. */
    fun build(
        e: ActivityEntity, acts: List<ActivityEntity>, details: Map<Long, ActDetail>, settings: PlanSettings,
        daily: List<DailyEntity>, plan: PlanOutcome, hist: Map<Long, Map<Int, Double>>,
        withRoute: Boolean = true,
    ): StickerExtras {
        val date = runCatching { LocalDate.parse(e.dateIso.take(10)) }.getOrNull() ?: return StickerExtras()
        return StickerExtras(
            prs = runCatching { ProgressAnalytics.personalBests(details) }.getOrDefault(emptyList()),
            sameRoute = if (withRoute) runCatching { sameRoute(e, acts, details) }.getOrNull() else null,
            load = runCatching { load(settings, acts, daily, plan, date, hist) }.getOrNull(),
            race = runCatching { race(settings) }.getOrNull(),
            year = runCatching { year(acts, date) }.getOrNull(),
            streak = runCatching { streak(acts, date) }.getOrNull(),
        )
    }
}
