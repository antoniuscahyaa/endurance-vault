package com.endurancevault.app.domain

import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Video segmen 3D: rute dibagi menjadi beberapa segmen berwarna (mis. antar pos bantuan/WS), tiap segmen punya kartu
 * (nama, jarak, naik/turun, gradien rata-rata), dan grafik elevasi menandai batas segmennya. File ini murni Kotlin
 * (tanpa Android) supaya bisa dites JUnit biasa; penggambaran ada di `ui/video/RouteVideoOverlay`.
 */

/** Satu segmen rute. Jarak dalam meter dari awal jejak; [index] mulai dari 0. */
class VideoSegment(
    val index: Int,
    /** Judul untuk kartu, mis. "2. Dingklik → Kecciri" atau "Segmen 2". */
    val title: String,
    val startM: Double, val endM: Double,
    val gain: Int, val loss: Int,
    /** Gradien rata-rata (%) dari elevasi awal ke akhir; null bila tidak ada data elevasi. */
    val avgGrade: Double?,
    val color: Int,
) {
    val lengthM: Double get() = endM - startM
}

object SegmentVideoPlan {
    /** Warna segmen berurutan (oranye, kuning, hijau, biru, ungu, merah muda), berulang bila segmen lebih dari enam. */
    val PALETTE: IntArray = intArrayOf(
        0xFFFF5A36.toInt(), 0xFFFFB020.toInt(), 0xFF2ED8A0.toInt(),
        0xFF2F9BFF.toInt(), 0xFFA66BFF.toInt(), 0xFFFF6FB5.toInt(),
    )

    /** Awalan label batas antar segmen di grafik dan di peta (WS1, WS2, ...). */
    const val BOUNDARY_PREFIX = "WS"

    private const val MIN_SEG_M = 50.0

    private fun fmt(v: Double, dp: Int): String = String.format(Locale.US, "%.${dp}f", v).replace('.', ',')

    fun colorOf(index: Int): Int = PALETTE[index.mod(PALETTE.size)]

    fun boundaryLabel(k: Int): String = "$BOUNDARY_PREFIX$k"

    /**
     * Bangun daftar segmen dari segmen buatan pengguna ([segs], `k` = jarak kumulatif akhir dalam km). Bila pengguna belum
     * membuat minimal dua segmen yang masuk akal, jejak dibagi rata otomatis ([autoSplit]).
     */
    fun build(track: RouteVideoTrack, segs: List<Segment>): List<VideoSegment> {
        val total = track.totalM
        if (total < 200.0) return emptyList()
        val ends = ArrayList<Double>()
        val src = ArrayList<Segment?>()
        var cursor = 0.0
        for (s in segs) {
            val end = if (s.k > 0.0) s.k * 1000.0 else cursor + s.d * 1000.0
            val e = min(end, total)
            if (e - cursor < MIN_SEG_M) continue
            ends.add(e); src.add(s); cursor = e
            if (cursor >= total - MIN_SEG_M) break
        }
        if (ends.size < 2) return autoSplit(track)
        // Sisa jejak di ujung: kecil (< 3%) menyatu ke segmen terakhir, besar menjadi segmen tambahan.
        if (total - cursor > MIN_SEG_M && total - cursor >= total * 0.03) { ends.add(total); src.add(null) }
        else ends[ends.lastIndex] = total

        var start = 0.0
        return ends.mapIndexed { i, end ->
            val s = src[i]
            val label = s?.let { SegKind.displayLabel(it.label, it.type) }
            val title = if (label != null) "${i + 1}. $label" else "Segmen ${i + 1}"
            val (g, l) = if (s != null) s.gain to s.loss else climb(track, start, end)
            val seg = VideoSegment(i, title, start, end, g, l, gradeOf(track, start, end), colorOf(i))
            start = end
            seg
        }
    }

    /** Bagi jejak menjadi 3 sampai 5 segmen sama panjang (sekitar satu segmen per 8 km). */
    fun autoSplit(track: RouteVideoTrack): List<VideoSegment> {
        val total = track.totalM
        if (total < 200.0) return emptyList()
        val count = (total / 1000.0 / 8.0).roundToInt().coerceIn(3, 5)
        return List(count) { i ->
            val a = total * i / count; val b = total * (i + 1) / count
            val (g, l) = climb(track, a, b)
            VideoSegment(i, "Segmen ${i + 1}", a, b, g, l, gradeOf(track, a, b), colorOf(i))
        }
    }

    private fun climb(t: RouteVideoTrack, a: Double, b: Double): Pair<Int, Int> {
        if (!t.hasEle) return 0 to 0
        val i0 = t.indexAtDist(a); val i1 = t.indexAtDist(b)
        var up = 0.0; var down = 0.0
        for (i in i0 + 1..i1) {
            val x = t.eleS[i - 1]; val y = t.eleS[i]
            if (x.isFinite() && y.isFinite()) { if (y > x) up += y - x else down += x - y }
        }
        return up.roundToInt() to down.roundToInt()
    }

    private fun gradeOf(t: RouteVideoTrack, a: Double, b: Double): Double? {
        if (!t.hasEle || b - a < MIN_SEG_M) return null
        val ea = t.eleS[t.indexAtDist(a)]; val eb = t.eleS[t.indexAtDist(b)]
        return if (ea.isFinite() && eb.isFinite()) (eb - ea) / (b - a) * 100.0 else null
    }

    /** Segmen yang memuat jarak [distM] (di luar rentang: segmen pertama atau terakhir). */
    fun segmentAt(segs: List<VideoSegment>, distM: Double): VideoSegment? =
        segs.lastOrNull { it.startM <= distM } ?: segs.firstOrNull()

    fun colorAt(segs: List<VideoSegment>, distM: Double): Int = segmentAt(segs, distM)?.color ?: PALETTE[0]

    /** "10,9 km" / "0,0–10,9 km" untuk kartu. */
    fun rangeText(s: VideoSegment): String = "${fmt(s.startM / 1000.0, 1)}–${fmt(s.endM / 1000.0, 1)} km"

    /** "+611 m / −358 m · 2,3%" untuk kartu. */
    fun climbText(s: VideoSegment): String = buildString {
        append("+${s.gain} m / −${s.loss} m")
        s.avgGrade?.let { append(" · ").append(fmt(it, 1)).append('%') }
    }

    /** Teks jarak batas ke-[k] (1..n-1): jarak awal segmen berikutnya dalam km, mis. "10,9 km". */
    fun boundaryKm(segs: List<VideoSegment>, k: Int): String =
        segs.getOrNull(k)?.let { "${fmt(it.startM / 1000.0, 1)} km" } ?: ""
}

/**
 * Pengaturan bawaan video segmen 3D: garis berwarna menurut segmen, kamera mengikuti pelari, data jarak, elevasi,
 * gradien, dan total naik, serta grafik elevasi bertanda batas segmen. Pengaturan lain (rasio, kualitas, judul) tidak diubah.
 */
fun RouteVideoPrefs.withSegmentPreset(): RouteVideoPrefs = copy(
    lineMode = "segmen",
    cameraMode = "chase",
    live = true,
    durationSec = max(durationSec, 30),
    lineWidth = max(lineWidth, 130),
    kmMarkers = false, flagEnds = true, flagPeak = false, flagSteep = false, flagFast = false, flagHrMax = false,
    layout = layout.copy(
        stats = listOf("jarak", "elev", "grad", "gain"),
        showChart = true, chartKind = "profil", legend = false,
    ),
).sanitized()
