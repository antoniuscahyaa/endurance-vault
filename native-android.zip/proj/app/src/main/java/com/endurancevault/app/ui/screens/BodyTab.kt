package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.i18n.Text
import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.Bedtime
import androidx.compose.material.icons.outlined.Equalizer
import androidx.compose.material.icons.outlined.FitnessCenter
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.endurancevault.app.data.DailyEntity
import com.endurancevault.app.domain.Js
import com.endurancevault.app.domain.LiveLaunch
import com.endurancevault.app.domain.LiveResult
import com.endurancevault.app.domain.StrengthLive
import com.endurancevault.app.domain.StrengthSuggestion
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.TrainingMetrics
import com.endurancevault.app.ui.StrengthWorkoutRecord
import com.endurancevault.app.ui.UiState
import org.json.JSONObject
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.TextStyle as JTextStyle
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Tab Body, sistem kartu yang sama dengan Rekap dan Fitness. Tiga kartu selebar layar:
 * Sleep and condition (terbuka secara bawaan), Strength progress, Strength balance.
 *
 * Sleep and condition mengikuti tampilan aplikasi lama: batang utang tidur 7 hari (Mon-Sun, tidur efektif = malam + tidur siang
 * maks. 3 jam, sama dengan dasar kartu readiness), kebutuhan tidur yang bisa diubah, rincian tidur hari terakhir (malam dan tiap
 * tidur siang), riwayat 7 hari yang bisa dibuka, lalu baris metrik dengan sparkline 7 hari.
 * Kebutuhan tidur disimpan di `readiness_settings` / `sleep_need_hours`, kunci yang sama dengan dialog Readiness.
 */
@Composable
internal fun BodyTab(state: UiState, onStrengthSaved: (LiveResult) -> Unit = {}) {
    val today = LocalDate.now()
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("readiness_settings", Context.MODE_PRIVATE) }
    var need by remember {
        mutableStateOf(((prefs.getFloat("sleep_need_hours", 7.5f).toDouble().coerceIn(5.0, 10.0)) * 10).roundToInt() / 10.0)
    }
    val days = remember(state.daily) { state.daily.sortedBy { it.dateIso }.map { bdParse(it) } }
    val win = remember(days, today) {
        val by = days.associateBy { it.date }
        (6 downTo 0).map { by[today.minusDays(it.toLong()).toString()] }
    }
    val sw = remember(state.strengthWorkouts) { state.strengthWorkouts.filter { !it.deleted }.sortedBy { it.dateIso } }
    val plannedDays = remember(state.plan) {
        (state.plan as? PlanOutcome.Ok)?.weeks.orEmpty().flatMap { it.days }.count { it.str != null || it.ank != null || it.up != null }
    }

    var oSl by rememberSaveable { mutableStateOf(true) }
    var oSt by rememberSaveable { mutableStateOf(false) }
    var oBal by rememberSaveable { mutableStateOf(false) }
    var oHist by rememberSaveable { mutableStateOf(false) }
    val onNeed: (Double) -> Unit = { v ->
        need = v
        prefs.edit().putFloat("sleep_need_hours", v.toFloat()).apply()
    }

    BdSleep(days, win, today, need, onNeed, oSl, { oSl = !oSl }, oHist, { oHist = !oHist }, Modifier.fillMaxWidth())
    // Sesi live: rekomendasi dari rencana (7 hari, belum selesai) dan sesi bebas. Selesai = centang manual atau tertaut sesi jam.
    val doneKeys = remember(state.done, state.strengthWorkouts) { state.done + state.strengthWorkouts.mapNotNull { it.linkedKey } }
    val suggestions = remember(state.plan, doneKeys, today) { StrengthLive.suggest(state.plan, doneKeys, today) }
    val freeOptions = remember(state.plan, today) { StrengthLive.freeOptions(state.plan, today) }
    var live by remember { mutableStateOf<LiveLaunch?>(null) }

    BdStrength(sw, plannedDays, today, suggestions, freeOptions, { live = it }, oSt, { oSt = !oSt }, Modifier.fillMaxWidth())
    BdBalance(sw, today, oBal, { oBal = !oBal }, Modifier.fillMaxWidth())

    live?.let { l ->
        StrengthLiveSession(
            launch = l,
            onSave = { r -> onStrengthSaved(r); live = null },
            onClose = { live = null },
        )
    }
}

// ===================== data harian =====================

private class BdNap(val a: String, val b: String, val m: Int)

/** Satu baris harian yang sudah diurai dari DailyEntity dan JSON `raw`-nya. */
private class BdDay(
    val date: String,
    val rhr: Int?, val hrv: Int?, val sleepH: Double?, val leg: Int?, val mood: Int?,
    val effH: Double?, val sleepHr: Double?, val spo2: Double?, val resp: Double?, val napMin: Int?,
    val bed: String?, val wake: String?, val deep: Int?, val rem: Int?, val light: Int?, val latency: Int?,
    val naps: List<BdNap>, val syncedAt: Long?,
) {
    val has: Boolean
        get() = sleepH != null || rhr != null || hrv != null || leg != null || mood != null || napMin != null || sleepHr != null
}

private fun bdParse(d: DailyEntity): BdDay {
    val raw = runCatching { JSONObject(d.raw) }.getOrDefault(JSONObject())
    val watch = raw.optJSONObject("watch") ?: JSONObject()
    fun pos(o: JSONObject, k: String): Double? = o.optDouble(k, Double.NaN).takeIf { it.isFinite() && it > 0 }
    fun posInt(k: String): Int? = raw.optInt(k, 0).takeIf { it > 0 }
    val naps = raw.optJSONArray("naps")?.let { arr ->
        (0 until arr.length()).mapNotNull { i ->
            arr.optJSONObject(i)?.let { o ->
                o.optInt("m", 0).takeIf { it > 0 }?.let { m -> BdNap(o.optString("a"), o.optString("b"), m) }
            }
        }
    }.orEmpty()
    val napMin = naps.sumOf { it.m }.takeIf { it > 0 } ?: pos(raw, "nap")?.roundToInt()
    return BdDay(
        date = d.dateIso.take(10),
        rhr = d.rhr, hrv = d.hrv, sleepH = d.sleepH, leg = d.leg, mood = d.mood,
        effH = TrainingMetrics.effectiveSleepHours(d),
        sleepHr = pos(raw, "shr") ?: pos(watch, "sleepHr"),
        spo2 = pos(raw, "ssp") ?: pos(watch, "sleepSpo2"),
        resp = pos(raw, "srr") ?: pos(watch, "sleepResp"),
        napMin = napMin,
        bed = raw.optString("bed").takeIf { it.isNotBlank() },
        wake = raw.optString("wake").takeIf { it.isNotBlank() },
        deep = posInt("deep"), rem = posInt("rem"), light = posInt("light"), latency = posInt("lat"),
        naps = naps,
        syncedAt = watch.optLong("syncedAt", 0L).takeIf { it > 0L },
    )
}

// ===================== helper kecil =====================

private val BD_LOC: Locale = Locale.ENGLISH
private val BD_HRV = Color(0xFFF2600A)
private val BD_C_RHR = Color(0xFF6B7585)
private val BD_C_SHR = Color(0xFF3A4150)
private val BD_C_SPO2 = Color(0xFF3B9AD9)
private val BD_C_RESP = Color(0xFF1AA69B)
private val BD_C_DUR = Color(0xFF9AA0A8)
private val BD_C_NAP = Color(0xFFC4500E)
private val BD_BAR_DEBT = Color(0xFFD8410C)
private val BD_BAR_OK = Color(0xFFC25009)
private val BD_ST_DEEP = Color(0xFF4A505C)
private val BD_ST_REM = Color(0xFF7F8696)
private val BD_ST_LIGHT = Color(0xFFA3AAB8)

/** Angka satu desimal tanpa ",0" di belakang: 7.0 -> "7", 6.7 -> "6.7". */
private fun bdNum(x: Double): String {
    val r = (x * 10).roundToInt() / 10.0
    return if (r == Math.floor(r)) r.toInt().toString() else r.toString()
}
private fun bdF1(x: Double): String = String.format(Locale.US, "%.1f", x)
private fun bdDate(d: LocalDate): String = "${d.dayOfMonth} ${d.month.getDisplayName(JTextStyle.SHORT, BD_LOC)}"
private fun bdDateIso(iso: String): String = runCatching { bdDate(LocalDate.parse(iso.take(10))) }.getOrDefault(iso)
private fun bdHm(min: Int): String = "${min / 60}h ${(min % 60).toString().padStart(2, '0')}m"
private fun bdIn(dateIso: String, from: LocalDate, to: LocalDate): Boolean =
    runCatching { LocalDate.parse(dateIso) }.getOrNull()?.let { !it.isBefore(from) && !it.isAfter(to) } == true

private fun bdClock(ms: Long): String {
    val t = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault())
    return String.format(Locale.US, "%02d:%02d", t.hour, t.minute)
}

private fun bdAgo(ms: Long): String {
    val min = ((System.currentTimeMillis() - ms) / 60_000L).coerceAtLeast(0L)
    return when {
        min < 2L -> "just now"
        min < 60L -> "$min min ago"
        min < 1440L -> "${min / 60L} h ago"
        else -> "${min / 1440L} d ago"
    }
}

@Composable
private fun BdStat(modifier: Modifier, label: String, value: String, sub: String?) {
    val cs = MaterialTheme.colorScheme
    Column(modifier, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label.uppercase(Locale.ROOT), style = monoStyle(9f, .4f), color = cs.onSurfaceVariant, maxLines = 1)
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1)
        if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1)
    }
}

/** Batang mini per pekan (8 pekan), pekan terakhir beraksen. */
@Composable
private fun BdBars(values: List<Int>, height: Int = 34) {
    val acc = MaterialTheme.colorScheme.primary
    val dim = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = .35f)
    Canvas(Modifier.fillMaxWidth().height(height.dp)) {
        val mx = values.maxOrNull() ?: 0
        if (mx <= 0 || values.isEmpty()) return@Canvas
        val gap = 4.dp.toPx(); val bw = (size.width - gap * (values.size - 1)) / values.size
        values.forEachIndexed { i, v ->
            val h = if (v > 0) max(size.height * .08f, v.toFloat() / mx * size.height) else 3.dp.toPx()
            drawRoundRect(if (i == values.lastIndex) acc else dim, Offset(i * (bw + gap), size.height - h), Size(bw, h), CornerRadius(3.dp.toPx()))
        }
    }
}

/** Garis kecil 7 hari; hari tanpa data memutus garis (hari terakhir kosong = garis berhenti lebih awal). */
@Composable
private fun BdSpark(series: List<Double?>, color: Color, modifier: Modifier) {
    Canvas(modifier) {
        val vs = series.filterNotNull()
        if (vs.isEmpty() || series.size < 2) return@Canvas
        val lo = vs.minOrNull() ?: 0.0
        val hi = vs.maxOrNull() ?: 1.0
        val padV = 6.dp.toPx(); val h = size.height - 2 * padV
        val stepX = size.width / (series.size - 1)
        val st = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        var path = Path(); var segLen = 0; var lastX = 0f; var lastY = 0f
        fun flush() {
            if (segLen >= 2) drawPath(path, color, style = st)
            else if (segLen == 1) drawCircle(color, 2.5.dp.toPx(), Offset(lastX, lastY))
            path = Path(); segLen = 0
        }
        series.forEachIndexed { i, v ->
            if (v == null) {
                flush()
            } else {
                val t = if (hi - lo < 1e-9) 0.5 else (v - lo) / (hi - lo)
                val x = i * stepX; val y = padV + h * (1f - t.toFloat())
                if (segLen == 0) path.moveTo(x, y) else path.lineTo(x, y)
                segLen++; lastX = x; lastY = y
            }
        }
        flush()
    }
}

private class BdMetric(val label: String, val value: String, val color: Color, val series: List<Double?>)

@Composable
private fun BdMetricRow(m: BdMetric) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(.9f)) {
            Text(m.label, style = MaterialTheme.typography.bodyLarge, color = cs.onSurfaceVariant, maxLines = 1)
            Text(m.value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1)
        }
        BdSpark(m.series, m.color, Modifier.weight(1.1f).height(44.dp))
    }
}

@Composable
private fun BdLine(label: String, value: String, bold: Boolean = true, muted: Boolean = false) {
    val cs = MaterialTheme.colorScheme
    val c = if (muted) cs.onSurfaceVariant else cs.onSurface
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge, color = c)
        Text(value, style = MaterialTheme.typography.bodyLarge, fontWeight = if (bold && !muted) FontWeight.Bold else FontWeight.Normal, color = c)
    }
}

@Composable
private fun BdDivider() = HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, thickness = .8.dp)

// ===================== 1. Sleep and condition =====================

/** Batang utang tidur 7 hari. Di bawah kebutuhan = merah-oranye, memenuhi = oranye tua, belum tercatat = "-". */
@Composable
private fun BdDebt(win: List<BdDay?>, today: LocalDate, need: Double, debt: Double?) {
    val cs = MaterialTheme.colorScheme
    val vals = win.map { it?.effH }
    val top = max(9.0, vals.filterNotNull().maxOrNull() ?: 0.0)
    val dash = cs.onSurfaceVariant.copy(alpha = .55f)
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("7-day sleep debt", Modifier.weight(1f), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Medium)
            Text(if (debt != null) "Debt ${bdNum(debt)} h" else "–", style = MaterialTheme.typography.bodyLarge)
        }
        Canvas(Modifier.fillMaxWidth().height(1.dp)) {
            drawLine(
                dash, Offset(0f, 0f), Offset(size.width, 0f), 1.dp.toPx(),
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(5.dp.toPx(), 4.dp.toPx())),
            )
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            vals.forEachIndexed { i, v ->
                val d = today.minusDays((6 - i).toLong())
                Column(
                    Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(3.dp),
                ) {
                    Text(v?.let { bdNum(it) } ?: "-", style = monoStyle(10.5f, 0f), color = cs.onSurfaceVariant, maxLines = 1)
                    Box(
                        Modifier.fillMaxWidth().height(78.dp).clip(RoundedCornerShape(9.dp)).background(cs.onSurface.copy(alpha = .06f)),
                        contentAlignment = Alignment.BottomCenter,
                    ) {
                        if (v != null && v > 0.0) {
                            Box(
                                Modifier.fillMaxWidth().fillMaxHeight((v / top).toFloat().coerceIn(.04f, 1f))
                                    .clip(RoundedCornerShape(9.dp)).background(if (v < need) BD_BAR_DEBT else BD_BAR_OK),
                            )
                        }
                    }
                    Text(d.dayOfWeek.getDisplayName(JTextStyle.SHORT, BD_LOC), style = monoStyle(10.5f, 0f), color = cs.onSurfaceVariant, maxLines = 1)
                }
            }
        }
    }
}

/** Kolom isian kebutuhan tidur (5 sampai 10 jam); nilai sah langsung disimpan. */
@Composable
private fun BdNeed(need: Double, onNeed: (Double) -> Unit) {
    val cs = MaterialTheme.colorScheme
    var text by rememberSaveable { mutableStateOf(bdNum(need)) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Sleep need (hours per night)", style = MaterialTheme.typography.bodyLarge)
        Box(
            Modifier.width(96.dp).clip(RoundedCornerShape(99.dp)).background(cs.onSurface.copy(alpha = .08f))
                .padding(horizontal = 14.dp, vertical = 8.dp),
        ) {
            BasicTextField(
                value = text,
                onValueChange = { raw ->
                    val t = raw.filter { it.isDigit() || it == '.' || it == ',' }.take(4)
                    text = t
                    t.replace(',', '.').toDoubleOrNull()?.takeIf { it in 5.0..10.0 }?.let(onNeed)
                },
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyLarge.copy(color = cs.onSurface),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                cursorBrush = SolidColor(cs.primary),
            )
        }
        RcInfo(
            "Sleep debt = for each of the last 7 nights, sleep need minus sleep (a surplus counts at most 1 h per night), summed and never below 0. Sleep per night = main night plus naps (naps count at most 3 h). Needs at least 3 logged nights. Allowed range 5 to 10 h; the same setting is used by Readiness on Today.",
        )
    }
}

/** Rincian tidur hari terakhir yang punya data: malam (jam tidur, total, jam bangun, bilah fase), lalu tiap tidur siang. */
@Composable
private fun BdSleepDetail(d: BdDay) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Sleep", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(bdDateIso(d.date), style = MaterialTheme.typography.bodyLarge)
        }
        val night = d.sleepH
        if (night != null) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(d.bed ?: "", Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                Text(bdHm((night * 60).roundToInt()), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(d.wake ?: "", Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.End)
            }
            val deep = d.deep ?: 0; val rem = d.rem ?: 0; val light = d.light ?: 0
            if (deep + rem + light > 0) {
                Row(Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(99.dp))) {
                    if (deep > 0) Box(Modifier.weight(deep.toFloat()).fillMaxHeight().background(BD_ST_DEEP))
                    if (rem > 0) Box(Modifier.weight(rem.toFloat()).fillMaxHeight().background(BD_ST_REM))
                    if (light > 0) Box(Modifier.weight(light.toFloat()).fillMaxHeight().background(BD_ST_LIGHT))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    BdStage("Deep", deep, BD_ST_DEEP)
                    BdStage("REM", rem, BD_ST_REM)
                    BdStage("Light", light, BD_ST_LIGHT)
                }
            }
            d.latency?.let { BdLine("Time to fall asleep", bdHm(it)) }
            d.sleepHr?.let { BdLine("Average sleep HR", "${it.roundToInt()} bpm") }
            if (d.spo2 != null || d.resp != null) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    if (d.spo2 != null) BdInline("Avg SpO₂ ", "${d.spo2.roundToInt()}%") else Box(Modifier)
                    if (d.resp != null) BdInline("Avg respiratory rate ", "${bdNum(d.resp)} br/min")
                }
            }
        }
        d.naps.forEach { BdLine("Nap · ${it.a}–${it.b}", bdHm(it.m)) }
        val napTotal = d.napMin
        if (napTotal != null) {
            BdLine(if (d.naps.isNotEmpty()) "Nap total · ${d.naps.size}×" else "Nap total", bdHm(napTotal))
        }
        if (night == null && napTotal == null) {
            RcMuted("No sleep recorded for this day.")
        }
    }
}

@Composable
private fun BdStage(label: String, min: Int, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(Modifier.size(14.dp).clip(RoundedCornerShape(4.dp)).background(color))
        BdInline("$label ", bdHm(min))
    }
}

/** Label biasa diikuti nilai tebal dalam satu baris teks. */
@Composable
private fun BdInline(label: String, value: String) {
    Row {
        Text(label, style = MaterialTheme.typography.bodyLarge)
        Text(value, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
    }
}

/** "▶ Sleep history, 7 days": ketuk untuk membuka tabel tujuh hari terakhir. */
@Composable
private fun BdHistory(win: List<BdDay?>, open: Boolean, onToggle: () -> Unit) {
    Text(
        (if (open) "▼ " else "▶ ") + "Sleep history, 7 days",
        Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(vertical = 4.dp),
        style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
    )
    if (open) {
        val rows = win.filterNotNull().filter { it.has }.asReversed()
        if (rows.isEmpty()) {
            RcMuted("No daily records in the last 7 days.")
        } else {
            RcInner {
                val w = listOf(1.2f, .9f, .9f, .8f, .8f, .7f, .7f)
                RcTableRow(listOf("Date", "Sleep", "Nap", "RHR", "HRV", "Leg", "Mood"), w, head = true)
                rows.forEach { d ->
                    RcTableRow(
                        listOf(
                            bdDateIso(d.date), d.sleepH?.let { bdNum(it) } ?: "–", d.napMin?.toString() ?: "–",
                            d.rhr?.toString() ?: "–", d.hrv?.toString() ?: "–", d.leg?.toString() ?: "–", d.mood?.toString() ?: "–",
                        ), w,
                    )
                }
            }
        }
        RcInfo("Sleep in hours (main night), Nap in minutes, RHR = resting HR in bpm, HRV in ms. Leg feel: 1 = fresh to 5 = very heavy. Mood/stress: 1 = relaxed to 5 = very stressed.")
    }
}

@Composable
private fun BdSleep(
    days: List<BdDay>, win: List<BdDay?>, today: LocalDate, need: Double, onNeed: (Double) -> Unit,
    open: Boolean, onToggle: () -> Unit, hist: Boolean, onHist: () -> Unit, modifier: Modifier,
) {
    val hasAny = days.any { it.has }
    val latest = days.lastOrNull { it.has }
    val logged = win.mapNotNull { it?.effH }
    val debt = if (logged.size >= 3) TrainingMetrics.sleepDebtOf(logged, need) else null
    val avg = logged.takeIf { it.isNotEmpty() }?.average()
    val syncedAt = days.mapNotNull { it.syncedAt }.maxOrNull()
    fun lastD(sel: (BdDay) -> Double?): Double? = days.asReversed().firstNotNullOfOrNull(sel)

    val rhr = lastD { it.rhr?.toDouble() }
    val hrv = lastD { it.hrv?.toDouble() }
    val sleepLast = lastD { it.sleepH }
    val metrics = listOf(
        BdMetric("Resting HR", rhr?.let { "${it.roundToInt()} bpm" } ?: "–", BD_C_RHR, win.map { it?.rhr?.toDouble() }),
        BdMetric("Sleep HR", lastD { it.sleepHr }?.let { "${it.roundToInt()} bpm" } ?: "–", BD_C_SHR, win.map { it?.sleepHr }),
        BdMetric("HRV", hrv?.let { "${it.roundToInt()} ms" } ?: "–", BD_HRV, win.map { it?.hrv?.toDouble() }),
        BdMetric("Sleep SpO₂", lastD { it.spo2 }?.let { "${it.roundToInt()} %" } ?: "–", BD_C_SPO2, win.map { it?.spo2 }),
        BdMetric("Sleep respiration", lastD { it.resp }?.let { "${bdNum(it)} br/min" } ?: "–", BD_C_RESP, win.map { it?.resp }),
        BdMetric("Sleep duration", sleepLast?.let { "${bdNum(it)} h" } ?: "–", BD_C_DUR, win.map { it?.sleepH }),
        BdMetric(
            "Nap", lastD { it.napMin?.toDouble() }?.let { "${it.roundToInt()} min" } ?: "–", BD_C_NAP,
            win.map { it?.napMin?.toDouble() },
        ),
    )

    RcCard(Icons.Outlined.Bedtime, "SLEEP AND CONDITION", open, onToggle, modifier,
        headText = latest?.let { bdDateIso(it.date) },
        summary = {
            if (!hasAny) {
                RcMuted("No daily data yet. Log your morning condition or sync the watch.")
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    BdStat(Modifier.weight(1f), "Sleep", sleepLast?.let { "${bdNum(it)} h" } ?: "–", avg?.let { "avg ${bdNum(it)} h" })
                    BdStat(Modifier.weight(1f), "Resting HR", rhr?.let { "${it.roundToInt()} bpm" } ?: "–", null)
                    BdStat(Modifier.weight(1f), "HRV", hrv?.let { "${it.roundToInt()} ms" } ?: "–", null)
                }
                RcMono("${debt?.let { "Debt ${bdNum(it)} h" } ?: "Debt –"} · ${logged.size}/7 nights logged")
            }
        },
        body = {
            if (!hasAny) {
                RcMuted("No daily data yet. Log your morning condition or sync the watch.")
            } else {
                BdDebt(win, today, need, debt)
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    if (debt != null) RcMono("Average ${avg?.let { bdNum(it) } ?: "–"} of ${bdNum(need)} h · ${logged.size}/7 nights logged")
                    else RcMono("Needs sleep data for at least 3 of the last 7 nights (${logged.size} so far).")
                    if (syncedAt != null) RcMono("Watch data last applied ${bdClock(syncedAt)} (${bdAgo(syncedAt)})")
                }
                BdNeed(need, onNeed)
                BdDivider()
                if (latest != null) BdSleepDetail(latest)
                BdDivider()
                BdHistory(win, hist, onHist)
                BdDivider()
                Column {
                    metrics.forEachIndexed { i, m ->
                        BdMetricRow(m)
                        if (i < metrics.lastIndex) BdDivider()
                    }
                }
            }
        })
}

// ===================== 2. Strength progress =====================

@Composable
private fun BdStrength(
    sw: List<StrengthWorkoutRecord>, plannedDays: Int, today: LocalDate,
    suggestions: List<StrengthSuggestion>, freeOptions: List<LiveLaunch>, onStart: (LiveLaunch) -> Unit,
    open: Boolean, onToggle: () -> Unit, modifier: Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val total = sw.sumOf { it.minutes }
    val weekMin = remember(sw, today) {
        val monday = today.with(DayOfWeek.MONDAY)
        (7 downTo 0).map { k ->
            val from = monday.minusWeeks(k.toLong()); val to = from.plusDays(6)
            sw.filter { w -> bdIn(w.dateIso, from, to) }.sumOf { it.minutes }
        }
    }
    val last7 = sw.count { bdIn(it.dateIso, today.minusDays(6), today) }
    val prev7 = sw.count { bdIn(it.dateIso, today.minusDays(13), today.minusDays(7)) }
    val pct = if (prev7 > 0) ((last7 - prev7) * 100.0 / prev7).roundToInt() else null
    val pill = when {
        pct == null -> if (last7 > 0) "▲ new" else null
        pct < 0 -> "▼ ${-pct}%"
        pct > 0 -> "▲ $pct%"
        else -> "0%"
    }
    val mx = max(max(last7, prev7), 1)
    RcCard(Icons.Outlined.FitnessCenter, "STRENGTH PROGRESS", open, onToggle, modifier,
        headText = "${sw.size} sessions",
        summary = {
            RcBig("$last7", "sessions · 7 days", pill, neg = (pct ?: 0) < 0)
            RcCompare(listOf((last7 * 100f / mx) to cs.primary, (prev7 * 100f / mx) to cs.onSurfaceVariant.copy(alpha = .35f)), h = 10)
            BdLive(suggestions, freeOptions, today, expanded = false, onStart = onStart)
        },
        body = {
            BdLive(suggestions, freeOptions, today, expanded = true, onStart = onStart)
            if (sw.isEmpty()) {
                RcMuted("No strength workouts from the watch yet.")
            } else {
                RcStats(listOf(
                    "Total" to bdHm(total),
                    "Average" to "${(total.toDouble() / sw.size).roundToInt()} min",
                    "Planned" to "$plannedDays days",
                ))
                BdBars(weekMin, 48)
                RcLegend("8 weeks ago", "this week")
                RcInner {
                    val w = listOf(1.2f, .8f, .8f, .9f, 1.1f)
                    RcTableRow(listOf("Date", "Min", "HR", "Kcal", "Type"), w, head = true)
                    sw.takeLast(20).asReversed().forEach { x ->
                        RcTableRow(listOf(
                            bdDateIso(x.dateIso), "${x.minutes}", x.avgHr?.toString() ?: "–", x.calories?.toString() ?: "–",
                            when { x.free -> "Free"; x.linkedKey != null -> "Linked"; else -> "Imported" },
                        ), w)
                    }
                }
                RcInfo("Sessions this week (last 7 days) are compared with the 7 days before. The watch does not record sets, so progress counts sessions. Strength workouts stay separate from running and do not count toward mileage, PRs, or training load. Type: Free = no plan, Linked = tied to a planned session, Imported = from the watch without a link.")
            }
        })
}

// ===================== Sesi live =====================

private fun bdDayLabel(d: LocalDate, today: LocalDate): String = when (d) {
    today -> "Hari ini"
    today.plusDays(1) -> "Besok"
    else -> bdDate(d)
}

/**
 * Rekomendasi strength berikutnya dari rencana dengan tombol mulai sesi live. Tertutup: satu rekomendasi saja;
 * terbuka: ditambah sesi terjadwal lain dan sesi bebas (Strength A/B, upper, ankle) mengikuti fase saat ini.
 */
@Composable
private fun BdLive(
    suggestions: List<StrengthSuggestion>, freeOptions: List<LiveLaunch>, today: LocalDate,
    expanded: Boolean, onStart: (LiveLaunch) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val top = suggestions.firstOrNull()
    RcInner {
        Text("SESI LIVE", style = monoStyle(9f, .4f), color = cs.onSurfaceVariant)
        if (top != null) {
            Text("Rekomendasi", style = MaterialTheme.typography.labelSmall, color = cs.primary)
            BdLiveRow(
                top.block.title,
                "${bdDayLabel(top.date, today)} · ${top.block.mins} mnt · ${top.block.lines.size} gerakan",
            ) { onStart(LiveLaunch(top.block, top.key, top.block.title)) }
        } else {
            RcMuted("Tidak ada strength terjadwal yang belum selesai dalam 7 hari ke depan.")
            if (!expanded) freeOptions.firstOrNull()?.let { f ->
                BdLiveRow(f.label, "Sesi bebas · ${f.block.mins} mnt") { onStart(f) }
            }
        }
        if (expanded) {
            val others = suggestions.drop(1)
            if (others.isNotEmpty()) {
                Text("Terjadwal lainnya", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
                others.forEach { sg ->
                    BdLiveRow(sg.block.title, "${bdDayLabel(sg.date, today)} · ${sg.block.mins} mnt") {
                        onStart(LiveLaunch(sg.block, sg.key, sg.block.title))
                    }
                }
            }
            Text("Sesi bebas", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
            freeOptions.forEach { f -> BdLiveRow(f.label, "${f.block.mins} mnt · ${f.block.lines.size} gerakan") { onStart(f) } }
            RcInfo("Sesi live memandu tiap set dengan animasi, menghitung repetisi dan waktu tahan, serta mengatur istirahat. Setelah selesai, sesi tersimpan di riwayat strength; sesi dari rencana otomatis ditandai selesai di jadwal.")
        }
    }
}

@Composable
private fun BdLiveRow(title: String, sub: String, onStart: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            Text(sub, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        FilledTonalButton(onClick = onStart, contentPadding = PaddingValues(horizontal = 12.dp)) {
            Icon(Icons.Filled.PlayArrow, contentDescription = null, Modifier.size(18.dp))
            Spacer(Modifier.width(4.dp))
            Text("Mulai live")
        }
    }
}

// ===================== 3. Strength balance =====================

@Composable
private fun BdBalance(sw: List<StrengthWorkoutRecord>, today: LocalDate, open: Boolean, onToggle: () -> Unit, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val total = sw.sumOf { it.minutes }
    val avgHr = sw.mapNotNull { it.avgHr }.takeIf { it.isNotEmpty() }?.average()
    val maxHr = sw.mapNotNull { it.maxHr }.maxOrNull()
    val kcal = sw.mapNotNull { it.calories }.sum()
    val recent = remember(sw, today) {
        val from = today.with(DayOfWeek.MONDAY).minusWeeks(7)
        sw.filter { w -> bdIn(w.dateIso, from, today) }
    }
    val perWeek = recent.size / 8.0
    val minPerWeek = recent.sumOf { it.minutes } / 8.0
    RcCard(Icons.Outlined.Equalizer, "STRENGTH BALANCE", open, onToggle, modifier,
        headText = "${sw.count { it.avgHr != null }} HR records",
        summary = {
            if (sw.isEmpty()) {
                RcMuted("No strength session history from the watch yet.")
            } else {
                RcStats(listOf(
                    "Duration" to bdHm(total),
                    "Avg HR" to (avgHr?.let { "${it.roundToInt()}" } ?: "–"),
                    "Sessions/wk" to bdF1(perWeek),
                ))
            }
        },
        body = {
            if (sw.isEmpty()) {
                RcMuted("No strength session history from the watch yet.")
            } else {
                RcStatGrid(listOf(
                    "Total duration" to bdHm(total), "Sessions/wk" to bdF1(perWeek), "Min/week" to "${minPerWeek.roundToInt()}",
                    "Avg HR" to (avgHr?.let { "${it.roundToInt()}" } ?: "–"), "Max HR" to (maxHr?.toString() ?: "–"),
                    "Calories" to (if (kcal > 0) Js.idn(kcal) else "–"),
                ))
                Text("SESSION TYPE", style = monoStyle(9f, .4f), color = cs.onSurfaceVariant)
                RcInner {
                    val rows = listOf(
                        Triple("Free strength", sw.count { it.free }, cs.primary),
                        Triple("Linked to plan", sw.count { !it.free && it.linkedKey != null }, cs.tertiary),
                        Triple("Watch import", sw.count { !it.free && it.linkedKey == null }, cs.secondary),
                    )
                    rows.forEach { (label, n, c) ->
                        Column(Modifier.padding(vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(Modifier.fillMaxWidth()) {
                                Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                                Text("$n", style = monoStyle(11f, 0f), color = cs.onSurfaceVariant)
                            }
                            RcCompare(listOf((n * 100f / sw.size) to c), h = 6)
                        }
                    }
                }
                RcInfo("Muscle-group distribution cannot be calculated because watch workouts do not store sets, reps, or exercises. Sessions/wk and Min/week use the last 8 weeks.")
            }
        })
}
