package com.endurancevault.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot

/**
 * Splash tahap 2. Tahap 1 (splash sistem Android) hanya warna aksen tanpa ikon
 * (lihat Theme.EnduranceVault.Splash). Di sini: lingkaran gelap muncul di tengah layar, bagian logo
 * masuk bergiliran, lalu huruf V digambar dari kiri sebagai panah yang bergerak (turun ke dasar V,
 * berbelok, naik ke kepala panah). Saat V utuh, kepala panah menyentak sedikit, lalu semuanya memudar.
 *
 * Semua animasi digerakkan satu jam (Animatable t, dalam ms) sehingga urutannya pasti. Jadwal tiap
 * bagian ada di konstanta di bawah; ubah angka-angka itu untuk mempercepat/memperlambat.
 *
 * Logo terkunci di tengah layar, lebar LOGO_WIDTH_FRAC x lebar layar. Koordinat logo dalam satuan
 * SYM_W x SYM_H (860 x 590), diskalakan ke layar.
 *
 * Huruf V digambar dengan mask: jalur tengah V (V_PATH) dijadikan area goresan yang tumbuh bertahap,
 * lalu bentuk V dipotong (irisan) dengan area itu, sehingga hanya V yang tergambar (tanpa latar).
 * Panah kecil di ujung goresan mengikuti arah jalur.
 */
private const val SYM_W = 860f
private const val SYM_H = 590f
private const val LOGO_WIDTH_FRAC = 0.55f

// Jadwal animasi (ms)
private const val CIRCLE_MS = 340f
private const val PIECE_MS = 380f
private const val V_START_MS = 600f
private const val V_DRAW_MS = 750f
private const val KICK_MS = 260f
private const val ANIM_MS = (V_START_MS + V_DRAW_MS + KICK_MS).toInt() // 1610
private const val HOLD_MS = 400L
private const val FADE_MS = 220

private val SplashBg = Color(0xFFEA5F0A)
private val SplashInk = Color(0xFF0B0C0F)

// Lingkaran gelap di belakang logo (satuan logo); sedikit lebih besar dari sudut logo.
private const val CIRCLE_R = 600f

// Jalur tengah huruf V: kiri atas -> dasar V -> kepala panah (satuan logo), dan tebal goresan mask.
private val V_PATH = floatArrayOf(374f, 120f, 545f, 478f, 776f, 72f, 876f, -24f)
private const val V_MASK_W = 175f

// Panah kecil di ujung goresan (menghadap +x, diputar mengikuti jalur) dan jarak sampel arah.
private val LEAD = floatArrayOf(-16f, -72f, -16f, 72f, 104f, 0f)
private const val LEAD_SMOOTH = 40f

// Sentakan kepala panah saat V utuh (satuan logo).
private const val KICK_DX = 40f
private const val KICK_DY = -27f

// Logo: warna sama dengan ikon launcher (res/drawable/ic_launcher_foreground.xml)
private val LG_MTN_RIGHT = floatArrayOf(340f, 455f, 360f, 442f, 411f, 465f, 434f, 438f, 512f, 583f, 415f, 583f)
private val LG_MTN_MID = floatArrayOf(98f, 583f, 146f, 534f, 224f, 579f, 315f, 482f, 378f, 577f)
private val LG_BAR = floatArrayOf(562f, 583f, 655f, 583f, 852f, 245f, 803f, 182f)
private val LG_TRI = floatArrayOf(160f, 431f, 248f, 437f, 210f, 470f)
private val LG_E = floatArrayOf(0f, 18f, 390f, 18f, 443f, 130f, 113f, 130f, 113f, 225f, 310f, 225f, 365f, 332f, 113f, 332f, 113f, 429f, 127f, 435f, 0f, 549f)
private val LG_TREND = floatArrayOf(7f, 583f, 140f, 453f, 218f, 500f, 337f, 372f, 418f, 415f, 402f, 442f, 347f, 420f, 219f, 547f, 143f, 503f, 60f, 583f)
private val LG_V = floatArrayOf(352f, 218f, 472f, 218f, 557f, 362f, 737f, 75f, 710f, 48f, 860f, 0f, 838f, 165f, 795f, 130f, 558f, 528f, 540f, 548f)
private val LgLight = Color(0xFFC9CACD)
private val LgMid = Color(0xFF9A9CA1)
private val LgE = Color(0xFFF5F5F6)
private val LgOrange = Color(0xFFFC6808)

/** Bagian logo yang masuk bergiliran: mulai dari offset (dx, dy) satuan logo, tiba di posisi aslinya. */
private class Piece(
    val pts: FloatArray,
    val color: Color,
    val delayMs: Float,
    val dx: Float,
    val dy: Float,
)

// Urutan gambar = urutan tumpukan (yang terakhir di atas).
private val PIECES = listOf(
    Piece(LG_MTN_MID, LgMid, 110f, 0f, 127f),
    Piece(LG_MTN_RIGHT, LgLight, 190f, 0f, 127f),
    Piece(LG_TRI, LgLight, 260f, 0f, 95f),
    Piece(LG_E, LgE, 230f, -127f, 0f),
    Piece(LG_BAR, LgLight, 340f, -127f, 127f),
    Piece(LG_TREND, LgOrange, 410f, -127f, 95f),
)

private val RiseEase = CubicBezierEasing(0.2f, 0.8f, 0.2f, 1f)
private val PopEase = CubicBezierEasing(0f, 0f, 0.2f, 1f)

private fun frac(t: Float, start: Float, dur: Float): Float = ((t - start) / dur).coerceIn(0f, 1f)

private fun polyPath(p: FloatArray, s: Float, ox: Float, oy: Float, close: Boolean = true): Path {
    val path = Path()
    path.moveTo(ox + p[0] * s, oy + p[1] * s)
    var i = 2
    while (i < p.size) {
        path.lineTo(ox + p[i] * s, oy + p[i + 1] * s)
        i += 2
    }
    if (close) path.close()
    return path
}

private fun DrawScope.poly(p: FloatArray, color: Color, s: Float, ox: Float, oy: Float, alpha: Float) {
    drawPath(polyPath(p, s, ox, oy), color, alpha = alpha)
}

private fun union(a: Path?, b: Path): Path {
    if (a == null) return b
    val out = Path()
    out.op(a, b, PathOperation.Union)
    return out
}

/** Titik-titik jalur dari awal sampai jarak [dist] (titik terakhir diinterpolasi). */
private fun partialPolyline(pts: List<Offset>, dist: Float): List<Offset> {
    val out = mutableListOf(pts[0])
    var cum = 0f
    for (i in 0 until pts.size - 1) {
        val a = pts[i]
        val b = pts[i + 1]
        val l = hypot(b.x - a.x, b.y - a.y)
        if (cum + l <= dist) {
            out.add(b)
            cum += l
        } else {
            val f = if (l > 0f) ((dist - cum) / l).coerceIn(0f, 1f) else 0f
            out.add(Offset(a.x + (b.x - a.x) * f, a.y + (b.y - a.y) * f))
            break
        }
    }
    return out
}

/** Area goresan setebal 2 x [half] di sepanjang jalur: persegi panjang per ruas + lingkaran di tiap tikungan. */
private fun strokeRegion(pts: List<Offset>, half: Float): Path? {
    var region: Path? = null
    for (i in 0 until pts.size - 1) {
        val a = pts[i]
        val b = pts[i + 1]
        val dx = b.x - a.x
        val dy = b.y - a.y
        val l = hypot(dx, dy)
        if (l < 0.01f) continue
        val nx = -dy / l * half
        val ny = dx / l * half
        val quad = Path()
        quad.moveTo(a.x + nx, a.y + ny)
        quad.lineTo(b.x + nx, b.y + ny)
        quad.lineTo(b.x - nx, b.y - ny)
        quad.lineTo(a.x - nx, a.y - ny)
        quad.close()
        region = union(region, quad)
        if (i > 0) {
            val dot = Path()
            dot.addOval(Rect(a.x - half, a.y - half, a.x + half, a.y + half))
            region = union(region, dot)
        }
    }
    return region
}

@Composable
fun SplashOverlay() {
    // rememberSaveable: tidak diputar ulang saat rotasi layar
    var visible by rememberSaveable { mutableStateOf(true) }
    if (!visible) return
    val clock = remember { Animatable(0f) }
    val fade = remember { Animatable(1f) }
    LaunchedEffect(Unit) {
        clock.animateTo(ANIM_MS.toFloat(), tween(ANIM_MS, easing = LinearEasing))
        delay(HOLD_MS)
        fade.animateTo(0f, tween(FADE_MS))
        visible = false
    }
    Canvas(
        Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = fade.value }
            // selama tampil, sentuhan tidak diteruskan ke layar di bawahnya
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) awaitPointerEvent().changes.forEach { it.consume() }
                }
            }
    ) {
        val t = clock.value
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val cy = h / 2f
        drawRect(SplashBg)

        val s = LOGO_WIDTH_FRAC * w / SYM_W
        val ox = cx - SYM_W / 2f * s
        val oy = cy - SYM_H / 2f * s

        // 1) Lingkaran gelap: membesar halus sambil memudar masuk
        val c = PopEase.transform(frac(t, 0f, CIRCLE_MS))
        drawCircle(SplashInk, radius = CIRCLE_R * s * (0.8f + 0.2f * c), center = Offset(cx, cy), alpha = c)

        // 2) Bagian logo masuk bergiliran
        for (pc in PIECES) {
            val e = RiseEase.transform(frac(t, pc.delayMs, PIECE_MS))
            if (e <= 0f) continue
            poly(pc.pts, pc.color, s, ox + pc.dx * (1f - e) * s, oy + pc.dy * (1f - e) * s, e)
        }

        // 3) Huruf V digambar dari kiri sebagai panah bergerak
        val k = frac(t, V_START_MS, V_DRAW_MS)
        if (k <= 0f) return@Canvas
        if (k < 1f) {
            val eased = 0.5f - 0.5f * cos(PI.toFloat() * k)
            val pts = ArrayList<Offset>(V_PATH.size / 2)
            var i = 0
            while (i < V_PATH.size) {
                pts.add(Offset(ox + V_PATH[i] * s, oy + V_PATH[i + 1] * s))
                i += 2
            }
            var len = 0f
            for (j in 0 until pts.size - 1) len += hypot(pts[j + 1].x - pts[j].x, pts[j + 1].y - pts[j].y)
            val dist = len * eased

            // V dipotong (irisan) dengan area goresan: hanya bentuk V yang tergambar, tanpa latar
            val region = strokeRegion(partialPolyline(pts, dist), V_MASK_W * s / 2f)
            if (region != null) {
                val clipped = Path()
                clipped.op(polyPath(LG_V, s, ox, oy), region, PathOperation.Intersect)
                drawPath(clipped, LgOrange)
            }

            // Panah kecil di ujung goresan, menghadap arah jalur
            val tip = partialPolyline(pts, dist).last()
            val a = partialPolyline(pts, (dist - LEAD_SMOOTH * s).coerceAtLeast(0f)).last()
            val b = partialPolyline(pts, (dist + LEAD_SMOOTH * s).coerceAtMost(len)).last()
            val angle = atan2(b.y - a.y, b.x - a.x) * 180f / PI.toFloat()
            withTransform({
                translate(tip.x, tip.y)
                rotate(angle, Offset.Zero)
            }) {
                drawPath(polyPath(LEAD, s, 0f, 0f), LgOrange)
            }
        } else {
            // V utuh: kepala panah menyentak sedikit searah geraknya, lalu kembali
            val kk = frac(t, V_START_MS + V_DRAW_MS, KICK_MS)
            val kick = if (kk < 0.4f) kk / 0.4f else (1f - kk) / 0.6f
            poly(LG_V, LgOrange, s, ox + KICK_DX * kick * s, oy + KICK_DY * kick * s, 1f)
        }
    }
}
