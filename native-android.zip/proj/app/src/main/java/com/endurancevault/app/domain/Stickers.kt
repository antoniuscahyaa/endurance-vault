package com.endurancevault.app.domain

import com.endurancevault.app.data.ActivityEntity
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import java.util.Locale
import kotlin.math.abs

/**
 * Stiker data (port `10c-stiker-data.js`): PNG transparan, satu data per gambar, untuk ditempel di foto.
 * File ini hanya berisi model dan pengaturan (tanpa Android), supaya bisa dites JUnit biasa.
 * Penggambaran ada di `ui/sticker/StickerRenderer.kt`.
 */

/** Satu angka: label, nilai, satuan (padanan `[label, nilai, satuan]` di web). */
data class StickerNum(val label: String, val value: String, val unit: String)

/** Kombinasi pengaturan umum yang disimpan dengan nama (warna, aksen, panel, ukuran, huruf, gaya angka). */
data class StickerPreset(
    val name: String, val ink: String, val inkCustom: String, val accent: String, val panel: String,
    val scale: Int, val fontNum: String, val fontBody: String, val numStyle: String,
)

/** Pengaturan tampilan stiker (padanan `STK` / `rl:stk` di web). Nilai tak valid dibersihkan oleh [sanitized]. */
data class StickerPrefs(
    /** w = putih, k = hitam, l = lime. */
    val ink: String = "w",
    val cols: Int = 3,
    /** gabung = satu kartu, pisah = satu PNG per angka. */
    val mode: String = "gabung",
    /** bawah = data di bawah rute, kiri = data di samping. */
    val lay: String = "bawah",
    val order: List<String> = listOf("jarak", "pace", "waktu"),
    val mapFields: Set<String> = Stickers.MAP_KEYS.toSet(),
    /** both = durasi dan persen, dur, pct. */
    val hz: String = "both",
    /** Warna aksen `#rrggbb`; kosong = bawaan palet. */
    val accent: String = "",
    /** off, soft, strong. */
    val panel: String = "off",
    val highlight: Boolean = true,
    val hrLine: Boolean = false,
    /** Isi paket sesi; null = belum pernah dipilih (pakai bawaan). */
    val pack: List<String>? = null,
    val snap: Boolean = true,
    /** Data angka minggu, urutan sesuai ketukan. */
    val wk: List<String> = listOf("jarak", "waktu", "elev", "sesi"),
    /** Jumlah minggu pada tren pace: 4, 6, atau 8. */
    val trendWeeks: Int = 8,
    /** Warna bar mingguan (zona HR minggu dan target minggu) `#rrggbb`; kosong = bawaan. */
    val weekColor: String = "",
    /** Nama berkas huruf kustom (di `files/sticker_fonts/`) untuk angka dan judul; kosong = bawaan. */
    val fontNum: String = "",
    /** Nama berkas huruf kustom untuk teks isi; kosong = bawaan. */
    val fontBody: String = "",
    /** Warna teks kustom `#rrggbb`; bila diisi, menggantikan pilihan [ink]. */
    val inkCustom: String = "",
    /** Skala ukuran PNG dalam persen (50..300); 100 = ukuran standar. */
    val scale: Int = 100,
    /** Data angka periode, urutan sesuai ketukan. */
    val pf: List<String> = listOf("jarak", "waktu", "pace", "elev"),
    /** std = angka dan judul standar, sport = miring dan tebal. */
    val numStyle: String = "std",
    /** Preset gaya tersimpan (maksimal 8). */
    val presets: List<StickerPreset> = emptyList(),
    /** Warna garis pada Rute berwarna: pace atau hr. */
    val mapColor: String = "pace",
) {
    fun asPreset(name: String) = StickerPreset(name, ink, inkCustom, accent, panel, scale, fontNum, fontBody, numStyle)

    fun withPreset(q: StickerPreset): StickerPrefs = copy(
        ink = q.ink, inkCustom = q.inkCustom, accent = q.accent, panel = q.panel, scale = q.scale,
        fontNum = q.fontNum, fontBody = q.fontBody, numStyle = q.numStyle,
    ).sanitized()

    fun matches(q: StickerPreset): Boolean = asPreset(q.name) == q

    fun sanitized(): StickerPrefs = copy(
        ink = if (ink in setOf("w", "k", "l")) ink else "w",
        cols = if (cols in 2..Stickers.MAX_COLS) cols else 3,
        mode = if (mode == "pisah") "pisah" else "gabung",
        lay = if (lay == "kiri") "kiri" else "bawah",
        order = order.filter { it in Stickers.ALL_NUM_KEYS }.distinct(),
        mapFields = mapFields.filter { it in Stickers.MAP_KEYS }.toSet(),
        hz = if (hz == "dur" || hz == "pct") hz else "both",
        accent = Stickers.hex(accent),
        panel = if (panel == "soft" || panel == "strong") panel else "off",
        pack = pack?.filter { it.length <= 40 }?.take(40),
        wk = wk.filter { it in Stickers.WK_KEYS }.distinct(),
        trendWeeks = if (trendWeeks == 4 || trendWeeks == 6) trendWeeks else 8,
        weekColor = Stickers.hex(weekColor),
        fontNum = Stickers.fontName(fontNum),
        fontBody = Stickers.fontName(fontBody),
        inkCustom = Stickers.hex(inkCustom),
        scale = scale.coerceIn(Stickers.MIN_SCALE, Stickers.MAX_SCALE),
        pf = pf.filter { it in Stickers.PERIOD_KEYS }.distinct(),
        numStyle = if (numStyle == "sport") "sport" else "std",
        mapColor = if (mapColor == "hr") "hr" else "pace",
        presets = presets.map { q ->
            q.copy(
                name = q.name.trim().take(20),
                ink = if (q.ink in setOf("w", "k", "l")) q.ink else "w",
                inkCustom = Stickers.hex(q.inkCustom), accent = Stickers.hex(q.accent),
                panel = if (q.panel == "soft" || q.panel == "strong") q.panel else "off",
                scale = q.scale.coerceIn(Stickers.MIN_SCALE, Stickers.MAX_SCALE),
                fontNum = Stickers.fontName(q.fontNum), fontBody = Stickers.fontName(q.fontBody),
                numStyle = if (q.numStyle == "sport") "sport" else "std",
            )
        }.filter { it.name.isNotEmpty() }.distinctBy { it.name }.take(8),
    )

    fun toJson(): String {
        val o = JsonObject()
        o.addProperty("ink", ink); o.addProperty("cols", cols); o.addProperty("mode", mode); o.addProperty("lay", lay)
        o.add("order", JsonArray().also { a -> order.forEach { a.add(it) } })
        o.add("mf", JsonArray().also { a -> mapFields.forEach { a.add(it) } })
        o.addProperty("hz", hz); o.addProperty("ac", accent); o.addProperty("pn", panel)
        o.addProperty("hl", highlight); o.addProperty("hrl", hrLine); o.addProperty("snap", snap)
        o.add("wk", JsonArray().also { a -> wk.forEach { a.add(it) } })
        o.addProperty("tw", trendWeeks); o.addProperty("wc", weekColor)
        o.addProperty("fn", fontNum); o.addProperty("fb", fontBody)
        o.addProperty("ic", inkCustom); o.addProperty("sc", scale)
        o.add("pf", JsonArray().also { a -> pf.forEach { a.add(it) } })
        o.addProperty("ns", numStyle); o.addProperty("mc", mapColor)
        o.add("pre", JsonArray().also { a ->
            presets.forEach { q ->
                a.add(JsonObject().also { j ->
                    j.addProperty("n", q.name); j.addProperty("ink", q.ink); j.addProperty("ic", q.inkCustom); j.addProperty("ac", q.accent)
                    j.addProperty("pn", q.panel); j.addProperty("sc", q.scale); j.addProperty("fn", q.fontNum); j.addProperty("fb", q.fontBody); j.addProperty("ns", q.numStyle)
                })
            }
        })
        pack?.let { p -> o.add("pkg", JsonArray().also { a -> p.forEach { a.add(it) } }) }
        return o.toString()
    }

    companion object {
        /** Membaca JSON hasil [toJson]; JSON rusak atau kosong menghasilkan pengaturan bawaan. */
        fun fromJson(json: String?): StickerPrefs {
            val d = StickerPrefs()
            val o = runCatching { JsonParser.parseString(json ?: "").asJsonObject }.getOrNull() ?: return d
            fun str(k: String, def: String) = o.get(k)?.takeIf { it.isJsonPrimitive }?.asString ?: def
            fun bool(k: String, def: Boolean) = o.get(k)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isBoolean }?.asBoolean ?: def
            fun list(k: String): List<String>? = o.get(k)?.takeIf { it.isJsonArray }?.asJsonArray
                ?.mapNotNull { e -> e.takeIf { it.isJsonPrimitive }?.asString }
            return StickerPrefs(
                ink = str("ink", d.ink),
                cols = o.get("cols")?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asInt ?: d.cols,
                mode = str("mode", d.mode), lay = str("lay", d.lay),
                order = list("order") ?: d.order,
                mapFields = list("mf")?.toSet() ?: d.mapFields,
                hz = str("hz", d.hz), accent = str("ac", d.accent), panel = str("pn", d.panel),
                highlight = bool("hl", d.highlight), hrLine = bool("hrl", d.hrLine),
                pack = list("pkg"), snap = bool("snap", d.snap),
                wk = list("wk") ?: d.wk,
                trendWeeks = o.get("tw")?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asInt ?: d.trendWeeks,
                weekColor = str("wc", d.weekColor),
                fontNum = str("fn", d.fontNum), fontBody = str("fb", d.fontBody),
                inkCustom = str("ic", d.inkCustom),
                scale = o.get("sc")?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asInt ?: d.scale,
                pf = list("pf") ?: d.pf,
                numStyle = str("ns", d.numStyle),
                mapColor = str("mc", d.mapColor),
                presets = o.get("pre")?.takeIf { it.isJsonArray }?.asJsonArray?.mapNotNull { e ->
                    val q = e.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null
                    fun s(k: String) = q.get(k)?.takeIf { it.isJsonPrimitive }?.asString ?: ""
                    StickerPreset(
                        s("n"), s("ink").ifEmpty { "w" }, s("ic"), s("ac"), s("pn"),
                        q.get("sc")?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asInt ?: 100, s("fn"), s("fb"), s("ns"),
                    )
                } ?: emptyList(),
            ).sanitized()
        }
    }
}

/** Ringkasan aerobik satu sesi: [hr] rata-rata, [easy] batas HR easy (null bila belum diketahui), persen waktu, [drift] (persen, positif = efisiensi turun). */
class MafInfo(
    val hr: Int, val easy: Int?, val z12: Double, val z3: Double, val z45: Double, val z1: Double, val drift: Double?, val pace: Double?,
)

/** Baris tabel segmen: [kind] jenis bawaan (atau null), [custom] true bila label buatan sendiri. */
class StickerSegRow(val name: String, val kind: String?, val custom: Boolean, val d: Double, val min: Double, val pace: Double, val hr: Int?)

/** Satu split km yang layak digambar. */
class StickerSplitRow(val k: Double, val pace: Double, val partial: Boolean)

/**
 * Data satu sesi untuk stiker (padanan `stkModel`). Dibuat lewat [Stickers.forActivity].
 * [hist] histogram HR {bpm: detik}; [zc] batas zona HR dari pengaturan.
 */
class StickerModel(
    val key: String,
    val date: String,
    val name: String,
    val km: Double,
    val min: Double,
    val bike: Boolean,
    val gain: Int?,
    val hr: Int?,
    val cad: Int?,
    val gapPace: Double?,
    val detail: ActDetail?,
    val hist: Map<Int, Double>,
    val zc: ZoneCuts,
    /** Pola interval yang terdeteksi (minimal dua repetisi), atau null. */
    val iv: IvResult? = null,
    /** Data minggu rencana dan aktivitas; null = stiker mingguan tidak tersedia. */
    val weekInput: SwInput? = null,
    /** Ringkasan harian/mingguan/bulanan, pembanding, dan target; null = stiker periode tidak tersedia. */
    val periods: PeriodData? = null,
    /** Id aktivitas (untuk membandingkan dengan PR); 0 bila tidak diketahui. */
    val actId: Long = 0,
    /** Data tambahan (PR, rute serupa, beban, lomba, tahun, streak); null = stiker itu tidak tersedia. */
    val extras: StickerExtras? = null,
) {
    val pace: Double? = if (min > 0 && km > 0) min / km else null

    /** Angka bernilai untuk [key], atau null bila datanya tidak ada pada sesi ini. */
    fun num(key: String): StickerNum? = when (key) {
        "jarak" -> StickerNum("Jarak", Stickers.km2(km), "km")
        "pace" -> pace?.let { StickerNum("Pace", Js.paceStr(it), "/km") }
        "waktu" -> if (min > 0) StickerNum("Waktu", Js.durStr(min), "") else null
        "elev" -> gain?.let { StickerNum("Elevasi naik", it.toString(), "m") }
        "hr" -> hr?.takeIf { it > 0 }?.let { StickerNum("HR rata-rata", it.toString(), "bpm") }
        "kad" -> cad?.takeIf { it > 0 }?.let { StickerNum("Kadens", it.toString(), "spm") }
        "gap" -> gapPace?.takeIf { it > 0 }?.let { StickerNum("GAP", Js.paceStr(it), "/km") }
        "rep", "piv", "best", "fade", "hrr" -> ivNum(key)
        else -> null
    }

    private fun ivNum(key: String): StickerNum? {
        val v = iv ?: return null
        val st = v.stats; val n = st.n
        return when (key) {
            "rep" -> {
                val dm = v.reps.sumOf { it.d } / n
                StickerNum("Repetisi", "$n×" + (if (dm < 1) (Js.round(dm * 100) * 10).toLong().toString() else Js.fmtKm(dm)), if (dm < 1) "m" else "km")
            }
            "piv" -> StickerNum("Pace interval", Js.paceStr(st.avg), "/km")
            "best" -> StickerNum("Tercepat", Js.paceStr(st.best), "/km")
            "fade" -> {
                val r = Js.round(st.fade).toInt()
                StickerNum("Fade", (if (r > 0) "+" else if (r < 0) "\u2212" else "") + abs(r), "dtk/km")
            }
            "hrr" -> {
                val a = st.hrFirst; val b = st.hrLast
                if (a != null && b != null && a > 0 && b > 0) StickerNum("HR awal→akhir", "$a→$b", "") else null
            }
            else -> null
        }
    }

    /** Konteks minggu sesi ini (minggu rencana yang memuatnya); null untuk sepeda atau sesi di luar rencana. */
    val wkCtx: SwCtx? by lazy {
        val wi = weekInput
        val d = runCatching { java.time.LocalDate.parse(date) }.getOrNull()
        if (bike || wi == null || d == null) null else runCatching { StickerWeeks.contextOf(d, wi, zc) }.getOrNull()
    }

    /** Angka satu minggu dari ringkasan minggu sesi ini, atau null bila datanya tidak ada. */
    fun numWk(key: String): StickerNum? {
        val ws = wkCtx?.summary ?: return null
        return when (key) {
            "jarak" -> StickerNum("Jarak minggu", String.format(Locale.ROOT, "%.1f", Js.round(ws.km * 10) / 10).replace('.', ','), "km")
            "waktu" -> if (ws.min > 0) StickerNum("Waktu minggu", Js.durStr(ws.min), "") else null
            "elev" -> if (ws.gain > 0) StickerNum("Elevasi naik", Js.round(ws.gain).toLong().toString(), "m") else null
            "sesi" -> {
                val n = ws.nDone + ws.nFree
                if (n > 0 || ws.nPlan > 0) StickerNum("Sesi", n.toString(), if (ws.nPlan > 0) "/ ${ws.nPlan}" else "") else null
            }
            "pace" -> ws.pace?.takeIf { it > 0 }?.let { StickerNum("Pace rata-rata", Js.paceStr(it), "/km") }
            "hr" -> ws.hr?.takeIf { it > 0 }?.let { StickerNum("HR rata-rata", Js.round(it).toLong().toString(), "bpm") }
            else -> null
        }
    }

    fun keysWk(order: List<String>): List<String> = order.filter { numWk(it) != null }

    /** Ringkasan periode terpilih ([per] = day, week, month), atau null bila tidak ada datanya. */
    fun periodSummary(per: String): PeriodSummary? = periods?.cur?.get(Stickers.perOf(per))?.takeIf { it.km > 0.0 }

    /** Angka satu periode, atau null bila datanya tidak ada. Label mingguan dan bulanan diberi akhiran "minggu" atau "bulan". */
    fun numPer(key: String, per: String): StickerNum? {
        val s = periodSummary(per) ?: return null
        val suf = when (per) { "week" -> " minggu"; "month" -> " bulan"; else -> "" }
        return when (key) {
            "jarak" -> StickerNum("Jarak$suf", if (per == "day") Stickers.km2(s.km) else Stickers.km1(s.km), "km")
            "waktu" -> if (s.durationSec > 0) StickerNum("Waktu$suf", Js.durStr(s.durationSec / 60.0), "") else null
            "pace" -> s.avgPace?.let { StickerNum("Pace rata-rata", Js.paceStr(it), "/km") }
            "elev" -> if (s.gain > 0) StickerNum("Elevasi naik", s.gain.toString(), "m") else null
            "sesi" -> StickerNum("Sesi lari", s.sessions.toString(), "kali")
            "hari" -> if (per != "day") StickerNum("Hari aktif", s.activeDays.toString(), "hari") else null
            "hr" -> s.avgHr?.takeIf { it > 0 }?.let { StickerNum("HR rata-rata", it.toString(), "bpm") }
            "terpanjang" -> if (s.longestKm > 0.0) StickerNum("Terpanjang", Stickers.km2(s.longestKm), "km") else null
            else -> null
        }
    }

    fun keysPer(order: List<String>, per: String): List<String> = order.filter { numPer(it, per) != null }

    /** Alasan stiker periode tidak tersedia, atau null bila tersedia. */
    private fun periodWhy(id: String): String? {
        val per = Stickers.perOfId(id) ?: return null
        val s = periodSummary(per) ?: return NO_PER
        return when (Stickers.kindOfId(id)) {
            "kalender", "kurva" -> if (s.period == SharePeriod.DAY) ONLY_RANGE else null
            "cincin" -> if ((periods?.target?.get(s.period) ?: 0.0) > 0.0) null else "Tidak ada target rencana pada periode ini."
            "banding" -> if (periods?.prev?.get(s.period) != null) null else "Belum ada pembanding untuk periode ini."
            "pekan" -> if (s.period != SharePeriod.MONTH) ONLY_MONTH else if (periods?.monthWeeks.orEmpty().isNotEmpty()) null else NO_PER
            "rekor" -> if (s.period != SharePeriod.MONTH) ONLY_MONTH else if (periods?.records != null) null else NO_PER
            else -> null
        }
    }

    private val trendCache = HashMap<Int, List<SwTrendPt>?>()

    /** Pace mingguan sampai minggu ini (maks. [n] minggu); null bila kurang dari dua minggu punya pace. Aman dipanggil dari dua thread. */
    fun trend(n: Int): List<SwTrendPt>? = synchronized(trendCache) {
        trendCache.getOrPut(n) {
            val c = wkCtx; val wi = weekInput
            if (c == null || wi == null) null else runCatching { StickerWeeks.trend(c, wi, zc, n) }.getOrNull()
        }
    }

    /** Ringkasan aerobik sesi (stiker MAF): HR, batas easy, porsi zona, drift, pace; null bila tidak ada data HR. */
    val maf: MafInfo? by lazy {
        val avg = hr?.takeIf { it > 0 } ?: return@lazy null
        if (hrTotalSec <= 60) return@lazy null
        val sc = zoneSecs; val t = sc.sum().takeIf { it > 0 } ?: return@lazy null
        val easy = zc.lo.getOrNull(2)?.minus(1)?.takeIf { it > 0 }
        val rows = detail?.splits.orEmpty().filter { !it.partial && it.pace in 2.0..20.0 && (it.hr ?: 0) > 0 }
        var drift: Double? = null
        if (rows.size >= 4) {
            val half = rows.size / 2
            fun ef(l: List<Split>) = l.map { (1.0 / it.pace) / it.hr!! }.average()
            val a = ef(rows.take(half)); val b = ef(rows.takeLast(half))
            if (a > 0) drift = (a - b) / a * 100
        }
        MafInfo(avg, easy, (sc[0] + sc[1]) / t * 100, sc[2] / t * 100, (sc[3] + sc[4]) / t * 100, sc[0] / t * 100, drift, pace)
    }

    /** Stiker Vert tersedia bila ada elevasi naik dan profil. */
    val hasVert: Boolean get() = (gain ?: 0) > 0 && (detail?.profile?.size ?: 0) >= 2

    /** Angka cuaca saat lari; kosong bila tidak ada data cuaca. */
    val wxNums: List<StickerNum> by lazy {
        val w = detail?.weather ?: return@lazy emptyList<StickerNum>()
        if (w.tempC.isNaN()) return@lazy emptyList<StickerNum>()
        val out = ArrayList<StickerNum>()
        out.add(StickerNum("Suhu", Js.round(w.tempC).toLong().toString(), "°C"))
        w.feelsLikeC?.let { out.add(StickerNum("Terasa", Js.round(it).toLong().toString(), "°C")) }
        w.humidityPct?.let { out.add(StickerNum("Lembap", it.toString(), "%")) }
        w.windKmh?.let { out.add(StickerNum("Angin", Js.round(it).toLong().toString(), "km/j")) }
        w.rainMm?.takeIf { it > 0.0 }?.let { out.add(StickerNum("Hujan", String.format(Locale.ROOT, "%.1f", it).replace('.', ','), "mm")) }
        out
    }

    /** Best effort sesi (1, 5, 10 km); minimal dua agar stiker bermakna. */
    val bestNums: List<StickerNum> by lazy {
        val d = detail ?: return@lazy emptyList<StickerNum>()
        StickerExtrasCalc.bestEfforts(d).map { (lab, min) -> StickerNum(lab, Js.durStr(min), "") }.takeIf { it.size >= 2 }.orEmpty()
    }

    /** Perbandingan dengan PR pada jarak terpanjang yang tersedia. */
    val prCmp: PrCompare? by lazy {
        val d = detail; val ex = extras
        if (d == null || ex == null) null else StickerExtrasCalc.prCompare(d, ex.prs, actId)
    }

    /**
     * Nilai 0..1 tiap titik rute untuk pewarnaan ([mode] pace atau hr): 0 = cepat atau rendah, 1 = lambat atau tinggi,
     * dinormalkan pada persentil 10 sampai 90. Null bila tidak ada rute atau serinya.
     */
    fun routeNorm(mode: String): List<Double>? {
        val d = detail ?: return null
        val rt = d.route
        if (rt.size < 2) return null
        val series = (if (mode == "hr" && d.hrSeries.size >= 2) d.hrSeries else d.paceSeries).filter { it.second > 0.0 }
        if (series.size < 2) return null
        val cum = DoubleArray(rt.size)
        for (i in 1 until rt.size) cum[i] = cum[i - 1] + Math.hypot((rt[i].first - rt[i - 1].first).toDouble(), (rt[i].second - rt[i - 1].second).toDouble())
        val total = cum.last().takeIf { it > 0 } ?: return null
        val kmEnd = series.last().first.takeIf { it > 0 } ?: return null
        var j = 0
        val vals = DoubleArray(rt.size) { i ->
            val km = cum[i] / total * kmEnd
            while (j < series.lastIndex && series[j + 1].first <= km) j++
            series[j].second
        }
        val sorted = vals.sorted()
        val lo = sorted[(sorted.size * .1).toInt()]; val hi = sorted[((sorted.size - 1) * .9).toInt()]
        val span = hi - lo
        return vals.map { if (span <= 1e-9) .5 else ((it - lo) / span).coerceIn(0.0, 1.0) }
    }

    /** Kunci yang dipakai menurut urutan ketukan, hanya yang datanya ada. */
    fun keys(order: List<String>): List<String> = order.filter { num(it) != null }

    val hasRoute: Boolean get() = (detail?.route?.size ?: 0) >= 2

    /** Baris tabel segmen; null bila kurang dari dua segmen. */
    val segRows: List<StickerSegRow> by lazy {
        val sg = detail?.segments.orEmpty()
        if (sg.size < 2) emptyList() else sg.map { s ->
            val kind = SegKind.normalize(s.type)
            val text = SegKind.displayLabel(s.label, s.type)
            StickerSegRow(text ?: "Tanpa label", kind, kind == null && text != null, s.d, s.min, s.pace, s.hr)
        }
    }

    /** Segmen yang punya jarak dan pace (untuk bar pace per segmen). */
    val paceSegments: List<Segment> by lazy { detail?.segments.orEmpty().filter { it.d > 0 && it.pace > 0 } }

    val splitRows: List<StickerSplitRow> by lazy {
        detail?.splits.orEmpty().filter { it.pace > 0 && it.pace < 30 }.map { StickerSplitRow(it.k, it.pace, it.partial) }
    }

    val hrTotalSec: Double get() = hist.values.sum()
    val zoneSecs: DoubleArray by lazy { Zones.secs(hist, zc) }

    /** Alasan sebuah grafik tidak tersedia (teks untuk pengguna), atau null bila tersedia. */
    fun graphWhy(id: String, trendWeeks: Int = 8): String? = if (Stickers.perOfId(id) != null) periodWhy(id) else when (id) {
        "tabel-segmen" -> if (segRows.size >= 2) null else NO_SEG
        "bar-segmen" -> if (detail?.segments.orEmpty().count { it.min > 0 } >= 2) null else NO_SEG
        "pace-segmen" -> if (paceSegments.size >= 2) null else NO_SEG
        "split-km" -> if (splitRows.size >= 2) null else "Sesi ini tidak punya data split per km."
        "elevasi" -> if ((detail?.profile?.size ?: 0) >= 2) null else "Sesi ini tidak punya data elevasi."
        "pace-repetisi" -> if (iv != null) null else "Belum ada pola interval yang terdeteksi."
        "tren-pace" -> if (trend(trendWeeks) != null) null else "Belum cukup minggu dengan data pace (minimal 2 minggu rencana sampai minggu ini)."
        "zona-hr-minggu" -> if (wkCtx?.summary?.zones != null) null else "Minggu ini belum punya data zona HR."
        "target-minggu" -> {
            val ws = wkCtx?.summary
            if (ws != null && ws.days.isNotEmpty() && ws.planKm > 0) null else "Sesi ini tidak ada di rencana minggu."
        }
        "zona-hr-sesi", "zona-hr-tumpuk" -> if (hrTotalSec > 60) null else "Sesi ini tidak punya data HR."
        "maf" -> if (maf != null) null else "Sesi ini tidak punya data HR."
        "vert" -> if (hasVert) null else "Sesi ini tidak punya data elevasi naik."
        "peta-warna" -> if (hasRoute && routeNorm("pace") != null) null else "Sesi ini tidak punya rute dan data pace."
        "cuaca" -> if (wxNums.isNotEmpty()) null else "Sesi ini belum punya data cuaca."
        "best-effort" -> if (bestNums.isNotEmpty()) null else "Sesi ini terlalu pendek atau belum punya split untuk best effort."
        "vs-pr" -> if (prCmp != null) null else "Belum ada PR yang bisa dibandingkan pada jarak sesi ini."
        "vs-rute" -> if (extras?.sameRoute != null) null else "Belum ada lari lain di rute serupa."
        "hitung-mundur" -> {
            val r = extras?.race
            if (r == null) "Belum ada tanggal lomba di rencana."
            else if (java.time.LocalDate.parse(date).isAfter(r.date)) "Tanggal lomba sudah lewat dari sesi ini." else null
        }
        "training-load" -> if (extras?.load != null) null else "Data beban belum cukup (sekitar 4 minggu aktivitas)."
        "tahun" -> if (extras?.year != null) null else "Belum ada lari di tahun ini."
        "streak" -> if ((extras?.streak?.days ?: 0) > 0) null else "Sesi ini bukan bagian dari streak lari."
        else -> "Stiker ini belum tersedia di versi native."
    }

    private companion object {
        const val NO_SEG = "Sesi ini belum punya segmen. Atur lewat Ubah pembagian segmen."
        const val NO_PER = "Belum ada lari di periode ini."
        const val ONLY_RANGE = "Hanya untuk periode mingguan atau bulanan."
        const val ONLY_MONTH = "Hanya untuk periode bulanan."
    }
}

object Stickers {
    val NUM_KEYS = listOf("jarak", "pace", "waktu", "elev", "hr", "kad", "gap")
    /** Angka dari analisis interval: repetisi, pace interval, tercepat, fade, HR awal ke akhir. */
    val IV_KEYS = listOf("rep", "piv", "best", "fade", "hrr")
    val ALL_NUM_KEYS = NUM_KEYS + IV_KEYS
    /** Angka satu minggu. */
    val WK_KEYS = listOf("jarak", "waktu", "elev", "sesi", "pace", "hr")
    val MAP_KEYS = listOf("pace", "jarak", "elev", "hr", "waktu")
    /** Angka satu periode (harian, mingguan, atau bulanan). */
    val PERIOD_KEYS = listOf("jarak", "waktu", "pace", "elev", "sesi", "hari", "hr", "terpanjang")
    /** Kategori stiker: sesi itu (day), minggu itu (week), bulan itu (month). */
    val SCOPES = listOf("day" to "Sesi", "week" to "Minggu", "month" to "Bulan", "year" to "Tahun")
    /** Jenis stiker statistik periode; id lengkapnya `p{d|w|m}-{jenis}`, mis. `pw-kalender` (kalender minggu itu). */
    val PERIOD_KINDS: List<Pair<String, String>> = listOf(
        "angka" to "Angka", "hero" to "Angka besar", "kalender" to "Kalender",
        "kurva" to "Kurva jarak harian", "cincin" to "Cincin target", "banding" to "Banding",
        "pekan" to "Km per minggu", "rekor" to "Rekor",
    )
    /** Stiker sesi yang isinya mingguan (selain stiker periode `pw-*`). */
    private val WEEK_IDS = setOf("wk-all", "tren-pace", "zona-hr-minggu", "target-minggu", "hitung-mundur", "training-load")
    /** Stiker kategori Tahun. */
    private val YEAR_IDS = setOf("tahun", "streak")

    fun periodId(per: String, kind: String): String = "p${per[0]}-$kind"

    /** day, week, atau month untuk id stiker periode (`pd-`, `pw-`, `pm-`); null bila bukan stiker periode. */
    fun perOfId(id: String): String? =
        if (id.length > 3 && id[0] == 'p' && id[2] == '-') when (id[1]) { 'd' -> "day"; 'w' -> "week"; 'm' -> "month"; else -> null } else null

    fun kindOfId(id: String): String = if (perOfId(id) != null) id.substring(3) else ""

    /** Kategori sebuah stiker: stiker periode mengikuti periodenya, stiker mingguan = week, sisanya = sesi (day). */
    fun scopeOf(id: String): String = perOfId(id) ?: if (id in WEEK_IDS) "week" else if (id in YEAR_IDS) "year" else "day"

    fun perOf(s: String): SharePeriod = when (s) { "day" -> SharePeriod.DAY; "month" -> SharePeriod.MONTH; else -> SharePeriod.WEEK }

    /** Satu desimal dengan koma. */
    fun km1(km: Double): String = String.format(Locale.ROOT, "%.1f", Js.round(km * 10) / 10).replace('.', ',')
    val ACCENTS = listOf("#c6f432", "#4caf7d", "#e8873a", "#3fa9f5", "#e5484d", "#b57bee", "#ffd23f")

    /** Grafik satu file per item, dengan judul. Urutan sama dengan daftar web (yang sudah diport). */
    val GRAPHS: List<Pair<String, String>> = listOf(
        "tabel-segmen" to "Tabel segmen",
        "bar-segmen" to "Bar segmen",
        "pace-segmen" to "Bar pace per segmen",
        "pace-repetisi" to "Pace per repetisi",
        "split-km" to "Split per km",
        "elevasi" to "Grafik elevasi",
        "zona-hr-sesi" to "Zona HR sesi",
        "tren-pace" to "Tren pace mingguan",
        "zona-hr-tumpuk" to "Zona HR bar tumpuk",
        "zona-hr-minggu" to "Zona HR minggu",
        "target-minggu" to "Target minggu",
        "maf" to "MAF / Aerobik",
        "vert" to "Vert dan tanjakan",
        "peta-warna" to "Rute berwarna",
        "cuaca" to "Cuaca",
        "best-effort" to "Best effort",
        "vs-pr" to "Vs PR",
        "vs-rute" to "Vs rute serupa",
        "hitung-mundur" to "Hitung mundur lomba",
        "training-load" to "Training load",
        "tahun" to "Tahun berjalan",
        "streak" to "Streak",
    )

    const val MAX_PHOTO_STICKERS = 5

    /** Angka per baris: 2 sampai [MAX_COLS]. */
    const val MAX_COLS = 6
    const val MIN_SCALE = 50
    const val MAX_SCALE = 300

    /** Warna zona HR (sama dengan `DetailZoneColors`) dalam RGB. */
    val ZONE_RGB = intArrayOf(0x7F9CD6, 0x3F9E86, 0xD8B04A, 0xE8844F, 0xC84B3B)

    /** Warna label segmen (sama dengan `segKindColor` / `CustomLabelColor`) dalam RGB; null = netral mengikuti palet. */
    fun segRgb(kind: String?, custom: Boolean): Int? = when {
        kind == SegKind.REPETITION -> 0xEA5F0A
        kind == SegKind.STRIDE -> 0x7F9CD6
        kind == SegKind.PROGRESSIVE -> 0x3F9E86
        custom -> 0x9B7FD1
        else -> null
    }

    /** Selisih pace bertanda, mis. +0:12 atau −0:05 (padanan `stkDPace`); d dalam menit/km. */
    fun dPace(d: Double): String {
        val sc = Js.round(abs(d) * 60).toInt()
        val sg = if (d > 0 && sc > 0) "+" else if (d < 0 && sc > 0) "\u2212" else "±"
        return "$sg${sc / 60}:${if (sc % 60 < 10) "0" else ""}${sc % 60}"
    }

    private val FONT_NAME = Regex("[A-Za-z0-9_-]{1,60}\\.(ttf|otf)")

    /** Nama berkas huruf yang aman (tanpa folder), atau kosong. */
    fun fontName(v: String?): String = if (v != null && FONT_NAME.matches(v)) v else ""

    fun hex(v: String?): String = if (v != null && Regex("^#[0-9a-fA-F]{6}$").matches(v)) v.lowercase(Locale.ROOT) else ""

    /** Dua desimal dengan koma, seperti `stkKm2`. */
    fun km2(km: Double): String = String.format(Locale.ROOT, "%.2f", Js.round(km * 100) / 100).replace('.', ',')

    /** Model stiker untuk satu aktivitas; null bila jaraknya nol. Detail dan histogram HR boleh kosong. */
    fun forActivity(
        e: ActivityEntity, d: ActDetail?, hist: Map<Int, Double>, zc: ZoneCuts, weekInput: SwInput? = null, periods: PeriodData? = null,
        extras: StickerExtras? = null,
    ): StickerModel? {
        val km = d?.km?.takeIf { it > 0 } ?: e.km
        if (!(km > 0)) return null
        val bike = e.type == "bike"
        val min = d?.movingMin?.takeIf { it > 0 } ?: (e.durationSec / 60.0)
        val gain = d?.gain ?: e.gain
        val gap = ActInsights.gapOfActivity(d?.gapPace, d?.splits.orEmpty(), gain != null, bike)
        return StickerModel(
            key = e.dateIso, date = e.dateIso.take(10), name = e.name.ifBlank { d?.name.orEmpty() },
            km = km, min = min, bike = bike, gain = gain, hr = d?.hr ?: e.avgHr, cad = d?.cad, gapPace = gap,
            detail = d, hist = d?.hrHist?.takeIf { it.isNotEmpty() } ?: hist, zc = zc,
            iv = runCatching { IntervalAnalysis.analyze(d) }.getOrNull(), weekInput = weekInput, periods = periods,
            actId = e.id, extras = extras,
        )
    }

    /** Id semua stiker yang tersedia untuk sesi ini, urutan sama dengan web (angka, peta, grafik). */
    fun allIds(m: StickerModel, p: StickerPrefs): List<String> {
        val ids = ArrayList<String>()
        val ks = m.keys(p.order)
        if (ks.isNotEmpty()) { if (p.mode == "pisah") ks.forEach { ids.add("n-$it") } else ids.add("n-all") }
        if (m.hasRoute) ids.add("map")
        if (m.keysWk(p.wk).isNotEmpty()) ids.add("wk-all")
        listOf("day", "week", "month").forEach { per ->
            if (m.keysPer(p.pf, per).isNotEmpty()) ids.add(periodId(per, "angka"))
            PERIOD_KINDS.forEach { (kind, _) -> if (kind != "angka" && m.graphWhy(periodId(per, kind)) == null) ids.add(periodId(per, kind)) }
        }
        GRAPHS.forEach { (id, _) -> if (m.graphWhy(id, p.trendWeeks) == null) ids.add(id) }
        return ids
    }

    fun idLabel(id: String, m: StickerModel): String = when {
        id == "n-all" -> "Kartu angka"
        id.startsWith("n-") -> "Angka: " + (m.num(id.removePrefix("n-"))?.label ?: id.removePrefix("n-"))
        id == "map" -> "Template peta"
        id == "wk-all" -> "Angka minggu"
        perOfId(id) != null -> (PERIOD_KINDS.firstOrNull { it.first == kindOfId(id) }?.second ?: kindOfId(id)) + " · " + (SCOPES.firstOrNull { it.first == perOfId(id) }?.second ?: "")
        else -> GRAPHS.firstOrNull { it.first == id }?.second ?: id
    }

    /** Paket sesi: pilihan pengguna bila ada, kalau tidak kartu angka, peta, dan bar pace per segmen (atau dua stiker pertama). */
    fun packSel(ids: List<String>, p: StickerPrefs): List<String> {
        p.pack?.let { saved -> return ids.filter { it in saved } }
        val d = ids.filter { it.startsWith("n-") || it == "map" || it == "pace-segmen" }
        return d.ifEmpty { ids.take(2) }
    }

    /** Nama berkas: `trainingplan-<item>-<tanggal>.png`; [seq] > 0 menambah nomor urut `01-`. */
    fun fileName(id: String, m: StickerModel, seq: Int = 0): String {
        var nm = if (id.startsWith("n-")) (if (id == "n-all") "angka" else id.removePrefix("n-")) else if (id == "wk-all") "angka-minggu" else if (perOfId(id) != null) "periode-${kindOfId(id)}-" + (when (perOfId(id)) { "day" -> "sesi"; "week" -> "minggu"; else -> "bulan" }) else id
        if (seq > 0) nm = String.format(Locale.ROOT, "%02d-%s", seq, nm)
        return "trainingplan-$nm-${m.date}.png"
    }
}


/**
 * Pengaturan mana yang mempengaruhi tiap stiker. Dipakai untuk menggambar ulang hanya stiker yang terdampak
 * (mis. menambah satu data angka hanya mengubah kartu angka). Stiker yang tidak dikenal dianggap bergantung pada
 * semua pengaturan, supaya tidak pernah menampilkan gambar yang kedaluwarsa.
 */
object StickerDeps {
    private val PANEL_ONLY = setOf(
        "tabel-segmen", "bar-segmen", "split-km", "elevasi", "pace-repetisi", "maf", "vert",
        "vs-pr", "vs-rute", "hitung-mundur", "training-load", "tahun", "streak",
    )

    /** Pengaturan yang mempengaruhi semua stiker: warna, panel, ukuran PNG, gaya angka. (Huruf kustom ikut lewat `fonts`.) */
    private fun global(p: StickerPrefs): List<Any?> = listOf(p.ink, p.inkCustom, p.accent, p.panel, p.scale, p.numStyle)

    fun key(id: String, p: StickerPrefs): List<Any?> = global(p) + when {
        id == "n-all" -> listOf(p.cols, p.order)
        id.startsWith("n-") -> emptyList()
        id == "wk-all" -> listOf(p.cols, p.wk)
        id == "cuaca" || id == "best-effort" -> listOf(p.cols)
        id == "map" || id == "peta-warna" -> listOf(p.lay, p.mapColor, p.mapFields)
        Stickers.perOfId(id) != null -> if (Stickers.kindOfId(id) == "angka") listOf(p.cols, p.pf) else emptyList()
        id == "zona-hr-sesi" || id == "zona-hr-tumpuk" -> listOf(p.hz)
        id == "zona-hr-minggu" -> listOf(p.hz, p.weekColor)
        id == "target-minggu" -> listOf(p.weekColor)
        id == "tren-pace" -> listOf(p.trendWeeks)
        id == "pace-segmen" -> listOf(p.highlight, p.hrLine)
        id in PANEL_ONLY -> emptyList()
        else -> listOf(p.copy(presets = emptyList(), pack = null))
    }
}
