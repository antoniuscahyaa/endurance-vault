package com.endurancevault.app.ui.screens

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import com.endurancevault.app.AppLog
import com.endurancevault.app.domain.GpxExport
import com.endurancevault.app.ui.i18n.Text
import java.io.File

/** Sesi yang sudah terbuka di halaman aktivitas Strava lewat layar ini (hanya penanda di perangkat; Strava menolak unggahan ganda). */
internal object StravaSent {
    private const val FILE = "strava_sent"
    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun has(ctx: Context, id: Long): Boolean = sp(ctx).getStringSet("ids", emptySet())?.contains(id.toString()) == true

    fun mark(ctx: Context, id: Long) {
        val s = (sp(ctx).getStringSet("ids", emptySet()) ?: emptySet()).toMutableSet()
        if (s.add(id.toString())) sp(ctx).edit().putStringSet("ids", s).apply()
    }
}

private const val UPLOAD_URL = "https://www.strava.com/upload/select"
private val ACTIVITY_URL = Regex("""strava\.com/activities/\d+""")

/** Tulis GPX ke cache (folder gpx/ yang sudah terdaftar di FileProvider); null bila gagal. */
private fun writeGpx(ctx: Context, g: GpxExport.Result): Uri? = runCatching {
    val dir = File(ctx.cacheDir, "gpx").apply { mkdirs() }
    val f = File(dir, g.fileName).apply { writeText(g.xml, Charsets.UTF_8) }
    FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
}.onFailure { AppLog.error("strava", it) }.getOrNull()

/**
 * Layar penuh berisi halaman upload Strava di WebView. Saat Anda mengetuk "Choose file", berkas GPX sesi ini langsung
 * dipakai tanpa membuka pemilih berkas; tombol Simpan di halaman Strava tetap ditekan sendiri. Login cukup sekali
 * (cookie WebView tersimpan). Login lewat Google/Apple biasanya diblokir di WebView, pakai email dan kata sandi atau
 * "Buka di browser".
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
internal fun StravaUploadScreen(gpx: GpxExport.Result, activityId: Long, onSaveFile: () -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val uri = remember(gpx) { writeGpx(ctx, gpx) }
    var progress by remember { mutableIntStateOf(0) }
    var opened by remember { mutableStateOf(false) }
    val web = remember { arrayOfNulls<WebView>(1) }
    val pending = remember { arrayOfNulls<ValueCallback<Array<Uri>>>(1) }

    val goBack = {
        val w = web[0]
        if (w != null && w.canGoBack()) w.goBack() else onClose()
    }
    DisposableEffect(Unit) {
        AppLog.add("strava", "buka layar upload, ${gpx.points} titik, ${"%.2f".format(java.util.Locale.US, gpx.gpxKm)} km, uri=${uri != null}")
        onDispose {
            pending[0]?.onReceiveValue(null); pending[0] = null
            web[0]?.destroy(); web[0] = null
        }
    }

    Dialog(
        onDismissRequest = { goBack() },
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false),
    ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    TextButton(onClick = onClose) { Text("‹ Kembali") }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = onSaveFile) { Text("Simpan GPX") }
                    TextButton(onClick = {
                        runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(UPLOAD_URL)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    }) { Text("Buka di browser") }
                }
                if (progress in 1..99) LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth())
                Text(
                    when {
                        uri == null -> "GPX gagal disiapkan. Gunakan Simpan GPX lalu unggah lewat Buka di browser."
                        opened -> "Sesi ini sudah terbuka di Strava. Strava menolak unggahan ganda, jadi cukup edit di sana."
                        else -> "Ketuk Choose file di halaman Strava: berkas GPX sesi ini terpilih otomatis. Lalu tekan Save di Strava."
                    },
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                )
                if (uri != null) {
                    AndroidView(
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        factory = { c ->
                            WebView(c).also { w ->
                                web[0] = w
                                w.settings.javaScriptEnabled = true
                                w.settings.domStorageEnabled = true
                                w.settings.setSupportMultipleWindows(false)
                                CookieManager.getInstance().apply { setAcceptCookie(true); setAcceptThirdPartyCookies(w, true) }
                                w.webViewClient = object : WebViewClient() {
                                    override fun onPageStarted(v: WebView?, url: String?, favicon: Bitmap?) { progress = 1 }
                                    override fun onPageFinished(v: WebView?, url: String?) { progress = 100; inspect(url) }
                                    override fun doUpdateVisitedHistory(v: WebView?, url: String?, isReload: Boolean) { inspect(url) }
                                    private fun inspect(url: String?) {
                                        if (url != null && ACTIVITY_URL.containsMatchIn(url) && !opened) {
                                            opened = true
                                            StravaSent.mark(c, activityId)
                                            AppLog.add("strava", "halaman aktivitas terbuka: ${url.substringBefore('?')}")
                                        }
                                    }
                                }
                                w.webChromeClient = object : WebChromeClient() {
                                    override fun onProgressChanged(v: WebView?, p: Int) { progress = p }
                                    override fun onShowFileChooser(v: WebView?, cb: ValueCallback<Array<Uri>>?, params: WebChromeClient.FileChooserParams?): Boolean {
                                        pending[0]?.onReceiveValue(null)   // pemilih sebelumnya yang belum selesai dibatalkan
                                        pending[0] = cb
                                        // Langsung berikan GPX sesi ini; callback hanya boleh dipanggil sekali.
                                        cb?.onReceiveValue(arrayOf(uri)); pending[0] = null
                                        AppLog.add("strava", "berkas GPX diberikan ke halaman upload")
                                        return true
                                    }
                                }
                                w.loadUrl(UPLOAD_URL)
                            }
                        },
                    )
                } else Spacer(Modifier.weight(1f))
            }
        }
    }
}
