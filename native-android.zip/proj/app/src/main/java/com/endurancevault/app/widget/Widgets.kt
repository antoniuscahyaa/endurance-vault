package com.endurancevault.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.RemoteViews
import com.endurancevault.app.MainActivity
import com.endurancevault.app.R
import com.endurancevault.app.ui.i18n.Lang
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Memuat data lalu menggambar dan memasang widget. Dipakai penyedia widget dan dipanggil juga saat tema/data aplikasi berubah. */
object WidgetUpdater {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private fun provider(kind: WidgetKind): Class<out AppWidgetProvider> = when (kind) {
        WidgetKind.TODAY -> TodayWidgetProvider::class.java
        WidgetKind.NEXT -> NextWidgetProvider::class.java
        WidgetKind.WEEK -> WeekWidgetProvider::class.java
    }

    /** Perbarui semua widget EnduranceVault yang terpasang (aman dipanggil dari thread mana pun). */
    fun updateAll(ctx: Context) {
        val app = ctx.applicationContext
        // Debounce: geser slider warna memanggil ini berkali-kali; cukup perbarui sekali setelah berhenti sejenak.
        pendingJob?.cancel()
        pendingJob = scope.launch { kotlinx.coroutines.delay(400); runCatching { update(app, null) } }
    }

    @Volatile private var pendingJob: kotlinx.coroutines.Job? = null

    /** Dipanggil dari penyedia: perbarui id tertentu lalu selesaikan broadcast. */
    fun updateAsync(ctx: Context, kind: WidgetKind, ids: IntArray, pending: android.content.BroadcastReceiver.PendingResult?) {
        val app = ctx.applicationContext
        scope.launch {
            try { runCatching { update(app, mapOf(kind to ids)) } } finally { pending?.finish() }
        }
    }

    private suspend fun update(ctx: Context, only: Map<WidgetKind, IntArray>?) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val targets = WidgetKind.values().mapNotNull { k ->
            val ids = only?.get(k) ?: mgr.getAppWidgetIds(ComponentName(ctx, provider(k)))
            if (ids.isEmpty()) null else k to ids
        }
        if (targets.isEmpty()) return
        val snap = WidgetData.load(ctx)
        for ((kind, ids) in targets) for (id in ids) {
            val opts = mgr.getAppWidgetOptions(id)
            val wDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250).coerceAtLeast(110)
            val hDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 120).coerceAtLeast(70)
            val bmp = WidgetRenderer.render(ctx, kind, snap, wDp, hDp)
            val rv = RemoteViews(ctx.packageName, R.layout.widget_image)
            rv.setImageViewBitmap(R.id.widget_image, bmp)
            rv.setContentDescription(R.id.widget_image, describe(kind, snap))
            val open = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            val pi = PendingIntent.getActivity(ctx, kind.ordinal, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            rv.setOnClickPendingIntent(R.id.widget_image, pi)
            mgr.updateAppWidget(id, rv)
        }
    }

    private fun describe(kind: WidgetKind, s: WidgetSnapshot): String = when (kind) {
        WidgetKind.TODAY -> "${s.dateLabel}. ${s.todayTitle}. ${s.todaySub}. " + (s.readiness?.let { Lang.tr("Kesiapan") + " $it" } ?: "")
        WidgetKind.NEXT -> Lang.tr("Sesi berikutnya") + ": " + s.next.joinToString("; ") { "${it.whenLabel} ${it.title} ${it.km}" }
        WidgetKind.WEEK -> Lang.tr("Pekan ini") + ": ${s.weekDone.roundToInt()} / ${s.weekTarget.roundToInt()} km"
    }

    private fun Double.roundToInt(): Int = kotlin.math.round(this).toInt()
}

abstract class BaseWidgetProvider(private val kind: WidgetKind) : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetUpdater.updateAsync(context, kind, appWidgetIds, goAsync())
    }

    override fun onAppWidgetOptionsChanged(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle) {
        WidgetUpdater.updateAsync(context, kind, intArrayOf(appWidgetId), null)
    }
}

class TodayWidgetProvider : BaseWidgetProvider(WidgetKind.TODAY)
class NextWidgetProvider : BaseWidgetProvider(WidgetKind.NEXT)
class WeekWidgetProvider : BaseWidgetProvider(WidgetKind.WEEK)
