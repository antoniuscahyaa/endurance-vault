package com.endurancevault.app.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.endurancevault.app.EnduranceVaultApp
import com.endurancevault.app.data.ActStore
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.data.BackupException
import com.endurancevault.app.data.BackupParser
import com.endurancevault.app.data.BackupSummary
import com.endurancevault.app.data.NativeBackup
import com.endurancevault.app.data.KvEntity
import com.endurancevault.app.data.DailyEntity
import com.endurancevault.app.data.GearEntity
import com.endurancevault.app.data.ParsedBackup
import com.endurancevault.app.data.TrackParsers
import com.endurancevault.app.data.ElevationCalibration
import com.endurancevault.app.data.WatchTrackMerge
import com.endurancevault.app.domain.GpsTrackCodec
import com.endurancevault.app.data.HuaweiWatchImport
import com.rencanalari.huaweiwatch.ProtocolBridge
import com.rencanalari.huaweiwatch.ProtocolGateway
import com.rencanalari.huaweiwatch.KeepAliveConfig
import com.endurancevault.app.security.SecretStore
import android.location.LocationManager
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import android.provider.Settings
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import org.json.JSONObject
import org.json.JSONArray
import java.time.Instant
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import com.endurancevault.app.domain.ActBuilder
import com.endurancevault.app.domain.ActivityDuplicates
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.sync.withLock
import com.endurancevault.app.domain.CoachAction
import com.endurancevault.app.domain.CoachActions
import com.endurancevault.app.domain.ActImportException
import com.endurancevault.app.domain.ActCrop
import com.endurancevault.app.domain.ActEdit
import com.endurancevault.app.domain.ActTombstones
import com.endurancevault.app.domain.ActDetail
import com.endurancevault.app.domain.RouteGeo
import com.endurancevault.app.domain.WatchBattery
import com.endurancevault.app.domain.WatchDock
import com.endurancevault.app.data.ActivityWeather
import com.endurancevault.app.data.JsonUtil
import com.endurancevault.app.domain.SegmentSplit
import com.endurancevault.app.domain.WatchLaps
import com.endurancevault.app.domain.CourseStrategy
import com.endurancevault.app.domain.EasyPace
import com.endurancevault.app.domain.GpxRoute
import com.endurancevault.app.domain.Js
import com.endurancevault.app.domain.PlanEngine
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.domain.Wx
import com.endurancevault.app.domain.WxSnapshot
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.withLock

private fun Double.toIntOrNullSafe(): Int = if (isFinite()) toInt() else 0

data class UiState(
    val settings: PlanSettings,
    val plan: PlanOutcome,
    val activities: List<ActivityEntity>,
    val daily: List<DailyEntity> = emptyList(),
    val gear: List<GearEntity> = emptyList(),
    val hrHistByActivity: Map<Long, Map<Int, Double>> = emptyMap(),
    val detailsByActivity: Map<Long, com.endurancevault.app.domain.ActDetail> = emptyMap(),
    val strengthWorkouts: List<StrengthWorkoutRecord> = emptyList(),
    /** Entri tukar hari / libur dadakan / geser / lewati (format `mv` web) dan centang manual `done`. */
    val mv: Map<String, com.endurancevault.app.domain.MvEntry> = emptyMap(),
    val done: Set<String> = emptySet(),
)

data class StrengthWorkoutRecord(
    val startEpoch: Long, val dateIso: String, val minutes: Int, val sportType: Int,
    val avgHr: Int?, val maxHr: Int?, val calories: Int?, val linkedKey: String?,
    val free: Boolean, val deleted: Boolean,
)

sealed interface ImportUi {
    data object Idle : ImportUi
    data object Working : ImportUi
    class Confirm(val backup: ParsedBackup, val file: File) : ImportUi
    class Done(val message: String) : ImportUi
    class Failed(val message: String) : ImportUi
}

/** Status cadangan lengkap (.zip): buat dan pulihkan. */
sealed interface BackupUi {
    data object Idle : BackupUi
    class Working(val label: String) : BackupUi
    class Confirm(val summary: BackupSummary) : BackupUi
    class Done(val message: String, val restored: Boolean) : BackupUi
    class Failed(val message: String) : BackupUi
}

/** Cocokkan workout jam dengan baris manual/backup agar satu sesi tidak dihitung dua kali. */
internal fun watchWorkoutMatches(
    row: ActivityEntity, dateIso: String, startTime: String, km: Double, durationSec: Int, type: String,
): Boolean {
    if (row.dateIso != dateIso || row.type != type || row.startTime == null) return false
    val timeClose = runCatching {
        val old = LocalTime.parse(row.startTime)
        val incoming = LocalTime.parse(startTime)
        kotlin.math.abs(java.time.Duration.between(old, incoming).toMinutes()).let { minOf(it, 1440 - it) } <= 5
    }.getOrDefault(false)
    val distanceClose = kotlin.math.abs(row.km - km) <= maxOf(0.20, km * 0.025)
    val durationClose = row.durationSec > 0 && kotlin.math.abs(row.durationSec - durationSec) <= 180
    return timeClose && distanceClose && durationClose
}

/** Pace easy dari lari tercatat (null bila belum ada pekan lengkap sebelum pekan ini). */
internal fun easyPaceOf(s: PlanSettings, acts: List<ActivityEntity>, restDefault: Int = 55): Double? {
    val runs = acts.map { EasyPace.Run(it.dateIso, it.km, it.durationSec / 60.0, it.avgHr, it.type, it.gain) }
    return EasyPace.estimate(runs, EasyPace.sessHr(s, restDefault))?.pace?.takeIf { it > 0 }
}

/** Batas pelengkapan jejak GPS (`gt`) pada detail jam lama per satu putaran sinkron, supaya sinkron pertama tidak berat. */
private const val GPS_BACKFILL_PER_SYNC = 30
private const val LAP_BACKFILL_PER_SYNC = 30

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val duplicateStatus = MutableStateFlow("")
    private val a = app as EnduranceVaultApp

    /** Dock Explore: menggambar rute, Koleksiku (rute dan lokasi tersimpan di tabel kv). */
    val explore = ExploreController(a, viewModelScope)
    private val settingsFlow = MutableStateFlow(a.settings.load())
    init { settingsFlow.value.let { com.endurancevault.app.AppLog.add("settings", "load rtype=${it.rtype} start=${it.start} race=${it.race} base=${it.base} peak=${it.peak} name='${it.name}'") } }

    private val kvMutex = kotlinx.coroutines.sync.Mutex()

    private val detailCache = java.util.concurrent.ConcurrentHashMap<String, Pair<Long, com.endurancevault.app.domain.ActDetail>>()

    val state: StateFlow<UiState> = combine(
        settingsFlow,
        a.db.activities().observeAll(),
        a.db.companion().observeDaily(),
        a.db.companion().observeGear(),
        combine(a.db.companion().observeKv("swo"), a.db.companion().observeKv("mv"), a.db.companion().observeKv("done")) { swo, mv, done -> Triple(swo, mv, done) },
    ) { s, acts, daily, gear, kv ->
        val (swo, mvKv, doneKv) = kv
        val strength = runCatching {
            val arr = org.json.JSONArray(swo?.json ?: "[]")
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                StrengthWorkoutRecord(
                    startEpoch = o.optLong("s"), dateIso = o.optString("d"),
                    minutes = o.optInt("m"), sportType = o.optInt("t"),
                    avgHr = o.optInt("hr").takeIf { it > 0 }, maxHr = o.optInt("mx").takeIf { it > 0 },
                    calories = o.optInt("c").takeIf { it > 0 }, linkedKey = o.optString("k").takeIf { it.isNotBlank() },
                    free = o.optBoolean("f"), deleted = o.optBoolean("x"),
                )
            }.filter { it.startEpoch > 0 && it.minutes > 0 && !it.deleted }.sortedBy { it.startEpoch }
        }.getOrDefault(emptyList())
        val mv = com.endurancevault.app.data.MvStore.parse(mvKv?.json)
        val doneSet = com.endurancevault.app.data.MvStore.parseDone(doneKv?.json)
        // Urutan seperti web: plan mentah -> tukar hari / libur dadakan / geser -> penyesuaian beban Profil.
        // Input plan() seperti planRaw web: HR/threshold dari zona, pace easy dari log, HR maks dari log.
        // HR maks dari log: abaikan lonjakan sensor (di luar 100..220 bpm), kalau tidak zona (dan kirim zona ke jam) ikut rusak.
        val sx = s.copy(logHrMax = acts.mapNotNull { it.maxHr }.filter { it in 100..220 }.maxOrNull() ?: 0)
        val restDef = com.endurancevault.app.ui.screens.restHrFrom(daily).first
        // Kegagalan hitung rencana (mis. pengecualian di mesin plan) tidak boleh menjatuhkan aplikasi: pengaturan sudah tersimpan, rencana tampil sebagai error dengan pesan penyebabnya.
        val planOut: com.endurancevault.app.domain.PlanOutcome = runCatching {
        val raw = com.endurancevault.app.domain.PlanRaw.plan(sx, easyPace = easyPaceOf(sx, acts, restDef), restDefault = restDef)
        val swapped = com.endurancevault.app.domain.SessionAdjust.apply(
            raw,
            com.endurancevault.app.domain.AdjInput(
                java.time.LocalDate.now(), mv, doneSet, com.endurancevault.app.domain.SessionAdjust.loggedKm(acts), s.hr,
            ),
        )
        com.endurancevault.app.domain.ProfilePlanAdjustments.apply(swapped, sx, acts)
        }.getOrElse { com.endurancevault.app.AppLog.error("plan", it); com.endurancevault.app.domain.PlanOutcome.Err("Gagal menghitung rencana (${it::class.java.simpleName}: ${it.message})") }
        UiState(sx, planOut, acts, daily, gear, strengthWorkouts = strength, mv = mv, done = doneSet)
    }.map { ui ->
        val loaded = withContext(Dispatchers.IO) {
            // Cache per berkas (tanda = waktu ubah + ukuran): perubahan tabel aktivitas tidak lagi mem-parse ulang semua detail,
            // dan berkas yang sudah tidak dipakai dibuang dari cache supaya memori tidak menumpuk.
            val keep = HashSet<String>()
            val out = HashMap<Long, com.endurancevault.app.domain.ActDetail>()
            for (act in ui.activities) {
                val file = act.detailFile ?: continue
                keep.add(file)
                val f = a.acts.file(file)
                val sig = f.lastModified() * 31 + f.length()
                val hit = detailCache[file]
                val detail = if (hit != null && hit.first == sig) hit.second
                else a.acts.read(file)?.also { detailCache[file] = sig to it }
                if (detail != null) out[act.id] = detail
            }
            detailCache.keys.retainAll(keep)
            out
        }
        val hist = loaded.mapNotNull { (id, detail) ->
            detail.hrHist.takeIf { it.isNotEmpty() }?.let { id to it }
        }.toMap()
        ui.copy(hrHistByActivity = hist, detailsByActivity = loaded)
    }.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5_000),
        UiState(
            settingsFlow.value,
            runCatching { com.endurancevault.app.domain.ProfilePlanAdjustments.apply(PlanEngine.plan(settingsFlow.value), settingsFlow.value, emptyList()) }
                .getOrElse { com.endurancevault.app.domain.PlanOutcome.Err("Gagal menghitung rencana (${it::class.java.simpleName}: ${it.message})") },
            emptyList(),
        ),
    )

    init { migrateLegacyAdjustments() }

    val importState = MutableStateFlow<ImportUi>(ImportUi.Idle)
    val backupState = MutableStateFlow<BackupUi>(BackupUi.Idle)
    private var restoreStaging: File? = null

    /** Pesan hasil impor berkas FIT/GPX/TCX (null = tidak ada). */
    val trackMsg = MutableStateFlow<String?>(null)
    val watchMessage = MutableStateFlow("Jam belum dihubungkan.")
    private val watchSyncLock = AtomicBoolean(false)
    val watchSyncing = MutableStateFlow(false)
    val watchAdvancedMessage = MutableStateFlow("Fitur lanjutan jam siap dikonfigurasi.")
    val liveHrJson = MutableStateFlow(JSONObject().put("active", false).put("running", false).put("bpm", 0))
    private val watchBridge by lazy { ProtocolBridge.get(a) }

    // ---- Dock Jam (port 30-dock-jam.js): pembacaan data jam, alias nama, dan penerapan sinkron latar ke Kondisi ----
    private val dockReader by lazy { com.endurancevault.app.data.WatchDockReader(a) }
    val watchDock = MutableStateFlow<com.endurancevault.app.data.WatchDockUi>(com.endurancevault.app.data.WatchDockUi.Loading)
    val watchAlias = MutableStateFlow("")
    /** Detik unix sinkron terakhir yang dijalankan dari aplikasi (padanan jamLastSync). */
    val watchLastSyncJs = MutableStateFlow(0L)
    private val dockReading = AtomicBoolean(false)
    @Volatile private var dockAppliedSync = 0L

    /** Baca ulang data jam dari basis data sinkron lokal (jamRefresh). Aman dipanggil berulang; pembacaan yang sedang berjalan dilewati. */
    fun refreshWatchDock() {
        if (!dockReading.compareAndSet(false, true)) return
        viewModelScope.launch {
            try {
                val hrMax = state.value.settings.hr
                val r = withContext(Dispatchers.IO) { dockReader.read(hrMax) }
                watchAlias.value = withContext(Dispatchers.IO) { dockReader.alias() }
                // Gagal baca tidak menghapus data yang sudah tampil.
                if (!(r is com.endurancevault.app.data.WatchDockUi.Failed && watchDock.value is com.endurancevault.app.data.WatchDockUi.Ready)) watchDock.value = r
                if (r is com.endurancevault.app.data.WatchDockUi.Ready) applyBackgroundSync(r.model.lastSyncAt)
            } finally { dockReading.set(false) }
        }
    }

    fun setWatchAlias(v: String) {
        viewModelScope.launch { withContext(Dispatchers.IO) { dockReader.setAlias(v) }; watchAlias.value = dockReader.alias(); refreshWatchDock() }
    }

    /**
     * Layanan latar (WatchKeepAliveService) menyinkron jam saat aplikasi di belakang. Bila sinkron itu lebih baru dari yang terakhir diterapkan,
     * impor ke Kondisi dan Jadwal sekarang (jamApplyNative / jamBgApply di web). Dilewati bila sinkron manual sedang berjalan.
     */
    private suspend fun applyBackgroundSync(lastSyncAt: Long?) {
        if (lastSyncAt == null || lastSyncAt <= dockAppliedSync || watchSyncing.value) return
        if (!watchSyncLock.compareAndSet(false, true)) return
        dockAppliedSync = lastSyncAt
        try { withContext(Dispatchers.IO) { importWatchData(false) } } catch (_: Exception) { } finally { watchSyncLock.set(false) }
    }

    init {
        // Polling ringan tiap 60 detik dari tab mana pun: hanya membaca status plugin, mengimpor bila ada sinkron latar yang lebih baru.
        viewModelScope.launch {
            kotlinx.coroutines.delay(5000)
            while (true) {
                runCatching {
                    val t = withContext(Dispatchers.IO) { watchBridge.status().optLong("lastSyncAt", 0L) }
                    if (t > dockAppliedSync) applyBackgroundSync(t)
                }
                kotlinx.coroutines.delay(60_000)
            }
        }
    }
    val weatherMessage = MutableStateFlow("")
    val weatherBusy = MutableStateFlow(false)
    private val weatherPrefs = a.getSharedPreferences("weather_loc", android.content.Context.MODE_PRIVATE)
    val weatherLat = MutableStateFlow(weatherPrefs.getString("lat", null) ?: "-6.99")
    val weatherLon = MutableStateFlow(weatherPrefs.getString("lon", null) ?: "110.42")
    val weatherPlace = MutableStateFlow(weatherPrefs.getString("place", null) ?: "Ungaran, Indonesia")
    /** Data terstruktur untuk kartu sapaan + cuaca di tab Hari ini (weatherMessage tetap untuk layar Atur). */
    val weatherSnapshot = MutableStateFlow<WxSnapshot?>(null)
    /** Pesan galat singkat dari pengambilan cuaca terakhir (null = berhasil / belum ada). */
    val weatherError = MutableStateFlow<String?>(null)
    /** Nama tempat untuk ditampilkan di kartu (titik GPS memakai nama hasil reverse geocoding, bukan "Lokasi saya"). */
    val weatherPlaceLabel = MutableStateFlow(weatherPrefs.getString("place", null) ?: "Ungaran, Indonesia")
    private var weatherLastAttemptMs = 0L
    private var pushWeatherAfterFetch = false
    /** Hasil singkat kirim lokasi + cuaca ke jam (kartu Hari ini dan halaman Cuaca); hilang sendiri setelah beberapa detik. */
    val weatherWatchNote = MutableStateFlow("")
    val weatherWatchBusy = MutableStateFlow(false)
    /** Info non-galat soal lokasi, mis. GPS belum dapat sehingga memakai lokasi tersimpan. */
    val weatherNotice = MutableStateFlow<String?>(null)
    val weatherWatchStatus = MutableStateFlow(runCatching { watchBridge.weatherStatus().toString() }.getOrDefault("{}"))
    val agpsStatus = MutableStateFlow(runCatching { watchBridge.agpsStatus().toString() }.getOrDefault("{}"))
    val notifyStatus = MutableStateFlow(runCatching { watchBridge.notifyStatus().toString() }.getOrDefault("{}"))
    val aiStatus = MutableStateFlow(if (runCatching { SecretStore(a).get("groq_api_key") }.getOrNull().isNullOrBlank()) "Masukkan Groq API key untuk mengaktifkan AI Coach online." else "API key Groq tersimpan terenkripsi dan siap digunakan.")
    val aiBusy = MutableStateFlow(false)
    val aiKeySet = MutableStateFlow(!runCatching { SecretStore(a).get("groq_api_key") }.getOrNull().isNullOrBlank())
    val aiError = MutableStateFlow<String?>(null)
    val aiMessages = MutableStateFlow<List<Pair<String, String>>>(emptyList())
    /** Daftar model Groq yang bisa dipilih: id API ke nama tampilan. Urutan ini juga urutan pergantian saat limit tercapai. */
    val aiModels = listOf(
        "openai/gpt-oss-120b" to "GPT-OSS 120B",
        "openai/gpt-oss-20b" to "GPT-OSS 20B",
        "llama-3.3-70b-versatile" to "Llama 3.3 70B",
    )
    private val aiPrefs = a.getSharedPreferences("ai_coach", android.content.Context.MODE_PRIVATE)
    val aiModel = MutableStateFlow(aiPrefs.getString("model", null)?.takeIf { id -> aiModels.any { it.first == id } } ?: aiModels.first().first)
    /** True bila permintaan terakhir ditolak karena limit (HTTP 429); chat menampilkan tombol refresh untuk ganti model. */
    val aiRateLimited = MutableStateFlow(false)
    private var lastAiWebSearch = true
    private fun aiModelLabel(id: String) = aiModels.firstOrNull { it.first == id }?.second ?: id
    fun setAiModel(id: String) {
        if (aiModels.none { it.first == id }) return
        aiModel.value = id
        aiPrefs.edit().putString("model", id).apply()
    }
    /** Ganti ke model berikutnya lalu kirim ulang pertanyaan terakhir yang gagal karena limit. */
    fun switchAiModelAndRetry() {
        if (aiBusy.value) return
        val q = aiMessages.value.lastOrNull()?.takeIf { it.first == "user" }?.second ?: return
        val i = aiModels.indexOfFirst { it.first == aiModel.value }
        setAiModel(aiModels[(i + 1) % aiModels.size].first)
        sendAiQuestion(q, "", lastAiWebSearch, retry = true)
    }
    private val secretStore by lazy { SecretStore(a) }

    private suspend fun bridgeCall(block: (ProtocolGateway.Callback) -> Unit): JSONObject = suspendCancellableCoroutine { cont ->
        try {
            block(object : ProtocolGateway.Callback {
                override fun ok(result: JSONObject) { if (cont.isActive) cont.resume(result) }
                override fun error(code: String, message: String) { if (cont.isActive) cont.resumeWithException(IllegalStateException("$code: $message")) }
            })
        } catch (t: Throwable) { if (cont.isActive) cont.resumeWithException(t) }
    }

    fun fetchWeather(lat: Double, lon: Double, place: String = weatherPlace.value) {
        if (weatherBusy.value) return
        weatherLat.value = lat.toString(); weatherLon.value = lon.toString(); weatherPlace.value = place
        weatherLastAttemptMs = System.currentTimeMillis()
        weatherPrefs.edit().putString("lat", lat.toString()).putString("lon", lon.toString()).putString("place", place).apply()
        weatherBusy.value = true; weatherMessage.value = "Mengambil cuaca 7 hari dan kualitas udara…"
        weatherError.value = null
        viewModelScope.launch {
            // Snapshot terstruktur sudah masuk lebih dulu; galat saat menyusun ringkasan teks tidak boleh dianggap gagal.
            var snapOk = false
            weatherMessage.value = try {
                withContext(Dispatchers.IO) {
                    fun getJson(url: String): JSONObject {
                        val c = (URL(url).openConnection() as HttpURLConnection).apply { connectTimeout=12000; readTimeout=15000; requestMethod="GET"; setRequestProperty("Accept","application/json") }
                        try { if(c.responseCode !in 200..299) throw IllegalStateException("HTTP ${c.responseCode}"); return c.inputStream.bufferedReader().use { JSONObject(it.readText()) } } finally { c.disconnect() }
                    }
                    val base = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=${Wx.FORECAST_PARAMS_CURRENT}&hourly=${Wx.FORECAST_PARAMS_HOURLY}&daily=${Wx.FORECAST_PARAMS_DAILY}&forecast_days=7&timezone=auto"
                    val j=getJson(base); val cur=j.getJSONObject("current"); val daily=j.getJSONObject("daily")
                    val aq=runCatching { getJson("https://air-quality-api.open-meteo.com/v1/air-quality?latitude=$lat&longitude=$lon&current=us_aqi,european_aqi,pm2_5,pm10&timezone=auto").optJSONObject("current") }.getOrNull()
                    weatherSnapshot.value = Wx.parse(j, aq, lat, lon, place, System.currentTimeMillis()); snapOk = true
                    weatherSnapshot.value?.let { snap -> runCatching { com.endurancevault.app.widget.GlanceWidgetStore.saveWeather(a, snap); com.endurancevault.app.widget.GlanceWidgetRenderer.updateAll(a) } }
                    val days=daily.getJSONArray("time"); val codes=daily.getJSONArray("weather_code"); val hi=daily.getJSONArray("temperature_2m_max"); val lo=daily.getJSONArray("temperature_2m_min"); val rain=daily.getJSONArray("precipitation_probability_max"); val wind=daily.getJSONArray("wind_speed_10m_max")
                    fun cond(code:Int)=when(code){0->"Cerah";1,2->"Cerah berawan";3->"Berawan";45,48->"Berkabut";51,53,55,56,57->"Gerimis";61,63,65,66,67->"Hujan";71,73,75,77->"Salju";80,81,82->"Hujan lokal";85,86->"Hujan salju";95,96,99->"Badai petir";else->"Tidak diketahui"}
                    val out=StringBuilder()
                    out.append("CUACA SAAT INI · ${cond(cur.optInt("weather_code",-1))}\nSuhu ${cur.optDouble("temperature_2m",0.0)}°C · terasa ${cur.optDouble("apparent_temperature",0.0)}°C · kelembapan ${cur.optInt("relative_humidity_2m",-1)}%\nHujan ${cur.optDouble("precipitation",0.0)} mm · angin ${cur.optDouble("wind_speed_10m",0.0)} km/jam\n")
                    out.append("KUALITAS UDARA · US AQI ${aq?.optInt("us_aqi",-1) ?: -1} · EU AQI ${aq?.optInt("european_aqi",-1) ?: -1} · PM2.5 ${aq?.optDouble("pm2_5",Double.NaN)} µg/m³ · PM10 ${aq?.optDouble("pm10",Double.NaN)} µg/m³\n\nPRAKIRAAN 7 HARI\n")
                    for(i in 0 until days.length()) out.append("${days.getString(i)} · ${cond(codes.optInt(i,-1))} · ${lo.optDouble(i)}–${hi.optDouble(i)}°C · peluang hujan ${rain.optInt(i,-1)}% · angin maks ${wind.optDouble(i)} km/jam\n")
                    out.append("\nKoordinat ${"%.4f".format(Locale.US,lat)}, ${"%.4f".format(Locale.US,lon)} · Open-Meteo")
                    out.toString()
                }
            } catch (e: Exception) {
                if (snapOk) "Cuaca diperbarui."
                else { weatherError.value = e.message ?: "periksa koneksi"; "Cuaca/AQI tidak tersedia: ${e.message ?: "periksa koneksi"}" }
            }
            weatherBusy.value=false
            if (weatherSnapshot.value?.let { it.lat == lat && it.lon == lon } == true && !weatherMessage.value.startsWith("Cuaca/AQI tidak tersedia")) {
                weatherError.value = null
                resolveWeatherLabel(lat, lon, place)
                if (pushWeatherAfterFetch) {
                    pushWeatherAfterFetch = false
                    // Tombol Perbarui juga menyegarkan lokasi + cuaca di jam bila sinkron cuaca aktif atau jam sedang tersambung.
                    if (withContext(Dispatchers.IO) { watchWeatherWanted() }) sendWeatherToWatch(lat, lon, weatherPlaceLabel.value.ifBlank { place })
                }
            } else pushWeatherAfterFetch = false
        }
    }

    private fun watchWeatherWanted(): Boolean {
        val on = runCatching { JSONObject(weatherWatchStatus.value).optBoolean("enabled", false) }.getOrDefault(false)
        if (on) return true
        return runCatching { watchBridge.status().optString("state") in setOf("connected", "syncing") }.getOrDefault(false)
    }

    private fun isGpsLikePlace(n: String) = n.isBlank() || n.trim().equals("Lokasi saya", true) || n.trim().equals("My location", true)

    /** Nama tempat untuk kartu: nama kota apa adanya, atau (untuk titik GPS) hasil reverse geocoding yang di-cache per ~1 km. */
    private fun resolveWeatherLabel(lat: Double, lon: Double, place: String) {
        if (!isGpsLikePlace(place)) { weatherPlaceLabel.value = place; return }
        val key = "%.2f,%.2f".format(Locale.US, lat, lon)
        val cached = if (weatherPrefs.getString("pn_k", null) == key) weatherPrefs.getString("pn_n", null) else null
        weatherPlaceLabel.value = cached ?: "Lokasi saya"
        if (cached != null) return
        viewModelScope.launch {
            val name = withContext(Dispatchers.IO) { runCatching { reverseGeocodeName(lat, lon) }.getOrNull() }
            if (!name.isNullOrBlank()) {
                weatherPrefs.edit().putString("pn_k", key).putString("pn_n", name).apply()
                if (isGpsLikePlace(weatherPlace.value)) weatherPlaceLabel.value = name
            }
        }
    }

    /** Alamat Nominatim menjadi "Kelurahan/Kota, Kabupaten" (port wxNowPlaceFrom di web). */
    private fun reverseGeocodeName(lat: Double, lon: Double): String? {
        val url = URL("https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=14&addressdetails=1&accept-language=id&lat=$lat&lon=$lon")
        val c = url.openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10000; c.readTimeout = 12000
            c.setRequestProperty("User-Agent", "EnduranceVault/0.5 (Android)")
            if (c.responseCode !in 200..299) return null
            val addr = JSONObject(c.inputStream.bufferedReader().use { it.readText() }).optJSONObject("address") ?: return null
            fun g(vararg k: String) = k.firstNotNullOfOrNull { key -> addr.optString(key).takeIf { v -> v.isNotBlank() } }.orEmpty()
            val first = g("suburb", "village", "neighbourhood", "hamlet", "town", "city_district", "city", "municipality")
            var area = g("city", "county", "regency", "state_district", "town", "state")
            if (first == area) area = g("county", "state")
            return listOf(first, area).filter { it.isNotBlank() }.joinToString(", ").replace(Regex("\\bKabupaten\\b"), "Kab.").take(60).ifBlank { null }
        } finally { c.disconnect() }
    }

    /** Muat ulang bila data lebih tua dari [maxAgeMs]. Dipakai saat Hari ini dibuka/kembali ke layar dan oleh timer 10 menit. */
    fun refreshWeatherIfStale(maxAgeMs: Long = 15 * 60_000L) {
        if (weatherBusy.value) return
        val now = System.currentTimeMillis()
        val last = weatherSnapshot.value?.fetchedAtMs ?: 0L
        if (now - last < maxAgeMs || now - weatherLastAttemptMs < 60_000L) return
        val lat = weatherLat.value.toDoubleOrNull() ?: return
        val lon = weatherLon.value.toDoubleOrNull() ?: return
        fetchWeather(lat, lon)
    }

    /**
     * Tombol Perbarui di kartu (setara wxNowFollow di web): untuk lokasi "Lokasi saya" ambil GPS terbaru bila izin ada;
     * lokasi pilihan di Atur tidak diubah. Bila "Kirim cuaca ke jam" menyala, cuaca terbaru ikut dikirim ke jam.
     */
    fun refreshWeatherFromCard() {
        if (weatherBusy.value || weatherWatchBusy.value) return
        pushWeatherAfterFetch = true
        val fine = ContextCompat.checkSelfPermission(a, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(a, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (isGpsLikePlace(weatherPlace.value) && (fine || coarse)) { useCurrentLocation(); return }
        val lat = weatherLat.value.toDoubleOrNull() ?: -6.99
        val lon = weatherLon.value.toDoubleOrNull() ?: 110.42
        fetchWeather(lat, lon, weatherPlace.value)
    }

    fun clearWeather() { weatherMessage.value="" }

    fun searchWeatherCity(query:String) = viewModelScope.launch {
        val q=query.trim(); if(q.isEmpty()) return@launch
        weatherBusy.value=true; weatherNotice.value=null; weatherMessage.value="Mencari lokasi…"
        try {
            val result=withContext(Dispatchers.IO) {
                val url=URL("https://geocoding-api.open-meteo.com/v1/search?count=1&language=id&name="+java.net.URLEncoder.encode(q,"UTF-8"))
                val c=url.openConnection() as HttpURLConnection
                try {
                    c.connectTimeout=10000; c.readTimeout=12000
                    val j=JSONObject(c.inputStream.bufferedReader().use{it.readText()})
                    val x=j.optJSONArray("results")?.optJSONObject(0)?:throw IllegalStateException("Kota tidak ditemukan")
                    Triple(x.getDouble("latitude"),x.getDouble("longitude"),listOf(x.optString("name"),x.optString("admin1"),x.optString("country")).filter{it.isNotBlank()}.joinToString(", "))
                } finally { c.disconnect() }
            }
            weatherBusy.value=false; fetchWeather(result.first,result.second,result.third)
        } catch(e:Exception) { weatherMessage.value="Pencarian lokasi gagal: ${e.message}"; weatherBusy.value=false }
    }

    @Suppress("MissingPermission")
    fun useCurrentLocation() {
        if (weatherBusy.value) return
        val fine=ContextCompat.checkSelfPermission(a,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED
        val coarse=ContextCompat.checkSelfPermission(a,Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED
        if(!fine&&!coarse){pushWeatherAfterFetch=false;weatherMessage.value="Izin lokasi belum diberikan. Tekan Gunakan GPS dan izinkan akses saat digunakan.";return}
        // Sibuk selama mencari GPS: ikon berputar dan ketukan berikutnya tidak menumpuk permintaan.
        weatherBusy.value = true; weatherNotice.value = null; weatherMessage.value = "Mencari lokasi GPS…"
        try {
            val lm=a.getSystemService(android.content.Context.LOCATION_SERVICE) as LocationManager
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                val provider = if (fine && lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) LocationManager.GPS_PROVIDER else LocationManager.NETWORK_PROVIDER
                lm.getCurrentLocation(provider, null, a.mainExecutor) { loc -> onGpsFix(loc) }
            } else {
                val loc=lm.getProviders(true).mapNotNull { provider -> runCatching { lm.getLastKnownLocation(provider) }.getOrNull() }.maxByOrNull { it.time }
                onGpsFix(loc)
            }
        } catch(e:Exception){ onGpsFix(null) }
    }

    /** Hasil GPS: berhasil -> cuaca di titik itu; gagal -> tetap muat cuaca (dan kirim ke jam) dari lokasi tersimpan, dengan catatan. */
    private fun onGpsFix(loc: android.location.Location?) {
        weatherBusy.value = false
        if (loc != null) { fetchWeather(loc.latitude, loc.longitude, "Lokasi saya"); return }
        weatherNotice.value = "GPS belum mendapat lokasi, memakai lokasi tersimpan."
        fetchWeather(weatherLat.value.toDoubleOrNull() ?: -6.99, weatherLon.value.toDoubleOrNull() ?: 110.42, weatherPlace.value)
    }

    fun sendWeatherToWatch(lat: Double, lon: Double, name: String) = viewModelScope.launch {
        if (weatherWatchBusy.value) return@launch
        weatherWatchBusy.value = true
        weatherWatchNote.value = "Mengirim lokasi & cuaca ke jam…"
        try {
            val raw = if (name == "Lokasi latihan") weatherPlace.value else name
            // Titik GPS dikirim dengan nama tempat sungguhan (bukan "Lokasi saya") bila reverse geocoding berhasil.
            val shown = if (!isGpsLikePlace(raw)) raw
                else weatherPlaceLabel.value.takeUnless { isGpsLikePlace(it) }
                    ?: withContext(Dispatchers.IO) { runCatching { reverseGeocodeName(lat, lon) }.getOrNull() }
                    ?: raw
            val result=bridgeCall { cb -> watchBridge.setWeather(JSONObject().put("enabled",true).put("lat",lat).put("lon",lon).put("name",shown).put("unit","celsius").put("intervalMinutes",60).toString(),cb) }
            weatherWatchStatus.value=result.toString()
            val refreshed=bridgeCall { cb -> watchBridge.refreshWeather(cb) }
            weatherWatchStatus.value=refreshed.toString()
            weatherWatchNote.value = "Lokasi & cuaca terkirim ke jam."
        } catch(e:Exception) {
            weatherWatchNote.value = "Pengiriman ke jam gagal: ${e.message}"
            weatherWatchStatus.value=runCatching{watchBridge.weatherStatus().toString()}.getOrDefault("{}")
        } finally { weatherWatchBusy.value = false }
        val shownNote = weatherWatchNote.value
        kotlinx.coroutines.delay(8_000)
        if (!weatherWatchBusy.value && weatherWatchNote.value == shownNote) weatherWatchNote.value = ""
    }

    fun setAgps(enabled:Boolean, mirror:String) = viewModelScope.launch {
        try { agpsStatus.value=bridgeCall { cb -> watchBridge.setAgps(JSONObject().put("enabled",enabled).put("mirrorUrl",mirror.trim()).toString(),cb) }.toString() }
        catch(e:Exception) { agpsStatus.value=runCatching{watchBridge.agpsStatus().put("lastError",e.message).toString()}.getOrDefault("{}") }
    }
    val agpsBusy = MutableStateFlow(false)
    val agpsNote = MutableStateFlow("")
    /** Tombol refresh kartu cuaca Beranda: muat ulang cuaca (lalu kirim ke jam) sekaligus unduh dan kirim A-GPS ke jam. */
    fun refreshWeatherAndAgps() { refreshWeatherFromCard(); sendAgpsFromCard() }
    private fun sendAgpsFromCard() {
        if (agpsBusy.value) return
        agpsBusy.value = true
        agpsNote.value = "Mengirim A-GPS ke jam…"
        viewModelScope.launch {
            try {
                bridgeCall { cb -> watchBridge.testAgps(cb) }; agpsStatus.value = watchBridge.agpsStatus().toString()
                agpsNote.value = "A-GPS terkirim."
            } catch (e: Exception) {
                agpsStatus.value = runCatching { watchBridge.agpsStatus().put("lastError", e.message).toString() }.getOrDefault("{}")
                agpsNote.value = "A-GPS gagal: ${e.message ?: e.javaClass.simpleName}"
            } finally { agpsBusy.value = false }
            val shown = agpsNote.value
            kotlinx.coroutines.delay(8_000)
            if (!agpsBusy.value && agpsNote.value == shown) agpsNote.value = ""
        }
    }
    fun testAgps() = viewModelScope.launch {
        try { bridgeCall { cb -> watchBridge.testAgps(cb) }; agpsStatus.value=watchBridge.agpsStatus().toString() }
        catch(e:Exception) { agpsStatus.value=runCatching{watchBridge.agpsStatus().put("lastError",e.message).toString()}.getOrDefault("{}") }
    }
    fun setWatchNotifications(enabled:Boolean, quiet:Boolean, start:Int, end:Int, screenOff:Boolean, apps:Map<String,Boolean> = emptyMap()) = viewModelScope.launch {
        try { val payload=JSONObject().put("enabled",enabled).put("quietEnabled",quiet).put("quietStart",start).put("quietEnd",end).put("onlyScreenOff",screenOff).put("apps",JSONObject(apps)); notifyStatus.value=bridgeCall { cb -> watchBridge.setNotify(payload.toString(),cb) }.toString() }
        catch(e:Exception) { notifyStatus.value=runCatching{watchBridge.notifyStatus().put("lastError",e.message).toString()}.getOrDefault("{}") }
    }
    fun testWatchNotification() = viewModelScope.launch {
        try { notifyStatus.value=bridgeCall { cb -> watchBridge.testNotify(cb) }.toString() }
        catch(e:Exception) { notifyStatus.value=runCatching{watchBridge.notifyStatus().put("lastError",e.message).toString()}.getOrDefault("{}") }
    }

    fun saveAiKey(value:String) {
        secretStore.put("groq_api_key",value.trim())
        aiKeySet.value=value.isNotBlank(); aiStatus.value=if(value.isBlank())"API key dihapus." else "API key tersimpan terenkripsi di Android Keystore."
    }

    /** Bahasa balasan AI Coach mengikuti bahasa aplikasi; data konteks di prompt tetap berbahasa Indonesia. */
    private fun coachReplyLanguage(): String =
        if (com.endurancevault.app.ui.i18n.Lang.current == com.endurancevault.app.ui.i18n.AppLang.EN)
            "Balas seluruhnya dalam bahasa Inggris (English), termasuk sapaan dan pertanyaan penutup, walau data di bawah berbahasa Indonesia"
        else "Jawab Bahasa Indonesia"

    /** Aturan aksi data untuk system prompt: coach hanya mengusulkan, pengguna yang menyetujui. */
    private val COACH_ACTION_RULES = "Kamu punya tool untuk MENGUSULKAN perubahan data (catat/ubah/hapus aktivitas, kondisi harian, nyeri/cedera, gear dan pemasangannya pada aktivitas, tandai/lewati sesi, ubah pengaturan, dan membuat sesi latihan terstruktur lalu mengirimnya ke jam). Untuk sesi ke jam, target intensitas dinyatakan sebagai zona HR 1..5 atau rentang pace, bukan angka bpm; aplikasi yang mengonversi dari zona pengguna. Jangan mengarang sesi di luar permintaan pengguna atau rencana yang tersedia. Panggil tool hanya bila pengguna jelas meminta perubahan data, jangan untuk pertanyaan biasa. Jangan menebak nilai yang tidak disebut pengguna: tanyakan dulu bila jarak, durasi, atau tanggal belum jelas. Perubahan baru berlaku setelah pengguna mengetuk Terapkan, jadi tulis satu kalimat singkat tentang apa yang kamu usulkan dan jangan bilang sudah tersimpan. Hapus data hanya bila diminta eksplisit."

    /** Tanpa rencana aktif (No plan atau plan error) tidak ada sesi yang bisa ditandai selesai atau dilewati; tool-nya juga tidak dikirim. */
    private fun coachRules(planActive: Boolean): String =
        if (planActive) COACH_ACTION_RULES
        else COACH_ACTION_RULES.replace("tandai/lewati sesi, ", "") + " Tidak ada rencana latihan aktif, jadi tidak ada sesi yang bisa ditandai selesai atau dilewati."

    /** Usulan aksi dari coach yang menunggu persetujuan pengguna (kartu konfirmasi di chat). */
    val aiPending = MutableStateFlow<List<CoachAction>>(emptyList())

    private class GroqHttpException(val code: Int, message: String) : IllegalStateException(message)

    private fun postGroq(key: String, body: JSONObject): JSONObject {
        val c = (URL("https://api.groq.com/openai/v1/chat/completions").openConnection() as HttpURLConnection).apply { requestMethod="POST";connectTimeout=15000;readTimeout=45000;doOutput=true;setRequestProperty("Authorization","Bearer $key");setRequestProperty("Content-Type","application/json") }
        try {
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val data = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw GroqHttpException(code, "Groq HTTP $code: ${runCatching { JSONObject(data).optJSONObject("error")?.optString("message") }.getOrNull() ?: data.take(180)}")
            return JSONObject(data)
        } finally { c.disconnect() }
    }

    fun sendAiQuestion(question:String, enteredKey:String, webSearch:Boolean = true, retry:Boolean = false) {
        val q=question.trim(); if(q.isEmpty()||aiBusy.value)return
        val key=enteredKey.trim().ifBlank { secretStore.get("groq_api_key").orEmpty() }
        if(key.isBlank()){aiStatus.value="Masukkan dan simpan Groq API key terlebih dahulu.";return}
        if(enteredKey.isNotBlank()) { secretStore.put("groq_api_key",enteredKey.trim()); aiKeySet.value=true }
        aiPending.value = emptyList() // usulan lama tidak berlaku lagi setelah percakapan lanjut
        val modelId = aiModel.value
        lastAiWebSearch = webSearch; aiRateLimited.value = false
        aiError.value=null; aiBusy.value=true; if (!retry) aiMessages.update { (it+ listOf("user" to q)).takeLast(16) }; aiStatus.value="Menganalisis data latihan dan menghubungi AI…"
        viewModelScope.launch {
            try {
                val (answer, parsed) = withContext(Dispatchers.IO) {
                    val todayD=java.time.LocalDate.now()
                    val sortedActs=state.value.activities.sortedByDescending{it.dateIso}
                    val cutIso=todayD.minusDays(com.endurancevault.app.domain.CoachContext.HABIT_WINDOW_DAYS.toLong()).toString()
                    val inWin=sortedActs.filter{it.dateIso.take(10)>=cutIso}
                    val recentActs=if(inWin.size>=12) inWin.take(40) else sortedActs.take(12)
                    // 8 aktivitas terbaru: struktur interval, HR bagian kerja, dan rasa lari supaya coach tidak menilai sesi threshold dari HR rata-rata
                    fun sessionNoteOf(ix: Int, x: ActivityEntity): String {
                        if (x.type == "bike") return ""
                        val d = if (ix < 8) runCatching { x.detailFile?.let { a.acts.read(it) } }.getOrNull() else null
                        val iv = com.endurancevault.app.domain.IntervalAnalysis.analyze(d)
                        val work = if (d != null) com.endurancevault.app.domain.FeelCheck.workEffort(d, state.value.hrHistByActivity[x.id].orEmpty(), false) else null
                        return com.endurancevault.app.domain.CoachContext.sessionNote(iv, work, x.feel10) ?: ""
                    }
                    val recent=recentActs.withIndex().joinToString("\n") { (ix, x) -> "#${x.id} ${x.dateIso} (${runCatching{com.endurancevault.app.domain.CoachContext.dayName(java.time.LocalDate.parse(x.dateIso.take(10)))}.getOrDefault("?")}, ${x.type}): ${x.km} km, ${x.durationSec/60} menit, pace ${if(x.km>0)"%.2f".format(Locale.US,x.durationSec/60.0/x.km) else "—"} menit/km, HR ${x.avgHr?:"—"}, elevasi ${x.gain?:"—"} m" + sessionNoteOf(ix, x) }
                    val daily=state.value.daily.take(7).joinToString("\n") { d -> "${d.dateIso}: tidur ${d.sleepH?:"—"} jam, HR istirahat ${d.rhr?:"—"}, HRV ${d.hrv?:"—"}, kaki ${d.leg?:"—"}/5, mood/stres ${d.mood?:"—"}/5" }
                    val plan=when(val p=state.value.plan){ is PlanOutcome.Ok -> if(p.none) com.endurancevault.app.domain.CoachContext.NO_PLAN_NOTE else p.weeks.flatMap{it.days}.filter{!it.date.isBefore(java.time.LocalDate.now())}.take(7).joinToString("\n"){d->"${d.date}: ${d.title}, ${d.km} km. ${d.detail}"}.ifBlank{com.endurancevault.app.domain.CoachContext.NO_SESSION_STATUS}; is PlanOutcome.Err -> "Rencana latihan tidak aktif (${p.message}). "+com.endurancevault.app.domain.CoachContext.NO_SESSION_STATUS }
                    val planActive=com.endurancevault.app.domain.CoachContext.planActive(state.value.plan)
                    val habit=com.endurancevault.app.domain.CoachContext.habitSummary(state.value.activities.filter{it.type=="run"}.mapNotNull{runCatching{java.time.LocalDate.parse(it.dateIso.take(10))}.getOrNull()}, todayD)
                    val runPts=state.value.activities.filter{it.type!="bike"}.mapNotNull{ x -> runCatching{ com.endurancevault.app.domain.CoachContext.RunPoint(java.time.LocalDate.parse(x.dateIso.take(10)), x.km, x.durationSec/60.0, x.avgHr) }.getOrNull() }
                    val trend=com.endurancevault.app.domain.CoachContext.trendSummary(runPts, todayD)
                    val tm=runCatching{ com.endurancevault.app.domain.TrainingMetrics.calculate(state.value.settings, state.value.activities, state.value.daily, state.value.plan, todayD, hrHistByActivity=state.value.hrHistByActivity, readinessConfig=com.endurancevault.app.data.ReadinessPrefs.load(a.getSharedPreferences(com.endurancevault.app.data.ReadinessPrefs.FILE,android.content.Context.MODE_PRIVATE))) }.getOrNull()
                    val recovery=com.endurancevault.app.domain.CoachContext.recoverySummary(tm)
                    val rests=com.endurancevault.app.domain.CoachContext.unplannedRestsSummary(com.endurancevault.app.domain.SessionAdjust.spHistory(state.value.mv, todayD))
                    val gearCtx=state.value.gear.filter{!it.retired}.joinToString("; "){ g -> g.name + (if(g.limitKm>0)" (batas ${g.limitKm.toInt()} km)" else "") }.ifBlank{"belum ada"}
                    val painCtx=runCatching{ val arr=JSONArray(a.getSharedPreferences("readiness_settings",android.content.Context.MODE_PRIVATE).getString("pain_entries","[]")); (0 until arr.length()).mapNotNull{arr.optJSONObject(it)}.sortedByDescending{it.optString("date")}.take(5).joinToString("; "){ o -> "${o.optString("date")} ${com.endurancevault.app.domain.InjuryPrevention.areaName(o.optString("area"))} ${com.endurancevault.app.domain.InjuryPrevention.sideName(o.optString("side"))} ${o.optInt("severity")}/5" } }.getOrDefault("").ifBlank{"tidak ada"}
                    val system="Kamu adalah AI Coach EnduranceVault. ${coachReplyLanguage()}, ringkas dan spesifik, dengan gaya hangat dan bersahabat seperti pelatih lari yang peduli: sapa singkat bila pas, kalimat pendek, boleh 1-2 emoji. Format dengan markdown ringan: **tebal** untuk poin penting dan daftar berpoin untuk saran atau langkah; jangan pakai tabel. Tutup dengan satu pertanyaan atau tawaran lanjutan yang singkat. Gunakan hanya data berikut; jangan mengarang angka atau mengubah rumus readiness/CTL/ATL/TSB/Training Effect. Jika data tidak tersedia, katakan tidak tersedia. Data aktivitas terbaru (awalan #id dipakai untuk edit/hapus):\n$recent\nKondisi harian (7 catatan terakhir):\n$daily\nRencana mendatang:\n$plan\n$habit\n$trend\n$recovery\nLibur dadakan 28 hari terakhir: $rests\nPengaturan: ${state.value.settings.name}; HR max ${state.value.settings.hr}; target pace ${state.value.settings.pace}. Gear aktif: $gearCtx. Catatan nyeri terbaru: $painCtx. Data pribadi hanya dikirim karena pengguna menekan tombol Kirim. Hari ini ${com.endurancevault.app.domain.CoachContext.dayName(todayD)} $todayD. ${com.endurancevault.app.domain.CoachContext.DECISION_GUIDE} ${com.endurancevault.app.domain.CoachContext.INTERVAL_GUIDE} ${coachRules(planActive)}"
                    val msgs=JSONArray().put(JSONObject().put("role","system").put("content",system))
                    aiMessages.value.takeLast(11).forEach { (role,msg) -> msgs.put(JSONObject().put("role",if(role=="coach")"assistant" else "user").put("content",msg)) }
                    fun request(withWeb: Boolean): JSONObject {
                        val tools = CoachActions.toolDefinitions(planActive)
                        if (withWeb) tools.put(JSONObject().put("type","browser_search"))
                        val body=JSONObject().put("model",modelId).put("messages",msgs).put("temperature",0.25).put("max_tokens",if(withWeb)1800 else 900).put("tools",tools).put("tool_choice","auto")
                        return postGroq(key, body)
                    }
                    // Bila model menolak gabungan tool pencarian web + tool aksi (HTTP 400), ulangi tanpa pencarian web agar aksi tetap jalan.
                    val resp = try { request(webSearch) } catch (e: GroqHttpException) { if (webSearch && e.code == 400) request(false) else throw e }
                    val msg = resp.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message") ?: throw IllegalStateException("Model tidak memberikan jawaban")
                    val text = msg.optString("content").trim()
                    val parsed = CoachActions.parse(msg.optJSONArray("tool_calls"))
                    if (text.isBlank() && parsed.actions.isEmpty() && parsed.rejected.isEmpty()) throw IllegalStateException("Model tidak memberikan jawaban")
                    text to parsed
                }
                val reply = buildString {
                    append(answer.ifBlank { if (parsed.actions.isNotEmpty()) "Ini perubahan yang aku usulkan. Cek dulu, lalu ketuk **Terapkan** bila sudah benar." else "Maaf, usulan perubahannya tidak bisa kupakai." })
                    if (parsed.rejected.isNotEmpty()) append("\n\n⚠️ Usulan ditolak karena tidak valid: ").append(parsed.rejected.joinToString("; "))
                }
                aiMessages.update { (it+ listOf("coach" to reply)).takeLast(16) }
                aiPending.value = parsed.actions
                aiStatus.value=if(parsed.actions.isNotEmpty())"Menunggu persetujuan untuk ${parsed.actions.size} perubahan data." else if(webSearch)"Jawaban diterima dari Groq · ${aiModelLabel(modelId)} (pencarian web diizinkan)." else "Jawaban diterima dari Groq · ${aiModelLabel(modelId)}."
            } catch(e:Exception) { if (e is GroqHttpException && e.code == 429) aiRateLimited.value = true; aiStatus.value="AI Coach gagal: ${e.message ?: e.javaClass.simpleName}"; aiError.value=aiStatus.value }
            finally { aiBusy.value=false }
        }
    }

    /** Pengguna menyetujui usulan coach: tulis tiap aksi ke data aplikasi, lalu laporkan hasilnya di chat. */
    fun applyAiActions() {
        val list = aiPending.value
        if (list.isEmpty() || aiBusy.value) return
        aiPending.value = emptyList()
        aiBusy.value = true
        viewModelScope.launch {
            try {
                val lines = withContext(Dispatchers.IO) {
                    list.map { act -> runCatching { executeCoachAction(act) }.getOrElse { "❌ ${act.summary}: ${it.message ?: it.javaClass.simpleName}" } }
                }
                aiMessages.update { (it + listOf("coach" to lines.joinToString("\n"))).takeLast(16) }
                aiStatus.value = "Perubahan data diterapkan."
            } finally { aiBusy.value = false }
        }
    }

    /** Pengguna menolak usulan coach; tidak ada data yang berubah. */
    fun dismissAiActions() {
        if (aiPending.value.isEmpty()) return
        aiPending.value = emptyList()
        aiMessages.update { (it + listOf("coach" to "Oke, tidak ada data yang diubah.")).takeLast(16) }
    }

    /** Pesan penolakan untuk aksi sesi rencana: bedakan "tidak ada rencana aktif" dari "tidak ada sesi di tanggal itu". */
    private fun noSessionMessage(dateIso: String): String =
        if (!com.endurancevault.app.domain.CoachContext.planActive(state.value.plan)) "⚠️ Tidak ada rencana latihan aktif, jadi tidak ada sesi yang bisa ditandai atau dilewati."
        else "⚠️ Tidak ada sesi latihan pada $dateIso."

    /** Jalankan satu aksi yang sudah disetujui. Mengembalikan baris hasil (✅ berhasil, ⚠️ dilewati). Dipanggil di Dispatchers.IO. */
    private suspend fun executeCoachAction(act: CoachAction): String {
        val acts = a.db.activities(); val comp = a.db.companion()
        return when (act) {
            is CoachAction.AddActivity -> {
                val dup = acts.byDateAndType(act.dateIso, act.type).firstOrNull { kotlin.math.abs(it.km - act.km) < 0.05 && kotlin.math.abs(it.durationSec - act.durationSec) < 120 }
                if (dup != null) "⚠️ Dilewati: ${act.dateIso} ${act.km} km sudah tercatat (#${dup.id})."
                else {
                    val id = acts.insert(ActivityEntity(
                        dateIso = act.dateIso, km = act.km, durationSec = act.durationSec, avgHr = act.avgHr, feel = act.feel10?.let { (it + 1) / 2 },
                        note = act.note, name = act.name, gain = act.gain, startTime = act.startTime, maxHr = act.maxHr, type = act.type, feel10 = act.feel10,
                    ))
                    "✅ ${act.summary} (#$id)"
                }
            }
            is CoachAction.EditActivity -> {
                val e = acts.byId(act.id) ?: return "⚠️ Aktivitas #${act.id} tidak ditemukan."
                val err = editActivity(
                    act.id, act.name ?: e.name, act.description ?: com.endurancevault.app.domain.ActEdit.userNote(e.note),
                    act.type ?: e.type, act.dateIso ?: e.dateIso, act.startTime ?: e.startTime.orEmpty(),
                )
                if (err == null) "✅ ${act.summary}" else "❌ ${act.summary}: $err"
            }
            is CoachAction.SetActivityFeel -> {
                if (acts.byId(act.id) == null) "⚠️ Aktivitas #${act.id} tidak ditemukan."
                else { acts.setFeel(act.id, act.feel10?.let { (it + 1) / 2 }, act.feel10); "✅ ${act.summary}" }
            }
            is CoachAction.DeleteActivity -> {
                if (acts.byId(act.id) == null) "⚠️ Aktivitas #${act.id} tidak ditemukan."
                else { deleteActivity(act.id).join(); "✅ Aktivitas #${act.id} dihapus." }
            }
            is CoachAction.SaveDaily -> {
                val cur = comp.allDaily().firstOrNull { it.dateIso == act.dateIso } ?: DailyEntity(dateIso = act.dateIso)
                comp.saveDaily(cur.copy(
                    sleepH = act.sleepH ?: cur.sleepH, rhr = act.rhr ?: cur.rhr, hrv = act.hrv ?: cur.hrv,
                    leg = act.leg ?: cur.leg, mood = act.mood ?: cur.mood,
                ))
                "✅ ${act.summary}"
            }
            is CoachAction.AddGear -> {
                if (comp.allGear().any { it.name.equals(act.name, true) && !it.retired }) "⚠️ Gear \"${act.name}\" sudah ada."
                else { comp.saveGear(GearEntity(java.util.UUID.randomUUID().toString(), act.name, act.model, act.km0, act.limitKm)); "✅ ${act.summary}" }
            }
            is CoachAction.LogPain -> {
                // Format sama dengan layar Nyeri dan cedera / Training Readiness: SharedPreferences readiness_settings -> pain_entries.
                val prefs = a.getSharedPreferences("readiness_settings", android.content.Context.MODE_PRIVATE)
                synchronized(prefs) {
                    val old = runCatching { JSONArray(prefs.getString("pain_entries", "[]")) }.getOrDefault(JSONArray())
                    val kept = (0 until old.length()).mapNotNull { i -> old.optJSONObject(i) }
                        .filterNot { it.optString("date") == act.dateIso && it.optString("area") == act.area && it.optString("side") == act.side }
                    val next = (kept + JSONObject().put("date", act.dateIso).put("area", act.area).put("severity", act.severity).put("side", act.side).put("when", act.moment)).takeLast(300)
                    prefs.edit().putString("pain_entries", JSONArray(next).toString()).apply()
                }
                "✅ ${act.summary}"
            }
            is CoachAction.SetActivityGear -> {
                val gear = comp.allGear().firstOrNull { it.name.equals(act.gearName, true) && !it.retired }
                    ?: return "⚠️ Gear \"${act.gearName}\" tidak ditemukan. Tambahkan dulu atau cek namanya."
                val target = act.activityId?.let { acts.byId(it) }
                    ?: if (act.activityId == null) acts.all().filter { it.type != "bike" }.maxWithOrNull(compareBy<ActivityEntity>({ it.dateIso }, { it.id })) else null
                if (target == null) "⚠️ Aktivitas ${act.activityId?.let { "#$it" } ?: com.endurancevault.app.ui.i18n.Lang.tr("lari")} tidak ditemukan."
                else if (target.type == "bike") "⚠️ Gear hanya bisa dipasang pada aktivitas lari."
                else { acts.setGear(target.id, gear.id); "✅ Gear \"${gear.name}\" dipasang pada ${target.dateIso} ${target.km} km (#${target.id})." }
            }
            is CoachAction.SendWorkout -> sendCoachWorkout(act)
            is CoachAction.SetSessionDone -> {
                // Menandai selesai hanya untuk hari yang punya sesi di rencana aktif; membatalkan tanda selalu boleh (bersihkan tanda lama).
                if (act.done && !com.endurancevault.app.domain.CoachContext.hasSessionOn(state.value.plan, act.dateIso)) noSessionMessage(act.dateIso)
                else { setDone(act.dateIso, act.done).join(); "✅ ${act.summary}" }
            }
            is CoachAction.SkipSession -> {
                if (!com.endurancevault.app.domain.CoachContext.hasSessionOn(state.value.plan, act.dateIso)) noSessionMessage(act.dateIso)
                else { setMv(act.dateIso, com.endurancevault.app.domain.MvEntry("skip")).join(); "✅ ${act.summary}" }
            }
            is CoachAction.UpdateSettings -> { saveSettings(CoachActions.applySettings(state.value.settings, act.changes)); "✅ ${act.summary}" }
        }
    }

    /**
     * Kirim sesi terstruktur usulan coach ke jam lewat jalur yang sama dengan form Structured workout. Zona HR dikonversi dari zona
     * pengguna (HR maks dan batas zona di Pengaturan), jadi angka bpm tidak pernah berasal dari model. Menunggu jawaban jam sampai 60 detik.
     */
    private suspend fun sendCoachWorkout(w: CoachAction.SendWorkout): String {
        val st = state.value
        val cuts = com.endurancevault.app.domain.Zones.cuts(st.settings, com.endurancevault.app.ui.screens.restHrFrom(st.daily).first)
        val lower = com.endurancevault.app.domain.StructuredWorkout.watchLowerBounds(cuts.mode, cuts.lo, cuts.maxHr)
        val targets = CoachActions.workoutTargets(w, lower, cuts.maxHr)
        com.endurancevault.app.domain.StructuredWorkout.validate(w.warmupMin, w.repeats, w.runMin, w.recoveryMin, w.cooldownMin, targets)
            ?.let { return "⚠️ Workout tidak dikirim: $it" }
        val payload = com.endurancevault.app.domain.StructuredWorkout.buildPayload("ev-${System.currentTimeMillis()}", w.name, w.warmupMin, w.repeats, w.runMin, w.recoveryMin, w.cooldownMin, targets)
        val result = kotlinx.coroutines.withTimeoutOrNull(60_000L) {
            suspendCancellableCoroutine<String> { cont ->
                try {
                    watchBridge.pushCourses(payload.toString(), object : ProtocolGateway.Callback {
                        override fun ok(result: JSONObject) {
                            val sent = result.optInt("sent"); val failed = result.optInt("failed")
                            if (cont.isActive) cont.resume(if (sent > 0 && failed == 0) "✅ ${w.summary}. Terkirim ke jam; cek di daftar latihan jam." else "⚠️ Workout dikirim: $sent berhasil, $failed gagal. Periksa jam dan log protokol.") {}
                        }
                        override fun error(code: String, message: String) { if (cont.isActive) cont.resume("⚠️ Pengiriman ke jam gagal [$code]: $message") {} }
                    })
                } catch (e: Exception) { if (cont.isActive) cont.resume("⚠️ Pengiriman ke jam gagal: ${e.message ?: e.javaClass.simpleName}") {} }
            }
        }
        return result ?: "⚠️ Jam belum menjawab dalam 60 detik. Pastikan jam terhubung, lalu minta coach mengirim ulang."
    }

    /** Simpan (atau hapus bila [entry] null) satu entri `mv`: tukar hari "sw:tanggal", libur dadakan, geser, lewati. */
    fun setMv(key: String, entry: com.endurancevault.app.domain.MvEntry?) = viewModelScope.launch(Dispatchers.IO) {
        kvMutex.withLock {
            val dao = a.db.companion()
            val map = com.endurancevault.app.data.MvStore.parse(dao.kv("mv")).toMutableMap()
            if (entry == null) map.remove(key) else map[key] = entry
            dao.putKv(listOf(KvEntity("mv", com.endurancevault.app.data.MvStore.toJson(map))))
        }
    }

    /** Centang manual sesi selesai. Kunci: "tanggal" untuk lari, "tanggal:s", "tanggal:a", "tanggal:u" untuk strength/ankle/upper. */
    fun setDone(key: String, value: Boolean) = viewModelScope.launch(Dispatchers.IO) {
        kvMutex.withLock {
            val dao = a.db.companion()
            dao.putKv(listOf(KvEntity("done", com.endurancevault.app.data.MvStore.doneJson(dao.kv("done"), key, value))))
        }
    }

    /** Sekali jalan: pindahkan tukar jadwal dan libur dadakan lama (SharedPreferences) ke format mv bila mv belum ada. */
    private fun migrateLegacyAdjustments() = viewModelScope.launch(Dispatchers.IO) {
        runCatching {
            val prefs = a.getSharedPreferences("week_adjustments_v1", android.content.Context.MODE_PRIVATE)
            if (prefs.getBoolean("migrated_mv", false)) return@runCatching
            kvMutex.withLock {
                val dao = a.db.companion()
                val legacy = com.endurancevault.app.data.MvStore.fromLegacy(prefs.getString("data", "{}"))
                if (legacy.isNotEmpty()) {
                    val cur = com.endurancevault.app.data.MvStore.parse(dao.kv("mv")).toMutableMap()
                    legacy.forEach { (k, v) -> if (k !in cur) cur[k] = v }
                    dao.putKv(listOf(KvEntity("mv", com.endurancevault.app.data.MvStore.toJson(cur))))
                }
                prefs.edit().putBoolean("migrated_mv", true).apply()
            }
        }
    }

    fun saveSettings(s: PlanSettings) {
        com.endurancevault.app.AppLog.add("settings", "save rtype=${s.rtype} start=${s.start} race=${s.race} base=${s.base} peak=${s.peak} name='${s.name}' dari ${com.endurancevault.app.AppLog.caller()}")
        a.settings.save(s)
        settingsFlow.update { s }
    }

    fun addActivity(e: ActivityEntity) = viewModelScope.launch { a.db.activities().insert(e) }

    /**
     * Hapus aktivitas beserta berkas detailnya (rute, grafik). Aktivitas yang berasal dari jam dicatat di daftar
     * "sudah dihapus" supaya sinkron jam berikutnya tidak memasukkannya lagi.
     */
    fun deleteActivity(id: Long) = viewModelScope.launch(Dispatchers.IO) {
        val e = a.db.activities().byId(id) ?: return@launch
        val detail = e.detailFile?.let { a.acts.readMap(it) }
        val keys = ActTombstones.keysFor(e.srcKey, e.type, e.dateIso, e.startTime, e.note, detail)
        if (keys.isNotEmpty()) kvMutex.withLock {
            val dao = a.db.companion()
            val merged = ActTombstones.parse(dao.kv(ActTombstones.KV_KEY)) + keys
            dao.putKv(listOf(KvEntity(ActTombstones.KV_KEY, ActTombstones.toJson(merged))))
        }
        a.db.activities().delete(id)
        // Berkas dibuang hanya bila tidak dipakai baris lain (mis. sisa penggabungan duplikat).
        e.detailFile?.let { name ->
            if (a.db.activities().all().none { it.detailFile == name }) a.acts.delete(name)
        }
    }

    /**
     * Crop: pertahankan detik [startSec]..[endSec] (detik bergerak), buang sisanya, dan hitung ulang seluruh statistik.
     * Mengembalikan null bila berhasil, atau pesan galat. Tidak bisa dibatalkan.
     */
    suspend fun cropActivity(id: Long, startSec: Int, endSec: Int): String? = withContext(Dispatchers.IO) {
        runCatching {
            val e = a.db.activities().byId(id) ?: return@runCatching "Aktivitas tidak ditemukan"
            val file = e.detailFile ?: return@runCatching "Aktivitas ini belum punya data detail"
            val act = a.acts.readMap(file) ?: return@runCatching "Detail aktivitas tidak bisa dibaca"
            val r = ActCrop.crop(act, startSec, endSec)
            a.acts.write(file, r.act)
            a.db.activities().update(
                e.copy(
                    km = r.km, durationSec = r.durationSec, avgHr = r.avgHr, maxHr = r.maxHr, gain = r.gain,
                    note = ActEdit.markCropped(ActEdit.withWatchStart(e.note, act)),
                ),
            )
            null
        }.getOrElse { it.message ?: "Crop gagal" }
    }

    /** Edit ala Strava: nama, deskripsi, tipe (run/bike), tanggal, jam mulai. Null = berhasil, selain itu pesan galat. */
    suspend fun editActivity(id: Long, name: String, description: String, type: String, dateIso: String, startTime: String): String? =
        withContext(Dispatchers.IO) {
            runCatching {
                val e = a.db.activities().byId(id) ?: return@runCatching "Aktivitas tidak ditemukan"
                val date = dateIso.trim(); val time = startTime.trim()
                ActEdit.validate(date, time, type)?.let { return@runCatching it }
                val act = e.detailFile?.let { a.acts.readMap(it) }
                val fields = ActEdit.Fields(
                    name.trim(), ActEdit.withUserNote(ActEdit.withWatchStart(e.note, act), description), type, date, time.ifEmpty { null } ?: e.startTime,
                )
                if (act != null) a.acts.write(e.detailFile!!, ActEdit.applyToDetail(act, fields))
                a.db.activities().update(
                    e.copy(
                        name = fields.name, note = fields.note, type = type, dateIso = date, startTime = fields.startTime,
                        gearId = if (type == "bike") null else e.gearId,
                    ),
                )
                null
            }.getOrElse { it.message ?: "Gagal menyimpan" }
        }

    /**
     * Simpan pembagian segmen manual (waktu/jarak) ke kunci `sg` berkas detail. [drafts] kosong = hapus semua segmen.
     * Statistik tiap segmen dihitung dari deret 1 Hz; angka sesi utuh tidak berubah. Null = berhasil, selain itu pesan galat.
     */
    suspend fun saveSegments(id: Long, drafts: List<SegmentSplit.Draft>): String? = withContext(Dispatchers.IO) {
        runCatching {
            val e = a.db.activities().byId(id) ?: return@runCatching "Aktivitas tidak ditemukan"
            val file = e.detailFile ?: return@runCatching "Aktivitas ini belum punya data detail"
            val act = a.acts.readMap(file) ?: return@runCatching "Detail aktivitas tidak bisa dibaca"
            val out = LinkedHashMap<String, Any?>(act)
            if (drafts.isEmpty()) out.remove("sg")
            else {
                val ts = ActCrop.seriesOf(act) ?: return@runCatching "Aktivitas ini tidak punya data per detik"
                SegmentSplit.validate(ts, drafts)?.let { return@runCatching it }
                val (gs, ls) = SegmentSplit.elevScales(act)
                out["sg"] = SegmentSplit.toMaps(SegmentSplit.toSegments(ts, drafts, gs, ls))
            }
            a.acts.write(file, out)
            null
        }.getOrElse { it.message ?: "Gagal menyimpan segmen" }
    }

    private var pendingDuplicatePairs: List<Pair<ActivityEntity, ActivityEntity>> = emptyList()
    private val dupMutex = kotlinx.coroutines.sync.Mutex()

    /** Jumlah pasangan kandidat duplikat yang menunggu konfirmasi (kartu peringatan di Hari ini). */
    val duplicateCount = MutableStateFlow(0)
    /** Pesan singkat hasil gabung otomatis; dikosongkan saat kartu ditutup. */
    val duplicateNotice = MutableStateFlow("")

    init {
        // Pindai otomatis tiap daftar aktivitas berubah (impor, sinkron jam, catat manual); ditunda sebentar agar tidak berulang saat impor massal.
        viewModelScope.launch {
            a.db.activities().observeAll().collectLatest { rows ->
                kotlinx.coroutines.delay(1500)
                autoScanDuplicates(rows)
            }
        }
    }

    private suspend fun autoScanDuplicates(rows: List<ActivityEntity>) {
        dupMutex.withLock {
            val pairs = ActivityDuplicates.findPairs(rows)
            val sure = pairs.filter { ActivityDuplicates.highConfidence(it.first, it.second) }
            val merged = if (sure.isNotEmpty()) mergePairs(sure) else 0
            if (merged > 0) duplicateNotice.value = "$merged aktivitas ganda digabung otomatis. Detail jam/rute dan catatan manual dipertahankan."
            val remaining = pairs.filter { p -> sure.none { it === p } }
            pendingDuplicatePairs = remaining
            duplicateCount.value = remaining.size
        }
    }

    fun dismissDuplicateNotice() { duplicateNotice.value = "" }

    fun scanDuplicateActivities() = viewModelScope.launch {
        duplicateStatus.value = "Memeriksa aktivitas…"
        val rows = withContext(Dispatchers.IO) { a.db.activities().observeAll().first() }
        val pairs = ActivityDuplicates.findPairs(rows)
        pendingDuplicatePairs = pairs
        duplicateCount.value = pairs.size
        duplicateStatus.value = if (pairs.isEmpty()) {
            "Tidak ditemukan aktivitas ganda."
        } else {
            "Ditemukan ${pairs.size} pasangan kandidat:\n" + pairs.take(12).joinToString("\n") { (a1, b1) ->
                val keeper = if (a1.detailFile != null) a1 else b1.takeIf { it.detailFile != null } ?: a1
                val other = if (keeper.id == a1.id) b1 else a1
                "${keeper.dateIso} · ${keeper.type} · ${"%.2f".format(keeper.km)} km / ${keeper.durationSec / 60} mnt ↔ ${"%.2f".format(other.km)} km / ${other.durationSec / 60} mnt"
            } + if (pairs.size > 12) "\n…dan ${pairs.size - 12} pasangan lainnya." else ""
        }
    }

    /** Gabungkan pasangan yang masih memenuhi kriteria; mengembalikan jumlah yang digabung. */
    private suspend fun mergePairs(pairs: List<Pair<ActivityEntity, ActivityEntity>>): Int {
        val dao = a.db.activities()
        var merged = 0
        withContext(Dispatchers.IO) {
            pairs.forEach { (first, second) ->
                val currentA = dao.byId(first.id) ?: return@forEach
                val currentB = dao.byId(second.id) ?: return@forEach
                if (!ActivityDuplicates.sameActivity(currentA, currentB)) return@forEach
                val primary = if (currentA.detailFile != null) currentA else if (currentB.detailFile != null) currentB else currentA
                val secondary = if (primary.id == currentA.id) currentB else currentA
                val mergedRow = primary.copy(
                    feel = primary.feel ?: secondary.feel,
                    feel10 = primary.feel10 ?: secondary.feel10,
                    note = primary.note.ifBlank { secondary.note },
                    name = primary.name.ifBlank { secondary.name },
                    gearId = primary.gearId ?: secondary.gearId,
                    avgHr = primary.avgHr ?: secondary.avgHr,
                    maxHr = primary.maxHr ?: secondary.maxHr,
                    gain = primary.gain ?: secondary.gain,
                    detailFile = primary.detailFile ?: secondary.detailFile,
                    srcKey = primary.srcKey.ifBlank { secondary.srcKey },
                    startTime = primary.startTime ?: secondary.startTime,
                )
                dao.mergeDuplicate(mergedRow, secondary.id)
                merged++
            }
        }
        return merged
    }

    fun mergeDuplicateActivities() = viewModelScope.launch {
        val pairs = pendingDuplicatePairs
        if (pairs.isEmpty()) {
            duplicateStatus.value = "Belum ada kandidat. Jalankan pemeriksaan terlebih dahulu."
            return@launch
        }
        duplicateStatus.value = "Menggabungkan ${pairs.size} pasangan…"
        val merged = dupMutex.withLock { mergePairs(pairs) }
        pendingDuplicatePairs = emptyList()
        duplicateCount.value = 0
        duplicateStatus.value = if (merged > 0) {
            "$merged aktivitas ganda digabung. Detail jam/rute dan catatan manual dipertahankan."
        } else {
            "Tidak ada pasangan yang masih memenuhi kriteria untuk digabung."
        }
    }

    /** Catatan kesiapan harian disimpan native di Room; tanggal menjadi identitas unik. */
    fun saveDaily(item: DailyEntity) = viewModelScope.launch { a.db.companion().saveDaily(item) }

    /** Gear dapat diperbarui/dipensiunkan tanpa menghapus riwayat aktivitas yang pernah memakainya. */
    fun saveGear(item: GearEntity) = viewModelScope.launch { a.db.companion().saveGear(item) }
    fun deleteGear(id: String) = viewModelScope.launch { a.db.companion().deleteGear(id) }

    /** Salin berkas ke penyimpanan aplikasi (utuh, tanpa kehilangan data), lalu baca ringkasannya. */
    fun startImport(uri: Uri) {
        importState.value = ImportUi.Working
        viewModelScope.launch {
            importState.value = try {
                val picked = withContext(Dispatchers.IO) {
                    val dir = File(a.filesDir, "imports").apply { mkdirs() }
                    val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
                    val f = File(dir, "cadangan-web-$stamp.json")
                    val ins = a.contentResolver.openInputStream(uri) ?: throw BackupException("Berkas tidak bisa dibuka.")
                    ins.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                    try {
                        f to f.inputStream().use { BackupParser.parse(it) }
                    } catch (e: BackupException) {
                        f.delete(); throw e
                    }
                }
                ImportUi.Confirm(picked.second, picked.first)
            } catch (e: BackupException) {
                ImportUi.Failed(e.message ?: "Cadangan tidak bisa dibaca.")
            } catch (e: Exception) {
                ImportUi.Failed("Gagal membaca berkas: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    fun confirmImport() {
        val c = importState.value as? ImportUi.Confirm ?: return
        importState.value = ImportUi.Working
        viewModelScope.launch {
            try {
                // Extract into staging first. A malformed/truncated `acts` section must never
                // erase detail files that are currently referenced by the live database.
                val staging = File(a.cacheDir, "backup-acts-${System.nanoTime()}").apply { mkdirs() }
                var restoredActivities: List<ActivityEntity> = emptyList()
                try {
                    val keys = withContext(Dispatchers.IO) {
                        c.file.inputStream().use { BackupParser.extractActs(it, staging) }
                    }.toSet()
                    restoredActivities = c.backup.activities.map {
                        if (it.srcKey in keys) it.copy(detailFile = ActStore.backupFileName(it.srcKey)) else it
                    }
                    a.db.activities().replaceImported(restoredActivities)
                    a.db.companion().replaceAll(c.backup.daily, c.backup.gear, c.backup.kv.map { KvEntity(it.key, it.value) })
                    withContext(Dispatchers.IO) { a.acts.installBackupFiles(staging) }
                    saveSettings(c.backup.settings)
                } finally {
                    staging.deleteRecursively()
                }
                importState.value = ImportUi.Done(
                    "Pengaturan rencana, ${restoredActivities.size} catatan lari (${restoredActivities.count { it.detailFile != null }} dengan rute dan grafik), ${c.backup.daily.size} catatan harian, dan ${c.backup.gear.size} gear dipulihkan. Salinan lengkap cadangan disimpan di penyimpanan aplikasi.",
                )
            } catch (e: Exception) {
                importState.value = ImportUi.Failed("Gagal memulihkan: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    /** Impor satu atau beberapa berkas FIT/GPX/TCX sebagai aktivitas dengan rute dan grafik. */
    fun importTracks(uris: List<Uri>) {
        trackMsg.value = "Membaca ${uris.size} berkas…"
        viewModelScope.launch {
            var added = 0; var attached = 0; var skipped = 0; var upgraded = 0
            val errs = mutableListOf<String>()
            for ((i, u) in uris.withIndex()) {
                try {
                    val act = withContext(Dispatchers.IO) {
                        val bytes = a.contentResolver.openInputStream(u)?.use { it.readBytes() }
                            ?: throw ActImportException("berkas tidak bisa dibuka")
                        if (bytes.size > 80_000_000) throw ActImportException("berkas terlalu besar (maks 80 MB)")
                        val t = TrackParsers.parse(bytes)
                        ActBuilder.build(t.pts, t.sport, t.name)
                    }
                    when (ingestBuiltAct(act)) { 0 -> added++; 1 -> attached++; 2 -> upgraded++; else -> skipped++ }
                } catch (e: ActImportException) {
                    errs.add("berkas ${i + 1}: ${e.message}")
                } catch (e: Exception) {
                    errs.add("berkas ${i + 1}: ${e.message ?: e.javaClass.simpleName}")
                }
            }
            trackMsg.value = buildString {
                append("$added aktivitas baru")
                if (attached > 0) append(", $attached dilengkapi rute dan grafik")
                if (upgraded > 0) append(", $upgraded dilengkapi jejak GPS untuk GPX akurat")
                if (skipped > 0) append(", $skipped sudah ada")
                if (errs.isNotEmpty()) append(". Gagal: " + errs.joinToString("; "))
                append(".")
            }
        }
    }

    /**
     * Simpan satu aktivitas hasil [ActBuilder.build] (dipakai impor FIT/GPX/TCX dan impor zip Huawei Health).
     * Mengembalikan 0 = aktivitas baru, 1 = melengkapi catatan lama yang belum punya detail,
     * 2 = jejak GPS asli ditambahkan ke detail lama, 3 = sudah ada (dilewati).
     */
    private suspend fun ingestBuiltAct(act: Map<String, Any?>): Int {
        val date = act["date"] as String; val st = act["st"] as String
        val km = act["km"] as Double
        val impType = if (act["bike"] == true) "bike" else "run"
        val impSec = Math.round((act["min"] as Double) * 60).toInt()
        val existing = state.value.activities.firstOrNull {
            com.endurancevault.app.domain.ActivityDuplicates.matchesImport(it, date, st, km, impSec, impType)
        }
        if (existing != null && existing.detailFile != null) {
            // Sudah punya detail: hanya tambahkan jejak GPS asli bila detail lama belum punya dan lintasannya sama.
            val file = existing.detailFile!!
            return if (withContext(Dispatchers.IO) { upgradeGpsTrack(file, act) }) 2 else 3
        }
        val id = existing?.id ?: a.db.activities().insert(
            ActivityEntity(
                dateIso = date, km = km, durationSec = impSec,
                avgHr = (act["hr"] as? Double)?.toInt(), maxHr = (act["hrMax"] as? Double)?.toInt(),
                gain = (act["gain"] as? Double)?.toInt(), startTime = st, name = act["nm"] as String,
                type = impType,
            ),
        )
        val file = ActStore.importFileName(id)
        withContext(Dispatchers.IO) { a.acts.write(file, act) }
        a.db.activities().setDetail(id, file)
        return if (existing != null) 1 else 0
    }

    /**
     * Impor ekspor data Huawei Health (HUAWEI_HEALTH_*.zip): hanya folder "Motion path detail data" yang dibaca,
     * tiap rekaman latihan GPS (lari, sepeda, hiking) menjadi aktivitas dengan rute, HR, dan ketinggian.
     * [password] kosong untuk zip tanpa kata sandi.
     */
    fun importHuaweiZip(uri: Uri, password: String) {
        trackMsg.value = "Membaca zip Huawei Health… (ekspor besar bisa beberapa menit)"
        viewModelScope.launch {
            var added = 0; var attached = 0; var upgraded = 0; var dup = 0; var read = 0
            val skips = LinkedHashMap<String, Int>()
            val seen = HashSet<Long>()
            val pw = password.takeIf { it.isNotEmpty() }?.toCharArray()
            try {
                val stats = withContext(Dispatchers.IO) {
                    com.endurancevault.app.data.HuaweiHealthZip.scan(a.contentResolver, uri, pw) { rec ->
                        read++
                        trackMsg.value = "Membaca aktivitas Huawei: $read dibaca…"
                        val startMs = com.endurancevault.app.data.HuaweiMotionPath.startMs(rec)
                        if (startMs != null && !seen.add(startMs)) { dup++; return@scan }
                        try {
                            val conv = com.endurancevault.app.data.HuaweiMotionPath.convert(rec)
                            val act = ActBuilder.build(conv.track.pts, conv.track.sport, conv.track.name, conv.zone, cadScale = 1)
                            when (ingestBuiltAct(act)) { 0 -> added++; 1 -> attached++; 2 -> upgraded++; else -> dup++ }
                        } catch (e: com.endurancevault.app.data.HuaweiMotionPath.Skip) {
                            skips[e.reason] = (skips[e.reason] ?: 0) + 1
                        } catch (e: ActImportException) {
                            skips[e.message ?: "tidak valid"] = (skips[e.message ?: "tidak valid"] ?: 0) + 1
                        } catch (e: kotlinx.coroutines.CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            // Satu rekaman gagal tidak boleh menghentikan sisa zip.
                            skips["gagal disimpan"] = (skips["gagal disimpan"] ?: 0) + 1
                        }
                    }
                }
                trackMsg.value = if (stats.jsonFiles == 0) {
                    "Gagal: tidak ada folder Motion path detail data di zip ini. Pastikan ini ekspor HUAWEI_HEALTH dengan data jalur gerak."
                } else buildString {
                    append("$added aktivitas baru dari Huawei Health")
                    if (attached > 0) append(", $attached dilengkapi rute dan grafik")
                    if (upgraded > 0) append(", $upgraded dilengkapi jejak GPS")
                    if (dup > 0) append(", $dup sudah ada")
                    if (skips.isNotEmpty()) append(". Dilewati: " + skips.entries.joinToString(", ") { "${it.value}× ${it.key}" })
                    if (stats.badFiles > 0) append(". ${stats.badFiles} berkas JSON tidak terbaca")
                    append(".")
                }
            } catch (e: com.endurancevault.app.data.HuaweiHealthZip.WrongPasswordException) {
                trackMsg.value = "Gagal: kata sandi zip salah atau belum diisi."
            } catch (e: Exception) {
                trackMsg.value = "Gagal membaca zip: ${e.message ?: e.javaClass.simpleName}" +
                    if (added + attached + upgraded > 0) " ($added aktivitas sempat masuk)" else ""
            }
        }
    }

    /** Hubungkan langsung ke jam Huawei melalui protokol Bluetooth turunan Gadgetbridge yang sudah ada di proyek sumber. */
    fun connectWatch(address: String) {
        watchMessage.value = "Menghubungkan ke jam… konfirmasi permintaan ikatan pada layar jam bila muncul."
        watchBridge.connect(address, object : ProtocolGateway.Callback {
            override fun ok(result: JSONObject) {
                KeepAliveConfig.setWanted(a, true)
                val keep = KeepAliveConfig.start(a)
                watchMessage.value = buildString {
                    append("Terhubung: ").append(result.optString("name", "Huawei Watch"))
                    result.optString("model").takeIf { it.isNotBlank() }?.let { append(" · ").append(it) }
                    append(".")
                    if (keep != null) append(" Penjagaan latar belum aktif: ").append(keep)
                    else append(" Penjagaan koneksi latar aktif.")
                }
                syncWatch(false)
            }
            override fun error(code: String, message: String) {
                watchMessage.value = "Gagal menghubungkan [$code]: $message"
            }
        })
    }

    fun disconnectWatch() {
        KeepAliveConfig.setWanted(a, false)
        KeepAliveConfig.stop(a)
        watchBridge.disconnect()
        watchMessage.value = "Jam diputuskan. Data yang sudah tersimpan tidak dihapus."
    }

    /** Hapus hanya kredensial pairing perangkat terpilih, lalu lakukan pairing ulang seperti aplikasi lama. */
    fun forgetAndReconnectWatch(address: String) {
        if (!watchSyncLock.compareAndSet(false, true)) {
            watchMessage.value = "Operasi jam lain sedang berjalan. Tunggu hingga selesai."
            return
        }
        watchSyncing.value = true
        watchMessage.value = "Memutuskan koneksi dan menghapus kunci pairing lama… data latihan tetap aman."
        KeepAliveConfig.setWanted(a, false)
        KeepAliveConfig.stop(a)
        try {
            watchBridge.disconnect()
            watchBridge.forget(address)
            watchMessage.value = "Kunci pairing lama dihapus. Memulai pairing ulang… konfirmasi di layar jam bila diminta."
            watchBridge.connect(address, object : ProtocolGateway.Callback {
                override fun ok(result: JSONObject) {
                    KeepAliveConfig.setWanted(a, true)
                    val keep = KeepAliveConfig.start(a)
                    watchMessage.value = buildString {
                        append("Pairing ulang berhasil: ").append(result.optString("name", "Huawei Watch"))
                        result.optString("model").takeIf { it.isNotBlank() }?.let { append(" · ").append(it) }
                        append(". Data latihan tidak dihapus.")
                        if (keep != null) append(" Penjagaan latar belum aktif: ").append(keep)
                    }
                    watchSyncing.value = false
                    watchSyncLock.set(false)
                    syncWatch(false)
                }
                override fun error(code: String, message: String) {
                    watchMessage.value = "Pairing ulang gagal [$code]: $message. Kunci lama sudah dihapus; coba Hubungkan lagi. Data latihan tetap aman."
                    watchSyncing.value = false
                    watchSyncLock.set(false)
                }
            })
        } catch (e: Exception) {
            watchMessage.value = "Gagal menyiapkan pairing ulang: ${e.message ?: e.javaClass.simpleName}. Data latihan tidak dihapus."
            watchSyncing.value = false
            watchSyncLock.set(false)
        }
    }

    fun syncWatch(fullHistory: Boolean = false) {
        if (!watchSyncLock.compareAndSet(false, true)) {
            watchMessage.value = "Sinkronisasi sedang berjalan. Tunggu hingga selesai sebelum meminta sinkronisasi berikutnya."
            return
        }
        watchSyncing.value = true
        watchMessage.value = if (fullHistory) "Mengambil seluruh riwayat dari jam…" else "Menyinkronkan data jam…"
        try {
            watchBridge.sync(fullHistory, object : ProtocolGateway.Callback {
                override fun ok(result: JSONObject) {
                    viewModelScope.launch {
                        try {
                            val imported = withContext(Dispatchers.IO) { importWatchData(fullHistory) }
                            val doneAt = System.currentTimeMillis() / 1000L
                            watchLastSyncJs.value = doneAt; dockAppliedSync = maxOf(dockAppliedSync, doneAt)
                            val samples = result.optInt("samples", 0)
                            val sleep = result.optInt("sleep", 0)
                            val workouts = result.optInt("workouts", 0)
                            watchMessage.value = "Sinkron selesai: $samples sampel, $sleep segmen tidur, $workouts workout. ${imported.first} hari kondisi diperbarui; ${imported.second} aktivitas diimpor."
                        } catch (e: Exception) {
                            watchMessage.value = "Sinkron jam berhasil, tetapi impor ke EnduranceVault gagal: ${e.message ?: e.javaClass.simpleName}"
                        } finally {
                            watchSyncLock.set(false)
                            watchSyncing.value = false
                        }
                    }
                }
                override fun error(code: String, message: String) {
                    watchMessage.value = "Sinkron gagal [$code]: $message"
                    watchSyncLock.set(false)
                    watchSyncing.value = false
                }
            })
        } catch (e: Exception) {
            watchMessage.value = "Sinkron gagal: ${e.message ?: e.javaClass.simpleName}"
            watchSyncLock.set(false)
            watchSyncing.value = false
        }
    }

    fun refreshLiveHr() {
        runCatching { watchBridge.liveHeartRate() }.onSuccess { liveHrJson.value = it }
    }

    fun setLiveHr(active: Boolean) {
        try {
            watchBridge.setLiveHeartRate(active)
            refreshLiveHr()
            watchAdvancedMessage.value = if (active) "Permintaan Live HR dikirim ke jam." else "Live HR dimatikan; HR otomatis jam dipulihkan."
        } catch (e: Exception) {
            watchAdvancedMessage.value = "Live HR gagal: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    fun syncWatchHrZones(settings: PlanSettings) {
        try {
            // Samakan dengan zjPayload() aplikasi lama: HRR memakai lima batas Karvonen;
            // LTHR: batas bawah sama (Z1 = min(50% HRmax, awal Z2 - 1)). Hanya bila LTHR diisi manual dikirim sebagai metode "lthr"
            // (jam jalur track lalu memakai nama zona LTHR); LTHR otomatis atau jam non-track memakai MHR biasa.
            val today = java.time.LocalDate.now().toString()
            val restValues = state.value.daily
                .filter { it.dateIso < today && it.rhr != null }
                .sortedBy { it.dateIso }.takeLast(14).mapNotNull { it.rhr }.sorted()
            val restDefault = restValues.getOrNull(restValues.size / 2) ?: 55
            val cuts = com.endurancevault.app.domain.Zones.cuts(settings, restDefault)
            val manualLthr = settings.lthr?.takeIf { it >= 100 }?.let { Js.roundI(it) }
            val method = when {
                cuts.mode == "hrr" -> "hrr"
                manualLthr != null -> "lthr"
                else -> "mhr"
            }
            val lower = com.endurancevault.app.domain.StructuredWorkout.watchLowerBounds(cuts.mode, cuts.lo, cuts.maxHr)
            require(lower.size == 5) { "Batas zona HR tidak lengkap." }
            require(lower.all { it in 1..219 } && lower.zipWithNext().all { it.second > it.first }) {
                "Batas zona harus 1–219 bpm dan naik berurutan."
            }
            require(cuts.maxHr in 100..219 && lower[4] <= cuts.maxHr) { "HR maks atau batas zona di luar rentang jam." }
            val restHr = cuts.rest ?: restDefault
            require(restHr in 30..150 && (method != "hrr" || lower[0] > restHr)) {
                "HR istirahat atau batas Z1 tidak valid untuk jam."
            }
            watchAdvancedMessage.value = "Mengirim zona HR ke jam…"
            val payload = JSONObject().put("method", method).put("lower", JSONArray(lower))
                .put("maxHr", cuts.maxHr).put("restHr", restHr)
            if (method == "lthr") payload.put("lthr", manualLthr)
            watchBridge.setHrZones(payload.toString(), object : ProtocolGateway.Callback {
                override fun ok(result: JSONObject) {
                    val lthrNote = if (method == "lthr" && result.optString("branch") != "track") " Nama zona LTHR hanya untuk jam jalur track; jam ini menerima rentang bpm saja." else ""
                    watchAdvancedMessage.value = if (result.optBoolean("sent")) "Zona HR tersimpan dan dikirim ke jam (${result.optString("branch")}).$lthrNote" else "Zona HR tersimpan di aplikasi; jam belum terhubung atau belum mendukung jalur kirim."
                }
                override fun error(code: String, message: String) { watchAdvancedMessage.value = "Zona HR gagal [$code]: $message" }
            })
        } catch (e: Exception) { watchAdvancedMessage.value = "Zona HR tidak valid: ${e.message ?: e.javaClass.simpleName}" }
    }

    fun pushStructuredWorkout(name: String, warmupMin: Int, repeats: Int, runMin: Int, recoveryMin: Int, cooldownMin: Int, targets: com.endurancevault.app.domain.WorkoutTargets = com.endurancevault.app.domain.WorkoutTargets()) {
        try {
            com.endurancevault.app.domain.StructuredWorkout.validate(warmupMin, repeats, runMin, recoveryMin, cooldownMin, targets)?.let { throw IllegalArgumentException(it) }
            val payload = com.endurancevault.app.domain.StructuredWorkout.buildPayload("ev-${System.currentTimeMillis()}", name, warmupMin, repeats, runMin, recoveryMin, cooldownMin, targets)
            watchBridge.pushCourses(payload.toString(), object : ProtocolGateway.Callback {
                override fun ok(result: JSONObject) { watchAdvancedMessage.value = "Workout dikirim: ${result.optInt("sent")} berhasil, ${result.optInt("failed")} gagal. Periksa respons jam dan log protokol." }
                override fun error(code: String, message: String) { watchAdvancedMessage.value = "Pengiriman workout gagal [$code]: $message" }
            })
        } catch (e: Exception) { watchAdvancedMessage.value = "Workout tidak valid: ${e.message ?: e.javaClass.simpleName}" }
    }

    /** Pratinjau rute GPX yang menunggu konfirmasi kirim ke jam (null = tidak ada dialog). */
    val gpxPreview = MutableStateFlow<GpxRoute.Preview?>(null)

    /** Baca berkas GPX lalu tampilkan pratinjau (peta jalur, statistik, strategi pacing). Pengiriman baru terjadi di [confirmGpxRoute]. */
    fun pushGpxRoute(uri: Uri) {
        viewModelScope.launch {
            try {
                val p = withContext(Dispatchers.IO) {
                    val xml = a.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: throw GpxRoute.Err("GPX tidak dapat dibuka")
                    val fileName = a.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                        if (c.moveToFirst()) c.getString(0) else null
                    } ?: uri.lastPathSegment ?: "Rute"
                    GpxRoute.preview(xml, fileName)
                }
                gpxPreview.value = p
            } catch (e: GpxRoute.Err) { watchAdvancedMessage.value = "GPX gagal diproses: ${e.message}"
            } catch (e: Exception) { watchAdvancedMessage.value = "GPX gagal diproses: ${e.message ?: e.javaClass.simpleName}" }
        }
    }

    fun dismissGpxPreview() { gpxPreview.value = null }

    /** Kirim rute dari pratinjau yang sedang terbuka ke jam; bila [pace] ada, strategi pace menyusul sebagai sesi latihan. */
    fun confirmGpxRoute(pace: CourseStrategy.Result? = null) {
        val p = gpxPreview.value ?: return
        gpxPreview.value = null
        watchAdvancedMessage.value = "Mengirim rute \"${p.name}\" (${Js.fmtKm(p.km)} km) ke jam…"
        watchBridge.pushRoute(p.payload, object : ProtocolGateway.Callback {
            override fun ok(result: JSONObject) {
                val routeOk = result.optBoolean("ok")
                val routeMsg = if (routeOk) "Rute \"${p.name}\" terkirim: ${result.optInt("points")} titik, ${result.optInt("bytes")} byte. Status unggah: ${result.optString("uploadStatus")}; jawaban jam: ${result.optBoolean("answered")}." else "Jam belum mengonfirmasi penerimaan rute: $result"
                watchAdvancedMessage.value = routeMsg
                if (routeOk) explore.onWatchRouteSent(p.fileName)
                if (pace != null) pushPaceCourse(p, pace, routeMsg)
            }
            override fun error(code: String, message: String) { watchAdvancedMessage.value = "Rute gagal [$code]: $message" }
        })
    }

    /** Strategi pace sebagai sesi lari di jam (dikirim setelah rute, lewat jalur kursus). */
    private fun pushPaceCourse(p: GpxRoute.Preview, pace: CourseStrategy.Result, routeMsg: String) {
        val json = GpxRoute.paceCourse(p.name, pace, "ev-pace-${System.currentTimeMillis()}")
        if (json == null) { watchAdvancedMessage.value = "$routeMsg Strategi pace tidak dikirim: tidak ada ruas yang bisa dijadikan langkah."; return }
        watchAdvancedMessage.value = "$routeMsg Mengirim strategi pace…"
        watchBridge.pushCourses(json, object : ProtocolGateway.Callback {
            override fun ok(result: JSONObject) {
                watchAdvancedMessage.value = if (result.optInt("failed") == 0) "$routeMsg Strategi pace terkirim sebagai sesi \"Pace ${p.name}\"." else "$routeMsg Strategi pace gagal dikirim: ${result.optJSONArray("results")}"
            }
            override fun error(code: String, message: String) { watchAdvancedMessage.value = "$routeMsg Strategi pace gagal [$code]: $message" }
        })
    }

    private suspend fun importWatchData(fullHistory: Boolean): Pair<Int, Int> {
        val now = System.currentTimeMillis() / 1000L
        val since = if (fullHistory) 0L else now - 45L * 24L * 3600L
        val zone = ZoneId.systemDefault()
        val offsetMin = zone.rules.getOffset(Instant.now()).totalSeconds / 60
        val dailyPayload = watchBridge.readDaily(since, offsetMin)
        val existingDaily = state.value.daily
        val dailyRows = HuaweiWatchImport.daily(dailyPayload, existingDaily, zone)
        dailyRows.forEach { a.db.companion().saveDaily(it) }

        val workoutPayload = watchBridge.readWorkouts(since, if (fullHistory) 100 else 60).optJSONArray("workouts") ?: JSONArray()
        var imported = 0
        var gpsBackfilled = 0
        var lapsBackfilled = 0
        val tombstones = ActTombstones.parse(a.db.companion().kv(ActTombstones.KV_KEY))
        for (i in 0 until workoutPayload.length()) {
            val w = workoutPayload.optJSONObject(i) ?: continue
            val start = w.optLong("start", 0L)
            val duration = w.optInt("duration", 0)
            val distanceM = w.optInt("distance", 0)
            val sport = w.optInt("sportType", -1)
            if (start <= 0 || duration <= 0 || distanceM <= 0 || w.optBoolean("complete", true).not()) continue
            val type = when (sport) {
                1, 11 -> "run"
                3 -> "bike"
                else -> continue
            }
            val srcKey = "watch:$start"
            val startAt = Instant.ofEpochSecond(start).atZone(zone)
            val date = startAt.toLocalDate().toString()
            val time = startAt.toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm"))
            val km = distanceM / 1000.0
            // Aktivitas yang sudah dihapus pengguna tidak dimasukkan lagi.
            if (ActTombstones.blocked(tombstones, srcKey, date, time, type)) continue
            // Baca langsung dari Room, bukan hanya StateFlow yang mungkin belum sempat terbarui.
            val dayRows = a.db.activities().byDateAndType(date, type)
            // Cocok lewat kunci jam, bukan tanggal/jam/jarak, supaya baris yang sudah di-crop atau disunting tetap dikenali.
            val exactWatch = a.db.activities().bySrcKey(srcKey)
                ?: a.db.activities().byNoteLike("%\"watchStart\":$start%")
            val similarExisting = exactWatch ?: dayRows.firstOrNull { row ->
                watchWorkoutMatches(row, date, time, km, duration, type)
            }
            // Bila sudah ada aktivitas serupa dari backup/manual, gabungkan metadata jam ke baris itu;
            // jangan membuat sesi kedua yang akan menggandakan load/CTL/ATL.
            // Detail hasil impor jam versi lama (sebelum penggabungan HR/kadens/altitude) dibangun ulang dari titik
            // yang sudah tersimpan di database jam. Detail dari impor FIT/GPX manual tidak pernah disentuh.
            val existingDetail = similarExisting?.detailFile
            val detailVersion = if (existingDetail != null) withContext(Dispatchers.IO) { a.acts.watchVersion(existingDetail) } else -1
            val staleWatchDetail = detailVersion >= 0 && detailVersion < WatchTrackMerge.VERSION
            // Detail jam yang dibangun sebelum jejak GPS per detik (`gt`) ada: tempelkan jejaknya tanpa membangun ulang
            // sisa berkas (cuaca, anotasi, edit pengguna tetap utuh). Sesi yang sudah di-crop dilewati.
            val needsGpsTrack = existingDetail != null && detailVersion >= 0 && !staleWatchDetail &&
                gpsBackfilled < GPS_BACKFILL_PER_SYNC && w.optInt("gpsPoints", 0) >= 2 &&
                similarExisting?.let { ActEdit.isCropped(it.note.orEmpty()) } != true &&
                withContext(Dispatchers.IO) { !a.acts.hasGpsTrackKey(existingDetail!!) }
            val points = if (w.optInt("gpsPoints", 0) >= 2 && (existingDetail == null || staleWatchDetail || needsGpsTrack)) {
                runCatching { watchBridge.readWorkoutPoints(start).optJSONArray("points") }.getOrNull()
            } else null
            // Lap dari jam untuk detail lama (tanpa membangun ulang berkas): sekali per aktivitas, tidak menimpa segmen yang ada.
            if (existingDetail != null && !staleWatchDetail && !needsGpsTrack && lapsBackfilled < LAP_BACKFILL_PER_SYNC &&
                w.optJSONArray("sections") != null && similarExisting?.let { ActEdit.isCropped(it.note.orEmpty()) } != true
            ) {
                if (withContext(Dispatchers.IO) { backfillWatchLaps(existingDetail, w.optJSONArray("sections")!!) }) lapsBackfilled++
            }
            val watchGain = w.watchMeters("elevationGain")
            val watchLoss = w.watchMeters("elevationLoss")
            val watchAvgHr = w.optInt("avgHr").takeIf { it in 30..230 }
            val watchMaxHr = w.optInt("maxHr").takeIf { it in 30..230 }

            var detailFile: String? = null
            var gain: Int? = null
            var name = w.optString("sportName", if (type == "bike") "Cycling" else "Huawei Watch Run")
            if (needsGpsTrack) {
                if (points != null && points.length() >= 2) {
                    gpsBackfilled++
                    val file = existingDetail!!
                    withContext(Dispatchers.IO) { backfillGpsTrack(file, points, type, name) }
                }
            } else if (points != null && points.length() >= 2) {
                val built = runCatching {
                    val track = WatchTrackMerge.merge(points)
                    // Elevation Gain/Loss diselaraskan dengan total yang dicatat jam (lihat ElevationCalibration).
                    ElevationCalibration.calibrate(ActBuilder.build(track, if (type == "bike") "biking" else "running", name), w)
                }.getOrNull()
                if (built != null) {
                    name = (built["nm"] as? String)?.ifBlank { name } ?: name
                    // D+ dari rute (altitude barometer jam); bila rute tanpa altitude pakai ringkasan resmi jam.
                    gain = (built["gain"] as? Double)?.toInt() ?: watchGain
                    val builtHr = (built["hr"] as? Double)?.toInt()
                    val builtHrMax = (built["hrMax"] as? Double)?.toInt()
                    val base = similarExisting
                    val mergedNote = mergeWatchNote(base?.note.orEmpty(), w)
                    val row = if (base != null) base.copy(
                        avgHr = base.avgHr ?: watchAvgHr ?: builtHr,
                        maxHr = base.maxHr ?: watchMaxHr ?: builtHrMax,
                        // Detail jam lama bisa membawa D+ keliru (tanpa altitude); yang baru menggantikannya.
                        gain = if (staleWatchDetail) gain ?: base.gain else base.gain ?: gain,
                        note = mergedNote,
                    ) else ActivityEntity(
                        dateIso = date, km = km, durationSec = duration,
                        avgHr = watchAvgHr ?: builtHr,
                        maxHr = watchMaxHr ?: builtHrMax,
                        gain = gain, startTime = time, name = name, type = type, srcKey = srcKey,
                        note = mergedNote,
                    )
                    val id = if (base != null) { a.db.activities().update(row); base.id } else a.db.activities().insert(row)
                    val file = ActStore.importFileName(id)
                    val payload = HashMap(built)
                    payload["watch"] = JSONObject(w.toString()).toString()
                    payload["wv"] = WatchTrackMerge.VERSION
                    watchLapMaps(payload, w.optJSONArray("sections"))?.let { payload["sg"] = it }
                    payload["sgw"] = 1
                    if (payload["gain"] == null && watchGain != null) payload["gain"] = watchGain.toDouble()
                    if (payload["loss"] == null && watchLoss != null) payload["loss"] = watchLoss.toDouble()
                    withContext(Dispatchers.IO) { a.acts.write(file, payload) }
                    a.db.activities().setDetail(id, file)
                    detailFile = file
                }
            }
            if (detailFile == null) {
                if (similarExisting != null) {
                    val merged = similarExisting.copy(
                        avgHr = similarExisting.avgHr ?: watchAvgHr,
                        maxHr = similarExisting.maxHr ?: watchMaxHr,
                        gain = similarExisting.gain ?: watchGain,
                        note = mergeWatchNote(similarExisting.note, w),
                    )
                    a.db.activities().update(merged)
                } else {
                    a.db.activities().insert(
                        ActivityEntity(
                            dateIso = date, km = km, durationSec = duration,
                            avgHr = watchAvgHr, maxHr = watchMaxHr, gain = watchGain,
                            startTime = time, name = name, type = type, srcKey = srcKey,
                            note = watchWorkoutNote(w),
                        ),
                    )
                }
            }
            imported++
        }
        return dailyRows.size to imported
    }

    /**
     * Tempelkan `gt` (jejak GPS asli per detik) ke berkas detail jam lama tanpa mengubah angka lain. Lintasan dibangun
     * ulang dari titik jam dan hanya dipakai bila sejajar dengan `tl` yang sudah tersimpan; bila tidak, berkas diberi
     * `gt` kosong sebagai tanda "sudah dicoba" supaya sinkron berikutnya tidak membaca titik jam berulang-ulang.
     */
    private fun backfillGpsTrack(file: String, points: JSONArray, type: String, name: String) {
        val existing = a.acts.readMap(file) ?: return
        val built = runCatching {
            ActBuilder.build(WatchTrackMerge.merge(points), if (type == "bike") "biking" else "running", name)
        }.getOrNull()
        @Suppress("UNCHECKED_CAST")
        val gt = built?.get("gt") as? Map<String, Any?>
        val out = LinkedHashMap(existing)
        out["gt"] = if (gt != null && GpsTrackCodec.alignedWith(existing["tl"], built?.get("tl"))) gt else emptyMap<String, Any?>()
        a.acts.write(file, out)
    }

    /** Segmen (kunci `sg`) dari blok lap jam untuk objek aktivitas [act]; null bila tidak ada lap sungguhan (lihat [WatchLaps]). */
    private fun watchLapMaps(act: Map<String, Any?>, sections: JSONArray?): List<Map<String, Any?>>? {
        if (sections == null || sections.length() < 2) return null
        val ts = ActCrop.seriesOf(act) ?: return null
        val dist = (0 until sections.length()).map { sections.optJSONObject(it)?.optDouble("distance", Double.NaN) ?: Double.NaN }
        val drafts = WatchLaps.draftsFromSections(ts, dist) ?: return null
        val (gs, ls) = SegmentSplit.elevScales(act)
        return SegmentSplit.toMaps(SegmentSplit.toSegments(ts, drafts, gs, ls))
    }

    /**
     * Lengkapi detail jam lama dengan segmen dari lap jam. Hanya sekali per aktivitas (penanda `sgw`), dan tidak pernah
     * menimpa `sg` yang sudah ada (lap FIT, pembagian manual). True bila berkas ditulis.
     */
    private fun backfillWatchLaps(file: String, sections: JSONArray): Boolean {
        val existing = a.acts.readMap(file) ?: return false
        if (existing["sgw"] != null) return false
        val out = LinkedHashMap(existing)
        out["sgw"] = 1
        if (existing["sg"] == null) watchLapMaps(existing, sections)?.let { out["sg"] = it }
        a.acts.write(file, out)
        return true
    }

    /** Untuk impor ulang berkas FIT/GPX/TCX: lengkapi detail lama dengan `gt` bila lintasannya sama persis. */
    private fun upgradeGpsTrack(file: String, fresh: Map<String, Any?>): Boolean {
        val old = a.acts.readMap(file) ?: return false
        if (GpsTrackCodec.decode(old["gt"]) != null) return false
        @Suppress("UNCHECKED_CAST")
        val gt = fresh["gt"] as? Map<String, Any?> ?: return false
        if (!GpsTrackCodec.alignedWith(old["tl"], fresh["tl"])) return false
        val out = LinkedHashMap(old)
        out["gt"] = gt
        a.acts.write(file, out)
        return true
    }

    /** Meter bulat dari kolom ringkasan jam (mis. `elevationGain`); null bila tidak ada atau tidak valid. */
    private fun JSONObject.watchMeters(key: String): Int? {
        if (!has(key) || isNull(key)) return null
        val v = optDouble(key, Double.NaN)
        return if (v.isNaN() || v.isInfinite() || v < 0) null else Math.round(v).toInt()
    }

    private fun mergeWatchNote(previous: String, w: JSONObject): String = JSONObject().apply {
        val old = previous.trim()
        // Sesi yang sudah di-crop tidak lagi memakai angka jam (TE, load, recovery, D+/D− resmi) yang dihitung untuk sesi utuh.
        val cropped = ActEdit.isCropped(old)
        if (old.isNotEmpty() && runCatching { JSONObject(old).optString("source") == "huawei-watch" }.getOrDefault(false)) {
            put("userNote", runCatching { JSONObject(old).optString("userNote") }.getOrDefault(""))
        } else if (old.isNotEmpty()) put("userNote", old)
        put("source", "huawei-watch")
        if (w.optLong("start", 0L) > 0) put("watchStart", w.optLong("start"))
        if (cropped) { put("cropped", true); return@apply }
        if (w.has("recoveryHours")) put("recoveryHours", w.optDouble("recoveryHours"))
        if (w.has("elevationGain")) put("elevationGain", w.optDouble("elevationGain"))
        if (w.has("elevationLoss")) put("elevationLoss", w.optDouble("elevationLoss"))
        if (w.has("workoutLoad")) put("workoutLoad", w.optInt("workoutLoad"))
        if (w.has("aerobicEffect")) put("aerobicEffect", w.optDouble("aerobicEffect"))
        if (w.has("anaerobicEffect")) put("anaerobicEffect", w.optDouble("anaerobicEffect"))
        if (w.has("recoveryHr")) put("recoveryHr", w.optJSONArray("recoveryHr"))
    }.toString()

    private fun watchWorkoutNote(w: JSONObject): String = JSONObject().apply {
        put("source", "huawei-watch")
        if (w.optLong("start", 0L) > 0) put("watchStart", w.optLong("start"))
        if (w.has("recoveryHours")) put("recoveryHours", w.optDouble("recoveryHours"))
        if (w.has("elevationGain")) put("elevationGain", w.optDouble("elevationGain"))
        if (w.has("elevationLoss")) put("elevationLoss", w.optDouble("elevationLoss"))
        if (w.has("workoutLoad")) put("workoutLoad", w.optInt("workoutLoad"))
        if (w.has("aerobicEffect")) put("aerobicEffect", w.optDouble("aerobicEffect"))
        if (w.has("anaerobicEffect")) put("anaerobicEffect", w.optDouble("anaerobicEffect"))
        if (w.has("recoveryHr")) put("recoveryHr", w.optJSONArray("recoveryHr"))
    }.toString()

    fun clearTrackMsg() { trackMsg.value = null }

    /** Pilih gear (sepatu) untuk satu aktivitas dari layar detail; null = tanpa gear. */
    fun setActivityGear(id: Long, gearId: String?) {
        viewModelScope.launch(Dispatchers.IO) { a.db.activities().setGear(id, gearId) }
    }

    /** Simpan rasa setelah lari (skala 1..10) dari layar detail; null = hapus. Kolom lama `feel` (1..5) diisi (n+1)/2 untuk fitur lama. */
    fun setActivityFeel(id: Long, feel10: Int?) {
        val f10 = feel10?.takeIf { it in 1..10 }
        viewModelScope.launch(Dispatchers.IO) { a.db.activities().setFeel(id, f10?.let { (it + 1) / 2 }, f10) }
    }

    /** Baca detail (rute, split, grafik) satu aktivitas dari berkasnya. */
    suspend fun detailOf(e: ActivityEntity): ActDetail? = withContext(Dispatchers.IO) { e.detailFile?.let { a.acts.read(it) } }

    /** Waktu mulai sesi (detik epoch): `t0` detail, lalu `watchStart` catatan jam, lalu tanggal + jam mulai di zona perangkat. */
    private fun activityStartSec(e: ActivityEntity, d: ActDetail?): Long? {
        d?.startEpochMs?.takeIf { it > 0 }?.let { return it / 1000 }
        runCatching { JSONObject(e.note).optLong("watchStart", 0L) }.getOrDefault(0L).takeIf { it > 0 }?.let { return it }
        val hm = e.startTime?.takeIf { Regex("\\d{1,2}:\\d{2}").matches(it) } ?: return null
        return runCatching {
            java.time.LocalDateTime.of(java.time.LocalDate.parse(e.dateIso.take(10)), java.time.LocalTime.parse(hm.padStart(5, '0')))
                .atZone(java.time.ZoneId.systemDefault()).toEpochSecond()
        }.getOrNull()
    }

    /**
     * Ambil cuaca Open-Meteo untuk titik awal dan jam sesi, lalu simpan ke kunci `wx` berkas detail (suhu sensor jam `dv` dipertahankan).
     * Null = berhasil, selain itu pesan galat untuk ditampilkan.
     */
    suspend fun fetchActivityWeather(e: ActivityEntity): String? = withContext(Dispatchers.IO) {
        runCatching {
            val file = e.detailFile ?: return@runCatching "Aktivitas ini belum punya data detail"
            val d = a.acts.read(file) ?: return@runCatching "Detail aktivitas tidak bisa dibaca"
            val p = d.gpsTrack?.let { g -> if (g.size > 0) g.lat[0] to g.lon[0] else null }
                ?: d.geo?.let { fr -> RouteGeo.toLatLon(fr, d.route.take(1)).firstOrNull()?.let { it.lat to it.lon } }
                ?: return@runCatching "Aktivitas ini tidak punya posisi GPS, jadi cuaca tidak bisa dicari"
            val start = activityStartSec(e, d) ?: return@runCatching "Waktu mulai aktivitas tidak diketahui"
            val dur = (d.elapsedMin * 60).toInt().takeIf { it > 0 } ?: e.durationSec
            val wx = ActivityWeather.fetch(p.first, p.second, start, dur)
                ?: return@runCatching "Gagal mengambil cuaca. Periksa koneksi lalu coba lagi"
            val act = a.acts.readMap(file) ?: return@runCatching "Detail aktivitas tidak bisa dibaca"
            val out = LinkedHashMap<String, Any?>(act)
            val merged = LinkedHashMap<String, Any?>(wx)
            JsonUtil.asMap(act["wx"])?.get("dv")?.let { merged["dv"] = it }
            out["wx"] = merged
            a.acts.write(file, out)
            null
        }.getOrElse { it.message ?: "Gagal menyimpan cuaca" }
    }

    /**
     * Pemakaian baterai jam selama sesi, dihitung dari log baterai bila berkas detail belum punya `bat`, lalu disimpan ke berkas
     * (log hanya menyimpan 60 hari). Null bila bukan sesi jam, sesi sudah dipangkas, atau cuplikan baterai di sekitar sesi tidak cukup.
     */
    suspend fun activityBattery(e: ActivityEntity, d: ActDetail?): WatchBattery? = withContext(Dispatchers.IO) {
        runCatching {
            d?.battery?.let { return@runCatching it }
            val meta = JSONObject(e.note)
            if (meta.optString("source") != "huawei-watch" || meta.optBoolean("cropped", false)) return@runCatching null
            val start = meta.optLong("watchStart", 0L).takeIf { it > 0 } ?: activityStartSec(e, d) ?: return@runCatching null
            val dur = (d?.elapsedMin?.times(60))?.toLong()?.takeIf { it > 0 } ?: e.durationSec.toLong()
            val b = WatchDock.batSession(dockReader.batLog(), start, start + dur)
            if (!WatchDock.batOk(b, dur / 60.0) || b == null) return@runCatching null
            val res = WatchBattery(b.s, b.e, b.used, b.ap, b.ph)
            e.detailFile?.let { f ->
                a.acts.readMap(f)?.let { act ->
                    val out = LinkedHashMap<String, Any?>(act)
                    out["bat"] = mapOf("s" to b.s, "e" to b.e, "used" to b.used, "ap" to if (b.ap) 1 else 0, "ph" to b.ph)
                    a.acts.write(f, out)
                }
            }
            res
        }.getOrNull()
    }

    fun dismissImport() { importState.value = ImportUi.Idle }

    /* ---------- Cadangan lengkap (.zip) ---------- */

    fun backupFileName(): String = NativeBackup.fileName()

    /** Tulis seluruh data aplikasi ke berkas tujuan yang dipilih pengguna. */
    fun exportBackup(uri: Uri) {
        if (backupState.value is BackupUi.Working) return
        backupState.value = BackupUi.Working("Membuat cadangan…")
        viewModelScope.launch {
            backupState.value = try {
                val s = withContext(Dispatchers.IO) {
                    val out = a.contentResolver.openOutputStream(uri, "w") ?: throw BackupException("Berkas tujuan tidak bisa dibuka.")
                    try {
                        out.use { NativeBackup.export(a, it) }
                    } catch (t: Throwable) {
                        runCatching { android.provider.DocumentsContract.deleteDocument(a.contentResolver, uri) }
                        throw t
                    }
                }
                BackupUi.Done(
                    "Cadangan tersimpan (${"%.1f".format(Locale.US, s.sizeBytes / 1_048_576.0)} MB): ${s.activities} aktivitas (${s.activityDetails} dengan rute dan grafik), ${s.sleepSegments} segmen tidur, ${s.stepSamples} sampel langkah/HR, ${s.daily} catatan harian, ${s.gear} gear, pengaturan, dan foto profil. Simpan berkasnya di luar ponsel (mis. Google Drive atau komputer).",
                    restored = false,
                )
            } catch (e: BackupException) {
                BackupUi.Failed(e.message ?: "Cadangan gagal dibuat.")
            } catch (e: Exception) {
                BackupUi.Failed("Cadangan gagal dibuat: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    /** Baca berkas cadangan (.zip) dan tampilkan ringkasannya sebelum data diganti. */
    fun startRestore(uri: Uri) {
        if (backupState.value is BackupUi.Working) return
        if (watchSyncing.value) { backupState.value = BackupUi.Failed("Sinkronisasi jam sedang berjalan. Coba lagi setelah selesai."); return }
        backupState.value = BackupUi.Working("Membaca cadangan…")
        viewModelScope.launch {
            val staging = File(a.cacheDir, "restore-staging")
            backupState.value = try {
                val summary = withContext(Dispatchers.IO) {
                    val ins = a.contentResolver.openInputStream(uri) ?: throw BackupException("Berkas tidak bisa dibuka.")
                    ins.use { NativeBackup.stage(it, staging) }
                }
                restoreStaging = staging
                BackupUi.Confirm(summary)
            } catch (e: BackupException) {
                staging.deleteRecursively()
                BackupUi.Failed(e.message ?: "Cadangan tidak bisa dibaca.")
            } catch (e: Exception) {
                staging.deleteRecursively()
                BackupUi.Failed("Gagal membaca berkas: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    fun confirmRestore() {
        val staging = restoreStaging ?: return
        if (backupState.value !is BackupUi.Confirm) return
        if (!watchSyncLock.compareAndSet(false, true)) {
            backupState.value = BackupUi.Failed("Sinkronisasi jam sedang berjalan. Coba lagi setelah selesai.")
            return
        }
        backupState.value = BackupUi.Working("Memulihkan data…")
        viewModelScope.launch {
            backupState.value = try {
                val msg = withContext(Dispatchers.IO) { NativeBackup.restore(a, staging) }
                reloadAfterRestore()
                BackupUi.Done(msg, restored = true)
            } catch (e: BackupException) {
                BackupUi.Failed(e.message ?: "Pemulihan gagal.")
            } catch (e: Exception) {
                BackupUi.Failed("Gagal memulihkan: ${e.message ?: e.javaClass.simpleName}. Data sebelumnya tersimpan di salinan pengaman (folder backups di penyimpanan aplikasi).")
            } finally {
                staging.deleteRecursively(); restoreStaging = null
                watchSyncLock.set(false)
            }
        }
    }

    fun dismissBackup() {
        if (backupState.value is BackupUi.Working) return
        restoreStaging?.deleteRecursively(); restoreStaging = null
        backupState.value = BackupUi.Idle
    }

    /** Muat ulang state yang dipegang ViewModel dari SharedPreferences hasil pemulihan. */
    private fun reloadAfterRestore() {
        settingsFlow.value = a.settings.load()
        weatherLat.value = weatherPrefs.getString("lat", null) ?: "-6.99"
        weatherLon.value = weatherPrefs.getString("lon", null) ?: "110.42"
        weatherPlace.value = weatherPrefs.getString("place", null) ?: "Ungaran, Indonesia"
        weatherPlaceLabel.value = weatherPlace.value
    }
}
