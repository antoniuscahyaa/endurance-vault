@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.i18n.Text
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CompareArrows
import androidx.compose.material.icons.outlined.ExpandLess
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.Route
import androidx.compose.material.icons.outlined.Terrain
import androidx.compose.material.icons.outlined.Timeline
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.data.MapStyle
import com.endurancevault.app.data.MapTiles
import com.endurancevault.app.domain.ActDetail
import com.endurancevault.app.domain.ActInsights
import com.endurancevault.app.domain.EffortPace
import com.endurancevault.app.domain.Js
import com.endurancevault.app.domain.ProgressAnalytics
import com.endurancevault.app.domain.ProgressTabs
import com.endurancevault.app.domain.RouteActivity
import com.endurancevault.app.domain.RouteGeo
import com.endurancevault.app.domain.TrainingMetrics
import com.endurancevault.app.domain.Zones
import com.endurancevault.app.ui.UiState
import java.time.LocalDate
import java.time.format.TextStyle as JTextStyle
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.roundToInt
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

/**
 * Tab Routes & conditions, memakai sistem kartu yang sama dengan Rekap dan Fitness.
 * Susunan mengikuti rencana lari: Rute serupa + Bandingkan aktivitas (berpasangan), Heatmap rute + Ridgeline elevasi
 * (berpasangan), lalu Dampak cuaca selebar layar. Kartu "Fuelling" sengaja tidak ada di aplikasi ini.
 */
@Composable
internal fun RoutesTab(state: UiState, onOpen: (Long) -> Unit) {
    val runs = remember(state.activities, state.detailsByActivity) {
        state.activities
            .filter { it.type != "bike" && it.km > 0 && it.durationSec > 0 }
            .sortedBy { it.dateIso + " " + (it.startTime ?: "") }
            .mapNotNull { a -> state.detailsByActivity[a.id]?.let { RtRun(a, it) } }
    }
    val byId = remember(runs) { runs.associateBy { it.a.id } }
    val groups = remember(runs, byId) {
        val raw = runCatching {
            ProgressAnalytics.similarRoutes(
                runs.filter { it.d.hasRoute }.map { RouteActivity(it.a.id, it.a.dateIso, it.a.km, it.d.route) },
            )
        }.getOrDefault(emptyList())
        raw.mapNotNull { g ->
            val ms = g.members.mapNotNull { byId[it.id] }.sortedBy { it.a.dateIso + " " + (it.a.startTime ?: "") }
            if (ms.isEmpty()) null else RtGroupData(g.representative.km, ms)
        }.sortedByDescending { it.latest.a.dateIso }
    }
    val heat = remember(runs) { rtHeatPolys(runs) }
    val easyCut = remember(state.settings) { runCatching { Zones.cuts(state.settings).lo.getOrNull(2) }.getOrNull() }
    val wx = remember(runs, easyCut) { rtWeather(runs, easyCut) }

    var oSim by rememberSaveable { mutableStateOf(false) }
    var oCmp by rememberSaveable { mutableStateOf(false) }
    var oHeat by rememberSaveable { mutableStateOf(false) }
    var oRidge by rememberSaveable { mutableStateOf(false) }
    var oWx by rememberSaveable { mutableStateOf(false) }
    var mainArea by rememberSaveable { mutableStateOf(true) }

    RcPair(oSim, oCmp,
        left = { m -> RtSimilar(groups, onOpen, oSim, { oSim = !oSim }, m) },
        right = { m -> RtCompare(state, oCmp, { oCmp = !oCmp }, m) })
    RcPair(oHeat, oRidge,
        left = { m -> RtHeatCard(heat, runs.size, mainArea, { mainArea = it }, oHeat, { oHeat = !oHeat }, m) },
        right = { m -> RtRidgeCard(runs, oRidge, { oRidge = !oRidge }, m) })
    RtWeather(wx, oWx, { oWx = !oWx }, Modifier.fillMaxWidth())
}

// ===================== model & helper =====================

private val RT_LOC = com.endurancevault.app.ui.i18n.Lang.locale

/** Satu lari beserta detailnya. */
private class RtRun(val a: ActivityEntity, val d: ActDetail) {
    val pace: Double? get() = (d.avgPace ?: if (a.km > 0) a.durationSec / 60.0 / a.km else null)?.takeIf { it in 2.0..20.0 }
    val hr: Int? get() = d.hr ?: a.avgHr
    val gain: Int? get() = d.gain ?: a.gain
    val movingSec: Int get() = if (d.movingMin > 0) (d.movingMin * 60).roundToInt() else a.durationSec
}

/** Satu kelompok rute serupa; [members] urut tanggal naik. */
private class RtGroupData(val km: Double, val members: List<RtRun>) {
    val latest: RtRun get() = members.last()
}

/** Satu rute (titik lintasan) untuk heatmap; [main] = berada di area utama. */
private class RtPoly(val pts: List<RouteGeo.LatLon>, val main: Boolean)

private class RtMap(val lines: List<List<Offset>>, val aspect: Float)

private class RtWx(val date: String, val temp: Double, val feels: Double?, val pace: Double, val hr: Double?, val easy: Boolean)

private fun rtF1(x: Double): String = String.format(Locale.US, "%.1f", x).let { if (com.endurancevault.app.domain.ActInsights.decimalComma) it.replace('.', ',') else it }
private fun rtF2(x: Double): String = String.format(Locale.US, "%.2f", x).let { if (com.endurancevault.app.domain.ActInsights.decimalComma) it.replace('.', ',') else it }
private fun rtSigned(x: Int): String = if (x > 0) "+$x" else if (x < 0) "−${abs(x)}" else "0"
private fun rtSignedD(x: Double, f: (Double) -> String): String = if (x > 0.0) "+" + f(x) else if (x < 0.0) "−" + f(abs(x)) else f(0.0)

private fun rtDate(iso: String): String {
    val d = runCatching { LocalDate.parse(iso.take(10)) }.getOrNull() ?: return iso
    return "${d.dayOfMonth} ${d.month.getDisplayName(JTextStyle.SHORT, RT_LOC)}"
}

private fun rtDateY(iso: String): String {
    val d = runCatching { LocalDate.parse(iso.take(10)) }.getOrNull() ?: return iso
    return "${d.dayOfMonth} ${d.month.getDisplayName(JTextStyle.SHORT, RT_LOC)} ${d.year}"
}

/** mm:ss, atau j:mm:ss bila lebih dari satu jam. */
private fun rtDur(sec: Int): String {
    val s = sec.coerceAtLeast(0)
    val h = s / 3600; val m = (s % 3600) / 60; val r = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, r) else String.format(Locale.US, "%02d:%02d", m, r)
}

/** Titik rute lat/lon (maks ~[cap] titik) dari satu lari; kosong bila tak ada koordinat. */
private fun rtLatLon(r: RtRun, cap: Int): List<RouteGeo.LatLon> {
    val frame = r.d.geo ?: return emptyList()
    if (!r.d.hasRoute) return emptyList()
    val ll = RouteGeo.toLatLon(frame, r.d.route)
    val step = (ll.size / cap).coerceAtLeast(1)
    return ll.filterIndexed { i, _ -> i % step == 0 || i == ll.lastIndex }
}

private fun rtHeatPolys(runs: List<RtRun>): List<RtPoly> {
    val lines = runs.map { rtLatLon(it, 160) }.filter { it.size >= 2 }
    if (lines.isEmpty()) return emptyList()
    val flags = ProgressTabs.mainAreaFlags(lines.map { l -> l.map { it.lat }.average() to l.map { it.lon }.average() })
    return lines.mapIndexed { i, l -> RtPoly(l, flags.getOrElse(i) { true }) }
}

/** Dua titik pojok yang membungkus semua garis; cukup untuk [RouteGeo.fitView]. */
private fun rtBounds(lines: List<List<RouteGeo.LatLon>>): List<RouteGeo.LatLon> {
    val all = lines.flatten()
    if (all.isEmpty()) return emptyList()
    return listOf(
        RouteGeo.LatLon(all.minOf { it.lat }, all.minOf { it.lon }),
        RouteGeo.LatLon(all.maxOf { it.lat }, all.maxOf { it.lon }),
    )
}

/** Semua garis dalam satu bingkai 0..1 untuk pratinjau mini. */
private fun rtMiniMap(lines: List<List<RouteGeo.LatLon>>): RtMap? {
    val all = lines.flatten()
    if (all.size < 2) return null
    val cosLat = cos(Math.toRadians(all.map { it.lat }.average()))
    val minLon = all.minOf { it.lon }; val maxLon = all.maxOf { it.lon }
    val minLat = all.minOf { it.lat }; val maxLat = all.maxOf { it.lat }
    val w = ((maxLon - minLon) * cosLat).coerceAtLeast(1e-6)
    val h = (maxLat - minLat).coerceAtLeast(1e-6)
    val out = lines.map { pts -> pts.map { p -> Offset(((p.lon - minLon) * cosLat / w).toFloat(), ((maxLat - p.lat) / h).toFloat()) } }
    return RtMap(out, (w / h).toFloat())
}

private fun rtWeather(runs: List<RtRun>, easyCut: Int?): List<RtWx> = runs.mapNotNull { r ->
    val t = r.d.weatherTempC ?: r.d.weather?.tempC ?: return@mapNotNull null
    val p = r.pace ?: return@mapNotNull null
    val hr = r.hr
    val easy = r.d.easyRun?.enabled == true || (hr != null && easyCut != null && hr < easyCut)
    RtWx(r.a.dateIso, t, r.d.weatherFeelsLikeC ?: r.d.weather?.feelsLikeC, p, hr?.toDouble(), easy)
}

/** Warna kelompok rute di ringkasan: oranye aplikasi, jingga-merah, kuning tua, hijau. */
@Composable
private fun rtGroupColors(): List<Color> {
    val cs = MaterialTheme.colorScheme
    return listOf(cs.primary, Color(0xFFE5481A), Color(0xFFC08A1E), Color(0xFF3FA37B))
}

// ===================== peta ubin (OSM) + kanvas =====================

private fun rtCam(v: RouteGeo.View, maxNative: Int): RouteGeo.Camera {
    val z = floor(v.zoomF).toInt().coerceIn(0, maxNative)
    val k = Math.pow(2.0, z.toDouble())
    return RouteGeo.Camera(z, Math.pow(2.0, v.zoomF - z), v.cx0 * k, v.cy0 * k)
}

/**
 * Kanvas peta statis (tanpa gestur): ubin OpenStreetMap dari cache/jaringan di belakang, lalu [content] menggambar
 * garis lewat fungsi proyeksi lat/lon -> piksel. [bounds] menentukan bingkai; [mapKey] mengganti cache ubin saat bingkai berubah.
 * [showTiles] = false menampilkan latar polos. [dim] menggelapkan ubin (untuk heatmap).
 */
@Composable
private fun RtTileMap(
    bounds: List<RouteGeo.LatLon>, mapKey: Any, showTiles: Boolean, height: Dp, bg: Color,
    modifier: Modifier = Modifier, dim: Float = 0f, pad: Double = 0.08,
    content: DrawScope.((RouteGeo.LatLon) -> Offset) -> Unit,
) {
    val context = LocalContext.current
    val density = LocalDensity.current
    // Mengikuti gaya peta yang dipilih di peta aktivitas/pratinjau (default, satelit, topografi, kontur).
    val style = routeMapStyle
    val bitmaps = remember(mapKey, style) { mutableStateMapOf<RouteGeo.TileId, ImageBitmap>() }
    BoxWithConstraints(modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(12.dp))) {
        val wPx = with(density) { maxWidth.toPx() }.toDouble()
        val hPx = with(density) { maxHeight.toPx() }.toDouble()
        val view = remember(mapKey, wPx, hPx) { RouteGeo.fitView(bounds, wPx, hPx, pad) }
        val cam = remember(view) { view?.let { rtCam(it, style.maxNative) } }
        val placed = remember(cam, wPx, hPx, showTiles) {
            if (showTiles && cam != null) RouteGeo.tilesFor(cam, wPx, hPx) else emptyList()
        }
        LaunchedEffect(placed, style) {
            if (bitmaps.size > 160) bitmaps.clear()
            coroutineScope {
                placed.map { it.id }.distinct().forEach { id ->
                    launch {
                        val bmp = MapTiles.load(context, id, style)
                        if (bmp != null) bitmaps[id] = bmp.asImageBitmap()
                    }
                }
            }
        }
        Canvas(Modifier.fillMaxSize()) {
            drawRect(bg)
            if (cam == null) return@Canvas
            val s = cam.scale
            val cx = size.width / 2.0
            val cy = size.height / 2.0
            fun sx(wx: Double) = (cx + (wx - cam.centerX) * s).toFloat()
            fun sy(wy: Double) = (cy + (wy - cam.centerY) * s).toFloat()
            if (showTiles) {
                val tile = RouteGeo.TILE.toDouble()
                placed.forEach { p ->
                    val bmp = bitmaps[p.id] ?: return@forEach
                    val left = sx(p.ux * tile).roundToInt()
                    val top = sy(p.id.y * tile).roundToInt()
                    val right = sx((p.ux + 1) * tile).roundToInt()
                    val bottom = sy((p.id.y + 1) * tile).roundToInt()
                    drawImage(bmp, dstOffset = IntOffset(left, top), dstSize = IntSize(right - left, bottom - top))
                }
                if (dim > 0f) drawRect(Color(0xFF17181A).copy(alpha = dim))
            }
            val proj: (RouteGeo.LatLon) -> Offset = { p ->
                Offset(sx(RouteGeo.worldX(p.lon, cam.zoom)), sy(RouteGeo.worldY(p.lat, cam.zoom)))
            }
            content(this, proj)
        }
        if (showTiles) {
            Text(
                "© OpenStreetMap contributors",
                modifier = Modifier.align(Alignment.BottomEnd).background(Color.White.copy(alpha = 0.6f)).padding(horizontal = 3.dp),
                color = Color(0xFF333333), fontSize = 7.sp, lineHeight = 9.sp,
            )
        }
    }
}

private fun DrawScope.rtPolyline(pts: List<RouteGeo.LatLon>, proj: (RouteGeo.LatLon) -> Offset): Path {
    val path = Path()
    pts.forEachIndexed { i, p -> val o = proj(p); if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y) }
    return path
}

// ===================== 1. Rute serupa =====================

@Composable
private fun RtSimilar(
    groups: List<RtGroupData>, onOpen: (Long) -> Unit,
    open: Boolean, onToggle: () -> Unit, modifier: Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val colors = rtGroupColors()
    var mapMode by rememberSaveable { mutableIntStateOf(0) }       // 0 = peta, 1 = polos
    var expanded by rememberSaveable { mutableIntStateOf(-1) }
    val bySize = remember(groups) { groups.sortedByDescending { it.members.size } }
    RcCard(Icons.Outlined.Route, "RUTE SERUPA", open, onToggle, modifier,
        headText = "${groups.size} rute",
        summary = {
            if (groups.isEmpty()) {
                RcMuted("Belum ada dua aktivitas dengan bentuk rute dan jarak yang cukup mirip.")
            } else {
                val top = bySize.first()
                RcBig("${groups.size} rute", "terbanyak: ${fmtKmUi(top.km)} km ×${top.members.size}")
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                        bySize.take(4).forEachIndexed { i, _ -> Box(Modifier.size(12.dp).clip(CircleShape).background(colors[i % colors.size])) }
                    }
                    Spacer(Modifier.weight(1f))
                    Text(bySize.take(4).joinToString(" ") { "×${it.members.size}" }, style = monoStyle(9f, 0f), color = cs.onSurfaceVariant, maxLines = 1)
                }
            }
        },
        body = {
            if (groups.isEmpty()) {
                RcMuted("Belum ada dua aktivitas dengan bentuk rute dan jarak yang cukup mirip.")
            } else {
                RcSeg(listOf("Peta", "Polos"), mapMode) { mapMode = it }
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    groups.forEachIndexed { i, g ->
                        RtGroupRow(g, i == expanded, mapMode == 0, onOpen) { expanded = if (expanded == i) -1 else i }
                    }
                }
                RcInfo("Rute dikelompokkan dari bentuk lintasan GPS dan jarak (±12%). Perbandingan bersifat deskriptif; tidak mengoreksi cuaca, elevasi, arah lintasan, atau tingkat usaha.")
            }
        })
}

@Composable
private fun RtGroupRow(g: RtGroupData, open: Boolean, tiles: Boolean, onOpen: (Long) -> Unit, onToggle: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
        color = if (open) cs.surface else cs.surfaceVariant.copy(alpha = .7f),
        border = BorderStroke(.8.dp, cs.outlineVariant),
    ) {
        Column {
            Row(Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(horizontal = 14.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${fmtKmUi(g.km)} km · ${g.members.size} lari · terbaru ${rtDate(g.latest.a.dateIso)}",
                    Modifier.weight(1f), style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Icon(if (open) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore, null, Modifier.size(20.dp), tint = cs.onSurfaceVariant)
            }
            if (open) {
                androidx.compose.material3.HorizontalDivider(color = cs.outlineVariant, thickness = .8.dp)
                RtGroupBody(g, tiles, onOpen)
            }
        }
    }
}

@Composable
private fun RtGroupBody(g: RtGroupData, tiles: Boolean, onOpen: (Long) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val lines = remember(g) { g.members.takeLast(10).map { rtLatLon(it, 220) }.filter { it.size >= 2 } }
    val bounds = remember(lines) { rtBounds(lines) }
    var showAll by rememberSaveable(g.latest.a.id) { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (lines.isNotEmpty()) {
            val bg = if (tiles) Color(0xFFE9E6DF) else cs.surfaceVariant
            RtTileMap(bounds, g.latest.a.id, tiles, 230.dp, bg) { proj ->
                val round = { w: Float -> Stroke(w, cap = StrokeCap.Round, join = StrokeJoin.Round) }
                lines.dropLast(1).forEach { l -> drawPath(rtPolyline(l, proj), cs.primary.copy(alpha = .22f), style = round(3.dp.toPx())) }
                val main = rtPolyline(lines.last(), proj)
                drawPath(main, Color.White.copy(alpha = .9f), style = round(7.dp.toPx()))
                drawPath(main, cs.primary, style = round(4.dp.toPx()))
            }
        }
        // tabel lari: tanggal berbentuk pil, lalu waktu, pace, HR, D+
        val w = listOf(1.25f, 1f, .9f, .75f, .8f)
        Column {
            RcTableRow(listOf("Tanggal", "Waktu", "Pace", "HR", "D+"), w, head = true)
            val rows = g.members.asReversed().let { if (showAll) it else it.take(10) }
            rows.forEach { r ->
                Row(Modifier.fillMaxWidth().clickable { onOpen(r.a.id) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(w[0])) {
                        Surface(shape = RoundedCornerShape(99.dp), color = cs.surfaceVariant, border = BorderStroke(.8.dp, cs.outlineVariant)) {
                            Text(rtDate(r.a.dateIso), Modifier.padding(horizontal = 10.dp, vertical = 6.dp), style = monoStyle(10.5f, 0f), maxLines = 1)
                        }
                    }
                    listOf(rtDur(r.movingSec), r.pace?.let { Js.paceStr(it) } ?: "–", r.hr?.toString() ?: "–", r.gain?.toString() ?: "–")
                        .forEachIndexed { i, t -> Text(t, Modifier.weight(w[i + 1]), style = monoStyle(10.5f, 0f), textAlign = TextAlign.End, maxLines = 1) }
                }
                androidx.compose.material3.HorizontalDivider(color = cs.outlineVariant.copy(alpha = .6f), thickness = .6.dp)
            }
            if (g.members.size > 10) {
                Box(Modifier.fillMaxWidth().clickable { showAll = !showAll }.padding(top = 8.dp)) {
                    RcMono(if (showAll) "Tampilkan lebih sedikit" else "+${g.members.size - 10} lari lebih lama · ketuk untuk semua")
                }
            }
        }
    }
}

// ===================== 2. Bandingkan aktivitas =====================

private class RtCmpRow(val label: String, val a: String, val b: String, val d: String)

private fun rtCmpRow(label: String, a: Double?, b: Double?, fmt: (Double) -> String, dfmt: (Double) -> String = fmt): RtCmpRow? {
    if (a == null && b == null) return null
    val delta = if (a != null && b != null) rtSignedD(b - a, dfmt) else "–"
    return RtCmpRow(label, a?.let(fmt) ?: "–", b?.let(fmt) ?: "–", delta)
}

/** Kumpulan angka satu aktivitas untuk tabel banding; null = tidak ada datanya. */
private class RtMetricSet(
    val km: Double, val sec: Double, val pace: Double?, val gap: Double?, val effort: Double?, val hr: Double?,
    val hrMax: Double?, val cad: Double?, val stride: Double?, val gain: Double?, val load: Double?, val te: Double?, val vo2: Double?,
)

@Composable
private fun RtCompare(state: UiState, open: Boolean, onToggle: () -> Unit, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    var selA by rememberSaveable { mutableLongStateOf(-1L) }
    var selB by rememberSaveable { mutableLongStateOf(-1L) }
    val acts = remember(state.activities) {
        state.activities.filter { it.km > 0 || it.durationSec > 0 }.sortedByDescending { it.dateIso + " " + (it.startTime ?: "") }
    }
    val a = acts.firstOrNull { it.id == selA } ?: acts.getOrNull(0)
    val b = acts.firstOrNull { it.id == selB } ?: acts.getOrNull(1)
    RcCard(Icons.Outlined.CompareArrows, "BANDINGKAN AKTIVITAS", open, onToggle, modifier,
        headText = "${acts.size} aktivitas",
        summary = {
            RcBig("${acts.size}", "aktivitas")
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                RtAbBadge("A")
                Canvas(Modifier.weight(1f).height(2.dp).padding(horizontal = 8.dp)) {
                    drawLine(cs.outlineVariant, Offset(0f, 1.dp.toPx()), Offset(size.width, 1.dp.toPx()), 1.5.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f)))
                }
                RtAbBadge("B")
            }
        },
        body = {
            if (acts.size < 2 || a == null || b == null) {
                RcMuted("Minimal dua aktivitas diperlukan.")
            } else {
                RtCompareBody(state, acts, a, b, { selA = it }, { selB = it })
            }
        })
}

@Composable
private fun RtAbBadge(text: String) {
    val cs = MaterialTheme.colorScheme
    Box(Modifier.size(30.dp).clip(CircleShape).background(cs.primary), contentAlignment = Alignment.Center) {
        Text(text, style = MaterialTheme.typography.labelLarge, color = cs.onPrimary, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun RtDropdown(tag: String, items: List<Pair<Long, String>>, selected: Long, modifier: Modifier, onSelect: (Long) -> Unit) {
    val cs = MaterialTheme.colorScheme
    var open by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.dp)
    Column(modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(tag, style = monoStyle(10f, 0f), color = cs.onSurfaceVariant)
        Box {
            Row(
                Modifier.fillMaxWidth().clip(shape).background(cs.surfaceVariant).border(.8.dp, cs.outlineVariant, shape)
                    .clickable { open = true }.padding(horizontal = 12.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(items.firstOrNull { it.first == selected }?.second ?: "–", Modifier.weight(1f),
                    style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Icon(Icons.Outlined.ExpandMore, null, Modifier.size(18.dp), tint = cs.onSurfaceVariant)
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                items.forEach { (id, label) -> DropdownMenuItem(text = { Text(label) }, onClick = { onSelect(id); open = false }) }
            }
        }
    }
}

@Composable
private fun RtCompareBody(
    state: UiState, acts: List<ActivityEntity>, a: ActivityEntity, b: ActivityEntity,
    onA: (Long) -> Unit, onB: (Long) -> Unit,
) {
    // Dihitung hanya saat kartu dibuka: beban sesi, kalibrasi panas, dan indeks kemampuan.
    val metrics = remember(state.settings, state.activities, state.daily, state.plan, state.hrHistByActivity) {
        runCatching { TrainingMetrics.calculate(state.settings, state.activities, state.daily, state.plan, hrHistByActivity = state.hrHistByActivity) }.getOrNull()
    }
    val sessions = remember(metrics) { metrics?.sessions.orEmpty().associateBy { it.activityId } }
    val lthr = metrics?.lthr ?: runCatching { Zones.cuts(state.settings).lthr }.getOrNull() ?: 0
    val heat = remember(state.detailsByActivity, lthr) { EffortPace.calibrate(state.detailsByActivity.values, lthr) }
    val basis = remember(state.settings, state.activities, state.daily) { ProgressAnalytics.abilityBasis(state.settings, state.activities, state.daily) }

    fun metricOf(e: ActivityEntity): RtMetricSet {
        val d = state.detailsByActivity[e.id]
        val bike = e.type == "bike"
        val sec = if (d != null && d.movingMin > 0) d.movingMin * 60.0 else e.durationSec.toDouble()
        val km = if (e.km > 0) e.km else d?.km ?: 0.0
        val gain = d?.gain ?: e.gain
        val pace = if (bike || km <= 0) null else (d?.avgPace ?: (sec / 60.0 / km)).takeIf { it in 2.0..20.0 }
        val gap = if (bike) null else ActInsights.gapOfActivity(d?.gapPace, d?.splits.orEmpty(), gain != null, false)
        val effort = if (bike) null else EffortPace.compute(gap, d?.weather, d?.weatherFeelsLikeC ?: d?.weatherTempC, heat)?.pace
        val cad = d?.cad?.takeIf { it > 0 }
        val stride = if (bike) null else ActInsights.strideLength(km, sec / 60.0, cad)
        val s = sessions[e.id]
        return RtMetricSet(
            km, sec, pace, gap, effort, (d?.hr ?: e.avgHr)?.toDouble(), (d?.hrMax ?: e.maxHr)?.toDouble(),
            if (bike) null else cad?.toDouble(), stride, gain?.toDouble(), s?.load?.takeIf { it > 0 }, s?.aerobicEffect?.takeIf { it > 0 },
            ProgressAnalytics.activityAbility(e, basis),
        )
    }
    val ma = metricOf(a); val mb = metricOf(b)
    val items = remember(acts) { acts.take(120).map { it.id to "${rtDateY(it.dateIso)} · ${if (it.type == "bike") "Sepeda" else "Lari"}" } }
    val paceD = { x: Double -> "${(x * 60.0).roundToInt()} dtk" }

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        RtDropdown("A", items, a.id, Modifier.weight(1f), onA)
        RtDropdown("B", items, b.id, Modifier.weight(1f), onB)
    }
    val rows = listOfNotNull(
        rtCmpRow("Jarak", ma.km, mb.km, { "${fmtKmUi(it)} km" }, { "${rtF1(it)} km" }),
        rtCmpRow("Waktu gerak", ma.sec, mb.sec, { rtDur(it.roundToInt()) }),
        rtCmpRow("Pace", ma.pace, mb.pace, { "${Js.paceStr(it)}/km" }, paceD),
        rtCmpRow("GAP", ma.gap, mb.gap, { "${Js.paceStr(it)}/km" }, paceD),
        rtCmpRow("Pace usaha", ma.effort, mb.effort, { "${Js.paceStr(it)}/km" }, paceD),
        rtCmpRow("HR rata-rata", ma.hr, mb.hr, { "${it.roundToInt()}" }),
        rtCmpRow("HR maks", ma.hrMax, mb.hrMax, { "${it.roundToInt()}" }),
        rtCmpRow("Kadens", ma.cad, mb.cad, { "${it.roundToInt()} spm" }),
        rtCmpRow("Panjang langkah", ma.stride, mb.stride, { "${rtF2(it)} m" }),
        rtCmpRow("Elevasi naik", ma.gain, mb.gain, { "${it.roundToInt()} m" }),
        rtCmpRow("Beban latihan", ma.load, mb.load, { "${it.roundToInt()}" }),
        rtCmpRow("Efek aerobik", ma.te, mb.te, { rtF1(it) }),
        rtCmpRow("Est. VO2max", ma.vo2, mb.vo2, { rtF1(it) }),
    )
    RcInner(pad = 8) {
        val w = listOf(1.35f, 1.1f, 1.1f, 1.1f)
        RcTableRow(listOf("Metrik", "A · ${rtDate(a.dateIso).uppercase(Locale.ROOT)}", "B · ${rtDate(b.dateIso).uppercase(Locale.ROOT)}", "Δ B−A"), w, head = true)
        rows.forEachIndexed { i, r -> RcTableRow(listOf(r.label, r.a, r.b, r.d), w, line = i < rows.lastIndex) }
    }
    RcInfo("Selisih Δ = B dikurangi A. Pace usaha adalah GAP yang dikoreksi panas. Beban latihan, efek aerobik, dan Est. VO2max dihitung dari HR sesi; aktivitas tanpa data HR atau sepeda dikosongkan (–).")
}

// ===================== 3. Heatmap rute =====================

@Composable
private fun RtHeatMini(map: RtMap, heightDp: Int) {
    val line = MaterialTheme.colorScheme.primary
    Canvas(Modifier.fillMaxWidth().height(heightDp.dp)) {
        val pad = 6.dp.toPx()
        val aw = (size.width - 2 * pad).coerceAtLeast(1f); val ah = (size.height - 2 * pad).coerceAtLeast(1f)
        val cw: Float; val ch: Float
        if (aw / ah > map.aspect) { ch = ah; cw = ah * map.aspect } else { cw = aw; ch = aw / map.aspect }
        val ox = pad + (aw - cw) / 2f; val oy = pad + (ah - ch) / 2f
        map.lines.forEach { pts ->
            if (pts.size >= 2) {
                val p = Path()
                pts.forEachIndexed { i, o ->
                    val x = ox + o.x * cw; val y = oy + o.y * ch
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                drawPath(p, line.copy(alpha = .35f), style = Stroke(1.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
    }
}

@Composable
private fun RtHeatCard(
    heat: List<RtPoly>, totalRuns: Int, mainArea: Boolean, onMainArea: (Boolean) -> Unit,
    open: Boolean, onToggle: () -> Unit, modifier: Modifier,
) {
    val cs = MaterialTheme.colorScheme
    var tiles by rememberSaveable { mutableStateOf(true) }
    val shown = remember(heat, mainArea) { if (mainArea) heat.filter { it.main } else heat }
    val mini = remember(shown) { rtMiniMap(shown.map { it.pts }) }
    val bounds = remember(shown) { rtBounds(shown.map { it.pts }) }
    val widthKm = remember(shown) {
        val all = shown.flatMap { it.pts }
        if (all.isEmpty()) 0.0 else {
            val lonSpan = all.maxOf { it.lon } - all.minOf { it.lon }
            lonSpan * 111.32 * cos(Math.toRadians(all.map { it.lat }.average()))
        }
    }
    RcCard(Icons.Outlined.Timeline, "HEATMAP RUTE", open, onToggle, modifier,
        headText = if (mainArea) "${shown.size} lari (dari $totalRuns)" else "${shown.size} lari",
        summary = {
            RcBig("$totalRuns lari", if (mainArea) "area utama" else "semua area")
            if (mini == null) RcMuted("Belum ada rute dengan koordinat.") else RtHeatMini(mini, 96)
        },
        body = {
            if (shown.isEmpty()) {
                RcMuted("Belum ada rute dengan koordinat. Impor aktivitas FIT/GPX/TCX atau sinkronkan dari jam.")
            } else {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    RcSeg(listOf("Area utama", "Semua"), if (mainArea) 0 else 1) { onMainArea(it == 0) }
                    RcSeg(listOf("Peta", "Polos"), if (tiles) 0 else 1) { tiles = it == 0 }
                }
                RcInner(pad = 8) {
                    val glow = Color(0xFFFFA24A)
                    RtTileMap(bounds, if (mainArea) "heat-main" else "heat-all", tiles, 300.dp, Color(0xFF2B2D30), dim = .74f, pad = .05) { proj ->
                        val sw = 2.dp.toPx()
                        shown.forEach { poly ->
                            val path = rtPolyline(poly.pts, proj)
                            drawPath(path, glow.copy(alpha = .09f), style = Stroke(sw * 2.8f, cap = StrokeCap.Round, join = StrokeJoin.Round), blendMode = BlendMode.Plus)
                            drawPath(path, glow.copy(alpha = .26f), style = Stroke(sw * .8f, cap = StrokeCap.Round, join = StrokeJoin.Round), blendMode = BlendMode.Plus)
                        }
                    }
                    RcMono("Makin terang berarti makin sering dilewati. Lebar area sekitar ${rtF1(widthKm)} km.")
                }
            }
        })
}

// ===================== 4. Ridgeline elevasi 3D =====================

@Composable
private fun RtRidgeCard(runs: List<RtRun>, open: Boolean, onToggle: () -> Unit, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val counts = listOf(4, 6, 8, 12)
    var nIdx by rememberSaveable { mutableIntStateOf(1) }
    var absolute by rememberSaveable { mutableStateOf(false) }
    var sel by rememberSaveable { mutableLongStateOf(-1L) }
    val withProfile = remember(runs) { runs.filter { it.d.profile.size >= 2 } }
    val items = remember(withProfile, nIdx) { withProfile.takeLast(counts[nIdx]) }
    val defaultItems = remember(withProfile) { withProfile.takeLast(6) }
    val gains = defaultItems.map { it.gain ?: 0 }
    RcCard(Icons.Outlined.Terrain, "RIDGELINE ELEVASI 3D", open, onToggle, modifier,
        headText = "${items.size} lari",
        summary = {
            if (defaultItems.isEmpty()) {
                RcMuted("Belum ada profil elevasi.")
            } else {
                RcBig("+${Js.idn(gains.sum())} m", "dari ${defaultItems.size} lari")
                val mx = (gains.maxOrNull() ?: 1).coerceAtLeast(1)
                Row(Modifier.fillMaxWidth().height(48.dp), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.Bottom) {
                    gains.forEachIndexed { i, g ->
                        val last = i == gains.lastIndex
                        Box(
                            Modifier.weight(1f).height((6 + 42f * g / mx).dp).clip(RoundedCornerShape(4.dp))
                                .background(if (last) cs.primary else cs.primary.copy(alpha = .16f)),
                        )
                    }
                }
            }
        },
        body = {
            if (items.isEmpty()) {
                RcMuted("Belum ada profil elevasi. Impor aktivitas FIT/GPX/TCX atau sinkronkan dari jam.")
            } else {
                val selId = items.firstOrNull { it.a.id == sel }?.a?.id ?: items.last().a.id
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    RcSeg(counts.map { "$it" }, nIdx) { nIdx = it }
                    RcSeg(listOf("Relatif", "Absolut"), if (absolute) 1 else 0) { absolute = it == 1 }
                }
                RcInner(pad = 8) { RtRidgeChart(items, absolute, selId) }
                RcInfo("Relatif: tiap lari mulai dari titik terendahnya sendiri dengan skala meter yang sama, jadi tinggi bukit bisa dibandingkan langsung. Absolut: semua lari memakai ketinggian di atas permukaan laut yang sama.")
                RcInfo("Label kanan: tanggal, jarak, dan elevasi naik. Ketuk tanggal di bawah untuk menyorot satu lari; titik menandai ketinggian awalnya.")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items.asReversed().forEach { r ->
                        val on = r.a.id == selId
                        val shape = RoundedCornerShape(99.dp)
                        Box(
                            Modifier.clip(shape)
                                .then(if (on) Modifier.background(GRAD) else Modifier.border(.8.dp, cs.outlineVariant, shape).background(cs.surfaceVariant))
                                .clickable { sel = r.a.id }.padding(horizontal = 14.dp, vertical = 9.dp),
                        ) {
                            Text(rtDate(r.a.dateIso), style = MaterialTheme.typography.labelLarge,
                                color = if (on) Color.White else cs.onSurfaceVariant, maxLines = 1)
                        }
                    }
                }
            }
        })
}

/** Ridgeline: profil elevasi beberapa lari terakhir bertumpuk (terlama di atas, terbaru di depan); label di kanan. */
@Composable
private fun RtRidgeChart(items: List<RtRun>, absolute: Boolean, selId: Long) {
    val cs = MaterialTheme.colorScheme
    val tm = rememberTextMeasurer()
    val ts = tickStyle()
    val series = remember(items) { items.map { r -> r to ProgressTabs.resample(r.d.profile, 90) } }
    val n = series.size
    val ridgeDp = 64; val stepDp = 36; val topDp = 22
    val fillBase = lerp(cs.surfaceVariant, cs.primary, .14f)
    val fillSel = lerp(cs.surfaceVariant, cs.primary, .30f)
    Canvas(Modifier.fillMaxWidth().height((topDp + ridgeDp + stepDp * (n - 1).coerceAtLeast(0) + 6).dp)) {
        val plotL = 6.dp.toPx(); val plotW = size.width * .60f
        val ridgeH = ridgeDp.dp.toPx(); val step = stepDp.dp.toPx(); val top = topDp.dp.toPx()
        val maxKm = series.maxOf { (r, _) -> r.d.profile.maxOfOrNull { it.first } ?: r.a.km }.coerceAtLeast(0.1)
        val relRange = series.maxOf { (_, v) -> (v.maxOrNull() ?: 0f) - (v.minOrNull() ?: 0f) }.coerceAtLeast(8f)
        val absMin = series.minOf { (_, v) -> v.minOrNull() ?: 0f }
        val absRange = (series.maxOf { (_, v) -> v.maxOrNull() ?: 0f } - absMin).coerceAtLeast(8f)
        val k = ridgeH * .92f / (if (absolute) absRange else relRange)
        series.forEachIndexed { i, (r, vals) ->
            if (vals.isEmpty()) return@forEachIndexed
            val isSel = r.a.id == selId
            val base = top + ridgeH + i * step
            val ref = if (absolute) absMin else (vals.minOrNull() ?: 0f)
            val km = r.d.profile.maxOfOrNull { it.first } ?: r.a.km
            val w = plotW * (km / maxKm).toFloat()
            val line = Path(); val area = Path()
            vals.forEachIndexed { j, v ->
                val x = plotL + w * j / (vals.size - 1).coerceAtLeast(1)
                val y = base - (v - ref) * k
                if (j == 0) { line.moveTo(x, y); area.moveTo(x, base); area.lineTo(x, y) } else { line.lineTo(x, y); area.lineTo(x, y) }
            }
            area.lineTo(plotL + w, base); area.close()
            drawPath(area, if (isSel) fillSel else fillBase)
            drawLine(cs.outlineVariant.copy(alpha = .7f), Offset(plotL, base), Offset(plotL + w, base), 1.dp.toPx())
            drawPath(line, if (isSel) cs.primary else cs.primary.copy(alpha = .8f),
                style = Stroke(if (isSel) 2.4.dp.toPx() else 1.7.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            val c = if (isSel) cs.primary else cs.onSurfaceVariant
            val l1 = tm.measure(rtDate(r.a.dateIso), ts.copy(color = c))
            val txt2 = "${rtF1(r.a.km).removeSuffix(",0")} km · +${r.gain ?: 0}"
            val l2 = tm.measure(txt2, ts.copy(color = c))
            val right = size.width - 2.dp.toPx()
            drawText(l1, topLeft = Offset(right - l1.size.width, base - 27.dp.toPx()))
            drawText(l2, topLeft = Offset(right - l2.size.width, base - 15.dp.toPx()))
            if (isSel) {
                val e0 = r.d.profile.sortedBy { it.first }.first().second
                val o = Offset(plotL + 0f, base - (vals.first() - ref) * k)
                drawCircle(Color.White, 6.dp.toPx(), o)
                drawCircle(cs.primary, 4.dp.toPx(), o)
                val m = tm.measure("${Js.idn(e0.roundToInt())} m", ts)
                drawText(m, topLeft = Offset(o.x, (o.y - 20.dp.toPx()).coerceAtLeast(0f)))
            }
        }
    }
}

// ===================== 5. Dampak cuaca =====================

@Composable
private fun RtScatter(points: List<Pair<Double, Double>>, tr: ProgressTabs.Trend?, invertY: Boolean, yFmt: (Double) -> String) {
    if (points.size < 2) {
        RcMuted("Belum cukup lari bercuaca untuk scatter.")
        return
    }
    val cs = MaterialTheme.colorScheme
    val tm = rememberTextMeasurer()
    val ts = tickStyle()
    val grid = cs.outlineVariant; val dot = cs.primary
    Canvas(Modifier.fillMaxWidth().height(240.dp)) {
        val l = 46.dp.toPx(); val r = 14.dp.toPx(); val t = 12.dp.toPx(); val b = 28.dp.toPx()
        val minX = floor(points.minOf { it.first }); val maxX = ceil(points.maxOf { it.first }).coerceAtLeast(minX + 1.0)
        val rawMinY = points.minOf { it.second }; val rawMaxY = points.maxOf { it.second }
        val padY = ((rawMaxY - rawMinY) * .08).coerceAtLeast(1e-6)
        val minY = rawMinY - padY; val maxY = rawMaxY + padY
        val spanX = maxX - minX; val spanY = maxY - minY
        fun px(x: Double) = l + (size.width - l - r) * ((x - minX) / spanX).toFloat()
        fun py(y: Double): Float {
            val f = ((y - minY) / spanY).toFloat()
            return t + (size.height - t - b) * (if (invertY) f else 1f - f)
        }
        // garis dan label sumbu Y: bawah, tengah, atas
        listOf(minY, (minY + maxY) / 2.0, maxY).forEach { v ->
            val y = py(v)
            drawLine(grid.copy(alpha = .7f), Offset(l, y), Offset(size.width - r, y), 1.dp.toPx())
            val m = tm.measure(yFmt(v), ts)
            drawText(m, topLeft = Offset(l - 6.dp.toPx() - m.size.width, y - m.size.height / 2f))
        }
        // label sumbu X tiap 2°C (tiap 5°C bila rentang lebar)
        val stepX = if (spanX > 14.0) 5.0 else 2.0
        var tx = ceil(minX / stepX) * stepX
        while (tx <= maxX + 1e-9) {
            val m = tm.measure("${tx.roundToInt()}°", ts)
            drawText(m, topLeft = Offset(px(tx) - m.size.width / 2f, size.height - b + 8.dp.toPx()))
            tx += stepX
        }
        points.forEach { (x, y) -> drawCircle(dot.copy(alpha = .55f), 4.5.dp.toPx(), Offset(px(x), py(y))) }
        if (tr != null) {
            val x0 = points.minOf { it.first }; val x1 = points.maxOf { it.first }
            val y0 = (tr.intercept + tr.slope * x0).coerceIn(minY, maxY)
            val y1 = (tr.intercept + tr.slope * x1).coerceIn(minY, maxY)
            drawLine(cs.primary, Offset(px(x0), py(y0)), Offset(px(x1), py(y1)), 2.dp.toPx(), cap = StrokeCap.Round,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 9f)))
        }
    }
}

@Composable
private fun RtWeather(wx: List<RtWx>, open: Boolean, onToggle: () -> Unit, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    var metric by rememberSaveable { mutableIntStateOf(0) }      // 0 pace, 1 HR
    var feels by rememberSaveable { mutableIntStateOf(0) }       // 0 aktual, 1 terasa
    var easyOnly by rememberSaveable { mutableIntStateOf(0) }    // 0 semua, 1 easy
    val hasHr = wx.count { it.hr != null } >= 3
    val m = if (metric == 1 && hasHr) 1 else 0
    val src = if (easyOnly == 1) wx.filter { it.easy } else wx
    val pts = src.mapNotNull { w ->
        val x = if (feels == 1) (w.feels ?: w.temp) else w.temp
        (if (m == 0) w.pace else w.hr)?.let { x to it }
    }
    val tr = ProgressTabs.trend(pts)
    val bands = (0..2).map { bi -> wx.filter { ProgressTabs.tempBand(it.temp) == bi } }
    val bandPace = bands.map { rows -> rows.takeIf { it.isNotEmpty() }?.map { it.pace }?.average() }
    RcCard(Icons.Outlined.WbSunny, "DAMPAK CUACA", open, onToggle, modifier,
        headText = if (m == 0) "pace vs suhu" else "HR vs suhu",
        summary = {
            if (wx.isEmpty()) {
                RcMuted("Arsip cuaca historis belum tersedia pada data aktivitas ini.")
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ProgressTabs.BAND_LABELS.forEachIndexed { i, label ->
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(label.removeSuffix("C"), style = monoStyle(10f, 0f), color = cs.onSurfaceVariant, maxLines = 1)
                            Text(bandPace[i]?.let { Js.paceStr(it) } ?: "–", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, maxLines = 1)
                        }
                    }
                }
                val valid = bandPace.filterNotNull()
                val lo = valid.minOrNull() ?: 0.0; val hi = valid.maxOrNull() ?: 0.0
                Row(Modifier.fillMaxWidth().height(52.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Bottom) {
                    val tints = listOf(cs.primary.copy(alpha = .16f), cs.primary.copy(alpha = .30f), cs.primary)
                    bandPace.forEachIndexed { i, p ->
                        val h = if (p == null) 8f else if (hi - lo < 1e-6) 30f else (16f + 36f * ((p - lo) / (hi - lo)).toFloat())
                        Box(Modifier.weight(1f).height(h.dp).clip(RoundedCornerShape(5.dp)).background(tints[i]))
                    }
                }
            }
        },
        body = {
            if (wx.isEmpty()) {
                RcMuted("Arsip cuaca historis belum tersedia pada data aktivitas ini.")
            } else {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (hasHr) RcSeg(listOf("Pace", "HR"), m) { metric = it } else RcSeg(listOf("Pace"), 0) {}
                    RcSeg(listOf("Aktual", "Terasa"), feels) { feels = it }
                    RcSeg(listOf("Semua", "Easy"), easyOnly) { easyOnly = it }
                }
                RcInner(pad = 8) {
                    RtScatter(pts, tr, invertY = m == 0, yFmt = { if (m == 0) Js.paceStr(it) else "${it.roundToInt()}" })
                }
                RtWxInsight(pts.size, tr, m)
                RcInfo("Korelasi bukan sebab-akibat; medan, intensitas, tidur, dan kelelahan juga memengaruhi pace. Garis tren putus-putus adalah regresi linear sederhana dari titik yang ada. \"Terasa\" memakai suhu terasa bila tersedia; \"Easy\" hanya lari dengan HR di bawah zona 3 atau yang ditandai easy.")
            }
        })
}

@Composable
private fun RtWxInsight(n: Int, tr: ProgressTabs.Trend?, m: Int) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(14.dp)
    val text = if (tr == null) {
        "Belum cukup lari untuk membaca tren suhu."
    } else {
        val per5 = tr.slope * 5.0
        val r = tr.r?.let { rtF1(it) } ?: "–"
        val first = if (m == 0) {
            "Setiap +5°C, pace ${if (per5 >= 0) "melambat" else "menguat"} ${(abs(per5) * 60.0).roundToInt()} dtk/km (r $r, $n lari)."
        } else {
            "Setiap +5°C, HR ${if (per5 >= 0) "naik" else "turun"} ${abs(per5).roundToInt()} bpm (r $r, $n lari)."
        }
        "$first Hubungannya ${ProgressTabs.corrLabel(tr.r)}; usaha dan medan juga berpengaruh."
    }
    Box(Modifier.fillMaxWidth().clip(shape).background(cs.surfaceVariant).border(.8.dp, cs.outlineVariant, shape).padding(14.dp)) {
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
}
