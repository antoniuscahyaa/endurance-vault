package com.endurancevault.app.widget

import android.content.Context
import com.endurancevault.app.EnduranceVaultApp
import com.endurancevault.app.data.MvStore
import com.endurancevault.app.data.ReadinessHistoryStore
import com.endurancevault.app.data.ReadinessPrefs
import com.endurancevault.app.domain.AdjInput
import com.endurancevault.app.domain.Kinds
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.PlanRaw
import com.endurancevault.app.domain.ProfilePlanAdjustments
import com.endurancevault.app.domain.SessionAdjust
import com.endurancevault.app.domain.TrainingMetrics
import com.endurancevault.app.ui.i18n.Lang
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.time.temporal.ChronoUnit

/** Satu baris sesi pada widget "Sesi berikutnya". */
class WidgetNext(val whenLabel: String, val title: String, val km: String)

/** Data ringkas untuk ketiga widget; dibangun dari sumber yang sama dengan layar Today (rencana + aktivitas + kesiapan). */
class WidgetSnapshot(
    val dateLabel: String,
    val todayTitle: String,
    val todaySub: String,
    val todayDone: Boolean,
    val readiness: Int?,
    val next: List<WidgetNext>,
    val weekDone: Double,
    val weekTarget: Double,
    val dayKm: DoubleArray,
    val dayLabels: List<String>,
    val todayIdx: Int,
)

object WidgetData {
    private fun km(x: Double): String {
        val s = if (x == Math.floor(x)) x.toLong().toString() else String.format(java.util.Locale.US, "%.1f", x)
        return if (Lang.current == com.endurancevault.app.ui.i18n.AppLang.ID) s.replace('.', ',') else s
    }

    /** Membaca database dan menyusun ulang rencana seperti MainViewModel. Panggil dari thread latar. */
    suspend fun load(ctx: Context, initLang: Boolean = true): WidgetSnapshot {
        // Dari dalam aplikasi (pratinjau) bahasa sudah dimuat; hanya proses widget yang perlu memuatnya sendiri.
        if (initLang) Lang.load(ctx)
        val app = ctx.applicationContext as EnduranceVaultApp
        val s = app.settings.load()
        val acts = app.db.activities().all()
        val daily = app.db.companion().allDaily()
        val mv = MvStore.parse(app.db.companion().kv("mv"))
        val done = MvStore.parseDone(app.db.companion().kv("done"))
        val today = LocalDate.now()
        val sx = s.copy(logHrMax = acts.mapNotNull { it.maxHr }.filter { it in 100..220 }.maxOrNull() ?: 0)
        val restDef = com.endurancevault.app.ui.screens.restHrFrom(daily).first
        val raw = PlanRaw.plan(sx, easyPace = com.endurancevault.app.ui.easyPaceOf(sx, acts, restDef), restDefault = restDef)
        val swapped = SessionAdjust.apply(raw, AdjInput(today, mv, done, SessionAdjust.loggedKm(acts), s.hr))
        val plan = ProfilePlanAdjustments.apply(swapped, sx, acts)
        val planOk = plan as? PlanOutcome.Ok
        val week = planOk?.weeks?.firstOrNull { !today.isBefore(it.start) && !today.isAfter(it.end) }
        val day = week?.days?.firstOrNull { it.date == today }
        val freeMode = s.rtype == "none"

        // Kesiapan: pakai nilai yang sudah dicatat aplikasi hari ini (sama persis dengan kartu Today); bila belum ada, hitung.
        val readiness = ReadinessHistoryStore.load(ctx).lastOrNull { it.date == today }?.score
            ?: runCatching {
                val cfg = ReadinessPrefs.load(ctx.getSharedPreferences(ReadinessPrefs.FILE, Context.MODE_PRIVATE))
                TrainingMetrics.calculate(sx, acts, daily, plan, today, readinessConfig = cfg).readiness?.score
            }.getOrNull()

        val ranToday = acts.any { it.dateIso == today.toString() && it.km > 0 }
        val title = when {
            day == null && freeMode -> Lang.tr("Latihan fleksibel")
            day == null -> Lang.tr("Tidak ada sesi terjadwal")
            day.kind == Kinds.REST -> Lang.tr("Libur")
            else -> day.title
        }
        val sub = when {
            ranToday -> Lang.tr("Selesai hari ini")
            day != null && day.kind != Kinds.REST && day.km > 0 -> "${km(day.km)} km"
            else -> ""
        }

        val next = ArrayList<WidgetNext>()
        if (planOk != null) {
            val upcoming = planOk.weeks.flatMap { it.days }.filter { it.date.isAfter(today) && it.kind != Kinds.REST }.sortedBy { it.date }
            for (d in upcoming.take(3)) {
                val diff = ChronoUnit.DAYS.between(today, d.date).toInt()
                val whenLabel = when (diff) {
                    1 -> Lang.tr("Besok")
                    2 -> Lang.tr("Lusa")
                    else -> d.date.dayOfWeek.getDisplayName(TextStyle.SHORT, Lang.locale)
                }
                next.add(WidgetNext(whenLabel, d.title, if (d.km > 0) "${km(d.km)} km" else ""))
            }
        }

        val weekStart = today.with(DayOfWeek.MONDAY)
        val dayKm = DoubleArray(7)
        for (a in acts) {
            if (a.type == "bike" || a.km <= 0) continue
            val i = runCatching { ChronoUnit.DAYS.between(weekStart, LocalDate.parse(a.dateIso)).toInt() }.getOrDefault(-1)
            if (i in 0..6) dayKm[i] += a.km
        }
        val labels = (0..6).map { weekStart.plusDays(it.toLong()).dayOfWeek.getDisplayName(TextStyle.NARROW, Lang.locale) }

        return WidgetSnapshot(
            dateLabel = today.format(DateTimeFormatter.ofPattern("EEEE, d MMM", Lang.locale)).uppercase(Lang.locale),
            todayTitle = title, todaySub = sub, todayDone = ranToday, readiness = readiness,
            next = next, weekDone = dayKm.sum(), weekTarget = week?.km ?: 0.0,
            dayKm = dayKm, dayLabels = labels, todayIdx = ChronoUnit.DAYS.between(weekStart, today).toInt().coerceIn(0, 6),
        )
    }
}
