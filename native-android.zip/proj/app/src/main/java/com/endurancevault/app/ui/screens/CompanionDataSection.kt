package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.theme.EvButton

import com.endurancevault.app.ui.i18n.Text
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.data.DailyEntity
import com.endurancevault.app.data.GearEntity
import java.time.LocalDate
import java.util.UUID

@Composable
fun CompanionDataSection(
    daily: List<DailyEntity>,
    onSaveDaily: (DailyEntity) -> Unit,
) {
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var leg by remember { mutableStateOf("3") }
    var mood by remember { mutableStateOf("3") }
    var dailyError by remember { mutableStateOf<String?>(null) }


    val full = Modifier.fillMaxWidth()
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Kondisi harian", style = MaterialTheme.typography.titleLarge)
        Text("Data tidur, HR istirahat, dan HRV diambil otomatis dari sinkronisasi jam. Di sini cukup catat Leg feel dan Mood.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        DateField(date, { date = it }, "Tanggal", modifier = full)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(leg, { leg = it }, label = { Text("Rasa kaki 1–5") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
            OutlinedTextField(mood, { mood = it }, label = { Text("Stres 1–5") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
        }
        dailyError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        EvButton(onClick = {
            val parsedDate = runCatching { LocalDate.parse(date) }.getOrNull()
            val l = leg.toIntOrNull(); val m = mood.toIntOrNull()
            val existing = daily.firstOrNull { it.dateIso == date }
            if (parsedDate == null || l == null || l !in 1..5 || m == null || m !in 1..5) {
                dailyError = "Periksa tanggal serta Leg feel dan Mood (1–5)."
            } else {
                dailyError = null
                onSaveDaily(
                    DailyEntity(
                        dateIso = date,
                        rhr = existing?.rhr,
                        hrv = existing?.hrv,
                        leg = l,
                        mood = m,
                        sleepH = existing?.sleepH,
                        raw = existing?.raw ?: "{}",
                    )
                )
            }
        }, modifier = full) { Text("Simpan kondisi harian") }
        Text("Riwayat kondisi", style = MaterialTheme.typography.titleMedium)
        daily.take(5).forEach { d ->
            Text("${d.dateIso}  ·  Leg feel ${d.leg ?: "—"}  ·  Mood ${d.mood ?: "—"}  ·  tidur ${d.sleepH?.let { "%.1f jam".format(it) } ?: "dari jam"}", style = MaterialTheme.typography.bodySmall)
        }

    }
}
