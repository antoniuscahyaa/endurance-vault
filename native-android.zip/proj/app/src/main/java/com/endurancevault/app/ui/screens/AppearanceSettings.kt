package com.endurancevault.app.ui.screens

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.endurancevault.app.ui.i18n.Text
import com.endurancevault.app.ui.theme.AccentTheme
import com.endurancevault.app.ui.theme.AppFont
import com.endurancevault.app.ui.theme.EvButton
import com.endurancevault.app.ui.theme.ThemePrefs
import com.endurancevault.app.ui.theme.cardTint
import com.endurancevault.app.ui.theme.evTone
import com.endurancevault.app.ui.theme.onCardTint
import com.endurancevault.app.widget.WidgetTextPrefs
import kotlin.math.roundToInt

private val Swatches = listOf(
    0xFF6D5AE6, 0xFF2563EB, 0xFF0E9F8E, 0xFF2EB872, 0xFFD9A400,
    0xFFF97316, 0xFFE4572E, 0xFFEC4899, 0xFFA855F7, 0xFF475569,
).map { it.toInt() }

private fun hueOf(argb: Int): Float {
    val a = FloatArray(3)
    android.graphics.Color.colorToHSV(argb, a)
    return a[0]
}

private fun fromHue(h: Float): Int = android.graphics.Color.HSVToColor(floatArrayOf(h.coerceIn(0f, 360f), 0.75f, 0.8f))

/**
 * Bagian pengaturan tampilan: pratinjau langsung, warna aksen (termasuk warna sendiri), font, dan ukuran teks.
 * Semua pilihan berlaku seketika dan tersimpan; tema default tetap tidak berubah.
 */
@Composable
internal fun AppearanceSection(ctx: Context) {
    val cs = MaterialTheme.colorScheme

    EvGroupTitle("Pratinjau", "Contoh langsung dari pilihan di bawah")
    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.cardTint).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Text("SELAMAT MALAM", style = MaterialTheme.typography.labelMedium, color = cs.onCardTint)
                Text("Besok: Easy run 8 km", style = MaterialTheme.typography.titleMedium)
                Text("Zona 2 · 52 menit", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PreviewRing("TIDUR", 0.82f, "82", 0, Modifier.weight(1f))
                PreviewRing("KESIAPAN", 0.64f, "64", 1, Modifier.weight(1f))
                PreviewRing("ZONA HR", 0.78f, "78%", 2, Modifier.weight(1f))
            }
            EvButton(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("Mulai sesi") }
        }
    }

    EvGroupTitle("Pratinjau widget", "Seperti tampilan widget di layar utama, mengikuti tema yang dipilih")
    WidgetPreviews(ctx)

    WidgetTextColorSection(ctx)

    EvGroupTitle("Warna aksen", "Pilih warna tambahan di luar default. Berlaku untuk mode terang dan gelap")
    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            AccentTheme.values().forEach { a ->
                val on = ThemePrefs.accent == a
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(cs.surfaceVariant)
                        .clickable { ThemePrefs.setAccent(ctx, a) }
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(a.label, style = MaterialTheme.typography.titleSmall, color = if (on) cs.onCardTint else cs.onSurface)
                        Text(a.note, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    }
                    if (on) Text("Aktif", style = MaterialTheme.typography.labelMedium, color = cs.onCardTint)
                }
            }
            if (ThemePrefs.accent == AccentTheme.CUSTOM) CustomColorPicker(ThemePrefs.customColor) { ThemePrefs.setCustom(ctx, it) }
        }
    }

    EvGroupTitle("Font", "Ganti jenis huruf di seluruh aplikasi. Contoh teks memakai font masing-masing")
    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            AppFont.values().forEach { f ->
                val on = ThemePrefs.font == f
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(cs.surfaceVariant)
                        .clickable { ThemePrefs.setFont(ctx, f) }
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text("Aa", style = MaterialTheme.typography.headlineSmall.copy(fontFamily = f.family), color = if (on) cs.onCardTint else cs.onSurface)
                    Column(Modifier.weight(1f)) {
                        Text(f.label, style = MaterialTheme.typography.titleSmall.copy(fontFamily = f.family), color = if (on) cs.onCardTint else cs.onSurface)
                        Text(f.note, style = MaterialTheme.typography.bodySmall.copy(fontFamily = f.family), color = cs.onSurfaceVariant)
                    }
                    if (on) Text("Aktif", style = MaterialTheme.typography.labelMedium, color = cs.onCardTint)
                }
            }
        }
    }

    EvGroupTitle("Ukuran teks", "Perbesar atau perkecil semua teks. Tata letak tetap, hanya huruf yang berubah")
    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${(ThemePrefs.fontScale * 100).roundToInt()}%", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                TextButton(onClick = { ThemePrefs.setFontScale(ctx, 1f) }, enabled = ThemePrefs.fontScale != 1f) { Text("Atur ulang") }
            }
            Slider(
                value = ThemePrefs.fontScale,
                onValueChange = { ThemePrefs.setFontScale(ctx, ((it * 20f).roundToInt() / 20f)) },
                valueRange = 0.85f..1.3f,
                steps = 8,
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Kecil", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                Text("Besar", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun CustomColorPicker(current: Int, onPick: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(cs.surface)
            .border(BorderStroke(0.8.dp, cs.outlineVariant), RoundedCornerShape(12.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("Pilih warna", style = MaterialTheme.typography.labelLarge)
        listOf(Swatches.take(5), Swatches.drop(5)).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                row.forEach { c ->
                    val sel = c == current
                    Box(
                        Modifier.size(38.dp).clip(CircleShape).background(Color(c))
                            .then(if (sel) Modifier.border(3.dp, cs.onSurface, CircleShape) else Modifier)
                            .clickable { onPick(c) },
                    )
                }
            }
        }
        Text("Atau geser untuk warna lain", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        Box(Modifier.fillMaxWidth().height(28.dp), contentAlignment = Alignment.Center) {
            val rainbow = Brush.horizontalGradient((0..6).map { Color(fromHue(it * 60f)) })
            Box(Modifier.fillMaxWidth().height(10.dp).clip(CircleShape).background(rainbow))
            Slider(
                value = hueOf(current),
                onValueChange = { onPick(fromHue(it)) },
                valueRange = 0f..360f,
                colors = SliderDefaults.colors(activeTrackColor = Color.Transparent, inactiveTrackColor = Color.Transparent),
            )
        }
    }
}

@Composable
private fun PreviewRing(title: String, pct: Float, big: String, toneIndex: Int, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val tone = evTone(toneIndex)
    val ringColor = tone?.content ?: cs.primary
    val track = cs.outlineVariant
    Column(
        modifier.clip(RoundedCornerShape(14.dp)).background(tone?.container ?: cs.surfaceVariant).padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Text(title, style = MaterialTheme.typography.labelSmall, color = ringColor, textAlign = TextAlign.Center, maxLines = 1)
        Box(Modifier.size(52.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(52.dp)) {
                val sw = 5.dp.toPx()
                val d = size.minDimension - sw
                val tl = Offset(sw / 2f, sw / 2f)
                drawArc(track, 0f, 360f, false, tl, Size(d, d), style = Stroke(sw))
                drawArc(ringColor, -90f, 360f * pct, false, tl, Size(d, d), style = Stroke(sw, cap = StrokeCap.Round))
            }
            Text(big, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
    }
}

private const val PREVIEW_W_DP = 300
private const val PREVIEW_H_DP = 130

/** Menggambar ketiga widget dengan renderer yang sama dengan widget sebenarnya, memakai data aktual aplikasi. */
@Composable
private fun WidgetPreviews(ctx: Context) {
    val cs = MaterialTheme.colorScheme
    val snap by androidx.compose.runtime.produceState<com.endurancevault.app.widget.WidgetSnapshot?>(null, ctx) {
        value = runCatching {
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                com.endurancevault.app.widget.WidgetData.load(ctx, initLang = false)
            }
        }.getOrNull()
    }
    val systemDark = androidx.compose.foundation.isSystemInDarkTheme()
    val images = androidx.compose.runtime.remember(snap, ThemePrefs.accent, ThemePrefs.customColor, ThemePrefs.mode, ThemePrefs.fontScale, systemDark) {
        snap?.let { sn ->
            com.endurancevault.app.widget.WidgetKind.values().map {
                com.endurancevault.app.widget.WidgetRenderer.render(ctx, it, sn, PREVIEW_W_DP, PREVIEW_H_DP).asImageBitmap()
            }
        }
    }
    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (images == null) {
                Text(if (snap == null) "Memuat pratinjau…" else "Pratinjau widget tidak tersedia", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            } else {
                images.forEach { img ->
                    androidx.compose.foundation.Image(
                        bitmap = img, contentDescription = null,
                        modifier = Modifier.fillMaxWidth().aspectRatio(PREVIEW_W_DP.toFloat() / PREVIEW_H_DP),
                    )
                }
            }
        }
    }
}

/** Pengaturan warna teks widget "Hari ini" (layar utama). Hanya mengubah warna font; ukuran dan tata letak tetap. */
@Composable
private fun WidgetTextColorSection(ctx: Context) {
    val cs = MaterialTheme.colorScheme
    var mode by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(WidgetTextPrefs.mode(ctx)) }
    var custom by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(WidgetTextPrefs.customColor(ctx)) }
    val options = listOf(
        Triple(WidgetTextPrefs.Mode.AUTO, "Otomatis", "Putih atau gelap mengikuti wallpaper"),
        Triple(WidgetTextPrefs.Mode.LIGHT, "Putih", "Untuk wallpaper gelap"),
        Triple(WidgetTextPrefs.Mode.DARK, "Gelap", "Untuk wallpaper terang"),
        Triple(WidgetTextPrefs.Mode.CUSTOM, "Warna sendiri", "Pilih warna teks sesuka Anda"),
    )
    EvGroupTitle("Warna teks widget", "Hanya mengubah warna font widget Hari ini di layar utama")
    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (m, label, note) ->
                val on = mode == m
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(cs.surfaceVariant)
                        .clickable { mode = m; WidgetTextPrefs.setMode(ctx, m) }
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(label, style = MaterialTheme.typography.titleSmall, color = if (on) cs.onCardTint else cs.onSurface)
                        Text(note, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    }
                    if (m == WidgetTextPrefs.Mode.CUSTOM) Box(Modifier.size(22.dp).clip(CircleShape).background(Color(custom)).border(1.dp, cs.outlineVariant, CircleShape))
                    if (on) Text("Aktif", style = MaterialTheme.typography.labelMedium, color = cs.onCardTint, modifier = Modifier.padding(start = 10.dp))
                }
            }
            if (mode == WidgetTextPrefs.Mode.CUSTOM) CustomColorPicker(custom) { c -> custom = c; WidgetTextPrefs.setCustom(ctx, c) }
        }
    }
}
