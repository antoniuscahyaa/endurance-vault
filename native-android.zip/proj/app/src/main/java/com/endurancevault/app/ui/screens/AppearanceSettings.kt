package com.endurancevault.app.ui.screens

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.endurancevault.app.ui.i18n.Text
import com.endurancevault.app.ui.theme.AccentTheme
import com.endurancevault.app.ui.theme.AppFont
import com.endurancevault.app.ui.theme.EvButton
import com.endurancevault.app.ui.theme.ThemePrefs
import com.endurancevault.app.ui.theme.cardTint
import com.endurancevault.app.ui.theme.evTone
import com.endurancevault.app.ui.theme.onCardTint
import com.endurancevault.app.widget.WidgetTextPrefs
import kotlin.math.roundToInt

private val Swatches = listOf(
    0xFF6D5AE6, 0xFF2563EB, 0xFF0E9F8E, 0xFF2EB872, 0xFFD9A400,
    0xFFF97316, 0xFFE4572E, 0xFFEC4899, 0xFFA855F7, 0xFF475569,
).map { it.toInt() }

private fun hueOf(argb: Int): Float {
    val a = FloatArray(3)
    android.graphics.Color.colorToHSV(argb, a)
    return a[0]
}

private fun fromHue(h: Float): Int = android.graphics.Color.HSVToColor(floatArrayOf(h.coerceIn(0f, 360f), 0.75f, 0.8f))

@Composable
internal fun CustomColorPicker(current: Int, onPick: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(cs.surface)
            .border(BorderStroke(0.8.dp, cs.outlineVariant), RoundedCornerShape(12.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("Pilih warna", style = MaterialTheme.typography.labelLarge)
        listOf(Swatches.take(5), Swatches.drop(5)).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                row.forEach { c ->
                    val sel = c == current
                    Box(
                        Modifier.size(38.dp).clip(CircleShape).background(Color(c))
                            .then(if (sel) Modifier.border(3.dp, cs.onSurface, CircleShape) else Modifier)
                            .clickable { onPick(c) },
                    )
                }
            }
        }
        Text("Atau geser untuk warna lain", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        Box(Modifier.fillMaxWidth().height(28.dp), contentAlignment = Alignment.Center) {
            val rainbow = Brush.horizontalGradient((0..6).map { Color(fromHue(it * 60f)) })
            Box(Modifier.fillMaxWidth().height(10.dp).clip(CircleShape).background(rainbow))
            Slider(
                value = hueOf(current),
                onValueChange = { onPick(fromHue(it)) },
                valueRange = 0f..360f,
                colors = SliderDefaults.colors(activeTrackColor = Color.Transparent, inactiveTrackColor = Color.Transparent),
            )
        }
    }
}

@Composable
internal fun PreviewRing(title: String, pct: Float, big: String, toneIndex: Int, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val tone = evTone(toneIndex)
    val ringColor = tone?.content ?: cs.primary
    val track = cs.outlineVariant
    Column(
        modifier.clip(RoundedCornerShape(14.dp)).background(tone?.container ?: cs.surfaceVariant).padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Text(title, style = MaterialTheme.typography.labelSmall, color = ringColor, textAlign = TextAlign.Center, maxLines = 1)
        Box(Modifier.size(52.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(52.dp)) {
                val sw = 5.dp.toPx()
                val d = size.minDimension - sw
                val tl = Offset(sw / 2f, sw / 2f)
                drawArc(track, 0f, 360f, false, tl, Size(d, d), style = Stroke(sw))
                drawArc(ringColor, -90f, 360f * pct, false, tl, Size(d, d), style = Stroke(sw, cap = StrokeCap.Round))
            }
            Text(big, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
    }
}
