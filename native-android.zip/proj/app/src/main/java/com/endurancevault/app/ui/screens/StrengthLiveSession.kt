package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.i18n.Text
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.endurancevault.app.domain.LiveLaunch
import com.endurancevault.app.domain.LivePlan
import com.endurancevault.app.domain.LiveResult
import com.endurancevault.app.domain.LiveStep
import com.endurancevault.app.domain.StrengthLive
import java.time.Instant
import java.time.ZoneId
import kotlin.math.max
import kotlin.math.min

private const val STAGE_READY = 0
private const val STAGE_RUN = 1
private const val STAGE_DONE = 2

private fun clock(totalSec: Long): String = "${totalSec / 60}:${(totalSec % 60).toString().padStart(2, '0')}"

/**
 * Sesi strength live layar penuh: pemandu animasi, hitungan repetisi otomatis, hitung mundur tahan, istirahat
 * antar set, dan jeda singkat pindah sisi. Selesai (atau diakhiri lebih awal) -> [onSave] dengan lama sesi sebenarnya.
 * Layar tetap menyala selama sesi. Status disimpan agar tidak hilang saat layar diputar.
 */
@Composable
internal fun StrengthLiveSession(launch: LiveLaunch, onSave: (LiveResult) -> Unit, onClose: () -> Unit) {
    val plan = remember(launch) { StrengthLive.build(launch.block) }
    val stage = rememberSaveable { mutableStateOf(STAGE_READY) }
    val idx = rememberSaveable { mutableStateOf(0) }
    val stepMs = rememberSaveable { mutableStateOf(0L) }
    val totalMs = rememberSaveable { mutableStateOf(0L) }
    val restExtra = rememberSaveable { mutableStateOf(0L) }
    val paused = rememberSaveable { mutableStateOf(false) }
    val startedAt = rememberSaveable { mutableStateOf(0L) }
    var confirmExit by remember { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current
    val view = LocalView.current
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }

    fun go(to: Int) {
        stepMs.value = 0L
        restExtra.value = 0L
        if (to >= plan.steps.size) stage.value = STAGE_DONE else idx.value = max(0, to)
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
    }

    fun due(): Boolean {
        val s = plan.steps.getOrNull(idx.value) ?: return false
        val ms = stepMs.value
        return when (s) {
            is LiveStep.Work -> {
                val ex = plan.exercises[s.ex]
                val lead = StrengthLive.leadMs(idx.value)
                val hold = ex.holdSec
                val reps = ex.reps
                when {
                    hold != null -> ms >= lead + hold * 1000L
                    reps != null -> ms >= lead + reps * ex.tempoMs.toLong() + 500L
                    else -> false  // gerakan tanpa target terbaca: selesai manual
                }
            }
            is LiveStep.Rest -> ms >= s.seconds * 1000L + restExtra.value
        }
    }

    LaunchedEffect(stage.value, paused.value) {
        if (stage.value != STAGE_RUN || paused.value) return@LaunchedEffect
        var last = withFrameNanosCompat()
        while (true) {
            val now = withFrameNanosCompat()
            val dt = ((now - last) / 1_000_000L).coerceIn(0L, 250L)
            last = now
            stepMs.value += dt
            totalMs.value += dt
            if (due()) go(idx.value + 1)
        }
    }

    val doneSets = if (stage.value == STAGE_DONE) plan.workCount else plan.steps.take(idx.value).count { it is LiveStep.Work }
    val minutes = max(1, ((totalMs.value + 30_000L) / 60_000L).toInt())
    fun result(): LiveResult {
        val startMs = if (startedAt.value > 0L) startedAt.value else System.currentTimeMillis()
        val date = Instant.ofEpochMilli(startMs).atZone(ZoneId.systemDefault()).toLocalDate().toString()
        return LiveResult(startMs / 1000L, date, minutes, launch.key)
    }

    Dialog(
        onDismissRequest = { if (stage.value == STAGE_RUN) confirmExit = true else onClose() },
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false),
    ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp)) {
                TopBar(
                    title = launch.block.title, totalSec = (totalMs.value / 1000L),
                    showClock = stage.value == STAGE_RUN,
                    onClose = { if (stage.value == STAGE_RUN) confirmExit = true else onClose() },
                )
                if (stage.value == STAGE_RUN) {
                    LinearProgressIndicator(
                        progress = { if (plan.workCount == 0) 0f else doneSets.toFloat() / plan.workCount },
                        modifier = Modifier.fillMaxWidth().height(6.dp),
                        trackColor = MaterialTheme.colorScheme.surfaceVariant,
                    )
                    Spacer(Modifier.height(10.dp))
                }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    when (stage.value) {
                        STAGE_READY -> ReadyPane(launch, plan) {
                            startedAt.value = System.currentTimeMillis()
                            idx.value = 0; stepMs.value = 0L; totalMs.value = 0L
                            stage.value = STAGE_RUN
                        }
                        STAGE_RUN -> {
                            val step = plan.steps.getOrNull(idx.value)
                            val back = {
                                var i = idx.value - 1
                                while (i > 0 && plan.steps[i] !is LiveStep.Work) i--
                                go(max(i, 0))
                            }
                            when (step) {
                                is LiveStep.Work -> WorkPane(
                                    plan, idx.value, step, stepMs, paused.value,
                                    onBack = back, onToggle = { paused.value = !paused.value }, onNext = { go(idx.value + 1) },
                                )
                                is LiveStep.Rest -> RestPane(
                                    plan, idx.value, step, stepMs, restExtra, paused.value,
                                    onBack = back, onToggle = { paused.value = !paused.value }, onNext = { go(idx.value + 1) },
                                )
                                null -> {}
                            }
                        }
                        else -> DonePane(plan, totalMs.value / 1000L, onSave = { onSave(result()) }, onDiscard = onClose)
                    }
                }
            }
        }
    }

    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text("Akhiri sesi?") },
            text = {
                Text(
                    if (doneSets > 0) "Kamu sudah menyelesaikan $doneSets dari ${plan.workCount} set. Simpan sebagai sesi strength?"
                    else "Belum ada set yang selesai.",
                )
            },
            confirmButton = {
                Row {
                    TextButton(onClick = { confirmExit = false; onClose() }) { Text("Buang") }
                    if (doneSets > 0) TextButton(onClick = { confirmExit = false; onSave(result()) }) { Text("Simpan") }
                }
            },
            dismissButton = { TextButton(onClick = { confirmExit = false }) { Text("Lanjutkan") } },
        )
    }
}

/** Menunggu frame berikutnya dan memberi stempel waktunya (nanodetik). */
private suspend fun withFrameNanosCompat(): Long = androidx.compose.runtime.withFrameNanos { it }

@Composable
private fun TopBar(title: String, totalSec: Long, showClock: Boolean, onClose: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onClose) { Icon(Icons.Filled.Close, contentDescription = "Tutup") }
        Text(
            title, Modifier.weight(1f), style = MaterialTheme.typography.titleSmall,
            maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
        )
        if (showClock) Text(clock(totalSec), style = monoStyle(14f, 0f), color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ===================== siap =====================

@Composable
private fun ReadyPane(launch: LiveLaunch, plan: LivePlan, onStart: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("SESI STRENGTH LIVE", style = monoStyle(10f, 0.4f), color = cs.onSurfaceVariant)
            Text(launch.block.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
            Text(
                "${plan.exercises.size} gerakan · ${plan.workCount} set · sekitar ${launch.block.mins} mnt",
                style = MaterialTheme.typography.bodyMedium, color = cs.primary,
            )
            if (launch.block.note.isNotBlank()) {
                Text(launch.block.note, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
            Spacer(Modifier.height(4.dp))
            plan.exercises.forEachIndexed { i, ex ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = cs.surfaceVariant),
                    border = BorderStroke(0.8.dp, cs.outlineVariant),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                ) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${i + 1}", Modifier.size(22.dp), style = monoStyle(11f, 0f), color = cs.primary)
                        Text(ex.raw, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            Text(
                "Istirahat antar set: ${plan.restSec} dtk. Hitungan repetisi dan waktu tahan berjalan otomatis; " +
                    "ketuk Selesai set bila lebih cepat.",
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
            )
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = onStart, Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
            Icon(Icons.Filled.PlayArrow, contentDescription = null)
            Spacer(Modifier.size(8.dp))
            Text("Mulai sesi")
        }
    }
}

// ===================== set kerja =====================

@Composable
private fun WorkPane(
    plan: LivePlan, idx: Int, step: LiveStep.Work, stepMs: State<Long>, paused: Boolean,
    onBack: () -> Unit, onToggle: () -> Unit, onNext: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val ex = plan.exercises[step.ex]
    val lead = StrengthLive.leadMs(idx)
    val tempo = if (ex.timed) 4000 else ex.tempoMs
    val big by remember(idx) {
        derivedStateOf {
            val t = stepMs.value - lead
            val hold = ex.holdSec
            val reps = ex.reps
            when {
                t < 0L -> (((-t) + 999L) / 1000L).toString()  // hitung mundur persiapan: 3, 2, 1
                hold != null -> {
                    val left = max(0L, hold * 1000L - t)
                    if (ex.unit == "m") "${(left + 999L) / 1000L} m" else clock((left + 999L) / 1000L)
                }
                reps != null -> "${min(reps.toLong(), t / ex.tempoMs)} / $reps"
                else -> "—"
            }
        }
    }
    val getReady by remember(idx) { derivedStateOf { stepMs.value < lead } }
    val cue by remember(idx) { derivedStateOf { ex.move.cues[((stepMs.value / 6000L) % ex.move.cues.size).toInt()] } }
    val nextText = nextWorkText(plan, idx)

    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        GuideCard(Modifier.fillMaxWidth().height(250.dp)) {
            StrengthGuide(ex.move, { stepMs.value }, tempo, lead, Modifier.fillMaxSize().padding(8.dp))
        }
        Spacer(Modifier.height(10.dp))
        Text(ex.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Set ${step.set} dari ${step.setCount}", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
            ex.sideLabel(step.side)?.let {
                Text(it, style = MaterialTheme.typography.labelLarge, color = cs.primary, fontWeight = FontWeight.SemiBold)
            }
        }
        Text(
            if (getReady) "Bersiap" else if (paused) "Dijeda" else "",
            style = MaterialTheme.typography.labelMedium, color = cs.tertiary,
        )
        Text(big, fontSize = 56.sp, fontWeight = FontWeight.Bold, color = if (paused) cs.onSurfaceVariant else cs.primary)
        if (ex.targetText.isNotEmpty() && ex.reps != null && ex.repsLabel != ex.reps.toString()) {
            Text("Target ${ex.targetText} repetisi", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
        Spacer(Modifier.height(6.dp))
        Text(cue, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 8.dp))
        Spacer(Modifier.weight(1f))
        nextText?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis) }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack, Modifier.size(52.dp)) { Icon(Icons.Filled.SkipPrevious, contentDescription = "Sebelumnya") }
            FilledIconButton(onClick = onToggle, Modifier.size(68.dp)) {
                Icon(if (paused) Icons.Filled.PlayArrow else Icons.Filled.Pause, contentDescription = if (paused) "Lanjut" else "Jeda", Modifier.size(34.dp))
            }
            Button(onClick = onNext, Modifier.height(52.dp), shape = RoundedCornerShape(16.dp)) {
                Icon(Icons.Filled.Check, contentDescription = null, Modifier.size(18.dp))
                Spacer(Modifier.size(6.dp))
                Text("Selesai set")
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

// ===================== istirahat =====================

@Composable
private fun RestPane(
    plan: LivePlan, idx: Int, step: LiveStep.Rest, stepMs: State<Long>, restExtra: MutableState<Long>, paused: Boolean,
    onBack: () -> Unit, onToggle: () -> Unit, onNext: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val ex = plan.exercises[step.nextEx.coerceIn(0, plan.exercises.lastIndex)]
    val nextWork = plan.steps.drop(idx + 1).firstOrNull { it is LiveStep.Work } as? LiveStep.Work
    val left by remember(idx) {
        derivedStateOf { max(0L, step.seconds * 1000L + restExtra.value - stepMs.value) }
    }
    val tempo = if (ex.timed) 4000 else ex.tempoMs

    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(if (step.switchSide) "GANTI SISI" else "ISTIRAHAT", style = monoStyle(11f, 0.6f), color = cs.onSurfaceVariant)
        Text(
            clock((left + 999L) / 1000L), fontSize = 72.sp, fontWeight = FontWeight.Bold,
            color = if (paused) cs.onSurfaceVariant else cs.primary,
        )
        if (paused) Text("Dijeda", style = MaterialTheme.typography.labelMedium, color = cs.tertiary)
        Spacer(Modifier.height(8.dp))
        Text("Berikutnya", style = monoStyle(10f, 0.4f), color = cs.onSurfaceVariant)
        GuideCard(Modifier.fillMaxWidth().height(190.dp)) {
            StrengthGuide(ex.move, { stepMs.value }, tempo, 0L, Modifier.fillMaxSize().padding(6.dp))
        }
        Spacer(Modifier.height(8.dp))
        Text(ex.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        nextWork?.let { w ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Set ${w.set} dari ${w.setCount}", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                ex.sideLabel(w.side)?.let { Text(it, style = MaterialTheme.typography.labelLarge, color = cs.primary, fontWeight = FontWeight.SemiBold) }
            }
        }
        Text(
            ex.move.cues.first(), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
            textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
        )
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack, Modifier.size(52.dp)) { Icon(Icons.Filled.SkipPrevious, contentDescription = "Sebelumnya") }
            FilledIconButton(onClick = onToggle, Modifier.size(68.dp)) {
                Icon(if (paused) Icons.Filled.PlayArrow else Icons.Filled.Pause, contentDescription = if (paused) "Lanjut" else "Jeda", Modifier.size(34.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                if (!step.switchSide) OutlinedButton(onClick = { restExtra.value += 15_000L }) { Text("+15 dtk") }
                Button(onClick = onNext, shape = RoundedCornerShape(16.dp)) { Text("Lewati") }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

// ===================== selesai =====================

@Composable
private fun DonePane(plan: LivePlan, totalSec: Long, onSave: () -> Unit, onDiscard: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(72.dp), contentAlignment = Alignment.Center) {
            Surface(shape = androidx.compose.foundation.shape.CircleShape, color = cs.primary.copy(alpha = 0.14f), modifier = Modifier.fillMaxSize()) {}
            Icon(Icons.Filled.Check, contentDescription = null, Modifier.size(36.dp), tint = cs.primary)
        }
        Spacer(Modifier.height(14.dp))
        Text("Sesi selesai", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
            DoneStat("Waktu", clock(totalSec))
            DoneStat("Set", "${plan.workCount}")
            DoneStat("Gerakan", "${plan.exercises.size}")
        }
        Spacer(Modifier.height(24.dp))
        Button(onClick = onSave, Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) { Text("Simpan ke riwayat") }
        TextButton(onClick = onDiscard) { Text("Tutup tanpa menyimpan") }
    }
}

@Composable
private fun DoneStat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(label, style = monoStyle(9f, 0.3f), color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ===================== bagian bersama =====================

@Composable
private fun GuideCard(modifier: Modifier, content: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Card(
        modifier = modifier, shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = cs.surfaceVariant.copy(alpha = 0.6f)),
        border = BorderStroke(0.8.dp, cs.outlineVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
    ) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { content() } }
}

/** "Berikutnya: gerakan" untuk set kerja setelah set ini; null bila ini set terakhir. */
private fun nextWorkText(plan: LivePlan, idx: Int): String? {
    val next = plan.steps.drop(idx + 1).firstOrNull { it is LiveStep.Work } as? LiveStep.Work ?: return null
    return "Berikutnya: ${plan.exercises[next.ex].name}"
}
