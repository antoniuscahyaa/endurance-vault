package com.endurancevault.app.widget

import android.content.Context
import com.endurancevault.app.domain.Wx
import com.endurancevault.app.domain.WxKind
import com.endurancevault.app.domain.WxSnapshot
import org.json.JSONArray
import org.json.JSONObject

/**
 * Sesi hari ini untuk widget. state: todo | rest | done | none. source: plan (jadwal training plan) | rec (saran/rekomendasi).
 * Diisi dari layar Hari ini, yang sudah menghitung jadwal dan saran sesi.
 */
data class WidgetSession(
    val dateIso: String, val source: String, val state: String, val title: String,
    val km: Double, val minutes: Int?, val hrLimit: Int?, val ranToday: Boolean,
    /** Id aktivitas yang sudah dilakukan hari ini (hanya untuk state done), supaya ketukan widget membuka detailnya. */
    val activityId: Long? = null,
)

/** Hari rencana berikutnya, supaya widget tetap benar setelah lewat tengah malam walau aplikasi belum dibuka. */
data class WidgetUpcoming(val dateIso: String, val rest: Boolean, val title: String, val km: Double, val hrLimit: Int?)

/** Cuaca ringkas. alert: storm | rain | heat | "" (kosong = tidak ada peringatan untuk sesi outdoor). */
data class WidgetWeather(val temp: Double, val code: Int, val night: Boolean, val alert: String, val fetchedAtMs: Long)

/** Penyimpanan data widget (SharedPreferences "widget_glance"). */
object GlanceWidgetStore {
    private const val PREFS = "widget_glance"
    private const val K_SESSION = "session"
    private const val K_UPCOMING = "upcoming"
    private const val K_WEATHER = "weather"
    private const val HEAT_C = 34.0
    private const val RAIN_POP = 60

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Simpan sesi hari ini + rencana 14 hari ke depan; widget digambar ulang hanya bila isinya berubah. */
    fun publishSession(ctx: Context, s: WidgetSession, upcoming: List<WidgetUpcoming>) {
        val sj = JSONObject()
            .put("d", s.dateIso).put("src", s.source).put("st", s.state).put("t", s.title)
            .put("km", if (s.km.isFinite()) s.km else 0.0).put("ran", s.ranToday)
        s.activityId?.let { sj.put("aid", it) }
        s.minutes?.let { sj.put("min", it) }
        s.hrLimit?.let { sj.put("hr", it) }
        val ua = JSONArray()
        for (u in upcoming) {
            val o = JSONObject().put("d", u.dateIso).put("r", u.rest).put("t", u.title).put("km", if (u.km.isFinite()) u.km else 0.0)
            u.hrLimit?.let { o.put("hr", it) }
            ua.put(o)
        }
        val sStr = sj.toString(); val uStr = ua.toString()
        val p = sp(ctx)
        if (p.getString(K_SESSION, null) == sStr && p.getString(K_UPCOMING, null) == uStr) return
        p.edit().putString(K_SESSION, sStr).putString(K_UPCOMING, uStr).apply()
        GlanceWidgetRenderer.updateAll(ctx)
    }

    fun loadSession(ctx: Context): Pair<WidgetSession, List<WidgetUpcoming>>? {
        val p = sp(ctx)
        val raw = p.getString(K_SESSION, null) ?: return null
        return runCatching {
            val o = JSONObject(raw)
            val s = WidgetSession(
                dateIso = o.getString("d"), source = o.optString("src", "plan"), state = o.optString("st", "none"),
                title = o.optString("t", ""), km = o.optDouble("km", 0.0),
                minutes = if (o.has("min")) o.getInt("min") else null,
                hrLimit = if (o.has("hr")) o.getInt("hr") else null,
                ranToday = o.optBoolean("ran", false),
                activityId = if (o.has("aid")) o.getLong("aid") else null,
            )
            val up = ArrayList<WidgetUpcoming>()
            p.getString(K_UPCOMING, null)?.let { u ->
                val a = JSONArray(u)
                for (i in 0 until a.length()) {
                    val x = a.getJSONObject(i)
                    up += WidgetUpcoming(x.getString("d"), x.optBoolean("r", false), x.optString("t", ""), x.optDouble("km", 0.0), if (x.has("hr")) x.getInt("hr") else null)
                }
            }
            s to up.toList()
        }.getOrNull()
    }

    /** Simpan cuaca saat ini + peringatan untuk 3 jam ke depan (hujan, badai, panas). */
    fun saveWeather(ctx: Context, w: WxSnapshot) {
        val next = w.hours.take(4)
        val codes = listOf(w.code) + next.map { it.code }
        val pop = next.maxOfOrNull { it.pop ?: 0 } ?: 0
        val maxT = (listOf(w.temp) + next.map { it.temp }).maxOrNull() ?: w.temp
        val alert = when {
            codes.any { Wx.kind(it) == WxKind.STORM } -> "storm"
            codes.any { Wx.kind(it) == WxKind.RAIN } || pop >= RAIN_POP -> "rain"
            maxT >= HEAT_C -> "heat"
            else -> ""
        }
        val night = Wx.isNight(w.currentTime, w.sunrise, w.sunset)
        val o = JSONObject().put("t", w.temp).put("c", w.code).put("n", night).put("a", alert).put("f", w.fetchedAtMs)
        sp(ctx).edit().putString(K_WEATHER, o.toString()).apply()
    }

    fun loadWeather(ctx: Context): WidgetWeather? {
        val raw = sp(ctx).getString(K_WEATHER, null) ?: return null
        return runCatching {
            val o = JSONObject(raw)
            WidgetWeather(o.getDouble("t"), o.optInt("c", -1), o.optBoolean("n", false), o.optString("a", ""), o.optLong("f", 0L))
        }.getOrNull()
    }
}
