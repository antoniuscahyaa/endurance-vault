package com.endurancevault.app

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Log kecil di berkas (filesDir/applog.txt) untuk melacak masalah di HP tanpa komputer. Ditulis sinkron per baris
 * supaya tetap ada walau aplikasi crash sesudahnya. Dibatasi ±64 KB (sisa terbaru dipertahankan). Dibaca lewat ikon "i" di Plan settings.
 */
object AppLog {
    private var file: File? = null
    private val fmt = SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.US)

    fun init(ctx: Context) { file = File(ctx.filesDir, "applog.txt") }

    @Synchronized
    fun add(tag: String, msg: String) {
        val f = file ?: return
        runCatching {
            if (f.length() > 48_000) f.writeText(f.readText().takeLast(20_000))
            f.appendText("${fmt.format(Date())} [$tag] $msg\n")
        }
    }

    private var lastErr: String? = null

    /** Error yang sama beruntun hanya dicatat sekali, supaya hitung ulang rencana yang berulang tidak membanjiri log. */
    fun error(tag: String, t: Throwable) {
        val key = "$tag|${t::class.java.name}|${t.message}"
        synchronized(this) { if (key == lastErr) return; lastErr = key }
        add(tag, "ERROR " + Log.getStackTraceString(t).trim().take(2500))
    }

    /** Beberapa frame pemanggil teratas, untuk tahu siapa yang memanggil fungsi tertentu. */
    fun caller(skip: Int = 2, n: Int = 4): String =
        Throwable().stackTrace.drop(skip).take(n).joinToString(" < ") { "${it.className.substringAfterLast('.')}.${it.methodName}" }

    /** Hanya ekor berkas (maks [maxChars] karakter), dibaca dari belakang; aman dipanggil dari thread latar. */
    @Synchronized
    fun readTail(maxChars: Int = 20_000): String = runCatching {
        val f = file?.takeIf { it.exists() } ?: return@runCatching ""
        java.io.RandomAccessFile(f, "r").use { r ->
            val n = minOf(r.length(), maxChars.toLong() * 2).toInt()
            val buf = ByteArray(n)
            r.seek(r.length() - n); r.readFully(buf)
            String(buf, Charsets.UTF_8).takeLast(maxChars).substringAfter('\n', "")
        }
    }.getOrDefault("")

    @Synchronized
    fun clear() { runCatching { file?.delete() } }
}
