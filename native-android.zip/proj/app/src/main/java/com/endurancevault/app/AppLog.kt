package com.endurancevault.app

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Log kecil di berkas (filesDir/applog.txt) untuk melacak masalah di HP tanpa komputer. Ditulis sinkron per baris
 * supaya tetap ada walau aplikasi crash sesudahnya. Dibatasi ±64 KB (sisa terbaru dipertahankan). Dibaca lewat ikon "i" di Plan settings.
 */
object AppLog {
    private var file: File? = null
    private val fmt = SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.US)

    fun init(ctx: Context) { file = File(ctx.filesDir, "applog.txt") }

    @Synchronized
    fun add(tag: String, msg: String) {
        val f = file ?: return
        runCatching {
            if (f.length() > 64_000) f.writeText(f.readText().takeLast(32_000))
            f.appendText("${fmt.format(Date())} [$tag] $msg\n")
        }
    }

    fun error(tag: String, t: Throwable) = add(tag, "ERROR " + Log.getStackTraceString(t).trim().take(4000))

    /** Beberapa frame pemanggil teratas, untuk tahu siapa yang memanggil fungsi tertentu. */
    fun caller(skip: Int = 2, n: Int = 4): String =
        Throwable().stackTrace.drop(skip).take(n).joinToString(" < ") { "${it.className.substringAfterLast('.')}.${it.methodName}" }

    @Synchronized
    fun read(): String = runCatching { file?.takeIf { it.exists() }?.readText().orEmpty() }.getOrDefault("")

    @Synchronized
    fun clear() { runCatching { file?.delete() } }
}
