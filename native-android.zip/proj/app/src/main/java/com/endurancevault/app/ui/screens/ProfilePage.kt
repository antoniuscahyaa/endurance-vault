package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.theme.EvButton

import com.endurancevault.app.ui.i18n.Text
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.data.GearEntity
import com.endurancevault.app.domain.Js
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.domain.Phases
import com.endurancevault.app.domain.TrainingRefs
import com.endurancevault.app.domain.ProgressAnalytics
import com.endurancevault.app.domain.ZoneCuts
import com.endurancevault.app.domain.Zones
import com.endurancevault.app.domain.raceKmOf
import com.endurancevault.app.domain.rcOf
import com.endurancevault.app.ui.UiState
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale
import java.util.UUID

private val ID = com.endurancevault.app.ui.i18n.Lang.locale
private val GearWarn = Color(0xFFE0A33B)

/**
 * Halaman Profil (dibuka dari kartu profil di Pengaturan): identitas, total lari, detak jantung (zona HR dipindah dari Pengaturan),
 * target lomba (expand = grafik pekan rencana), rekor pribadi (salinan ringkas dari Fitness), dan gear aktif (dipindah dari Kondisi).
 */
@Composable
internal fun ProfilePage(
    state: UiState,
    profileName: String, profilePhotoUri: String?, onEditName: () -> Unit, onPickPhoto: () -> Unit,
    onSave: (PlanSettings) -> Unit, onSyncHrZones: (PlanSettings) -> Unit, watchStatus: String, watchSyncing: Boolean,
    onSaveGear: (GearEntity) -> Unit, onDeleteGear: (String) -> Unit,
    onOpenFitness: () -> Unit,
    onOpenPlan: () -> Unit,
) {
    val runs = remember(state.activities) { state.activities.filter { it.type == "run" } }
    val since = remember(runs) {
        runs.minOfOrNull { it.dateIso }?.let { d -> runCatching { LocalDate.parse(d.take(10)).format(DateTimeFormatter.ofPattern("MMM yyyy", ID)) }.getOrNull() }
    }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        IdentityHeader(profileName, profilePhotoUri, since, onEditName, onPickPhoto)
        TotalsCard(runs)
        HeartRateCard(state, onSave, onSyncHrZones, watchStatus, watchSyncing)
        RefsCard(state)
        TargetCard(state, onOpenPlan)
        PrCard(state, onOpenFitness)
        GearCard(state.gear, state.activities, onSaveGear, onDeleteGear)
    }
}

// ---------- bahan bersama ----------

@Composable
private fun PCard(
    title: String,
    onCardClick: (() -> Unit)? = null,
    onHeaderClick: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).border(BorderStroke(0.8.dp, cs.outlineVariant), shape)
            .then(if (onCardClick != null) Modifier.clickable(onClick = onCardClick) else Modifier)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(
            Modifier.fillMaxWidth().then(if (onHeaderClick != null) Modifier.clickable(onClick = onHeaderClick) else Modifier),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            trailing?.invoke()
        }
        content()
    }
}

@Composable
private fun Chevron(open: Boolean? = null) {
    val icon = when (open) { null -> Icons.Filled.KeyboardArrowRight; true -> Icons.Filled.KeyboardArrowUp; false -> Icons.Filled.KeyboardArrowDown }
    Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
}

@Composable
private fun StatBox(label: String, value: String, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    Column(modifier.clip(RoundedCornerShape(10.dp)).background(cs.surfaceVariant.copy(alpha = .6f)).padding(horizontal = 10.dp, vertical = 8.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun StatGrid(items: List<Pair<String, String>>) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                pair.forEach { (l, v) -> StatBox(l, v, Modifier.weight(1f)) }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

// ---------- identitas ----------

@Composable
private fun IdentityHeader(name: String, photoUri: String?, since: String?, onEditName: () -> Unit, onPickPhoto: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val avatar = rememberProfileAvatar(photoUri)
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(
            Modifier.size(64.dp).clip(CircleShape).background(cs.surfaceVariant).border(1.dp, cs.outlineVariant, CircleShape).clickable(onClick = onPickPhoto),
            contentAlignment = Alignment.Center,
        ) {
            if (avatar != null) Image(bitmap = avatar, contentDescription = com.endurancevault.app.ui.i18n.Lang.tr("Ganti foto profil"), contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            else Icon(Icons.Filled.Person, contentDescription = com.endurancevault.app.ui.i18n.Lang.tr("Pilih foto profil"), tint = cs.onSurfaceVariant, modifier = Modifier.size(32.dp))
        }
        Column(Modifier.weight(1f).clickable(onClick = onEditName), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                name.ifBlank { "Tambahkan nama profil" }, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis, color = if (name.isBlank()) cs.onSurfaceVariant else cs.onSurface,
            )
            if (since != null) Text("Mencatat sejak $since", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
        Icon(Icons.Filled.Edit, contentDescription = com.endurancevault.app.ui.i18n.Lang.tr("Edit nama"), modifier = Modifier.size(18.dp).clickable(onClick = onEditName), tint = cs.onSurfaceVariant)
    }
}

// ---------- total keseluruhan ----------

@Composable
private fun TotalsCard(allRuns: List<ActivityEntity>) {
    var thisYear by rememberSaveable { mutableStateOf(false) }
    val year = remember { LocalDate.now().year.toString() }
    val runs = remember(allRuns, thisYear) { if (thisYear) allRuns.filter { it.dateIso.take(4) == year } else allRuns }
    PCard(
        if (thisYear) "Total tahun ini" else "Total keseluruhan",
        trailing = {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = !thisYear, onClick = { thisYear = false }, label = { Text("Semua") })
                FilterChip(selected = thisYear, onClick = { thisYear = true }, label = { Text("Tahun ini") })
            }
        },
    ) {
        if (runs.isEmpty()) {
            Text(if (thisYear) "Belum ada lari tahun ini." else "Belum ada lari tercatat.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            val km = runs.sumOf { it.km }
            val hours = runs.sumOf { it.durationSec.toLong() } / 3600.0
            val longest = runs.maxOfOrNull { it.km } ?: 0.0
            StatGrid(listOf(
                "Lari" to String.format(ID, "%,d", runs.size),
                "Jarak" to String.format(ID, "%,.0f km", km),
                "Waktu" to String.format(ID, "%,.0f j", hours),
                "Terpanjang" to String.format(ID, "%.1f km", longest),
            ))
        }
    }
}

// ---------- detak jantung (dipindah dari Pengaturan > Zona HR) ----------

private val ZoneFills = listOf(Color(0xFF9FE1CB), Color(0xFFC0DD97), Color(0xFFFAC775), Color(0xFFF0997B), Color(0xFFF09595))

@Composable
private fun ZoneBar(zc: ZoneCuts) {
    val bands = remember(zc) { runCatching { zc.bands() }.getOrDefault(emptyList()) }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        ZoneFills.forEachIndexed { i, c ->
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(6.dp)).background(c).padding(vertical = 5.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("Z${i + 1}", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold, color = Color(0xFF2C2C2A))
                bands.getOrNull(i)?.let { Text(it, fontSize = 10.sp, color = Color(0xFF2C2C2A), maxLines = 1) }
            }
        }
    }
}

@Composable
private fun HeartRateCard(
    state: UiState,
    onSave: (PlanSettings) -> Unit, onSyncHrZones: (PlanSettings) -> Unit, watchStatus: String, watchSyncing: Boolean,
) {
    var open by rememberSaveable { mutableStateOf(false) }
    val s = state.settings
    val (restDefault, restKnown) = restHrFrom(state.daily)
    val zc = Zones.cuts(s, restDefault)
    PCard("Detak jantung", onHeaderClick = { open = !open }, trailing = { Chevron(open) }) {
        StatGrid(listOf(
            "HR maks" to "${zc.maxHr} bpm",
            "HR istirahat" to "${zc.rest ?: restDefault} bpm",
            "LTHR" to (zc.lthr?.let { "$it bpm" } ?: "Otomatis"),
            "Metode zona" to if (zc.mode == "hrr") "HRR" else "LTHR",
        ))
        ZoneBar(zc)
        if (!open) {
            Text("Ketuk untuk ubah metode dan batas zona", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            HrZoneSettings(
                settings = s, restDefault = restDefault, restKnown = restKnown,
                onSave = onSave, onSendToWatch = onSyncHrZones,
                watchStatus = watchStatus, sending = watchSyncing,
            )
        }
    }
}

// ---------- acuan latihan (otomatis, tanpa isian) ----------

@Composable
private fun RefPill(label: String, value: String, unit: String, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    Column(
        modifier.clip(RoundedCornerShape(12.dp)).background(cs.surfaceVariant.copy(alpha = .6f)).padding(horizontal = 4.dp, vertical = 9.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(value, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
        Text(unit, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
    }
}

@Composable
private fun RefsCard(state: UiState) {
    val s = state.settings
    val (restDefault, _) = restHrFrom(state.daily)
    val refs = remember(s, state.activities, state.daily, restDefault) {
        runCatching { TrainingRefs.compute(s, state.activities, state.daily, restDefault) }.getOrNull()
    } ?: return
    val cs = MaterialTheme.colorScheme
    PCard("Acuan latihan", trailing = { Text("Otomatis", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant) }) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            RefPill("Batas HR easy", "${refs.easyHr}", "bpm", Modifier.weight(1f))
            RefPill("HR threshold", refs.thr, "bpm", Modifier.weight(1f))
            RefPill("Pace easy", refs.paceRange ?: s.pace.ifBlank { "–" }, "/km", Modifier.weight(1f))
        }
        Text(
            when (refs.source) {
                TrainingRefs.Source.RAI -> "HR dari zona aktif. Pace dari zona Easy RAI."
                TrainingRefs.Source.EASY_RUNS -> "HR dari zona aktif. Pace dari rata-rata lari easy terakhir ±10 dtk."
                TrainingRefs.Source.NONE -> "HR dari zona aktif. Belum ada data pace, memakai nilai tersimpan."
            },
            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
        )
    }
}

// ---------- target (kartu hitung mundur; expand = grafik pekan) ----------

@Composable
private fun TargetCard(state: UiState, onOpenPlan: () -> Unit) {
    val plan = state.plan as? PlanOutcome.Ok ?: return
    if (plan.noRace || plan.none) return
    val s = state.settings
    val cs = MaterialTheme.colorScheme
    var open by rememberSaveable { mutableStateOf(false) }
    val today = remember { LocalDate.now() }
    val days = ChronoUnit.DAYS.between(today, plan.race).coerceAtLeast(0)
    val weeks = plan.weeks
    val curIdx = remember(weeks) {
        weeks.indexOfFirst { !today.isBefore(it.start) && !today.isAfter(it.end) }.takeIf { it >= 0 }
            ?: weeks.indexOfFirst { !it.end.isBefore(today) }.takeIf { it >= 0 } ?: (weeks.size - 1).coerceAtLeast(0)
    }
    val cur = weeks.getOrNull(curIdx)
    val goalMin = Js.parseDur(s.goalT)
    val km = raceKmOf(s)
    val goalTxt = if (goalMin > 0) Js.durStr(goalMin) else "–"
    val paceTxt = if (goalMin > 0 && km > 0) Js.paceStr(goalMin / km) + "/km" else "–"
    val phase = when {
        cur == null -> ""
        cur.race -> "Lomba"
        cur.cut || cur.rec -> "Recovery"
        else -> when (cur.phase) {
            Phases.BASE -> "Base"; Phases.BUILD -> "Build"; Phases.PEAK -> "Peak"; Phases.TAPER -> "Taper"
            else -> cur.phase.replaceFirstChar { it.uppercase() }
        }
    }
    val dateTxt = plan.race.format(DateTimeFormatter.ofPattern("d MMM yyyy", ID))
    if (today.isAfter(plan.race)) {
        PCard("Target") {
            Text("Lomba selesai", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text("${rcOf(s).nm} · $dateTxt", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            Text("Atur target baru di Rencana", style = MaterialTheme.typography.bodySmall, color = cs.primary, modifier = Modifier.clickable(onClick = onOpenPlan))
        }
        return
    }
    PCard("Target", onCardClick = { open = !open }, trailing = { Chevron(open) }) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(horizontal = 6.dp)) {
                if (days == 0L) {
                    Text("Hari H", fontSize = 24.sp, fontWeight = FontWeight.Medium, lineHeight = 36.sp)
                    Text("lomba hari ini", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                } else {
                    Text("$days", fontSize = 34.sp, fontWeight = FontWeight.Medium, lineHeight = 36.sp)
                    Text("hari lagi", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(rcOf(s).nm, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(dateTxt, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatBox("Target", goalTxt, Modifier.weight(1f))
            StatBox("Pace", paceTxt, Modifier.weight(1f))
        }
        if (cur != null) Text("Fase $phase · pekan ${curIdx + 1} dari ${weeks.size}", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        if (open && weeks.isNotEmpty()) {
            val mx = weeks.maxOf { it.km }.takeIf { it > 0 } ?: 1.0
            Row(Modifier.fillMaxWidth().height(56.dp), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.Bottom) {
                weeks.forEachIndexed { i, w ->
                    val frac = (w.km / mx).toFloat().coerceIn(0.06f, 1f)
                    val bar = Modifier.weight(1f).fillMaxHeight(frac).clip(RoundedCornerShape(2.dp))
                        .background(planBarColor(w, cs).copy(alpha = if (i > curIdx) .4f else 1f))
                    Box(if (i == curIdx) bar.border(1.5.dp, cs.onSurface, RoundedCornerShape(2.dp)) else bar)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                LegendDot(planBarBuild(cs), "Build"); LegendDot(planBarRecovery(cs), "Recovery"); LegendDot(BarTaper, "Taper")
            }
            if (cur != null) Text(
                "Pekan ini ${String.format(ID, "%.0f", cur.km)} dari puncak ${String.format(ID, "%.0f", mx)} km",
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun LegendDot(c: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(Modifier.size(10.dp).clip(RoundedCornerShape(3.dp)).background(c))
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ---------- rekor pribadi (salinan ringkas dari Fitness) ----------

@Composable
private fun PrCard(state: UiState, onOpenFitness: () -> Unit) {
    val prs = remember(state.detailsByActivity) { runCatching { ProgressAnalytics.personalBests(state.detailsByActivity) }.getOrDefault(emptyList()) }
    val defs = listOf("1 km" to "1 km", "5K" to "5K", "10K" to "10K", "Half marathon" to "Half")
    PCard("Rekor pribadi", onHeaderClick = onOpenFitness, trailing = { Chevron() }) {
        StatGrid(defs.map { (full, short) -> short to (prs.firstOrNull { it.label == full }?.let { Js.durStr(it.durationMinutes) } ?: "–") })
        Text(
            "Lihat semua di Fitness", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.clickable(onClick = onOpenFitness),
        )
    }
}

// ---------- gear aktif (dipindah dari Kondisi) ----------

@Composable
private fun GearCard(gear: List<GearEntity>, activities: List<ActivityEntity>, onSaveGear: (GearEntity) -> Unit, onDeleteGear: (String) -> Unit) {
    var manage by rememberSaveable { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme
    val active = gear.filter { !it.retired }
    PCard("Gear aktif", onHeaderClick = { manage = !manage }, trailing = { Chevron(manage) }) {
        if (active.isEmpty()) {
            Text("Belum ada gear aktif. Ketuk untuk menambah.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
        active.forEach { g ->
            val used = g.km0 + activities.filter { it.gearId == g.id }.sumOf { it.km }
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                    Text(g.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        String.format(ID, "%.0f", used) + (if (g.limitKm > 0) " / " + String.format(ID, "%.0f", g.limitKm) else "") + " km",
                        style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                    )
                }
                if (g.limitKm > 0) LinearProgressIndicator(
                    progress = { (used / g.limitKm).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                    color = when { used >= g.limitKm -> cs.error; used >= g.limitKm * .8 -> GearWarn; else -> cs.primary }, trackColor = cs.surfaceVariant,
                )
                if (g.limitKm > 0 && used >= g.limitKm * .8) Text(
                    if (used >= g.limitKm) "Melewati batas, pertimbangkan ganti" else "Mendekati batas (${(used / g.limitKm * 100).toInt()}%)",
                    style = MaterialTheme.typography.labelSmall, color = if (used >= g.limitKm) cs.error else GearWarn,
                )
                if (g.isDefault) Text("Default", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
            }
        }
        if (!manage) Text("Kelola gear", style = MaterialTheme.typography.bodySmall, color = cs.primary, modifier = Modifier.clickable { manage = true })
        else GearManager(gear, activities, onSaveGear, onDeleteGear)
    }
}

/** Form tambah gear dan daftar lengkap (termasuk yang dipensiunkan); dulu bagian dari CompanionDataSection. */
@Composable
private fun GearManager(gear: List<GearEntity>, activities: List<ActivityEntity>, onSaveGear: (GearEntity) -> Unit, onDeleteGear: (String) -> Unit) {
    var gearName by remember { mutableStateOf("") }
    var gearModel by remember { mutableStateOf("") }
    var gearStartKm by remember { mutableStateOf("0") }
    var gearLimitKm by remember { mutableStateOf("800") }
    var gearError by remember { mutableStateOf<String?>(null) }
    val full = Modifier.fillMaxWidth()
    val numeric = KeyboardOptions(keyboardType = KeyboardType.Decimal)
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Kelola sepatu atau perlengkapan. Jarak pemakaian dihitung dari aktivitas yang ditautkan ke gear tersebut.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedTextField(gearName, { gearName = it }, label = { Text("Nama gear") }, singleLine = true, modifier = full)
        OutlinedTextField(gearModel, { gearModel = it }, label = { Text("Model / catatan") }, singleLine = true, modifier = full)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(gearStartKm, { gearStartKm = it }, label = { Text("Km awal") }, keyboardOptions = numeric, singleLine = true, modifier = Modifier.weight(1f))
            OutlinedTextField(gearLimitKm, { gearLimitKm = it }, label = { Text("Batas km (0=tanpa)") }, keyboardOptions = numeric, singleLine = true, modifier = Modifier.weight(1f))
        }
        gearError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        EvButton(onClick = {
            val initial = gearStartKm.replace(',', '.').toDoubleOrNull()
            val limit = gearLimitKm.replace(',', '.').toDoubleOrNull()
            if (gearName.isBlank() || initial == null || limit == null || initial < 0 || limit < 0) gearError = "Isi nama gear dan angka jarak yang valid."
            else {
                gearError = null
                onSaveGear(GearEntity(UUID.randomUUID().toString(), gearName.trim(), gearModel.trim(), initial, limit))
                gearName = ""; gearModel = ""; gearStartKm = "0"; gearLimitKm = "800"
            }
        }, modifier = full) { Text("Tambah gear") }
        gear.forEach { g ->
            val used = g.km0 + activities.filter { it.gearId == g.id }.sumOf { it.km }
            Card(modifier = full) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(g.name, style = MaterialTheme.typography.titleMedium)
                            if (g.model.isNotBlank()) Text(g.model, style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(checked = g.retired, onCheckedChange = { onSaveGear(g.copy(retired = it)) })
                    }
                    Text("${"%.1f".format(used)} km${if (g.limitKm > 0) " / ${"%.0f".format(g.limitKm)} km" else ""}${if (g.isDefault) " · Default" else ""}", style = MaterialTheme.typography.bodyMedium)
                    Text(if (g.retired) "Dipensiunkan" else "Aktif", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.End, modifier = full) {
                        OutlinedButton(onClick = { onDeleteGear(g.id) }) { Text("Hapus") }
                    }
                }
            }
        }
    }
}
