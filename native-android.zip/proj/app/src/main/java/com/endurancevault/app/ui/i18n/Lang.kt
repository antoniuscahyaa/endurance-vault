package com.endurancevault.app.ui.i18n

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import java.util.Locale

/** Bahasa yang tersedia di aplikasi. Teks sumber di kode berbahasa Indonesia; kamus Inggris ada di assets/i18n/en.tsv. */
enum class AppLang(val tag: String, val nativeName: String, val locale: Locale) {
    ID("id", "Bahasa Indonesia", Locale("id", "ID")),
    EN("en", "English", Locale.US),
}

object Lang {
    private const val PREFS = "app_language"
    private const val KEY = "lang"

    @Volatile
    var current: AppLang = AppLang.ID
        private set

    /** Locale untuk format tanggal/angka; mengikuti bahasa pilihan. */
    val locale: Locale get() = current.locale

    /** Baca pilihan tersimpan dan, bila Inggris, muat kamus. Dipanggil paling awal (attachBaseContext). */
    fun load(ctx: Context) {
        val tag = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
        current = AppLang.values().firstOrNull { it.tag == tag } ?: AppLang.ID
        com.endurancevault.app.domain.ActInsights.decimalComma = current == AppLang.ID
        if (current == AppLang.EN) Translator.load(ctx) else Translator.loadId(ctx)
    }

    /** Simpan pilihan lalu buat ulang activity supaya semua layar (termasuk state yang di-remember) memakai bahasa baru. */
    fun set(activity: Activity, lang: AppLang) {
        if (lang == current) return
        activity.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, lang.tag).commit()
        // Widget layar utama ikut berganti bahasa tanpa menunggu pembaruan berkala.
        runCatching {
            com.endurancevault.app.widget.GlanceWidgetRenderer.updateAll(activity.applicationContext)
            com.endurancevault.app.widget.WidgetUpdater.updateAll(activity.applicationContext)
        }
        activity.recreate()
    }

    /** Bungkus context dasar dengan locale pilihan agar komponen sistem (date picker dll.) ikut berbahasa sama. */
    fun wrap(base: Context): Context {
        load(base)
        Locale.setDefault(locale)
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(locale)
        return base.createConfigurationContext(cfg)
    }

    /** Cari Activity dari context Compose (yang sering terbungkus ContextWrapper). */
    fun activityOf(ctx: Context): Activity? {
        var c: Context? = ctx
        while (c is android.content.ContextWrapper) {
            if (c is Activity) return c
            c = c.baseContext
        }
        return null
    }

    /** Terjemahkan teks sumber (Indonesia) ke bahasa aktif. Mode Indonesia hanya mengganti teks berbahasa Inggris di kode yang terdaftar di id.tsv. */
    fun tr(s: String): String = if (current == AppLang.ID) Translator.id(s) else Translator.en(s)
}
