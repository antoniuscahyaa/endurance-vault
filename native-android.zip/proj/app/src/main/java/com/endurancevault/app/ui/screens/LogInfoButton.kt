package com.endurancevault.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.endurancevault.app.AppLog
import com.endurancevault.app.ui.floating.AlertDialog
import com.endurancevault.app.ui.i18n.Text
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Ikon "i" super kecil; ketuk membuka dialog melayang berisi log aplikasi (bisa disalin atau dihapus).
 * Log dibaca di thread latar (hanya ekornya, maks 300 baris) dan ditampilkan lazy, jadi dialog tidak menahan UI.
 */
@Composable
internal fun LogInfoButton(modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    Icon(
        Icons.Outlined.Info, contentDescription = "Log",
        modifier = modifier.size(14.dp).alpha(.55f).clickable { open = true },
        tint = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    if (open) {
        var reload by remember { mutableStateOf(0) }
        val lines by produceState<List<String>?>(null, reload) {
            value = null
            value = withContext(Dispatchers.IO) {
                AppLog.readTail(20_000).lines().filter { it.isNotBlank() }.takeLast(300).map { it.take(500) }
            }
        }
        val clip = LocalClipboardManager.current
        AlertDialog(
            onDismissRequest = { open = false },
            title = { Text("Log") },
            text = {
                Box(Modifier.height(360.dp)) {
                    val ls = lines
                    when {
                        ls == null -> Text("Memuat…")
                        ls.isEmpty() -> Text("Belum ada log.")
                        else -> LazyColumn {
                            items(ls) { line -> Text(line, fontFamily = FontFamily.Monospace, fontSize = 10.sp, lineHeight = 13.sp) }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { lines?.let { clip.setText(AnnotatedString(it.joinToString("\n"))) } }) { Text("Salin") } },
            dismissButton = {
                Column {
                    TextButton(onClick = { AppLog.clear(); reload++ }) { Text("Hapus") }
                    TextButton(onClick = { open = false }) { Text("Tutup") }
                }
            },
        )
    }
}
