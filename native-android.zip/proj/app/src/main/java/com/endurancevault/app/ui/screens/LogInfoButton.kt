package com.endurancevault.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.endurancevault.app.AppLog
import com.endurancevault.app.ui.floating.AlertDialog
import com.endurancevault.app.ui.i18n.Text

/** Ikon "i" super kecil; ketuk membuka dialog melayang berisi log aplikasi (bisa disalin atau dihapus). */
@Composable
internal fun LogInfoButton(modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    Icon(
        Icons.Outlined.Info, contentDescription = "Log",
        modifier = modifier.size(14.dp).alpha(.55f).clickable { open = true },
        tint = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    if (open) {
        var text by remember { mutableStateOf(AppLog.read()) }
        val clip = LocalClipboardManager.current
        AlertDialog(
            onDismissRequest = { open = false },
            title = { Text("Log") },
            text = {
                Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text.ifBlank { "Belum ada log." },
                        fontFamily = FontFamily.Monospace, fontSize = 10.sp, lineHeight = 13.sp,
                    )
                }
            },
            confirmButton = { TextButton(onClick = { clip.setText(AnnotatedString(text)) }) { Text("Salin") } },
            dismissButton = {
                Column {
                    TextButton(onClick = { AppLog.clear(); text = "" }) { Text("Hapus") }
                    TextButton(onClick = { open = false }) { Text("Tutup") }
                }
            },
        )
    }
}
