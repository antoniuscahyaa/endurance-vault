package com.rencanalari.huaweiwatch

import com.endurancevault.app.watch.DeviceCaps
import com.endurancevault.app.watch.ErrorCodes
import com.endurancevault.app.watch.FileUploader
import com.endurancevault.app.watch.FitnessCourseService
import com.endurancevault.app.watch.LogDirection
import com.endurancevault.app.watch.P2pRoute
import com.endurancevault.app.watch.UploadFile
import com.endurancevault.app.watch.WearEvents
import com.endurancevault.app.watch.WearException
import com.endurancevault.app.watch.WearLink
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import nodomain.freeyourgadget.gadgetbridge.devices.huawei.HuaweiTLV
import nodomain.freeyourgadget.gadgetbridge.service.devices.huawei.HuaweiP2PManager
import nodomain.freeyourgadget.gadgetbridge.service.devices.huawei.p2p.utils.HuaweiP2PSubMsg
import nodomain.freeyourgadget.gadgetbridge.service.devices.huawei.utils.HuaweiConvertTrack
import nodomain.freeyourgadget.gadgetbridge.service.devices.huawei.utils.HuaweiRouteTrack
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest

/*
 * Kirim rute GPX ke jam Huawei lewat P2P, sebagai rute yang bisa diikuti di aplikasi latihan jam. Berkas milik proyek TrainingPlan.
 *
 * Alurnya SAMA dengan Gadgetbridge (`HuaweiSupportProvider.onInstallApp` + `HuaweiGPSTrackConverter.getTrack` + `HuaweiP2PFitnessData`),
 * hanya dijalankan di atas transport plugin ini:
 *   1. Gerbang: ExpandCapability 70 (supportsRouteUpload); 216 (supportsRouteV2) memilih format v2 (dengan elevasi) atau v1 (tanpa).
 *   2. Phone -> jam, modul P2P `hw.unitedevice.fitness`: pesan tipe 5, isinya TLV tag 5 = nama rute. Jam mengakui paket (0xcf).
 *   3. Jam -> phone: pesan tipe 5, isi int32 LE `code` (1 = lanjut) dan int32 LE `maxPoints` (opsional).
 *   4. Phone mengubah titik menjadi biner jam (`HuaweiConvertTrack.convertTrackToBin(track, max(maxPoints, 200))`), membungkusnya
 *      dalam pesan tipe 6, dan mengunggahnya sebagai berkas P2P `byte.bin` (tipe berkas 7).
 *   5. Jam -> phone: pesan tipe 6, isi int32 LE `code` (1 = berhasil).
 * Balasan tipe 5 dan 6 diterima lewat `FitnessCourseService.routeListener` (modul P2P yang sama dengan kursus lari).
 *
 * Jalur kursus lari sudah dilaporkan EKSPERIMENTAL; rute ini juga belum teruji di jam. Tiap langkah dicatat ke log (`Route: ...`) dan
 * kode jam dikembalikan apa adanya ke JS supaya penolakan bisa dibaca penyebabnya.
 */
internal class RoutePoint(val lat: Double, val lon: Double, val alt: Double?)

internal class RouteSpec(val name: String, val points: List<RoutePoint>)

internal class RoutePusher(
  private val link: WearLink,
  private val events: WearEvents,
  private val manager: () -> HuaweiP2PManager?,
) {
  private fun log(message: String) {
    events.log(LogDirection.INFO, null, null, null, message)
  }

  /**
   * Teks JSON `{"name":"...","points":[[lat,lon,ele|null],...]}`. Melempar WearException(INVALID_ARGUMENT) bila bentuknya salah:
   * nama kosong atau lebih dari 60 byte UTF-8, kurang dari 2 atau lebih dari 5000 titik, koordinat di luar jangkauan.
   */
  fun parse(json: String): RouteSpec {
    fun bad(what: String): Nothing = throw WearException(ErrorCodes.INVALID_ARGUMENT, what)
    val root = try {
      JSONObject(json)
    } catch (e: JSONException) {
      bad("Rute tidak terbaca")
    }
    val name = root.optString("name", "").trim()
    if (name.isEmpty()) bad("Rute butuh nama")
    if (name.toByteArray(Charsets.UTF_8).size > MAX_NAME_BYTES) bad("Nama rute terlalu panjang (maksimal $MAX_NAME_BYTES byte)")
    val arr = root.optJSONArray("points") ?: bad("Rute tidak punya titik")
    if (arr.length() < 2) bad("Rute butuh minimal 2 titik")
    if (arr.length() > MAX_POINTS) bad("Rute terlalu panjang (maksimal $MAX_POINTS titik)")
    val points = ArrayList<RoutePoint>(arr.length())
    for (i in 0 until arr.length()) {
      val p = arr.optJSONArray(i) ?: bad("Titik ${i + 1} tidak terbaca")
      if (p.length() < 2) bad("Titik ${i + 1} tidak terbaca")
      val lat = p.optDouble(0, Double.NaN)
      val lon = p.optDouble(1, Double.NaN)
      if (lat.isNaN() || lon.isNaN() || lat < -90.0 || lat > 90.0 || lon < -180.0 || lon > 180.0) bad("Koordinat titik ${i + 1} di luar jangkauan")
      val alt = if (p.length() > 2 && !p.isNull(2)) p.optDouble(2, Double.NaN).takeIf { !it.isNaN() } else null
      points.add(RoutePoint(lat, lon, alt))
    }
    return RouteSpec(name, points)
  }

  /** Port `HuaweiGPSTrackConverter.getTrack`: elevasi terakhir yang ada dipakai ulang, 0 bila rute tanpa elevasi; v1 bila jam tanpa 216. */
  fun buildTrack(spec: RouteSpec, routeV2: Boolean): HuaweiRouteTrack {
    val hasAlt = spec.points.first().alt != null
    var alt = if (hasAlt) spec.points.first().alt!! else 0.0
    val pts = ArrayList<HuaweiRouteTrack.TrackPoint>(spec.points.size)
    for (p in spec.points) {
      if (hasAlt && p.alt != null) alt = p.alt
      pts.add(HuaweiRouteTrack.TrackPoint(p.lat, p.lon, alt))
    }
    val track = HuaweiRouteTrack()
    track.trackName = spec.name
    track.trackId = trackId(spec.name)
    track.isHasAltitude = routeV2
    track.version = if (routeV2) 2 else 1
    track.totalTime = 0
    track.points = pts
    return track
  }

  /** `HuaweiGPSTrackConverter.generateTrackId`: SHA-256 dari nama, Base64 tanpa pembungkus baris (flag NO_WRAP = 2). */
  fun trackId(name: String): String {
    val digest = MessageDigest.getInstance("SHA-256").digest(name.toByteArray(Charsets.UTF_8))
    return android.util.Base64.encodeToString(digest, android.util.Base64.NO_WRAP)
  }

  /** Teks JSON hasil: `{ok, name, points, bytes, maxPoints, routeV2, ...}` atau melempar WearException. */
  suspend fun push(spec: RouteSpec): JSONObject {
    val handle = link.handle() ?: throw WearException(ErrorCodes.NOT_CONNECTED, "Jam belum terhubung")
    val p2p = manager() ?: throw WearException(ErrorCodes.UNSUPPORTED, "Jam ini tidak mencantumkan layanan P2P (34/01)")
    val gate = DeviceCaps.expandCapability(GATE_ROUTE_UPLOAD)
    val v2 = DeviceCaps.expandCapability(GATE_ROUTE_V2)
    log("Route: gates ExpandCapability $GATE_ROUTE_UPLOAD=$gate (unggah rute) $GATE_ROUTE_V2=$v2 (format v2, dengan elevasi)")
    if (!gate) log("Route: peringatan, jam tidak menyatakan ExpandCapability $GATE_ROUTE_UPLOAD; tetap dicoba")

    var service = p2p.getRegisteredService(FitnessCourseService.MODULE) as? FitnessCourseService
    if (service == null) {
      service = FitnessCourseService(p2p, events)
      service.register()
    }
    val registered: FitnessCourseService = service
    val ready = withTimeoutOrNull(PING_WAIT_MS) {
      while (registered.pingCode == null) delay(100)
      true
    }
    log("Route: ping ${FitnessCourseService.PACKAGE} -> ${registered.pingCode?.let { "0x%02x".format(it and 0xFF) } ?: "tidak dijawab dalam $PING_WAIT_MS ms"}")
    if (ready != true) log("Route: aplikasi kebugaran jam tidak menjawab ping; permintaan mungkin ditolak")

    val track = buildTrack(spec, v2)
    val initReply = CompletableDeferred<Pair<Int, Int>>()
    val doneReply = CompletableDeferred<Int>()
    registered.routeListener = { msg ->
      val body = msg.data ?: ByteArray(0)
      val buf = ByteBuffer.wrap(body).order(ByteOrder.LITTLE_ENDIAN)
      when (msg.type) {
        FitnessCourseService.ROUTE_INIT_REPLY -> {
          if (buf.remaining() >= 4) {
            val code = buf.int
            val max = if (buf.remaining() >= 4) buf.int else 0
            log("Route: jam menjawab init, code=$code maxPoints=$max")
            initReply.complete(code to max)
          } else {
            log("Route: jawaban init terlalu pendek (${body.size} byte)")
            initReply.complete(0 to 0)
          }
        }
        FitnessCourseService.ROUTE_UPLOAD_REPLY -> {
          val code = if (buf.remaining() >= 4) buf.int else 0
          log("Route: jam menjawab unggahan, code=$code")
          doneReply.complete(code)
        }
      }
    }
    try {
      val tlv = HuaweiTLV().put(TLV_TRACK_NAME, spec.name)
      val init = HuaweiP2PSubMsg(MSG_INIT, HuaweiP2PSubMsg.getNext(), tlv.serialize())
      val ack = CompletableDeferred<Int>()
      registered.sendCommand(init.bytes) { code, _ -> ack.complete(code) }
      val ackCode = withTimeoutOrNull(ACK_WAIT_MS) { ack.await() }
      log("Route: ${spec.name}: ${spec.points.size} titik, init terkirim, ack ${ackCode?.let { "0x%02x".format(it and 0xFF) } ?: "tidak ada dalam $ACK_WAIT_MS ms"}")
      if (ackCode != null && (ackCode and 0xFF) != 0xCF) {
        throw WearException(ErrorCodes.PROTOCOL, "Jam menolak permintaan rute (ack 0x%02x)".format(ackCode and 0xFF))
      }
      val init2 = withTimeoutOrNull(INIT_WAIT_MS) { initReply.await() }
        ?: throw WearException(ErrorCodes.TIMEOUT, "Jam tidak menjawab permintaan rute dalam ${INIT_WAIT_MS / 1000} dtk")
      if (init2.first != 1) throw WearException(ErrorCodes.PROTOCOL, "Jam menolak rute (kode ${init2.first})")

      val maxPoints = maxOf(init2.second, MIN_MAX_POINTS)
      val bin = HuaweiConvertTrack().convertTrackToBin(track, maxPoints)
      if (bin.isEmpty()) throw WearException(ErrorCodes.INVALID_ARGUMENT, "Rute tidak bisa diubah ke format jam (titik tidak valid atau terlalu sedikit)")
      val file = HuaweiP2PSubMsg(MSG_UPLOAD, HuaweiP2PSubMsg.getNext(), bin).bytes
      log("Route: biner ${bin.size} byte (maks $maxPoints titik, format v${track.version}), pesan ${file.size} byte")

      val outcome = handle.operationLock.withLock {
        val route = P2pRoute(FitnessCourseService.MODULE, FitnessCourseService.PACKAGE, registered.localFingerprint, FitnessCourseService.FINGERPRINT)
        FileUploader(handle.session, events, { bytes, total -> events.uploadProgress(bytes, total) })
          .upload(UploadFile(FILE_NAME, FILE_TYPE_P2P, file, route))
      }
      val done = withTimeoutOrNull(DONE_WAIT_MS) { doneReply.await() }
      log("Route: unggah selesai, status jam=${outcome.resultStatus ?: "tidak ada"}; jawaban ${done?.toString() ?: "tidak ada dalam ${DONE_WAIT_MS / 1000} dtk"}")
      if (done != null && done != 1) throw WearException(ErrorCodes.PROTOCOL, "Jam menolak berkas rute (kode $done)")
      return JSONObject()
        .put("ok", true)
        .put("name", spec.name)
        .put("points", spec.points.size)
        .put("bytes", file.size)
        .put("maxPoints", maxPoints)
        .put("routeV2", v2)
        .put("gate", gate)
        .put("uploadStatus", outcome.resultStatus ?: JSONObject.NULL)
        .put("answered", done != null)
        .put("pingCode", registered.pingCode ?: JSONObject.NULL)
    } finally {
      registered.routeListener = null
    }
  }

  private companion object {
    /** GB HuaweiState.supportsRouteUpload / supportsRouteV2. */
    const val GATE_ROUTE_UPLOAD = 70
    const val GATE_ROUTE_V2 = 216

    const val MSG_INIT = 5
    const val MSG_UPLOAD = 6
    const val TLV_TRACK_NAME = 5

    const val MAX_NAME_BYTES = 60
    const val MAX_POINTS = 5000
    const val MIN_MAX_POINTS = 200

    const val PING_WAIT_MS = 4_000L
    const val ACK_WAIT_MS = 5_000L
    const val INIT_WAIT_MS = 15_000L
    const val DONE_WAIT_MS = 10_000L

    /** GB HuaweiP2PFitnessData.sendCurrentTrack: nama berkas dan tipe berkas 7 (P2P). */
    const val FILE_NAME = "byte.bin"
    const val FILE_TYPE_P2P: Byte = 7
  }
}
