package com.rencanalari.huaweiwatch

import android.content.Context
import com.endurancevault.app.watch.AgpsSource

/**
 * Pengaturan A-GPS (update satelit) ke jam: saklar dan alamat mirror milik pengguna (mis. Cloudflare Worker yang meneruskan
 * file LTO Broadcom). Mirror dicoba dulu, Broadcom langsung jadi cadangan. Disimpan terpisah dari WearSettings agar modul
 * yang disalin tidak berubah. File ini milik proyek TrainingPlan, bukan salinan dari proyek lain.
 */
internal class AgpsConfig(context: Context) {
  private val prefs = context.applicationContext.getSharedPreferences("rl_agps", Context.MODE_PRIVATE)

  /** Bawaan menyala: jam yang meminta A-GPS dilayani selama tautan hidup. */
  var enabled: Boolean
    get() = prefs.getBoolean("enabled", true)
    set(value) = prefs.edit().putBoolean("enabled", value).apply()

  /** Alamat https mirror; kosong = langsung ke Broadcom. */
  var mirrorUrl: String
    get() = prefs.getString("mirror", "") ?: ""
    set(value) = prefs.edit().putString("mirror", value).apply()

  /** Teruskan pilihan ke sumber unduhan (dipanggil saat mulai dan tiap pengaturan berubah). */
  fun apply() {
    AgpsSource.customUrl = mirrorUrl.trim().ifEmpty { null }
  }
}
