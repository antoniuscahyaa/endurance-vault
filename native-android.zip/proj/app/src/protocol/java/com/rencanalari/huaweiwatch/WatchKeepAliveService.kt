package com.rencanalari.huaweiwatch

import com.endurancevault.app.R

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import com.endurancevault.app.watch.LinkState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Layanan latar (foreground service, tipe connectedDevice) yang menjaga tautan ke jam tetap hidup selama aplikasi tidak dibuka:
 * menyambung ulang dengan jeda bertahap bila tautan putus, menguji tautan tiap beberapa menit, dan menyinkronkan data jam ke
 * basis data lokal tiap N menit (Atur › Huawei Watch). Notifikasinya tetap (ongoing, tidak bisa digeser) dan menjadi
 * indikator keadaan koneksi. Layanan berhenti hanya saat pengguna menekan Putuskan atau menonaktifkannya.
 *
 * Tautan dan sinkronnya tetap milik [ProtocolBridge] (satu tautan per proses); layanan ini hanya memanggilnya, jadi aksi dari
 * aplikasi (Hubungkan, Sinkron sekarang) dan aksi layanan tidak berbenturan: sinkron yang tumpang tindih ditolak dengan BUSY
 * dan dianggap bukan kegagalan.
 */
class WatchKeepAliveService : Service() {
  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
  private var loopJob: Job? = null
  private lateinit var bridge: ProtocolBridge
  private val wake = Channel<Unit>(Channel.CONFLATED)
  private var wakeLock: PowerManager.WakeLock? = null

  @Volatile private var note: String? = null
  @Volatile private var forceNow = false
  @Volatile private var nextAttemptAt = 0L
  private var lastShown: String? = null
  private var attempt = 0

  private val bridgeListener: () -> Unit = {
    notifyNewWorkoutIfNeeded()
    postNotification()
    wake.trySend(Unit)
  }

  /** Workout baru yang ditemukan saat autosync diberi notifikasi terpisah; tidak mengubah Activity Log diam-diam. */
  private fun notifyNewWorkoutIfNeeded() {
    try {
      val status = bridge.status()
      val summary = status.optJSONObject("lastSummary") ?: return
      val workouts = summary.optInt("workouts", 0)
      if (workouts <= 0) return
      val from = summary.optLong("from", 0L)
      val to = summary.optLong("to", 0L)
      val key = "$from:$to:$workouts"
      val prefs = getSharedPreferences("watch_workout_alerts", MODE_PRIVATE)
      if (prefs.getString("last_key", null) == key) return
      prefs.edit().putString("last_key", key).apply()
      ensureWorkoutAlertChannel()
      val open = Intent(this, com.endurancevault.app.MainActivity::class.java)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        .putExtra("review_watch_workouts", true)
      val pi = PendingIntent.getActivity(
        this, 7422, open,
        PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0),
      )
      val n = if (Build.VERSION.SDK_INT >= 26)
        Notification.Builder(this, WORKOUT_ALERT_CHANNEL)
      else Notification.Builder(this).setPriority(Notification.PRIORITY_DEFAULT)
      n.setSmallIcon(R.drawable.ic_stat_ev)
        .setColor(ACCENT_ORANGE)
        .setContentTitle("Aktivitas baru dari Huawei Watch")
        .setContentText("$workouts workout ditemukan. Buka Huawei Watch lalu pilih Sinkronkan untuk mengimpor.")
        .setAutoCancel(true)
        .setContentIntent(pi)
        .setCategory(Notification.CATEGORY_STATUS)
      (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
        .notify(WORKOUT_ALERT_ID, n.build())
    } catch (_: Throwable) { }
  }

  private fun ensureWorkoutAlertChannel() {
    if (Build.VERSION.SDK_INT >= 26) {
      val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      if (nm.getNotificationChannel(WORKOUT_ALERT_CHANNEL) == null) {
        nm.createNotificationChannel(NotificationChannel(
          WORKOUT_ALERT_CHANNEL, "Aktivitas baru dari jam", NotificationManager.IMPORTANCE_DEFAULT
        ).apply { description = "Pemberitahuan saat autosync menemukan workout baru dari Huawei Watch." })
      }
    }
  }

  private val btReceiver = object : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
      if (intent?.action == BluetoothAdapter.ACTION_STATE_CHANGED) {
        nextAttemptAt = 0L
        wake.trySend(Unit)
      }
    }
  }

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onCreate() {
    super.onCreate()
    bridge = ProtocolBridge.get(this)
    ensureChannel()
    bridge.addListener(bridgeListener)
    try {
      val filter = IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED)
      if (Build.VERSION.SDK_INT >= 33) registerReceiver(btReceiver, filter, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(btReceiver, filter)
    } catch (_: Throwable) {
    }
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    // Wajib dalam 5 detik setelah startForegroundService, apa pun isi intent (juga saat dihidupkan ulang sistem dengan intent null).
    if (!enterForeground()) {
      stopSelf()
      return START_NOT_STICKY
    }
    when (intent?.action) {
      ACTION_NOW -> {
        // Tombol di notifikasi: sambung/sinkron sekarang, tanpa menunggu jeda.
        forceNow = true
        nextAttemptAt = 0L
        attempt = 0
        wake.trySend(Unit)
      }
      ACTION_TICK, ACTION_REPOST -> {
        lastShown = null
        postNotification()
        wake.trySend(Unit)
      }
    }
    if (loopJob?.isActive != true) loopJob = scope.launch { runLoop() }
    return START_STICKY
  }

  override fun onDestroy() {
    try { unregisterReceiver(btReceiver) } catch (_: Throwable) {}
    bridge.removeListener(bridgeListener)
    cancelTick()
    releaseWake()
    scope.cancel()
    super.onDestroy()
  }

  // ---- Perulangan utama ----

  private var lastPing = 0L
  private var syncRetryAt = 0L

  private suspend fun runLoop() {
    while (true) {
      var waitMs = 0L
      try {
        if (!KeepAliveConfig.wanted(this)) {
          finish()
          return
        }
        waitMs = step()
      } catch (e: CancellationException) {
        throw e
      } catch (t: Throwable) {
        // Kegagalan tak terduga tidak boleh mematikan penjagaan: catat di notifikasi, lalu coba lagi.
        note = t.message ?: t.javaClass.simpleName
        postNotification()
        withTimeoutOrNull(10_000L) { wake.receive() }
        continue
      }
      postNotification()
      if (waitMs >= 20_000L) scheduleTick(waitMs)
      withTimeoutOrNull(waitMs) { wake.receive() }
    }
  }

  /** Satu putaran: sambung ulang, sinkron, atau uji tautan sesuai keadaan. Mengembalikan lama menunggu sebelum putaran berikut. */
  private suspend fun step(): Long {
    val intervalMs = KeepAliveConfig.intervalMin(this) * 60_000L
    val now = System.currentTimeMillis()
    val snap = bridge.snapshot()
    if (!bluetoothReady()) {
      note = tr("Bluetooth mati atau izin kurang", "Bluetooth is off or permission missing")
      return 15_000L
    }
    if (bridge.watchAddress() == null) {
      note = tr("Belum ada jam: hubungkan dari Atur › Huawei Watch", "No watch yet: connect from Settings › Huawei Watch")
      return 30_000L
    }
    when (snap.state) {
      LinkState.CONNECTED -> {
        note = null
        attempt = 0
        val dueAt = maxOf(syncRetryAt, if (bridge.lastSyncAtMs == 0L) 0L else bridge.lastSyncAtMs + intervalMs)
        if (forceNow || now >= dueAt) {
          forceNow = false
          val ok = withWake { bridge.keepSync() }
          // Gagal: tunggu semenit sebelum mencoba lagi, jangan menghajar jam setiap beberapa detik.
          syncRetryAt = if (ok) 0L else System.currentTimeMillis() + 60_000L
          lastPing = System.currentTimeMillis()
        } else if (now - lastPing >= PING_MS) {
          lastPing = now
          val alive = withWake { bridge.keepPing() }
          if (!alive) {
            bridge.keepDrop()
            return 1_000L
          }
        }
        val after = System.currentTimeMillis()
        val nextSync = maxOf(syncRetryAt, if (bridge.lastSyncAtMs == 0L) 0L else bridge.lastSyncAtMs + intervalMs)
        val untilSync = maxOf(5_000L, nextSync - after)
        val untilPing = maxOf(5_000L, lastPing + PING_MS - after)
        return minOf(untilSync, untilPing, MAX_IDLE_MS)
      }
      LinkState.DISCONNECTED -> {
        if (now < nextAttemptAt) return maxOf(1_000L, nextAttemptAt - now)
        val failure = withWake { bridge.keepConnect() }
        if (failure == null) {
          note = null
          attempt = 0
          syncRetryAt = 0L
          lastPing = System.currentTimeMillis()
          return 1_000L
        }
        if (failure == "needs-bind") {
          note = tr("Ikat jam dulu dari aplikasi (konfirmasi di layar jam)", "Bind the watch from the app first (confirm on the watch)")
          nextAttemptAt = System.currentTimeMillis() + 60_000L
          return 60_000L
        }
        attempt++
        val delaySec = BACKOFF_SEC[minOf(attempt - 1, BACKOFF_SEC.size - 1)]
        note = tr("Mencoba lagi dalam $delaySec dtk (percobaan ke-$attempt)", "Retrying in ${delaySec}s (attempt $attempt)")
        nextAttemptAt = System.currentTimeMillis() + delaySec * 1000L
        return delaySec * 1000L
      }
      else -> return 3_000L // sedang menyambung atau menyinkron (dari aplikasi atau layanan)
    }
  }

  private fun finish() {
    try {
      if (Build.VERSION.SDK_INT >= 24) {
        stopForeground(STOP_FOREGROUND_REMOVE)
      } else {
        @Suppress("DEPRECATION")
        stopForeground(true)
      }
    } catch (_: Throwable) {
    }
    stopSelf()
  }

  private suspend fun <T> withWake(block: suspend () -> T): T {
    acquireWake()
    try {
      return block()
    } finally {
      releaseWake()
    }
  }

  private fun acquireWake() {
    try {
      val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
      val lock = wakeLock ?: pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "TrainingPlan:WatchLink").also {
        it.setReferenceCounted(false)
        wakeLock = it
      }
      if (!lock.isHeld) lock.acquire(WAKE_MAX_MS)
    } catch (_: Throwable) {
    }
  }

  private fun releaseWake() {
    try {
      wakeLock?.let { if (it.isHeld) it.release() }
    } catch (_: Throwable) {
    }
  }

  private fun bluetoothReady(): Boolean {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
      checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
    ) return false
    val adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter ?: return false
    return adapter.isEnabled
  }

  // ---- Alarm cadangan (Doze menunda timer biasa; alarm ini membangunkan perulangan) ----

  private fun tickIntent(): PendingIntent {
    val i = Intent().setClassName(packageName, KeepAliveConfig.SERVICE_CLASS).setAction(ACTION_TICK)
    val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
    return if (Build.VERSION.SDK_INT >= 26) PendingIntent.getForegroundService(this, 11, i, flags) else PendingIntent.getService(this, 11, i, flags)
  }

  private fun scheduleTick(afterMs: Long) {
    try {
      val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
      val at = SystemClock.elapsedRealtime() + afterMs
      if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, tickIntent())
      else am.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, tickIntent())
    } catch (_: Throwable) {
    }
  }

  private fun cancelTick() {
    try {
      (getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(tickIntent())
    } catch (_: Throwable) {
    }
  }

  // ---- Notifikasi tetap ----

  private fun tr(id: String, en: String): String = if (KeepAliveConfig.lang(this) == "en") en else id

  private fun ensureChannel() {
    if (Build.VERSION.SDK_INT < 26) return
    val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (nm.getNotificationChannel(CHANNEL_ID) != null) return
    val ch = NotificationChannel(CHANNEL_ID, tr("Koneksi jam", "Watch connection"), NotificationManager.IMPORTANCE_LOW)
    ch.description = tr("Menunjukkan apakah jam Huawei tersambung dan kapan terakhir disinkron.", "Shows whether the Huawei watch is connected and when it last synced.")
    ch.setShowBadge(false)
    ch.enableVibration(false)
    ch.setSound(null, null)
    ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
    nm.createNotificationChannel(ch)
  }

  private fun hm(ms: Long): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(ms))

  // ---- Estimasi baterai: log sampel (detik, persen) disimpan ringan di SharedPreferences, rumus sama dengan kartu baterai di app ----

  private val batLog = ArrayList<LongArray>()
  private var batLoaded = false

  private fun batPrefs() = getSharedPreferences("ev_keepalive_bat", Context.MODE_PRIVATE)

  private fun loadBatLog() {
    if (batLoaded) return
    batLoaded = true
    try {
      val raw = batPrefs().getString("log", "") ?: ""
      for (part in raw.split(",")) {
        val kv = part.split(":")
        if (kv.size == 2) batLog.add(longArrayOf(kv[0].toLong(), kv[1].toLong()))
      }
    } catch (_: Throwable) {
      batLog.clear()
    }
  }

  private fun recordBattery(level: Int) {
    loadBatLog()
    val nowSec = System.currentTimeMillis() / 1000L
    val last = batLog.lastOrNull()
    if (last != null && last[1] == level.toLong() && nowSec - last[0] < 600L) return
    batLog.add(longArrayOf(nowSec, level.toLong()))
    batLog.removeAll { it[0] < nowSec - 7 * 3600L }
    try {
      batPrefs().edit().putString("log", batLog.joinToString(",") { "${it[0]}:${it[1]}" }).apply()
    } catch (_: Throwable) {
    }
  }

  /** Sisa jam menurut laju turun terkini (jendela 1 jam, lalu 6 jam); null bila data belum cukup. */
  private fun batteryHoursLeft(level: Int): Double? {
    loadBatLog()
    val nowSec = System.currentTimeMillis() / 1000L
    if (level <= 0) return null
    for (win in longArrayOf(3600L, 6 * 3600L)) {
      var pts = batLog.filter { it[0] >= nowSec - win && it[0] <= nowSec + 60L }
      var from = 0
      for (i in 1 until pts.size) if (pts[i][1] > pts[i - 1][1]) from = i
      pts = pts.drop(from)
      if (pts.size < 2) continue
      val span = pts.last()[0] - pts.first()[0]
      val drop = pts.first()[1] - pts.last()[1]
      if (span >= 900L && drop >= 1L) return minOf(99.0, level / (drop / (span / 3600.0)))
    }
    return null
  }

  private fun batteryCharging(): Boolean {
    loadBatLog()
    val n = batLog.size
    val nowSec = System.currentTimeMillis() / 1000L
    return n >= 2 && batLog[n - 1][1] > batLog[n - 2][1] && nowSec - batLog[n - 1][0] <= 1800L
  }

  /** Dua satuan: "3 days 14 hours", "5 hours 20 min", "40 min". */
  private fun durationTxt(hours: Double): String {
    val en = KeepAliveConfig.lang(this) == "en"
    fun u(n: Long, one: String, many: String, id: String) = if (en) "$n ${if (n == 1L) one else many}" else "$n $id"
    val totalMin = Math.round(hours * 60.0)
    if (totalMin >= 24 * 60) {
      val totalH = Math.round(hours)
      val d = totalH / 24
      val h = totalH % 24
      val dTxt = u(d, "day", "days", "hari")
      return if (h > 0) dTxt + " " + u(h, "hour", "hours", "jam") else dTxt
    }
    val h = totalMin / 60
    val m = totalMin % 60
    if (h <= 0L) return u(maxOf(m, 1L), "min", "min", "mnt")
    val hTxt = u(h, "hour", "hours", "jam")
    return if (m > 0) hTxt + " " + u(m, "min", "min", "mnt") else hTxt
  }

  /**
   * Pengingat sekali per penurunan: bila baterai jam turun sampai ambang (bawaan 20%, 0 = mati) dan tidak sedang mengisi, kirim satu
   * notifikasi biasa (bukan yang tetap). Dibuka lagi setelah jam diisi atau baterai naik 15 poin di atas ambang. Jam yang mati
   * di tengah malam berarti tidur malam itu tidak terekam.
   */
  private fun checkLowBattery(level: Int) {
    val pct = KeepAliveConfig.lowBatteryPct(this)
    if (pct <= 0) return
    val prefs = batPrefs()
    val warned = prefs.getBoolean("low_warned", false)
    val charging = batteryCharging()
    if (warned) {
      if (charging || level >= pct + 15) prefs.edit().putBoolean("low_warned", false).apply()
      return
    }
    if (!charging && level <= pct) {
      prefs.edit().putBoolean("low_warned", true).apply()
      postLowBattery(level)
    }
  }

  private fun postLowBattery(level: Int) {
    try {
      val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(LOW_BAT_CHANNEL) == null) {
        val ch = NotificationChannel(LOW_BAT_CHANNEL, tr("Baterai jam rendah", "Watch battery low"), NotificationManager.IMPORTANCE_DEFAULT)
        ch.description = tr("Pengingat satu kali agar jam diisi daya sebelum mati.", "A one-time reminder to charge the watch before it dies.")
        nm.createNotificationChannel(ch)
      }
      val immutable = if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
      val open = packageManager.getLaunchIntentForPackage(packageName)?.apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
      }
      val openPi = open?.let { PendingIntent.getActivity(this, 1, it, PendingIntent.FLAG_UPDATE_CURRENT or immutable) }
      @Suppress("DEPRECATION")
      val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, LOW_BAT_CHANNEL) else Notification.Builder(this)
      b.setSmallIcon(R.drawable.ic_stat_ev_off)
        .setColor(ACCENT_ORANGE)
        .setContentTitle(tr("Baterai jam $level%", "Watch battery $level%"))
        .setContentText(tr("Isi daya sebelum tidur agar data tidur malam ini tercatat.", "Charge it before bed so tonight's sleep gets recorded."))
        .setAutoCancel(true)
      if (openPi != null) b.setContentIntent(openPi)
      nm.notify(LOW_BAT_NOTIF_ID, b.build())
    } catch (_: Throwable) {
    }
  }

  private fun batteryLine(level: Int?): String {
    if (level == null) return ""
    recordBattery(level)
    checkLowBattery(level)
    val head = tr("Baterai $level%", "Battery $level%")
    if (batteryCharging()) return head + " · " + tr("sedang mengisi", "charging")
    val left = batteryHoursLeft(level) ?: return head
    return head + " · " + tr("estimasi ${durationTxt(left)} lagi", "est. ${durationTxt(left)} left")
  }

  /** Judul dan isi notifikasi menurut keadaan tautan saat ini. */
  private fun describe(): Triple<String, String, Boolean> {
    val snap = bridge.snapshot()
    return when (snap.state) {
      LinkState.CONNECTED, LinkState.SYNCING -> Triple("Connected", batteryLine(snap.battery), true)
      LinkState.CONNECTING, LinkState.AUTHENTICATING, LinkState.INITIALIZING ->
        Triple(tr("Menghubungkan…", "Connecting…"), "", false)
      else -> Triple("Disconnected", "", false)
    }
  }

  private fun buildNotification(): Notification {
    val (title, text, connected) = describe()
    val immutable = if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
    val open = packageManager.getLaunchIntentForPackage(packageName)?.apply {
      addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
    }
    val openPi = open?.let { PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_UPDATE_CURRENT or immutable) }
    val actionIntent = Intent().setClassName(packageName, KeepAliveConfig.SERVICE_CLASS).setAction(ACTION_NOW)
    val deleteIntent = Intent().setClassName(packageName, KeepAliveConfig.SERVICE_CLASS).setAction(ACTION_REPOST)
    val actionPi: PendingIntent
    val deletePi: PendingIntent
    if (Build.VERSION.SDK_INT >= 26) {
      actionPi = PendingIntent.getForegroundService(this, 12, actionIntent, PendingIntent.FLAG_UPDATE_CURRENT or immutable)
      deletePi = PendingIntent.getForegroundService(this, 13, deleteIntent, PendingIntent.FLAG_UPDATE_CURRENT or immutable)
    } else {
      actionPi = PendingIntent.getService(this, 12, actionIntent, PendingIntent.FLAG_UPDATE_CURRENT or immutable)
      deletePi = PendingIntent.getService(this, 13, deleteIntent, PendingIntent.FLAG_UPDATE_CURRENT or immutable)
    }
    @Suppress("DEPRECATION")
    val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this).setPriority(Notification.PRIORITY_LOW)
    // Ikon siluet tanda EV (res/drawable/ic_stat_ev*.xml), diwarnai oranye lewat setColor seperti ikon aplikasi.
    // Android 10 memakai siluet satu warna; yang terputus diberi lencana tanda seru di kanan bawah.
    // Status "menghubungkan" masih memakai ikon biasa tanpa lencana.
    val linkState = bridge.snapshot().state
    val linking = linkState == LinkState.CONNECTING || linkState == LinkState.AUTHENTICATING || linkState == LinkState.INITIALIZING
    b.setSmallIcon(if (connected || linking) R.drawable.ic_stat_ev else R.drawable.ic_stat_ev_off)
      .setColor(ACCENT_ORANGE)
      .setContentTitle(title)
      .setOngoing(true)
      .setOnlyAlertOnce(true)
      .setShowWhen(false)
      .setCategory(Notification.CATEGORY_SERVICE)
      .setDeleteIntent(deletePi)
    if (text.isNotEmpty()) b.setContentText(text).setStyle(Notification.BigTextStyle().bigText(text))
    if (openPi != null) b.setContentIntent(openPi)
    // Tombol hanya saat terputus (bukan saat sedang menghubungkan atau terhubung).
    if (!connected && !linking) {
      @Suppress("DEPRECATION")
      b.addAction(0, "Connect", actionPi)
    }
    if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
    val n = b.build()
    // Tidak bisa digeser pergi, juga di Android 14+ (notifikasi layanan latar yang ongoing tidak bisa ditutup pengguna).
    n.flags = n.flags or Notification.FLAG_ONGOING_EVENT or Notification.FLAG_NO_CLEAR
    return n
  }

  private fun enterForeground(): Boolean {
    return try {
      ensureChannel()
      val n = buildNotification()
      if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
      else startForeground(NOTIF_ID, n)
      lastShown = describe().let { it.first + "|" + it.second }
      true
    } catch (_: Throwable) {
      // Android menolak (izin Bluetooth belum diberikan, atau dimulai dari latar belakang tanpa pengecualian).
      false
    }
  }

  private fun postNotification() {
    try {
      val d = describe()
      val key = d.first + "|" + d.second
      if (key == lastShown) return
      lastShown = key
      (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification())
    } catch (_: Throwable) {
    }
  }

  companion object {
    private const val WORKOUT_ALERT_CHANNEL = "watch_new_workouts"
    private const val WORKOUT_ALERT_ID = 7422
    const val ACTION_NOW = "com.rencanalari.huaweiwatch.action.NOW"
    const val ACTION_TICK = "com.rencanalari.huaweiwatch.action.TICK"
    const val ACTION_REPOST = "com.rencanalari.huaweiwatch.action.REPOST"
    private const val CHANNEL_ID = "watch_keepalive"
    private const val NOTIF_ID = 7410
    private const val LOW_BAT_NOTIF_ID = 7411
    private const val LOW_BAT_CHANNEL = "watch_low_battery"
    /** Oranye logo EV untuk ikon notifikasi (siluet satu warna diwarnai lewat setColor). */
    private const val ACCENT_ORANGE = 0xFFFF7A12.toInt()
    private const val PING_MS = 3 * 60_000L
    private const val MAX_IDLE_MS = 60_000L
    private const val WAKE_MAX_MS = 3 * 60_000L
    private val BACKOFF_SEC = intArrayOf(5, 10, 20, 40, 60, 120, 300)
  }
}
