package com.endurancevault.app.watch

import nodomain.freeyourgadget.gadgetbridge.devices.huawei.HuaweiPacket
import nodomain.freeyourgadget.gadgetbridge.devices.huawei.HuaweiTLV

/*
 * Pengganti BuildConfig dan R untuk berkas protokol yang disalin apa adanya (Distribution.kt, MorningSummary.kt).
 * Di proyek asalnya keduanya dibuat Gradle; di plugin ini namespace-nya berbeda, jadi paket com.endurancevault.app.watch
 * tidak punya keduanya. Berkas ini milik proyek TrainingPlan, bukan salinan dari proyek lain.
 */

/** Build sideload: tidak memakai izin SMS, log panggilan, atau kontak (plugin ini juga tidak mendeklarasikannya). */
internal object BuildConfig {
  const val DISTRIBUTION = "sideload"
}

internal object R {
  object drawable {
    const val ic_stat_watch: Int = android.R.drawable.stat_notify_sync
  }
  object color {
    const val watch_notification_accent: Int = android.R.color.holo_blue_dark
  }
}

/**
 * Paket dari TLV siap pakai, terenkripsi seperti paket pasca-autentikasi lain. Di proyek asalnya ini ada di WorkoutLink.kt, yang tidak ikut
 * disalin; Ephemeris.kt (A-GPS) memakainya. Isinya sama dengan aslinya.
 */
internal class RawPacket(params: HuaweiPacket.ParamsProvider, service: Int, command: Int, content: HuaweiTLV) : HuaweiPacket(params) {
  init {
    serviceId = service.toByte()
    commandId = command.toByte()
    tlv = content
    isEncrypted = true
    complete = true
  }
}
