package com.endurancevault.app.watch

import android.content.Context
import java.io.File

/**
 * Memindahkan data lapisan jam dari nama lama ke nama baru, sekali saja, sebelum ada yang membukanya:
 *  - database `SQLite/joyofit.db` (+ `-wal`, `-shm`, `-journal`) menjadi `SQLite/watch.db`
 *  - SharedPreferences `joyofit_settings` menjadi `watch_settings`
 * Berkas milik proyek ini (bukan salinan dari proyek lain). Aman dipanggil berulang: bila nama lama tidak ada, tidak melakukan apa pun.
 */
object LegacyWatchMigration {
  const val OLD_DB = "joyofit.db"
  const val NEW_DB = "watch.db"
  const val OLD_PREFS = "joyofit_settings"
  const val NEW_PREFS = "watch_settings"

  private val DB_SUFFIXES = listOf("", "-wal", "-shm", "-journal")

  /** Panggil dari Application.onCreate, sebelum SyncStore / WearSettings / WeatherSettings disentuh. */
  fun run(context: Context) {
    val app = context.applicationContext
    try {
      migrateDbFiles(File(app.filesDir, "SQLite"))
    } catch (e: Exception) {
      // Gagal pindah berkas: biarkan data lama di tempatnya, pengguna tidak kehilangan apa pun.
    }
    try {
      migratePrefs(app)
    } catch (e: Exception) {
    }
  }

  /**
   * Pindahkan berkas database lama ke nama baru. Tidak menimpa: bila `watch.db` sudah ada, berkas lama dibiarkan.
   * Berkas utama dipindah paling akhir supaya kegagalan di tengah jalan tidak meninggalkan WAL tanpa database.
   * @return true bila ada yang dipindah
   */
  internal fun migrateDbFiles(dir: File): Boolean {
    val oldMain = File(dir, OLD_DB)
    val newMain = File(dir, NEW_DB)
    if (!oldMain.exists() || newMain.exists()) return false
    for (suffix in DB_SUFFIXES.reversed()) {
      val from = File(dir, OLD_DB + suffix)
      if (!from.exists()) continue
      val to = File(dir, NEW_DB + suffix)
      if (!from.renameTo(to)) {
        from.copyTo(to, overwrite = true)
        from.delete()
      }
    }
    return true
  }

  /** Salin semua kunci dari pengaturan lama yang belum ada di yang baru, lalu hapus yang lama. */
  private fun migratePrefs(app: Context) {
    val oldFile = File(File(app.filesDir.parentFile, "shared_prefs"), "$OLD_PREFS.xml")
    if (!oldFile.exists()) return
    val old = app.getSharedPreferences(OLD_PREFS, Context.MODE_PRIVATE)
    val target = app.getSharedPreferences(NEW_PREFS, Context.MODE_PRIVATE)
    val editor = target.edit()
    for ((key, value) in old.all) {
      if (target.contains(key)) continue
      when (value) {
        is String -> editor.putString(key, value)
        is Int -> editor.putInt(key, value)
        is Long -> editor.putLong(key, value)
        is Float -> editor.putFloat(key, value)
        is Boolean -> editor.putBoolean(key, value)
        is Set<*> -> editor.putStringSet(key, value.filterIsInstance<String>().toSet())
      }
    }
    if (editor.commit()) {
      old.edit().clear().commit()
      app.deleteSharedPreferences(OLD_PREFS)
    }
  }
}
