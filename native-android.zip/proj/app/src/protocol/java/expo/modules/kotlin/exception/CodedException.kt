package expo.modules.kotlin.exception

/**
 * Pengganti minimal untuk CodedException milik Expo. Kode protokol yang disalin (WearTypes.kt) mewarisinya;
 * di sini tidak ada Expo, jadi cukup kelas biasa dengan kode galat. Bukan bagian dari Expo.
 */
open class CodedException(val code: String, message: String?, cause: Throwable?) : RuntimeException(message, cause)
