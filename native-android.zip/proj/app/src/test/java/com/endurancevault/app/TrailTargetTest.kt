package com.endurancevault.app

import com.endurancevault.app.domain.GpxRoute
import com.endurancevault.app.domain.Kinds
import com.endurancevault.app.domain.PDay
import com.endurancevault.app.domain.PlanEngine
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.domain.TrailTarget
import com.endurancevault.app.domain.TrailTarget.Level
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.time.LocalDate

class TrailTargetTest {
    // ---------- toleransi ----------

    @Test fun toleransiJarakDanGain() {
        assertEquals(1.0, TrailTarget.kmTol(5.0), 1e-9)      // lantai 1 km
        assertEquals(1.4, TrailTarget.kmTol(14.0), 1e-9)     // 10%
        assertEquals(50.0, TrailTarget.gainTol(200.0), 1e-9) // lantai 50 m
        assertEquals(90.0, TrailTarget.gainTol(600.0), 1e-9) // 15%
    }

    @Test fun levelOkNearOff() {
        assertEquals(Level.OK, TrailTarget.level(1.4, 1.4))
        assertEquals(Level.OK, TrailTarget.level(-1.0, 1.4))
        assertEquals(Level.NEAR, TrailTarget.level(1.5, 1.4))
        assertEquals(Level.NEAR, TrailTarget.level(-2.1, 1.4))   // batas 1,5 × 1,4 = 2,1
        assertEquals(Level.OFF, TrailTarget.level(2.2, 1.4))
    }

    // ---------- review dari statistik ----------

    private fun stats(km: Double, up: Int, hasEle: Boolean = true) =
        GpxRoute.Stats(km, up, 0, null, null, hasEle, emptyList())

    @Test fun reviewSesuai() {
        val r = TrailTarget.review("R", 14.0, 600, stats(13.2, 560))
        assertEquals(Level.OK, r.overall)
        assertEquals(Level.OK, r.km.level)
        assertEquals(Level.OK, r.gain!!.level)
        assertFalse(r.noElevation)
    }

    @Test fun reviewTerburukMenentukanHasilAkhir() {
        // jarak pas, D+ kurang 40% → belum sesuai
        val r = TrailTarget.review("R", 14.0, 600, stats(14.0, 360))
        assertEquals(Level.OK, r.km.level)
        assertEquals(Level.OFF, r.gain!!.level)
        assertEquals(Level.OFF, r.overall)
        assertTrue(r.lines.any { it.startsWith("D+ kurang") })
    }

    @Test fun reviewHampirSesuai() {
        // jarak kelebihan 1,6 km (toleransi 1,4; batas hampir 2,1)
        val r = TrailTarget.review("R", 14.0, 600, stats(15.6, 600))
        assertEquals(Level.NEAR, r.overall)
        assertTrue(r.lines.any { it.startsWith("Jarak lebih") })
    }

    @Test fun gpxTanpaElevasiHanyaMenilaiJarak() {
        val r = TrailTarget.review("R", 14.0, 600, stats(14.2, 0, hasEle = false))
        assertTrue(r.noElevation)
        assertNull(r.gain)
        assertEquals(Level.OK, r.overall)
        assertTrue(r.lines.any { it.contains("tidak punya data elevasi") })
    }

    @Test fun tanpaTargetGainHanyaJarak() {
        val r = TrailTarget.review("R", 10.0, null, stats(10.0, 500))
        assertNull(r.gain)
        assertFalse(r.noElevation)
    }

    // ---------- review dari teks GPX ----------

    private fun gpx(pts: List<Triple<Double, Double, Double?>>) =
        "<?xml version=\"1.0\"?><gpx xmlns=\"http://www.topografix.com/GPX/1/1\"><trk><name>Uji</name><trkseg>" +
            pts.joinToString("") { (la, lo, e) -> "<trkpt lat=\"$la\" lon=\"$lo\">" + (if (e != null) "<ele>$e</ele>" else "") + "</trkpt>" } +
            "</trkseg></trk></gpx>"

    // 41 titik, lintang naik 0,001° tiap titik (±4,45 km), elevasi 100 → 180 m (D+ 80 m)
    private val line = (0..40).map { Triple(-6.0 + it * 0.001, 106.0, 100.0 + it * 2.0) }

    @Test fun reviewGpxMemakaiJarakDanDplusDariBerkas() {
        val ok = TrailTarget.reviewGpx(gpx(line), "x.gpx", 4.5, 80)
        assertEquals("Uji", ok.routeName)
        assertEquals(Level.OK, ok.overall)
        val jauh = TrailTarget.reviewGpx(gpx(line), "x.gpx", 10.0, 80)
        assertEquals(Level.OFF, jauh.km.level)
        assertEquals(Level.OFF, jauh.overall)
    }

    @Test fun gpxRusakDitolakDenganPesan() {
        try { TrailTarget.reviewGpx("bukan xml", "a.gpx", 10.0, 100); fail() } catch (e: GpxRoute.Err) { assertTrue(e.message!!.contains("tidak bisa dibaca")) }
        try { TrailTarget.reviewGpx(gpx(listOf(Triple(-6.0, 106.0, 1.0))), "a.gpx", 10.0, 100); fail() } catch (e: GpxRoute.Err) { assertTrue(e.message!!.contains("minimal 2 titik")) }
    }

    // ---------- target pada rencana ----------

    private fun day(km: Double, gain: Int?, detail: String = TrailTarget.targetText(km, gain) + "HR ≤ 150. ") =
        PDay(LocalDate.of(2026, 11, 8), 6, Kinds.LONG, "long", "Long run · Trail", km, detail).also { it.gain = gain }

    @Test fun targetHanyaUntukSesiTrailBertarget() {
        val d = day(14.0, 600)
        val t = TrailTarget.targetOf(d)
        assertNotNull(t); assertEquals(14.0, t!!.km, 1e-9); assertEquals(600, t.gain)
        assertNull(TrailTarget.targetOf(day(14.0, 600, "Easy, HR ≤ 150.")))         // bukan sesi bertarget
        assertNull(TrailTarget.targetOf(day(14.0, 600).also { it.kind = Kinds.REST })) // libur
        assertNull(TrailTarget.targetOf(day(0.0, 600)))                              // sudah dibatalkan (km 0)
        assertNull(TrailTarget.targetOf(day(14.0, null))!!.gain)                     // tanpa D+: hanya jarak
    }

    @Test fun syncMenyelaraskanTeksDenganKmDanGainBaru() {
        val d = day(14.0, 600)
        d.km = 9.8; d.gain = 400
        TrailTarget.sync(d)
        assertTrue(d.detail, d.detail.startsWith("Target trail: ±9.8 km dan +400 m. "))
        assertTrue(d.detail, d.detail.endsWith("HR ≤ 150. "))
        // sinkron ulang tidak mengubah apa pun
        val before = d.detail
        TrailTarget.sync(d)
        assertEquals(before, d.detail)
    }

    @Test fun scaleGainMenjagaKerapatanTanjakan() {
        val d = day(14.0, 600)
        TrailTarget.scaleGain(d, 0.7)
        assertEquals(420, d.gain)
        val bukanTarget = day(14.0, 600, "Easy bergelombang.")
        TrailTarget.scaleGain(bukanTarget, 0.7)
        assertEquals(600, bukanTarget.gain)
    }

    private fun ultra(smooth: Boolean) = PlanSettings(
        name = "Uji", rtype = "ultra", start = LocalDate.of(2026, 11, 2), race = LocalDate.of(2027, 5, 30),
        raceKm = 50.0, raceGain = 2400.0, base = 55.0, peak = 75.0, days = 6, gSmooth = smooth,
    )

    @Test fun rencanaTrailTidakLagiMemakaiLoopUngaran() {
        for (smooth in listOf(false, true)) {
            val out = PlanEngine.plan(ultra(smooth), LocalDate.of(2026, 11, 5)) as PlanOutcome.Ok
            var trailSessions = 0
            out.weeks.forEach { w ->
                w.days.forEach { d ->
                    assertFalse("Ungaran masih muncul: ${d.title}", d.title.contains("Ungaran"))
                    assertFalse("Ungaran masih muncul: ${d.detail}", d.detail.contains("Ungaran"))
                    // sesi Uji kebugaran memang memakai loop Ambarawa 6,3 km; sesi lain tidak boleh memakai loop tetap
                    if (!d.bench) assertFalse("loop masih muncul: ${d.detail}", d.detail.contains("loop"))
                    if (d.title.contains("Trail")) {
                        trailSessions++
                        assertNotNull("sesi trail harus punya target (smooth=$smooth): ${d.title}", TrailTarget.targetOf(d))
                        // teks target selalu sama dengan km dan D+ sesi (bukan kelipatan loop 7 km / 750 m)
                        assertTrue("detail: ${d.detail}", d.detail.startsWith(TrailTarget.targetText(d.km, d.gain)))
                        assertTrue(d.km >= 3.0)
                    }
                }
            }
            assertTrue("rencana ultra harus punya sesi trail (smooth=$smooth)", trailSessions > 0)
        }
    }

    @Test fun sesiTrailMendapatGainPadaRencanaDenganPenghalus() {
        val out = PlanEngine.plan(ultra(true), LocalDate.of(2026, 11, 5)) as PlanOutcome.Ok
        val trail = out.weeks.flatMap { it.days }.filter { it.title.contains("Trail") }
        assertTrue(trail.isNotEmpty())
        assertTrue("minimal sebagian besar sesi trail ber-D+", trail.count { (it.gain ?: 0) > 0 } >= trail.size * 0.9)
    }
}
