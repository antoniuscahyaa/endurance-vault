package com.endurancevault.app

import com.endurancevault.app.domain.StickerDeps
import com.endurancevault.app.domain.StickerPrefs
import com.endurancevault.app.domain.Stickers
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Menjaga tabel "pengaturan mana mempengaruhi stiker mana" ([StickerDeps]). Bila ada stiker atau pengaturan baru dan tabel
 * lupa diperbarui, tes ini gagal; tanpa tes, hasilnya gambar pratinjau yang diam-diam kedaluwarsa.
 */
class StickerDepsTest {
    private val base = StickerPrefs()

    /** Semua id stiker yang mungkin ada: angka, peta, angka minggu, statistik periode, dan grafik. */
    private val ids: List<String> = buildList {
        add("n-all")
        Stickers.ALL_NUM_KEYS.forEach { add("n-$it") }
        add("map"); add("wk-all")
        listOf("day", "week", "month").forEach { per -> Stickers.PERIOD_KINDS.forEach { (kind, _) -> add(Stickers.periodId(per, kind)) } }
        Stickers.GRAPHS.forEach { add(it.first) }
    }

    private val angka = setOf("pd-angka", "pw-angka", "pm-angka")

    private fun affected(p: StickerPrefs): Set<String> = ids.filter { StickerDeps.key(it, base) != StickerDeps.key(it, p) }.toSet()

    @Test fun idListHasNoDuplicates() {
        assertEquals(ids.size, ids.toSet().size)
    }

    @Test fun everyKnownIdHasAnExplicitRule() {
        // Id tak dikenal jatuh ke aturan aman yang memuat seluruh pengaturan (termasuk snap); id yang sudah dipetakan tidak.
        for (id in ids) assertEquals("stiker $id belum ada di StickerDeps", StickerDeps.key(id, base), StickerDeps.key(id, base.copy(snap = !base.snap)))
    }

    @Test fun unknownIdDependsOnEverything() {
        assertNotEquals(StickerDeps.key("zzz", base), StickerDeps.key("zzz", base.copy(cols = 4)))
        assertNotEquals(StickerDeps.key("zzz", base), StickerDeps.key("zzz", base.copy(trendWeeks = 4)))
    }

    @Test fun styleSettingsAffectEverySticker() {
        val all = ids.toSet()
        assertEquals(all, affected(base.copy(ink = "k")))
        assertEquals(all, affected(base.copy(inkCustom = "#ff0000")))
        assertEquals(all, affected(base.copy(accent = "#ff0000")))
        assertEquals(all, affected(base.copy(panel = "soft")))
        assertEquals(all, affected(base.copy(scale = 150)))
        assertEquals(all, affected(base.copy(numStyle = "sport")))
    }

    @Test fun numberChoicesOnlyAffectNumberCards() {
        assertEquals(setOf("n-all"), affected(base.copy(order = listOf("jarak"))))
        assertEquals(setOf("wk-all"), affected(base.copy(wk = listOf("jarak"))))
        assertEquals(angka, affected(base.copy(pf = listOf("jarak"))))
        assertEquals(setOf("n-all", "wk-all", "cuaca", "best-effort") + angka, affected(base.copy(cols = 4)))
    }

    @Test fun mapSettingsOnlyAffectMaps() {
        val maps = setOf("map", "peta-warna")
        assertEquals(maps, affected(base.copy(lay = "kiri")))
        assertEquals(maps, affected(base.copy(mapColor = "hr")))
        assertEquals(maps, affected(base.copy(mapFields = emptySet())))
    }

    @Test fun chartSettingsOnlyAffectTheirCharts() {
        assertEquals(setOf("zona-hr-sesi", "zona-hr-tumpuk", "zona-hr-minggu"), affected(base.copy(hz = "dur")))
        assertEquals(setOf("zona-hr-minggu", "target-minggu"), affected(base.copy(weekColor = "#ff0000")))
        assertEquals(setOf("tren-pace"), affected(base.copy(trendWeeks = 4)))
        assertEquals(setOf("pace-segmen"), affected(base.copy(highlight = !base.highlight)))
        assertEquals(setOf("pace-segmen"), affected(base.copy(hrLine = !base.hrLine)))
    }

    @Test fun settingsThatDoNotChangeRenderingAffectNothing() {
        // mode/pack/snap hanya mengubah daftar atau cara simpan; huruf kustom ditangani lewat objek fonts di layar.
        assertTrue(affected(base.copy(mode = "pisah")).isEmpty())
        assertTrue(affected(base.copy(pack = listOf("map"))).isEmpty())
        assertTrue(affected(base.copy(snap = !base.snap)).isEmpty())
        assertTrue(affected(base.copy(fontNum = "x.ttf", fontBody = "y.ttf")).isEmpty())
    }
}
