package com.endurancevault.app

import com.endurancevault.app.domain.PlanEngine
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.PlanSettings
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

/** Sesi plan tidak boleh memuat nama daerah atau loop tetap; uji kebugaran dan turunan memakai rumus umum. */
class PlanGenericLabelsTest {
    private val today = LocalDate.of(2026, 11, 5)

    private fun plan(rtype: String): PlanOutcome.Ok {
        val s = PlanSettings(
            name = "Uji", rtype = rtype, start = LocalDate.of(2026, 11, 2), race = LocalDate.of(2027, 5, 30),
            raceKm = if (rtype == "ultra") 40.0 else null, raceGain = if (rtype == "ultra") 2000.0 else null,
            base = 40.0, peak = 65.0, days = 5, rest = 0, rest2 = 4, longDay = 6, hr = 150, thr = "164–172", pace = "6:30",
        )
        return PlanEngine.plan(s, today) as PlanOutcome.Ok
    }

    @Test fun tanpaNamaDaerahDanLoopTetap() {
        for (rt in listOf("hm", "ultra")) plan(rt).weeks.forEach { w -> w.days.forEach { d ->
            for (bad in listOf("Ambarawa", "Kebonsari", "Panjang–", "loop 6,3")) {
                assertFalse("${d.title}: $bad", d.title.contains(bad))
                assertFalse("${d.detail}: $bad", d.detail.contains(bad))
            }
        } }
    }

    @Test fun ujiKebugaranDanTurunanMemakaiRumusUmum() {
        var bench = 0; var descent = 0
        for (rt in listOf("hm", "ultra")) plan(rt).weeks.forEach { w -> w.days.forEach { d ->
            if (d.bench) {
                bench++
                assertTrue(d.title, d.title == "Uji kebugaran · HR tetap")
                assertTrue(d.detail, d.detail.contains("30 menit") && d.detail.contains("HR dikunci"))
            }
            if (d.title == "Turunan") {
                descent++
                assertTrue(d.detail, d.detail.contains("Estimasi target") && d.detail.contains("±6–8%"))
                assertTrue(d.gain != null && d.gain!! > 0)
            }
        } }
        assertTrue("harus ada sesi uji kebugaran", bench > 0)
    }
}
