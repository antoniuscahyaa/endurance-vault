package com.endurancevault.app

import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.domain.PeriodData
import com.endurancevault.app.domain.PeriodStats
import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.domain.SharePeriod
import com.endurancevault.app.domain.StickerPreset
import com.endurancevault.app.domain.StickerModel
import com.endurancevault.app.domain.StickerPrefs
import com.endurancevault.app.domain.Stickers
import com.endurancevault.app.domain.Zones
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class StickerPeriodTest {
    private val zc = Zones.cuts(PlanSettings(thr = "164–172"))

    private fun act(date: String, km: Double, sec: Int, hr: Int? = null, gain: Int? = null) =
        ActivityEntity(dateIso = date, km = km, durationSec = sec, avgHr = hr, gain = gain, type = "run")

    // 11 Nov 2026 = Rabu; minggunya 9..15 Nov, minggu lalu 2..8 Nov.
    private val acts = listOf(act("2026-11-09", 10.0, 3000, 150, 80), act("2026-11-11", 5.0, 1700, 140, 20), act("2026-11-02", 8.0, 2600))

    private fun model(): StickerModel {
        val e = acts[1]
        val p = PeriodData.of(acts, e, LocalDate.of(2026, 11, 11), emptyList(), LocalDate.of(2026, 11, 20))
        return Stickers.forActivity(e, null, emptyMap(), zc, null, p)!!
    }

    @Test fun weekNumbersUseWeekTotalsAndSuffixedLabels() {
        val m = model()
        assertEquals("15,0", m.numPer("jarak", "week")!!.value)
        assertEquals("Jarak minggu", m.numPer("jarak", "week")!!.label)
        assertEquals("2", m.numPer("hari", "week")!!.value)
        assertEquals("2", m.numPer("sesi", "week")!!.value)
    }

    @Test fun dayUsesOnlyTheOpenedSession() {
        val m = model()
        assertEquals("5,00", m.numPer("jarak", "day")!!.value)
        assertEquals("Jarak", m.numPer("jarak", "day")!!.label)
        assertNull(m.numPer("hari", "day"))
    }

    @Test fun calendarAndCurveOnlyForWeekAndMonth() {
        val m = model()
        assertNotNull(m.graphWhy("pd-kalender"))
        assertNotNull(m.graphWhy("pd-kurva"))
        assertNull(m.graphWhy("pw-kalender"))
        assertNull(m.graphWhy("pm-kurva"))
    }

    @Test fun ringNeedsPlanTargetAndCompareNeedsPrevious() {
        val m = model()
        assertNotNull(m.graphWhy("pw-cincin"))
        assertNull(m.graphWhy("pw-banding"))
    }

    @Test fun periodStickersAppearPerScopeWithLabels() {
        val m = model()
        val ids = Stickers.allIds(m, StickerPrefs())
        assertTrue("pw-angka" in ids)
        assertTrue("pd-angka" in ids)
        assertTrue("pm-angka" in ids)
        assertTrue("pw-hero" in ids)
        assertFalse("pw-cincin" in ids)
        assertFalse("pd-kalender" in ids)
        assertEquals("Angka · Minggu", Stickers.idLabel("pw-angka", m))
        assertEquals("Kalender · Bulan", Stickers.idLabel("pm-kalender", m))
        assertEquals("trainingplan-periode-hero-minggu-${m.date}.png", Stickers.fileName("pw-hero", m))
    }

    @Test fun scopesGroupStickersBySessionWeekMonth() {
        assertEquals("day", Stickers.scopeOf("map"))
        assertEquals("day", Stickers.scopeOf("n-all"))
        assertEquals("day", Stickers.scopeOf("pace-segmen"))
        assertEquals("day", Stickers.scopeOf("pd-banding"))
        assertEquals("week", Stickers.scopeOf("wk-all"))
        assertEquals("week", Stickers.scopeOf("tren-pace"))
        assertEquals("week", Stickers.scopeOf("pw-hero"))
        assertEquals("month", Stickers.scopeOf("pm-hero"))
        assertEquals(null, Stickers.perOfId("pace-repetisi"))
        assertEquals("", Stickers.kindOfId("pace-segmen"))
    }

    @Test fun prefsRoundTripAndSanitizePeriodFields() {
        val p = StickerPrefs.fromJson(StickerPrefs(pf = listOf("jarak", "sesi", "x")).toJson())
        assertEquals(listOf("jarak", "sesi"), p.pf)
    }

    @Test fun runningWeekComparesSameElapsedDays() {
        val a = listOf(act("2026-11-02", 8.0, 2600), act("2026-11-07", 20.0, 6000), act("2026-11-09", 10.0, 3000))
        val running = PeriodStats.previous(a, SharePeriod.WEEK, LocalDate.of(2026, 11, 9), LocalDate.of(2026, 11, 11))!!
        assertEquals(8.0, running.km, 1e-9)
        assertEquals(3, running.dailyKm.size)
        val done = PeriodStats.previous(a, SharePeriod.WEEK, LocalDate.of(2026, 11, 9), LocalDate.of(2026, 11, 20))!!
        assertEquals(28.0, done.km, 1e-9)
        assertEquals(7, done.dailyKm.size)
        assertEquals(28.0, PeriodStats.previous(a, SharePeriod.WEEK, LocalDate.of(2026, 11, 9))!!.km, 1e-9)
    }

    @Test fun runningMonthCutsPreviousMonthAtSameDay() {
        val a = listOf(act("2026-10-03", 5.0, 1500), act("2026-10-20", 30.0, 9000), act("2026-11-04", 6.0, 1800))
        val p = PeriodStats.previous(a, SharePeriod.MONTH, LocalDate.of(2026, 11, 4), LocalDate.of(2026, 11, 10))!!
        assertEquals(5.0, p.km, 1e-9)
        assertEquals(10, p.dailyKm.size)
    }

    @Test fun stylePresetsRoundTripAndSanitize() {
        val q = StickerPreset("Malam", "k", "#112233", "#ff8800", "soft", 150, "", "", "sport")
        val p = StickerPrefs(presets = listOf(q, q.copy(name = "  "), q.copy(name = "Malam"))).sanitized()
        assertEquals(listOf("Malam"), p.presets.map { it.name })
        val back = StickerPrefs.fromJson(StickerPrefs(numStyle = "sport", presets = listOf(q)).toJson())
        assertEquals("sport", back.numStyle)
        assertEquals(listOf(q), back.presets)
        val applied = StickerPrefs().withPreset(q)
        assertEquals("k", applied.ink); assertEquals("sport", applied.numStyle); assertEquals(150, applied.scale)
        assertTrue(applied.matches(q))
        assertEquals("std", StickerPrefs(numStyle = "x").sanitized().numStyle)
    }

    @Test fun monthWeeksAreClippedToMonthAndSumToMonthKm() {
        val w = PeriodStats.monthWeeks(acts, LocalDate.of(2026, 11, 11))
        assertEquals(6, w.size)
        assertEquals(listOf(0.0, 8.0, 15.0, 0.0, 0.0, 0.0), w.map { it.km })
        assertEquals(LocalDate.of(2026, 11, 1), w.first().start)
        assertEquals(LocalDate.of(2026, 11, 1), w.first().end)
        assertEquals(LocalDate.of(2026, 11, 30), w.last().start)
        assertEquals(LocalDate.of(2026, 11, 30), w.last().end)
        assertEquals(23.0, w.sumOf { it.km }, 1e-9)
    }

    @Test fun monthRecordsPickLongestFastestAndClimb() {
        val r = PeriodStats.monthRecords(acts, LocalDate.of(2026, 11, 11))!!
        assertEquals(10.0, r.longestKm, 1e-9); assertEquals(LocalDate.of(2026, 11, 9), r.longestDate)
        assertEquals(5.0, r.fastestPace!!, 1e-9); assertEquals(LocalDate.of(2026, 11, 9), r.fastestDate)
        assertEquals(80, r.topGain); assertEquals(LocalDate.of(2026, 11, 9), r.topGainDate)
        // lari pendek yang sangat cepat tidak dihitung untuk pace tercepat
        val withSprint = acts + act("2026-11-12", 1.0, 150)
        assertEquals(5.0, PeriodStats.monthRecords(withSprint, LocalDate.of(2026, 11, 11))!!.fastestPace!!, 1e-9)
        assertNull(PeriodStats.monthRecords(emptyList(), LocalDate.of(2026, 11, 11)))
    }

    @Test fun monthOnlyStickersAppearOnlyForMonth() {
        val m = model()
        val ids = Stickers.allIds(m, StickerPrefs())
        assertTrue("pm-pekan" in ids)
        assertTrue("pm-rekor" in ids)
        assertFalse("pw-pekan" in ids)
        assertFalse("pd-rekor" in ids)
        assertEquals("Rekor · Bulan", Stickers.idLabel("pm-rekor", m))
        assertEquals("Km per minggu · Bulan", Stickers.idLabel("pm-pekan", m))
        assertEquals("month", Stickers.scopeOf("pm-rekor"))
    }
}
