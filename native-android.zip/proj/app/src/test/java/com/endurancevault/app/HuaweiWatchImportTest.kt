package com.endurancevault.app

import com.endurancevault.app.data.DailyEntity
import com.endurancevault.app.data.HuaweiWatchImport
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant
import java.time.OffsetDateTime
import java.time.ZoneOffset

class HuaweiWatchImportTest {
    private fun ts(value: String) = Instant.parse(value).epochSecond

    @Test fun importsDirectWatchRhrHrvAndSleepStages() {
        val payload = JSONObject().apply {
            put("days", org.json.JSONArray().put(JSONObject().put("day", "2026-11-05").put("rhrLast", 48)))
            put("sleep", org.json.JSONArray()
                .put(JSONObject().put("start", ts("2026-11-04T22:00:00Z")).put("end", ts("2026-11-04T23:30:00Z")).put("type", 0).put("stage", "deep"))
                .put(JSONObject().put("start", ts("2026-11-04T23:30:00Z")).put("end", ts("2026-11-05T01:00:00Z")).put("type", 0).put("stage", "rem"))
                .put(JSONObject().put("start", ts("2026-11-05T01:00:00Z")).put("end", ts("2026-11-05T01:10:00Z")).put("type", 0).put("stage", "awake"))
                .put(JSONObject().put("start", ts("2026-11-05T02:00:00Z")).put("end", ts("2026-11-05T02:30:00Z")).put("type", 0x5659).put("stage", "light")))
            put("hrv", org.json.JSONArray().put(JSONObject().put("start", ts("2026-11-04T22:00:00Z")).put("end", ts("2026-11-05T02:30:00Z")).put("rmssd", 52.4)))
        }
        val rows = HuaweiWatchImport.daily(payload, emptyList(), ZoneOffset.UTC)
        assertEquals(1, rows.size)
        val row = rows.single()
        assertEquals(48, row.rhr)
        assertEquals(52, row.hrv)
        assertEquals(3.0, row.sleepH!!, 0.001)
        val raw = JSONObject(row.raw)
        assertEquals(90, raw.getInt("deep"))
        assertEquals(90, raw.getInt("rem"))
        assertEquals(30, raw.getInt("nap"))
        // the awake block after the last sleep minute is the tail of the night, not a wake-up in the middle of it
        assertTrue(!raw.has("wkN"))
        assertEquals("huawei-watch", raw.getString("source"))
    }

    @Test fun manualDailyValuesAreNeverOverwritten() {
        val old = DailyEntity(
            dateIso = "2026-11-05",
            rhr = 55,
            hrv = 61,
            sleepH = 7.25,
            leg = 2,
            mood = 1,
            raw = """{"source":"manual","sleep":7.25}""",
        )
        val payload = JSONObject().put("days", org.json.JSONArray().put(JSONObject().put("day", "2026-11-05").put("rhrLast", 45)))
            .put("hrv", org.json.JSONArray().put(JSONObject().put("end", ts("2026-11-05T02:30:00Z")).put("rmssd", 40.0)))
        val row = HuaweiWatchImport.daily(payload, listOf(old), ZoneOffset.UTC).single()
        assertEquals(55, row.rhr)
        assertEquals(61, row.hrv)
        assertEquals(7.25, row.sleepH!!, 0.001)
        assertEquals(2, row.leg)
        assertEquals(1, row.mood)
        assertEquals(7.25, JSONObject(row.raw).getDouble("sleep"), 0.001)
    }
    @Test fun importsSleepHeartRateFromDedicatedSleepWindowRows() {
        val payload = JSONObject()
            .put("sleepHr", org.json.JSONArray().put(JSONObject()
                .put("day", "2026-11-05").put("avg", 49.6).put("n", 35)))
        val row = HuaweiWatchImport.daily(payload, emptyList(), ZoneOffset.UTC).single()
        assertEquals(50, JSONObject(row.raw).getDouble("shr").toInt())
        assertEquals("watch-sync", JSONObject(row.raw).getString("huaweiHr_shr"))
    }

    @Test fun selectsLongestMainSleepPerWakeDateInsteadOfSummingFragments() {
        val payload = JSONObject().put("sleep", org.json.JSONArray()
            // Main night: 5h20m
            .put(JSONObject().put("start", ts("2026-11-04T22:00:00Z")).put("end", ts("2026-11-05T03:20:00Z")).put("type", 0).put("stage", "light"))
            // Separate early-evening fragment on same wake date; legacy keeps it out of main-night total.
            .put(JSONObject().put("start", ts("2026-11-04T18:00:00Z")).put("end", ts("2026-11-04T20:00:00Z")).put("type", 0).put("stage", "light")))
        val row = HuaweiWatchImport.daily(payload, emptyList(), ZoneOffset.UTC).single { it.dateIso == "2026-11-05" }
        assertEquals(5.3, row.sleepH!!, 0.001) // legacy stores hours rounded to 0.1
    }

    @Test fun dailyAverageRestingHrMatchesLegacyWatchMapping() {
        val payload = JSONObject().put("days", org.json.JSONArray().put(JSONObject()
            .put("day", "2026-11-05").put("rhrLast", 48).put("rhrAvg", 52.7).put("rhrN", 12)))
        val row = HuaweiWatchImport.daily(payload, emptyList(), ZoneOffset.UTC).single()
        assertEquals(53, row.rhr) // legacy rounds the daily average (Math.round), it does not truncate
    }


    // ---- scenarios below are checked against the legacy hwSleepNights output (same synthetic input in Node) ----
    private val wib = ZoneOffset.ofHours(7)
    private fun l(value: String) = OffsetDateTime.parse(value + "+07:00").toEpochSecond()
    private fun seg(a: String, b: String, stage: String, type: Int = 0) =
        JSONObject().put("start", l(a)).put("end", l(b)).put("type", type).put("stage", stage)
    private fun sleepPayload(vararg segs: JSONObject) = JSONObject().put("sleep", org.json.JSONArray().apply { segs.forEach { put(it) } })
    private val nightA = arrayOf(
        seg("2026-11-05T20:37:00", "2026-11-05T20:41:00", "light"),
        seg("2026-11-05T21:10:00", "2026-11-05T21:18:00", "light"),
        seg("2026-11-05T22:20:00", "2026-11-06T00:00:00", "light"),
        seg("2026-11-06T00:00:00", "2026-11-06T01:30:00", "deep"),
        seg("2026-11-06T01:30:00", "2026-11-06T03:00:00", "rem"),
        seg("2026-11-06T03:00:00", "2026-11-06T03:12:00", "awake"),
        seg("2026-11-06T03:12:00", "2026-11-06T05:00:00", "light"),
        seg("2026-11-06T05:00:00", "2026-11-06T06:10:00", "deep"),
        seg("2026-11-06T06:25:00", "2026-11-06T06:29:00", "light"),
    )

    @Test fun eveningFragmentsDoNotMoveBedTimeEarlier() {
        val row = HuaweiWatchImport.daily(sleepPayload(*nightA), emptyList(), wib).single { it.dateIso == "2026-11-06" }
        val raw = JSONObject(row.raw)
        assertEquals("22:20", raw.getString("bed"))
        assertEquals("06:10", raw.getString("wake"))
        assertEquals(160, raw.getInt("deep")); assertEquals(90, raw.getInt("rem")); assertEquals(208, raw.getInt("light"))
        assertEquals(7.6, row.sleepH!!, 0.001)
        assertEquals(1, raw.getInt("wkN"))
        val wks = raw.getJSONArray("wks")
        assertEquals(1, wks.length()); assertEquals(12, wks.getJSONObject(0).getInt("m"))
        // the wake-up time must not be stored in wkAt (that field means "awake from" in the readiness engine)
        assertTrue(!raw.has("wkAt"))
    }

    @Test fun workoutWindowIsCutOutOfSleep() {
        val payload = sleepPayload(*nightA, seg("2026-11-06T05:43:00", "2026-11-06T06:43:00", "light"))
            .put("workouts", org.json.JSONArray().put(JSONObject().put("start", l("2026-11-06T05:43:00")).put("end", l("2026-11-06T06:43:00")).put("duration", 3600)))
        val row = HuaweiWatchImport.daily(payload, emptyList(), wib).single { it.dateIso == "2026-11-06" }
        val raw = JSONObject(row.raw)
        assertEquals("05:41", raw.getString("wake"))
        assertEquals(131, raw.getInt("deep"))
        assertEquals(7.2, row.sleepH!!, 0.001)
    }

    @Test fun noDataGapInsideTheNightIsNotCountedAsAwake() {
        val payload = sleepPayload(
            seg("2026-11-05T23:00:00", "2026-11-06T01:00:00", "light"),
            seg("2026-11-06T01:00:00", "2026-11-06T02:00:00", "deep"),
            seg("2026-11-06T02:25:00", "2026-11-06T05:00:00", "rem"),
            seg("2026-11-06T05:00:00", "2026-11-06T06:30:00", "light"),
            seg("2026-11-06T13:00:00", "2026-11-06T13:40:00", "light", 0x5659),
        )
        val row = HuaweiWatchImport.daily(payload, emptyList(), wib).single { it.dateIso == "2026-11-06" }
        val raw = JSONObject(row.raw)
        assertTrue(!raw.has("wkN"))
        val gap = raw.getJSONArray("wks").getJSONObject(0)
        assertEquals(25, gap.getInt("m")); assertEquals(1, gap.getInt("g"))
        assertEquals(40, raw.getInt("nap"))
        assertEquals(7.1, row.sleepH!!, 0.001)
    }

    @Test fun asleepAgainSessionCountsTowardTotalSleep() {
        val payload = sleepPayload(
            seg("2026-11-05T21:30:00", "2026-11-05T23:10:00", "light"),
            seg("2026-11-06T00:30:00", "2026-11-06T06:00:00", "light"),
        )
        val row = HuaweiWatchImport.daily(payload, emptyList(), wib).single { it.dateIso == "2026-11-06" }
        val raw = JSONObject(row.raw)
        assertEquals("00:30", raw.getString("bed"))
        assertEquals(100, raw.getJSONArray("ext").getJSONObject(0).getInt("m"))
        assertEquals(7.2, row.sleepH!!, 0.001)
    }

    @Test fun hrvTakesTheReadingThatEndedLastAndRounds() {
        val payload = JSONObject().put("hrv", org.json.JSONArray()
            .put(JSONObject().put("start", l("2026-11-06T00:00:00")).put("end", l("2026-11-06T06:00:00")).put("rmssd", 52.6))
            .put(JSONObject().put("start", l("2026-11-05T22:00:00")).put("end", l("2026-11-06T03:00:00")).put("rmssd", 70.0)))
        val row = HuaweiWatchImport.daily(payload, emptyList(), wib).single()
        assertEquals(53, row.hrv)
    }

    @Test fun manualRestingHrIsNotMarkedAsWatchOwnedAndSurvivesRepeatedSyncs() {
        val old = DailyEntity("2026-11-05", rhr = 55, raw = "{}")
        val payload = JSONObject().put("days", org.json.JSONArray().put(JSONObject().put("day", "2026-11-05").put("rhrAvg", 45.0).put("rhrN", 5)))
        val first = HuaweiWatchImport.daily(payload, listOf(old), wib).single()
        assertEquals(55, first.rhr)
        assertEquals("", JSONObject(first.raw).optString("huaweiHr_rhr"))
        assertEquals(55, HuaweiWatchImport.daily(payload, listOf(first), wib).single().rhr)
    }

    @Test fun watchOwnedSleepIsRefreshedButManualSleepIsKept() {
        val first = HuaweiWatchImport.daily(sleepPayload(*nightA), emptyList(), wib).single { it.dateIso == "2026-11-06" }
        val fixed = sleepPayload(*nightA, seg("2026-11-06T05:43:00", "2026-11-06T06:43:00", "light"))
            .put("workouts", org.json.JSONArray().put(JSONObject().put("start", l("2026-11-06T05:43:00")).put("end", l("2026-11-06T06:43:00")).put("duration", 3600)))
        val refreshed = HuaweiWatchImport.daily(fixed, listOf(first), wib).single { it.dateIso == "2026-11-06" }
        assertEquals(7.2, refreshed.sleepH!!, 0.001)
        val manual = DailyEntity("2026-11-06", sleepH = 6.0, raw = """{"sleep":6}""")
        assertEquals(6.0, HuaweiWatchImport.daily(sleepPayload(*nightA), listOf(manual), wib).single { it.dateIso == "2026-11-06" }.sleepH!!, 0.001)
    }
}
