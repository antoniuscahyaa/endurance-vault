package com.endurancevault.app

import com.endurancevault.app.domain.RouteVideoColors
import com.endurancevault.app.domain.RouteVideoPrefs
import com.endurancevault.app.domain.RouteVideoTrack
import com.endurancevault.app.domain.Segment
import com.endurancevault.app.domain.SegmentVideoPlan
import com.endurancevault.app.domain.allAnchors
import com.endurancevault.app.domain.withSegmentPreset
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SegmentVideoTest {
    /** Lari lurus [km] km ke timur, 1 sampel per 3 detik, elevasi naik 0 sampai 300 m merata. */
    private fun track(km: Double = 30.0, n: Int = 1000): RouteVideoTrack {
        val dist = DoubleArray(n) { it * km * 1000.0 / (n - 1) }
        return RouteVideoTrack(
            lat = DoubleArray(n) { -7.0 }, lon = DoubleArray(n) { 107.0 + dist[it] / 111_320.0 },
            dist = dist, sec = IntArray(n) { it * 3 },
            hr = IntArray(n) { 150 }, cad = IntArray(n) { 170 },
            ele = DoubleArray(n) { 2000.0 + 300.0 * it / (n - 1) }, gradeRaw = DoubleArray(n) { Double.NaN },
            title = "Trail", dateText = "10 Nov 2026",
        )
    }

    private fun seg(k: Double, d: Double, label: String? = null, gain: Int = 100, loss: Int = 50) =
        Segment(k = k, d = d, min = 60.0, pace = 7.0, hr = 150, gain = gain, loss = loss, cad = 170, name = "x", type = null, label = label)

    @Test fun userSegmentsBecomeSegmentsWithPalette() {
        val t = track()
        val s = SegmentVideoPlan.build(t, listOf(seg(10.0, 10.0, "Dingklik"), seg(20.0, 10.0, "Keciri"), seg(30.0, 10.0, "Finish")))
        assertEquals(3, s.size)
        assertEquals(0.0, s[0].startM, 1e-6)
        assertEquals(10_000.0, s[0].endM, 1e-6)
        assertEquals(10_000.0, s[1].startM, 1e-6)
        assertEquals(t.totalM, s.last().endM, 1e-6)
        assertEquals("1. Dingklik", s[0].title)
        assertEquals(100, s[0].gain)
        assertEquals(50, s[0].loss)
        assertEquals(SegmentVideoPlan.PALETTE[0], s[0].color)
        assertEquals(SegmentVideoPlan.PALETTE[2], s[2].color)
    }

    @Test fun smallTailMergesAndBigTailBecomesExtraSegment() {
        val t = track(30.0)
        // sisa 0,3 km (1%) menyatu ke segmen terakhir
        val a = SegmentVideoPlan.build(t, listOf(seg(15.0, 15.0), seg(29.7, 14.7)))
        assertEquals(2, a.size)
        assertEquals(t.totalM, a.last().endM, 1e-6)
        // sisa 10 km menjadi segmen tambahan
        val b = SegmentVideoPlan.build(t, listOf(seg(10.0, 10.0), seg(20.0, 10.0)))
        assertEquals(3, b.size)
        assertEquals("Segmen 3", b.last().title)
        assertEquals(t.totalM, b.last().endM, 1e-6)
    }

    @Test fun withoutUsableSegmentsRouteSplitsEvenly() {
        val t = track(30.0)
        val none = SegmentVideoPlan.build(t, emptyList())
        assertEquals(4, none.size) // 30 km / 8 km = 3,75 -> 4
        assertEquals(t.totalM, none.last().endM, 1e-6)
        assertTrue(none.zipWithNext().all { (a, b) -> kotlin.math.abs(a.endM - b.startM) < 1e-6 })
        // satu segmen saja tidak berguna: dibagi otomatis juga
        assertEquals(4, SegmentVideoPlan.build(t, listOf(seg(30.0, 30.0))).size)
        // rute pendek tetap minimal 3 segmen
        assertEquals(3, SegmentVideoPlan.build(track(5.0), emptyList()).size)
    }

    @Test fun climbAndGradeComeFromElevationWhenNotUserSegments() {
        val t = track(30.0)
        val s = SegmentVideoPlan.autoSplit(t)
        // 300 m naik merata di 30 km = gradien 1%
        assertEquals(1.0, s[0].avgGrade!!, 0.05)
        assertTrue(kotlin.math.abs(s.sumOf { it.gain } - 300) <= 4)
    }

    @Test fun colorsFollowSegmentsAndBoundariesBecomeAnchors() {
        val t = track(30.0)
        t.segments = SegmentVideoPlan.build(t, listOf(seg(10.0, 10.0), seg(20.0, 10.0), seg(30.0, 10.0)))
        val fr = floatArrayOf(0.05f, 0.5f, 0.95f)
        val c = RouteVideoColors.colors(t, "segmen", 0xFFC6F432.toInt(), fr)
        assertEquals(SegmentVideoPlan.PALETTE[0], c[0])
        assertEquals(SegmentVideoPlan.PALETTE[1], c[1])
        assertEquals(SegmentVideoPlan.PALETTE[2], c[2])
        val marks = t.allAnchors().filter { it.kind == "seg" }
        assertEquals(2, marks.size)
        assertEquals(1, marks[0].km)
        assertEquals(10.0, marks[0].value, 1e-6)
        assertEquals("WS1", SegmentVideoPlan.boundaryLabel(1))
        // tanpa segmen, mode segmen jatuh ke satu warna
        val plain = track(30.0)
        assertEquals(0xFFC6F432.toInt(), RouteVideoColors.colors(plain, "segmen", 0xFFC6F432.toInt(), fr)[0])
    }

    @Test fun presetEnablesSegmentModeAndRoundTrips() {
        val p = RouteVideoPrefs().withSegmentPreset()
        assertEquals("segmen", p.lineMode)
        assertEquals("chase", p.cameraMode)
        assertTrue(p.layout.showChart)
        assertEquals("profil", p.layout.chartKind)
        assertTrue(p.showsAnchor("seg"))
        assertTrue(!RouteVideoPrefs().showsAnchor("seg"))
        assertEquals("segmen", RouteVideoPrefs.fromJson(p.toJson()).lineMode)
    }

    @Test fun textHelpersUseIndonesianDecimals() {
        val t = track(30.0)
        val s = SegmentVideoPlan.build(t, listOf(seg(10.9, 10.9, "Dingklik", 611, 358), seg(30.0, 19.1)))
        assertEquals("0,0–10,9 km", SegmentVideoPlan.rangeText(s[0]))
        assertTrue(SegmentVideoPlan.climbText(s[0]).startsWith("+611 m / −358 m · "))
        assertEquals("10,9 km", SegmentVideoPlan.boundaryKm(s, 1))
    }
}
