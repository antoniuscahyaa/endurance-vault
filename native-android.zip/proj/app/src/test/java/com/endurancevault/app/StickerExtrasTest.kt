package com.endurancevault.app

import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.domain.ActDetail
import com.endurancevault.app.domain.ActWeather
import com.endurancevault.app.domain.LoadSnap
import com.endurancevault.app.domain.PersonalBest
import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.domain.RaceSnap
import com.endurancevault.app.domain.Split
import com.endurancevault.app.domain.StickerExtras
import com.endurancevault.app.domain.StickerExtrasCalc
import com.endurancevault.app.domain.StickerModel
import com.endurancevault.app.domain.StickerPrefs
import com.endurancevault.app.domain.Stickers
import com.endurancevault.app.domain.StreakStats
import com.endurancevault.app.domain.YearStats
import com.endurancevault.app.domain.Zones
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class StickerExtrasTest {
    private val zc = Zones.cuts(PlanSettings(thr = "164–172"))

    private fun split(k: Double, pace: Double, hr: Int? = null, partial: Boolean = false) = Split(k, pace, hr, 0, 0, null, null, partial)

    private fun detail(
        km: Double = 5.0, splits: List<Split> = emptyList(), route: List<Pair<Int, Int>> = emptyList(),
        profile: List<Pair<Double, Double>> = emptyList(), paceSeries: List<Pair<Double, Double>> = emptyList(),
        hist: Map<Int, Double> = emptyMap(), weather: ActWeather? = null, date: String = "2026-11-14",
    ) = ActDetail(
        date = date, startTime = "06:00", name = "Run", bike = false, kind = null, km = km, movingMin = km * 6, elapsedMin = km * 6 + 1,
        gain = 40, loss = 38, hr = 150, hrMax = 170, cad = null, gapPace = null, splits = splits, segments = emptyList(),
        route = route, routeW = 1000, routeH = 600, profile = profile, paceSeries = paceSeries, hrSeries = emptyList(),
        cadSeries = emptyList(), hrHist = hist, weather = weather,
    )

    private fun entity(id: Long = 1, date: String = "2026-11-14", km: Double = 5.0, sec: Int = 1800, type: String = "run", gain: Int? = 40) =
        ActivityEntity(id = id, dateIso = date, km = km, durationSec = sec, avgHr = 150, gain = gain, type = type, name = "Run")

    private fun model(d: ActDetail?, extras: StickerExtras? = null, e: ActivityEntity = entity(), hist: Map<Int, Double> = emptyMap()): StickerModel =
        Stickers.forActivity(e, d, hist, zc, null, null, extras)!!

    private val paces = listOf(6.0, 5.5, 5.6, 5.4, 5.5, 5.7)

    @Test fun jendelaTercepatDanBestEffort() {
        val d = detail(km = 6.0, splits = paces.mapIndexed { i, p -> split(i + 1.0, p) })
        assertEquals(5.4, StickerExtrasCalc.windowBest(d, 1, 1.0)!!, 1e-9)
        assertEquals(27.7, StickerExtrasCalc.windowBest(d, 5, 5.0)!!, 1e-9)
        assertNull(StickerExtrasCalc.windowBest(d, 10, 10.0))
        assertEquals(listOf("1 km", "5 km"), StickerExtrasCalc.bestEfforts(d).map { it.first })
    }

    @Test fun splitTidakWajarDilewati() {
        val d = detail(km = 3.0, splits = listOf(split(1.0, 6.0), split(2.0, 0.5), split(3.0, 5.0)))
        assertEquals(5.0, StickerExtrasCalc.windowBest(d, 1, 1.0)!!, 1e-9)
        assertNull(StickerExtrasCalc.windowBest(d, 3, 3.0))
    }

    @Test fun bandingPrMemilihJarakTerpanjangDanMengenaliPr() {
        val d = detail(km = 6.0, splits = paces.mapIndexed { i, p -> split(i + 1.0, p) })
        val own = listOf(PersonalBest("1 km", 1.0, 5.4, 7, "2026-11-14"), PersonalBest("5K", 5.0, 27.7, 7, "2026-11-14"))
        val c = StickerExtrasCalc.prCompare(d, own, 7)!!
        assertEquals("5K", c.label); assertTrue(c.isPr)
        val faster = listOf(PersonalBest("5K", 5.0, 26.0, 9, "2026-10-01"))
        val c2 = StickerExtrasCalc.prCompare(d, faster, 7)!!
        assertFalse(c2.isPr); assertEquals(27.7, c2.todayMin, 1e-9); assertEquals(26.0, c2.prMin, 1e-9)
        assertNull(StickerExtrasCalc.prCompare(d, emptyList(), 7))
    }

    @Test fun mafMenghitungZonaDanDrift() {
        val sp = listOf(split(1.0, 6.0, 140), split(2.0, 6.0, 140), split(3.0, 6.0, 150), split(4.0, 6.0, 150))
        val d = detail(km = 4.0, splits = sp, hist = mapOf(130 to 600.0, 150 to 300.0, 170 to 100.0))
        val m = model(d, hist = d.hrHist)
        val f = m.maf!!
        assertEquals(150, f.hr)
        assertEquals(60.0, f.z1, 1e-6); assertEquals(90.0, f.z12, 1e-6); assertEquals(10.0, f.z45, 1e-6)
        assertEquals((1 - 140.0 / 150) * 100, f.drift!!, 1e-6)
        assertEquals(zc.lo[2] - 1, f.easy)
        assertNull(m.graphWhy("maf"))
    }

    @Test fun mafTanpaDataHrTidakTersedia() {
        val m = model(detail())
        assertNull(m.maf)
        assertNotNull(m.graphWhy("maf"))
    }

    @Test fun cuacaMenjadiAngka() {
        val w = ActWeather(tempC = 24.4, feelsLikeC = 27.0, humidityPct = 78, windKmh = 8.0, rainMm = 0.0)
        val m = model(detail(weather = w))
        assertEquals(listOf("Suhu", "Terasa", "Lembap", "Angin"), m.wxNums.map { it.label })
        assertEquals("24", m.wxNums[0].value); assertEquals("°C", m.wxNums[0].unit)
        assertNull(m.graphWhy("cuaca"))
        assertNotNull(model(detail()).graphWhy("cuaca"))
    }

    @Test fun vertButuhElevasiDanProfil() {
        assertNotNull(model(detail()).graphWhy("vert"))
        val m = model(detail(profile = listOf(0.0 to 10.0, 2.0 to 40.0, 5.0 to 20.0)))
        assertTrue(m.hasVert); assertNull(m.graphWhy("vert"))
    }

    @Test fun warnaRuteDinormalkan() {
        val route = (0..9).map { it * 100 to (if (it < 5) 0 else (it - 4) * 50) }
        val d = detail(route = route, paceSeries = listOf(0.0 to 6.0, 1.0 to 5.0, 2.0 to 5.5, 3.0 to 7.0, 4.0 to 6.5, 5.0 to 6.0))
        val m = model(d)
        val n = m.routeNorm("pace")!!
        assertEquals(route.size, n.size)
        assertTrue(n.all { it in 0.0..1.0 })
        assertTrue(n.last() >= n.first() || n.any { it > .5 })
        assertNotNull(m.routeNorm("hr")) // hr kosong jatuh ke pace
        assertNull(model(detail(route = route)).routeNorm("pace"))
    }

    @Test fun ruteSerupaMembandingkanPace() {
        val pts = listOf(0 to 0, 100 to 0, 200 to 0, 300 to 100, 400 to 200, 500 to 300, 600 to 300, 700 to 300)
        val a1 = entity(id = 1, date = "2026-11-01", km = 5.0, sec = 1800)
        val a2 = entity(id = 2, date = "2026-11-14", km = 5.0, sec = 1740)
        val lain = entity(id = 3, date = "2026-11-10", km = 12.0, sec = 4000)
        val det = mapOf(1L to detail(route = pts), 2L to detail(route = pts), 3L to detail(km = 12.0, route = listOf(0 to 0, 900 to 900, 0 to 900, 900 to 0, 450 to 450, 100 to 800, 800 to 100, 300 to 300)))
        val rc = StickerExtrasCalc.sameRoute(a2, listOf(a1, a2, lain), det)!!
        assertEquals(2, rc.points.size)
        assertEquals(-0.2, rc.deltaMin, 1e-9)
        assertTrue(rc.points.last().current)
        assertNull(StickerExtrasCalc.sameRoute(lain, listOf(a1, a2, lain), det))
    }

    @Test fun tahunMenjumlahSampaiTanggalSesi() {
        val acts = listOf(
            entity(1, "2026-01-03", 5.0, gain = 10), entity(2, "2026-11-02", 10.0, gain = 100),
            entity(3, "2026-11-02", 30.0, type = "bike"), entity(4, "2026-11-20", 8.0), entity(5, "2025-12-31", 9.0),
        )
        val y = StickerExtrasCalc.year(acts, LocalDate.of(2026, 11, 14))!!
        assertEquals(15.0, y.km, 1e-9); assertEquals(110, y.gain); assertEquals(2, y.activeDays); assertEquals(2, y.sessions)
        assertEquals(365, y.cells.size); assertEquals(3, y.offset)
        assertEquals(5.0, y.cells[2], 1e-9)
        assertEquals(0.0, y.cells[317], 1e-9); assertEquals(-1.0, y.cells[318], 1e-9)
        assertNull(StickerExtrasCalc.year(acts, LocalDate.of(2024, 5, 1)))
    }

    @Test fun streakHariPekanDanRekor() {
        val days = listOf("2026-11-12", "2026-11-13", "2026-11-14", "2026-11-09", "2026-11-03") + (20..25).map { "2026-10-$it" }
        val acts = days.mapIndexed { i, d -> entity(i + 1L, d) } + entity(99, "2026-11-11", type = "bike")
        val st = StickerExtrasCalc.streak(acts, LocalDate.of(2026, 11, 14))!!
        assertEquals(3, st.days); assertEquals(2, st.weeks); assertEquals(6, st.bestDays)
        assertEquals(listOf("M", "S", "S", "R", "K", "J", "S"), st.last7.map { it.first })
        assertEquals(listOf(false, true, false, false, true, true, true), st.last7.map { it.second })
        assertEquals(0, StickerExtrasCalc.streak(acts, LocalDate.of(2026, 11, 15))!!.days)
    }

    @Test fun idBaruDanKategoriTahun() {
        val ex = StickerExtras(
            race = RaceSnap("Merbabu Sky Race 40k", LocalDate.of(2027, 5, 1), 40.0),
            load = LoadSnap(1.18, "Beban optimal", listOf(1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0)),
            year = YearStats(2026, 100.0, 1000, 20, 25, List(365) { 0.0 }, 3),
            streak = StreakStats(5, 3, 9, List(7) { "S" to true }),
        )
        val m = model(detail(), ex)
        val ids = Stickers.allIds(m, StickerPrefs())
        listOf("hitung-mundur", "training-load", "tahun", "streak").forEach { assertTrue(it, it in ids) }
        assertEquals("week", Stickers.scopeOf("hitung-mundur")); assertEquals("week", Stickers.scopeOf("training-load"))
        assertEquals("year", Stickers.scopeOf("tahun")); assertEquals("year", Stickers.scopeOf("streak"))
        assertEquals("day", Stickers.scopeOf("maf")); assertEquals("day", Stickers.scopeOf("vs-pr"))
        assertTrue(Stickers.SCOPES.any { it.first == "year" })
    }

    @Test fun lombaYangSudahLewatTidakTampil() {
        val ex = StickerExtras(race = RaceSnap("Lomba", LocalDate.of(2026, 11, 1), 10.0))
        assertNotNull(model(detail(), ex).graphWhy("hitung-mundur"))
        assertNotNull(model(detail(), null).graphWhy("hitung-mundur"))
    }

    @Test fun warnaRutePengaturanBolakBalik() {
        val p = StickerPrefs(mapColor = "hr")
        assertEquals("hr", StickerPrefs.fromJson(p.toJson()).mapColor)
        assertEquals("pace", StickerPrefs(mapColor = "xx").sanitized().mapColor)
    }
}
