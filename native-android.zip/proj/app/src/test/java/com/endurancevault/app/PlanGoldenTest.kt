package com.endurancevault.app

import com.endurancevault.app.domain.PbAk
import com.endurancevault.app.domain.PbConv
import com.endurancevault.app.domain.PbPost
import com.endurancevault.app.domain.PDay
import com.endurancevault.app.domain.PlanEngine
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.domain.StrengthBlock
import com.endurancevault.app.domain.TrainingMethod
import org.json.JSONArray
import java.time.LocalDate
import org.json.JSONObject
import org.junit.Assert.fail
import org.junit.Test

/**
 * Mencocokkan keluaran PlanEngine dengan data acuan yang dihasilkan plan() versi web
 * (tools/golden-plan.mjs; gSmooth mati kecuali skenario *-gs). Mencakup metode latihan (pyramidal/polarized/MAF), sesi quality kedua, dan
 * strength/ankle/upper. Tiap ketidakcocokan menyebut skenario, minggu, hari, dan field.
 */
class PlanGoldenTest {
    private val today = LocalDate.of(2026, 11, 5)

    private fun settings(j: JSONObject): PlanSettings {
        fun str(k: String) = if (j.has(k) && !j.isNull(k)) j.get(k).toString() else ""
        fun dbl(k: String): Double? = str(k).takeIf { it.isNotBlank() }?.toDoubleOrNull()
        fun date(k: String): LocalDate? = str(k).takeIf { it.isNotBlank() }?.let { LocalDate.parse(it.take(10)) }
        return PlanSettings(
            name = str("name"), rtype = str("rtype"), start = date("start")!!, race = date("race"),
            raceKm = dbl("raceKm"), raceGain = dbl("raceGain"), goalT = str("goalT"),
            base = dbl("base")!!, peak = dbl("peak")!!, days = j.getInt("days"), rest = j.getInt("rest"),
            rest2 = j.getInt("rest2"), longDay = j.getInt("longDay"), hr = j.getInt("hr"), thr = str("thr"),
            pace = str("pace"), hrMax = str("hrmax").toIntOrNull(), bspd = dbl("bspd") ?: 20.0,
            pbCycle = str("pbCycle"), pbFocus = str("pbFocus"),
            pbPost = j.optJSONObject("pbPost")?.let { PbPost(it.getDouble("rec"), it.getDouble("lvl")) },
            pbConv = j.optJSONObject("pbConv")?.let { PbConv(it.getInt("wk"), it.getDouble("b0"), it.getDouble("p0")) },
            pbAk = j.optJSONObject("pbAk")?.let { PbAk(LocalDate.parse(it.getString("wk")), it.getDouble("km")) },
            evOn = j.optBoolean("evOn", false), evDate = date("evDate"), evKm = dbl("evKm") ?: 0.0, evGain = dbl("evGain") ?: 0.0,
            zm = str("zm").ifEmpty { "lthr" }, lthr = dbl("lthr"), rhr = dbl("rhr"),
            method = str("method").ifEmpty { "default" }, qSess = str("qSess").ifEmpty { "1" },
            sLeg = j.optBoolean("sLeg", true), sAnk = j.optBoolean("sAnk", true), sUp = str("sUp").ifEmpty { "auto" },
            gSmooth = j.optBoolean("gSmooth", true), gBase = dbl("gBase") ?: 0.0,
        )
    }

    /** Judul versi web (bernama daerah) -> judul native generik. */
    private fun legacyTitle(t: String): String = when (t) {
        "Uji kebugaran · loop 6,3 km" -> "Uji kebugaran · HR tetap"
        "Turunan Panjang–Kebonsari" -> "Turunan"
        else -> t.replace("Ambarawa (jalan)", "Jalan")
    }

    /** Blok strength dipadatkan oleh golden-plan.mjs: [judul, menit, indeks catatan, baris digabung '|']. */
    private fun checkBlock(tag: String, f: String, e: JSONArray?, notes: JSONArray, a: StrengthBlock?, errs: MutableList<String>) {
        if (e == null) { if (a != null) errs.add("$tag.$f web=tidak ada kotlin=${a.title}"); return }
        if (a == null) { errs.add("$tag.$f web=${e.getString(0)} kotlin=tidak ada"); return }
        fun eq(sub: String, exp: Any?, act: Any?) { if (exp != act) errs.add("$tag.$f.$sub\n   web   : $exp\n   kotlin: $act") }
        eq("title", e.getString(0), a.title)
        eq("mins", e.getInt(1), a.mins)
        eq("note", notes.getString(e.getInt(2)), a.note)
        eq("lines", e.getString(3), a.lines.joinToString("|"))
    }

    /**
     * [structural] true: hanya kerangka hari yang dibandingkan (tanggal, jenis, peran, grup). Dipakai untuk skenario trail
     * (rtype "ultra"): versi web masih memakai loop Ungaran, sedangkan versi native sengaja memakai target jarak + D+
     * (lihat TrailTargetTest), sehingga judul, jarak, D+, dan teks sesi trail memang berbeda.
     */
    private fun checkDay(tag: String, e: JSONObject, a: PDay, notes: JSONArray, errs: MutableList<String>, structural: Boolean = false) {
        fun eq(f: String, exp: Any?, act: Any?) { if (exp != act) errs.add("$tag.$f\n   web   : $exp\n   kotlin: $act") }
        eq("date", e.getString("date"), a.date.toString())
        eq("kind", e.getString("kind"), a.kind)
        eq("role", e.optString("role", "").ifEmpty { null }, a.role)
        eq("grp", e.getString("grp"), a.grp)
        if (structural) return
        // Versi web masih memakai nama daerah (Ambarawa, Panjang–Kebonsari) dan loop 6,3 km. Versi native sengaja generik:
        // judul dipetakan di bawah, dan teks detail sesi uji kebugaran + turunan memang berbeda (lihat PlanGenericLabelsTest).
        val webTitle = e.getString("title")
        val textChanged = webTitle == "Uji kebugaran · loop 6,3 km" || webTitle == "Turunan Panjang–Kebonsari"
        eq("title", legacyTitle(webTitle), a.title)
        if (kotlin.math.abs(e.getDouble("km") - a.km) > 0.051) errs.add("$tag.km web=${e.getDouble("km")} kotlin=${a.km}")
        if (!textChanged) eq("detail", e.getString("detail"), a.detail)
        eq("gain", if (e.has("gain")) e.getInt("gain") else null, a.gain)
        eq("b2b", if (e.has("b2b")) e.getInt("b2b") else null, a.b2b)
        eq("qk", e.optString("qk", "").ifEmpty { null }, a.qk)
        if (e.has("qMin")) { if (a.qMin == null || kotlin.math.abs(e.getDouble("qMin") - a.qMin!!) > 0.01) errs.add("$tag.qMin web=${e.getDouble("qMin")} kotlin=${a.qMin}") }
        else if (a.qMin != null) errs.add("$tag.qMin web=null kotlin=${a.qMin}")
        eq("sim", e.has("sim"), a.sim)
        eq("bench", e.has("bench"), a.bench)
        eq("xtra", if (e.has("xtra")) e.getInt("xtra") else null, a.xtra)
        eq("altMins", if (e.has("altMins")) e.getInt("altMins") else null, a.altMins)
        eq("q2", if (e.has("q2")) e.getInt("q2") else null, a.q2)
        eq("tm", e.optString("tm", "").ifEmpty { null }, a.tm)
        val em = e.optJSONObject("mod")
        eq("mod",
            em?.let { "${it.getInt("min")} ${it.getJSONArray("band").getInt(0)}-${it.getJSONArray("band").getInt(1)} z${it.getInt("z")}" },
            a.mod?.let { "${it.min} ${it.band[0]}-${it.band[1]} z${it.z}" })
        checkBlock(tag, "str", e.optJSONArray("str"), notes, a.str, errs)
        checkBlock(tag, "ank", e.optJSONArray("ank"), notes, a.ank, errs)
        checkBlock(tag, "up", e.optJSONArray("up"), notes, a.up, errs)
    }

    @Test fun cocokDenganVersiWeb() {
        val text = javaClass.getResourceAsStream("/golden/plan-golden.json")!!.bufferedReader().readText()
        val root = JSONObject(text)
        val errs = mutableListOf<String>()
        val notes = root.getJSONArray("__notes")
        root.keys().forEach { name ->
            if (name.startsWith("__")) return@forEach
            val sc = root.getJSONObject(name)
            val exp = sc.getJSONObject("result")
            val structural = sc.getJSONObject("settings").optString("rtype") == "ultra"
            val out = PlanEngine.plan(settings(sc.getJSONObject("settings")), today)
            if (exp.has("err")) {
                if (out !is PlanOutcome.Err) errs.add("[$name] seharusnya galat: ${exp.getString("err")}")
                else if (out.message != exp.getString("err")) errs.add("[$name] pesan galat\n   web   : ${exp.getString("err")}\n   kotlin: ${out.message}")
                return@forEach
            }
            if (out !is PlanOutcome.Ok) { errs.add("[$name] galat tak terduga: ${(out as PlanOutcome.Err).message}"); return@forEach }
            val ew = exp.getJSONArray("weeks")
            if (ew.length() != out.weeks.size) { errs.add("[$name] jumlah minggu web=${ew.length()} kotlin=${out.weeks.size}"); return@forEach }
            for (wi in 0 until ew.length()) {
                val e = ew.getJSONObject(wi); val a = out.weeks[wi]
                val wt = "[$name] minggu ${wi + 1}"
                if (e.getString("phase") != a.phase) errs.add("$wt phase web=${e.getString("phase")} kotlin=${a.phase}")
                if (e.getBoolean("cut") != a.cut) errs.add("$wt cut web=${e.getBoolean("cut")} kotlin=${a.cut}")
                if (e.getBoolean("rec") != a.rec) errs.add("$wt rec")
                if (e.getBoolean("race") != a.race) errs.add("$wt race")
                if (!structural && kotlin.math.abs(e.getDouble("km") - a.km) > 0.051) errs.add("$wt km web=${e.getDouble("km")} kotlin=${a.km}")
                val ed = e.getJSONArray("days")
                if (ed.length() != a.days.size) { errs.add("$wt jumlah hari web=${ed.length()} kotlin=${a.days.size}"); continue }
                for (di in 0 until ed.length()) checkDay("$wt hari ${di + 1}", ed.getJSONObject(di), a.days[di], notes, errs, structural)
            }
        }
        if (errs.isNotEmpty()) {
            // Kelompokkan agar satu pola yang berulang tidak menutupi pola lain.
            val groups = errs.groupBy { e ->
                e.lineSequence().first().replace(Regex("minggu \\d+"), "minggu N").replace(Regex("hari \\d+"), "hari N")
            }
            val msg = StringBuilder("${errs.size} ketidakcocokan dengan versi web, ${groups.size} pola:\n")
            groups.entries.take(40).forEach { (k, v) -> msg.append("\n(x${v.size}) contoh:\n").append(v.first()).append("\n") }
            fail(msg.toString())
        }
    }

    /** Saran distribusi intensitas per metode (tmAdvice di web). */
    @Test fun saranDistribusiCocokDenganVersiWeb() {
        val text = javaClass.getResourceAsStream("/golden/plan-golden.json")!!.bufferedReader().readText()
        val adv = JSONObject(text).getJSONArray("__advice")
        val errs = mutableListOf<String>()
        for (i in 0 until adv.length()) {
            val c = adv.getJSONObject(i)
            val sj = c.getJSONArray("secs")
            val secs = DoubleArray(5) { sj.getDouble(it) }
            val s = PlanSettings(method = c.getString("m"))
            val r = TrainingMethod.advice(secs, c.getInt("hrEasy"), s)
            val e = c.optJSONObject("r")
            val tag = "[advice ${c.getString("m")} #$i]"
            if (e == null) { if (r != null) errs.add("$tag web=null kotlin=${r.kind}"); continue }
            if (r == null) { errs.add("$tag web=${e.getString("k")} kotlin=null"); continue }
            if (e.getString("k") != r.kind) errs.add("$tag kind web=${e.getString("k")} kotlin=${r.kind}")
            if (e.getString("txt") != r.text) errs.add("$tag teks\n   web   : ${e.getString("txt")}\n   kotlin: ${r.text}")
        }
        if (errs.isNotEmpty()) fail(errs.joinToString("\n"))
    }
}
