package com.endurancevault.app.watch

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class LegacyWatchMigrationTest {
  @get:Rule val tmp = TemporaryFolder()

  @Test fun movesDatabaseAndSidecarFiles() {
    val dir = tmp.newFolder("SQLite")
    File(dir, "joyofit.db").writeText("main")
    File(dir, "joyofit.db-wal").writeText("wal")
    File(dir, "joyofit.db-shm").writeText("shm")

    assertTrue(LegacyWatchMigration.migrateDbFiles(dir))

    assertEquals("main", File(dir, "watch.db").readText())
    assertEquals("wal", File(dir, "watch.db-wal").readText())
    assertEquals("shm", File(dir, "watch.db-shm").readText())
    assertFalse(File(dir, "joyofit.db").exists())
    assertFalse(File(dir, "joyofit.db-wal").exists())
    assertFalse(File(dir, "joyofit.db-shm").exists())
  }

  @Test fun doesNothingWhenOldDatabaseIsMissing() {
    val dir = tmp.newFolder("SQLite")
    assertFalse(LegacyWatchMigration.migrateDbFiles(dir))
    assertFalse(File(dir, "watch.db").exists())
  }

  @Test fun neverOverwritesAnExistingNewDatabase() {
    val dir = tmp.newFolder("SQLite")
    File(dir, "joyofit.db").writeText("old")
    File(dir, "watch.db").writeText("new")

    assertFalse(LegacyWatchMigration.migrateDbFiles(dir))

    assertEquals("new", File(dir, "watch.db").readText())
    assertEquals("old", File(dir, "joyofit.db").readText())
  }

  @Test fun secondRunIsANoOp() {
    val dir = tmp.newFolder("SQLite")
    File(dir, "joyofit.db").writeText("main")
    assertTrue(LegacyWatchMigration.migrateDbFiles(dir))
    assertFalse(LegacyWatchMigration.migrateDbFiles(dir))
    assertEquals("main", File(dir, "watch.db").readText())
  }
}
