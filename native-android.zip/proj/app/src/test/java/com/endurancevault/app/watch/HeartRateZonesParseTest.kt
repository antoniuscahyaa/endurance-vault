package com.endurancevault.app.watch

import com.endurancevault.app.watch.HeartRateZonesCalc.Method
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class HeartRateZonesParseTest {
  @Test fun parsesLthrWithItsThreshold() {
    val c = HeartRateZonesSync.parseCustom("""{"method":"lthr","lower":[95,150,160,170,180],"maxHr":190,"restHr":50,"lthr":175}""")!!
    assertEquals(Method.LTHR, c.method)
    assertEquals(175, c.lthr)
    assertNull(c.error())
  }

  @Test fun oldMhrAndHrrJsonStillParses() {
    val m = HeartRateZonesSync.parseCustom("""{"method":"mhr","lower":[95,150,160,170,180],"maxHr":190,"restHr":50}""")!!
    assertEquals(Method.MHR, m.method)
    assertEquals(0, m.lthr)
    assertNull(m.error())
    assertEquals(Method.HRR, HeartRateZonesSync.parseCustom("""{"method":"hrr","lower":[100,120,140,150,170],"maxHr":190,"restHr":50}""")!!.method)
  }

  @Test fun lthrWithoutThresholdIsNotSendable() {
    val c = HeartRateZonesSync.parseCustom("""{"method":"lthr","lower":[95,150,160,170,180],"maxHr":190,"restHr":50}""")!!
    assertEquals("LTHR must be 100..219 bpm", c.error())
  }
}
