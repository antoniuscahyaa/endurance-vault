package com.endurancevault.app

import com.endurancevault.app.data.ExploreRouting
import com.endurancevault.app.domain.CourseStrategy.Pt
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExploreRoutingTest {
    // Garis lurus ke timur sepanjang ±1,1 km (0,01 derajat bujur di dekat ekuator), titik tiap ±11 m.
    private fun line(lat: Double) = (0..100).map { Pt(lat, 106.80 + it * 0.0001, null) }

    @Test fun resampleMenjagaUjungDanJarakKira2() {
        val v = ExploreRouting.resample(line(-6.2), 300.0)
        assertEquals(-6.2, v.first().lat, 0.0)
        assertEquals(106.81, v.last().lon, 1e-9)
        assertTrue(v.size in 4..6)
    }

    @Test fun shareNearPenuhBilaSamaDanNolBilaJauh() {
        assertEquals(1.0, ExploreRouting.shareNear(line(-6.2), line(-6.2), 25.0), 1e-9)
        assertEquals(0.0, ExploreRouting.shareNear(line(-6.2), line(-6.2010), 25.0), 1e-9)
    }
}
