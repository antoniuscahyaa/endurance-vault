package com.endurancevault.app

import com.endurancevault.app.domain.GreetingEngine
import com.endurancevault.app.ui.i18n.Translator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.BeforeClass
import org.junit.Test
import java.io.File

/** Sapaan Inggris dan kamus kebalikan (assets/i18n/id.tsv: teks Inggris di kode -> Indonesia untuk mode Indonesia). */
class GreetingLanguageTest {
    companion object {
        private val idFile: File = listOf("src/main/assets/i18n/id.tsv", "app/src/main/assets/i18n/id.tsv").map(::File).first { it.exists() }

        @BeforeClass @JvmStatic fun load() {
            Translator.loadIdLines(idFile.readLines(Charsets.UTF_8).asSequence())
        }
    }

    @Test fun sapaanInggrisMengikutiJam() {
        assertEquals("GOOD MORNING", GreetingEngine.wordEn("pagi", 4))
        assertEquals("GOOD MORNING", GreetingEngine.wordEn("siang", 11))
        assertEquals("GOOD AFTERNOON", GreetingEngine.wordEn("siang", 12))
        assertEquals("GOOD AFTERNOON", GreetingEngine.wordEn("sore", 17))
        assertEquals("GOOD EVENING", GreetingEngine.wordEn("malam", 18))
        assertEquals("GOOD EVENING", GreetingEngine.wordEn("malam", 2))
    }

    @Test fun sapaanInggrisTanpaJamMemakaiPeriode() {
        assertEquals("GOOD AFTERNOON", GreetingEngine.wordEn("sore"))
        assertEquals("GOOD EVENING", GreetingEngine.wordEn("malam"))
    }

    @Test fun sapaanIndonesiaTidakBerubah() {
        assertEquals("SELAMAT SORE", GreetingEngine.word("sore"))
    }

    @Test fun formatKamusKebalikanValid() {
        val seen = HashSet<String>()
        idFile.readLines(Charsets.UTF_8).forEachIndexed { i, line ->
            if (line.isEmpty()) return@forEachIndexed
            val tab = line.indexOf('\t')
            assertTrue("id.tsv baris ${i + 1}: tidak ada TAB", tab > 0)
            assertTrue("id.tsv baris ${i + 1}: kunci ganda", seen.add(line.substring(0, tab)))
            assertTrue("id.tsv baris ${i + 1}: terjemahan kosong", line.substring(tab + 1).isNotBlank())
        }
    }

    @Test fun kalimatInggrisDiKodeDiterjemahkanKeIndonesia() {
        assertEquals("Pekan ini", Translator.id("This week"))
        assertEquals("Belum ada data harian. Catat kondisi pagimu atau sinkronkan jam.", Translator.id("No daily data yet. Log your morning condition or sync the watch."))
        assertEquals("Pekan 3 dari 12 · Build", Translator.id("Week 3 of 12 · Build"))
    }
}
