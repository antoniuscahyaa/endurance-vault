package com.endurancevault.app

import com.endurancevault.app.domain.GreetingPools
import com.endurancevault.app.ui.i18n.Translator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.BeforeClass
import org.junit.Test
import java.io.File

/**
 * Menjaga kamus Inggris (assets/i18n/en.tsv): format, placeholder, kalimat sapaan, dan kalimat gabungan yang pernah bocor
 * (sebagian Indonesia di mode English). Teks baru berbahasa Indonesia di kode TIDAK dicek otomatis; tambahkan ke kamus dan
 * ke tes ini bila menambah kalimat yang tampil di layar.
 */
class I18nCoverageTest {
    companion object {
        private val tsvFile: File = listOf("src/main/assets/i18n/en.tsv", "app/src/main/assets/i18n/en.tsv").map(::File).first { it.exists() }
        private val rawLines: List<String> by lazy { tsvFile.readLines(Charsets.UTF_8) }

        @BeforeClass @JvmStatic fun load() {
            Translator.loadLines(rawLines.asSequence())
        }

        private val PH = Regex("""\{\d*\}|%(?:\.\d+)?[sdf]""")

        /** Kata Indonesia umum; sisa kata ini di hasil terjemahan menandakan teks masih bercampur. */
        private val ID_WORDS = setOf(
            "yang", "dan", "untuk", "tidak", "dengan", "dari", "pada", "hari", "kamu", "sudah", "mulai", "jangan", "bukan", "karena",
            "saja", "boleh", "cukup", "nanti", "lagi", "sesi", "lari", "sepatu", "tubuh", "latihan", "rencana", "hanya", "belum",
            "atau", "bisa", "akan", "lebih", "dalam", "ini", "itu", "tapi", "tetapi", "bila", "jika", "saat", "setelah", "sebelum",
            "kakimu", "tidurmu", "sekitar", "rata", "terakhir", "minggu", "bulan", "menit", "detik",
        )
        private val WORD = Regex("[A-Za-z]+")

        fun leftovers(s: String): List<String> = WORD.findAll(s).map { it.value.lowercase() }.filter { it in ID_WORDS }.toList()

        fun tr(s: String): String = Translator.en(s)
    }

    @Test fun formatKamusValid() {
        val seen = HashSet<String>()
        rawLines.forEachIndexed { i, line ->
            if (line.isEmpty()) return@forEachIndexed
            val tab = line.indexOf('\t')
            assertTrue("en.tsv baris ${i + 1}: tidak ada TAB pemisah", tab > 0)
            val key = line.substring(0, tab); val value = line.substring(tab + 1)
            assertTrue("en.tsv baris ${i + 1}: kunci ganda \"$key\"", seen.add(key))
            assertTrue("en.tsv baris ${i + 1}: terjemahan kosong", value.isNotBlank())
            val kp = PH.findAll(key).count(); val vp = PH.findAll(value).count()
            val indexed = Regex("""\{\d+\}""").containsMatchIn(value)
            assertTrue("en.tsv baris ${i + 1}: placeholder terjemahan ($vp) lebih banyak dari kunci ($kp): \"$key\"", vp <= kp)
            assertTrue("en.tsv baris ${i + 1}: jumlah placeholder kunci ($kp) dan terjemahan ($vp) berbeda: \"$key\"", indexed || vp == 0 || vp == kp)
        }
    }

    @Test fun semuaKalimatSapaanTerjemahPenuh() {
        val bad = ArrayList<String>()
        for ((cat, pool) in GreetingPools.id) for (src in pool) {
            for (n in listOf("3", "2,15", "31")) {
                val text = src.replace("{n}", n)
                val out = tr(text)
                if (out == text || leftovers(out).isNotEmpty()) { bad += "[$cat] $text => $out"; break }
            }
        }
        assertTrue("Sapaan belum diterjemahkan penuh (${bad.size}):\n" + bad.joinToString("\n"), bad.isEmpty())
    }

    @Test fun kalimatKomentarOtomatisGabunganTerjemahPenuh() {
        // Kalimat gabungan seperti yang tampil di halaman Ringkasan (pemisah ". " dan " · " memecah teks).
        val cases = mapOf(
            "Pace rata-rata 6:14/km, GAP 6:15/km · rute relatif datar. Km tercepat 7 di 5:20/km." to
                "Avg pace 6:14/km, GAP 6:15/km · route is relatively flat. Fastest km 7 at 5:20/km.",
            "Load sesi 167, TE 3,4 (Meningkatkan). Sekitar 0,9× rata-rata 10 sesi terakhir. Dosis normal untuk polamu." to
                "Session load 167, TE 3,4 (Improving). About 0,9× the average of the last 10 sessions. Normal dose for your pattern.",
            "Segmen kerja (3 repetisi): HR rata-rata 163 bpm (96% dari LTHR), usaha sekitar threshold. Rata-rata seluruh sesi 153 bpm sudah termasuk pemanasan dan jeda." to
                "Work segments (3 reps): avg HR 163 bpm (96% of LTHR), around threshold effort. The whole-session average of 153 bpm includes warm-up and rests.",
            "3 repetisi × 8:00 (±1,49 km), pace rata-rata 5:22/km. Sangat konsisten (selisih terbaik dan terburuk 5 dtk/km)." to
                "3 reps × 8:00 (±1,49 km), avg pace 5:22/km. Very consistent (best-to-worst gap 5 s/km).",
            "Suhu terasa 30°C dan lembap 82%. HR cenderung lebih tinggi dan pace lebih lambat dari biasa; bandingkan dengan sesi bersuhu serupa, bukan hanya angka pace." to
                "Feels like 30°C and humid at 82%. HR tends to run higher and pace slower than usual; compare with sessions at a similar temperature, not just the pace figure.",
            "HR drift 3,9% (stabil). Efisiensi pace per detak di paruh akhir dibanding paruh awal. Di bawah 5% berarti stabil; di atas 8% tanda kelelahan, panas, atau dehidrasi." to
                "HR drift 3,9% (stable). Pace efficiency per heartbeat in the second half compared with the first half. Under 5% means stable; over 8% suggests fatigue, heat, or dehydration.",
        )
        for ((src, want) in cases) assertEquals(want, tr(src))
    }

    @Test fun satuanDanLabelRute() {
        assertEquals("4 km/h SW", tr("4 km/j SW"))
        assertEquals("Run · follows trails · 1 point", tr("Lari · mengikuti jalur · 1 titik"))
        assertEquals("Run · follows trails · 5 points", tr("Lari · mengikuti jalur · 5 titik"))
    }

    @Test fun templatTidakMenelanKalimatBerikutnya() {
        // "Load sesi {}" tidak boleh menelan seluruh teks beberapa kalimat dan membiarkan sisanya Indonesia.
        val out = tr("Load sesi 167, TE 3,4 (Meningkatkan). Dosis normal untuk polamu.")
        assertTrue(out, leftovers(out).isEmpty())
    }

    @Test fun kalimatTengahTanpaTitikCocokKunciBerTitik() {
        assertEquals("Fastest km 7 at 5:20/km.", tr("Km tercepat 7 di 5:20/km."))
        assertEquals("Avg pace 6:14/km · route is relatively flat. Fastest km 7 at 5:20/km.", tr("Pace rata-rata 6:14/km · rute relatif datar. Km tercepat 7 di 5:20/km."))
    }

    @Test fun labelStikerDanBulanTerjemah() {
        for (s in listOf("HR rendah", "HR tinggi", "Pace hari ini", "Beban 7 hari / kebiasaan", "Tahun 2026", "Rekor", "Kalender", "Banding", "Lari berturut-turut", "Minggu beruntun", "Rekor streak")) {
            val out = tr(s)
            assertFalse("\"$s\" belum diterjemahkan", out == s)
        }
    }
}
