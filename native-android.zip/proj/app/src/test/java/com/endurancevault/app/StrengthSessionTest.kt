package com.endurancevault.app

import com.endurancevault.app.domain.GuideMotion
import com.endurancevault.app.domain.GuideMove
import com.endurancevault.app.domain.ankleFor
import com.endurancevault.app.domain.strengthFor
import com.endurancevault.app.domain.upperFor
import com.endurancevault.app.domain.LiveResult
import com.endurancevault.app.domain.LiveStep
import com.endurancevault.app.domain.Phases
import com.endurancevault.app.domain.StrengthLive
import com.endurancevault.app.domain.StrengthBlock
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class StrengthSessionTest {
    @Test fun barisRepetisiBiasa() {
        val e = StrengthLive.parseLine("Goblet / front squat 3×10")
        assertEquals(GuideMove.SQUAT, e.move); assertEquals(3, e.sets); assertEquals(10, e.reps); assertFalse(e.perSide)
    }

    @Test fun rentangDanPerKaki() {
        val e = StrengthLive.parseLine("Bulgarian split squat 4×6–8 per kaki")
        assertEquals(GuideMove.LUNGE, e.move); assertEquals(8, e.reps); assertEquals("6–8", e.repsLabel)
        assertTrue(e.perSide); assertEquals("Kaki kiri", e.sideLabel(0)); assertEquals("Kaki kanan", e.sideLabel(1))
    }

    @Test fun tahanDetikDanJarak() {
        val p = StrengthLive.parseLine("Side plank 3×30 dtk per sisi")
        assertEquals(GuideMove.SIDE_PLANK, p.move); assertEquals(30, p.holdSec); assertNull(p.reps); assertEquals("Sisi kanan", p.sideLabel(1))
        val c = StrengthLive.parseLine("Farmer carry 3×30 m")
        assertEquals(GuideMove.CARRY, c.move); assertEquals("30 m", c.targetText)
    }

    @Test fun turunPelanMemperlambatTempo() {
        val e = StrengthLive.parseLine("Step-down eksentrik 3×8 per kaki, turun 3 dtk")
        assertEquals(GuideMove.STEP, e.move); assertEquals(4500, e.tempoMs)
    }

    @Test fun barisTakTerbacaTetapJadiSatuSetManual() {
        val e = StrengthLive.parseLine("Peregangan bebas")
        assertEquals(1, e.sets); assertNull(e.reps); assertNull(e.holdSec)
    }

    @Test fun semuaBarisRencanaTerbacaDanPunyaAnimasi() {
        val phases = listOf(Phases.BASE, Phases.BUILD, Phases.PEAK, Phases.TAPER)
        for (ph in phases) for (cut in listOf(false, true)) {
            val blocks = listOf(strengthFor("A", ph, cut), strengthFor("B", ph, cut), upperFor(1, ph, cut), upperFor(2, ph, cut), ankleFor(ph))
            for (b in blocks) for (line in b.lines) {
                val e = StrengthLive.parseLine(line)
                assertTrue("tak terbaca: $line", e.reps != null || e.holdSec != null)
                assertTrue("tanpa animasi khusus: $line", e.move != GuideMove.GENERIC)
            }
        }
    }

    @Test fun istirahatDariCatatan() {
        assertEquals(90, StrengthLive.restSeconds(strengthFor("A", Phases.BUILD, false)))
        assertEquals(45, StrengthLive.restSeconds(strengthFor("A", Phases.TAPER, false)))
        assertEquals(40, StrengthLive.restSeconds(ankleFor(Phases.BASE)))
    }

    @Test fun urutanLangkahPerSisiDanIstirahat() {
        val b = StrengthBlock("Uji", 20, "Istirahat 60 dtk.", listOf("Plank 2×20 dtk", "Single-leg RDL 2×8 per kaki"))
        val plan = StrengthLive.build(b)
        // plank: W R W R | RDL: (W s R W) R (W s R W)   -> 2 + 4 set kerja per sisi
        assertEquals(2 + 4, plan.workCount)
        assertTrue(plan.steps.first() is LiveStep.Work)
        assertTrue(plan.steps.last() is LiveStep.Work)
        val switches = plan.steps.count { it is LiveStep.Rest && it.switchSide }
        assertEquals(2, switches)
    }

    @Test fun entriRiwayat() {
        val linked = StrengthLive.entryJson(LiveResult(1_800_000_000L, "2026-11-17", 35, "2026-11-17:s"))
        assertEquals("2026-11-17:s", linked.getString("k")); assertFalse(linked.has("f")); assertEquals(140, linked.getInt("t"))
        val free = StrengthLive.entryJson(LiveResult(1_800_000_000L, "2026-11-17", 20, null))
        assertTrue(free.getBoolean("f")); assertFalse(free.has("k"))
    }

    @Test fun profilGerakKembaliKeAwalDanMulus() {
        for (tempo in listOf(1500, 2000, 3000, 4000, 4500, 5000)) {
            assertEquals(0f, GuideMotion.phase(0L, tempo), 0f)
            var prev = 0f
            for (t in 0L until tempo * 12L) {
                val p = GuideMotion.phase(t, tempo)
                assertTrue("di luar 0..1: $p", p in 0f..1f)
                assertTrue("lompatan di t=$t tempo=$tempo", kotlin.math.abs(p - prev) < 0.06f)
                prev = p
            }
            assertEquals(0f, GuideMotion.phase(tempo - 1L, tempo), 0f)  // akhir repetisi = pose awal
        }
        assertEquals(0f, GuideMotion.phase(-5L, 4000), 0f)  // masa persiapan: diam
    }

    @Test fun tiapRepetisiSedikitBerbeda() {
        val peaks = (0 until 6).map { r -> (0 until 4000 step 50).maxOf { GuideMotion.phase(r * 4000L + it, 4000) } }
        assertTrue(peaks.toSet().size > 1)
        assertEquals(GuideMotion.phase(1234L, 4000), GuideMotion.phase(1234L, 4000), 0f)  // deterministik
    }

    @Test fun semuaGerakanPunyaIsyaratTeknik() {
        for (m in GuideMove.values()) {
            assertEquals("isyarat ${m.name}", 3, m.cues.size)
            assertTrue(m.tempoMs in 1000..6000)
        }
    }
}
