# 0.5.110 — Explore: rute tidak lagi belok ke gang

## Masalah
Saat menarik titik A ke B di jalan utama, router OSRM/BRouter memilih jalur terpendek untuk pejalan kaki, sehingga sebagian ruas memotong lewat gang.

## Perbaikan
- Opsi baru **Jalan utama** (menu Layer → Routing, default menyala) untuk mode Lari dan Sepeda.
- Cara kerja: rangka rute diambil dari router jalan raya (`routed-car`), dijarangkan jadi titik lewat tiap ±300 m, lalu router kaki/sepeda pilihan (OSRM atau BRouter) dipaksa melewati titik-titik itu. Hasil tetap sah untuk pejalan kaki.
- Pengaman: dipakai rute biasa bila rangka gagal, terlalu memutar (>1,6× rute biasa), titik lewat tidak menempel ke jalan kaki dalam 35 m, atau hasil membengkak. Rute biasa yang sudah ≥90% di jalan besar tidak diproses ulang.
- Mode Manual dan Mendaki tidak berubah.

## Catatan
- Perlu internet; tiap ruas memakai 2 sampai beberapa permintaan, jadi sedikit lebih lambat.
- Matikan "Jalan utama" bila ingin jalur terpendek lagi.

## Tes
- `ExploreRoutingTest` (resample dan shareNear).
