# 0.5.110 — Explore: rute tidak lagi belok ke gang

## Masalah
Saat menarik titik A ke B di jalan utama, router OSRM/BRouter memilih jalur terpendek untuk pejalan kaki, sehingga sebagian ruas memotong lewat gang.

## Perbaikan
- Opsi baru **Jalan utama** (default menyala) untuk mode Lari dan Sepeda, diatur lewat Layer → Routing → **Pengaturan**.
- Cara kerja: rangka rute diambil dari router jalan raya (`routed-car`), dijarangkan jadi titik lewat tiap ±300 m, lalu router kaki/sepeda pilihan (OSRM atau BRouter) dipaksa melewati titik-titik itu. Hasil tetap sah untuk pejalan kaki.
- Pengaman: dipakai rute biasa bila rangka gagal, terlalu memutar (>1,6× rute biasa), titik lewat tidak menempel ke jalan kaki dalam 35 m, atau hasil membengkak. Rute biasa yang sudah ≥90% di jalan besar tidak diproses ulang.
- Mode Manual dan Mendaki tidak berubah.

## Pengaturan routing (baru)
- **Seberapa ketat** mengikuti jalan utama: Longgar (titik lewat tiap 450 m, memutar maks 1,3×), Sedang (300 m, 1,6×, bawaan), Ketat (200 m, 2,2×).
- **Profil BRouter**: Otomatis (Trekking untuk lari, Fastbike untuk sepeda), Trekking, atau Fastbike. Berlaku juga untuk rute biasa tanpa "Jalan utama".
- Semua pilihan tersimpan di perangkat.

## Catatan
- Perlu internet; tiap ruas memakai 2 sampai beberapa permintaan, jadi sedikit lebih lambat.
- Matikan "Jalan utama" bila ingin jalur terpendek lagi.

## Tes
- `ExploreRoutingTest` (resample, shareNear, pemilihan profil, tingkat ketat).
