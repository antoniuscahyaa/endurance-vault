# 0.5.109 — Lapisan jam berdiri sendiri (lepas dari nama JoyoFit)

## Yang berubah
- Paket lapisan protokol jam: `com.joyodigitama.huaweiwear` → `com.endurancevault.app.watch` (kode, tes, proguard).
- Nama teknis: database `joyofit.db` → `watch.db`, pengaturan `joyofit_settings` → `watch_settings`, aset migrasi `joyofit-db-migrations.json` → `watch-db-migrations.json`, deep link `joyofit://` → `endurancevault://`, tag logcat `JoyoFit`/`JoyoFitBle` → `WatchLink`/`WatchLinkBle`, User-Agent, wakelock, konstanta `HU_JOYOFIT*` → `HU_WATCH_FIT*`.
- Komentar dan dokumen tidak lagi menyebut nama proyek perantara.
- `licenses/NOTICE-JoyoFit` diganti `licenses/NOTICE`: induk lisensi Gadgetbridge (AGPL-3.0-or-later), daftar modifikasi, dan satu baris kredit untuk portingnya. Hak cipta di header tiap file tidak diubah.

## Data lama aman
- `LegacyWatchMigration` (dipanggil di `EnduranceVaultApp.onCreate`) memindahkan `SQLite/joyofit.db` (+ `-wal`/`-shm`) dan pengaturan lama ke nama baru, sekali saja, tanpa menimpa data baru.
- Cadangan lengkap yang dibuat sebelum versi ini tetap bisa dipulihkan: entri `prefs/joyofit_settings.json` dipetakan ke `watch_settings`.

## Tes baru
- `LegacyWatchMigrationTest` (pindah berkas, tidak menimpa, dua kali jalan tidak berefek) dan `BackupCodecLegacyPrefTest`.

## Belum dikerjakan
- Layar info lisensi di aplikasi (dibutuhkan bila nanti dibagikan ke orang lain).
