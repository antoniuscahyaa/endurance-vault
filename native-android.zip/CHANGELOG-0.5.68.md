# Splash: siluet dari editor, logo warna asli di tengah

Menggantikan desain splash di CHANGELOG-0.5.66 (bagian "Splash").

## Tahap 1: splash sistem Android
- Hanya latar warna aksen Ember `#EA5F0A`, tanpa ikon (`ic_splash_empty.xml`). Ikon kosong ini wajib ada, kalau tidak Android 12+ menampilkan ikon launcher.

## Tahap 2: `SplashOverlay` (Compose)
- Area gelap `#0B0C0F` naik dari bawah layar, tepi atasnya berupa garis siluet. Semua di bawah garis gelap penuh.
- Logo dengan warna asli ikon launcher terkunci di tengah layar (lebar 0,55 x lebar layar), muncul memudar saat area gelap naik, bertahan 0,7 detik, lalu seluruhnya memudar.
- Garis siluet berasal dari editor siluet: bagian kiri sesuai titik dari editor, bagian kanan dirapikan menjadi offset berjarak tetap (±13 px referensi) dari tepi atas V dan panah.
- Koordinat garis disimpan relatif terhadap pusat layar (px referensi 324 x 724, diskalakan `lebar / 324`), jadi jarak siluet ke logo sama di semua ukuran dan rasio layar.
- Penyesuaian cepat di `SplashOverlay.kt`: `LOGO_WIDTH_FRAC`, `RISE_MS`, `HOLD_MS`, `FADE_MS`. Ubah `RIDGE` lewat editor siluet, jangan diedit manual.

Berkas berubah:
- app/src/main/java/com/endurancevault/app/ui/SplashOverlay.kt (ditulis ulang)
- app/src/main/res/values/themes.xml (ikon splash sistem = ic_splash_empty)
- app/src/main/res/drawable/ic_splash_empty.xml (baru)
- app/src/main/res/drawable/ic_splash_logo.xml (dihapus, tidak dipakai lagi)
