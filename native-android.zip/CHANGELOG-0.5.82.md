# Explore: rencana pendakian

- Penanda puncak, sumber air, dan pondok dari OpenStreetMap (Overpass), digambar di peta Explore dan detail rute (menu lapisan peta "Puncak & sumber air", atau tombol di peta detail). Cache 30 hari per kotak. Di Explore dimuat di sekitar pusat peta saat zoom ≥ 11.
- Detail rute: puncak, air, dan pondok yang ≤ 150 m dari rute masuk daftar "Titik di rute" lengkap dengan elevasi dan perkiraan jam tiba.
- Rencana mendaki (rute naik ≥ 150 m): atur jam mulai (±30 menit), lihat jam tiba tiap titik (rumus Tobler), jam matahari terbit/terbenam di lokasi rute, dan peringatan headlamp.
- Cek cuaca di titik tertinggi rute (Open-Meteo, disesuaikan ketinggian): suhu, peluang hujan, angin dan hembusan selama jendela waktu pendakian.
- Ekspor GPX kini menyertakan waypoint puncak/air/pondok di dekat rute (bila sudah dimuat).
- Overlay jalur pendakian kini juga ada di peta aktivitas dan pratinjau GPX (tombol di kontrol peta).

Tidak dikerjakan: kirim waypoint ke jam. Protokol kirim rute (`GpxRoute.payload`) hanya membawa titik jalur, jadi waypoint hanya ada di GPX ekspor.
Kode belum dikompilasi di sini; mohon rebuild.
