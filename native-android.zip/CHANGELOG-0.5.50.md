# EnduranceVault Native 0.5.50: strategi pace ikut dikirim ke jam

## Perubahan
- Di dialog **Preview rute GPX**, setelah target waktu diisi dan strategi pacing terhitung, muncul kotak **Kirim juga pace ke jam** (bawaan: dicentang).
- Saat **Kirim ke jam**, rute GPX dikirim seperti biasa, lalu strategi pace menyusul sebagai **sesi lari** ("Pace <nama rute>") lewat jalur kursus P2P:
  - satu langkah `run` per ruas (tanjakan, turunan, datar), target **jarak**, rentang **pace ±5%** (`GpxRoute.PACE_TOL`);
  - ruas < 150 m digabung ke tetangganya (pace dihitung ulang dari total waktu), maksimum 100 langkah (batas jam).
- Tanpa target waktu atau kotak tidak dicentang, perilaku sama seperti 0.5.49 (hanya rute).

## Kode
- `GpxRoute.paceCourse(name, result, id)` (baru): hasil `CourseStrategy` → JSON `pushCourses`.
- `GpxPreviewDialog.onSend(Result?)`, `MainViewModel.confirmGpxRoute(pace)` + `pushPaceCourse`, `AppRoot` menyesuaikan.
- Tes baru: `GpxRouteTest.paceCourseSatuLangkahPerRuasDenganRentangPace`.

## Catatan
- Jalur kursus di jam masih EKSPERIMENTAL (lihat `CoursePush.kt`); belum teruji di perangkat. Periksa pesan hasil dan log protokol.
- Kode belum dikompilasi dan tes belum dijalankan di lingkungan ini (tidak ada Gradle/Kotlin). Jalankan CI.

## Layout dialog (layar penuh)
- Dialog Preview rute GPX kini **layar penuh**: header, panel atas terpaku, area tengah yang bisa digulir, dan bar bawah terpaku (centang "Kirim juga pace", **Batal**, **Kirim ke jam**).
- **Panel terpaku**: peta dan profil elevasi + batang pace dijadikan satu kartu, tidak ikut menggulir. Data di bawahnya (jarak/naik/turun, strategi, pace per ruas) digulir sendiri.
- **Peta**: zoom cubit (1×–8×), geser satu jari, ketuk dua kali untuk zoom 3× / reset, tombol "Reset". Switch **Indikator km** di pojok peta; jarak antar penanda menyesuaikan zoom (0,5 / 1 / 2 / 5 / 10 km), sumbu km di grafik ikut menyala/mati.
- **Strategi pacing**: tinggal satu baris ringkasan + satu tombol pengaturan. Target waktu, strategi, dan permukaan turunan pindah ke lembar bawah (bottom sheet).
- Belum teruji di perangkat: perilaku gestur zoom dan insets layar penuh perlu dicoba langsung.
