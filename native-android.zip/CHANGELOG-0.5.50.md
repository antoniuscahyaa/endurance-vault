# EnduranceVault Native 0.5.50: sub-tab Load, Routes & conditions, dan Body disamakan dengan Rekap/Fitness

Versi 0.5.50, version code 64.

## Perubahan
Ketiga sub-tab memakai sistem kartu yang sama dengan Rekap dan Fitness (`RcCard`: ringkasan saat tertutup, detail saat dibuka;
`RcPair`: dua kartu setengah lebar yang melebar bila salah satu dibuka). Header besar dan kartu lama (`ProgressCard`) dihapus.

### Load (4 kartu)
1. **Training readiness** (selebar layar): gauge berwarna + tingkat + saran; detail: bar faktor, penyesuaian sesi hari ini.
2. **Training load** (selebar layar): Load 7 hari, Form, CTL/ATL/Recovery + garis mini; detail: grafik 56 hari, kisi metrik, tabel Training Effect.
3. **ACWR · Strain** (setengah lebar): rasio + zona (Rendah/Optimal/Waspada/Tinggi), Monotony, Strain.
4. **Intensitas 80/20** (setengah lebar): batang bertumpuk Z1–2/Z3/Z4–5; detail: tren 8 pekan, tabel, saran (hanya rekomendasi, rencana tidak diubah).

### Routes & conditions (4 kartu)
1. **Rute serupa** (selebar layar): tiap grup berisi overlay elevasi dan pace per km (skala bersama), tabel anggota (ketuk membuka sesi), perbandingan sekitar setahun.
2. **Bandingkan aktivitas** (selebar layar): pilih A dan B dengan chip yang bisa digeser (menggantikan dua daftar radio), tabel selisih, pace per km dan elevasi A vs B.
3. **Heatmap rute** (setengah lebar): semua rute ber-koordinat bertumpuk di satu peta (makin pekat = makin sering) + ridgeline elevasi.
4. **Dampak cuaca** (setengah lebar): suhu vs pace atau HR (saklar), garis tren, korelasi, tabel pita suhu.

### Body (3 kartu, semuanya selebar layar, Tidur & kondisi paling atas)
1. **Tidur & kondisi**: data terakhir + rata-rata tiap metrik (tidur, HR istirahat, HRV); satu grafik gabungan 14 hari (tidur = batang, RHR = biru, HRV = oranye) dengan saklar tiap seri (minimal satu menyala); detail: rasa kaki & mood, riwayat.
2. **Strength progress**: jumlah sesi, batang 8 pekan, tabel 20 sesi terakhir.
3. **Strength balance**: durasi, sesi/pekan, HR, kalori, pembagian jenis sesi.

## Perilaku yang berubah
- Workout strength yang sudah dihapus (`deleted`) tidak lagi dihitung di kartu Strength (sebelumnya ikut).
- Grafik garis memakai satu skala bersama untuk semua seri (sebelumnya tiap seri dinormalkan sendiri sehingga overlay elevasi tidak bisa dibandingkan).
- Jendela kondisi 14 hari memakai hari kalender (hari tanpa data jadi celah), bukan 14 entri terakhir.
- Aktivitas diurutkan menurut tanggal dan jam sebelum dipilih sebagai "terbaru" di Bandingkan.
- Ambang baru yang bisa disesuaikan di `domain/ProgressTabs.kt`: zona ACWR 0,8/1,3/1,5; saran 80/20 (Z3 > 15% atau Z1–2 < 75%); pita suhu 24/28°C.

## Kode
- Baru: `ui/screens/LoadTab.kt`, `RoutesTab.kt`, `BodyTab.kt`; `domain/ProgressTabs.kt` (logika murni); tes `ProgressTabsTest.kt`.
- `ProgressScreen.kt` disederhanakan: hanya kerangka, bar chip, dan `TabScroll`; kode kartu lama dan fungsi privat yang tak terpakai dihapus.
- `TrainingLoadSection.kt` tidak lagi dipanggil dari mana pun (dibiarkan; aman dihapus).
- `RtLines` (grafik garis banyak seri) bersifat `internal` dan dipakai Routes serta Body.

## Belum ada / batasan
- Heatmap rute digambar offline tanpa ubin peta; `RouteMapView` masih terikat ke satu `ActDetail`.
- Strength balance belum bisa menghitung kelompok otot (data jam tidak menyimpan gerakan).
- Opsi "berapa kali terbangun" di Kondisi pagi belum ditampilkan di kartu Tidur.

## Validasi
- Gradle dan Kotlin tidak tersedia di lingkungan ini (tanpa jaringan), jadi kode belum dikompilasi dan tes belum dijalankan.
  Kurung/kurawal sudah dicek seimbang dan ekspektasi tes dihitung manual. Jalankan CI, kirim log bila ada error kompilasi,
  lalu cek di perangkat: buka tiap kartu, ganti saklar seri di Body, pilih A/B di Bandingkan, ganti Pace/HR di Dampak cuaca.
