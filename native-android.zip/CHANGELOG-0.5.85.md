# Tab Minggu: tombol "Kirim ke jam" di sesi quality

- Kartu sesi quality di tab Minggu punya tombol kecil **Kirim ke jam** (di bawah judul/detail). Tombol hanya muncul bila sesi punya struktur interval, belum ada lari tercatat, dan tidak dibatalkan/dilewati. Sesi tanpa interval (strides, tanjakan pendek dalam detik, uji kebugaran) tidak punya tombol.
- Ketuk tombol → dialog konfirmasi berisi langkah yang akan dikirim (pemanasan, N × lari + jog, pendinginan, total menit), lalu **Kirim**. Hasilnya tampil sebagai satu baris status di bawah tombol Import/Share.
- Struktur dibaca dari teks detail sesi (`domain/QualityWorkout.kt`): threshold/tempo/VO2max/fartlek/pace lomba, sesi kedua (q2), dan mendaki panjang. Repetisi dalam jarak (mis. 6×800 m) dikonversi ke menit dari pace di teks, dibulatkan ke menit terdekat.
- Target HR: langkah lari memakai rentang HR sesi (dikonversi ke % HR maks); pemanasan/pendinginan 50% HR maks sampai batas easy; recovery tanpa target. Interval VO2max/fartlek tanpa target HR (HR baru naik di repetisi ke-2).
- Menit pemanasan/pendinginan yang tidak tertulis di rencana (sesi trail) memakai 10 mnt dan ditandai di dialog.
- Memakai jalur kirim yang sama dengan Structured workout di halaman jam (`MainViewModel.pushStructuredWorkout`); belum dikompilasi dan belum diuji di jam. Tes: `QualityWorkoutTest`.
