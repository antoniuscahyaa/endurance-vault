# Zoom kamera dan gerak kamera sinematik (Video rute 3D dan Video Trail 3D)

## Fitur baru

### Video rute 3D
- **Zoom kamera** 0,50×–2,50× (langkah 0,05×). Berlaku di semua mode kamera, termasuk saat pengantar dan penutup.
- **4 mode kamera sinematik** (di samping Orbit, Ikuti arah lari, Dari atas):
  - **Dolly masuk** – jarak kamera menyusut pelan ke pelari selama lari, melebar lagi di penutup.
  - **Crane naik** – mulai rendah dan dekat, naik dan melebar sepanjang lari.
  - **Spiral** – berputar lebar (90°–360°) sambil turun dan mendekat.
  - **Terbang menyisir** – menyapu dari kiri ke kanan pelari pada ketinggian rendah.
- **Kekuatan gerak kamera** 0–100% (muncul untuk mode sinematik). 0% = hampir diam.
- **Getaran kamera genggam** 0–100% (bawaan mati): gelombang sinus berfrekuensi rendah, deterministik, jadi pratinjau dan hasil render identik.

### Video Trail 3D
- **Zoom kamera** 0,60×–2,50×.
- **Gerak kamera**: Tetap (bawaan, sama seperti sebelumnya), **Dolly masuk**, **Tarik mundur**, **Crane turun**, **Ikuti pelari** (zoom ke pelari dan titik pandang mengikuti posisinya), **Spiral**.
- **Kekuatan gerak** 0–100% dan **getaran kamera genggam** 0–100%.
- Setelah lari selesai kamera kembali ke tampilan penuh (halus, ±0,9 dtk) supaya kartu ringkasan tidak tertutup zoom.
- Penanda di adegan (START, km, PUNCAK, FINISH, pelari) disembunyikan bila keluar dari kotak adegan saat zoom, supaya tidak melayang di atas judul atau panel data.
- Lebar garis rute, garis kontur, dan jarak label ikut skala zoom.

Semua pengaturan baru disimpan di preferensi (`zm`/`ca`/`shk` pada rute; `zoom`/`camMove`/`camAmount`/`shake` pada Trail). Pengaturan lama tanpa kunci ini otomatis memakai nilai bawaan, dan **dengan nilai bawaan (zoom 100%, getaran 0, mode lama) hasil video sama seperti sebelumnya**.

## Berkas yang berubah
- `domain/RouteVideo.kt` – `RouteVideoPrefs` (zoom, camAmount, shake), `CameraPose.zoom`, `RouteVideoCamera` (4 mode baru, `handheld`), `RouteVideoKeys` (mode + keterangan).
- `domain/TrailVideo.kt` – `TrailPrefs` (zoom, camMove, camAmount, shake), `TrailCam`, `TrailCamera`, `TrailTimeline.Pt.cam`.
- `ui/video/TerrainGl.kt` – jarak kamera dibagi zoom.
- `ui/video/TrailGl.kt` – `setCamera`, `mvp` dengan zoom/kemiringan dinamis/ikuti pelari, skala meter-per-piksel mengikuti zoom.
- `ui/video/TrailEncoder.kt` – `setCamera` sebelum menggambar; cakupan azimut untuk fit slab ikut putaran spiral.
- `ui/video/TrailPainter.kt` – penanda di luar kotak adegan disembunyikan.
- `ui/screens/RouteVideoScreen.kt`, `ui/screens/TrailVideoScreen.kt` – kontrol baru; kunci cache pratinjau rute ditambah zoom/kekuatan/getaran.
- `assets/i18n/en.tsv` – 22 terjemahan baru.
- Tes baru di `RouteVideoTest` (7) dan `TrailVideoTest` (8): bawaan tidak berubah, sanitasi dan simpan/muat JSON, zoom di semua mode, arah gerak tiap mode, batas aman (pitch, jarak, ikuti, zoom), kamera kembali penuh untuk ringkasan, getaran deterministik dan kecil.

## Catatan dan batasan
- Kode **belum dikompilasi dan belum dijalankan di perangkat** (lingkungan ini tanpa Kotlin/Gradle). Rumus gerak kamera dan semua asersi tes baru sudah diverifikasi lewat port Python, tetapi tampilan visual perlu dicek langsung. Mohon rebuild dan kirim log CI atau tangkapan layar bila ada error atau tampilan yang meleset.
- Trail: zoom di atas 1× memotong tepi slab pada kotak adegan (disengaja, efek push-in). Fit slab tetap dihitung pada zoom 1×.
- Trail "Crane turun" mengubah kemiringan hanya di atas kemiringan yang dipilih, dan dibatasi maksimal 80° dari atas.
- Depth buffer 16 bit: bidang dekat kamera Trail diperkecil (0,25 → 0,15 jarak dasar) agar zoom tinggi tidak memotong slab; belum diuji di perangkat dengan zoom 2,5×.
