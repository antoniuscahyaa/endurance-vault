# 0.5.97

## Video Trail 3D dan Video HUD (menu ⋮ di Detail aktivitas)
Dua fitur dari aplikasi web (APK Rencana Lari) diadaptasi ke native. Keduanya dibuka dari menu **⋮** di Detail aktivitas: **Video Trail 3D** dan **Video HUD**. Render berjalan di latar belakang lewat `RouteVideoJobs` (satu render pada satu waktu, notifikasi progres, simpan ke galeri, bagikan), sama seperti Video rute 3D.

### Video Trail 3D
- **Slab medan 3D** bergaya (bukan citra satelit): relief dari DEM terhaluskan, garis kontur halus dan tebal, pencahayaan dari barat laut, dinding slab, rute redup + bagian tertempuh menyala. Bentuk **lingkaran, persegi, segi enam, segi delapan**; kemiringan 20–75°, tinggi relief 5–60%, sudut awal dan putaran selama lari.
- **Latar**: pegunungan senja (langit, matahari, tiga lapis punggungan), langit polos, warna polos, atau **foto sendiri** dengan peredam gelap. Palet **oranye neon** dan **lime neon**, atau warna aksen bebas.
- **Grafik elevasi** yang terisi seiring lari, **jalur zona HR**, pita dan label **tanjakan** (deteksi: ≥3% terhaluskan, naik ≥40 m, ≥0,4 km, rata-rata ≥4%), label **puncak**, pil **gradien**, penanda **START / km / PUNCAK / FINISH** dengan penempatan label tanpa tabrakan.
- **Panel data** empat layout (**Klasik, Tengah, Kartu 2×2, Ringkas**), bar progres, baris tambahan (VAM/GAP, cadence, naik), data otomatis atau pilih sendiri sampai 4 (pace/kecepatan, detak, naik, waktu, cadence, GAP, VAM), kartu kaca/pekat/otomatis bila latar terang, mode aman Story 9:16.
- Animasi masuk, **ringkasan akhir** (data berjalan memudar jadi rata-rata), lama lari 6–60 dtk, rasio 9:16 / 4:5 / 1:1 / 16:9, 1080p atau 720p. **Foto bingkai** dari posisi pratinjau. Judul, lokasi, akun, dan cuaca di header.
- Medan dibangun tanpa unduhan citra satelit (`TerrainBuilder.buildTrail`), hanya DEM, jadi lebih cepat dan hemat data.

### Video HUD
- Pilih video dari galeri; data lari ditempel dan bergerak sesuai waktu video: **HR, jarak, pace, waktu, elevasi, kemiringan, kecepatan (gauge), minimap rute** (jejak tertempuh + titik posisi). Gaya **Dua kolom** dan **Minimal**, warna aksen, peredam gelap.
- **Sinkron waktu**: offset detik dengan penyesuaian −10/−1/+1/+10 dan pratinjau bingkai di posisi mana pun; offset awal **ditebak** dari waktu rekam video (metadata, lalu waktu ubah berkas) terhadap jam mulai lari.
- Pipeline native: `MediaExtractor` → `MediaCodec` decoder → OpenGL (rotasi tampilan diperhitungkan) + HUD sebagai tekstur transparan → encoder H.264 → `MediaMuxer`. **Suara asli AAC disalin tanpa di-encode ulang.** Maksimal 15 menit pertama; sisi terpanjang hasil ≤ 1920 px.

### Teknis
- Berkas baru: `domain/TrailVideo.kt`, `domain/VideoHud.kt`, `ui/video/Trail{Palette,Gl,Painter,Encoder,PrefsStore}.kt`, `ui/video/Hud{Painter,Encoder}.kt`, `ui/screens/{VideoUiParts,TrailVideoScreen,HudVideoScreen}.kt`.
- Tes baru: `TrailVideoTest`, `VideoHudTest` (pengaturan, tata letak, deteksi tanjakan, linimasa, GAP/VAM, sinkron HUD, minimap).
- Berubah: `ActivityDetailScreen.kt` (dua item menu), `AppRoot.kt` (rute `trailvideo/{id}` dan `hudvideo/{id}`), `Terrain.kt` (`buildTrail`, bingkai medan bisa lebih lebar), `RouteVideoJobs.kt` (`startTask` untuk render umum), `i18n/en.tsv`.
- Tidak ada izin atau dependensi baru.

### Catatan dan batasan
- Kode **belum dikompilasi dan belum dijalankan di perangkat**. Mohon rebuild dan kirim log CI atau tangkapan layar bila ada error atau tampilan yang meleset.
- Offset HUD dihitung dari **waktu gerak** jejak (`RouteVideoTrack.sec`); pada lari dengan jeda panjang, HUD bisa bergeser dari jam dinding. Slider offset dipakai untuk mengoreksinya.
- Pratinjau HUD berupa bingkai diam (digeser lewat slider), bukan pemutaran video.
- Suara selain AAC tidak dibawa (hasil tanpa suara, ada catatan di layar). Video HDR/10-bit belum diuji.
- Foto latar Trail hanya dipakai selama layar terbuka dan tidak disimpan.
