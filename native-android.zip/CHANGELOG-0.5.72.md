# Penyempurnaan Profil, Jam, dan simpan otomatis

## Simpan otomatis acuan latihan dibatasi
- Pace easy tersimpan hanya diganti bila selisihnya 5 detik/km atau lebih (atau pace tersimpan tidak valid), supaya rencana tidak dihitung ulang setiap pergeseran kecil RAI.
- Batas HR easy dan rentang threshold disimpan begitu berubah (berasal dari zona, jadi stabil).
- Logikanya di `TrainingRefs.update`, diuji di `TrainingRefsTest` (jalur tanpa data, fallback lari easy, RAI, dan batas simpan).

## Back dari halaman Jam
- Halaman Jam yang dibuka dari kartu Jam di Pengaturan kini kembali ke Pengaturan saat Back ditekan. Dari halaman Jam ke Koneksi jam, Back tetap kembali ke halaman Jam dulu.

## Kartu Jam di Pengaturan
- Ringkasan menambah waktu sinkron terakhir, mis. "Terhubung · Baterai 82% · Sinkron 3 mnt lalu".

## Halaman Profil
- Gear: bar km kuning mulai 80% dari batas, dengan teks "Mendekati batas (N%)"; merah dan "Melewati batas" bila terlewati.
- Target: setelah tanggal lomba lewat kartu menjadi "Lomba selesai" dengan tautan ke Rencana; pada hari lomba tampil "Hari H" menggantikan angka 0.
- Total keseluruhan: pilihan "Semua" atau "Tahun ini".

Berkas berubah:
- app/src/main/java/com/endurancevault/app/domain/TrainingRefs.kt
- app/src/main/java/com/endurancevault/app/ui/AppRoot.kt
- app/src/main/java/com/endurancevault/app/ui/screens/ProfilePage.kt
- app/src/main/java/com/endurancevault/app/ui/screens/ProfileScreen.kt
- app/src/main/java/com/endurancevault/app/ui/screens/WatchStatus.kt
- app/src/test/java/com/endurancevault/app/TrainingRefsTest.kt (baru)
