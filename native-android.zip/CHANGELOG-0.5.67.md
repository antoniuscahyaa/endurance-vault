# Dock Jam pindah ke Pengaturan, status jam tampil di header

Tab "Jam" dihapus dari dock bawah (sisa Hari ini, Progres, Minggu, Jadwal). Isi halaman Jam tidak berubah dan tetap bisa dibuka.

## Kartu Jam di Pengaturan
- Letaknya tepat di bawah kartu profil, dengan bentuk dan lebar yang sama.
- Judul = nama jam (alias bila ada, jika tidak nama dari jam). Ringkasan = status koneksi dan baterai, mis. "Terhubung · Baterai 82%".
- Titik kecil di pojok kanan atas menunjukkan status sinkron (hijau = baru sinkron, kuning = sinkron lama, biru berkedip = menyinkron, merah = terputus, abu-abu = belum diketahui).
  Ketuk titik = sinkron otomatis bila jam terhubung; bila terputus, membuka halaman koneksi jam (`watchsettings`).
- Ketuk kartu = membuka halaman Jam penuh (rute `watch`, tanpa tab).

## Pil status di header
- Di samping pill Recovery: titik status sinkron + persen baterai. Ketukannya sama dengan titik di kartu.
- Pada layar sempit, teks "ready HH:mm" di pill Recovery dipotong lebih dulu.

## Pembacaan status
- `AppRoot` memanggil `refreshWatchDock()` tiap 60 detik dan setiap sinkron mulai/selesai, supaya header dan kartu tetap segar tanpa membuka halaman Jam.

Berkas berubah:
- app/src/main/java/com/endurancevault/app/ui/screens/WatchStatus.kt (baru: WatchBadge, WatchSettingsCard, WatchHeaderPill)
- app/src/main/java/com/endurancevault/app/ui/AppRoot.kt (hapus Tab.Watch dari dock, pil di header, state dan callback status jam)
- app/src/main/java/com/endurancevault/app/ui/screens/ProfileScreen.kt (parameter `settingsExtra`, dirender di bawah kartu profil)
