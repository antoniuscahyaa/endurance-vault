# Progress dashboard migration — expanded native pass

## Dashboard structure
Progress is split into the five legacy categories: Recap, Fitness, Load, Routes & conditions, and Body. It remains nested inside Profile > Progress; the app dock is unchanged.

## Ported in this pass
- Full activity-detail loading is now exposed in UiState from ActStore (route geometry, splits, HR histogram, pace/elevation series). This data is loaded off the main thread and reused by analytics.
- RAI: ported the legacy run-estimate formula (minimum 3 km, duration and HR required; elevation correction; HR reserve; median of recent eligible runs; fallback to last six if there are fewer than three in 28 days).
- Fitness RAI and Fatigue RAI display use the legacy equations from `renderFit`.
- Pace zones use the legacy RAI pace conversion and Easy/Tempo/Threshold/VO2max fractions.
- ACWR uses the legacy 7-day acute / 28-day weekly chronic calculation and minimum 8 active-load days.
- Monotony and strain use the legacy 7-day mean / population standard deviation and load × monotony.
- HR intensity distribution is calculated from the available per-activity HR histograms.
- PRs use legacy full-kilometre split windows for 1 km, 5 km, 10 km, and half marathon.
- Similar route groups use the legacy distance tolerance (0.88–1.14), 48-point resampling, symmetric 90th percentile nearest-point distance, and route-length tolerance.
- Activity comparison now selects two imported detail activities and compares distance, pace, HR and elevation.
- Ridgeline mini-profiles render from stored elevation profiles.
- Weather impact reads retained legacy `wx.t` / `wx.fl` values from activity detail JSON when present.
- Recap shows weekly volume, plan session adherence, target distance, monthly summary, year-specific consistency and annual daily-distance heatmap.
- Body shows synced daily sleep/RHR/HRV plus manual leg feel and mood, and planned strength sessions.

## Legacy source files referenced
- `24-ringkasan-progres.js`
- `15-training-load-te-kebugaran.js`
- `22-statistik-data.js`
- `24b-kepatuhan-rencana.js`
- `25-nilai-easy-run.js`
- `08-kesesuaian-rute-serupa-detail.js`
- `23-kartu-elevasi-ridgeline.js`
- `04-kondisi-pagi-ulasan-bandingkan.js`
- `09-gerakan-strength.js`
- `29b-strength-dari-jam.js`
- `05-lomba-tema-prediksi.js`
- `20-zona-log-bulanan-pr-cadangan.js`

## Remaining parity work (not represented as fabricated metrics)
- Easy-run compliance now reads the legacy `hz`/`vz` 5-second bucket arrays, `ez` annotation, and `zs` stride marker from activity detail JSON. It ports the legacy warm-up removal, HR excess bands, penalty multiplier, drift, speed stability, aerobic efficiency, and weighted score. The 14-day session list is native; a full 14/30-day trend chart and complete stride auto-detection parity remain outstanding.
- Aerobic efficiency and cardiac drift use the exact paired legacy `hz`/`vz` bucket arrays when present. Existing detail imports without those arrays fall back only to the legacy HR histogram compliance and do not fabricate drift/efficiency values.
- Weather trend regression by temperature/feels-like and easy-HR filter still needs broader historical metadata; current display reports available per-activity temperature/feels-like and uses temperature threshold adjustment in EasyRunAnalytics when enabled.
- Watch strength workout records are now restored from the legacy `swo` backup key and displayed separately from run activities, with date, duration, average/max HR and calories. As in the legacy app, they are excluded from mileage, PR and running training load. Strength progress by movement/muscle balance still needs set/repetition and exercise identity data, which the legacy watch record schema does not contain.
- Monthly comparison vs prior year, full daily condition 14/30-day multi-series chart, route heatmap overlays, and full activity comparison charts remain to be ported.
- Plan adherence currently counts completed planned run days; the legacy's full weekly review (PRs, records, streaks, load and plan-shift proposals) remains outstanding.

## Integrity / verification
No plan, readiness, CTL/ATL/TSB, or Training Effect formulas were changed by this pass. ZIP integrity is checked. Android build/device verification is pending because neither `gradlew` nor system Gradle is available in the current environment.

## Data-structure work in this pass
- `ActDetail` now parses and retains `hz`, `vz`, `ez`, `zs`, and weather `wx` data alongside route/split/series payloads.
- `EasyRunConfig` maps the old `S.ezp` settings (including tolerance bands, score thresholds, warm-up, stride and heat options) into native `PlanSettings` and SharedPreferences.
- `BackupParser` now preserves the legacy `swo` strength-workout collection in companion KV backup restore.
- `UiState` exposes complete activity detail objects and parsed strength workout rows without merging strength sessions into run mileage.

## Resolusi deret aktivitas 1 Hz

- Impor FIT/GPX/TCX native kini membangun `tl` versi 1 (`r=1`) pada setiap detik bergerak.
- Kanal tersimpan: detik, jarak, HR, cadence, elevasi, kecepatan GAP (cm/detik), dan grade. Kanal tanpa pasangan sampel valid/celah timestamp panjang dibiarkan kosong atau nol sesuai tipe, bukan diisi seolah-olah pengukuran sensor.
- HR/GAP easy-run memakai kanal 1 Hz untuk aktivitas baru; data lama `hz`/`vz` 5 detik tetap dibaca dengan skala 5 detik.
- Grafik detail aktivitas memilih elevasi dan HR 1 Hz jika tersedia, dan menambahkan grafik GAP 1 Hz.
- Format detail JSON bersifat aditif; schema Room tidak berubah. Data aktivitas lama tetap kompatibel.
- Data per detik adalah hasil resampling/interpolasi dari titik rekaman sumber, bukan klaim bahwa perangkat merekam setiap metrik tepat sekali per detik.
