package com.endurancevault.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.endurancevault.app.domain.Js
import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.domain.RBAND
import com.endurancevault.app.domain.Zones
import com.endurancevault.app.domain.hrMaxEst
import com.endurancevault.app.domain.thrBand

/*
 * Pengaturan Zona HR native, padanan section "Zona HR" (#pfZones) di rencana lari:
 * Default, Patokan sesi, LTHR, HRR (Karvonen), HR lomba per kategori. Setiap panel bisa dibuka-tutup,
 * persen tiap zona diedit langsung di tabel, dan perubahan langsung tersimpan (tanpa tombol Simpan),
 * sama seperti event "change" di web. Satu komposabel ini dipakai di Profil dan layar Watch.
 * Catatan: panel "LT test" belum ada di native, jadi belum ditampilkan.
 */

private val ZC = listOf(Color(0xFF7F9CD6), Color(0xFF3F9E86), Color(0xFFD8B04A), Color(0xFFE8844F), Color(0xFFC84B3B))
private val ZNAME = listOf("Z1 Pemulihan", "Z2 Aerobik", "Z3 Tempo", "Z4 Threshold", "Z5 VO2max")
private val ZUSE = listOf(
    "Jalan, jog sangat santai", "Easy dan long run", "Tempo, pace maraton",
    "Threshold, pace half marathon dan 10K", "Interval, pace 5K",
)
private val ZTEXT = Color(0xFF0F1613)
private val RACE_CATS = listOf(
    listOf("5K", "5k", "Interval VO2max, pace 5K", "HR lambat naik, andalkan usaha di 1–2 menit pertama"),
    listOf("10K", "10k", "Interval 3K–5K dan threshold", "Tahan di sekitar threshold atas"),
    listOf("Half marathon", "hm", "Threshold dan tempo", "Mulai di batas bawah, naik bertahap"),
    listOf("Marathon", "fm", "Tempo dan pace maraton", "Jaga di bawah threshold agar glikogen cukup"),
    listOf("Trail", "ultra", "Easy, mendaki panjang", "Mendaki: napas terkendali, bukan HR; datar: zona 2–3"),
    listOf("Ultra road", "ultrar", "Easy, threshold, tempo", "Jaga di zona 2–3, tempo tetap di bawah threshold"),
)

/** Median HR istirahat 14 catatan harian terakhir (sebelum hari ini); sama dengan yang dikirim ke jam. */
internal fun restHrFrom(daily: List<com.endurancevault.app.data.DailyEntity>): Pair<Int, Boolean> {
    val today = java.time.LocalDate.now().toString()
    val v = daily.filter { it.dateIso < today && (it.rhr ?: 0) > 0 }.sortedBy { it.dateIso }.takeLast(14).mapNotNull { it.rhr }.sorted()
    return if (v.isEmpty()) 55 to false else v[v.size / 2] to true
}

private fun tint(i: Int): Color = lerp(ZC[i], Color.White, 0.28f) // color-mix(zona 72%, putih)
private fun pctTxt(d: Double) = if (d % 1.0 == 0.0) d.toInt().toString() else d.toString()
private fun num(t: String) = t.replace(',', '.').toDoubleOrNull()

/** Simpan saat kolom kehilangan fokus (padanan event change di web). */
private fun Modifier.commitOnBlur(onCommit: () -> Unit): Modifier = composed {
    var had by remember { mutableStateOf(false) }
    onFocusChanged { if (had && !it.isFocused) onCommit(); had = it.isFocused }
}

@Composable
internal fun HrZoneSettings(
    settings: PlanSettings,
    restDefault: Int,
    restKnown: Boolean,
    onSave: (PlanSettings) -> Unit,
    onSendToWatch: (PlanSettings) -> Unit,
    watchStatus: String,
    sending: Boolean,
    modifier: Modifier = Modifier,
) {
    var method by remember(settings) { mutableStateOf(if (settings.zm == "hrr") "hrr" else "lthr") }
    var lthr by remember(settings) { mutableStateOf(settings.lthr?.toInt()?.toString().orEmpty()) }
    var rhr by remember(settings) { mutableStateOf(settings.rhr?.toInt()?.toString().orEmpty()) }
    val zlF = remember(settings) { mutableStateListOf(*settings.zl.map(::pctTxt).toTypedArray()) }
    val zrF = remember(settings) { mutableStateListOf(*settings.zr.map(::pctTxt).toTypedArray()) }
    var changedHint by remember { mutableStateOf(false) }

    fun build(m: String = method) = settings.copy(
        zm = m,
        lthr = num(lthr),
        rhr = num(rhr),
        zl = zlF.mapIndexed { i, t -> num(t) ?: settings.zl[i] },
        zr = zrF.mapIndexed { i, t -> num(t) ?: settings.zr[i] },
    )
    fun commit(m: String = method) {
        val n = build(m)
        if (n != settings) { onSave(n); changedHint = true }
    }

    val cur = build()
    val zc = Zones.cuts(cur, restDefault)
    val mx = hrMaxEst(cur)
    val hasMx = (cur.hrMax ?: 0) >= 140
    val mxNote = if (hasMx) "" else " (perkiraan; isi di Atur rencana bila Anda tahu angka sebenarnya)"
    val (easy, thr) = Zones.sessionRefs(zc)

    // LTHR
    val band = thrBand(cur) ?: listOf(164, 172)
    val custLt = (cur.lthr ?: 0.0) >= 100
    val lt = if (custLt) Js.roundI(cur.lthr!!) else Js.roundI((band[0] + band[1]) / 2.0)
    val zlOk = Zones.zcut(cur.zl, Zones.ZLD, 150.0).let { it === cur.zl }
    val zlV = Zones.zcut(cur.zl, Zones.ZLD, 150.0)
    fun pl(x: Double) = Js.roundI(x * lt / 100)
    // HRR
    val custRest = (cur.rhr ?: 0.0) >= 30
    val rest = if (custRest) Js.roundI(cur.rhr!!) else restDefault
    val zrOk = Zones.zcut(cur.zr, Zones.ZRD, 100.0).let { it === cur.zr }
    val zrV = Zones.zcut(cur.zr, Zones.ZRD, 100.0)
    fun pr(x: Double) = Js.roundI(rest + x / 100 * (mx - rest))

    EvPanel(modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Zona HR", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 2.dp, bottom = 4.dp))

            ZoneSet("Zona HR · Default", startOpen = true) {
                Box(Modifier.padding(horizontal = 10.dp).fillMaxWidth()) {
                    var menu by remember { mutableStateOf(false) }
                    OutlinedTextField(
                        value = if (method == "hrr") "HRR (Karvonen)" else "Threshold (% LTHR)", onValueChange = {}, readOnly = true,
                        label = { Text("Metode zona default") }, trailingIcon = { Text("▾") }, modifier = Modifier.fillMaxWidth(),
                    )
                    Box(Modifier.matchParentSize().clickable { menu = true }.semantics { contentDescription = "Metode zona default" })
                    DropdownMenu(menu, { menu = false }) {
                        listOf("lthr" to "Threshold (% LTHR)", "hrr" to "HRR (Karvonen)").forEach { (k, l) ->
                            DropdownMenuItem(text = { Text(l) }, onClick = { menu = false; method = k; commit(k) })
                        }
                    }
                }
                Info((if (zc.mode == "hrr") "HRR (Karvonen), HR maks ${zc.maxHr} bpm" else "LTHR ${zc.lthr} bpm") + ". " +
                    zc.bands().mapIndexed { i, b -> "Z${i + 1} $b" }.joinToString(" · ") + " bpm. " +
                    "Dipakai untuk distribusi zona per sesi, minggu, dan bulan di Progres. Persen tiap zona bisa diubah di bawah.")
                Column(Modifier.padding(start = 10.dp, end = 10.dp, bottom = 10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { changedHint = false; onSendToWatch(build()) }, enabled = !sending) { Text("Kirim zona ke jam") }
                    val st = if (changedHint) "Zona berubah. Tekan Kirim lagi agar jam ikut." else watchStatus
                    if (st.isNotBlank()) Text(st, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            ZoneSet("Zona HR · Patokan sesi") {
                val w = listOf(1.5f, 1f, 2.4f)
                Table(listOf("Zona", "HR (bpm)", "Dipakai untuk"), w) {
                    TRow(w, tint(1), "Easy / MAF", "≤ $easy", "Easy, long run, naik kembali saat latihan turunan, uji kebugaran")
                    TRow(w, tint(0), "Sepeda zona 1–2", "${easy - 15}–${easy - 5}", "Cross training sepeda")
                    TRow(w, tint(3), "Threshold", "${thr.first}–${thr.last}", "Sesi threshold")
                    TRow(w, null, "Mendaki panjang", "napas terkendali", "Power hike, masih bisa bicara kalimat pendek")
                    TRow(w, null, "Turun terkendali", "abaikan HR", "Usaha 5–6 dari 10, langkah pendek")
                }
            }

            ZoneSet("Zona HR · LTHR") {
                Box(Modifier.padding(horizontal = 10.dp)) {
                    CommitField(lthr, { lthr = it.filter(Char::isDigit).take(3) }, "LTHR (bpm, opsional)", "otomatis", { commit() })
                }
                Info("LTHR $lt bpm (${if (custLt) "diisi manual" else "otomatis dari rentang threshold"}). Rumus: HR = % × LTHR. Batas easy $easy bpm." +
                    if (zlOk) "" else " Persen tidak berurutan, memakai nilai awal.")
                val w = listOf(1.5f, 1.1f, 1f, 2f)
                Table(listOf("Zona", "% LTHR", "HR (bpm)", "Dipakai untuk"), w) {
                    ZRow(w, 0, "< ${pctTxt(zlV[0])}%", "< ${pl(zlV[0])}")
                    for (i in 0 until 4) {
                        val bpm = if (i < 3) "${pl(zlV[i])}–${pl(zlV[i + 1]) - 1}" else "≥ ${pl(zlV[3])}"
                        ZRow(w, i + 1, null, bpm) { PctField(zlF[i], { zlF[i] = it }, "Z ${i + 2}", { commit() }) }
                    }
                }
                ResetBtn { zlF.indices.forEach { zlF[it] = pctTxt(Zones.ZLD[it]) }; commit() }
            }

            ZoneSet("Zona HR · HRR (Karvonen)") {
                Box(Modifier.padding(horizontal = 10.dp)) {
                    CommitField(rhr, { rhr = it.filter(Char::isDigit).take(3) }, "HR istirahat (bpm, opsional)", "otomatis", { commit() })
                }
                Info("HR maks $mx bpm$mxNote, HR istirahat $rest bpm (" +
                    (if (custRest) "diisi manual" else if (restKnown) "median catatan harian 14 hari terakhir" else "bawaan, belum ada catatan harian") +
                    "). Rumus: HR = istirahat + % × (maks − istirahat)." + if (zrOk) "" else " Persen tidak berurutan, memakai nilai awal.")
                val w = listOf(1.5f, 1.1f, 1f, 2f)
                Table(listOf("Zona", "% HRR", "HR (bpm)", "Dipakai untuk"), w) {
                    for (i in 0 until 5) {
                        val bpm = if (i < 4) "${pr(zrV[i])}–${pr(zrV[i + 1]) - 1}" else "${pr(zrV[4])}–$mx"
                        ZRow(w, i, null, bpm) { PctField(zrF[i], { zrF[i] = it }, "Z ${i + 1}", { commit() }) }
                    }
                }
                ResetBtn { zrF.indices.forEach { zrF[it] = pctTxt(Zones.ZRD[it]) }; commit() }
            }

            ZoneSet("HR lomba per kategori") {
                val w = listOf(1.3f, 1f, 2.4f)
                Table(listOf("Kategori", "HR lomba", "Sesi kunci dan catatan"), w) {
                    RACE_CATS.forEach { c ->
                        val r = RBAND.getValue(c[1]); val on = cur.rtype.ifBlank { "ultra" } == c[1]
                        TRow(w, null, c[0] + if (on) " (dipilih)" else "", "${Js.roundI(r[0] * mx)}–${Js.roundI(r[1] * mx)}", c[2] + ". " + c[3], bold = on)
                    }
                }
                Text(
                    "HR maks $mx bpm$mxNote. Rentang HR lomba berupa persen HR maks dan hanya patokan; pace atau usaha tetap diutamakan karena HR tertinggal di awal interval dan naik karena panas serta kelelahan.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 10.dp, end = 10.dp, top = 8.dp, bottom = 12.dp),
                )
            }
        }
    }
}

/** Padanan details.set: judul tebal, chevron berputar, latar mengikuti kartu. */
@Composable
private fun ZoneSet(title: String, startOpen: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    var open by rememberSaveable(title) { mutableStateOf(startOpen) }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.background)) {
        Row(
            Modifier.fillMaxWidth().heightIn(min = 54.dp).clickable { open = !open }.padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("›", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.rotate(if (open) -90f else 90f))
        }
        if (open) { content(); Box(Modifier.height(4.dp)) }
    }
}

@Composable
private fun Info(text: String) = Text(
    text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
    modifier = Modifier.padding(start = 10.dp, end = 10.dp, top = 8.dp, bottom = 4.dp),
)

@Composable
private fun Table(head: List<String>, w: List<Float>, rows: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp).padding(top = 6.dp, bottom = 4.dp).border(BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant), shape).clip(shape)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp)) {
            head.forEachIndexed { i, h ->
                Text(h, Modifier.weight(w[i]), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = if (i == 0 || i == head.lastIndex) TextAlign.Start else TextAlign.End)
            }
        }
        rows()
    }
}

@Composable
private fun TRow(w: List<Float>, bg: Color?, a: String, b: String, c: String, bold: Boolean = false) {
    val col = if (bg != null) ZTEXT else MaterialTheme.colorScheme.onSurface
    Row(Modifier.fillMaxWidth().let { if (bg != null) it.background(bg) else it }.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        val st = MaterialTheme.typography.bodySmall.copy(color = col, fontWeight = if (bold) FontWeight.SemiBold else FontWeight.Normal)
        Text(a, Modifier.weight(w[0]), style = st)
        Text(b, Modifier.weight(w[1]), style = st, textAlign = TextAlign.End)
        Text(c, Modifier.weight(w[2]).padding(start = 10.dp), style = st)
    }
}

/** Baris zona berwarna: nama, kolom persen (teks atau kolom edit), bpm, keterangan. */
@Composable
private fun ZRow(w: List<Float>, i: Int, pctText: String?, bpm: String, pct: (@Composable () -> Unit)? = null) {
    val st = MaterialTheme.typography.bodySmall.copy(color = ZTEXT)
    Row(Modifier.fillMaxWidth().background(tint(i)).padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(ZNAME[i], Modifier.weight(w[0]), style = st)
        Box(Modifier.weight(w[1]), contentAlignment = Alignment.CenterEnd) { if (pct != null) pct() else Text(pctText.orEmpty(), style = st) }
        Text(bpm, Modifier.weight(w[2]), style = st, textAlign = TextAlign.End)
        Text(ZUSE[i], Modifier.weight(w[3]).padding(start = 10.dp), style = st)
    }
}

@Composable
private fun PctField(value: String, onValue: (String) -> Unit, label: String, onCommit: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        BasicTextField(
            value = value, onValueChange = { onValue(it.filter { c -> c.isDigit() || c == '.' }.take(5)) }, singleLine = true,
            textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface, textAlign = TextAlign.End, fontSize = MaterialTheme.typography.bodySmall.fontSize),
            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { onCommit() }),
            modifier = Modifier.width(52.dp).height(36.dp).semantics { contentDescription = label }.commitOnBlur(onCommit),
            decorationBox = { inner ->
                Box(
                    Modifier.fillMaxWidth().height(36.dp).clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.background)
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp)).padding(horizontal = 6.dp),
                    contentAlignment = Alignment.CenterEnd,
                ) { inner() }
            },
        )
        Text("%", Modifier.padding(start = 2.dp), style = MaterialTheme.typography.bodySmall, color = ZTEXT)
    }
}

@Composable
private fun CommitField(value: String, onValue: (String) -> Unit, label: String, placeholder: String, onCommit: () -> Unit) {
    OutlinedTextField(
        value, onValue, label = { Text(label) }, placeholder = { Text(placeholder) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
        keyboardActions = KeyboardActions(onDone = { onCommit() }),
        modifier = Modifier.fillMaxWidth().commitOnBlur(onCommit),
    )
}

@Composable
private fun ResetBtn(onClick: () -> Unit) {
    Box(Modifier.padding(start = 10.dp, end = 10.dp, top = 10.dp, bottom = 12.dp)) {
        OutlinedButton(onClick = onClick) { Text("Kembalikan persen ke awal") }
    }
}
