package com.endurancevault.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.Icon
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.Surface
import androidx.compose.foundation.layout.size
import androidx.compose.ui.Alignment
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.navArgument
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.endurancevault.app.ui.screens.ActivityDetailScreen
import com.endurancevault.app.ui.screens.ProfileScreen
import com.endurancevault.app.ui.screens.ProgressScreen
import com.endurancevault.app.ui.screens.ScheduleScreen
import com.endurancevault.app.ui.screens.PlanOverviewScreen
import com.endurancevault.app.ui.screens.TodayScreen
import com.endurancevault.app.ui.screens.HuaweiWatchSection

private enum class Tab(val route: String, val label: String, val icon: ImageVector) {
    Today("today", "Hari ini", Icons.Filled.Home),
    Profile("profile", "Profil", Icons.Filled.Person),
    Watch("watch", "Jam", Icons.Filled.Favorite),
    Week("week", "Minggu", Icons.Filled.CalendarMonth),
    Schedule("schedule", "Jadwal", Icons.Filled.CalendarMonth),
}

@Composable
fun AppRoot(vm: MainViewModel = viewModel()) {
    val nav = rememberNavController()
    val state by vm.state.collectAsState()
    val current = nav.currentBackStackEntryAsState().value?.destination?.route
    // Jadwal is a contextual destination: it exists only while a training plan is selected.
    val hasTrainingPlan = state.settings.rtype != "none"
    LaunchedEffect(hasTrainingPlan, current) {
        if (!hasTrainingPlan && current == Tab.Schedule.route) {
            nav.navigate(Tab.Week.route) { popUpTo(Tab.Today.route); launchSingleTop = true }
        }
    }
    val tabs = buildList {
        add(Tab.Today); add(Tab.Profile); add(Tab.Watch); add(Tab.Week)
        if (hasTrainingPlan) add(Tab.Schedule)
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentColor = MaterialTheme.colorScheme.onBackground,
        bottomBar = {
            // Dock mengikuti pola aplikasi lama: transparan, empat tujuan utama,
            // Today menjadi tombol utama; Jadwal hanya muncul ketika plan aktif.
            Surface(color = MaterialTheme.colorScheme.background, tonalElevation = 0.dp) {
                Column {
                    if (current == Tab.Profile.route || current == "progress") {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 3.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            FilterChip(
                                selected = current == Tab.Profile.route,
                                onClick = { nav.navigate(Tab.Profile.route) { launchSingleTop = true } },
                                label = { Text("Profil") },
                            )
                            androidx.compose.foundation.layout.Spacer(Modifier.size(8.dp))
                            FilterChip(
                                selected = current == "progress",
                                onClick = { nav.navigate("progress") { launchSingleTop = true } },
                                label = { Text("Progres") },
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 14.dp, vertical = 5.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                    tabs.forEach { t ->
                        val selected = current == t.route || (t == Tab.Profile && current == "progress")
                        val isHome = t == Tab.Today
                        Column(
                            modifier = Modifier
                                .weight(if (isHome) 1.18f else 1f)
                                .height(54.dp)
                                .then(
                                    if (isHome && selected) Modifier
                                        .shadow(1.dp, RoundedCornerShape(14.dp))
                                        .then(Modifier)
                                    else Modifier
                                )
                                .background(
                                    if (isHome && selected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    RoundedCornerShape(14.dp),
                                )
                                .clickable {
                                    nav.navigate(t.route) {
                                        popUpTo(Tab.Today.route) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                                .padding(vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                        ) {
                            Icon(
                                t.icon,
                                contentDescription = t.label,
                                modifier = Modifier.size(20.dp),
                                tint = when {
                                    isHome && selected -> MaterialTheme.colorScheme.onPrimary
                                    selected -> MaterialTheme.colorScheme.primary
                                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                                },
                            )
                            Text(
                                t.label,
                                maxLines = 1,
                                style = MaterialTheme.typography.labelSmall,
                                color = when {
                                    isHome && selected -> MaterialTheme.colorScheme.onPrimary
                                    selected -> MaterialTheme.colorScheme.primary
                                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                                },
                            )
                        }
                    }
                    }
                }
            }
        },
    ) { pad ->
        NavHost(nav, startDestination = Tab.Today.route, modifier = Modifier.padding(pad)) {
            composable(Tab.Today.route) {
                val weather by vm.weatherMessage.collectAsState()
                val weatherBusy by vm.weatherBusy.collectAsState()
                val weatherPlace by vm.weatherPlace.collectAsState()
                TodayScreen(
                    state = state, onAdd = vm::addActivity, weatherMessage = weather, weatherPlace = weatherPlace,
                    weatherBusy = weatherBusy, onRefreshWeather = {
                        val lat = vm.weatherLat.value.toDoubleOrNull() ?: -6.99
                        val lon = vm.weatherLon.value.toDoubleOrNull() ?: 110.42
                        vm.fetchWeather(lat, lon, weatherPlace)
                    },
                    onOpenActivity = { id -> nav.navigate("activity/$id") },
                    onGoWeek = { nav.navigate(Tab.Week.route) { launchSingleTop = true } },
                )
            }
            composable("progress") {
                val trackMsg by vm.trackMsg.collectAsState()
                ProgressScreen(
                    state = state,
                    onDelete = vm::deleteActivity,
                    onOpen = { id -> nav.navigate("activity/$id") },
                    onImportTracks = vm::importTracks,
                    trackMsg = trackMsg,
                )
            }
            composable(Tab.Week.route) { ScheduleScreen(state) { id -> nav.navigate("activity/$id") } }
            composable(Tab.Schedule.route) {
                if (hasTrainingPlan) PlanOverviewScreen(state) else TodayScreen(state, vm::addActivity)
            }
            composable(Tab.Watch.route) {
                val watchMsg by vm.watchMessage.collectAsState()
                val watchSyncing by vm.watchSyncing.collectAsState()
                val watchAdvancedMessage by vm.watchAdvancedMessage.collectAsState()
                val liveHr by vm.liveHrJson.collectAsState()
                androidx.compose.foundation.lazy.LazyColumn(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 18.dp, bottom = 24.dp),
                ) {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text("PERANGKAT", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            Text("Jam", style = MaterialTheme.typography.headlineMedium)
                            Text("Koneksi dan sinkronisasi perangkat", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    item {
                        HuaweiWatchSection(
                            message = watchMsg, onConnect = vm::connectWatch, onDisconnect = vm::disconnectWatch,
                            onForgetAndReconnect = vm::forgetAndReconnectWatch, onSync = vm::syncWatch,
                            isSyncing = watchSyncing, settings = state.settings, advancedMessage = watchAdvancedMessage,
                            liveHr = liveHr, onRefreshLiveHr = vm::refreshLiveHr, onSetLiveHr = vm::setLiveHr,
                            onSyncHrZones = vm::syncWatchHrZones, onPushWorkout = vm::pushStructuredWorkout,
                            onPushRoute = vm::pushGpxRoute, onSaveSettings = vm::saveSettings, daily = state.daily,
                        )
                    }
                }
            }
            composable("activity/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
                ActivityDetailScreen(state, e.arguments?.getLong("id") ?: -1L, vm::detailOf) { nav.popBackStack() }
            }
            composable(Tab.Profile.route) {
                val imp by vm.importState.collectAsState()
                val watchMsg by vm.watchMessage.collectAsState()
                val watchSyncing by vm.watchSyncing.collectAsState()
                val watchAdvancedMessage by vm.watchAdvancedMessage.collectAsState()
                val liveHr by vm.liveHrJson.collectAsState()
                val weather by vm.weatherMessage.collectAsState()
                val weatherBusy by vm.weatherBusy.collectAsState()
                val weatherLat by vm.weatherLat.collectAsState()
                val weatherLon by vm.weatherLon.collectAsState()
                val weatherWatchStatus by vm.weatherWatchStatus.collectAsState()
                val agpsStatus by vm.agpsStatus.collectAsState()
                val notifyStatus by vm.notifyStatus.collectAsState()
                val aiStatus by vm.aiStatus.collectAsState()
                val aiMessages by vm.aiMessages.collectAsState()
                val aiBusy by vm.aiBusy.collectAsState()
                val duplicateStatus by vm.duplicateStatus.collectAsState()
                ProfileScreen(
                    state, vm::saveSettings, imp, vm::startImport, vm::confirmImport, vm::dismissImport, vm::mergeDuplicateActivities, duplicateStatus,
                    vm::saveDaily, vm::saveGear, vm::deleteGear,
                    watchMsg, vm::connectWatch, vm::disconnectWatch, vm::forgetAndReconnectWatch, vm::syncWatch, watchSyncing,
                    watchAdvancedMessage, liveHr, vm::refreshLiveHr, vm::setLiveHr, vm::syncWatchHrZones,
                    vm::pushStructuredWorkout, vm::pushGpxRoute,
                    weather, weatherBusy, weatherLat, weatherLon, { lat, lon -> vm.fetchWeather(lat, lon) }, { q -> vm.searchWeatherCity(q) }, vm::useCurrentLocation, { lat, lon, name -> vm.sendWeatherToWatch(lat, lon, name) },
                    weatherWatchStatus, agpsStatus, { enabled, mirror -> vm.setAgps(enabled, mirror) }, { vm.testAgps() },
                    notifyStatus, { enabled, quiet, start, end, screenOff, apps -> vm.setWatchNotifications(enabled, quiet, start, end, screenOff, apps) }, { vm.testWatchNotification() },
                    aiStatus, aiMessages, vm::saveAiKey, vm::sendAiQuestion, aiBusy,
                )
            }
        }
    }
}
