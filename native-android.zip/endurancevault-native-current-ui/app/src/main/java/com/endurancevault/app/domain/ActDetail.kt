package com.endurancevault.app.domain

class Split(
    val k: Double, val pace: Double, val hr: Int?, val gain: Int, val loss: Int,
    val cad: Int?, val gap: Double?, val partial: Boolean,
)

class Segment(
    val k: Double, val d: Double, val min: Double, val pace: Double, val hr: Int?,
    val gain: Int, val loss: Int, val cad: Int?, val name: String, val type: String?,
)

/** Detail satu aktivitas, dibaca dari objek aktivitas format web (rt, pf, sp, sg, h, dst.). */
class ActDetail(
    val date: String, val startTime: String, val name: String, val bike: Boolean, val kind: String?,
    val km: Double, val movingMin: Double, val elapsedMin: Double,
    val gain: Int?, val loss: Int?, val hr: Int?, val hrMax: Int?, val cad: Int?, val gapPace: Double?,
    val splits: List<Split>, val segments: List<Segment>,
    /** titik rute dinormalkan 0..1000 (x ke kanan, y ke bawah), lebar rw dan tinggi rh */
    val route: List<Pair<Int, Int>>, val routeW: Int, val routeH: Int,
    val profile: List<Pair<Double, Double>>,       // (km, elevasi m)
    val paceSeries: List<Pair<Double, Double>>,    // (km, menit/km)
    val hrSeries: List<Pair<Double, Double>>,
    val cadSeries: List<Pair<Double, Double>>,
    val hrHist: Map<Int, Double>,                  // bpm -> detik
    val weatherTempC: Double? = null,
    val weatherFeelsLikeC: Double? = null,
    /** Seri HR dan kecepatan GAP per bucket 5 detik gerak dari pipeline easy-run lama. */
    val easyHrBuckets: List<Int> = emptyList(),
    val easySpeedBuckets: List<Int> = emptyList(),
    val easyRun: EasyRunAnnotation? = null,
    val strideStartSec: Int? = null,
    /** Deret waktu 1 Hz hasil impor/resampling; null menandakan sampel tidak tersedia. */
    val timeSeries: ActivityTimeSeries? = null,
) {
    val avgPace: Double? get() = if (km > 0 && movingMin > 0) movingMin / km else null
    val hasRoute: Boolean get() = route.size >= 2
}

/** Penanda sesi easy-run yang disimpan pada objek aktivitas lama (`ez`). */
data class EasyRunAnnotation(
    val enabled: Boolean,
    val kind: String?,
    val strideStartSec: Int?,
    val strideDisabled: Boolean,
)


/** Data aktivitas tersinkron pada detik bergerak. Nilai nol pada HR/GAP berarti tidak ada sampel valid. */
data class ActivityTimeSeries(
    val seconds: List<Int>,
    val distanceMeters: List<Double>,
    val heartRateBpm: List<Int>,
    val cadenceSpm: List<Int>,
    val elevationMeters: List<Double?>,
    val gapSpeedCmPerSec: List<Int>,
    val grade: List<Double?>,
)
