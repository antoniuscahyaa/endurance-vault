package com.endurancevault.app.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.endurancevault.app.domain.ActivityAnalytics
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.ui.UiState
import java.time.LocalDate
import java.time.DayOfWeek
import java.time.YearMonth
import kotlin.math.roundToInt

private enum class ProgressTab(val label: String) {
    RECAP("Recap"), FITNESS("Fitness"), LOAD("Load"), ROUTES("Routes & conditions"), BODY("Body")
}

@Composable
fun ProgressScreen(
    state: UiState, onDelete: (Long) -> Unit, onOpen: (Long) -> Unit,
    onImportTracks: (List<Uri>) -> Unit, trackMsg: String?,
) {
    var selected by remember { mutableStateOf(ProgressTab.RECAP) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> if (uris.isNotEmpty()) onImportTracks(uris) }
    val summary = ActivityAnalytics.summarize(state.activities)
    val weeks = (state.plan as? PlanOutcome.Ok)?.weeks.orEmpty()
    val thisWeek = weeks.firstOrNull { !LocalDate.now().isBefore(it.start) && LocalDate.now().isBefore(it.start.plusDays(7)) }
    val done = thisWeek?.let { w ->
        state.activities.filter {
            if (it.type == "bike") return@filter false
            val d = LocalDate.parse(it.dateIso); !d.isBefore(w.start) && d.isBefore(w.start.plusDays(7))
        }.sumOf { it.km }
    } ?: 0.0
    val runs = state.activities.filter { it.type != "bike" && it.km > 0 && it.durationSec > 0 }
    val sortedRuns = runs.sortedBy { it.dateIso }
    val today = LocalDate.now()
    val currentMonday = today.with(DayOfWeek.MONDAY)
    val recentWeeks = (0..3).map { start ->
        val from = currentMonday.minusWeeks((3-start).toLong())
        val to = from.plusDays(7)
        runs.filter { runCatching { LocalDate.parse(it.dateIso) }.getOrNull()?.let { d -> !d.isBefore(from) && d.isBefore(to) } == true }
    }
    val monthRuns = runs.filter { runCatching { YearMonth.from(LocalDate.parse(it.dateIso)) == YearMonth.from(today) }.getOrDefault(false) }
    val activeDays = runs.mapNotNull { runCatching { LocalDate.parse(it.dateIso) }.getOrNull() }
        .filter { it.year == today.year }.distinct().size
    val plannedRunDays = thisWeek?.days?.filter { it.kind != com.endurancevault.app.domain.Kinds.REST && it.kind != com.endurancevault.app.domain.Kinds.EVENT && it.kind != com.endurancevault.app.domain.Kinds.RACE }.orEmpty()
    val completedRunDays = plannedRunDays.count { day -> runs.any { it.dateIso == day.date.toString() } }
    val adherencePct = if (plannedRunDays.isNotEmpty()) (completedRunDays * 100.0 / plannedRunDays.size).roundToInt() else null
    val latestDaily = state.daily.firstOrNull { it.dateIso == today.toString() } ?: state.daily.maxByOrNull { it.dateIso }

    Column(Modifier.fillMaxSize()) {
        when (selected) {
            ProgressTab.RECAP -> {
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    ProgressHeader("RECAP", "Ringkasan latihan dan konsistensi")
                    ProgressCard("PROGRESS", "${weeks.count { it.start <= today }} weeks", "Rencana berjalan") {
                        Text("Rata-rata ${fmtKmUi(if (weeks.isNotEmpty()) weeks.take(4).map { it.km }.average() else 0.0)} km per minggu")
                        LinearProgressIndicator(progress = { if (weeks.isNotEmpty()) weeks.count { it.start <= today }.toFloat() / weeks.size else 0f }, modifier = Modifier.fillMaxWidth())
                        Text("${weeks.count { it.start <= today }} / ${weeks.size} minggu", style = MaterialTheme.typography.labelSmall)
                    }
                    ProgressCard("WEEKLY CHART", "${fmtKmUi(done)} km", "Volume minggu ini · 8 minggu") {
                        ActivityVolumeChart(state.activities)
                        Text("Rata-rata 4 minggu: ${fmtKmUi(recentWeeks.map { w -> w.sumOf { it.km } }.average().takeIf { it.isFinite() } ?: 0.0)} km")
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ProgressCard("PLAN ADHERENCE", adherencePct?.let { "$it%" } ?: "—", "Sesi lari selesai minggu ini", Modifier.weight(1f)) {
                            Text("$completedRunDays / ${plannedRunDays.size} sesi")
                        }
                        ProgressCard("WEEKLY REVIEW", thisWeek?.let { "${if (it.km > 0) (done / it.km * 100).roundToInt() else 0}%" } ?: "—", "Realisasi target jarak", Modifier.weight(1f)) {
                            Text("${fmtKmUi(done)} / ${thisWeek?.let { fmtKmUi(it.km) } ?: "—"} km")
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ProgressCard("MONTHLY LOG", "${monthRuns.size}", "Sesi bulan ini", Modifier.weight(1f)) {
                            Text("${fmtKmUi(monthRuns.sumOf { it.km })} km")
                        }
                        ProgressCard("CONSISTENCY", "$activeDays hari", "Hari aktif tersimpan", Modifier.weight(1f)) {
                            Text("Tahun ${today.year}")
                        }
                    }
                    ProgressCard("YEARLY HEATMAP", "${fmtKmUi(runs.filter { it.dateIso.startsWith(today.year.toString()) }.sumOf { it.km })} km", "Jarak per hari · tahun ${today.year}") {
                        YearHeatmap(runs, today.year)
                    }
                    ProgressCard("ACTIVITY SUMMARY", "${summary.runCount} runs", "Semua aktivitas lari tersimpan") {
                        MetricLine("Total distance", "${fmtKmUi(summary.totalKm)} km")
                        MetricLine("Longest run", summary.longestKm?.let { "${fmtKmUi(it)} km" } ?: "—")
                        MetricLine("28 days", "${fmtKmUi(summary.last28Km)} km · ${summary.last28Runs} runs")
                    }
                }
            }
            ProgressTab.FITNESS -> {
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    ProgressHeader("FITNESS", "Fitness, recovery, dan kemampuan lari")
                    TrainingLoadSection(state)
                    val rai = com.endurancevault.app.domain.ProgressAnalytics.runningAbility(state.settings, state.activities, state.daily)
                    ProgressCard("RUNNING FITNESS", rai?.let { "%.1f".format(it.value) } ?: "—", rai?.let { "from last ${it.runs} eligible runs" } ?: "Butuh minimal 3 lari ≥3 km dengan HR") {
                        val m = com.endurancevault.app.domain.TrainingMetrics.calculate(state.settings, state.activities, state.daily, state.plan, hrHistByActivity = state.hrHistByActivity)
                        val ab = rai?.let { ((it.value - 20) / 45 * 100).coerceIn(0.0, 100.0) }
                        val fit = if (ab != null) (.7 * ab + .3 * m.fitness).roundToInt() else m.fitness
                        val fatigue = if (m.fitness > 8) (10 + (m.ratio - .6) * 90).coerceIn(0.0, 100.0).roundToInt() else m.fatigue
                        MetricLine("Fitness RAI", "$fit · ${fitLabelNative(fit)}")
                        MetricLine("Fatigue RAI", "$fatigue · ${fatLabelNative(fatigue)}")
                        MetricLine("Recovery", if (m.recoveryRemainingHours < 2) "Ready" else "${m.recoveryRemainingHours} h")
                        rai?.weekly?.takeLast(5)?.forEach { MetricLine(it.first.toString(), "%.1f".format(it.second)) }
                    }
                    ProgressCard("PERSONAL RECORD", "${runs.size} runs", "Best full-kilometre splits from imported activity detail") {
                        val prs = com.endurancevault.app.domain.ProgressAnalytics.personalBests(state.detailsByActivity)
                        listOf("1 km", "5K", "10K", "Half marathon").forEach { label ->
                            val best = prs.firstOrNull { it.label == label }
                            MetricLine(label, best?.let { "${com.endurancevault.app.domain.Js.paceStr(it.durationMinutes / it.distanceKm)} /km · ${formatDurationMinutes(it.durationMinutes)}" } ?: "—")
                        }
                        MetricLine("Longest run", summary.longestKm?.let { "${fmtKmUi(it)} km" } ?: "—")
                    }
                    val easyRuns = com.endurancevault.app.domain.EasyRunAnalytics.calculate(state.detailsByActivity, loadMetricsLthr(state), state.settings.easyRun)
                    ProgressCard("EASY-RUN COMPLIANCE", easyRuns.lastOrNull()?.compliancePct?.let { "%.1f%%".format(it) } ?: "—", "Kepatuhan HR · bucket 5 detik · pemanasan dibuang") {
                        easyRuns.takeLast(14).asReversed().forEach { r ->
                            MetricLine(r.date.toString(), "${r.kind} · ${r.compliancePct?.let { "%.1f%%".format(it) } ?: "—"} · ${r.verdict}")
                            if (r.score != null) Text("Score ${r.score} · drift ${r.driftPct?.let { "%.1f%%".format(it) } ?: "—"} · stability ${r.stabilityCv?.let { "%.1f%%".format(it) } ?: "—"}", style = MaterialTheme.typography.bodySmall)
                        }
                        if (easyRuns.isEmpty()) Text("Belum ada aktivitas dengan penanda easy-run dan data HR yang sesuai.")
                        else Text("Legacy histogram-only: ${easyRuns.count { it.legacyHistogramOnly }} sesi. Seri per detik dipakai bila tersedia.", style = MaterialTheme.typography.bodySmall)
                    }
                    ProgressCard("PACE ZONES FROM RAI", "Pace zones", "Zona pace datar dari Running Ability Index") {
                        val raiValue = rai?.value
                        if (raiValue == null) Text("Belum cukup data HR dan pace untuk membentuk zona pace RAI.")
                        else listOf("Easy" to (.62 to .74), "Tempo" to (.80 to .87), "Threshold" to (.88 to .92), "VO₂max" to (.95 to 1.0)).forEach { (label, f) ->
                            val lo = paceAtRai(raiValue, f.first)
                            val hi = paceAtRai(raiValue, f.second)
                            MetricLine(label, "${com.endurancevault.app.domain.Js.paceStr(hi)} – ${com.endurancevault.app.domain.Js.paceStr(lo)} /km")
                        }
                        Text("Untuk jalan datar. Di tanjakan atau cuaca panas, ikuti HR dan rasa usaha, bukan pace.", style = MaterialTheme.typography.bodySmall)
                    }
                    ProgressCard("AEROBIC EFFICIENCY & CARDIAC DRIFT", "—", "Perlu stream HR dan pace per waktu") {
                        Text("Data ringkasan aktivitas saja belum cukup untuk menghitung efisiensi aerobik dan cardiac drift secara sahih. Impor FIT/TCX dengan data HR dan detail aktivitas diperlukan.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            ProgressTab.LOAD -> {
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    ProgressHeader("LOAD", "Beban latihan dan distribusi intensitas")
                    TrainingLoadSection(state)
                    val loadMetrics = com.endurancevault.app.domain.TrainingMetrics.calculate(state.settings, state.activities, state.daily, state.plan, today, hrHistByActivity = state.hrHistByActivity)
                    val acwr = com.endurancevault.app.domain.ProgressAnalytics.acuteChronic(loadMetrics.days, today)
                    val mono = com.endurancevault.app.domain.ProgressAnalytics.monotonyStrain(loadMetrics.days, today)
                    ProgressCard("ACWR, MONOTONY & STRAIN", acwr?.let { "%.2f".format(it.ratio) } ?: "—", "Acute : chronic workload · 28 days") {
                        MetricLine("Acute 7 days", acwr?.let { "%.1f".format(it.acute) } ?: "—")
                        MetricLine("Chronic 28 days", acwr?.let { "%.1f".format(it.chronic) } ?: "—")
                        MetricLine("Monotony · 7 days", mono?.let { "%.2f".format(it.monotony) } ?: "—")
                        MetricLine("Strain", mono?.let { "%.0f".format(it.strain) } ?: "—")
                        Text("ACWR memakai total 7 hari dibagi rata-rata mingguan 28 hari. Monotony = rerata beban harian / simpangan baku 7 hari; strain = total beban × monotony.", style = MaterialTheme.typography.bodySmall)
                    }
                    ProgressCard("80/20 INTENSITY", "HR distribution", "Distribusi waktu berdasarkan histogram HR") {
                        val dist = com.endurancevault.app.domain.ProgressAnalytics.intensity(state.hrHistByActivity.values, loadMetrics.lthr, loadMetrics.hrMax)
                        if (dist == null) Text("Belum ada histogram HR aktivitas yang cukup.")
                        else {
                            MetricLine("Z1–2", "%.1f%%".format(dist.z1z2))
                            MetricLine("Z3", "%.1f%%".format(dist.z3))
                            MetricLine("Z4–5", "%.1f%%".format(dist.z4z5))
                            Text("Total sampel ${(dist.totalSeconds / 3600).format1()} jam.")
                        }
                    }
                }
            }
            ProgressTab.ROUTES -> {
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    ProgressHeader("ROUTES & CONDITIONS", "Analisis rute dan pengaruh kondisi")
                    val withDetail = runs.mapNotNull { a -> state.detailsByActivity[a.id]?.let { a to it } }
                    var compareA by remember(withDetail.map { it.first.id }) { mutableStateOf(withDetail.lastOrNull()?.first?.id) }
                    var compareB by remember(withDetail.map { it.first.id }) { mutableStateOf(withDetail.dropLast(1).lastOrNull()?.first?.id) }
                    val routeGroups = com.endurancevault.app.domain.ProgressAnalytics.similarRoutes(
                        withDetail.filter { it.second.hasRoute }.map { (a,d) ->
                            com.endurancevault.app.domain.RouteActivity(a.id, a.dateIso, a.km, d.route)
                        }
                    )
                    ProgressCard("SIMILAR ROUTES", "${routeGroups.size} groups", "Kelompok rute dari geometri GPS · km ±12%") {
                        routeGroups.take(8).forEach { group ->
                            MetricLine("${group.representative.dateIso} · ${fmtKmUi(group.representative.km)} km", "×${group.members.size}")
                            Text(group.members.joinToString(" · ") { it.dateIso }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (routeGroups.isEmpty()) Text("Belum ada dua aktivitas dengan bentuk rute dan jarak yang cukup mirip.")
                    }
                    ProgressCard("COMPARE ACTIVITIES", "${withDetail.size} activities", "Pilih dua aktivitas ber-detail") {
                        val choices = withDetail.takeLast(30)
                        if (choices.size >= 2) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Column(Modifier.weight(1f)) {
                                    Text("Aktivitas A", style = MaterialTheme.typography.labelSmall)
                                    choices.forEach { (a, _) -> Row(Modifier.fillMaxWidth().clickable { compareA = a.id }.padding(vertical = 3.dp)) { Text((if (compareA == a.id) "● " else "○ ") + a.dateIso, style = MaterialTheme.typography.bodySmall) } }
                                }
                                Column(Modifier.weight(1f)) {
                                    Text("Aktivitas B", style = MaterialTheme.typography.labelSmall)
                                    choices.forEach { (a, _) -> Row(Modifier.fillMaxWidth().clickable { compareB = a.id }.padding(vertical = 3.dp)) { Text((if (compareB == a.id) "● " else "○ ") + a.dateIso, style = MaterialTheme.typography.bodySmall) } }
                                }
                            }
                            val a = choices.firstOrNull { it.first.id == compareA }
                            val b = choices.firstOrNull { it.first.id == compareB }
                            if (a != null && b != null && a.first.id != b.first.id) {
                                MetricLine("Distance", "${fmtKmUi(a.first.km)} / ${fmtKmUi(b.first.km)} km")
                                MetricLine("Pace", "${com.endurancevault.app.domain.Js.paceStr(a.second.avgPace ?: 0.0)} / ${com.endurancevault.app.domain.Js.paceStr(b.second.avgPace ?: 0.0)}")
                                MetricLine("HR", "${a.second.hr ?: "—"} / ${b.second.hr ?: "—"} bpm")
                                MetricLine("Elevation", "${a.second.gain ?: 0} / ${b.second.gain ?: 0} m")
                            }
                        } else Text("Minimal dua aktivitas dengan detail FIT/GPX/TCX diperlukan.")
                    }
                    ProgressCard("ROUTE HEATMAP & RIDGELINE", "${withDetail.count { it.second.hasRoute }} routes", "Data rute dan profil elevasi") {
                        MetricLine("Total elevation gain", "${withDetail.sumOf { it.second.gain ?: 0 }} m")
                        withDetail.filter { it.second.profile.size >= 2 }.takeLast(5).forEach { (a, d) ->
                            Text("${a.dateIso} · ${fmtKmUi(a.km)} km · ${d.profile.size} titik elevasi", style = MaterialTheme.typography.bodySmall)
                            ElevationMiniChart(d.profile)
                        }
                    }
                    ProgressCard("WEATHER IMPACT", "Weather history", "Kondisi cuaca saat aktivitas") {
                        val weatherRows = withDetail.mapNotNull { (a,d) -> d.weatherTempC?.let { Triple(a, it, d.weatherFeelsLikeC) } }
                        if (weatherRows.isEmpty()) Text("Arsip cuaca historis belum tersedia pada data aktivitas ini.")
                        else {
                            val grouped = weatherRows.groupBy { (_, t, _) -> when { t < 24 -> "<24°C"; t < 28 -> "24–28°C"; else -> "≥28°C" } }
                            listOf("<24°C", "24–28°C", "≥28°C").forEach { band ->
                                val rows = grouped[band].orEmpty()
                                if (rows.isNotEmpty()) {
                                    MetricLine(band, "${rows.size} runs · avg pace ${com.endurancevault.app.domain.Js.paceStr(rows.map { it.first.durationSec / 60.0 / it.first.km }.average())}/km")
                                }
                            }
                            weatherRows.takeLast(10).forEach { (a,t,fl) -> MetricLine(a.dateIso, "%.1f°C".format(t) + (fl?.let { " · feels %.1f°C".format(it) } ?: "")) }
                        }
                    }
                }
            }
            ProgressTab.BODY -> {
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    ProgressHeader("BODY", "Tidur, kondisi, dan latihan kekuatan")
                    ProgressCard("SLEEP AND CONDITION", latestDaily?.sleepH?.let { "%.1f h".format(it) } ?: "—", latestDaily?.dateIso ?: "Belum ada data harian") {
                        MetricLine("Resting HR", latestDaily?.rhr?.let { "$it bpm" } ?: "—")
                        MetricLine("HRV", latestDaily?.hrv?.let { "$it ms" } ?: "—")
                        MetricLine("Leg feel", latestDaily?.leg?.let { "$it / 5" } ?: "Belum diisi")
                        MetricLine("Mood", latestDaily?.mood?.let { "$it / 5" } ?: "Belum diisi")
                    }
                    val strengthDays = weeks.flatMap { it.days }.filter { listOfNotNull(it.str, it.ank, it.up).isNotEmpty() }
                    ProgressCard("STRENGTH PROGRESS", "${state.strengthWorkouts.size} completed workouts", "Workout strength yang disinkronkan dari jam") {
                        state.strengthWorkouts.takeLast(20).asReversed().forEach { w ->
                            MetricLine(w.dateIso, "${w.minutes} min · ${w.avgHr?.let { "$it bpm" } ?: "HR —"} · ${w.calories?.let { "$it kcal" } ?: "—"}")
                            Text(when { w.free -> "Free Strength"; w.linkedKey != null -> "Linked: ${w.linkedKey}"; else -> "Imported strength" }, style = MaterialTheme.typography.bodySmall)
                        }
                        MetricLine("Planned strength days", strengthDays.size.toString())
                        Text("Workout strength tetap terpisah dari aktivitas lari dan tidak masuk mileage, PR, atau training load.", style = MaterialTheme.typography.bodySmall)
                    }
                    ProgressCard("STRENGTH BALANCE", "Session history", "Data aktual yang tersedia dari jam") {
                        val avgHr = state.strengthWorkouts.mapNotNull { it.avgHr }.takeIf { it.isNotEmpty() }?.average()
                        val total = state.strengthWorkouts.sumOf { it.minutes }
                        MetricLine("Total duration", "$total min")
                        MetricLine("Average HR", avgHr?.let { "${it.roundToInt()} bpm" } ?: "—")
                        MetricLine("HR records", state.strengthWorkouts.count { it.avgHr != null }.toString())
                        Text("Distribusi kelompok otot belum dapat dihitung karena workout dari jam tidak menyimpan set, repetisi, atau identitas gerakan.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        Surface(tonalElevation = 2.dp, color = MaterialTheme.colorScheme.surface) {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ProgressTab.values().forEach { tab ->
                    FilterChip(
                        selected = selected == tab,
                        onClick = { selected = tab },
                        label = { Text(tab.label) },
                    )
                }
            }
        }
    }
}

@Composable private fun ProgressHeader(kicker: String, title: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(kicker, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
        Text(title, style = MaterialTheme.typography.titleLarge)
    }
}

@Composable private fun ProgressCard(
    label: String, value: String, subtitle: String, modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    EvPanel(modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            Text(value, style = MaterialTheme.typography.headlineSmall)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            content()
        }
    }
}

@Composable private fun MetricLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable private fun YearHeatmap(runs: List<com.endurancevault.app.data.ActivityEntity>, year: Int) {
    val byDate = runs.groupBy { it.dateIso }.mapValues { (_, rows) -> rows.sumOf { it.km } }
    val first = LocalDate.of(year, 1, 1)
    val start = first.minusDays((first.dayOfWeek.value - 1).toLong())
    val max = byDate.values.maxOrNull()?.coerceAtLeast(1.0) ?: 1.0
    val accent = MaterialTheme.colorScheme.primary
    val empty = MaterialTheme.colorScheme.outlineVariant
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        repeat(7) { day ->
            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                repeat(53) { week ->
                    val date = start.plusDays((week * 7 + day).toLong())
                    val v = if (date.year == year) byDate[date.toString()] ?: 0.0 else 0.0
                    val alpha = if (v <= 0) .12f else (.25f + .75f * (v / max).toFloat()).coerceIn(.25f, 1f)
                    Canvas(Modifier.weight(1f).height(8.dp)) {
                        drawRoundRect((if (v > 0) accent else empty).copy(alpha = alpha), cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx()))
                    }
                }
            }
        }
    }
    Text("Jarak harian · intensitas warna mengikuti volume lari", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun ActivityVolumeChart(activities: List<com.endurancevault.app.data.ActivityEntity>) {
    val today = LocalDate.now()
    val currentMonday = today.with(DayOfWeek.MONDAY)
    val starts = (7 downTo 0).map { currentMonday.minusWeeks(it.toLong()) }
    val values = starts.map { start ->
        activities.filter { a ->
            if (a.type == "bike") return@filter false
            val date = runCatching { LocalDate.parse(a.dateIso) }.getOrNull() ?: return@filter false
            !date.isBefore(start) && date.isBefore(start.plusDays(7))
        }.sumOf { it.km }
    }
    val maxValue = (values.maxOrNull() ?: 0.0).coerceAtLeast(1.0)
    val accent = MaterialTheme.colorScheme.primary
    val muted = MaterialTheme.colorScheme.outlineVariant
    Canvas(Modifier.fillMaxWidth().height(116.dp)) {
        val left = 4.dp.toPx(); val right = 4.dp.toPx()
        val top = 8.dp.toPx(); val bottom = 8.dp.toPx()
        val usableW = size.width - left - right
        val usableH = size.height - top - bottom
        repeat(3) { i ->
            val y = top + usableH * (i / 2f)
            drawLine(muted.copy(alpha = .55f), Offset(left, y), Offset(size.width-right, y), 1.dp.toPx())
        }
        val slot = usableW / values.size
        values.forEachIndexed { i, value ->
            val h = (value / maxValue).toFloat() * usableH
            val barW = slot * .54f
            val x = left + slot * i + (slot - barW) / 2f
            drawRoundRect(
                color = if (i == values.lastIndex) accent else accent.copy(alpha = .48f),
                topLeft = Offset(x, top + usableH - h),
                size = androidx.compose.ui.geometry.Size(barW, h.coerceAtLeast(2.dp.toPx())),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(5.dp.toPx()),
            )
        }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text("8 pekan lalu", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("Pekan ini", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
    }
    Text("${fmtKmUi(values.last())} km pekan ini", style = MaterialTheme.typography.titleSmall)
}


private fun fitLabelNative(value: Int): String = when {
    value >= 85 -> "Excellent"
    value >= 70 -> "Very good"
    value >= 55 -> "Good"
    value >= 40 -> "Moderate"
    else -> "Building"
}

private fun fatLabelNative(value: Int): String = when {
    value >= 85 -> "Very high"
    value >= 70 -> "High"
    value >= 50 -> "Elevated"
    value >= 30 -> "Moderate"
    else -> "Low"
}

private fun formatDurationMinutes(minutes: Double): String {
    val total = (minutes * 60.0).toInt().coerceAtLeast(0)
    return "%d:%02d".format(total / 60, total % 60)
}

private fun loadMetricsLthr(state: UiState): Int =
    (state.settings.lthr ?: state.settings.hrMax?.let { it * 0.85 } ?: 160.0).toInt()

/** Pace datar (menit/km) estimasi dari RAI dan fraksi intensitas. */
private fun paceAtRai(rai: Double, fraction: Double): Double {
    val vo2 = 3.5 + (rai - 3.5) * fraction
    // Inversi persamaan VO2 = -4.6 + 0.182258*v + 0.000104*v², v dalam m/menit.
    val a = 0.000104
    val b = 0.182258
    val c = -4.6 - vo2
    val velocity = (-b + kotlin.math.sqrt(b*b - 4*a*c)) / (2*a)
    return if (velocity > 0) 1000.0 / velocity else 12.0
}

private fun Double.format1(): String = "%.1f".format(this)

@Composable
private fun ElevationMiniChart(profile: List<Pair<Double, Double>>) {
    if (profile.size < 2) return
    val values = profile.map { it.second }
    val low = values.minOrNull() ?: 0.0
    val span = ((values.maxOrNull() ?: low) - low).coerceAtLeast(1.0)
    val line = MaterialTheme.colorScheme.primary
    val fill = MaterialTheme.colorScheme.primary.copy(alpha = .12f)
    Canvas(Modifier.fillMaxWidth().height(72.dp)) {
        val points = profile.mapIndexed { index, pair ->
            Offset(
                x = size.width * index / (profile.size - 1).toFloat(),
                y = size.height - ((pair.second - low) / span).toFloat() * (size.height - 8.dp.toPx()) - 4.dp.toPx(),
            )
        }
        val path = Path().apply {
            moveTo(points.first().x, points.first().y)
            points.drop(1).forEach { lineTo(it.x, it.y) }
        }
        val area = Path().apply {
            addPath(path)
            lineTo(points.last().x, size.height)
            lineTo(points.first().x, size.height)
            close()
        }
        drawPath(area, fill)
        drawPath(path, line, style = Stroke(width = 2.dp.toPx()))
    }
    Text("${low.toInt()}–${(values.maxOrNull() ?: low).toInt()} m", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}
