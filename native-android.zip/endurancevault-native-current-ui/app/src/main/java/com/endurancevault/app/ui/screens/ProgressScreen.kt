package com.endurancevault.app.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ExpandLess
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.endurancevault.app.domain.ActivityAnalytics
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.ui.UiState
import java.time.LocalDate
import java.time.DayOfWeek
import java.time.YearMonth
import kotlin.math.roundToInt

private enum class ProgressTab(val label: String) {
    RECAP("Recap"), FITNESS("Fitness"), LOAD("Load"), ROUTES("Routes & conditions"), BODY("Body")
}

@Composable
fun ProgressScreen(
    state: UiState, onDelete: (Long) -> Unit, onOpen: (Long) -> Unit,
    onImportTracks: (List<Uri>) -> Unit, trackMsg: String?,
) {
    var selected by remember { mutableStateOf(ProgressTab.RECAP) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> if (uris.isNotEmpty()) onImportTracks(uris) }
    val summary = ActivityAnalytics.summarize(state.activities)
    val weeks = (state.plan as? PlanOutcome.Ok)?.weeks.orEmpty()
    val thisWeek = weeks.firstOrNull { !LocalDate.now().isBefore(it.start) && LocalDate.now().isBefore(it.start.plusDays(7)) }
    val done = thisWeek?.let { w ->
        state.activities.filter {
            if (it.type == "bike") return@filter false
            val d = LocalDate.parse(it.dateIso); !d.isBefore(w.start) && d.isBefore(w.start.plusDays(7))
        }.sumOf { it.km }
    } ?: 0.0
    val runs = state.activities.filter { it.type != "bike" && it.km > 0 && it.durationSec > 0 }
    val sortedRuns = runs.sortedBy { it.dateIso }
    val today = LocalDate.now()
    val currentMonday = today.with(DayOfWeek.MONDAY)
    val recentWeeks = (0..3).map { start ->
        val from = currentMonday.minusWeeks((3-start).toLong())
        val to = from.plusDays(7)
        runs.filter { runCatching { LocalDate.parse(it.dateIso) }.getOrNull()?.let { d -> !d.isBefore(from) && d.isBefore(to) } == true }
    }
    val monthRuns = runs.filter { runCatching { YearMonth.from(LocalDate.parse(it.dateIso)) == YearMonth.from(today) }.getOrDefault(false) }
    val activeDays = runs.mapNotNull { runCatching { LocalDate.parse(it.dateIso) }.getOrNull() }
        .filter { it.year == today.year }.distinct().size
    val plannedRunDays = thisWeek?.days?.filter { it.kind != com.endurancevault.app.domain.Kinds.REST && it.kind != com.endurancevault.app.domain.Kinds.EVENT && it.kind != com.endurancevault.app.domain.Kinds.RACE }.orEmpty()
    val completedRunDays = plannedRunDays.count { day -> runs.any { it.dateIso == day.date.toString() } }
    val adherencePct = if (plannedRunDays.isNotEmpty()) (completedRunDays * 100.0 / plannedRunDays.size).roundToInt() else null
    val latestDaily = state.daily.firstOrNull { it.dateIso == today.toString() } ?: state.daily.maxByOrNull { it.dateIso }

    Column(Modifier.fillMaxSize()) {
        when (selected) {
            ProgressTab.RECAP -> {
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    ProgressHeader("RECAP", "Ringkasan latihan dan konsistensi")
                    ProgressCard("PROGRESS", "${weeks.count { it.start <= today }} weeks", "Rencana berjalan") {
                        Text("Rata-rata ${fmtKmUi(if (weeks.isNotEmpty()) weeks.take(4).map { it.km }.average() else 0.0)} km per minggu")
                        LinearProgressIndicator(progress = { if (weeks.isNotEmpty()) weeks.count { it.start <= today }.toFloat() / weeks.size else 0f }, modifier = Modifier.fillMaxWidth())
                        Text("${weeks.count { it.start <= today }} / ${weeks.size} minggu", style = MaterialTheme.typography.labelSmall)
                    }
                    ProgressCard("WEEKLY CHART", "${fmtKmUi(done)} km", "Volume minggu ini · 8 minggu") {
                        ActivityVolumeChart(state.activities)
                        Text("Rata-rata 4 minggu: ${fmtKmUi(recentWeeks.map { w -> w.sumOf { it.km } }.average().takeIf { it.isFinite() } ?: 0.0)} km")
                        val last8 = (7 downTo 0).map { currentMonday.minusWeeks(it.toLong()) }
                        last8.forEachIndexed { i, start ->
                            val km = state.activities.filter { a -> a.type != "bike" && runCatching { LocalDate.parse(a.dateIso) }.getOrNull()?.let { !it.isBefore(start) && it.isBefore(start.plusDays(7)) } == true }.sumOf { it.km }
                            MetricLine("${start.dayOfMonth}/${start.monthValue}", "${fmtKmUi(km)} km")
                        }
                    }
                    val monthStarts = (11 downTo 0).map { YearMonth.from(today).minusMonths(it.toLong()) }
                    val monthlyKm = monthStarts.map { ym -> runs.filter { runCatching { YearMonth.from(LocalDate.parse(it.dateIso)) == ym }.getOrDefault(false) }.sumOf { it.km } }
                    ProgressCard("12-MONTH VOLUME TREND", "${fmtKmUi(monthlyKm.lastOrNull() ?: 0.0)} km", "Jarak lari per bulan · 12 bulan bergulir") {
                        TrendLineChart(listOf("Jarak" to monthlyKm.map { it.toFloat() }))
                        monthStarts.forEachIndexed { i, ym -> MetricLine("${ym.monthValue}/${ym.year}", "${fmtKmUi(monthlyKm[i])} km · ${runs.count { runCatching { YearMonth.from(LocalDate.parse(it.dateIso)) == ym }.getOrDefault(false) }} sesi") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ProgressCard("PLAN ADHERENCE", adherencePct?.let { "$it%" } ?: "—", "Sesi lari selesai minggu ini", Modifier.weight(1f)) {
                            Text("$completedRunDays / ${plannedRunDays.size} sesi")
                        }
                        ProgressCard("WEEKLY REVIEW", thisWeek?.let { "${if (it.km > 0) (done / it.km * 100).roundToInt() else 0}%" } ?: "—", "Realisasi target jarak", Modifier.weight(1f)) {
                            Text("${fmtKmUi(done)} / ${thisWeek?.let { fmtKmUi(it.km) } ?: "—"} km")
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ProgressCard("MONTHLY LOG", "${monthRuns.size}", "Sesi bulan ini", Modifier.weight(1f)) {
                            Text("${fmtKmUi(monthRuns.sumOf { it.km })} km")
                        }
                        ProgressCard("CONSISTENCY", "$activeDays hari", "Hari aktif tersimpan", Modifier.weight(1f)) {
                            Text("Tahun ${today.year}")
                        }
                    }
                    ProgressCard("YEARLY HEATMAP", "${fmtKmUi(runs.filter { it.dateIso.startsWith(today.year.toString()) }.sumOf { it.km })} km", "Jarak per hari · tahun ${today.year}") {
                        YearHeatmap(runs, today.year)
                    }
                    ProgressCard("ACTIVITY SUMMARY", "${summary.runCount} runs", "Semua aktivitas lari tersimpan") {
                        MetricLine("Total distance", "${fmtKmUi(summary.totalKm)} km")
                        MetricLine("Longest run", summary.longestKm?.let { "${fmtKmUi(it)} km" } ?: "—")
                        MetricLine("28 days", "${fmtKmUi(summary.last28Km)} km · ${summary.last28Runs} runs")
                    }
                }
            }
            ProgressTab.FITNESS -> {
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    ProgressHeader("FITNESS", "Fitness, recovery, dan kemampuan lari")
                    TrainingLoadSection(state)
                    val rai = com.endurancevault.app.domain.ProgressAnalytics.runningAbility(state.settings, state.activities, state.daily)
                    ProgressCard("RUNNING FITNESS", rai?.let { "%.1f".format(it.value) } ?: "—", rai?.let { "from last ${it.runs} eligible runs" } ?: "Butuh minimal 3 lari ≥3 km dengan HR") {
                        val m = com.endurancevault.app.domain.TrainingMetrics.calculate(state.settings, state.activities, state.daily, state.plan, hrHistByActivity = state.hrHistByActivity)
                        val ab = rai?.let { ((it.value - 20) / 45 * 100).coerceIn(0.0, 100.0) }
                        val ctS = m.fitness.toDouble().coerceIn(0.0, 100.0)
                        val fit = if (ab != null) (.7 * ab + .3 * ctS).roundToInt() else ctS.roundToInt()
                        val fatBase = if (m.fitness > 8 * m.scale) (10 + (m.ratio - .6) * 90).coerceIn(0.0, 100.0) else m.fatigue.toDouble().coerceIn(0.0, 100.0)
                        val fatigue = (fatBase + m.morningPts).coerceIn(0.0, 100.0).roundToInt()
                        MetricLine("Fitness RAI", "$fit · ${fitLabelUi(fit)}")
                        MetricLine("Fatigue RAI", "$fatigue · ${fatLabelUi(fatigue)}")
                        val rh = m.recoveryRemainingHours
                        MetricLine("Recovery", if (rh < 2) "Pulih" else if (rh >= 48) "${(rh / 24.0 * 10).roundToInt() / 10.0} hari" else "$rh jam")
                        rai?.weekly?.takeLast(5)?.forEach { MetricLine(it.first.toString(), "%.1f".format(it.second)) }
                    }
                    val dailyTrend = state.daily.sortedBy { it.dateIso }.takeLast(30)
                    ProgressCard("MORNING SIGNAL TREND", "${dailyTrend.size} days", "HR istirahat, HRV, dan tidur · 30 hari terakhir") {
                        val rhr = dailyTrend.map { it.rhr?.toFloat() ?: Float.NaN }
                        val hrv = dailyTrend.map { it.hrv?.toFloat() ?: Float.NaN }
                        val sleep = dailyTrend.map { it.sleepH?.toFloat() ?: Float.NaN }
                        TrendLineChart(listOf("RHR" to rhr, "HRV" to hrv, "Tidur" to sleep))
                        MetricLine("RHR terbaru", dailyTrend.lastOrNull { it.rhr != null }?.rhr?.let { "$it bpm" } ?: "—")
                        MetricLine("HRV terbaru", dailyTrend.lastOrNull { it.hrv != null }?.hrv?.let { "$it ms" } ?: "—")
                        MetricLine("Tidur terbaru", dailyTrend.lastOrNull { it.sleepH != null }?.sleepH?.let { "%.1f jam".format(it) } ?: "—")
                        Text("Garis dinormalisasi untuk membandingkan arah tren, bukan skala absolut. Titik kosong tidak diinterpolasi.", style = MaterialTheme.typography.bodySmall)
                    }
                    ProgressCard("PERSONAL RECORD", "${runs.size} runs", "Best full-kilometre splits from imported activity detail") {
                        val prs = com.endurancevault.app.domain.ProgressAnalytics.personalBests(state.detailsByActivity)
                        listOf("1 km", "5K", "10K", "Half marathon").forEach { label ->
                            val best = prs.firstOrNull { it.label == label }
                            MetricLine(label, best?.let { "${com.endurancevault.app.domain.Js.paceStr(it.durationMinutes / it.distanceKm)} /km · ${formatDurationMinutesUi(it.durationMinutes)}" } ?: "—")
                        }
                        MetricLine("Longest run", summary.longestKm?.let { "${fmtKmUi(it)} km" } ?: "—")
                    }
                    val easyRuns = com.endurancevault.app.domain.EasyRunAnalytics.calculate(state.detailsByActivity, loadMetricsLthrUi(state), state.settings.easyRun)
                    ProgressCard("EASY-RUN COMPLIANCE", easyRuns.lastOrNull()?.compliancePct?.let { "%.1f%%".format(it) } ?: "—", "Kepatuhan HR · timeline 1 detik bila tersedia · data lama tetap didukung") {
                        easyRuns.takeLast(14).asReversed().forEach { r ->
                            MetricLine(r.date.toString(), "${r.kind} · ${r.compliancePct?.let { "%.1f%%".format(it) } ?: "—"} · ${r.verdict}")
                            if (r.score != null) Text("Score ${r.score} · drift ${r.driftPct?.let { "%.1f%%".format(it) } ?: "—"} · stability ${r.stabilityCv?.let { "%.1f%%".format(it) } ?: "—"}", style = MaterialTheme.typography.bodySmall)
                        }
                        if (easyRuns.isEmpty()) Text("Belum ada aktivitas dengan penanda easy-run dan data HR yang sesuai.")
                        else Text("Legacy histogram-only: ${easyRuns.count { it.legacyHistogramOnly }} sesi. Seri per detik dipakai bila tersedia.", style = MaterialTheme.typography.bodySmall)
                    }
                    ProgressCard("PACE ZONES FROM RAI", "Pace zones", "Zona pace datar dari Running Ability Index") {
                        val raiValue = rai?.value
                        if (raiValue == null) Text("Belum cukup data HR dan pace untuk membentuk zona pace RAI.")
                        else listOf("Easy" to (.62 to .74), "Tempo" to (.80 to .87), "Threshold" to (.88 to .92), "VO₂max" to (.95 to 1.0)).forEach { (label, f) ->
                            val lo = paceAtRaiUi(raiValue, f.first)
                            val hi = paceAtRaiUi(raiValue, f.second)
                            MetricLine(label, "${com.endurancevault.app.domain.Js.paceStr(hi)} – ${com.endurancevault.app.domain.Js.paceStr(lo)} /km")
                        }
                        Text("Untuk jalan datar. Di tanjakan atau cuaca panas, ikuti HR dan rasa usaha, bukan pace.", style = MaterialTheme.typography.bodySmall)
                    }
                    ProgressCard("AEROBIC EFFICIENCY & CARDIAC DRIFT", easyRuns.lastOrNull()?.driftPct?.let { "+%.1f%%".format(it) } ?: "—", "Tren drift dan kestabilan dari stream HR/GAP aktivitas") {
                        val trend = easyRuns.takeLast(14)
                        TrendLineChart(listOf(
                            "Compliance" to trend.map { it.compliancePct?.toFloat() ?: Float.NaN },
                            "Drift" to trend.map { it.driftPct?.toFloat() ?: Float.NaN },
                            "Stability" to trend.map { it.stabilityCv?.toFloat() ?: Float.NaN },
                        ))
                        trend.asReversed().forEach { r ->
                            MetricLine(r.date.toString(), "${r.compliancePct?.let { "%.1f%%".format(it) } ?: "—"} · drift ${r.driftPct?.let { "%.1f%%".format(it) } ?: "—"} · stability ${r.stabilityCv?.let { "%.1f%%".format(it) } ?: "—"}")
                        }
                        if (trend.isEmpty()) Text("Belum ada sesi easy-run yang memiliki stream HR dan pace/GAP untuk analisis.", style = MaterialTheme.typography.bodySmall)
                        else Text("Grafik dinormalisasi per metrik untuk memperlihatkan arah perubahan. Hasil lama berbasis histogram ditandai terpisah pada kartu Easy Run Compliance.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            ProgressTab.LOAD -> {
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    ProgressHeader("LOAD", "Beban latihan dan distribusi intensitas")
                    TrainingLoadSection(state)
                    val loadMetrics = com.endurancevault.app.domain.TrainingMetrics.calculate(state.settings, state.activities, state.daily, state.plan, today, hrHistByActivity = state.hrHistByActivity)
                    val acwr = com.endurancevault.app.domain.ProgressAnalytics.acuteChronic(loadMetrics.days, today)
                    val mono = com.endurancevault.app.domain.ProgressAnalytics.monotonyStrain(loadMetrics.days, today)
                    ProgressCard("ACWR, MONOTONY & STRAIN", acwr?.let { "%.2f".format(it.ratio) } ?: "—", "Acute : chronic workload · 28 days") {
                        MetricLine("Acute 7 days", acwr?.let { "%.1f".format(it.acute) } ?: "—")
                        MetricLine("Chronic 28 days", acwr?.let { "%.1f".format(it.chronic) } ?: "—")
                        MetricLine("Monotony · 7 days", mono?.let { "%.2f".format(it.monotony) } ?: "—")
                        MetricLine("Strain", mono?.let { "%.0f".format(it.strain) } ?: "—")
                        Text("ACWR memakai total 7 hari dibagi rata-rata mingguan 28 hari. Monotony = rerata beban harian / simpangan baku 7 hari; strain = total beban × monotony.", style = MaterialTheme.typography.bodySmall)
                    }
                    ProgressCard("80/20 INTENSITY", "HR distribution", "Distribusi waktu berdasarkan histogram HR") {
                        val dist = com.endurancevault.app.domain.ProgressAnalytics.intensity(state.hrHistByActivity.values, loadMetrics.lthr, loadMetrics.hrMax)
                        if (dist == null) Text("Belum ada histogram HR aktivitas yang cukup.")
                        else {
                            MetricLine("Z1–2", "%.1f%%".format(dist.z1z2))
                            MetricLine("Z3", "%.1f%%".format(dist.z3))
                            MetricLine("Z4–5", "%.1f%%".format(dist.z4z5))
                            Text("Total sampel ${"%.1f".format(dist.totalSeconds / 3600)} jam.")
                        }
                    }
                }
            }
            ProgressTab.ROUTES -> {
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    ProgressHeader("ROUTES & CONDITIONS", "Analisis rute dan pengaruh kondisi")
                    val withDetail = runs.mapNotNull { a -> state.detailsByActivity[a.id]?.let { a to it } }
                    var compareA by remember(withDetail.map { it.first.id }) { mutableStateOf(withDetail.lastOrNull()?.first?.id) }
                    var compareB by remember(withDetail.map { it.first.id }) { mutableStateOf(withDetail.dropLast(1).lastOrNull()?.first?.id) }
                    val routeGroups = com.endurancevault.app.domain.ProgressAnalytics.similarRoutes(
                        withDetail.filter { it.second.hasRoute }.map { (a,d) ->
                            com.endurancevault.app.domain.RouteActivity(a.id, a.dateIso, a.km, d.route)
                        }
                    )
                    ProgressCard("SIMILAR ROUTES", "${routeGroups.size} groups", "Kelompok rute dari geometri GPS · km ±12%") {
                        routeGroups.take(8).forEach { group ->
                            MetricLine("${group.representative.dateIso} · ${fmtKmUi(group.representative.km)} km", "×${group.members.size}")
                            Text(group.members.joinToString(" · ") { it.dateIso }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (routeGroups.isEmpty()) Text("Belum ada dua aktivitas dengan bentuk rute dan jarak yang cukup mirip.")
                    }
                    ProgressCard("COMPARE ACTIVITIES", "${withDetail.size} activities", "Pilih dua aktivitas ber-detail") {
                        val choices = withDetail.takeLast(30)
                        if (choices.size >= 2) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Column(Modifier.weight(1f)) {
                                    Text("Aktivitas A", style = MaterialTheme.typography.labelSmall)
                                    choices.forEach { (a, _) -> Row(Modifier.fillMaxWidth().clickable { compareA = a.id }.padding(vertical = 3.dp)) { Text((if (compareA == a.id) "● " else "○ ") + a.dateIso, style = MaterialTheme.typography.bodySmall) } }
                                }
                                Column(Modifier.weight(1f)) {
                                    Text("Aktivitas B", style = MaterialTheme.typography.labelSmall)
                                    choices.forEach { (a, _) -> Row(Modifier.fillMaxWidth().clickable { compareB = a.id }.padding(vertical = 3.dp)) { Text((if (compareB == a.id) "● " else "○ ") + a.dateIso, style = MaterialTheme.typography.bodySmall) } }
                                }
                            }
                            val a = choices.firstOrNull { it.first.id == compareA }
                            val b = choices.firstOrNull { it.first.id == compareB }
                            if (a != null && b != null && a.first.id != b.first.id) {
                                MetricLine("Distance", "${fmtKmUi(a.first.km)} / ${fmtKmUi(b.first.km)} km")
                                MetricLine("Pace", "${com.endurancevault.app.domain.Js.paceStr(a.second.avgPace ?: 0.0)} / ${com.endurancevault.app.domain.Js.paceStr(b.second.avgPace ?: 0.0)}")
                                MetricLine("HR", "${a.second.hr ?: "—"} / ${b.second.hr ?: "—"} bpm")
                                MetricLine("Elevation", "${a.second.gain ?: 0} / ${b.second.gain ?: 0} m")
                            }
                        } else Text("Minimal dua aktivitas dengan detail FIT/GPX/TCX diperlukan.")
                    }
                    ProgressCard("ROUTE HEATMAP & RIDGELINE", "${withDetail.count { it.second.hasRoute }} routes", "Data rute dan profil elevasi") {
                        MetricLine("Total elevation gain", "${withDetail.sumOf { it.second.gain ?: 0 }} m")
                        withDetail.filter { it.second.profile.size >= 2 }.takeLast(5).forEach { (a, d) ->
                            Text("${a.dateIso} · ${fmtKmUi(a.km)} km · ${d.profile.size} titik elevasi", style = MaterialTheme.typography.bodySmall)
                            ElevationMiniChartUi(d.profile)
                        }
                    }
                    ProgressCard("WEATHER IMPACT", "Weather history", "Kondisi cuaca saat aktivitas") {
                        val weatherRows = withDetail.mapNotNull { (a,d) -> d.weatherTempC?.let { Triple(a, it, d.weatherFeelsLikeC) } }
                        if (weatherRows.isEmpty()) Text("Arsip cuaca historis belum tersedia pada data aktivitas ini.")
                        else {
                            val grouped = weatherRows.groupBy { (_, t, _) -> when { t < 24 -> "<24°C"; t < 28 -> "24–28°C"; else -> "≥28°C" } }
                            listOf("<24°C", "24–28°C", "≥28°C").forEach { band ->
                                val rows = grouped[band].orEmpty()
                                if (rows.isNotEmpty()) {
                                    MetricLine(band, "${rows.size} runs · avg pace ${com.endurancevault.app.domain.Js.paceStr(rows.map { it.first.durationSec / 60.0 / it.first.km }.average())}/km")
                                }
                            }
                            weatherRows.takeLast(10).forEach { (a,t,fl) -> MetricLine(a.dateIso, "%.1f°C".format(t) + (fl?.let { " · feels %.1f°C".format(it) } ?: "")) }
                        }
                    }
                }
            }
            ProgressTab.BODY -> {
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    ProgressHeader("BODY", "Tidur, kondisi, dan latihan kekuatan")
                    ProgressCard("SLEEP AND CONDITION", latestDaily?.sleepH?.let { "%.1f h".format(it) } ?: "—", latestDaily?.dateIso ?: "Belum ada data harian") {
                        MetricLine("Resting HR", latestDaily?.rhr?.let { "$it bpm" } ?: "—")
                        MetricLine("HRV", latestDaily?.hrv?.let { "$it ms" } ?: "—")
                        MetricLine("Leg feel", latestDaily?.leg?.let { "$it / 5" } ?: "Belum diisi")
                        MetricLine("Mood", latestDaily?.mood?.let { "$it / 5" } ?: "Belum diisi")
                        val history = state.daily.sortedBy { it.dateIso }.takeLast(14)
                        Text("Tren kondisi · 14 hari", style = MaterialTheme.typography.titleSmall)
                        TrendLineChart(listOf(
                            "Kaki" to history.map { it.leg?.toFloat() ?: Float.NaN },
                            "Mood/stres" to history.map { it.mood?.toFloat() ?: Float.NaN },
                        ))
                        history.asReversed().forEach { d ->
                            MetricLine(d.dateIso, "Kaki ${d.leg ?: "—"}/5 · Mood ${d.mood ?: "—"}/5 · ${d.sleepH?.let { "%.1f jam".format(it) } ?: "tidur —"}")
                        }
                    }
                    val strengthDays = weeks.flatMap { it.days }.filter { listOfNotNull(it.str, it.ank, it.up).isNotEmpty() }
                    ProgressCard("STRENGTH PROGRESS", "${state.strengthWorkouts.size} completed workouts", "Workout strength yang disinkronkan dari jam") {
                        state.strengthWorkouts.takeLast(20).asReversed().forEach { w ->
                            MetricLine(w.dateIso, "${w.minutes} min · ${w.avgHr?.let { "$it bpm" } ?: "HR —"} · ${w.calories?.let { "$it kcal" } ?: "—"}")
                            Text(when { w.free -> "Free Strength"; w.linkedKey != null -> "Linked: ${w.linkedKey}"; else -> "Imported strength" }, style = MaterialTheme.typography.bodySmall)
                        }
                        MetricLine("Planned strength days", strengthDays.size.toString())
                        Text("Workout strength tetap terpisah dari aktivitas lari dan tidak masuk mileage, PR, atau training load.", style = MaterialTheme.typography.bodySmall)
                    }
                    ProgressCard("STRENGTH BALANCE", "Session history", "Data aktual yang tersedia dari jam") {
                        val avgHr = state.strengthWorkouts.mapNotNull { it.avgHr }.takeIf { it.isNotEmpty() }?.average()
                        val total = state.strengthWorkouts.sumOf { it.minutes }
                        MetricLine("Total duration", "$total min")
                        MetricLine("Average HR", avgHr?.let { "${it.roundToInt()} bpm" } ?: "—")
                        MetricLine("HR records", state.strengthWorkouts.count { it.avgHr != null }.toString())
                        Text("Distribusi kelompok otot belum dapat dihitung karena workout dari jam tidak menyimpan set, repetisi, atau identitas gerakan.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        Surface(tonalElevation = 2.dp, color = MaterialTheme.colorScheme.surface) {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ProgressTab.values().forEach { tab ->
                    FilterChip(
                        selected = selected == tab,
                        onClick = { selected = tab },
                        label = { Text(tab.label) },
                    )
                }
            }
        }
    }
}

@Composable private fun ProgressHeader(kicker: String, title: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(kicker, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
        Text(title, style = MaterialTheme.typography.titleLarge)
    }
}

@Composable private fun ProgressCard(
    label: String, value: String, subtitle: String, modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    var expanded by remember(label) { mutableStateOf(false) }
    EvPanel(modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                Modifier.fillMaxWidth().clickable { expanded = !expanded },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    Text(value, style = MaterialTheme.typography.headlineSmall)
                    Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { expanded = !expanded }) {
                    Icon(if (expanded) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore,
                        contentDescription = if (expanded) "Tutup detail $label" else "Buka detail $label")
                }
            }
            AnimatedVisibility(visible = expanded, enter = expandVertically(), exit = shrinkVertically()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { content() }
            }
        }
    }
}

@Composable private fun MetricLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable private fun YearHeatmap(runs: List<com.endurancevault.app.data.ActivityEntity>, year: Int) {
    val byDate = runs.groupBy { it.dateIso }.mapValues { (_, rows) -> rows.sumOf { it.km } }
    val first = LocalDate.of(year, 1, 1)
    val start = first.minusDays((first.dayOfWeek.value - 1).toLong())
    val max = byDate.values.maxOrNull()?.coerceAtLeast(1.0) ?: 1.0
    val accent = MaterialTheme.colorScheme.primary
    val empty = MaterialTheme.colorScheme.outlineVariant
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        repeat(7) { day ->
            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                repeat(53) { week ->
                    val date = start.plusDays((week * 7 + day).toLong())
                    val v = if (date.year == year) byDate[date.toString()] ?: 0.0 else 0.0
                    val alpha = if (v <= 0) .12f else (.25f + .75f * (v / max).toFloat()).coerceIn(.25f, 1f)
                    Canvas(Modifier.weight(1f).height(8.dp)) {
                        drawRoundRect((if (v > 0) accent else empty).copy(alpha = alpha), cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx()))
                    }
                }
            }
        }
    }
    Text("Jarak harian · intensitas warna mengikuti volume lari", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun ActivityVolumeChart(activities: List<com.endurancevault.app.data.ActivityEntity>) {
    val today = LocalDate.now()
    val currentMonday = today.with(DayOfWeek.MONDAY)
    val starts = (7 downTo 0).map { currentMonday.minusWeeks(it.toLong()) }
    val values = starts.map { start ->
        activities.filter { a ->
            if (a.type == "bike") return@filter false
            val date = runCatching { LocalDate.parse(a.dateIso) }.getOrNull() ?: return@filter false
            !date.isBefore(start) && date.isBefore(start.plusDays(7))
        }.sumOf { it.km }
    }
    val maxValue = (values.maxOrNull() ?: 0.0).coerceAtLeast(1.0)
    val accent = MaterialTheme.colorScheme.primary
    val muted = MaterialTheme.colorScheme.outlineVariant
    Canvas(Modifier.fillMaxWidth().height(116.dp)) {
        val left = 4.dp.toPx(); val right = 4.dp.toPx()
        val top = 8.dp.toPx(); val bottom = 8.dp.toPx()
        val usableW = size.width - left - right
        val usableH = size.height - top - bottom
        repeat(3) { i ->
            val y = top + usableH * (i / 2f)
            drawLine(muted.copy(alpha = .55f), Offset(left, y), Offset(size.width-right, y), 1.dp.toPx())
        }
        val slot = usableW / values.size
        values.forEachIndexed { i, value ->
            val h = (value / maxValue).toFloat() * usableH
            val barW = slot * .54f
            val x = left + slot * i + (slot - barW) / 2f
            drawRoundRect(
                color = if (i == values.lastIndex) accent else accent.copy(alpha = .48f),
                topLeft = Offset(x, top + usableH - h),
                size = androidx.compose.ui.geometry.Size(barW, h.coerceAtLeast(2.dp.toPx())),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(5.dp.toPx()),
            )
        }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text("8 pekan lalu", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("Pekan ini", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
    }
    Text("${fmtKmUi(values.last())} km pekan ini", style = MaterialTheme.typography.titleSmall)
}


@Composable
private fun TrendLineChart(series: List<Pair<String, List<Float>>>) {
    val palette = listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.tertiary, MaterialTheme.colorScheme.secondary, MaterialTheme.colorScheme.error)
    val valid = series.filter { (_, values) -> values.any { it.isFinite() } }
    if (valid.isEmpty()) {
        Text("Belum cukup data historis untuk membentuk tren.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }
    val gridColor = MaterialTheme.colorScheme.outlineVariant
    val normalized = valid.map { (_, values) ->
        val finite = values.filter { it.isFinite() }
        val min = finite.minOrNull() ?: 0f
        val max = finite.maxOrNull() ?: 1f
        val span = (max - min).takeIf { it > 0.0001f } ?: 1f
        values.map { if (it.isFinite()) ((it - min) / span).coerceIn(0f, 1f) else Float.NaN }
    }
    Canvas(Modifier.fillMaxWidth().height(112.dp)) {
        val left = 5.dp.toPx(); val right = 5.dp.toPx(); val top = 8.dp.toPx(); val bottom = 8.dp.toPx()
        val w = size.width - left - right; val h = size.height - top - bottom
        repeat(3) { i ->
            val y = top + h * i / 2f
            drawLine(gridColor.copy(alpha = .55f), Offset(left, y), Offset(size.width-right, y), 1.dp.toPx())
        }
        normalized.forEachIndexed { si, values ->
            val pts = values.mapIndexedNotNull { i, v -> if (v.isFinite()) i to Offset(left + w * (if (values.size <= 1) 0f else i.toFloat() / (values.size - 1)), top + h * (1f-v)) else null }
            if (pts.size >= 2) {
                var path = Path(); var started = false; var prev = -2
                pts.forEach { (idx, pt) ->
                    if (!started || idx != prev + 1) { if (started) { drawPath(path, palette[si % palette.size], style = Stroke(2.dp.toPx())); path = Path() }; path.moveTo(pt.x, pt.y); started = true }
                    else path.lineTo(pt.x, pt.y)
                    prev = idx
                }
                if (started) drawPath(path, palette[si % palette.size], style = Stroke(2.dp.toPx()))
                pts.forEach { (_, pt) -> drawCircle(palette[si % palette.size], 2.5.dp.toPx(), pt) }
            }
        }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        valid.forEachIndexed { i, item ->
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Canvas(Modifier.size(7.dp)) { drawCircle(palette[i % palette.size]) }
                Text(item.first, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

private fun formatDurationMinutesUi(minutes: Double): String {
    val total = (minutes * 60).roundToInt()
    val h = total / 3600; val m = (total % 3600) / 60; val sec = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

private fun loadMetricsLthrUi(state: UiState): Int =
    com.endurancevault.app.domain.TrainingMetrics.calculate(
        state.settings, state.activities, state.daily, state.plan, hrHistByActivity = state.hrHistByActivity,
    ).lthr

private fun fitLabelUi(v: Int) = when {
    v >= 80 -> "Sangat tinggi"; v >= 60 -> "Tinggi"; v >= 40 -> "Sedang"; v >= 20 -> "Rendah"; else -> "Sangat rendah"
}

private fun fatLabelUi(v: Int) = when {
    v >= 80 -> "Sangat lelah"; v >= 60 -> "Lelah"; v >= 35 -> "Sedang"; v >= 15 -> "Ringan"; else -> "Segar"
}

/** Pace datar (menit/km) pada fraksi [fraction] dari VO2max/RAI [rai], dari VO2 = -4.6 + 0.182258v + 0.000104v² (v m/menit). */
private fun paceAtRaiUi(rai: Double, fraction: Double): Double {
    val target = rai * fraction
    val a = 0.000104; val b = 0.182258; val c = -4.6 - target
    val v = (-b + kotlin.math.sqrt(b * b - 4 * a * c)) / (2 * a)
    return 1000.0 / v
}

@Composable private fun ElevationMiniChartUi(profile: List<Pair<Double, Double>>) {
    if (profile.size < 2) return
    val lineColor = MaterialTheme.colorScheme.primary
    Canvas(Modifier.fillMaxWidth().height(48.dp)) {
        val minX = profile.minOf { it.first }; val maxX = profile.maxOf { it.first }
        val minY = profile.minOf { it.second }; val maxY = profile.maxOf { it.second }
        val dx = (maxX - minX).coerceAtLeast(1e-6); val dy = (maxY - minY).coerceAtLeast(1.0)
        val path = Path()
        profile.forEachIndexed { i, (x, y) ->
            val px = ((x - minX) / dx * size.width).toFloat()
            val py = (size.height - (y - minY) / dy * size.height).toFloat()
            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        drawPath(path, lineColor, style = Stroke(width = 2.dp.toPx()))
    }
}
