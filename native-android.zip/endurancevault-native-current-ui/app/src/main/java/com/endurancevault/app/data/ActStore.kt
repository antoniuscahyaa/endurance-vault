package com.endurancevault.app.data

import com.endurancevault.app.data.JsonUtil.dbl
import com.endurancevault.app.data.JsonUtil.int
import com.endurancevault.app.data.JsonUtil.text
import com.endurancevault.app.domain.ActDetail
import com.endurancevault.app.domain.ActivityTimeSeries
import com.endurancevault.app.domain.EasyRunAnnotation
import com.endurancevault.app.domain.Segment
import com.endurancevault.app.domain.Split
import com.google.gson.stream.JsonReader
import com.google.gson.stream.JsonWriter
import com.google.gson.stream.JsonToken
import java.io.File
import java.io.InputStream
import java.io.InputStreamReader
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.time.LocalDate

/** Penyimpanan detail aktivitas: satu berkas JSON per aktivitas (format objek aktivitas versi web). */
class ActStore(val dir: File) {
    init { dir.mkdirs() }

    fun file(name: String) = File(dir, name)

    /** Write through a sibling temp file so a process death cannot leave a truncated activity JSON. */
    fun write(name: String, act: Map<String, Any?>) {
        require(name.matches(Regex("[A-Za-z0-9._-]+\\.json"))) { "Nama berkas detail tidak valid" }
        val target = file(name)
        val temp = File(dir, ".${target.name}.${System.nanoTime()}.tmp")
        try {
            JsonWriter(temp.writer(Charsets.UTF_8).buffered()).use { JsonUtil.writeAny(it, act) }
            Files.move(temp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE)
        } finally {
            temp.delete()
        }
    }

    /** Install a fully extracted backup set only after parsing has completed successfully. */
    fun installBackupFiles(stagingDir: File) {
        val staged = stagingDir.listFiles { f -> f.isFile && f.name.matches(Regex("b_[A-Za-z0-9._-]+\\.json")) }.orEmpty()
        val keep = staged.map { it.name }.toSet()
        staged.forEach { source ->
            val target = File(dir, source.name)
            val temp = File(dir, ".${source.name}.${System.nanoTime()}.tmp")
            try {
                Files.copy(source.toPath(), temp.toPath(), StandardCopyOption.REPLACE_EXISTING)
                Files.move(temp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE)
            } finally { temp.delete() }
        }
        dir.listFiles { f -> f.name.startsWith("b_") && f.name.endsWith(".json") && f.name !in keep }
            ?.forEach { it.delete() }
    }

    /** Nama berkas detail yang sah (`b_*.json` hasil impor web, `f_<id>.json` hasil impor FIT/GPX). */
    fun detailFiles(): List<File> =
        dir.listFiles { f -> f.isFile && f.name.matches(DETAIL_NAME) }.orEmpty().sortedBy { it.name }

    /** Pasang semua berkas detail dari folder staging cadangan lengkap (atomik per berkas). Tidak menghapus apa pun. */
    fun installAllFiles(stagingDir: File) {
        stagingDir.listFiles { f -> f.isFile && f.name.matches(DETAIL_NAME) }.orEmpty().forEach { source ->
            val target = File(dir, source.name)
            val temp = File(dir, ".${source.name}.${System.nanoTime()}.tmp")
            try {
                Files.copy(source.toPath(), temp.toPath(), StandardCopyOption.REPLACE_EXISTING)
                Files.move(temp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE)
            } finally { temp.delete() }
        }
    }

    /** Hapus berkas detail yang tidak ada di [keep] setelah pemulihan cadangan lengkap berhasil. */
    fun deleteFilesExcept(keep: Set<String>) {
        detailFiles().filter { it.name !in keep }.forEach { it.delete() }
    }

    fun read(name: String): ActDetail? {
        val f = file(name)
        if (!f.exists()) return null
        return runCatching { f.inputStream().use { parse(it) } }.getOrNull()
    }

    /** Baca histogram HR saja untuk analitik, tanpa membangun objek rute/split yang besar. */
    fun readHrHist(name: String): Map<Int, Double> {
        val f = file(name)
        if (!f.exists()) return emptyMap()
        return runCatching {
            val out = LinkedHashMap<Int, Double>()
            JsonReader(InputStreamReader(f.inputStream(), Charsets.UTF_8)).use { r ->
                if (r.peek() != JsonToken.BEGIN_OBJECT) return@use
                r.beginObject()
                while (r.hasNext()) {
                    val key = r.nextName()
                    if (key == "h" && r.peek() == JsonToken.BEGIN_OBJECT) {
                        r.beginObject()
                        while (r.hasNext()) {
                            val bpm = r.nextName().toIntOrNull()
                            val seconds = if (r.peek() == JsonToken.NUMBER) r.nextDouble() else { r.skipValue(); null }
                            if (bpm != null && seconds != null && seconds > 0) out[bpm] = seconds
                        }
                        r.endObject()
                    } else r.skipValue()
                }
                r.endObject()
            }
            out
        }.getOrDefault(emptyMap())
    }

    fun delete(name: String) { file(name).delete() }

    /** Hapus detail backup lama setelah set backup pengganti berhasil dipasang. */
    fun clearBackupFiles() { dir.listFiles { x -> x.name.startsWith("b_") }?.forEach { it.delete() } }

    companion object {
        val DETAIL_NAME = Regex("[A-Za-z0-9._-]+\\.json")

        fun isValidBackupActivityKey(key: String): Boolean {
            if (!key.matches(Regex("\\d{4}-\\d{2}-\\d{2}(~[A-Za-z0-9_-]+)?"))) return false
            return runCatching { LocalDate.parse(key.take(10)) }.isSuccess
        }

        fun backupFileName(key: String): String {
            require(isValidBackupActivityKey(key)) { "Kunci aktivitas cadangan tidak valid" }
            return "b_" + key.replace('~', '_') + ".json"
        }
        fun importFileName(id: Long) = "f_$id.json"

        fun parse(input: InputStream): ActDetail {
            val r = JsonReader(InputStreamReader(input, Charsets.UTF_8))
            val m = JsonUtil.asMap(JsonUtil.readAny(r)) ?: throw IllegalArgumentException("bukan objek aktivitas")
            return fromMap(m)
        }

        private fun pairs(v: Any?): List<Pair<Double, Double>> =
            JsonUtil.asList(v).orEmpty().mapNotNull { e ->
                val l = JsonUtil.asList(e)
                val a = (l?.getOrNull(0) as? Double); val b = (l?.getOrNull(1) as? Double)
                if (a != null && b != null) a to b else null
            }

        fun fromMap(m: Map<String, Any?>): ActDetail {
            val splits = JsonUtil.asList(m["sp"]).orEmpty().mapNotNull { e ->
                val s = JsonUtil.asMap(e) ?: return@mapNotNull null
                Split(
                    s.dbl("k") ?: return@mapNotNull null, s.dbl("p") ?: return@mapNotNull null, s.int("h"),
                    s.int("g") ?: 0, s.int("l") ?: 0, s.int("c"), s.dbl("gp"), s.dbl("part") != null,
                )
            }
            val segs = JsonUtil.asList(m["sg"]).orEmpty().mapNotNull { e ->
                val s = JsonUtil.asMap(e) ?: return@mapNotNull null
                Segment(
                    s.dbl("k") ?: 0.0, s.dbl("d") ?: return@mapNotNull null, s.dbl("tm") ?: 0.0, s.dbl("p") ?: return@mapNotNull null,
                    s.int("h"), s.int("g") ?: 0, s.int("l") ?: 0, s.int("c"), s.text("n"), s.text("ty").ifEmpty { null },
                )
            }
            val route = JsonUtil.asList(m["rt"]).orEmpty().mapNotNull { e ->
                val l = JsonUtil.asList(e)
                val x = (l?.getOrNull(0) as? Double)?.toInt(); val y = (l?.getOrNull(1) as? Double)?.toInt()
                if (x != null && y != null) x to y else null
            }
            val hist = LinkedHashMap<Int, Double>()
            JsonUtil.asMap(m["h"])?.forEach { (k, v) -> val b = k.toIntOrNull(); val s = v as? Double; if (b != null && s != null) hist[b] = s }
            return ActDetail(
                date = m.text("date"), startTime = m.text("st"), name = m.text("nm"), bike = m["bike"] == true,
                kind = m.text("xk").ifEmpty { null },
                km = m.dbl("km") ?: 0.0, movingMin = m.dbl("min") ?: 0.0, elapsedMin = m.dbl("el") ?: 0.0,
                gain = m.int("gain"), loss = m.int("loss"), hr = m.int("hr"), hrMax = m.int("hrMax"), cad = m.int("cad"),
                gapPace = m.dbl("gap"), splits = splits, segments = segs,
                route = route, routeW = m.int("rw") ?: 0, routeH = m.int("rh") ?: 0,
                profile = pairs(m["pf"]), paceSeries = pairs(m["ps"]), hrSeries = pairs(m["hs"]), cadSeries = pairs(m["cs"]),
                hrHist = hist,
                weatherTempC = (JsonUtil.asMap(m["wx"])?.get("t") as? Number)?.toDouble() ?: m.dbl("tmp"),
                weatherFeelsLikeC = (JsonUtil.asMap(m["wx"])?.get("fl") as? Number)?.toDouble(),
                easyHrBuckets = JsonUtil.asList(m["hz"]).orEmpty().mapNotNull { (it as? Number)?.toInt() },
                easySpeedBuckets = JsonUtil.asList(m["vz"]).orEmpty().mapNotNull { (it as? Number)?.toInt() },
                easyRun = JsonUtil.asMap(m["ez"])?.let { ez ->
                    EasyRunAnnotation(
                        enabled = ez["on"] == true,
                        kind = ez["k"] as? String,
                        strideStartSec = (ez["st"] as? Number)?.toInt(),
                        strideDisabled = ez["st"] == false,
                    )
                },
                strideStartSec = (m["zs"] as? Number)?.toInt(),
                timeSeries = JsonUtil.asMap(m["tl"])?.let { tl ->
                    fun nums(key: String) = JsonUtil.asList(tl[key]).orEmpty()
                    val sec = nums("s").mapNotNull { (it as? Number)?.toInt() }
                    val dist = nums("d").map { (it as? Number)?.toDouble() ?: 0.0 }
                    val hr = nums("h").map { (it as? Number)?.toInt() ?: 0 }
                    val cad = nums("c").map { (it as? Number)?.toInt() ?: 0 }
                    val elev = nums("e").map { (it as? Number)?.toDouble() }
                    val gap = nums("v").map { (it as? Number)?.toInt() ?: 0 }
                    val grade = nums("g").map { (it as? Number)?.toDouble() }
                    val n = listOf(sec.size, dist.size, hr.size, cad.size, elev.size, gap.size, grade.size).minOrNull() ?: 0
                    if (n >= 2 && (tl["r"] as? Number)?.toInt() == 1) ActivityTimeSeries(
                        sec.take(n), dist.take(n), hr.take(n), cad.take(n), elev.take(n), gap.take(n), grade.take(n)
                    ) else null
                },
            )
        }
    }
}
