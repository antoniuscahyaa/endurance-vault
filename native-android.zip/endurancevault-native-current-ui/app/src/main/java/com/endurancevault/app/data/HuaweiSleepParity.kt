package com.endurancevault.app.data

import org.json.JSONArray
import java.time.Instant
import java.time.ZoneId

/** Mirrors the legacy watch importer: choose the longest >=3h main sleep per wake date. */
object HuaweiSleepParity {
    data class Segment(val start: Long, val end: Long, val stage: String)
    data class Night(val date: String, val start: Long, val end: Long, val deep: Int, val rem: Int,
                     val light: Int, val awake: Int, val unknown: Int, val awakeCount: Int,
                     val awakeMinutes: Int, val sleepMinutes: Int)
    private data class Group(val rows: MutableList<Segment>, var end: Long)

    fun parse(rows: JSONArray, zone: ZoneId): List<Night> {
        val input = mutableListOf<Segment>()
        for (i in 0 until rows.length()) {
            val o = rows.optJSONObject(i) ?: continue
            val s = o.optLong("start"); val e = o.optLong("end")
            if (s > 0 && e > s && o.optInt("type") != 0x5659)
                input += Segment(s, e, o.optString("stage").lowercase().let { if (it in setOf("deep", "rem", "light", "awake")) it else "unk" })
        }
        val groups = mutableListOf<Group>()
        input.sortedBy { it.start }.forEach { seg ->
            val g = groups.lastOrNull()
            val hour = Instant.ofEpochSecond(seg.start).atZone(zone).hour
            val gap = if (g == null) Long.MAX_VALUE else seg.start - g.end
            if (g == null || gap > 3600L || (gap >= 1800L && hour in 9..19)) groups += Group(mutableListOf(seg), seg.end)
            else { g.rows += seg; g.end = maxOf(g.end, seg.end) }
        }
        return groups.mapNotNull { night(it, zone) }.filter { it.sleepMinutes >= 180 }
            .groupBy { it.date }.values.mapNotNull { it.maxByOrNull(Night::sleepMinutes) }.sortedBy { it.date }
    }

    private fun night(g: Group, zone: ZoneId): Night? {
        val rank = mapOf("deep" to 4, "rem" to 4, "awake" to 3, "light" to 2, "unk" to 1)
        val slots = sortedMapOf<Long, String>()
        g.rows.forEach { seg ->
            var m = Math.floorDiv(seg.start, 60L); val stop = Math.floorDiv(seg.end + 59L, 60L)
            while (m < stop) { val old = slots[m]; if (old == null || rank.getValue(seg.stage) > rank.getValue(old)) slots[m] = seg.stage; m++ }
        }
        if (slots.isEmpty()) return null
        val counts = slots.values.groupingBy { it }.eachCount()
        val asleep = (counts["deep"] ?: 0) + (counts["rem"] ?: 0) + (counts["light"] ?: 0) + (counts["unk"] ?: 0)
        if (asleep == 0) return null
        val first = slots.entries.firstOrNull { it.value != "awake" }?.key ?: return null
        val last = slots.entries.lastOrNull { it.value != "awake" }?.key ?: return null
        var run = 0; var wakeN = 0; var wakeMin = 0
        for (m in first..last) {
            if (slots[m] == null || slots[m] == "awake") run++ else { if (run >= 3) { wakeN++; wakeMin += run }; run = 0 }
        }
        if (run >= 3) { wakeN++; wakeMin += run }
        val start = g.rows.minOf { it.start }; val end = g.end
        val date = Instant.ofEpochSecond(end).atZone(zone).toLocalDate().toString()
        return Night(date, start, end, counts["deep"] ?: 0, counts["rem"] ?: 0, counts["light"] ?: 0,
            counts["awake"] ?: 0, counts["unk"] ?: 0, wakeN, wakeMin, asleep)
    }
}
