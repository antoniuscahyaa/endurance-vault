package com.endurancevault.app.data

import org.json.JSONArray
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.max
import kotlin.math.min

/**
 * Port of the legacy `hwSleepNights` / `hwTrimFrags` (29-huawei-watch-sync.js).
 *
 * Pipeline, in the same order as the legacy code:
 *  1. clip every segment against workout windows ([Busy]) so "light sleep" recorded during a run is dropped;
 *  2. split nap-typed segments (0x5659) from the rest;
 *  3. group the rest (gap > 1 h, or gap >= 30 min before a segment that starts 09:00-19:59 local);
 *  4. trim stray fragments at both ends of each group (core-minute rule) and keep the cut parts;
 *  5. cut islands with >= 30 min sleep become extra sessions ("asleep again" or nap);
 *  6. one longest >= 3 h night per wake date; remaining sessions become extra sleep or naps;
 *  7. awake ranges inside the night (>= 3 min; pure no-data gaps >= 10 min are shown but never counted as awake).
 */
object HuaweiSleepParity {
    private const val NAP_TYPE = 0x5659
    private const val NIGHT_GAP = 3600L
    private const val DAY_GAP = 1800L
    private const val DAY_FROM = 9
    private const val DAY_TO = 20
    private const val NIGHT_MIN = 180
    private const val CUT_GAP = 1200L
    private const val CUT_MIN = 30
    private const val NAP_MERGE_GAP = 900L
    private val RANK = mapOf("deep" to 4, "rem" to 4, "awake" to 3, "light" to 2, "unk" to 1)
    private val HM: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")

    data class Segment(val start: Long, val end: Long, val stage: String)
    /** Workout window in epoch seconds (already widened by 2 minutes). */
    data class Busy(val start: Long, val end: Long)
    data class Wake(val a: String, val b: String, val min: Int, val gap: Boolean)
    data class Extra(val a: String, val b: String, val min: Int, val pos: String, val start: Long, val end: Long)
    data class NapItem(val a: String, val b: String, val min: Int)
    data class Nap(val date: String, val minutes: Int, val firstStart: Long, val list: List<NapItem>)
    data class Night(
        val date: String, val start: Long, val end: Long, val bed: String, val wake: String,
        val deep: Int, val rem: Int, val light: Int, val awake: Int, val unknown: Int,
        val awakeCount: Int, val awakeMinutes: Int, val gapMinutes: Int, val latencyMin: Int,
        val sleepMinutes: Int, val wakes: List<Wake>, val extras: List<Extra>, val extraMinutes: Int,
    ) {
        val hasStages: Boolean get() = deep + rem + light > 0
        /** Total sleep in minutes, including "asleep again" sessions (legacy: asleepMin + extraMin). */
        val totalMinutes: Int get() = sleepMinutes + extraMinutes
    }
    data class Result(val nights: List<Night>, val naps: List<Nap>)

    private class Seg(val start: Long, val end: Long, val stage: String)
    private class Group(var start: Long, var end: Long, var segs: List<Seg>, var cut: List<Seg> = emptyList())
    private class Slot(val p: Int, val st: String)
    private class Tally(val deep: Int, val rem: Int, val light: Int, val awake: Int, val unk: Int, val slot: Map<Long, Slot>) {
        val asleep: Int get() = deep + rem + light + unk
    }
    private class Rec(val night: Boolean, val g: Group, val t: Tally, val asleep: Int, val startH: Int, val date: String, val dateStart: String)

    /** Workout windows from the `workouts` payload rows: [start-120, end+120], windows shorter than 4 min dropped. */
    fun busyOf(workouts: JSONArray?): List<Busy> {
        val out = mutableListOf<Busy>()
        if (workouts == null) return out
        for (i in 0 until workouts.length()) {
            val w = workouts.optJSONObject(i) ?: continue
            val s = w.optLong("start", 0L); if (s <= 0L) continue
            val end = w.optLong("end", 0L); val dur = w.optLong("duration", 0L)
            val e = if (end > s) end else if (dur > 0) s + dur else s
            val b = Busy(s - 120, e + 120)
            if (b.end > b.start + 240) out += b
        }
        return out
    }

    fun busyFromPayload(arr: JSONArray?): List<Busy> {
        val out = mutableListOf<Busy>()
        if (arr == null) return out
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val s = o.optLong("s", 0L); val e = o.optLong("e", 0L)
            if (s > 0 && e > s) out += Busy(s, e)
        }
        return out
    }

    /** Kept for callers that only need the chosen nights. */
    fun parse(rows: JSONArray, zone: ZoneId, busy: List<Busy> = emptyList()): List<Night> = parseAll(rows, zone, busy).nights

    fun parseAll(rows: JSONArray, zone: ZoneId, busy: List<Busy> = emptyList()): Result {
        val main = mutableListOf<Seg>(); val napSegs = mutableListOf<Seg>()
        for (i in 0 until rows.length()) {
            val o = rows.optJSONObject(i) ?: continue
            val s = o.optLong("start"); val e = o.optLong("end")
            if (s <= 0 || e <= s) continue
            val stage = o.optString("stage").lowercase().let { if (RANK.containsKey(it) && it != "unk") it else "unk" }
            for ((ps, pe) in clip(s, e, busy)) {
                val seg = Seg(ps, pe, stage)
                if (o.optInt("type") == NAP_TYPE) napSegs += seg else main += seg
            }
        }
        main.sortBy { it.start }
        fun hm(ts: Long) = Instant.ofEpochSecond(ts).atZone(zone).format(HM)
        fun hour(ts: Long) = Instant.ofEpochSecond(ts).atZone(zone).hour
        fun date(ts: Long) = Instant.ofEpochSecond(ts).atZone(zone).toLocalDate().toString()

        var groups = mutableListOf<Group>()
        var curList: MutableList<Seg>? = null
        var curGroup: Group? = null
        for (s in main) {
            val g = curGroup
            val gp = if (g == null) 0L else s.start - g.end
            val sh = hour(s.start)
            if (g == null || gp > NIGHT_GAP || (gp >= DAY_GAP && sh in DAY_FROM until DAY_TO)) {
                val list = mutableListOf(s)
                val ng = Group(s.start, s.end, list)
                groups += ng; curGroup = ng; curList = list
            } else {
                g.end = max(g.end, s.end); curList!!.add(s)
            }
        }
        groups.forEach(::trimFrags)

        // Islands cut from the edges: >= 30 min of sleep stays as its own session, the rest is debris.
        val extraGroups = mutableListOf<Group>()
        groups.forEach { g ->
            val isl = mutableListOf<Group>()
            var c: Group? = null
            for (x in g.cut.sortedBy { it.start }) {
                val cc = c
                if (cc == null || x.start - cc.end >= CUT_GAP) {
                    val ng = Group(x.start, x.end, mutableListOf(x)); isl += ng; c = ng
                } else {
                    cc.end = max(cc.end, x.end); (cc.segs as MutableList<Seg>).add(x)
                }
            }
            isl.forEach { x -> if (tally(x).asleep >= CUT_MIN) extraGroups += x }
        }
        groups = (groups + extraGroups).toMutableList()

        val recs = mutableListOf<Rec>()
        groups.forEach { g ->
            val t = tally(g); val asleep = t.asleep
            if (asleep < 20) return@forEach
            recs += Rec(asleep >= NIGHT_MIN, g, t, asleep, hour(g.start), date(g.end), date(g.start))
        }
        // main night = longest session (>= 3 h) for each wake date; the earlier one wins ties
        val best = linkedMapOf<String, Rec>()
        recs.forEach { r -> if (r.night) { val b = best[r.date]; if (b == null || b.asleep < r.asleep) best[r.date] = r } }
        val bl = best.keys.sorted().map { best.getValue(it) }

        val extraBy = mutableMapOf<String, MutableList<Extra>>()
        val napGroups = mutableListOf<Rec>()
        recs.forEach { x ->
            if (bl.any { it === x }) return@forEach
            if (x.startH in 9 until 20) { napGroups += x; return@forEach }
            var tgt: Rec? = null; var gap = Long.MAX_VALUE
            bl.forEach { b ->
                val gp = if (x.g.start >= b.g.end) x.g.start - b.g.end else if (x.g.end <= b.g.start) b.g.start - x.g.end else Long.MAX_VALUE
                if (gp <= 6 * 3600L && gp < gap) { gap = gp; tgt = b }
            }
            val t = tgt
            if (t == null) { napGroups += x; return@forEach }
            extraBy.getOrPut(t.date) { mutableListOf() } += Extra(hm(x.g.start), hm(x.g.end), x.asleep, if (x.g.start >= t.g.end) "a" else "b", x.g.start, x.g.end)
        }

        val nights = bl.map { r ->
            val g = r.g; val t = r.t
            val (wakes, first) = wakesOf(t.slot, ::hm)
            val ex = (extraBy[r.date] ?: mutableListOf<Extra>()).sortedBy { it.start }
            val lat = if (first != null) max(0, Math.floor(first - g.start / 60.0 + 0.5).toInt()) else 0
            Night(r.date, g.start, g.end, hm(g.start), hm(g.end), t.deep, t.rem, t.light, t.awake, t.unk,
                wakes.count { !it.gap }, wakes.filter { !it.gap }.sumOf { it.min }, wakes.filter { it.gap }.sumOf { it.min },
                if (lat >= 1) lat else 0, r.asleep, wakes, ex, ex.sumOf { it.min })
        }

        // Nap-typed segments merge when <= 15 min apart; ordinary leftover sessions join unless they overlap a nap-typed one.
        class NapAcc(var s: Long, var e: Long)
        val napItems = mutableListOf<NapAcc>(); var mc: NapAcc? = null
        napSegs.sortedBy { it.start }.forEach { s ->
            if (mc != null && s.start - mc!!.e <= NAP_MERGE_GAP) mc!!.e = max(mc!!.e, s.end)
            else { mc = NapAcc(s.start, s.end); napItems += mc!! }
        }
        class NapDay(var start: Long, var min: Int, val list: MutableList<NapItem>)
        val napDay = sortedMapOf<String, NapDay>()
        fun addNap(d: String, s: Long, e: Long, m: Int) {
            val o = napDay.getOrPut(d) { NapDay(s, 0, mutableListOf()) }
            o.start = min(o.start, s); o.min += m; o.list += NapItem(hm(s), hm(e), m)
        }
        napItems.forEach { n -> val m = Math.floor((n.e - n.s) / 60.0 + 0.5).toInt(); if (m >= 1) addNap(date(n.s), n.s, n.e, m) }
        napGroups.forEach { x ->
            val dup = napItems.any { x.g.start < it.e && x.g.end > it.s }
            if (!dup) addNap(x.dateStart, x.g.start, x.g.end, x.asleep)
        }
        val naps = napDay.filter { it.value.min >= 20 }.map { (d, v) -> Nap(d, v.min, v.start, v.list.sortedBy { it.a }) }
        return Result(nights, naps)
    }

    private fun clip(s: Long, e: Long, busy: List<Busy>): List<Pair<Long, Long>> {
        var parts = listOf(s to e)
        busy.forEach { b ->
            val next = mutableListOf<Pair<Long, Long>>()
            parts.forEach { p ->
                if (b.end <= p.first || b.start >= p.second) { next += p; return@forEach }
                if (p.first < b.start) next += (p.first to b.start)
                if (p.second > b.end) next += (b.end to p.second)
            }
            parts = next
        }
        return parts.filter { it.second > it.first }
    }

    private fun ceilMin(sec: Long) = Math.floorDiv(sec + 59L, 60L)

    private fun slotsOf(segs: List<Seg>): MutableMap<Long, Slot> {
        val slot = HashMap<Long, Slot>()
        segs.forEach { s ->
            val pr = RANK.getValue(s.stage)
            var m = ceilMin(s.start); val stop = ceilMin(s.end)
            while (m < stop) { val o = slot[m]; if (o == null || o.p < pr) slot[m] = Slot(pr, s.stage); m++ }
        }
        return slot
    }

    private fun tally(g: Group): Tally {
        val slot = slotsOf(g.segs)
        var d = 0; var r = 0; var l = 0; var a = 0; var u = 0
        slot.values.forEach { when (it.st) { "deep" -> d++; "rem" -> r++; "light" -> l++; "awake" -> a++; else -> u++ } }
        return Tally(d, r, l, a, u, slot)
    }

    /**
     * Real start/end of the night. The watch often logs sleep fragments hours before real sleep (e.g. 19:37 / 20:37 when
     * asleep at 22:20) and after waking. A minute is "core" when +-30 min around it hold >= 42 minutes of sleep. The night
     * runs from the first to the last core minute, extended over connected sleep (gaps <= 3 min ignored), then over
     * adjoining awake minutes (<= 30 at the start = time to fall asleep, <= 15 at the end).
     */
    private fun trimFrags(g: Group) {
        val HALF = 30; val NEED = 42; val GAPOK = 3; val LATMAX = 30; val ENDMAX = 15
        val slot = slotsOf(g.segs)
        if (slot.isEmpty()) return
        val lo = slot.keys.minOrNull()!!; val hi = slot.keys.maxOrNull()!!; val n = (hi - lo + 1).toInt()
        fun sl(k: Int): Boolean { val o = slot[lo + k]; return o != null && o.st != "awake" }
        fun aw(k: Int): Boolean { val o = slot[lo + k]; return o != null && o.st == "awake" }
        val pre = IntArray(n + 1)
        for (i in 0 until n) pre[i + 1] = pre[i] + if (sl(i)) 1 else 0
        fun cnt(a0: Int, b0: Int): Int { val a = max(a0, 0); val b = min(b0, n); return if (b > a) pre[b] - pre[a] else 0 }
        fun core(k: Int) = sl(k) && cnt(k - HALF, k + HALF) >= NEED
        var on = -1; var off = -1
        for (i in 0 until n) if (core(i)) { on = i; break }
        for (i in n - 1 downTo 0) if (core(i)) { off = i; break }
        if (on < 0) {
            // Short session without any core minute: legacy island rule (gap >= 20 min separates, edge islands <= 10 min dropped).
            val GAP = 1200L; val MAXSPAN = 600L
            class Isl(val s: Long, var e: Long, val segs: MutableList<Seg>)
            val isl = mutableListOf<Isl>(); var c: Isl? = null
            g.segs.sortedBy { it.start }.forEach { s ->
                if (c == null || s.start - c!!.e >= GAP) { c = Isl(s.start, s.end, mutableListOf()); isl += c!! }
                c!!.e = max(c!!.e, s.end); c!!.segs += s
            }
            val cut = mutableListOf<Seg>()
            while (isl.size > 1 && isl.first().e - isl.first().s <= MAXSPAN) cut += isl.removeAt(0).segs
            while (isl.size > 1 && isl.last().e - isl.last().s <= MAXSPAN) cut += isl.removeAt(isl.size - 1).segs
            g.segs = isl.flatMap { it.segs }; g.start = isl.first().s; g.end = isl.last().e; g.cut = cut
            return
        }
        var a = on; var b = off; var run = 0
        for (j in on - 1 downTo 0) { if (sl(j)) { a = j; run = 0 } else if (++run > GAPOK) break }
        run = 0
        for (j in off + 1 until n) { if (sl(j)) { b = j; run = 0 } else if (++run > GAPOK) break }
        b++
        var j = 0
        while (j < LATMAX && a > 0 && aw(a - 1)) { a--; j++ }
        j = 0
        while (j < ENDMAX && b < n && aw(b)) { b++; j++ }
        val s0 = (lo + a) * 60; val e0 = (lo + b) * 60
        val keep = mutableListOf<Seg>(); val cut = mutableListOf<Seg>()
        g.segs.forEach { s ->
            if (s.start < s0) { val pe = min(s.end, s0); if (pe > s.start) cut += Seg(s.start, pe, s.stage) }
            if (s.end > e0) { val qs = max(s.start, e0); if (s.end > qs) cut += Seg(qs, s.end, s.stage) }
            if (s.end > s0 && s.start < e0) keep += if (s.start >= s0 && s.end <= e0) s else Seg(max(s.start, s0), min(s.end, e0), s.stage)
        }
        g.segs = keep; g.start = s0; g.end = e0; g.cut = cut
    }

    /**
     * Awake ranges inside the night: from the first to the last sleep minute, minutes that are awake or without data are
     * joined into ranges. Ranges >= 3 min count; pure no-data gaps (>= 10 min) are only shown (gap = true) because the
     * watch recorded nothing there, so they are no proof of waking. Latency and the tail are excluded.
     */
    private fun wakesOf(slot: Map<Long, Slot>, hm: (Long) -> String): Pair<List<Wake>, Long?> {
        val ks = slot.keys.sorted()
        var f = -1L; var l = -1L
        ks.forEach { k -> if (slot.getValue(k).st != "awake") { if (f < 0) f = k; l = k } }
        if (f < 0) return emptyList<Wake>() to null
        class R(val a: Long, var b: Long, var miss: Int)
        val out = mutableListOf<R>(); var c: R? = null
        var m = f
        while (m <= l) {
            val o = slot[m]; val aw = o == null || o.st == "awake"
            if (aw) {
                if (c == null) { c = R(m, m + 1, 0); out += c!! } else c!!.b = m + 1
                if (o == null) c!!.miss++
            } else c = null
            m++
        }
        val wakes = out.filter { val len = (it.b - it.a).toInt(); len >= (if (it.miss == len) 10 else 3) }
            .map { Wake(hm(it.a * 60), hm(it.b * 60), (it.b - it.a).toInt(), it.miss == (it.b - it.a).toInt()) }
        return wakes to f
    }
}
