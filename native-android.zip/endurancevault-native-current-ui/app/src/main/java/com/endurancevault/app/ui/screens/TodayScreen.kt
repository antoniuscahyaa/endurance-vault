package com.endurancevault.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.domain.*
import com.endurancevault.app.ui.UiState
import java.time.LocalDate
import java.time.DayOfWeek
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun TodayScreen(state: UiState, onAdd: (ActivityEntity) -> Unit, weatherMessage: String = "", weatherPlace: String = "Lokasi belum diatur", weatherBusy: Boolean = false, onRefreshWeather: (() -> Unit)? = null) {
    var dialog by remember { mutableStateOf(false) }
    var showSessionDetail by remember { mutableStateOf(false) }
    val today=LocalDate.now()
    val plan=state.plan
    val planOk=plan as? PlanOutcome.Ok
    val week=planOk?.weeks?.firstOrNull { !today.isBefore(it.start) && !today.isAfter(it.end) }
    val day=week?.days?.firstOrNull { it.date==today }
    val metrics=remember(state.settings,state.activities,state.daily,state.plan,state.hrHistByActivity) {
        TrainingMetrics.calculate(state.settings,state.activities,state.daily,state.plan,today,hrHistByActivity=state.hrHistByActivity)
    }
    val readiness=metrics.readiness
    val lastRun=state.activities.filter { it.km>0 && it.type!="bike" }
        .maxByOrNull { it.dateIso }
    val weekStart=today.with(DayOfWeek.MONDAY)
    val weekActivities=state.activities.filter { it.dateIso>=weekStart.toString() && it.dateIso<=today.toString() && it.type!="bike" }
    val doneDates=weekActivities.map { it.dateIso }.toSet()
    val plannedKm=week?.km ?: 0.0
    val completedKm=weekActivities.sumOf { it.km }
    val progress=if(plannedKm>0) (completedKm/plannedKm).coerceIn(0.0,1.0) else 0.0

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=16.dp, vertical=14.dp),
        verticalArrangement=Arrangement.spacedBy(12.dp),
    ) {
        Column(verticalArrangement=Arrangement.spacedBy(2.dp)) {
            Text("TODAY",style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.primary)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                Text("Hari ini",style=MaterialTheme.typography.headlineMedium)
                Text(today.format(DateTimeFormatter.ofPattern("EEE, d MMM",Locale.ENGLISH)),style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        if (weatherMessage.isNotBlank()) {
            val weatherLines=weatherMessage.lines()
            val current=weatherLines.firstOrNull { it.startsWith("CUACA SAAT INI") }
            val temperature=weatherLines.getOrNull(1).orEmpty()
            EvPanel(Modifier.fillMaxWidth(), containerColor=MaterialTheme.colorScheme.inverseSurface) {
                Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(4.dp)) {
                            Text("WEATHER",style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.inverseOnSurface)
                            Text(temperature.substringBefore(" · ").ifBlank { if(weatherBusy) "Memuat cuaca…" else current ?: "Cuaca tidak tersedia" },
                                style=MaterialTheme.typography.headlineMedium,color=MaterialTheme.colorScheme.inverseOnSurface)
                            Text("$weatherPlace · ${temperature.substringAfter("· ", "")}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.inverseOnSurface)
                        }
                        if(onRefreshWeather!=null) TextButton(onClick=onRefreshWeather,enabled=!weatherBusy) { Text(if(weatherBusy) "…" else "↻",color=MaterialTheme.colorScheme.inverseOnSurface) }
                    }
                    HorizontalDivider(color=MaterialTheme.colorScheme.inverseOnSurface.copy(alpha=.25f))
                    Text("Weather details  ▾",style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.inverseOnSurface)
                    Text(weatherMessage.substringAfter("KUALITAS UDARA", "").takeIf { it.isNotBlank() }?.take(180) ?: "Informasi cuaca dan prakiraan tersedia saat data berhasil dimuat.",
                        style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.inverseOnSurface.copy(alpha=.8f),maxLines=3,overflow=TextOverflow.Ellipsis)
                }
            }
        }

        when(plan) {
            is PlanOutcome.Err -> EvPanel(Modifier.fillMaxWidth()) { Text(plan.message,Modifier.padding(16.dp),color=MaterialTheme.colorScheme.error) }
            is PlanOutcome.Ok -> {
                if(day==null) {
                    EvPanel(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(5.dp)) {
                            Text("TODAY’S SESSION",style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.primary)
                            Text("Tidak ada sesi terjadwal hari ini",style=MaterialTheme.typography.titleLarge)
                            Text("Gunakan hari ini untuk pemulihan atau catat aktivitas jika tetap berlatih.",style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                } else {
                    EvPanel(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                            Row(verticalAlignment=Alignment.CenterVertically) {
                                Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(5.dp)) {
                                    Text("TODAY’S SESSION",style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.primary)
                                    Text(day.title,style=MaterialTheme.typography.headlineSmall)
                                    Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                        if(day.km>0) Text("${fmtKmUi(day.km)} km",style=MaterialTheme.typography.titleMedium)
                                        Surface(color=MaterialTheme.colorScheme.surfaceVariant,shape=RoundedCornerShape(50)) {
                                            Text(if(state.activities.any{it.dateIso==today.toString()}) "Aktivitas tercatat" else "Belum dicatat",
                                                Modifier.padding(horizontal=10.dp,vertical=5.dp),style=MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                                if(readiness!=null) ReadinessRing(readiness.score,readiness.tier)
                            }
                            if(day.detail.isNotBlank()) {
                                Text(day.detail,maxLines=if(showSessionDetail) 12 else 2,overflow=TextOverflow.Ellipsis,
                                    style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
                                TextButton(onClick={showSessionDetail=!showSessionDetail},contentPadding=PaddingValues(0.dp)) {
                                    Text(if(showSessionDetail) "Sembunyikan detail" else "Detail sesi⌄")
                                }
                            }
                            Button(onClick={ if(day.detail.isNotBlank()) showSessionDetail=true else dialog=true },
                                shape=RoundedCornerShape(50)) { Text(if(day.detail.isNotBlank()) "Buka sesi" else "Catat aktivitas") }
                            if(readiness!=null && readiness.advice.isNotBlank()) Text(readiness.advice,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    if(showSessionDetail) SupportBlocks(day,expanded=true)
                }
            }
        }

        EvPanel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                    Text("THIS WEEK",style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.primary)
                    Text("%.1f km / %.0f km · %d%%".format(completedKm,plannedKm, (progress*100).toInt()),style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                    (0..6).forEach { index ->
                        val date=weekStart.plusDays(index.toLong())
                        val pday=week?.days?.firstOrNull{it.date==date}
                        val done=date.toString() in doneDates
                        val isToday=date==today
                        val isMissed=date.isBefore(today) && pday!=null && pday.kind!=Kinds.REST && !done
                        val tint=when { done->MaterialTheme.colorScheme.tertiary; isMissed->MaterialTheme.colorScheme.error; else->MaterialTheme.colorScheme.onSurfaceVariant }
                        Column(Modifier.weight(1f).clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha=if(isToday).72f else .38f))
                            .then(if(isToday) Modifier.border(1.5.dp,MaterialTheme.colorScheme.primary,RoundedCornerShape(14.dp)) else Modifier)
                            .padding(vertical=8.dp),
                            horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(5.dp)) {
                            Text(date.dayOfWeek.getDisplayName(java.time.format.TextStyle.SHORT,Locale.ENGLISH),style=MaterialTheme.typography.labelSmall,color=tint)
                            Box(Modifier.size(13.dp).clip(CircleShape)
                                .background(if(done) tint else MaterialTheme.colorScheme.surface)
                                .then(if(done) Modifier else Modifier.border(1.5.dp,tint,CircleShape)))
                        }
                    }
                }
                Text("Minggu ${week?.i ?: "—"} dari ${planOk?.n ?: "—"}",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            HomeMetric("ACWR",if(metrics.ratio>0) "%.2f".format(metrics.ratio) else "—",metrics.status)
            val streak=calculateRunStreak(state.activities,today)
            HomeMetric("Streak",streak.toString(),if(streak==1) "hari" else "hari berturut-turut")
        }
        EvPanel(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(14.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                Text("Last run",style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
                Text(lastRun?.let { "${relativeRunDate(it.dateIso,today)} · ${fmtKmUi(it.km)} km · ${runPace(it)} /km" } ?: "Belum ada aktivitas",
                    style=MaterialTheme.typography.titleSmall)
            }
        }
        EvPanel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                    Text("TRAINING LOAD",style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.primary)
                    Text("ATL:CTL ${if(metrics.ratio>0) "%.2f".format(metrics.ratio) else "—"}",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                    HomeMetric("FITNESS (CTL)",metrics.fitness.toString(),"")
                    HomeMetric("FATIGUE (ATL)",metrics.fatigue.toString(),"")
                    HomeMetric("FORM (TSB)",metrics.form.toString(),"")
                }
            }
        }
        OutlinedButton(onClick={dialog=true},Modifier.fillMaxWidth(),shape=RoundedCornerShape(50)) { Text("Catat lari manual") }
    }

    if(dialog) LogRunDialog(onDismiss={dialog=false}) { km,min,hr ->
        onAdd(ActivityEntity(dateIso=today.toString(),km=km,durationSec=min*60,avgHr=hr))
        dialog=false
    }
}

@Composable private fun ReadinessRing(score:Int,tier:String) {
    Column(horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(3.dp)) {
        Box(Modifier.size(76.dp).clip(CircleShape).background(MaterialTheme.colorScheme.tertiaryContainer),contentAlignment=Alignment.Center) {
            Text(score.toString(),style=MaterialTheme.typography.headlineMedium,color=MaterialTheme.colorScheme.onTertiaryContainer)
        }
        Text(tier,style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.tertiary)
        Text("Readiness",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
@Composable private fun RowScope.HomeMetric(label:String,value:String,sub:String) {
    EvPanel(Modifier.weight(1f)) {
        Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(4.dp)) {
            Text(label,style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value,style=MaterialTheme.typography.headlineSmall)
            if(sub.isNotBlank()) Text(sub,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant,maxLines=2)
        }
    }
}
private fun calculateRunStreak(activities:List<ActivityEntity>,today:LocalDate):Int {
    val dates=activities.filter{it.type!="bike"&&it.km>0}.mapNotNull{runCatching{LocalDate.parse(it.dateIso)}.getOrNull()}.toSet()
    var date=if(today in dates) today else today.minusDays(1)
    var count=0
    while(date in dates && count<365) { count++; date=date.minusDays(1) }
    return count
}
private fun relativeRunDate(iso:String,today:LocalDate):String {
    val d=runCatching{LocalDate.parse(iso)}.getOrNull()?:return iso
    return when(java.time.temporal.ChronoUnit.DAYS.between(d,today).toInt()) { 0->"hari ini";1->"kemarin";else->d.format(DateTimeFormatter.ofPattern("d MMM",Locale.ENGLISH)) }
}
private fun runPace(a:ActivityEntity):String=if(a.km>0&&a.durationSec>0) "%.2f".format(a.durationSec/60.0/a.km) else "—"

@Composable
private fun LogRunDialog(onDismiss:()->Unit,onSave:(Double,Int,Int?)->Unit) {
    var km by remember{mutableStateOf("")}; var min by remember{mutableStateOf("")}; var hr by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=onDismiss,title={Text("Catat lari")},text={
        Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(km,{km=it},label={Text("Jarak (km)")},singleLine=true)
            OutlinedTextField(min,{min=it},label={Text("Durasi (menit)")},singleLine=true)
            OutlinedTextField(hr,{hr=it},label={Text("HR rata-rata (opsional)")},singleLine=true)
        }
    },confirmButton={TextButton(onClick={
        val k=km.replace(',','.').toDoubleOrNull(); val m=min.toIntOrNull()
        if(k!=null&&k>0&&m!=null&&m>0) onSave(k,m,hr.toIntOrNull())
    }){Text("Simpan")}},dismissButton={TextButton(onClick=onDismiss){Text("Batal")}})
}

internal fun fmtKmUi(x:Double):String=if(x==kotlin.math.floor(x)) x.toLong().toString() else "%.1f".format(x).replace('.',',')
