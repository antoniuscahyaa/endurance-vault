package com.endurancevault.app.data

import android.content.Context
import com.endurancevault.app.domain.PbAk
import com.endurancevault.app.domain.PbConv
import com.endurancevault.app.domain.PbPost
import com.endurancevault.app.domain.PlanSettings
import java.time.LocalDate

/** Penyimpanan pengaturan rencana (SharedPreferences). */
class SettingsStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("plan_settings", Context.MODE_PRIVATE)

    fun load(): PlanSettings {
        val d = PlanSettings(start = LocalDate.now())
        fun dbl(k: String): Double? = if (sp.contains(k)) sp.getFloat(k, 0f).toDouble() else null
        return PlanSettings(
            name = sp.getString("name", "") ?: "",
            rtype = sp.getString("rtype", d.rtype) ?: d.rtype,
            start = date("start") ?: d.start,
            race = date("race"),
            raceKm = dbl("raceKm"),
            raceGain = dbl("raceGain"),
            goalT = sp.getString("goalT", "") ?: "",
            base = sp.getFloat("base", d.base.toFloat()).toDouble(),
            peak = sp.getFloat("peak", d.peak.toFloat()).toDouble(),
            days = sp.getInt("days", d.days),
            rest = sp.getInt("rest", d.rest),
            rest2 = sp.getInt("rest2", d.rest2),
            longDay = sp.getInt("longDay", d.longDay),
            hr = sp.getInt("hr", d.hr),
            thr = sp.getString("thr", d.thr) ?: d.thr,
            pace = sp.getString("pace", d.pace) ?: d.pace,
            hrMax = if (sp.contains("hrMax")) sp.getInt("hrMax", 0) else null,
            bspd = sp.getFloat("bspd", d.bspd.toFloat()).toDouble(),
            pbCycle = sp.getString("pbCycle", d.pbCycle) ?: d.pbCycle,
            pbFocus = sp.getString("pbFocus", d.pbFocus) ?: d.pbFocus,
            pbPost = if (sp.contains("pbPostRec")) PbPost(sp.getFloat("pbPostRec", 0f).toDouble(), sp.getFloat("pbPostLvl", 0f).toDouble()) else null,
            pbConv = if (sp.contains("pbConvWk")) PbConv(sp.getInt("pbConvWk", 0), sp.getFloat("pbConvB0", 0f).toDouble(), sp.getFloat("pbConvP0", 0f).toDouble()) else null,
            pbAk = date("pbAkWk")?.let { PbAk(it, sp.getFloat("pbAkKm", 0f).toDouble()) },
            evOn = sp.getBoolean("evOn", false),
            evDate = date("evDate"),
            evKm = sp.getFloat("evKm", 0f).toDouble(),
            evGain = sp.getFloat("evGain", 0f).toDouble(),
            zm = sp.getString("zm", d.zm) ?: d.zm,
            lthr = dbl("lthr"),
            rhr = dbl("rhr"),
            zl = sp.getString("zl", null)?.split(",")?.mapNotNull { it.toDoubleOrNull() }?.takeIf { it.size == 4 } ?: d.zl,
            zr = sp.getString("zr", null)?.split(",")?.mapNotNull { it.toDoubleOrNull() }?.takeIf { it.size == 5 } ?: d.zr,
            method = sp.getString("method", d.method) ?: d.method,
            qSess = sp.getString("qSess", d.qSess) ?: d.qSess,
            sLeg = sp.getBoolean("sLeg", d.sLeg),
            sAnk = sp.getBoolean("sAnk", d.sAnk),
            sUp = sp.getString("sUp", d.sUp) ?: d.sUp,
            gSmooth = sp.getBoolean("gSmooth", d.gSmooth),
            gBase = sp.getFloat("gBase", 0f).toDouble(),
            easyRun = com.endurancevault.app.domain.EasyRunConfig(
                warm=sp.getInt("ez_warm",2), easyTolerance=sp.getInt("ez_eTol",4), easyBand=sp.getInt("ez_eBand",6),
                easyPass=sp.getInt("ez_ePass",95), easyOk=sp.getInt("ez_eOk",85),
                longTolerance=sp.getInt("ez_lTol",8), longBand=sp.getInt("ez_lBand",8),
                longPass=sp.getInt("ez_lPass",85), longOk=sp.getInt("ez_lOk",80),
                strideCount=sp.getInt("ez_sN",2), stridePercent=sp.getInt("ez_sPct",30),
                strideMinSec=sp.getInt("ez_sMin",10), strideMaxSec=sp.getInt("ez_sMax",50),
                heatEnabled=sp.getBoolean("ez_heat",false), heatThreshold=sp.getInt("ez_heatT",26),
                heatCut=sp.getInt("ez_heatC",2), sleepEnabled=sp.getBoolean("ez_slp",false),
            ),
        )
    }

    fun save(s: PlanSettings) {
        val e = sp.edit().clear()
            .putString("name", s.name).putString("rtype", s.rtype).putString("start", s.start.toString())
            .putString("goalT", s.goalT)
            .putFloat("base", s.base.toFloat()).putFloat("peak", s.peak.toFloat())
            .putInt("days", s.days).putInt("rest", s.rest).putInt("rest2", s.rest2).putInt("longDay", s.longDay)
            .putInt("hr", s.hr).putString("thr", s.thr).putString("pace", s.pace).putFloat("bspd", s.bspd.toFloat())
            .putString("pbCycle", s.pbCycle).putString("pbFocus", s.pbFocus)
            .putString("zm", s.zm).putString("zl", s.zl.joinToString(",")).putString("zr", s.zr.joinToString(","))
            .putBoolean("evOn", s.evOn).putFloat("evKm", s.evKm.toFloat()).putFloat("evGain", s.evGain.toFloat())
            .putString("method", s.method).putString("qSess", s.qSess)
            .putBoolean("sLeg", s.sLeg).putBoolean("sAnk", s.sAnk).putString("sUp", s.sUp)
            .putBoolean("gSmooth", s.gSmooth).putFloat("gBase", s.gBase.toFloat())
            .putInt("ez_warm",s.easyRun.warm).putInt("ez_eTol",s.easyRun.easyTolerance).putInt("ez_eBand",s.easyRun.easyBand)
            .putInt("ez_ePass",s.easyRun.easyPass).putInt("ez_eOk",s.easyRun.easyOk)
            .putInt("ez_lTol",s.easyRun.longTolerance).putInt("ez_lBand",s.easyRun.longBand)
            .putInt("ez_lPass",s.easyRun.longPass).putInt("ez_lOk",s.easyRun.longOk)
            .putInt("ez_sN",s.easyRun.strideCount).putInt("ez_sPct",s.easyRun.stridePercent)
            .putInt("ez_sMin",s.easyRun.strideMinSec).putInt("ez_sMax",s.easyRun.strideMaxSec)
            .putBoolean("ez_heat",s.easyRun.heatEnabled).putInt("ez_heatT",s.easyRun.heatThreshold)
            .putInt("ez_heatC",s.easyRun.heatCut).putBoolean("ez_slp",s.easyRun.sleepEnabled)
        s.race?.let { e.putString("race", it.toString()) }
        s.lthr?.let { e.putFloat("lthr", it.toFloat()) }
        s.rhr?.let { e.putFloat("rhr", it.toFloat()) }
        s.raceKm?.let { e.putFloat("raceKm", it.toFloat()) }
        s.raceGain?.let { e.putFloat("raceGain", it.toFloat()) }
        s.hrMax?.let { e.putInt("hrMax", it) }
        s.pbPost?.let { e.putFloat("pbPostRec", it.rec.toFloat()).putFloat("pbPostLvl", it.lvl.toFloat()) }
        s.pbConv?.let { e.putInt("pbConvWk", it.wk).putFloat("pbConvB0", it.b0.toFloat()).putFloat("pbConvP0", it.p0.toFloat()) }
        s.pbAk?.let { e.putString("pbAkWk", it.wk.toString()).putFloat("pbAkKm", it.km.toFloat()) }
        s.evDate?.let { e.putString("evDate", it.toString()) }
        e.apply()
    }

    private fun date(key: String): LocalDate? =
        sp.getString(key, null)?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
}
