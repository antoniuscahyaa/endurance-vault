package com.endurancevault.app.domain

import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.data.DailyEntity
import java.time.LocalDate
import java.time.DayOfWeek
import kotlin.math.*

data class RunningAbility(val value: Double, val runs: Int, val weekly: List<Pair<LocalDate, Double>>)
data class AcuteChronic(val acute: Double, val chronic: Double, val ratio: Double, val daysWithLoad: Int)
data class MonotonyStrain(val load: Double, val mean: Double, val sd: Double, val monotony: Double, val strain: Double)
data class IntensityDistribution(val z1z2: Double, val z3: Double, val z4z5: Double, val totalSeconds: Double)
data class RouteActivity(val id: Long, val dateIso: String, val km: Double, val route: List<Pair<Int, Int>>)
data class SimilarRouteGroup(val members: List<RouteActivity>, val representative: RouteActivity)
data class PersonalBest(val label: String, val distanceKm: Double, val durationMinutes: Double, val activityId: Long, val dateIso: String)

object ProgressAnalytics {
    private fun median(values: List<Double>): Double? {
        if (values.isEmpty()) return null
        val s = values.sorted()
        return if (s.size % 2 == 1) s[s.size / 2] else (s[s.size / 2 - 1] + s[s.size / 2]) / 2.0
    }

    fun runningAbility(settings: PlanSettings, activities: List<ActivityEntity>, daily: List<DailyEntity>, today: LocalDate = LocalDate.now()): RunningAbility? {
        val rest = median(daily.filter {
            runCatching { !LocalDate.parse(it.dateIso).isAfter(today) && !LocalDate.parse(it.dateIso).isBefore(today.minusDays(13)) }.getOrDefault(false)
        }.mapNotNull { it.rhr?.takeIf { v -> v > 0 }?.toDouble() }) ?: settings.rhr?.toDouble() ?: 55.0
        val maxObserved = activities.mapNotNull { it.maxHr }.maxOrNull() ?: 0
        val maxHr = max(settings.hrMax ?: 0, max(maxObserved, settings.lthr?.div(.9)?.roundToInt() ?: 190))
        val all = activities.mapNotNull { a ->
            if (a.type == "bike" || a.km < 3 || a.durationSec <= 0 || a.avgHr == null || a.avgHr <= 0) return@mapNotNull null
            val pace = (a.durationSec / 60.0 - (a.gain ?: 0) / 100.0 * 3.0) / a.km
            if (pace !in 2.5..12.0) return@mapNotNull null
            val hrr = (a.avgHr - rest) / (maxHr - rest).coerceAtLeast(1)
            if (hrr !in .5..1.02) return@mapNotNull null
            val velocity = 1000.0 / pace
            val vo2 = -4.6 + .182258 * velocity + .000104 * velocity * velocity
            val rai = (vo2 - 3.5) / hrr + 3.5
            if (rai !in 20.0..85.0) null else runCatching { LocalDate.parse(a.dateIso) to rai }.getOrNull()
        }.sortedBy { it.first }
        if (all.size < 3) return null
        val recent = all.filter { !it.first.isBefore(today.minusDays(27)) }
            .ifEmpty { all.takeLast(6) }
        if (recent.size < 3) return null
        val grouped = all.groupBy { it.first.with(DayOfWeek.MONDAY) }.toSortedMap()
            .mapNotNull { (week, rows) -> median(rows.map { it.second })?.let { week to it } }
        return RunningAbility(median(recent.map { it.second })!!, recent.size, grouped)
    }

    fun acuteChronic(days: List<LoadDay>, end: LocalDate = LocalDate.now()): AcuteChronic? {
        val map = days.associateBy { it.date }
        val loads = (0 until 28).map { map[end.minusDays(it.toLong())]?.load?.takeIf { v -> v > 0 } ?: 0.0 }
        val active = loads.count { it > 0 }
        val chronic = loads.sum() / 4.0
        if (active < 8 || chronic <= 0) return null
        val acute = loads.take(7).sum()
        return AcuteChronic(acute, chronic, acute / chronic, active)
    }

    fun monotonyStrain(days: List<LoadDay>, end: LocalDate = LocalDate.now()): MonotonyStrain? {
        val map = days.associateBy { it.date }
        val values = (0 until 7).map { map[end.minusDays(it.toLong())]?.load ?: 0.0 }
        val total = values.sum()
        if (total <= 0) return null
        val mean = values.average()
        val sd = sqrt(values.sumOf { (it - mean).pow(2) } / values.size)
        val monotony = if (sd < 1e-9) 9.9 else min(9.9, mean / sd)
        return MonotonyStrain(total, mean, sd, monotony, total * monotony)
    }

    fun intensity(histograms: Collection<Map<Int, Double>>, lthr: Int, hrMax: Int): IntensityDistribution? {
        val bins = histograms.flatMap { it.entries }
        val total = bins.sumOf { it.value }.takeIf { it > 0 } ?: return null
        val z1z2 = bins.filter { it.key < lthr }.sumOf { it.value }
        val z3 = bins.filter { it.key >= lthr && it.key < lthr + .35 * (hrMax - lthr) }.sumOf { it.value }
        val z4z5 = bins.filter { it.key >= lthr + .35 * (hrMax - lthr) }.sumOf { it.value }
        return IntensityDistribution(z1z2 / total * 100, z3 / total * 100, z4z5 / total * 100, total)
    }

    private fun routeShape(route: RouteActivity): List<Pair<Double, Double>>? {
        if (route.km < 1.5 || route.route.size < 8) return null
        var length = 0.0
        for (i in 1 until route.route.size) {
            val dx = (route.route[i].first - route.route[i-1].first).toDouble()
            val dy = (route.route[i].second - route.route[i-1].second).toDouble()
            length += hypot(dx, dy)
        }
        if (length <= 0) return null
        val scale = route.km * 1000.0 / length
        val raw = route.route.map { it.first * scale to -it.second * scale }
        val cx = raw.map { it.first }.average()
        val cy = raw.map { it.second }.average()
        return raw.map { (x,y) -> x-cx to y-cy }
    }

    private fun resample(points: List<Pair<Double,Double>>, n: Int = 48): List<Pair<Double,Double>>? {
        if (points.size < 2) return null
        val cumulative = mutableListOf(0.0)
        for (i in 1 until points.size) cumulative += cumulative.last() + hypot(points[i].first-points[i-1].first, points[i].second-points[i-1].second)
        val total = cumulative.last()
        if (total <= 0) return null
        return (0 until n).map { index ->
            val target = total * index / (n-1)
            var j = 1
            while (j < points.lastIndex && cumulative[j] < target) j++
            val span = cumulative[j]-cumulative[j-1]
            val f = if (span > 0) ((target-cumulative[j-1])/span).coerceIn(0.0,1.0) else 0.0
            points[j-1].first+(points[j].first-points[j-1].first)*f to
                points[j-1].second+(points[j].second-points[j-1].second)*f
        }
    }

    private fun p90Distance(a: List<Pair<Double,Double>>, b: List<Pair<Double,Double>>): Double {
        val distances = a.map { p -> b.minOf { q -> hypot(p.first-q.first,p.second-q.second) } }.sorted()
        return distances[(distances.size * .9).toInt().coerceAtMost(distances.lastIndex)]
    }

    fun similarRoutes(activities: List<RouteActivity>): List<SimilarRouteGroup> {
        val candidates = activities.sortedBy { it.dateIso }.mapNotNull { a -> routeShape(a)?.let { a to it } }
        val groups = mutableListOf<MutableList<Pair<RouteActivity,List<Pair<Double,Double>>>>>()
        candidates.forEach { candidate ->
            val (activity, shape) = candidate
            val hit = groups.firstOrNull { group ->
                val (rep, repShape) = group.first()
                val ratio = activity.km / rep.km
                if (ratio !in .88..1.14) false else {
                    val a = resample(shape) ?: return@firstOrNull false
                    val b = resample(repShape) ?: return@firstOrNull false
                    max(p90Distance(a,b), p90Distance(b,a)) <= max(35.0, activity.km*1000*.045)
                }
            }
            if (hit != null) hit += candidate else groups += mutableListOf(candidate)
        }
        return groups.filter { it.size >= 2 }.map { group ->
            SimilarRouteGroup(group.map { it.first }, group.first().first)
        }.sortedByDescending { it.members.size }
    }

    fun personalBests(details: Map<Long, ActDetail>): List<PersonalBest> {
        val definitions = listOf(Triple("1 km",1,1.0), Triple("5K",5,5.0), Triple("10K",10,10.0), Triple("Half marathon",21,21.0975))
        return definitions.mapNotNull { (label, count, distance) ->
            var best: PersonalBest? = null
            details.forEach { (id, detail) ->
                if (detail.bike || detail.splits.size < count || detail.km < distance - .005) return@forEach
                val full = detail.splits.takeWhile { !it.partial }
                if (full.size < count) return@forEach
                for (start in 0..(full.size-count)) {
                    val selected = full.subList(start,start+count)
                    if (selected.any { it.pace !in 2.0..20.0 }) continue
                    var minutes = selected.sumOf { it.pace }
                    if (distance > count) {
                        val next = full.getOrNull(start+count)?.pace?.takeIf { it in 2.0..20.0 } ?: (minutes/count)
                        minutes += (distance-count)*next
                    }
                    if (best == null || minutes < best!!.durationMinutes) {
                        best = PersonalBest(label,distance,minutes,id,detail.date)
                    }
                }
            }
            best
        }
    }
}
