package com.endurancevault.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.domain.PainReadinessEntry
import com.endurancevault.app.domain.InjuryPrevention
import com.endurancevault.app.domain.TrainingMethod
import com.endurancevault.app.ui.ImportUi
import com.endurancevault.app.ui.UiState
import com.endurancevault.app.data.DailyEntity
import com.endurancevault.app.data.GearEntity
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.TextButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import java.time.LocalDate
import kotlin.math.roundToInt

private val TYPES = listOf(
    "5k" to "5K", "10k" to "10K", "hm" to "Half marathon", "fm" to "Marathon",
    "ultra" to "Trail", "ultrar" to "Ultra road", "pb" to "Performance Build", "none" to "No Race",
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileScreen(
    state: UiState,
    onSave: (PlanSettings) -> Unit,
    importUi: ImportUi,
    onImport: (Uri) -> Unit,
    onConfirmImport: () -> Unit,
    onDismissImport: () -> Unit,
    onMergeDuplicates: () -> Unit,
    onScanDuplicates: () -> Unit,
    duplicateStatus: String,
    onSaveDaily: (DailyEntity) -> Unit,
    onSaveGear: (GearEntity) -> Unit,
    onDeleteGear: (String) -> Unit,
    watchMessage: String,
    onConnectWatch: (String) -> Unit,
    onDisconnectWatch: () -> Unit,
    onForgetAndReconnectWatch: (String) -> Unit,
    onSyncWatch: (Boolean) -> Unit,
    watchSyncing: Boolean,
    watchAdvancedMessage: String,
    liveHr: org.json.JSONObject,
    onRefreshLiveHr: () -> Unit,
    onSetLiveHr: (Boolean) -> Unit,
    onSyncHrZones: (PlanSettings) -> Unit,
    onPushWorkout: (String, Int, Int, Int, Int, Int) -> Unit,
    onPushRoute: (Uri) -> Unit,
    weatherMessage: String, weatherBusy: Boolean, weatherLat: String, weatherLon: String,
    onFetchWeather: (Double,Double) -> Unit, onSearchWeatherCity: (String) -> Unit, onUseWeatherLocation: () -> Unit, onWeatherToWatch: (Double,Double,String) -> Unit,
    weatherWatchStatus: String, agpsStatus: String, onAgps: (Boolean,String) -> Unit, onTestAgps: () -> Unit,
    notifyStatus: String, onNotify: (Boolean,Boolean,Int,Int,Boolean,Map<String,Boolean>) -> Unit, onTestNotify: () -> Unit,
    aiStatus: String, aiMessages: List<Pair<String,String>>, onAiKey: (String) -> Unit,
    onAiSend: (String,String,Boolean) -> Unit, aiBusy: Boolean,
    onDeleteActivity: (Long) -> Unit, onOpenActivity: (Long) -> Unit,
    onImportTracks: (List<Uri>) -> Unit, trackMsg: String?,
) {
    var showDuplicateConfirm by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) onImport(uri) }
    val s = state.settings
    // Zona HR tersimpan otomatis oleh HrZoneSettings; jangan reset isian form lain saat zona berubah.
    val formKey = s.copy(zm = "lthr", lthr = null, rhr = null, zl = com.endurancevault.app.domain.Zones.ZLD, zr = com.endurancevault.app.domain.Zones.ZRD)
    var rtype by remember(formKey) { mutableStateOf(s.rtype) }
    var name by remember(formKey) { mutableStateOf(s.name) }
    var start by remember(formKey) { mutableStateOf(s.start.toString()) }
    var race by remember(formKey) { mutableStateOf(s.race?.toString() ?: "") }
    var raceKm by remember(formKey) { mutableStateOf(s.raceKm?.let { fmtKmUi(it) } ?: "") }
    var raceGain by remember(formKey) { mutableStateOf(s.raceGain?.let { fmtKmUi(it) } ?: "") }
    var goal by remember(formKey) { mutableStateOf(s.goalT) }
    var base by remember(formKey) { mutableStateOf(fmtKmUi(s.base)) }
    var peak by remember(formKey) { mutableStateOf(fmtKmUi(s.peak)) }
    var days by remember(formKey) { mutableStateOf(s.days) }
    var longDay by remember(formKey) { mutableStateOf(s.longDay.toString()) }
    var hr by remember(formKey) { mutableStateOf(s.hr.toString()) }
    var thr by remember(formKey) { mutableStateOf(s.thr) }
    var pace by remember(formKey) { mutableStateOf(s.pace) }
    var method by remember(formKey) { mutableStateOf(s.method) }
    var qSess by remember(formKey) { mutableStateOf(s.qSess) }
    var sLeg by remember(formKey) { mutableStateOf(s.sLeg) }
    var sAnk by remember(formKey) { mutableStateOf(s.sAnk) }
    var sUp by remember(formKey) { mutableStateOf(s.sUp) }
    var err by remember { mutableStateOf<String?>(null) }
    var profileSection by remember { mutableStateOf("Hari ini") }
    LaunchedEffect(openSettings) { if (openSettings) { profileSection = "Rencana"; onSettingsOpened() } }
    var profileHomeTab by remember { mutableStateOf("Profile") }
    var progressInitialTab by remember { mutableStateOf("Rekap") }
    val num = KeyboardOptions(keyboardType = KeyboardType.Number)
    val full = Modifier.fillMaxWidth()

    if (profileHomeTab == "Progress") {
        Column(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            ProfileHomeTabs(profileHomeTab) { tab -> profileHomeTab = tab; if (tab == "Profile") profileSection = "Hari ini" }
            Box(Modifier.weight(1f)) {
                ProgressScreen(state, onDeleteActivity, onOpenActivity, onImportTracks, trackMsg, progressInitialTab)
            }
        }
    } else Column(
        Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(11.dp),
    ) {
        ProfileHomeTabs(profileHomeTab) { tab -> profileHomeTab = tab; if (tab == "Profile") profileSection = "Hari ini" }
        if (profileSection != "Hari ini") {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("PROFIL", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                Text("Profil dan pengaturan", style = MaterialTheme.typography.headlineMedium)
                Text("Pengaturan yang tersedia di aplikasi native", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (profileSection != "Hari ini") {
            EvPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("PENGATURAN", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("Hari ini", "Rencana", "Zona HR", "Kondisi & gear", "Nyeri & cedera", "Layanan", "Cadangan").forEach { section ->
                            FilterChip(selected = profileSection == section, onClick = { profileSection = section }, label = { Text(section) })
                        }
                    }
                }
            }
        }
        when (profileSection) {
            "Hari ini" -> {
                ProfileTodaySection(
                    state = state,
                    onSaveDaily = onSaveDaily,
                    onSaveSettings = onSave,
                    onOpenProgress = { tab -> progressInitialTab = tab; profileHomeTab = "Progress" },
                )
            }
            "Rencana" -> {
            EvGroupTitle("Target latihan", "Jenis sasaran, tanggal, dan target performa")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TYPES.forEach { (k, label) -> FilterChip(selected = rtype == k, onClick = { rtype = k }, label = { Text(label) }) }
            }
            OutlinedTextField(name, { name = it }, label = { Text("Nama lomba") }, singleLine = true, modifier = full)
            OutlinedTextField(start, { start = it }, label = { Text("Mulai (yyyy-MM-dd)") }, singleLine = true, modifier = full)
            if (rtype != "pb" && rtype != "none") {
                OutlinedTextField(race, { race = it }, label = { Text("Tanggal lomba (yyyy-MM-dd)") }, singleLine = true, modifier = full)
                OutlinedTextField(goal, { goal = it }, label = { Text("Target waktu (h:mm:ss, opsional)") }, singleLine = true, modifier = full)
            }
            if (rtype == "ultra" || rtype == "ultrar") {
                OutlinedTextField(raceKm, { raceKm = it }, label = { Text("Jarak lomba (km)") }, keyboardOptions = num, singleLine = true, modifier = full)
                OutlinedTextField(raceGain, { raceGain = it }, label = { Text("Elevasi lomba D+ (m)") }, keyboardOptions = num, singleLine = true, modifier = full)
            }
            EvGroupTitle("Volume latihan", "Atur perkembangan jarak dan distribusi hari lari")
            OutlinedTextField(base, { base = it }, label = { Text("Km mingguan awal") }, keyboardOptions = num, singleLine = true, modifier = full)
            OutlinedTextField(peak, { peak = it }, label = { Text("Km mingguan puncak") }, keyboardOptions = num, singleLine = true, modifier = full)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = days == 5, onClick = { days = 5 }, label = { Text("5 hari lari") })
                FilterChip(selected = days == 6, onClick = { days = 6 }, label = { Text("6 hari lari") })
            }
            OutlinedTextField(longDay, { longDay = it }, label = { Text("Hari long run (0=Sen … 6=Min)") }, keyboardOptions = num, singleLine = true, modifier = full)
            EvGroupTitle("Metode latihan", "Pilih pendekatan periodisasi yang digunakan")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TrainingMethod.KEYS.forEach { k ->
                    FilterChip(selected = method == k, onClick = { method = k }, label = { Text(TrainingMethod.name(k)) })
                }
            }
            Text(TrainingMethod.info(method), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

            EvGroupTitle("Distribusi sesi", "Frekuensi sesi kualitas dalam satu pekan")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = qSess == "1", onClick = { qSess = "1" }, label = { Text("1 sesi") })
                FilterChip(selected = qSess == "2", onClick = { qSess = "2" }, label = { Text("2 sesi") })
            }
            if (qSess == "2") {
                Text(
                    "Sesi kedua hanya muncul di fase Bangun dan Puncak untuk 5K, 10K, Half, Marathon, dan Performance Build dengan 6 hari lari, " +
                        "saat hari easy pendek jatuh dua hari sebelum long run. Dosisnya naik bertahap dan dibatasi sekitar 20% waktu lari mingguan.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            EvGroupTitle("Strength & stabilitas", "Pengaturan latihan pendukung")
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Switch(checked = sLeg, onCheckedChange = { sLeg = it }); Text("Kaki dan panggul (Strength A dan B)")
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Switch(checked = sAnk, onCheckedChange = { sAnk = it }); Text("Ankle dan stabilitas")
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("auto" to "Upper otomatis", "off" to "Upper mati", "1" to "Upper 1×", "2" to "Upper 2×").forEach { (k, label) ->
                    FilterChip(selected = sUp == k, onClick = { sUp = k }, label = { Text(label) })
                }
            }
            err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Button(modifier = full, onClick = {
                fun d(t: String) = runCatching { LocalDate.parse(t) }.getOrNull()
                fun n(t: String) = t.replace(',', '.').toDoubleOrNull()
                val st = d(start)
                val rc = if (race.isBlank()) null else d(race)
                val b = n(base); val p = n(peak); val h = hr.toIntOrNull(); val ld = longDay.toIntOrNull()
                if (st == null || (race.isNotBlank() && rc == null) || b == null || p == null || h == null || ld == null) {
                    err = "Periksa format tanggal dan angka."
                } else {
                    err = null
                    onSave(
                        s.copy(
                            name = name.trim(), rtype = rtype, start = st, race = if (rtype == "pb" || rtype == "none") null else rc,
                            raceKm = n(raceKm), raceGain = n(raceGain), goalT = goal.trim(),
                            base = b, peak = p, days = days, longDay = ld, hr = h, thr = thr.trim(), pace = pace.trim(),
                            method = method, qSess = qSess, sLeg = sLeg, sAnk = sAnk, sUp = sUp,
                        ),
                    )
                }
            }) { Text("Simpan dan hitung ulang rencana") }

            }
            "Zona HR" -> {
            EvGroupTitle("Zona intensitas", "Parameter untuk panduan latihan berbasis detak jantung dan pace")
            OutlinedTextField(hr, { hr = it }, label = { Text("Batas HR easy") }, keyboardOptions = num, singleLine = true, modifier = full)
            OutlinedTextField(thr, { thr = it }, label = { Text("Rentang HR threshold (mis. 164–172)") }, singleLine = true, modifier = full)
            OutlinedTextField(pace, { pace = it }, label = { Text("Pace easy (m:ss)") }, singleLine = true, modifier = full)

            val (restDefault, restKnown) = restHrFrom(state.daily)
            HrZoneSettings(
                settings = s, restDefault = restDefault, restKnown = restKnown,
                onSave = onSave, onSendToWatch = onSyncHrZones,
                watchStatus = watchAdvancedMessage, sending = watchSyncing,
            )

            }
            "Kondisi & gear" -> {
            CompanionDataSection(
                daily = state.daily,
                gear = state.gear,
                activities = state.activities,
                onSaveDaily = onSaveDaily,
                onSaveGear = onSaveGear,
                onDeleteGear = onDeleteGear,
            )

            }
            "Nyeri & cedera" -> {
                PainInjurySettingsSection()
            }
            "Layanan" -> {
            OnlineServicesSection(
                weather = weatherMessage, weatherBusy = weatherBusy, weatherLat = weatherLat, weatherLon = weatherLon,
                onWeather = onFetchWeather, onSearchCity = onSearchWeatherCity, onUseLocation = onUseWeatherLocation, onWeatherToWatch = onWeatherToWatch, weatherWatchStatus = weatherWatchStatus,
                agpsStatus = agpsStatus, onAgps = onAgps, onTestAgps = onTestAgps,
                notifyStatus = notifyStatus, onNotify = onNotify, onTestNotify = onTestNotify,
                aiStatus = aiStatus, aiMessages = aiMessages, onAiKey = onAiKey, onAiSend = onAiSend, aiBusy = aiBusy,
            )

            }
            "Cadangan" -> {
            Text("Cadangan", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 16.dp))
            Text("Pemeliharaan aktivitas", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp))
            Text("Cari aktivitas ganda pada tanggal dan jenis olahraga yang sama. Penggabungan mempertahankan detail jam/rute dan catatan manual bila tersedia.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(modifier = full, onClick = { onScanDuplicates(); showDuplicateConfirm = true }) { Text("Periksa aktivitas ganda") }
            if (duplicateStatus.isNotBlank()) Text(duplicateStatus, color = MaterialTheme.colorScheme.primary)
            Text(
                "Impor berkas cadangan dari versi web (.json) untuk memulihkan pengaturan rencana dan catatan lari.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedButton(
                modifier = full,
                enabled = importUi !is ImportUi.Working,
                onClick = { picker.launch(arrayOf("application/json", "text/plain", "application/octet-stream")) },
            ) { Text(if (importUi is ImportUi.Working) "Membaca berkas…" else "Impor cadangan web") }
            when (importUi) {
                is ImportUi.Done -> Text(importUi.message, color = MaterialTheme.colorScheme.primary)
                is ImportUi.Failed -> Text(importUi.message, color = MaterialTheme.colorScheme.error)
                else -> {}
            }            }
        }

    }

    if (showDuplicateConfirm) AlertDialog(
        onDismissRequest = { showDuplicateConfirm = false },
        title = { Text("Hasil pemeriksaan aktivitas ganda") },
        text = {
            Text(
                (duplicateStatus.ifBlank { "Pemeriksaan sedang berjalan…" }) +
                    "\\n\\nAturan aplikasi lama: tanggal dan jenis olahraga harus sama; waktu mulai berbeda maksimal 1 menit (presisi native), atau tanpa waktu mulai jarak berbeda kurang dari 0,1 km dan durasi kurang dari 2 menit. Aktivitas dengan detail jam/rute diprioritaskan. Pastikan pasangan yang ditampilkan memang sesi yang sama sebelum menggabungkan."
            )
        },
        confirmButton = {
            TextButton(
                enabled = duplicateStatus.startsWith("Ditemukan "),
                onClick = { showDuplicateConfirm = false; onMergeDuplicates() }
            ) { Text("Gabungkan kandidat") }
        },
        dismissButton = { TextButton(onClick = { showDuplicateConfirm = false }) { Text("Tutup") } },
    )

    if (importUi is ImportUi.Confirm) {
        val b = importUi.backup
        AlertDialog(
            onDismissRequest = onDismissImport,
            title = { Text("Pulihkan cadangan?") },
            text = {
                Text(
                    "Ditemukan ${b.activities.size} catatan lari, ${b.doneDays} hari selesai, ${b.daily.size} catatan harian, ${b.gear.size} gear, dan pengaturan rencana" +
                        (if (b.settings.name.isNotBlank()) " \"${b.settings.name}\"" else "") + ".\n\n" +
                        "Pengaturan rencana saat ini akan ditimpa, begitu juga catatan hasil impor sebelumnya. " +
                        "Catatan yang Anda buat di aplikasi ini tidak diubah." +
                        (if (b.detailCount > 0) "\n\n${b.detailCount} detail aktivitas (rute GPS) ikut tersimpan di berkas dan akan dibaca pada tahap berikutnya." else ""),
                )
            },
            confirmButton = { TextButton(onClick = onConfirmImport) { Text("Pulihkan") } },
            dismissButton = { TextButton(onClick = onDismissImport) { Text("Batal") } },
        )
    }
}


@Composable
private fun ProfileHomeTabs(selected: String, onSelect: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 2.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("Profile", "Progress").forEach { tab ->
            val active = selected == tab
            androidx.compose.material3.Surface(
                modifier = Modifier.weight(1f).height(42.dp).clickable { onSelect(tab) },
                shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
                color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                border = if (active) null else androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                shadowElevation = if (active) 2.dp else 0.dp,
            ) { Box(contentAlignment = Alignment.Center) { Text(tab, color = if (active) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.titleSmall) } }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ProfileTodaySection(
    state: UiState,
    onSaveDaily: (DailyEntity) -> Unit,
    onSaveSettings: (PlanSettings) -> Unit,
    onOpenProgress: (String) -> Unit,
) {
    val today = LocalDate.now()
    val context = LocalContext.current
    val readinessHistory = remember(context, state.daily, state.activities) { com.endurancevault.app.data.ReadinessHistoryStore.load(context).takeLast(7) }
    val metrics = remember(state.settings, state.activities, state.daily, state.plan, state.hrHistByActivity) {
        com.endurancevault.app.domain.TrainingMetrics.calculate(
            state.settings, state.activities, state.daily, state.plan, today,
            hrHistByActivity = state.hrHistByActivity,
        )
    }
    val readiness = metrics.readiness
    val todayPlan = (state.plan as? com.endurancevault.app.domain.PlanOutcome.Ok)
        ?.weeks?.asSequence()?.flatMap { it.days.asSequence() }?.firstOrNull { it.date == today }
    val nextStrengthDay = (state.plan as? com.endurancevault.app.domain.PlanOutcome.Ok)
        ?.weeks?.asSequence()?.flatMap { it.days.asSequence() }
        ?.filter { !it.date.isBefore(today) && listOfNotNull(it.str, it.ank, it.up).isNotEmpty() }
        ?.minByOrNull { it.date }
    val strengthDay = todayPlan?.takeIf { listOfNotNull(it.str, it.ank, it.up).isNotEmpty() } ?: nextStrengthDay
    var suggestionExpanded by remember { mutableStateOf(true) }
    var morningExpanded by remember { mutableStateOf(false) }
    var strengthExpanded by remember { mutableStateOf(false) }
    var morningDateText by remember { mutableStateOf(today.toString()) }
    val morningDate = remember(morningDateText) { runCatching { LocalDate.parse(morningDateText) }.getOrNull() }
    val selectedDaily = state.daily.firstOrNull { it.dateIso == (morningDate?.toString() ?: today.toString()) }
    var legFeel by remember(morningDateText, selectedDaily?.leg) {
        mutableStateOf(selectedDaily?.leg?.toString() ?: "")
    }
    var mood by remember(morningDateText, selectedDaily?.mood) {
        mutableStateOf(selectedDaily?.mood?.toString() ?: "")
    }
    var morningError by remember { mutableStateOf<String?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OnTrackCard(state, metrics, onOpenProgress)
        EvGroupTitle("TODAY", today.format(java.time.format.DateTimeFormatter.ofPattern("EEE, d MMM", java.util.Locale.ENGLISH)))
        EvPanel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    when {
                        readiness == null -> "Training readiness belum tersedia"
                        readiness.score >= 80 -> "Today: continue as planned"
                        readiness.score >= 60 -> "Today: keep the effort controlled"
                        else -> "Today: prioritize recovery"
                    },
                    style = MaterialTheme.typography.titleMedium,
                )
                if (readiness != null) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text(readiness.score.toString(), style = MaterialTheme.typography.displaySmall, color = MaterialTheme.colorScheme.tertiary)
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("${readiness.tier.uppercase()} · ${readiness.parts.count { it.score != null }} faktor", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.tertiary)
                            Text(readiness.advice, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    if (readinessHistory.isNotEmpty()) {
                        val avg = readinessHistory.map { it.score }.average().roundToInt()
                        val previous = readinessHistory.dropLast(1).lastOrNull()?.score
                        val delta = previous?.let { readiness.score - it }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            androidx.compose.foundation.Canvas(Modifier.weight(1f).height(28.dp)) {
                                val values = readinessHistory.map { it.score.toFloat() } + readiness.score.toFloat()
                                val lo = (values.minOrNull() ?: 0f) - 5f; val hi = (values.maxOrNull() ?: 100f) + 5f
                                val step = if (values.size > 1) size.width / (values.size - 1) else 0f
                                val points = values.mapIndexed { i, v -> androidx.compose.ui.geometry.Offset(i * step, size.height - ((v - lo) / (hi - lo).coerceAtLeast(1f)) * size.height) }
                                for (i in 1 until points.size) drawLine(Color(0xFF388765), points[i-1], points[i], strokeWidth = 2.dp.toPx())
                                points.forEach { drawCircle(Color(0xFF388765), radius = 3.dp.toPx(), center = it) }
                            }
                            Text("7-day trend · average $avg${delta?.let { " · today ${if (it >= 0) "+" else ""}$it" } ?: ""}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    readiness.parts.filter { it.score != null }.take(7).forEach { part ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(part.label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("${part.score}/100", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                } else {
                    Text("Isi kondisi pagi atau catat aktivitas agar readiness dapat dihitung dari data yang tersedia.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }


        if (strengthDay != null) {
            val blocks = listOfNotNull(strengthDay.str, strengthDay.ank, strengthDay.up)
            val title = when {
                blocks.size > 1 -> "Strength Session"
                else -> blocks.first().title
            }
            EvPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("STRENGTH RECOMMENDATION", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    Text(title, style = MaterialTheme.typography.titleLarge)
                    if (strengthDay.date != today) {
                        Text("Jadwal berikutnya · ${strengthDay.date}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(blocks.joinToString("  ·  ") { "${it.title} · ${it.mins} mnt" }, style = MaterialTheme.typography.bodyMedium)
                    TextButton(onClick = { strengthExpanded = !strengthExpanded }, contentPadding = PaddingValues(0.dp)) {
                        Text(if (strengthExpanded) "Sembunyikan gerakan" else "Lihat set · ${blocks.sumOf { it.lines.size }} gerakan")
                    }
                    if (strengthExpanded) blocks.forEach { block ->
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(block.title, style = MaterialTheme.typography.titleSmall)
                            Text(block.note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            block.lines.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                }
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("SUGGESTIONS", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            EvPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        Modifier.fillMaxWidth().clickable { suggestionExpanded = !suggestionExpanded },
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(if (suggestionExpanded) "▾ Saran latihan" else "▸ Saran latihan", style = MaterialTheme.typography.titleSmall)
                        Text(if (suggestionExpanded) "Tutup" else "Buka", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    }
                    if (suggestionExpanded) {
                        val weekStart = today.with(java.time.DayOfWeek.MONDAY)
                        val weekKm = state.activities.filter { it.type != "bike" && it.km > 0 && it.dateIso >= weekStart.toString() && it.dateIso <= today.toString() }.sumOf { it.km }
                        val weekPlan = (state.plan as? com.endurancevault.app.domain.PlanOutcome.Ok)?.weeks?.firstOrNull { it.start == weekStart }
                        Text("Penyesuaian beban yang mengikuti rencana latihan aktif.", style = MaterialTheme.typography.bodyMedium)
                        Text("Jarak minggu ini: ${fmtKmUi(weekKm)} km${weekPlan?.let { " / ${fmtKmUi(it.km)} km rencana" } ?: ""}.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        val lightActive = state.settings.weekScale < .999 && state.settings.weekScaleWeek == weekStart
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            androidx.compose.material3.OutlinedButton(onClick = { onSaveSettings(state.settings.copy(weekScale = if (lightActive) 1.0 else .7, weekScaleWeek = if (lightActive) null else weekStart)) }) {
                                Text(if (lightActive) "Batalkan minggu ringan" else "Light week (70%)")
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            androidx.compose.material3.OutlinedButton(onClick = {
                                val active = state.settings.sickUntil?.let { !it.isBefore(today) } == true
                                onSaveSettings(state.settings.copy(sickUntil = if (active) null else today.plusDays(2), weekScale = 1.0, weekScaleWeek = null))
                            }) { Text(if (state.settings.sickUntil?.let { !it.isBefore(today) } == true) "Batalkan mode sakit" else "Sick/injured: rest 3 days") }
                        }
                        Text("Mode sakit menjadikan tiga hari ke depan sebagai istirahat dan mengurangi 20% sesi tersisa setelahnya. Minggu ringan mengurangi sesi yang belum selesai menjadi 70%.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.weight(1f)) { Text("Auto-adjust", style = MaterialTheme.typography.titleSmall); Text("Sesi easy berikutnya diringankan setelah lari dadakan atau lari jauh melebihi rencana. Kualitas dan long run tidak diubah.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                            Switch(checked = state.settings.autoAdjust, onCheckedChange = { onSaveSettings(state.settings.copy(autoAdjust = it)) })
                        }
                        if (metrics.planAdjustment != null) Text(metrics.planAdjustment.reason, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }

        EvPanel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    Modifier.fillMaxWidth().clickable { morningExpanded = !morningExpanded },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("MORNING CONDITION", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        Text("Kondisi pagi", style = MaterialTheme.typography.titleLarge)
                    }
                    Text(if (morningExpanded) "⌃" else "⌄", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                val latest = state.daily.firstOrNull { it.dateIso == today.toString() } ?: state.daily.maxByOrNull { it.dateIso }
                if (latest == null) {
                    Text("Data tidur akan muncul setelah sinkronisasi jam.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    val raw = remember(latest.raw) { runCatching { org.json.JSONObject(latest.raw) }.getOrDefault(org.json.JSONObject()) }
                    val watchRaw = raw.optJSONObject("watch") ?: org.json.JSONObject()
                    fun rawValue(key: String): String {
                        val number = raw.optDouble(key, Double.NaN).takeIf { it.isFinite() && it > 0 }
                            ?: when (key) {
                                "ssp" -> watchRaw.optDouble("sleepSpo2", Double.NaN).takeIf { it.isFinite() && it > 0 }
                                "srr" -> watchRaw.optDouble("sleepResp", Double.NaN).takeIf { it.isFinite() && it > 0 }
                                else -> null
                            }
                        return number?.let { if (it == kotlin.math.floor(it)) it.toInt().toString() else "%.1f".format(it) } ?: "–"
                    }
                    val priorDaily = state.daily.filter { it.dateIso < latest.dateIso }.sortedBy { it.dateIso }.takeLast(28)
                    fun averageOf(values: List<Double>): String? = values.filter { it.isFinite() && it > 0 }.takeIf { it.isNotEmpty() }?.average()?.let { "avg ${"%.1f".format(it)}" }
                    val rhrAvg = averageOf(priorDaily.mapNotNull { it.rhr?.toDouble() })
                    val sleepAvg = averageOf(priorDaily.mapNotNull { it.sleepH })
                    val hrvAvg = averageOf(priorDaily.mapNotNull { it.hrv?.toDouble() })
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MorningValue("RESTING HR", latest.rhr?.toString() ?: rawValue("rhr"), "bpm", rhrAvg)
                        MorningValue("SLEEP", latest.sleepH?.let { "%.1f".format(it) } ?: rawValue("sleep"), "h", sleepAvg)
                        MorningValue("HRV", latest.hrv?.toString() ?: rawValue("hrv"), "ms", hrvAvg)
                    }
                    val sleepHr = raw.optDouble("shr", Double.NaN).takeIf { it.isFinite() && it > 0 }
                        ?: watchRaw.optDouble("sleepHr", Double.NaN).takeIf { it.isFinite() && it > 0 }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MorningValue("SLEEP HR", sleepHr?.toInt()?.toString() ?: "–", "bpm")
                        MorningValue("NAP", rawValue("nap"), "min")
                        MorningValue("SLEEP SpO₂", rawValue("ssp"), "%")
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MorningValue("SLEEP RESP.", rawValue("srr"), "br/min")
                        MorningValue("LEG FEEL", latest.leg?.toString() ?: "–", "/5")
                        MorningValue("MOOD", latest.mood?.toString() ?: "–", "/5")
                    }
                }
                if (morningExpanded) {
                OutlinedTextField(
                    value = morningDateText, onValueChange = { morningDateText = it.take(10) },
                    label = { Text("DATE · yyyy-MM-dd") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                Text("LEG FEEL THIS MORNING", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    listOf("Segar", "Baik", "Normal", "Berat", "Sangat berat").forEachIndexed { index, label ->
                        val selected = legFeel == (index + 1).toString()
                        androidx.compose.material3.Surface(
                            modifier = Modifier.height(48.dp).clickable { legFeel = (index + 1).toString() },
                            shape = RoundedCornerShape(16.dp),
                            color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                        ) {
                            Box(Modifier.padding(horizontal = 18.dp), contentAlignment = Alignment.Center) {
                                Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold,
                                    color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
                Text("STRESS / MOOD THIS MORNING", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("😄", "🙂", "😐", "😟", "😣").forEachIndexed { index, emoji ->
                        val selected = mood == (index + 1).toString()
                        androidx.compose.material3.Surface(
                            modifier = Modifier.weight(1f).height(68.dp).clickable { mood = (index + 1).toString() },
                            shape = RoundedCornerShape(16.dp),
                            color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                Text(emoji, fontSize = 28.sp, lineHeight = 32.sp)
                                Text((index + 1).toString(), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
                morningError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                Button(
                    onClick = {
                        val legValue = legFeel.toIntOrNull()
                        val moodValue = mood.toIntOrNull()
                        if (morningDate == null) {
                            morningError = "Tanggal harus berformat yyyy-MM-dd."
                        } else if (legValue == null || legValue !in 1..5 || moodValue == null || moodValue !in 1..5) {
                            morningError = "Isi Leg feel dan Mood dengan angka 1 sampai 5."
                        } else {
                            morningError = null
                            val existing = selectedDaily
                            onSaveDaily(
                                DailyEntity(
                                    dateIso = morningDate.toString(),
                                    rhr = existing?.rhr,
                                    hrv = existing?.hrv,
                                    leg = legValue,
                                    mood = moodValue,
                                    sleepH = existing?.sleepH,
                                    raw = existing?.raw ?: "{}",
                                )
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Simpan kondisi pagi") }
                } else {
                    TextButton(onClick = { morningExpanded = true }, contentPadding = PaddingValues(0.dp)) { Text("Add data") }
                }
            }
        }
    }
}

@Composable
private fun OnTrackCard(state: UiState, metrics: com.endurancevault.app.domain.TrainingMetricsResult, onOpenProgress: (String) -> Unit) {
    val today = LocalDate.now()
    val plan = state.plan as? com.endurancevault.app.domain.PlanOutcome.Ok
    val monday = today.with(java.time.DayOfWeek.MONDAY)
    val week = plan?.weeks?.firstOrNull { it.start == monday }
    val actualKm = state.activities.filter { it.type != "bike" && it.km > 0 && it.dateIso >= monday.toString() && it.dateIso <= today.toString() }.sumOf { it.km }
    val volumePct = week?.km?.takeIf { it > 0 }?.let { actualKm / it * 100.0 }
    val planned = plan?.weeks?.flatMap { it.days }?.filter { it.date <= today && it.kind !in setOf("rest", "race", "event") }.orEmpty()
    val done = planned.count { day -> state.activities.any { it.type != "bike" && it.dateIso == day.date.toString() } }
    val consistency = if (planned.size >= 3) done * 100.0 / planned.size else null
    val currentFitness = metrics.fitness.toDouble()
    val oldFitness = metrics.days.lastOrNull { !it.date.isAfter(today.minusDays(28)) }?.fitness?.toDouble()
    val fitDelta = oldFitness?.let { currentFitness - it }
    val acwr = com.endurancevault.app.domain.ProgressAnalytics.acuteChronic(metrics.days, today)
    val ratio = acwr?.ratio?.takeIf { it.isFinite() && it > 0 }
    data class Signal(val name: String, val value: String, val pct: Float, val level: Int, val tab: String)
    val signals = buildList {
        volumePct?.let { val level = if (it in 85.0..125.0) 0 else if (it >= 70) 1 else 2; add(Signal("Volume", "${it.roundToInt()}% dari rencana", (it/100).coerceIn(0.03,1.0).toFloat(), level, "Rekap")) }
        consistency?.let { val level = if (it >= 85) 0 else if (it >= 70) 1 else 2; add(Signal("Consistency", "$done dari ${planned.size} sesi", (it/100).coerceIn(0.03,1.0).toFloat(), level, "Rekap")) }
        fitDelta?.let { val rel = if (oldFitness != null && oldFitness > 0) it / oldFitness else 0.0; val level = if (rel >= -.03) 0 else if (rel >= -.10) 1 else 2; add(Signal("Fitness", (if (it >= 0) "naik " else "turun ") + "${kotlin.math.abs(it).roundToInt()} poin", (currentFitness/100).coerceIn(0.03,1.0).toFloat(), level, "Fitness")) }
        ratio?.let { val level = if (it < .8 || it <= 1.3) 0 else if (it <= 1.5) 1 else 2; add(Signal("Training load", "ACWR ${"%.2f".format(it)} · ${when { it < .8 -> "Low"; it <= 1.3 -> "Sweet spot"; it <= 1.5 -> "Caution"; else -> "Spike" }}", (it/1.6).coerceIn(0.03,1.0).toFloat(), level, "Load")) }
    }
    val red = signals.count { it.level == 2 }; val amber = signals.count { it.level == 1 }
    val verdict = when { signals.size < 2 -> "Belum cukup data"; red > 0 || amber >= 2 -> "Perlu penyesuaian"; amber == 1 -> "On track, satu hal dijaga"; else -> "On track" }
    val color = when { signals.size < 2 -> MaterialTheme.colorScheme.onSurfaceVariant; red > 0 || amber >= 2 -> MaterialTheme.colorScheme.error; amber == 1 -> MaterialTheme.colorScheme.tertiary; else -> Color(0xFF388765) }
    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("AM I ON TRACK?", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 1.4.sp)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.size(11.dp).clip(CircleShape).background(color))
                Text(verdict, style = MaterialTheme.typography.headlineSmall, color = color)
            }
            Text(
                when { signals.size < 2 -> "Aktifkan rencana dan catat beberapa sesi agar status dapat dinilai."; red > 0 || amber >= 2 -> "Ada beberapa indikator yang perlu diperhatikan. Jangan mengejar sesi yang terlewat sekaligus."; amber == 1 -> "Sebagian besar indikator masih baik. Jaga faktor yang belum ideal."; else -> "Kamu berada di jalur rencana. Volume, konsistensi, fitness, dan beban latihan masih seimbang." },
                style = MaterialTheme.typography.bodyMedium,
            )
            signals.forEach { sig ->
                Column(Modifier.fillMaxWidth().clickable { onOpenProgress(sig.tab) }.padding(vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(9.dp).clip(CircleShape).background(if (sig.level == 0) Color(0xFF388765) else if (sig.level == 1) Color(0xFFE0A33B) else MaterialTheme.colorScheme.error))
                        Text(sig.name, modifier = Modifier.weight(1f).padding(start = 10.dp), style = MaterialTheme.typography.titleSmall)
                        Text(sig.value, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("  ›", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    LinearProgressIndicator(progress = { sig.pct }, modifier = Modifier.fillMaxWidth().padding(start = 20.dp), color = if (sig.level == 0) Color(0xFF388765) else if (sig.level == 1) Color(0xFFE0A33B) else MaterialTheme.colorScheme.error, trackColor = MaterialTheme.colorScheme.surfaceVariant)
                }
                androidx.compose.material3.HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf("Rekap", "Fitness", "Load", "Routes", "Body").forEach { tab ->
                    FilterChip(selected = false, onClick = { onOpenProgress(tab) }, label = { Text(when(tab) { "Rekap" -> "Recap"; "Routes" -> "Routes & conditions"; else -> tab }) })
                }
            }
        }
    }
}

@Composable
private fun RowScope.MorningValue(label: String, value: String, unit: String, average: String? = null) {
    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(value, style = MaterialTheme.typography.titleLarge)
            if (unit.isNotBlank()) Text(unit, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        average?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}


@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PainInjurySettingsSection() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("readiness_settings", android.content.Context.MODE_PRIVATE) }
    fun readEntries(): List<PainReadinessEntry> = runCatching {
        val arr = org.json.JSONArray(prefs.getString("pain_entries", "[]"))
        (0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i)?.let { o ->
            val rawArea = o.optString("area", "")
            val area = mapOf("Betis" to "betis", "Tulang kering" to "tibia", "Ankle" to "ankle", "Achilles" to "achilles", "Tumit" to "tumit", "Plantar" to "plantar", "Punggung kaki" to "pkaki", "Lutut" to "lutut", "IT band" to "itband", "Paha depan" to "pahad", "Paha belakang" to "pahab", "Pangkal paha" to "groin", "Glute" to "glute", "Punggung bawah" to "pbawah", "Bahu" to "bahu").entries.firstOrNull { it.key.equals(rawArea, true) }?.value ?: rawArea.lowercase()
            val rawSide = o.optString("side", "b")
            val side = mapOf("Kiri" to "k", "Kanan" to "r", "Keduanya" to "b").entries.firstOrNull { it.key.equals(rawSide, true) }?.value ?: rawSide
            PainReadinessEntry(LocalDate.parse(o.getString("date")), area, o.optInt("severity", 1), side, o.optString("when", "sl"))
        } }
    }.getOrDefault(emptyList())
    var entries by remember { mutableStateOf(readEntries()) }
    var area by remember { mutableStateOf("") }
    var side by remember { mutableStateOf("k") }
    var severity by remember { mutableStateOf(3) }
    var moment by remember { mutableStateOf("sl") }
    val today = LocalDate.now()
    fun persist(next: List<PainReadinessEntry>) {
        entries = next.takeLast(300)
        val arr = org.json.JSONArray()
        entries.forEach { e -> arr.put(org.json.JSONObject().put("date", e.date.toString()).put("area", e.area).put("severity", e.severity).put("side", e.side).put("when", e.whenTag)) }
        prefs.edit().putString("pain_entries", arr.toString()).apply()
    }
    LaunchedEffect(Unit) { entries = readEntries() }
    EvGroupTitle("Nyeri dan cedera", "Catat lokasi, sisi, tingkat, dan kapan nyeri muncul. Data ini digunakan oleh Training Readiness dan pencegahan cedera.")
    InjuryPrevention.groups.forEach { group ->
        Text(group.title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            group.areas.forEach { (id, label) -> FilterChip(selected = area == id, onClick = { area = if (area == id) "" else id }, label = { Text(label) }) }
        }
    }
    Text("Sisi", style = MaterialTheme.typography.labelMedium)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        InjuryPrevention.sides.forEach { (id, label) -> FilterChip(selected = side == id, onClick = { side = id }, label = { Text(label) }) }
    }
    Text("Tingkat nyeri · 1 ringan sampai 5 berat", style = MaterialTheme.typography.labelMedium)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { (1..5).forEach { v -> FilterChip(selected = severity == v, onClick = { severity = v }, label = { Text("$v") }) } }
    Text("Muncul saat", style = MaterialTheme.typography.labelMedium)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        InjuryPrevention.moments.forEach { (id, label) -> FilterChip(selected = moment == id, onClick = { moment = id }, label = { Text(label) }) }
    }
    Button(onClick = {
        val entry = PainReadinessEntry(today, area, severity, side, moment)
        persist(entries.filterNot { it.date == today && it.area == area && it.side == side } + entry)
        area = ""
    }, enabled = area.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Simpan catatan") }
    val alerts = InjuryPrevention.alerts(entries, today)
    if (alerts.isNotEmpty()) {
        EvGroupTitle("Peringatan berulang", "Area dengan nyeri ≥2 pada 3 dari 4 hari, atau ≥4 dalam dua hari terakhir")
        alerts.forEach { Text("${InjuryPrevention.areaName(it.area)} · ${it.days}/4 hari · puncak ${it.maxSeverity}/5", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
    }
    InjuryPrevention.prehab(entries, today)?.let { advice ->
        EvGroupTitle("Saran prehab · ${InjuryPrevention.areaName(advice.area)}", "Saran umum sesuai area yang paling perlu diperhatikan")
        advice.exercises.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
        Text(advice.caution, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    EvGroupTitle("Riwayat nyeri", "Enam catatan terakhir")
    entries.sortedByDescending { it.date }.take(6).forEach { e ->
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(InjuryPrevention.areaName(e.area), style = MaterialTheme.typography.bodyMedium)
                Text("${e.date} · ${InjuryPrevention.sideName(e.side)} · ${e.severity}/5 · ${InjuryPrevention.momentName(e.whenTag)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = { persist(entries - e) }) { Text("Hapus") }
        }
    }
    Text("Catatan nyeri membantu penyesuaian latihan, bukan diagnosis. Hentikan aktivitas yang memperburuk nyeri dan minta penilaian tenaga kesehatan bila nyeri berat, menetap, atau membatasi fungsi.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}
