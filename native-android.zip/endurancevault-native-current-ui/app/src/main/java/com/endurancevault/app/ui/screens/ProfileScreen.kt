package com.endurancevault.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.domain.TrainingMethod
import com.endurancevault.app.ui.ImportUi
import com.endurancevault.app.ui.UiState
import com.endurancevault.app.data.DailyEntity
import com.endurancevault.app.data.GearEntity
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.TextButton
import java.time.LocalDate

private val TYPES = listOf(
    "5k" to "5K", "10k" to "10K", "hm" to "Half marathon", "fm" to "Marathon",
    "ultra" to "Trail", "ultrar" to "Ultra road", "pb" to "Performance Build", "none" to "No Race",
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileScreen(
    state: UiState,
    onSave: (PlanSettings) -> Unit,
    importUi: ImportUi,
    onImport: (Uri) -> Unit,
    onConfirmImport: () -> Unit,
    onDismissImport: () -> Unit,
    onMergeDuplicates: () -> Unit,
    duplicateStatus: String,
    onSaveDaily: (DailyEntity) -> Unit,
    onSaveGear: (GearEntity) -> Unit,
    onDeleteGear: (String) -> Unit,
    watchMessage: String,
    onConnectWatch: (String) -> Unit,
    onDisconnectWatch: () -> Unit,
    onForgetAndReconnectWatch: (String) -> Unit,
    onSyncWatch: (Boolean) -> Unit,
    watchSyncing: Boolean,
    watchAdvancedMessage: String,
    liveHr: org.json.JSONObject,
    onRefreshLiveHr: () -> Unit,
    onSetLiveHr: (Boolean) -> Unit,
    onSyncHrZones: (PlanSettings) -> Unit,
    onPushWorkout: (String, Int, Int, Int, Int, Int) -> Unit,
    onPushRoute: (Uri) -> Unit,
    weatherMessage: String, weatherBusy: Boolean, weatherLat: String, weatherLon: String,
    onFetchWeather: (Double,Double) -> Unit, onSearchWeatherCity: (String) -> Unit, onUseWeatherLocation: () -> Unit, onWeatherToWatch: (Double,Double,String) -> Unit,
    weatherWatchStatus: String, agpsStatus: String, onAgps: (Boolean,String) -> Unit, onTestAgps: () -> Unit,
    notifyStatus: String, onNotify: (Boolean,Boolean,Int,Int,Boolean,Map<String,Boolean>) -> Unit, onTestNotify: () -> Unit,
    aiStatus: String, aiMessages: List<Pair<String,String>>, onAiKey: (String) -> Unit,
    onAiSend: (String,String,Boolean) -> Unit, aiBusy: Boolean,
) {
    var showDuplicateConfirm by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) onImport(uri) }
    val s = state.settings
    // Zona HR tersimpan otomatis oleh HrZoneSettings; jangan reset isian form lain saat zona berubah.
    val formKey = s.copy(zm = "lthr", lthr = null, rhr = null, zl = com.endurancevault.app.domain.Zones.ZLD, zr = com.endurancevault.app.domain.Zones.ZRD)
    var rtype by remember(formKey) { mutableStateOf(s.rtype) }
    var name by remember(formKey) { mutableStateOf(s.name) }
    var start by remember(formKey) { mutableStateOf(s.start.toString()) }
    var race by remember(formKey) { mutableStateOf(s.race?.toString() ?: "") }
    var raceKm by remember(formKey) { mutableStateOf(s.raceKm?.let { fmtKmUi(it) } ?: "") }
    var raceGain by remember(formKey) { mutableStateOf(s.raceGain?.let { fmtKmUi(it) } ?: "") }
    var goal by remember(formKey) { mutableStateOf(s.goalT) }
    var base by remember(formKey) { mutableStateOf(fmtKmUi(s.base)) }
    var peak by remember(formKey) { mutableStateOf(fmtKmUi(s.peak)) }
    var days by remember(formKey) { mutableStateOf(s.days) }
    var longDay by remember(formKey) { mutableStateOf(s.longDay.toString()) }
    var hr by remember(formKey) { mutableStateOf(s.hr.toString()) }
    var thr by remember(formKey) { mutableStateOf(s.thr) }
    var pace by remember(formKey) { mutableStateOf(s.pace) }
    var method by remember(formKey) { mutableStateOf(s.method) }
    var qSess by remember(formKey) { mutableStateOf(s.qSess) }
    var sLeg by remember(formKey) { mutableStateOf(s.sLeg) }
    var sAnk by remember(formKey) { mutableStateOf(s.sAnk) }
    var sUp by remember(formKey) { mutableStateOf(s.sUp) }
    var err by remember { mutableStateOf<String?>(null) }
    var profileSection by remember { mutableStateOf("Hari ini") }
    val num = KeyboardOptions(keyboardType = KeyboardType.Number)
    val full = Modifier.fillMaxWidth()

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp),
    ) {
        if (profileSection != "Hari ini") {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("PROFIL", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                Text("Profil dan pengaturan", style = MaterialTheme.typography.headlineMedium)
                Text("Pengaturan yang tersedia di aplikasi native", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (profileSection == "Hari ini") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = { profileSection = "Rencana" }) { Text("Pengaturan  ›") }
            }
        } else {
            EvPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("PENGATURAN", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("Hari ini", "Rencana", "Zona HR", "Kondisi & gear", "Layanan", "Cadangan").forEach { section ->
                            FilterChip(selected = profileSection == section, onClick = { profileSection = section }, label = { Text(section) })
                        }
                    }
                }
            }
        }
        when (profileSection) {
            "Hari ini" -> {
                ProfileTodaySection(
                    state = state,
                    onSaveDaily = onSaveDaily,
                )
            }
            "Rencana" -> {
            EvGroupTitle("Target latihan", "Jenis sasaran, tanggal, dan target performa")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TYPES.forEach { (k, label) -> FilterChip(selected = rtype == k, onClick = { rtype = k }, label = { Text(label) }) }
            }
            OutlinedTextField(name, { name = it }, label = { Text("Nama lomba") }, singleLine = true, modifier = full)
            OutlinedTextField(start, { start = it }, label = { Text("Mulai (yyyy-MM-dd)") }, singleLine = true, modifier = full)
            if (rtype != "pb" && rtype != "none") {
                OutlinedTextField(race, { race = it }, label = { Text("Tanggal lomba (yyyy-MM-dd)") }, singleLine = true, modifier = full)
                OutlinedTextField(goal, { goal = it }, label = { Text("Target waktu (h:mm:ss, opsional)") }, singleLine = true, modifier = full)
            }
            if (rtype == "ultra" || rtype == "ultrar") {
                OutlinedTextField(raceKm, { raceKm = it }, label = { Text("Jarak lomba (km)") }, keyboardOptions = num, singleLine = true, modifier = full)
                OutlinedTextField(raceGain, { raceGain = it }, label = { Text("Elevasi lomba D+ (m)") }, keyboardOptions = num, singleLine = true, modifier = full)
            }
            EvGroupTitle("Volume latihan", "Atur perkembangan jarak dan distribusi hari lari")
            OutlinedTextField(base, { base = it }, label = { Text("Km mingguan awal") }, keyboardOptions = num, singleLine = true, modifier = full)
            OutlinedTextField(peak, { peak = it }, label = { Text("Km mingguan puncak") }, keyboardOptions = num, singleLine = true, modifier = full)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = days == 5, onClick = { days = 5 }, label = { Text("5 hari lari") })
                FilterChip(selected = days == 6, onClick = { days = 6 }, label = { Text("6 hari lari") })
            }
            OutlinedTextField(longDay, { longDay = it }, label = { Text("Hari long run (0=Sen … 6=Min)") }, keyboardOptions = num, singleLine = true, modifier = full)
            EvGroupTitle("Metode latihan", "Pilih pendekatan periodisasi yang digunakan")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TrainingMethod.KEYS.forEach { k ->
                    FilterChip(selected = method == k, onClick = { method = k }, label = { Text(TrainingMethod.name(k)) })
                }
            }
            Text(TrainingMethod.info(method), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

            EvGroupTitle("Distribusi sesi", "Frekuensi sesi kualitas dalam satu pekan")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = qSess == "1", onClick = { qSess = "1" }, label = { Text("1 sesi") })
                FilterChip(selected = qSess == "2", onClick = { qSess = "2" }, label = { Text("2 sesi") })
            }
            if (qSess == "2") {
                Text(
                    "Sesi kedua hanya muncul di fase Bangun dan Puncak untuk 5K, 10K, Half, Marathon, dan Performance Build dengan 6 hari lari, " +
                        "saat hari easy pendek jatuh dua hari sebelum long run. Dosisnya naik bertahap dan dibatasi sekitar 20% waktu lari mingguan.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            EvGroupTitle("Strength & stabilitas", "Pengaturan latihan pendukung")
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Switch(checked = sLeg, onCheckedChange = { sLeg = it }); Text("Kaki dan panggul (Strength A dan B)")
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Switch(checked = sAnk, onCheckedChange = { sAnk = it }); Text("Ankle dan stabilitas")
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("auto" to "Upper otomatis", "off" to "Upper mati", "1" to "Upper 1×", "2" to "Upper 2×").forEach { (k, label) ->
                    FilterChip(selected = sUp == k, onClick = { sUp = k }, label = { Text(label) })
                }
            }
            err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Button(modifier = full, onClick = {
                fun d(t: String) = runCatching { LocalDate.parse(t) }.getOrNull()
                fun n(t: String) = t.replace(',', '.').toDoubleOrNull()
                val st = d(start)
                val rc = if (race.isBlank()) null else d(race)
                val b = n(base); val p = n(peak); val h = hr.toIntOrNull(); val ld = longDay.toIntOrNull()
                if (st == null || (race.isNotBlank() && rc == null) || b == null || p == null || h == null || ld == null) {
                    err = "Periksa format tanggal dan angka."
                } else {
                    err = null
                    onSave(
                        s.copy(
                            name = name.trim(), rtype = rtype, start = st, race = if (rtype == "pb" || rtype == "none") null else rc,
                            raceKm = n(raceKm), raceGain = n(raceGain), goalT = goal.trim(),
                            base = b, peak = p, days = days, longDay = ld, hr = h, thr = thr.trim(), pace = pace.trim(),
                            method = method, qSess = qSess, sLeg = sLeg, sAnk = sAnk, sUp = sUp,
                        ),
                    )
                }
            }) { Text("Simpan dan hitung ulang rencana") }

            }
            "Zona HR" -> {
            EvGroupTitle("Zona intensitas", "Parameter untuk panduan latihan berbasis detak jantung dan pace")
            OutlinedTextField(hr, { hr = it }, label = { Text("Batas HR easy") }, keyboardOptions = num, singleLine = true, modifier = full)
            OutlinedTextField(thr, { thr = it }, label = { Text("Rentang HR threshold (mis. 164–172)") }, singleLine = true, modifier = full)
            OutlinedTextField(pace, { pace = it }, label = { Text("Pace easy (m:ss)") }, singleLine = true, modifier = full)

            val (restDefault, restKnown) = restHrFrom(state.daily)
            HrZoneSettings(
                settings = s, restDefault = restDefault, restKnown = restKnown,
                onSave = onSave, onSendToWatch = onSyncHrZones,
                watchStatus = watchAdvancedMessage, sending = watchSyncing,
            )

            }
            "Kondisi & gear" -> {
            CompanionDataSection(
                daily = state.daily,
                gear = state.gear,
                activities = state.activities,
                onSaveDaily = onSaveDaily,
                onSaveGear = onSaveGear,
                onDeleteGear = onDeleteGear,
            )

            }
            "Layanan" -> {
            OnlineServicesSection(
                weather = weatherMessage, weatherBusy = weatherBusy, weatherLat = weatherLat, weatherLon = weatherLon,
                onWeather = onFetchWeather, onSearchCity = onSearchWeatherCity, onUseLocation = onUseWeatherLocation, onWeatherToWatch = onWeatherToWatch, weatherWatchStatus = weatherWatchStatus,
                agpsStatus = agpsStatus, onAgps = onAgps, onTestAgps = onTestAgps,
                notifyStatus = notifyStatus, onNotify = onNotify, onTestNotify = onTestNotify,
                aiStatus = aiStatus, aiMessages = aiMessages, onAiKey = onAiKey, onAiSend = onAiSend, aiBusy = aiBusy,
            )

            }
            "Cadangan" -> {
            Text("Cadangan", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 16.dp))
            Text("Pemeliharaan aktivitas", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp))
            Text("Cari aktivitas ganda pada tanggal dan jenis olahraga yang sama. Penggabungan mempertahankan detail jam/rute dan catatan manual bila tersedia.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(modifier = full, onClick = { showDuplicateConfirm = true }) { Text("Periksa & gabungkan aktivitas ganda") }
            if (duplicateStatus.isNotBlank()) Text(duplicateStatus, color = MaterialTheme.colorScheme.primary)
            Text(
                "Impor berkas cadangan dari versi web (.json) untuk memulihkan pengaturan rencana dan catatan lari.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedButton(
                modifier = full,
                enabled = importUi !is ImportUi.Working,
                onClick = { picker.launch(arrayOf("application/json", "text/plain", "application/octet-stream")) },
            ) { Text(if (importUi is ImportUi.Working) "Membaca berkas…" else "Impor cadangan web") }
            when (importUi) {
                is ImportUi.Done -> Text(importUi.message, color = MaterialTheme.colorScheme.primary)
                is ImportUi.Failed -> Text(importUi.message, color = MaterialTheme.colorScheme.error)
                else -> {}
            }            }
        }

    }

    if (importUi is ImportUi.Confirm) {
        if (showDuplicateConfirm) AlertDialog(
            onDismissRequest = { showDuplicateConfirm = false },
            title = { Text("Gabungkan aktivitas ganda?") },
            text = { Text("Aktivitas pada tanggal dan jenis olahraga yang sama akan digabung jika waktu mulai sama, atau jika waktu tidak tersedia jarak berbeda kurang dari 0,1 km dan durasi kurang dari 2 menit. Catatan dan detail jam akan dipertahankan bila tersedia. Tindakan ini menghapus baris duplikat dan belum memiliki tombol urungkan.") },
            confirmButton = { TextButton(onClick = { showDuplicateConfirm = false; onMergeDuplicates() }) { Text("Gabungkan") } },
            dismissButton = { TextButton(onClick = { showDuplicateConfirm = false }) { Text("Batal") } },
        )
        val b = importUi.backup
        AlertDialog(
            onDismissRequest = onDismissImport,
            title = { Text("Pulihkan cadangan?") },
            text = {
                Text(
                    "Ditemukan ${b.activities.size} catatan lari, ${b.doneDays} hari selesai, ${b.daily.size} catatan harian, ${b.gear.size} gear, dan pengaturan rencana" +
                        (if (b.settings.name.isNotBlank()) " \"${b.settings.name}\"" else "") + ".\n\n" +
                        "Pengaturan rencana saat ini akan ditimpa, begitu juga catatan hasil impor sebelumnya. " +
                        "Catatan yang Anda buat di aplikasi ini tidak diubah." +
                        (if (b.detailCount > 0) "\n\n${b.detailCount} detail aktivitas (rute GPS) ikut tersimpan di berkas dan akan dibaca pada tahap berikutnya." else ""),
                )
            },
            confirmButton = { TextButton(onClick = onConfirmImport) { Text("Pulihkan") } },
            dismissButton = { TextButton(onClick = onDismissImport) { Text("Batal") } },
        )
    }
}


@Composable
private fun ProfileTodaySection(
    state: UiState,
    onSaveDaily: (DailyEntity) -> Unit,
) {
    val today = LocalDate.now()
    val metrics = remember(state.settings, state.activities, state.daily, state.plan, state.hrHistByActivity) {
        com.endurancevault.app.domain.TrainingMetrics.calculate(
            state.settings, state.activities, state.daily, state.plan, today,
            hrHistByActivity = state.hrHistByActivity,
        )
    }
    val readiness = metrics.readiness
    val todayPlan = (state.plan as? com.endurancevault.app.domain.PlanOutcome.Ok)
        ?.weeks?.asSequence()?.flatMap { it.days.asSequence() }?.firstOrNull { it.date == today }
    val nextStrengthDay = (state.plan as? com.endurancevault.app.domain.PlanOutcome.Ok)
        ?.weeks?.asSequence()?.flatMap { it.days.asSequence() }
        ?.filter { !it.date.isBefore(today) && listOfNotNull(it.str, it.ank, it.up).isNotEmpty() }
        ?.minByOrNull { it.date }
    val strengthDay = todayPlan?.takeIf { listOfNotNull(it.str, it.ank, it.up).isNotEmpty() } ?: nextStrengthDay
    var suggestionExpanded by remember { mutableStateOf(false) }
    var morningExpanded by remember { mutableStateOf(false) }
    var strengthExpanded by remember { mutableStateOf(false) }
    var legFeel by remember(state.daily.firstOrNull { it.dateIso == today.toString() }?.leg) {
        mutableStateOf(state.daily.firstOrNull { it.dateIso == today.toString() }?.leg?.toString() ?: "")
    }
    var mood by remember(state.daily.firstOrNull { it.dateIso == today.toString() }?.mood) {
        mutableStateOf(state.daily.firstOrNull { it.dateIso == today.toString() }?.mood?.toString() ?: "")
    }
    var morningError by remember { mutableStateOf<String?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        EvGroupTitle("TODAY", today.format(java.time.format.DateTimeFormatter.ofPattern("EEE, d MMM", java.util.Locale.ENGLISH)))
        if (strengthDay != null) {
            val blocks = listOfNotNull(strengthDay.str, strengthDay.ank, strengthDay.up)
            val title = when {
                blocks.size > 1 -> "Strength Session"
                else -> blocks.first().title
            }
            EvPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("STRENGTH RECOMMENDATION", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    Text(title, style = MaterialTheme.typography.titleLarge)
                    if (strengthDay.date != today) {
                        Text("Jadwal berikutnya · ${strengthDay.date}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(blocks.joinToString("  ·  ") { "${it.title} · ${it.mins} mnt" }, style = MaterialTheme.typography.bodyMedium)
                    TextButton(onClick = { strengthExpanded = !strengthExpanded }, contentPadding = PaddingValues(0.dp)) {
                        Text(if (strengthExpanded) "Sembunyikan gerakan" else "Lihat set · ${blocks.sumOf { it.lines.size }} gerakan")
                    }
                    if (strengthExpanded) blocks.forEach { block ->
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(block.title, style = MaterialTheme.typography.titleSmall)
                            Text(block.note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            block.lines.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                }
            }
        } else {
            EvPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text("Strength Session", style = MaterialTheme.typography.titleLarge)
                    Text("Belum ada rekomendasi strength pada rencana yang tersedia.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        EvPanel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    when {
                        readiness == null -> "Training readiness belum tersedia"
                        readiness.score >= 80 -> "Today: continue as planned"
                        readiness.score >= 60 -> "Today: keep the effort controlled"
                        else -> "Today: prioritize recovery"
                    },
                    style = MaterialTheme.typography.titleMedium,
                )
                if (readiness != null) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text(readiness.score.toString(), style = MaterialTheme.typography.displaySmall, color = MaterialTheme.colorScheme.tertiary)
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("${readiness.tier.uppercase()} · ${readiness.parts.count { it.score != null }} faktor", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.tertiary)
                            Text(readiness.advice, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    readiness.parts.filter { it.score != null }.take(7).forEach { part ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(part.label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("${part.score}/100", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                } else {
                    Text("Isi kondisi pagi atau catat aktivitas agar readiness dapat dihitung dari data yang tersedia.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("SUGGESTIONS", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            EvPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        Modifier.fillMaxWidth().clickable { suggestionExpanded = !suggestionExpanded },
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(if (suggestionExpanded) "▾ Saran latihan" else "▸ Saran latihan", style = MaterialTheme.typography.titleSmall)
                        Text(if (suggestionExpanded) "Tutup" else "Buka", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    }
                    if (suggestionExpanded) {
                        val weekStart = today.with(java.time.DayOfWeek.MONDAY)
                        val prevStart = weekStart.minusDays(7)
                        val thisKm = state.activities.filter { it.type != "bike" && it.km > 0 && it.dateIso >= weekStart.toString() && it.dateIso <= today.toString() }.sumOf { it.km }
                        val prevKm = state.activities.filter { it.type != "bike" && it.km > 0 && it.dateIso >= prevStart.toString() && it.dateIso < weekStart.toString() }.sumOf { it.km }
                        val currentLoad = metrics.days.filter { !it.date.isBefore(today.minusDays(6)) && !it.date.isAfter(today) }.sumOf { it.load }
                        val previousLoad = metrics.days.filter { !it.date.isBefore(today.minusDays(13)) && it.date.isBefore(today.minusDays(6)) }.sumOf { it.load }
                        val suggestions = buildList {
                            val adjustment = metrics.planAdjustment
                            if (adjustment != null) add(adjustment.reason + " Rencana ${adjustment.plannedTitle}: ${"%.1f".format(adjustment.plannedKm)} km; saran ${"%.1f".format(adjustment.suggestedKm)} km.")
                            if (prevKm >= 15 && thisKm > prevKm * 1.15) add("Jarak minggu ini naik ${((thisKm / prevKm - 1) * 100).toInt()}% dibanding minggu lalu. Tahan penambahan volume.")
                            if (metrics.days.size >= 21 && previousLoad >= 150 && currentLoad > previousLoad * 1.10) add("Training load 7 hari meningkat ${((currentLoad / previousLoad - 1) * 100).toInt()}% dibanding 7 hari sebelumnya. Pertimbangkan sesi berikutnya lebih ringan.")
                            if (metrics.fitness > 20 && metrics.ratio > 1.4) add("Fatigue jauh di atas fitness (ATL:CTL ${"%.2f".format(metrics.ratio)}). Pertimbangkan hari ringan atau pemulihan tambahan.")
                        }
                        if (suggestions.isEmpty()) {
                            Text(
                                "Belum ada saran penyesuaian khusus dari data yang tersedia. Ikuti rencana latihan dan pantau kondisi tubuh.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        } else suggestions.forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium) }
                    }
                }
            }
        }

        EvPanel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    Modifier.fillMaxWidth().clickable { morningExpanded = !morningExpanded },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("MORNING CONDITION", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        Text("Kondisi pagi", style = MaterialTheme.typography.titleLarge)
                    }
                    Text(if (morningExpanded) "⌃" else "⌄", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                val latest = state.daily.firstOrNull { it.dateIso == today.toString() } ?: state.daily.maxByOrNull { it.dateIso }
                if (latest == null) {
                    Text("Data tidur akan muncul setelah sinkronisasi jam.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    val raw = remember(latest.raw) { runCatching { org.json.JSONObject(latest.raw) }.getOrDefault(org.json.JSONObject()) }
                    val watchRaw = raw.optJSONObject("watch") ?: org.json.JSONObject()
                    fun rawValue(key: String): String {
                        val number = raw.optDouble(key, Double.NaN).takeIf { it.isFinite() && it > 0 }
                            ?: when (key) {
                                "ssp" -> watchRaw.optDouble("sleepSpo2", Double.NaN).takeIf { it.isFinite() && it > 0 }
                                "srr" -> watchRaw.optDouble("sleepResp", Double.NaN).takeIf { it.isFinite() && it > 0 }
                                else -> null
                            }
                        return number?.let { if (it == kotlin.math.floor(it)) it.toInt().toString() else "%.1f".format(it) } ?: "–"
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MorningValue("RESTING HR", latest.rhr?.toString() ?: rawValue("rhr"), "bpm")
                        MorningValue("SLEEP", latest.sleepH?.let { "%.1f".format(it) } ?: rawValue("sleep"), "h")
                        MorningValue("HRV", latest.hrv?.toString() ?: rawValue("hrv"), "ms")
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MorningValue("NAP", rawValue("nap"), "min")
                        MorningValue("SLEEP SpO₂", rawValue("ssp"), "%")
                        MorningValue("SLEEP RESP.", rawValue("srr"), "br/min")
                    }
                }
                Text("DATA MANUAL", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                Text("Leg feel: 1 segar – 5 sangat berat. Mood/stres: 1 santai – 5 sangat stres. Data tidur dan biometrik lainnya berasal dari jam.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = legFeel, onValueChange = { legFeel = it.filter(Char::isDigit).take(1) },
                        label = { Text("Leg feel (1–5)") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                    )
                    OutlinedTextField(
                        value = mood, onValueChange = { mood = it.filter(Char::isDigit).take(1) },
                        label = { Text("Mood (1–5)") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                    )
                }
                morningError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                Button(
                    onClick = {
                        val legValue = legFeel.toIntOrNull()
                        val moodValue = mood.toIntOrNull()
                        if (legValue == null || legValue !in 1..5 || moodValue == null || moodValue !in 1..5) {
                            morningError = "Isi Leg feel dan Mood dengan angka 1 sampai 5."
                        } else {
                            morningError = null
                            val existing = state.daily.firstOrNull { it.dateIso == today.toString() }
                            onSaveDaily(
                                DailyEntity(
                                    dateIso = today.toString(),
                                    rhr = existing?.rhr,
                                    hrv = existing?.hrv,
                                    leg = legValue,
                                    mood = moodValue,
                                    sleepH = existing?.sleepH,
                                    raw = existing?.raw ?: "{}",
                                )
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Simpan Leg feel & Mood") }
                if (morningExpanded) {
                    Text("Data tidur berasal dari sinkronisasi jam. Leg feel dan Mood diisi manual di atas.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    TextButton(onClick = { morningExpanded = true }, contentPadding = PaddingValues(0.dp)) { Text("Add data") }
                }
            }
        }
    }
}

@Composable
private fun RowScope.MorningValue(label: String, value: String, unit: String) {
    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(value, style = MaterialTheme.typography.titleLarge)
            if (unit.isNotBlank()) Text(unit, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
