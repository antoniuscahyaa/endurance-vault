package com.endurancevault.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.max

/**
 * Normalizes direct Huawei-watch protocol records into EnduranceVault daily rows.
 * Manual values are never overwritten: watch values fill only empty fields.
 */
object HuaweiWatchImport {
    private const val NAP_TYPE = 0x5659

    fun daily(payload: JSONObject, existing: List<DailyEntity>, zone: ZoneId = ZoneId.systemDefault()): List<DailyEntity> {
        val oldByDate = existing.associateBy { it.dateIso }
        val days = linkedMapOf<String, DayData>()

        val dayRows = payload.optJSONArray("days") ?: JSONArray()
        for (i in 0 until dayRows.length()) {
            val row = dayRows.optJSONObject(i) ?: continue
            val date = row.optString("day")
            if (date.length != 10) continue
            val d = days.getOrPut(date) { DayData() }
            // Legacy importer uses the day's average resting-HR samples, not the last isolated sample.
            val rhr = row.optDoubleOrNull("rhrAvg")?.toInt() ?: row.optIntOrNull("rhrLast")
            if (rhr != null && rhr in 25..220) d.rhr = rhr
        }

        val sleepRows = payload.optJSONArray("sleep") ?: JSONArray()
        val segments = mutableListOf<SleepSegment>()
        for (i in 0 until sleepRows.length()) {
            val row = sleepRows.optJSONObject(i) ?: continue
            val start = row.optLong("start", 0L); val end = row.optLong("end", 0L)
            if (start > 0 && end > start) segments += SleepSegment(start, end, row.optInt("type", 0), row.optString("stage").lowercase())
        }
        // Exact parity rule: one longest >=3h main sleep per wake date, not the sum of every group.
        HuaweiSleepParity.parse(sleepRows, zone).forEach { night ->
            val d = days.getOrPut(night.date) { DayData() }
            d.deep = night.deep; d.rem = night.rem; d.light = night.light
            d.awake = night.awake; d.unknown = night.unknown
            d.wakes = night.awakeCount; d.wakeDurations.clear()
            if (night.awakeMinutes > 0) d.wakeDurations += night.awakeMinutes
            d.bed = night.start; d.wake = night.end
        }
        // Explicit nap records are kept separate from the main night.
        segments.filter { it.type == NAP_TYPE }.forEach { seg ->
            val date = Instant.ofEpochSecond(seg.start).atZone(zone).toLocalDate().toString()
            days.getOrPut(date) { DayData() }.nap += ((seg.end - seg.start) / 60L).toInt().coerceAtLeast(0)
        }

        val scores = payload.optJSONArray("sleepScores") ?: JSONArray()
        for (i in 0 until scores.length()) {
            val row = scores.optJSONObject(i) ?: continue
            val end = row.optLong("end", 0L)
            if (end <= 0) continue
            val date = Instant.ofEpochSecond(end).atZone(zone).toLocalDate().toString()
            val d = days.getOrPut(date) { DayData() }
            row.optIntOrNull("score")?.let { d.sleepScore = it }
            row.optIntOrNull("efficiency")?.let { d.efficiency = it }
            row.optIntOrNull("avgSpo2")?.let { d.spo2 = it }
            row.optDoubleOrNull("avgResp")?.let { d.resp = it }
        }

        // Average heart rate measured during the actual main-sleep window, computed by ProtocolBridge
        // from watch HR samples (same source as the legacy readWatchHr(start,end) path).
        val sleepHrRows = payload.optJSONArray("sleepHr") ?: JSONArray()
        for (i in 0 until sleepHrRows.length()) {
            val row = sleepHrRows.optJSONObject(i) ?: continue
            val date = row.optString("day")
            val value = row.optDoubleOrNull("avg")
            val count = row.optInt("n", 0)
            if (date.length == 10 && value != null && value in 25.0..220.0 && count >= 10) {
                val d = days.getOrPut(date) { DayData() }
                d.sleepHr = value
            }
        }

        val hrvRows = payload.optJSONArray("hrv") ?: JSONArray()
        for (i in 0 until hrvRows.length()) {
            val row = hrvRows.optJSONObject(i) ?: continue
            val end = row.optLong("end", 0L)
            val value = row.optDouble("rmssd", 0.0)
            if (end <= 0 || value <= 0.0 || value > 300.0) continue
            val date = Instant.ofEpochSecond(end).atZone(zone).toLocalDate().toString()
            val d = days.getOrPut(date) { DayData() }
            d.hrv = value.toInt()
        }

        return days.toSortedMap().map { (date, watch) ->
            val old = oldByDate[date]
            val raw = runCatching { org.json.JSONObject(old?.raw ?: "{}") }.getOrElse { JSONObject() }
            val watchRaw = JSONObject().apply {
                put("source", "huawei-watch")
                put("syncedAt", System.currentTimeMillis())
                watch.rhr?.let { put("rhr", it); put("huaweiHr_rhr", "watch-sync") }
                watch.hrv?.let { put("hrv", it); put("huaweiHr_hrv", "watch-sync") }
                watch.sleepHr?.let { put("sleepHr", it); put("huaweiHr_shr", "watch-sync") }
                put("deep", watch.deep)
                put("rem", watch.rem)
                put("light", watch.light)
                put("awake", watch.awake)
                put("nap", watch.nap)
                put("sleepScore", watch.sleepScore ?: JSONObject.NULL)
                put("sleepEfficiency", watch.efficiency ?: JSONObject.NULL)
                put("sleepSpo2", watch.spo2 ?: JSONObject.NULL)
                put("sleepResp", watch.resp ?: JSONObject.NULL)
                watch.bed?.let { put("bed", Instant.ofEpochSecond(it).atZone(zone).toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm"))) }
                watch.wake?.let { put("wkAt", Instant.ofEpochSecond(it).atZone(zone).toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm"))) }
                put("wkN", watch.wakeDurations.size)
                if (watch.wakeDurations.isNotEmpty()) {
                    val wakeRows = JSONArray()
                    watch.wakeDurations.forEach { wakeRows.put(JSONObject().put("m", it).put("g", false)) }
                    put("wks", wakeRows)
                }
            }
            raw.put("watch", watchRaw)
            val sleepWatchOwned = raw.optString("huaweiSleepSource") == "watch-sync" || raw.optString("source") == "huawei-watch"
            watch.rhr?.let { raw.put("huaweiHr_rhr", "watch-sync") }
            watch.hrv?.let { raw.put("huaweiHr_hrv", "watch-sync") }
            watch.sleepHr?.let {
                if (!raw.has("shr") || raw.optString("huaweiHr_shr") == "watch-sync") {
                    raw.put("shr", it).put("huaweiHr_shr", "watch-sync")
                }
            }
            // Root keys are consumed by the readiness engine. Populate them only when there is no manual sleep entry.
            val sleepMinutes = watch.deep + watch.rem + watch.light + watch.unknown
            if (sleepMinutes > 0 && (old?.sleepH == null && !raw.has("sleep") || sleepWatchOwned)) {
                raw.put("source", "huawei-watch").put("huaweiSleepSource", "watch-sync")
                raw.put("sleep", sleepMinutes / 60.0)
            }
            // Refresh fields previously owned by watch sync; preserve manually entered values.
            if (!raw.has("deep") || sleepWatchOwned) raw.put("deep", watch.deep)
            if (!raw.has("rem") || sleepWatchOwned) raw.put("rem", watch.rem)
            if (!raw.has("light") || sleepWatchOwned) raw.put("light", watch.light)
            if (!raw.has("nap") || sleepWatchOwned) raw.put("nap", watch.nap)
            watch.spo2?.let { if (!raw.has("ssp")) raw.put("ssp", it) }
            watch.resp?.let { if (!raw.has("srr")) raw.put("srr", it) }
            if (!raw.has("wkN") || sleepWatchOwned) raw.put("wkN", watch.wakeDurations.size)
            if ((!raw.has("wks") || sleepWatchOwned) && watch.wakeDurations.isNotEmpty()) {
                val wakeRows = JSONArray()
                watch.wakeDurations.forEach { wakeRows.put(JSONObject().put("m", it).put("g", false)) }
                raw.put("wks", wakeRows)
            }
            if (!raw.has("bed") || sleepWatchOwned) watch.bed?.let {
                raw.put("bed", Instant.ofEpochSecond(it).atZone(zone).toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm")))
            }
            if (!raw.has("wkAt") || sleepWatchOwned) watch.wake?.let {
                raw.put("wkAt", Instant.ofEpochSecond(it).atZone(zone).toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm")))
            }
            DailyEntity(
                dateIso = date,
                rhr = if (old != null && runCatching { JSONObject(old.raw).optString("huaweiHr_rhr") == "watch-sync" }.getOrDefault(false)) watch.rhr ?: old.rhr else old?.rhr ?: watch.rhr,
                hrv = if (old != null && runCatching { JSONObject(old.raw).optString("huaweiHr_hrv") == "watch-sync" }.getOrDefault(false)) watch.hrv ?: old.hrv else old?.hrv ?: watch.hrv,
                leg = old?.leg,
                mood = old?.mood,
                sleepH = if (sleepWatchOwned) (sleepMinutes.takeIf { it > 0 }?.div(60.0) ?: old?.sleepH) else old?.sleepH ?: (sleepMinutes.takeIf { it > 0 }?.div(60.0)),
                raw = raw.toString(),
            )
        }
    }

    private data class SleepSegment(val start: Long, val end: Long, val type: Int, val stage: String)

    private class DayData {
        var rhr: Int? = null
        var hrv: Int? = null
        var sleepHr: Double? = null
        var deep = 0
        var rem = 0
        var light = 0
        var awake = 0
        var unknown = 0
        var nap = 0
        var wakes = 0
        val wakeDurations = mutableListOf<Int>()
        var sleepScore: Int? = null
        var efficiency: Int? = null
        var spo2: Int? = null
        var resp: Double? = null
        var bed: Long? = null
        var wake: Long? = null
    }

    private fun JSONObject.optIntOrNull(key: String): Int? =
        if (!has(key) || isNull(key)) null else runCatching { getInt(key) }.getOrNull()

    private fun JSONObject.optDoubleOrNull(key: String): Double? =
        if (!has(key) || isNull(key)) null else runCatching { getDouble(key) }.getOrNull()
}
