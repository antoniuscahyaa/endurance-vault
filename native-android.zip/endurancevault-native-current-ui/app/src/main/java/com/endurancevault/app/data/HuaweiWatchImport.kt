package com.endurancevault.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.max

/**
 * Normalizes direct Huawei-watch protocol records into EnduranceVault daily rows.
 * Manual values are never overwritten: watch values fill only empty fields.
 */
object HuaweiWatchImport {
    private const val NAP_TYPE = 0x5659

    fun daily(payload: JSONObject, existing: List<DailyEntity>, zone: ZoneId = ZoneId.systemDefault()): List<DailyEntity> {
        val oldByDate = existing.associateBy { it.dateIso }
        val days = linkedMapOf<String, DayData>()

        val dayRows = payload.optJSONArray("days") ?: JSONArray()
        for (i in 0 until dayRows.length()) {
            val row = dayRows.optJSONObject(i) ?: continue
            val date = row.optString("day")
            if (date.length != 10) continue
            val d = days.getOrPut(date) { DayData() }
            // Legacy importer uses the day's average resting-HR samples, not the last isolated sample.
            val rhr = row.optDoubleOrNull("rhrAvg")?.toInt() ?: row.optIntOrNull("rhrLast")
            if (rhr != null && rhr in 25..220) d.rhr = rhr
        }

        val sleepRows = payload.optJSONArray("sleep") ?: JSONArray()
        val segments = mutableListOf<SleepSegment>()
        for (i in 0 until sleepRows.length()) {
            val row = sleepRows.optJSONObject(i) ?: continue
            val start = row.optLong("start", 0L)
            val end = row.optLong("end", 0L)
            if (start <= 0 || end <= start) continue
            segments += SleepSegment(start, end, row.optInt("type", 0), row.optString("stage", "").lowercase())
        }
        // The watch may split one night into many adjacent stage rows, including across midnight.
        // Join gaps up to one hour and assign the complete night to its wake-up date.
        val main = segments.filter { it.type != NAP_TYPE }.sortedBy { it.start }
        var group = mutableListOf<SleepSegment>()
        fun flushNight() {
            if (group.isEmpty()) return
            val date = Instant.ofEpochSecond(group.maxOf { it.end }).atZone(zone).toLocalDate().toString()
            val d = days.getOrPut(date) { DayData() }
            group.forEach { seg ->
                val minutes = ((seg.end - seg.start) / 60L).toInt().coerceAtLeast(0)
                when (seg.stage) {
                    "deep" -> d.deep += minutes
                    "rem" -> d.rem += minutes
                    "light" -> d.light += minutes
                    "awake" -> {
                        d.awake += minutes
                        if (minutes >= 3) {
                            d.wakes += minutes
                            d.wakeDurations += minutes
                        }
                    }
                    else -> d.unknown += minutes
                }
            }
            d.bed = group.minOf { it.start }
            d.wake = group.maxOf { it.end }
            group = mutableListOf()
        }
        main.forEach { seg ->
            if (group.isNotEmpty() && seg.start - group.maxOf { it.end } > 3600L) flushNight()
            group += seg
        }
        flushNight()
        segments.filter { it.type == NAP_TYPE }.forEach { seg ->
            val date = Instant.ofEpochSecond(seg.start).atZone(zone).toLocalDate().toString()
            days.getOrPut(date) { DayData() }.nap += ((seg.end - seg.start) / 60L).toInt().coerceAtLeast(0)
        }

        val scores = payload.optJSONArray("sleepScores") ?: JSONArray()
        for (i in 0 until scores.length()) {
            val row = scores.optJSONObject(i) ?: continue
            val end = row.optLong("end", 0L)
            if (end <= 0) continue
            val date = Instant.ofEpochSecond(end).atZone(zone).toLocalDate().toString()
            val d = days.getOrPut(date) { DayData() }
            row.optIntOrNull("score")?.let { d.sleepScore = it }
            row.optIntOrNull("efficiency")?.let { d.efficiency = it }
            row.optIntOrNull("avgSpo2")?.let { d.spo2 = it }
            row.optDoubleOrNull("avgResp")?.let { d.resp = it }
        }

        // Average heart rate measured during the actual main-sleep window, computed by ProtocolBridge
        // from watch HR samples (same source as the legacy readWatchHr(start,end) path).
        val sleepHrRows = payload.optJSONArray("sleepHr") ?: JSONArray()
        for (i in 0 until sleepHrRows.length()) {
            val row = sleepHrRows.optJSONObject(i) ?: continue
            val date = row.optString("day")
            val value = row.optDoubleOrNull("avg")
            val count = row.optInt("n", 0)
            if (date.length == 10 && value != null && value in 25.0..220.0 && count >= 10) {
                val d = days.getOrPut(date) { DayData() }
                d.sleepHr = value
            }
        }

        val hrvRows = payload.optJSONArray("hrv") ?: JSONArray()
        for (i in 0 until hrvRows.length()) {
            val row = hrvRows.optJSONObject(i) ?: continue
            val end = row.optLong("end", 0L)
            val value = row.optDouble("rmssd", 0.0)
            if (end <= 0 || value <= 0.0 || value > 300.0) continue
            val date = Instant.ofEpochSecond(end).atZone(zone).toLocalDate().toString()
            val d = days.getOrPut(date) { DayData() }
            d.hrv = value.toInt()
        }

        return days.toSortedMap().map { (date, watch) ->
            val old = oldByDate[date]
            val raw = runCatching { org.json.JSONObject(old?.raw ?: "{}") }.getOrElse { JSONObject() }
            val watchRaw = JSONObject().apply {
                put("source", "huawei-watch")
                put("syncedAt", System.currentTimeMillis())
                watch.rhr?.let { put("rhr", it); put("huaweiHr_rhr", "watch-sync") }
                watch.hrv?.let { put("hrv", it); put("huaweiHr_hrv", "watch-sync") }
                watch.sleepHr?.let { put("sleepHr", it); put("huaweiHr_shr", "watch-sync") }
                put("deep", watch.deep)
                put("rem", watch.rem)
                put("light", watch.light)
                put("awake", watch.awake)
                put("nap", watch.nap)
                put("sleepScore", watch.sleepScore ?: JSONObject.NULL)
                put("sleepEfficiency", watch.efficiency ?: JSONObject.NULL)
                put("sleepSpo2", watch.spo2 ?: JSONObject.NULL)
                put("sleepResp", watch.resp ?: JSONObject.NULL)
                watch.bed?.let { put("bed", Instant.ofEpochSecond(it).atZone(zone).toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm"))) }
                watch.wake?.let { put("wkAt", Instant.ofEpochSecond(it).atZone(zone).toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm"))) }
                put("wkN", watch.wakeDurations.size)
                if (watch.wakeDurations.isNotEmpty()) {
                    val wakeRows = JSONArray()
                    watch.wakeDurations.forEach { wakeRows.put(JSONObject().put("m", it).put("g", false)) }
                    put("wks", wakeRows)
                }
            }
            raw.put("watch", watchRaw)
            watch.rhr?.let { raw.put("huaweiHr_rhr", "watch-sync") }
            watch.hrv?.let { raw.put("huaweiHr_hrv", "watch-sync") }
            watch.sleepHr?.let {
                if (!raw.has("shr") || raw.optString("huaweiHr_shr") == "watch-sync") {
                    raw.put("shr", it).put("huaweiHr_shr", "watch-sync")
                }
            }
            // Root keys are consumed by the readiness engine. Populate them only when there is no manual sleep entry.
            val sleepMinutes = watch.deep + watch.rem + watch.light + watch.unknown
            if (old?.sleepH == null && !raw.has("sleep") && sleepMinutes > 0) {
                raw.put("source", "huawei-watch")
                raw.put("sleep", sleepMinutes / 60.0)
            }
            // Add watch-only recovery context without replacing any existing manual field.
            if (!raw.has("deep")) raw.put("deep", watch.deep)
            if (!raw.has("rem")) raw.put("rem", watch.rem)
            if (!raw.has("light")) raw.put("light", watch.light)
            if (!raw.has("nap")) raw.put("nap", watch.nap)
            watch.spo2?.let { if (!raw.has("ssp")) raw.put("ssp", it) }
            watch.resp?.let { if (!raw.has("srr")) raw.put("srr", it) }
            if (!raw.has("wkN")) raw.put("wkN", watch.wakeDurations.size)
            if (!raw.has("wks") && watch.wakeDurations.isNotEmpty()) {
                val wakeRows = JSONArray()
                watch.wakeDurations.forEach { wakeRows.put(JSONObject().put("m", it).put("g", false)) }
                raw.put("wks", wakeRows)
            }
            if (!raw.has("bed")) watch.bed?.let {
                raw.put("bed", Instant.ofEpochSecond(it).atZone(zone).toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm")))
            }
            if (!raw.has("wkAt")) watch.wake?.let {
                raw.put("wkAt", Instant.ofEpochSecond(it).atZone(zone).toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm")))
            }
            DailyEntity(
                dateIso = date,
                rhr = if (old != null && runCatching { JSONObject(old.raw).optString("huaweiHr_rhr") == "watch-sync" }.getOrDefault(false)) watch.rhr ?: old.rhr else old?.rhr ?: watch.rhr,
                hrv = if (old != null && runCatching { JSONObject(old.raw).optString("huaweiHr_hrv") == "watch-sync" }.getOrDefault(false)) watch.hrv ?: old.hrv else old?.hrv ?: watch.hrv,
                leg = old?.leg,
                mood = old?.mood,
                sleepH = old?.sleepH ?: ((watch.deep + watch.rem + watch.light + watch.unknown).takeIf { it > 0 }?.div(60.0)),
                raw = raw.toString(),
            )
        }
    }

    private data class SleepSegment(val start: Long, val end: Long, val type: Int, val stage: String)

    private class DayData {
        var rhr: Int? = null
        var hrv: Int? = null
        var sleepHr: Double? = null
        var deep = 0
        var rem = 0
        var light = 0
        var awake = 0
        var unknown = 0
        var nap = 0
        var wakes = 0
        val wakeDurations = mutableListOf<Int>()
        var sleepScore: Int? = null
        var efficiency: Int? = null
        var spo2: Int? = null
        var resp: Double? = null
        var bed: Long? = null
        var wake: Long? = null
    }

    private fun JSONObject.optIntOrNull(key: String): Int? =
        if (!has(key) || isNull(key)) null else runCatching { getInt(key) }.getOrNull()

    private fun JSONObject.optDoubleOrNull(key: String): Double? =
        if (!has(key) || isNull(key)) null else runCatching { getDouble(key) }.getOrNull()
}
