package com.endurancevault.app.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.endurancevault.app.EnduranceVaultApp
import com.endurancevault.app.data.ActStore
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.data.BackupException
import com.endurancevault.app.data.BackupParser
import com.endurancevault.app.data.BackupSummary
import com.endurancevault.app.data.NativeBackup
import com.endurancevault.app.data.KvEntity
import com.endurancevault.app.data.DailyEntity
import com.endurancevault.app.data.GearEntity
import com.endurancevault.app.data.ParsedBackup
import com.endurancevault.app.data.TrackParsers
import com.endurancevault.app.data.HuaweiWatchImport
import com.rencanalari.huaweiwatch.ProtocolBridge
import com.rencanalari.huaweiwatch.ProtocolGateway
import com.rencanalari.huaweiwatch.KeepAliveConfig
import com.endurancevault.app.security.SecretStore
import android.location.LocationManager
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import android.provider.Settings
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import org.json.JSONObject
import org.json.JSONArray
import java.time.Instant
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import com.endurancevault.app.domain.ActBuilder
import com.endurancevault.app.domain.ActImportException
import com.endurancevault.app.domain.ActDetail
import com.endurancevault.app.domain.EasyPace
import com.endurancevault.app.domain.PlanEngine
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.domain.Wx
import com.endurancevault.app.domain.WxSnapshot
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.withLock

private fun Double.toIntOrNullSafe(): Int = if (isFinite()) toInt() else 0

data class UiState(
    val settings: PlanSettings,
    val plan: PlanOutcome,
    val activities: List<ActivityEntity>,
    val daily: List<DailyEntity> = emptyList(),
    val gear: List<GearEntity> = emptyList(),
    val hrHistByActivity: Map<Long, Map<Int, Double>> = emptyMap(),
    val detailsByActivity: Map<Long, com.endurancevault.app.domain.ActDetail> = emptyMap(),
    val strengthWorkouts: List<StrengthWorkoutRecord> = emptyList(),
    /** Entri tukar hari / libur dadakan / geser / lewati (format `mv` web) dan centang manual `done`. */
    val mv: Map<String, com.endurancevault.app.domain.MvEntry> = emptyMap(),
    val done: Set<String> = emptySet(),
)

data class StrengthWorkoutRecord(
    val startEpoch: Long, val dateIso: String, val minutes: Int, val sportType: Int,
    val avgHr: Int?, val maxHr: Int?, val calories: Int?, val linkedKey: String?,
    val free: Boolean, val deleted: Boolean,
)

sealed interface ImportUi {
    data object Idle : ImportUi
    data object Working : ImportUi
    class Confirm(val backup: ParsedBackup, val file: File) : ImportUi
    class Done(val message: String) : ImportUi
    class Failed(val message: String) : ImportUi
}

/** Status cadangan lengkap (.zip): buat dan pulihkan. */
sealed interface BackupUi {
    data object Idle : BackupUi
    class Working(val label: String) : BackupUi
    class Confirm(val summary: BackupSummary) : BackupUi
    class Done(val message: String, val restored: Boolean) : BackupUi
    class Failed(val message: String) : BackupUi
}

/** Cocokkan workout jam dengan baris manual/backup agar satu sesi tidak dihitung dua kali. */
internal fun watchWorkoutMatches(
    row: ActivityEntity, dateIso: String, startTime: String, km: Double, durationSec: Int, type: String,
): Boolean {
    if (row.dateIso != dateIso || row.type != type || row.startTime == null) return false
    val timeClose = runCatching {
        val old = LocalTime.parse(row.startTime)
        val incoming = LocalTime.parse(startTime)
        kotlin.math.abs(java.time.Duration.between(old, incoming).toMinutes()).let { minOf(it, 1440 - it) } <= 5
    }.getOrDefault(false)
    val distanceClose = kotlin.math.abs(row.km - km) <= maxOf(0.20, km * 0.025)
    val durationClose = row.durationSec > 0 && kotlin.math.abs(row.durationSec - durationSec) <= 180
    return timeClose && distanceClose && durationClose
}

/** Pace easy dari lari tercatat (null bila belum ada pekan lengkap sebelum pekan ini). */
internal fun easyPaceOf(s: PlanSettings, acts: List<ActivityEntity>): Double? {
    val runs = acts.map { EasyPace.Run(it.dateIso, it.km, it.durationSec / 60.0, it.avgHr, it.type, it.gain) }
    return EasyPace.estimate(runs, EasyPace.sessHr(s))?.pace?.takeIf { it > 0 }
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val duplicateStatus = MutableStateFlow("")
    private val a = app as EnduranceVaultApp
    private val settingsFlow = MutableStateFlow(a.settings.load())

    private val kvMutex = kotlinx.coroutines.sync.Mutex()

    val state: StateFlow<UiState> = combine(
        settingsFlow,
        a.db.activities().observeAll(),
        a.db.companion().observeDaily(),
        a.db.companion().observeGear(),
        combine(a.db.companion().observeKv("swo"), a.db.companion().observeKv("mv"), a.db.companion().observeKv("done")) { swo, mv, done -> Triple(swo, mv, done) },
    ) { s, acts, daily, gear, kv ->
        val (swo, mvKv, doneKv) = kv
        val strength = runCatching {
            val arr = org.json.JSONArray(swo?.json ?: "[]")
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                StrengthWorkoutRecord(
                    startEpoch = o.optLong("s"), dateIso = o.optString("d"),
                    minutes = o.optInt("m"), sportType = o.optInt("t"),
                    avgHr = o.optInt("hr").takeIf { it > 0 }, maxHr = o.optInt("mx").takeIf { it > 0 },
                    calories = o.optInt("c").takeIf { it > 0 }, linkedKey = o.optString("k").takeIf { it.isNotBlank() },
                    free = o.optBoolean("f"), deleted = o.optBoolean("x"),
                )
            }.filter { it.startEpoch > 0 && it.minutes > 0 && !it.deleted }.sortedBy { it.startEpoch }
        }.getOrDefault(emptyList())
        val mv = com.endurancevault.app.data.MvStore.parse(mvKv?.json)
        val doneSet = com.endurancevault.app.data.MvStore.parseDone(doneKv?.json)
        // Urutan seperti web: plan mentah -> tukar hari / libur dadakan / geser -> penyesuaian beban Profil.
        val raw = PlanEngine.plan(s, easyPace = easyPaceOf(s, acts))
        val swapped = com.endurancevault.app.domain.SessionAdjust.apply(
            raw,
            com.endurancevault.app.domain.AdjInput(
                java.time.LocalDate.now(), mv, doneSet, com.endurancevault.app.domain.SessionAdjust.loggedKm(acts), s.hr,
            ),
        )
        UiState(s, com.endurancevault.app.domain.ProfilePlanAdjustments.apply(swapped, s, acts), acts, daily, gear, strengthWorkouts = strength, mv = mv, done = doneSet)
    }.map { ui ->
        val loaded = withContext(Dispatchers.IO) {
            ui.activities.mapNotNull { act ->
                val file = act.detailFile ?: return@mapNotNull null
                val detail = a.acts.read(file) ?: return@mapNotNull null
                act.id to detail
            }.toMap()
        }
        val hist = loaded.mapNotNull { (id, detail) ->
            detail.hrHist.takeIf { it.isNotEmpty() }?.let { id to it }
        }.toMap()
        ui.copy(hrHistByActivity = hist, detailsByActivity = loaded)
    }.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5_000),
        UiState(settingsFlow.value, com.endurancevault.app.domain.ProfilePlanAdjustments.apply(PlanEngine.plan(settingsFlow.value), settingsFlow.value, emptyList()), emptyList()),
    )

    init { migrateLegacyAdjustments() }

    val importState = MutableStateFlow<ImportUi>(ImportUi.Idle)
    val backupState = MutableStateFlow<BackupUi>(BackupUi.Idle)
    private var restoreStaging: File? = null

    /** Pesan hasil impor berkas FIT/GPX/TCX (null = tidak ada). */
    val trackMsg = MutableStateFlow<String?>(null)
    val watchMessage = MutableStateFlow("Jam belum dihubungkan.")
    private val watchSyncLock = AtomicBoolean(false)
    val watchSyncing = MutableStateFlow(false)
    val watchAdvancedMessage = MutableStateFlow("Fitur lanjutan jam siap dikonfigurasi.")
    val liveHrJson = MutableStateFlow(JSONObject().put("active", false).put("running", false).put("bpm", 0))
    private val watchBridge by lazy { ProtocolBridge.get(a) }
    val weatherMessage = MutableStateFlow("")
    val weatherBusy = MutableStateFlow(false)
    private val weatherPrefs = a.getSharedPreferences("weather_loc", android.content.Context.MODE_PRIVATE)
    val weatherLat = MutableStateFlow(weatherPrefs.getString("lat", null) ?: "-6.99")
    val weatherLon = MutableStateFlow(weatherPrefs.getString("lon", null) ?: "110.42")
    val weatherPlace = MutableStateFlow(weatherPrefs.getString("place", null) ?: "Ungaran, Indonesia")
    /** Data terstruktur untuk kartu sapaan + cuaca di tab Hari ini (weatherMessage tetap untuk layar Atur). */
    val weatherSnapshot = MutableStateFlow<WxSnapshot?>(null)
    /** Pesan galat singkat dari pengambilan cuaca terakhir (null = berhasil / belum ada). */
    val weatherError = MutableStateFlow<String?>(null)
    /** Nama tempat untuk ditampilkan di kartu (titik GPS memakai nama hasil reverse geocoding, bukan "Lokasi saya"). */
    val weatherPlaceLabel = MutableStateFlow(weatherPrefs.getString("place", null) ?: "Ungaran, Indonesia")
    private var weatherLastAttemptMs = 0L
    private var pushWeatherAfterFetch = false
    val weatherWatchStatus = MutableStateFlow(runCatching { watchBridge.weatherStatus().toString() }.getOrDefault("{}"))
    val agpsStatus = MutableStateFlow(runCatching { watchBridge.agpsStatus().toString() }.getOrDefault("{}"))
    val notifyStatus = MutableStateFlow(runCatching { watchBridge.notifyStatus().toString() }.getOrDefault("{}"))
    val aiStatus = MutableStateFlow(if (runCatching { SecretStore(a).get("groq_api_key") }.getOrNull().isNullOrBlank()) "Masukkan Groq API key untuk mengaktifkan AI Coach online." else "API key Groq tersimpan terenkripsi dan siap digunakan.")
    val aiBusy = MutableStateFlow(false)
    val aiMessages = MutableStateFlow<List<Pair<String, String>>>(emptyList())
    private val secretStore by lazy { SecretStore(a) }

    private suspend fun bridgeCall(block: (ProtocolGateway.Callback) -> Unit): JSONObject = suspendCancellableCoroutine { cont ->
        try {
            block(object : ProtocolGateway.Callback {
                override fun ok(result: JSONObject) { if (cont.isActive) cont.resume(result) }
                override fun error(code: String, message: String) { if (cont.isActive) cont.resumeWithException(IllegalStateException("$code: $message")) }
            })
        } catch (t: Throwable) { if (cont.isActive) cont.resumeWithException(t) }
    }

    fun fetchWeather(lat: Double, lon: Double, place: String = weatherPlace.value) {
        if (weatherBusy.value) return
        weatherLat.value = lat.toString(); weatherLon.value = lon.toString(); weatherPlace.value = place
        weatherLastAttemptMs = System.currentTimeMillis()
        weatherPrefs.edit().putString("lat", lat.toString()).putString("lon", lon.toString()).putString("place", place).apply()
        weatherBusy.value = true; weatherMessage.value = "Mengambil cuaca 7 hari dan kualitas udara…"
        viewModelScope.launch {
            weatherMessage.value = try {
                withContext(Dispatchers.IO) {
                    fun getJson(url: String): JSONObject {
                        val c = (URL(url).openConnection() as HttpURLConnection).apply { connectTimeout=12000; readTimeout=15000; requestMethod="GET"; setRequestProperty("Accept","application/json") }
                        try { if(c.responseCode !in 200..299) throw IllegalStateException("HTTP ${c.responseCode}"); return c.inputStream.bufferedReader().use { JSONObject(it.readText()) } } finally { c.disconnect() }
                    }
                    val base = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=${Wx.FORECAST_PARAMS_CURRENT}&hourly=${Wx.FORECAST_PARAMS_HOURLY}&daily=${Wx.FORECAST_PARAMS_DAILY}&forecast_days=7&timezone=auto"
                    val j=getJson(base); val cur=j.getJSONObject("current"); val daily=j.getJSONObject("daily")
                    val aq=runCatching { getJson("https://air-quality-api.open-meteo.com/v1/air-quality?latitude=$lat&longitude=$lon&current=us_aqi,european_aqi,pm2_5,pm10&timezone=auto").optJSONObject("current") }.getOrNull()
                    weatherSnapshot.value = Wx.parse(j, aq, lat, lon, place, System.currentTimeMillis())
                    val days=daily.getJSONArray("time"); val codes=daily.getJSONArray("weather_code"); val hi=daily.getJSONArray("temperature_2m_max"); val lo=daily.getJSONArray("temperature_2m_min"); val rain=daily.getJSONArray("precipitation_probability_max"); val wind=daily.getJSONArray("wind_speed_10m_max")
                    fun cond(code:Int)=when(code){0->"Cerah";1,2->"Cerah berawan";3->"Berawan";45,48->"Berkabut";51,53,55,56,57->"Gerimis";61,63,65,66,67->"Hujan";71,73,75,77->"Salju";80,81,82->"Hujan lokal";85,86->"Hujan salju";95,96,99->"Badai petir";else->"Tidak diketahui"}
                    val out=StringBuilder()
                    out.append("CUACA SAAT INI · ${cond(cur.optInt("weather_code",-1))}\nSuhu ${cur.optDouble("temperature_2m",0.0)}°C · terasa ${cur.optDouble("apparent_temperature",0.0)}°C · kelembapan ${cur.optInt("relative_humidity_2m",-1)}%\nHujan ${cur.optDouble("precipitation",0.0)} mm · angin ${cur.optDouble("wind_speed_10m",0.0)} km/jam\n")
                    out.append("KUALITAS UDARA · US AQI ${aq?.optInt("us_aqi",-1) ?: -1} · EU AQI ${aq?.optInt("european_aqi",-1) ?: -1} · PM2.5 ${aq?.optDouble("pm2_5",Double.NaN)} µg/m³ · PM10 ${aq?.optDouble("pm10",Double.NaN)} µg/m³\n\nPRAKIRAAN 7 HARI\n")
                    for(i in 0 until days.length()) out.append("${days.getString(i)} · ${cond(codes.optInt(i,-1))} · ${lo.optDouble(i)}–${hi.optDouble(i)}°C · peluang hujan ${rain.optInt(i,-1)}% · angin maks ${wind.optDouble(i)} km/jam\n")
                    out.append("\nKoordinat ${"%.4f".format(Locale.US,lat)}, ${"%.4f".format(Locale.US,lon)} · Open-Meteo")
                    out.toString()
                }
            } catch (e: Exception) { weatherError.value = e.message ?: "periksa koneksi"; "Cuaca/AQI tidak tersedia: ${e.message ?: "periksa koneksi"}" }
            weatherBusy.value=false
            if (weatherSnapshot.value?.let { it.lat == lat && it.lon == lon } == true && !weatherMessage.value.startsWith("Cuaca/AQI tidak tersedia")) {
                weatherError.value = null
                resolveWeatherLabel(lat, lon, place)
                if (pushWeatherAfterFetch) {
                    pushWeatherAfterFetch = false
                    val watchOn = runCatching { JSONObject(weatherWatchStatus.value).optBoolean("enabled", false) }.getOrDefault(false)
                    if (watchOn) sendWeatherToWatch(lat, lon, weatherPlaceLabel.value.ifBlank { place })
                }
            } else pushWeatherAfterFetch = false
        }
    }

    private fun isGpsLikePlace(n: String) = n.isBlank() || n.trim().equals("Lokasi saya", true) || n.trim().equals("My location", true)

    /** Nama tempat untuk kartu: nama kota apa adanya, atau (untuk titik GPS) hasil reverse geocoding yang di-cache per ~1 km. */
    private fun resolveWeatherLabel(lat: Double, lon: Double, place: String) {
        if (!isGpsLikePlace(place)) { weatherPlaceLabel.value = place; return }
        val key = "%.2f,%.2f".format(Locale.US, lat, lon)
        val cached = if (weatherPrefs.getString("pn_k", null) == key) weatherPrefs.getString("pn_n", null) else null
        weatherPlaceLabel.value = cached ?: "Lokasi saya"
        if (cached != null) return
        viewModelScope.launch {
            val name = withContext(Dispatchers.IO) { runCatching { reverseGeocodeName(lat, lon) }.getOrNull() }
            if (!name.isNullOrBlank()) {
                weatherPrefs.edit().putString("pn_k", key).putString("pn_n", name).apply()
                if (isGpsLikePlace(weatherPlace.value)) weatherPlaceLabel.value = name
            }
        }
    }

    /** Alamat Nominatim menjadi "Kelurahan/Kota, Kabupaten" (port wxNowPlaceFrom di web). */
    private fun reverseGeocodeName(lat: Double, lon: Double): String? {
        val url = URL("https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=14&addressdetails=1&accept-language=id&lat=$lat&lon=$lon")
        val c = url.openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10000; c.readTimeout = 12000
            c.setRequestProperty("User-Agent", "EnduranceVault/0.5 (Android)")
            if (c.responseCode !in 200..299) return null
            val addr = JSONObject(c.inputStream.bufferedReader().use { it.readText() }).optJSONObject("address") ?: return null
            fun g(vararg k: String) = k.firstNotNullOfOrNull { key -> addr.optString(key).takeIf { v -> v.isNotBlank() } }.orEmpty()
            val first = g("suburb", "village", "neighbourhood", "hamlet", "town", "city_district", "city", "municipality")
            var area = g("city", "county", "regency", "state_district", "town", "state")
            if (first == area) area = g("county", "state")
            return listOf(first, area).filter { it.isNotBlank() }.joinToString(", ").replace(Regex("\\bKabupaten\\b"), "Kab.").take(60).ifBlank { null }
        } finally { c.disconnect() }
    }

    /** Muat ulang bila data lebih tua dari [maxAgeMs]. Dipakai saat Hari ini dibuka/kembali ke layar dan oleh timer 10 menit. */
    fun refreshWeatherIfStale(maxAgeMs: Long = 15 * 60_000L) {
        if (weatherBusy.value) return
        val now = System.currentTimeMillis()
        val last = weatherSnapshot.value?.fetchedAtMs ?: 0L
        if (now - last < maxAgeMs || now - weatherLastAttemptMs < 60_000L) return
        val lat = weatherLat.value.toDoubleOrNull() ?: return
        val lon = weatherLon.value.toDoubleOrNull() ?: return
        fetchWeather(lat, lon)
    }

    /**
     * Tombol Perbarui di kartu (setara wxNowFollow di web): untuk lokasi "Lokasi saya" ambil GPS terbaru bila izin ada;
     * lokasi pilihan di Atur tidak diubah. Bila "Kirim cuaca ke jam" menyala, cuaca terbaru ikut dikirim ke jam.
     */
    fun refreshWeatherFromCard() {
        if (weatherBusy.value) return
        pushWeatherAfterFetch = true
        val fine = ContextCompat.checkSelfPermission(a, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(a, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (isGpsLikePlace(weatherPlace.value) && (fine || coarse)) { useCurrentLocation(); return }
        val lat = weatherLat.value.toDoubleOrNull() ?: -6.99
        val lon = weatherLon.value.toDoubleOrNull() ?: 110.42
        fetchWeather(lat, lon, weatherPlace.value)
    }

    fun clearWeather() { weatherMessage.value="" }

    fun searchWeatherCity(query:String) = viewModelScope.launch {
        val q=query.trim(); if(q.isEmpty()) return@launch
        weatherBusy.value=true; weatherMessage.value="Mencari lokasi…"
        try {
            val result=withContext(Dispatchers.IO) {
                val url=URL("https://geocoding-api.open-meteo.com/v1/search?count=1&language=id&name="+java.net.URLEncoder.encode(q,"UTF-8"))
                val c=url.openConnection() as HttpURLConnection
                try {
                    c.connectTimeout=10000; c.readTimeout=12000
                    val j=JSONObject(c.inputStream.bufferedReader().use{it.readText()})
                    val x=j.optJSONArray("results")?.optJSONObject(0)?:throw IllegalStateException("Kota tidak ditemukan")
                    Triple(x.getDouble("latitude"),x.getDouble("longitude"),listOf(x.optString("name"),x.optString("admin1"),x.optString("country")).filter{it.isNotBlank()}.joinToString(", "))
                } finally { c.disconnect() }
            }
            weatherBusy.value=false; fetchWeather(result.first,result.second,result.third)
        } catch(e:Exception) { weatherMessage.value="Pencarian lokasi gagal: ${e.message}"; weatherBusy.value=false }
    }

    @Suppress("MissingPermission")
    fun useCurrentLocation() {
        val fine=ContextCompat.checkSelfPermission(a,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED
        val coarse=ContextCompat.checkSelfPermission(a,Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED
        if(!fine&&!coarse){weatherMessage.value="Izin lokasi belum diberikan. Tekan Gunakan GPS dan izinkan akses saat digunakan.";return}
        try {
            val lm=a.getSystemService(android.content.Context.LOCATION_SERVICE) as LocationManager
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                val provider = if (fine && lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) LocationManager.GPS_PROVIDER else LocationManager.NETWORK_PROVIDER
                lm.getCurrentLocation(provider, null, a.mainExecutor) { loc ->
                    if (loc != null) fetchWeather(loc.latitude,loc.longitude,"Lokasi saya")
                    else weatherMessage.value="Lokasi saat ini belum tersedia. Periksa GPS dan coba lagi."
                }
            } else {
                val loc=lm.getProviders(true).mapNotNull { provider -> runCatching { lm.getLastKnownLocation(provider) }.getOrNull() }.maxByOrNull { it.time }
                if(loc==null){weatherMessage.value="Lokasi terakhir belum tersedia. Aktifkan lokasi perangkat lalu coba lagi.";return}
                fetchWeather(loc.latitude,loc.longitude,"Lokasi saya")
            }
        } catch(e:Exception){weatherMessage.value="Lokasi tidak tersedia: ${e.message}"}
    }

    fun sendWeatherToWatch(lat: Double, lon: Double, name: String) = viewModelScope.launch {
        aiStatus.value = "Mengirim cuaca ke Huawei Watch…"
        try {
            val result=bridgeCall { cb -> watchBridge.setWeather(JSONObject().put("enabled",true).put("lat",lat).put("lon",lon).put("name",if(name=="Lokasi latihan") weatherPlace.value else name).put("unit","celsius").put("intervalMinutes",60).toString(),cb) }
            weatherWatchStatus.value=result.toString()
            val refreshed=bridgeCall { cb -> watchBridge.refreshWeather(cb) }
            weatherWatchStatus.value=refreshed.toString(); aiStatus.value="Cuaca berhasil diminta untuk dikirim ke jam."
        } catch(e:Exception) { aiStatus.value="Pengiriman cuaca gagal: ${e.message}"; weatherWatchStatus.value=runCatching{watchBridge.weatherStatus().toString()}.getOrDefault("{}") }
    }

    fun setAgps(enabled:Boolean, mirror:String) = viewModelScope.launch {
        try { agpsStatus.value=bridgeCall { cb -> watchBridge.setAgps(JSONObject().put("enabled",enabled).put("mirrorUrl",mirror.trim()).toString(),cb) }.toString() }
        catch(e:Exception) { agpsStatus.value=runCatching{watchBridge.agpsStatus().put("lastError",e.message).toString()}.getOrDefault("{}") }
    }
    fun testAgps() = viewModelScope.launch {
        try { agpsStatus.value=bridgeCall { cb -> watchBridge.testAgps(cb) }.toString() }
        catch(e:Exception) { agpsStatus.value=runCatching{watchBridge.agpsStatus().put("lastError",e.message).toString()}.getOrDefault("{}") }
    }
    fun setWatchNotifications(enabled:Boolean, quiet:Boolean, start:Int, end:Int, screenOff:Boolean, apps:Map<String,Boolean> = emptyMap()) = viewModelScope.launch {
        try { val payload=JSONObject().put("enabled",enabled).put("quietEnabled",quiet).put("quietStart",start).put("quietEnd",end).put("onlyScreenOff",screenOff).put("apps",JSONObject(apps)); notifyStatus.value=bridgeCall { cb -> watchBridge.setNotify(payload.toString(),cb) }.toString() }
        catch(e:Exception) { notifyStatus.value=runCatching{watchBridge.notifyStatus().put("lastError",e.message).toString()}.getOrDefault("{}") }
    }
    fun testWatchNotification() = viewModelScope.launch {
        try { notifyStatus.value=bridgeCall { cb -> watchBridge.testNotify(cb) }.toString() }
        catch(e:Exception) { notifyStatus.value=runCatching{watchBridge.notifyStatus().put("lastError",e.message).toString()}.getOrDefault("{}") }
    }

    fun saveAiKey(value:String) {
        secretStore.put("groq_api_key",value.trim())
        aiStatus.value=if(value.isBlank())"API key dihapus." else "API key tersimpan terenkripsi di Android Keystore."
    }

    fun sendAiQuestion(question:String, enteredKey:String, webSearch:Boolean = true) {
        val q=question.trim(); if(q.isEmpty()||aiBusy.value)return
        val key=enteredKey.trim().ifBlank { secretStore.get("groq_api_key").orEmpty() }
        if(key.isBlank()){aiStatus.value="Masukkan dan simpan Groq API key terlebih dahulu.";return}
        if(enteredKey.isNotBlank()) secretStore.put("groq_api_key",enteredKey.trim())
        aiBusy.value=true; aiMessages.update { (it+ listOf("user" to q)).takeLast(16) }; aiStatus.value="Menganalisis data latihan dan menghubungi AI…"
        viewModelScope.launch {
            try {
                val answer=withContext(Dispatchers.IO) {
                    val recent=state.value.activities.sortedByDescending{it.dateIso}.take(12).joinToString("\n") { x -> "${x.dateIso}: ${x.km} km, ${x.durationSec/60} menit, pace ${if(x.km>0)"%.2f".format(Locale.US,x.durationSec/60.0/x.km) else "—"} menit/km, HR ${x.avgHr?:"—"}, elevasi ${x.gain?:"—"} m" }
                    val daily=state.value.daily.take(7).joinToString("\n") { d -> "${d.dateIso}: tidur ${d.sleepH?:"—"} jam, HR istirahat ${d.rhr?:"—"}, HRV ${d.hrv?:"—"}, kaki ${d.leg?:"—"}/5, mood/stres ${d.mood?:"—"}/5" }
                    val plan=when(val p=state.value.plan){ is PlanOutcome.Ok -> p.weeks.flatMap{it.days}.filter{!it.date.isBefore(java.time.LocalDate.now())}.take(7).joinToString("\n"){d->"${d.date}: ${d.title}, ${d.km} km. ${d.detail}"}; is PlanOutcome.Err -> p.message }
                    val system="Kamu adalah AI Coach EnduranceVault. Jawab Bahasa Indonesia, ringkas dan spesifik. Gunakan hanya data berikut; jangan mengarang angka atau mengubah rumus readiness/CTL/ATL/TSB/Training Effect. Jika data tidak tersedia, katakan tidak tersedia. Data aktivitas terbaru:\n$recent\nKondisi harian (7 catatan terakhir):\n$daily\nRencana mendatang:\n$plan\nPengaturan: ${state.value.settings.name}; HR max ${state.value.settings.hr}; target pace ${state.value.settings.pace}. Data pribadi hanya dikirim karena pengguna menekan tombol Kirim."
                    val msgs=JSONArray().put(JSONObject().put("role","system").put("content",system))
                    aiMessages.value.takeLast(11).forEach { (role,msg) -> msgs.put(JSONObject().put("role",if(role=="coach")"assistant" else "user").put("content",msg)) }
                    val body=JSONObject().put("model","openai/gpt-oss-120b").put("messages",msgs).put("temperature",0.25).put("max_tokens",if(webSearch)1800 else 900)
                    if(webSearch) body.put("tools",JSONArray().put(JSONObject().put("type","browser_search")))
                    val c=(URL("https://api.groq.com/openai/v1/chat/completions").openConnection() as HttpURLConnection).apply { requestMethod="POST";connectTimeout=15000;readTimeout=45000;doOutput=true;setRequestProperty("Authorization","Bearer $key");setRequestProperty("Content-Type","application/json") }
                    try { c.outputStream.use{it.write(body.toString().toByteArray())}; val code=c.responseCode; val stream=if(code in 200..299)c.inputStream else c.errorStream; val data=stream?.bufferedReader()?.use{it.readText()}.orEmpty(); if(code !in 200..299) throw IllegalStateException("Groq HTTP $code: ${runCatching{JSONObject(data).optJSONObject("error")?.optString("message")}.getOrNull()?:data.take(180)}"); JSONObject(data).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")?.takeIf{it.isNotBlank()}?:throw IllegalStateException("Model tidak memberikan jawaban") } finally { c.disconnect() }
                }
                aiMessages.update { (it+ listOf("coach" to answer)).takeLast(16) }; aiStatus.value=if(webSearch)"Jawaban diterima dari Groq · GPT-OSS 120B (pencarian web diizinkan)." else "Jawaban diterima dari Groq · GPT-OSS 120B."
            } catch(e:Exception) { aiStatus.value="AI Coach gagal: ${e.message ?: e.javaClass.simpleName}" }
            finally { aiBusy.value=false }
        }
    }

    /** Simpan (atau hapus bila [entry] null) satu entri `mv`: tukar hari "sw:tanggal", libur dadakan, geser, lewati. */
    fun setMv(key: String, entry: com.endurancevault.app.domain.MvEntry?) = viewModelScope.launch(Dispatchers.IO) {
        kvMutex.withLock {
            val dao = a.db.companion()
            val map = com.endurancevault.app.data.MvStore.parse(dao.kv("mv")).toMutableMap()
            if (entry == null) map.remove(key) else map[key] = entry
            dao.putKv(listOf(KvEntity("mv", com.endurancevault.app.data.MvStore.toJson(map))))
        }
    }

    /** Centang manual sesi selesai. Kunci: "tanggal" untuk lari, "tanggal:s", "tanggal:a", "tanggal:u" untuk strength/ankle/upper. */
    fun setDone(key: String, value: Boolean) = viewModelScope.launch(Dispatchers.IO) {
        kvMutex.withLock {
            val dao = a.db.companion()
            dao.putKv(listOf(KvEntity("done", com.endurancevault.app.data.MvStore.doneJson(dao.kv("done"), key, value))))
        }
    }

    /** Sekali jalan: pindahkan tukar jadwal dan libur dadakan lama (SharedPreferences) ke format mv bila mv belum ada. */
    private fun migrateLegacyAdjustments() = viewModelScope.launch(Dispatchers.IO) {
        runCatching {
            val prefs = a.getSharedPreferences("week_adjustments_v1", android.content.Context.MODE_PRIVATE)
            if (prefs.getBoolean("migrated_mv", false)) return@runCatching
            kvMutex.withLock {
                val dao = a.db.companion()
                val legacy = com.endurancevault.app.data.MvStore.fromLegacy(prefs.getString("data", "{}"))
                if (legacy.isNotEmpty()) {
                    val cur = com.endurancevault.app.data.MvStore.parse(dao.kv("mv")).toMutableMap()
                    legacy.forEach { (k, v) -> if (k !in cur) cur[k] = v }
                    dao.putKv(listOf(KvEntity("mv", com.endurancevault.app.data.MvStore.toJson(cur))))
                }
                prefs.edit().putBoolean("migrated_mv", true).apply()
            }
        }
    }

    fun saveSettings(s: PlanSettings) {
        a.settings.save(s)
        settingsFlow.update { s }
    }

    fun addActivity(e: ActivityEntity) = viewModelScope.launch { a.db.activities().insert(e) }
    fun deleteActivity(id: Long) = viewModelScope.launch { a.db.activities().delete(id) }
    private var pendingDuplicatePairs: List<Pair<ActivityEntity, ActivityEntity>> = emptyList()

    private fun legacySameActivity(a: ActivityEntity, b: ActivityEntity): Boolean {
        if (a.dateIso != b.dateIso || a.type != b.type) return false
        val ta = a.startTime?.trim()?.takeIf { it.isNotEmpty() }
        val tb = b.startTime?.trim()?.takeIf { it.isNotEmpty() }
        if (ta != null && tb != null) {
            fun minuteOfDay(value: String): Int? {
                val parts = value.split(":")
                if (parts.size < 2) return null
                val h = parts[0].toIntOrNull() ?: return null
                val m = parts[1].toIntOrNull() ?: return null
                if (h !in 0..23 || m !in 0..59) return null
                return h * 60 + m
            }
            val ma = minuteOfDay(ta); val mb = minuteOfDay(tb)
            if (ma != null && mb != null) return kotlin.math.abs(ma - mb) <= 1
        }
        return a.km > 0.0 && b.km > 0.0 &&
            kotlin.math.abs(a.km - b.km) < 0.1 &&
            kotlin.math.abs(a.durationSec - b.durationSec) < 120
    }

    fun scanDuplicateActivities() = viewModelScope.launch {
        duplicateStatus.value = "Memeriksa aktivitas…"
        val rows = withContext(Dispatchers.IO) { a.db.activities().observeAll().first() }
        val groups = rows.groupBy { it.dateIso to it.type }
        val pairs = mutableListOf<Pair<ActivityEntity, ActivityEntity>>()
        groups.values.forEach { group ->
            val sorted = group.sortedWith(compareByDescending<ActivityEntity> { it.detailFile != null }.thenBy { it.id })
            for (i in sorted.indices) for (j in i + 1 until sorted.size) {
                val left = sorted[i]; val right = sorted[j]
                // Mirror legacy behavior: at least one record must carry watch/track detail.
                if ((left.detailFile != null || right.detailFile != null) && legacySameActivity(left, right)) {
                    pairs += left to right
                }
            }
        }
        pendingDuplicatePairs = pairs
        duplicateStatus.value = if (pairs.isEmpty()) {
            "Tidak ditemukan aktivitas ganda dengan kriteria aplikasi lama."
        } else {
            "Ditemukan ${pairs.size} pasangan kandidat:\n" + pairs.take(12).joinToString("\n") { (a1, b1) ->
                val keeper = if (a1.detailFile != null) a1 else b1
                val other = if (keeper.id == a1.id) b1 else a1
                "${keeper.dateIso} · ${keeper.type} · ${"%.2f".format(keeper.km)} km / ${keeper.durationSec / 60} mnt ↔ ${"%.2f".format(other.km)} km / ${other.durationSec / 60} mnt"
            } + if (pairs.size > 12) "\n…dan ${pairs.size - 12} pasangan lainnya." else ""
        }
    }

    fun mergeDuplicateActivities() = viewModelScope.launch {
        val pairs = pendingDuplicatePairs
        if (pairs.isEmpty()) {
            duplicateStatus.value = "Belum ada kandidat. Jalankan pemeriksaan terlebih dahulu."
            return@launch
        }
        duplicateStatus.value = "Menggabungkan ${pairs.size} pasangan…"
        val dao = a.db.activities()
        var merged = 0
        withContext(Dispatchers.IO) {
            pairs.forEach { (first, second) ->
                val currentA = dao.byId(first.id) ?: return@forEach
                val currentB = dao.byId(second.id) ?: return@forEach
                if (!legacySameActivity(currentA, currentB)) return@forEach
                val primary = if (currentA.detailFile != null) currentA else if (currentB.detailFile != null) currentB else currentA
                val secondary = if (primary.id == currentA.id) currentB else currentA
                val mergedRow = primary.copy(
                    feel = primary.feel ?: secondary.feel,
                    note = primary.note.ifBlank { secondary.note },
                    name = primary.name.ifBlank { secondary.name },
                    gearId = primary.gearId ?: secondary.gearId,
                    avgHr = primary.avgHr ?: secondary.avgHr,
                    maxHr = primary.maxHr ?: secondary.maxHr,
                    gain = primary.gain ?: secondary.gain,
                    detailFile = primary.detailFile ?: secondary.detailFile,
                    srcKey = primary.srcKey.ifBlank { secondary.srcKey },
                    startTime = primary.startTime ?: secondary.startTime,
                )
                dao.mergeDuplicate(mergedRow, secondary.id)
                merged++
            }
        }
        pendingDuplicatePairs = emptyList()
        duplicateStatus.value = if (merged > 0) {
            "$merged aktivitas ganda digabung. Detail jam/rute dan catatan manual dipertahankan."
        } else {
            "Tidak ada pasangan yang masih memenuhi kriteria untuk digabung."
        }
    }

    /** Catatan kesiapan harian disimpan native di Room; tanggal menjadi identitas unik. */
    fun saveDaily(item: DailyEntity) = viewModelScope.launch { a.db.companion().saveDaily(item) }

    /** Gear dapat diperbarui/dipensiunkan tanpa menghapus riwayat aktivitas yang pernah memakainya. */
    fun saveGear(item: GearEntity) = viewModelScope.launch { a.db.companion().saveGear(item) }
    fun deleteGear(id: String) = viewModelScope.launch { a.db.companion().deleteGear(id) }

    /** Salin berkas ke penyimpanan aplikasi (utuh, tanpa kehilangan data), lalu baca ringkasannya. */
    fun startImport(uri: Uri) {
        importState.value = ImportUi.Working
        viewModelScope.launch {
            importState.value = try {
                val picked = withContext(Dispatchers.IO) {
                    val dir = File(a.filesDir, "imports").apply { mkdirs() }
                    val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
                    val f = File(dir, "cadangan-web-$stamp.json")
                    val ins = a.contentResolver.openInputStream(uri) ?: throw BackupException("Berkas tidak bisa dibuka.")
                    ins.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                    try {
                        f to f.inputStream().use { BackupParser.parse(it) }
                    } catch (e: BackupException) {
                        f.delete(); throw e
                    }
                }
                ImportUi.Confirm(picked.second, picked.first)
            } catch (e: BackupException) {
                ImportUi.Failed(e.message ?: "Cadangan tidak bisa dibaca.")
            } catch (e: Exception) {
                ImportUi.Failed("Gagal membaca berkas: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    fun confirmImport() {
        val c = importState.value as? ImportUi.Confirm ?: return
        importState.value = ImportUi.Working
        viewModelScope.launch {
            try {
                // Extract into staging first. A malformed/truncated `acts` section must never
                // erase detail files that are currently referenced by the live database.
                val staging = File(a.cacheDir, "backup-acts-${System.nanoTime()}").apply { mkdirs() }
                var restoredActivities: List<ActivityEntity> = emptyList()
                try {
                    val keys = withContext(Dispatchers.IO) {
                        c.file.inputStream().use { BackupParser.extractActs(it, staging) }
                    }.toSet()
                    restoredActivities = c.backup.activities.map {
                        if (it.srcKey in keys) it.copy(detailFile = ActStore.backupFileName(it.srcKey)) else it
                    }
                    a.db.activities().replaceImported(restoredActivities)
                    a.db.companion().replaceAll(c.backup.daily, c.backup.gear, c.backup.kv.map { KvEntity(it.key, it.value) })
                    withContext(Dispatchers.IO) { a.acts.installBackupFiles(staging) }
                    saveSettings(c.backup.settings)
                } finally {
                    staging.deleteRecursively()
                }
                importState.value = ImportUi.Done(
                    "Pengaturan rencana, ${restoredActivities.size} catatan lari (${restoredActivities.count { it.detailFile != null }} dengan rute dan grafik), " +
                        "${c.backup.daily.size} catatan harian, dan ${c.backup.gear.size} gear dipulihkan. " +
                        "Salinan lengkap cadangan disimpan di penyimpanan aplikasi.",
                )
            } catch (e: Exception) {
                importState.value = ImportUi.Failed("Gagal memulihkan: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    /** Impor satu atau beberapa berkas FIT/GPX/TCX sebagai aktivitas dengan rute dan grafik. */
    fun importTracks(uris: List<Uri>) {
        trackMsg.value = "Membaca ${uris.size} berkas…"
        viewModelScope.launch {
            var added = 0; var attached = 0; var skipped = 0
            val errs = mutableListOf<String>()
            for ((i, u) in uris.withIndex()) {
                try {
                    val act = withContext(Dispatchers.IO) {
                        val bytes = a.contentResolver.openInputStream(u)?.use { it.readBytes() }
                            ?: throw ActImportException("berkas tidak bisa dibuka")
                        if (bytes.size > 80_000_000) throw ActImportException("berkas terlalu besar (maks 80 MB)")
                        val t = TrackParsers.parse(bytes)
                        ActBuilder.build(t.pts, t.sport, t.name)
                    }
                    val date = act["date"] as String; val st = act["st"] as String
                    val km = act["km"] as Double
                    val existing = state.value.activities.firstOrNull {
                        it.dateIso == date && (it.startTime == st || it.startTime == null) && kotlin.math.abs(it.km - km) < 0.3 && it.type == (if (act["bike"] == true) "bike" else "run")
                    }
                    if (existing != null && existing.detailFile != null) { skipped++; continue }
                    val id = existing?.id ?: a.db.activities().insert(
                        ActivityEntity(
                            dateIso = date, km = km, durationSec = Math.round((act["min"] as Double) * 60).toInt(),
                            avgHr = (act["hr"] as? Double)?.toInt(), maxHr = (act["hrMax"] as? Double)?.toInt(),
                            gain = (act["gain"] as? Double)?.toInt(), startTime = st, name = act["nm"] as String,
                            type = if (act["bike"] == true) "bike" else "run",
                        ),
                    )
                    val file = ActStore.importFileName(id)
                    withContext(Dispatchers.IO) { a.acts.write(file, act) }
                    a.db.activities().setDetail(id, file)
                    if (existing != null) attached++ else added++
                } catch (e: ActImportException) {
                    errs.add("berkas ${i + 1}: ${e.message}")
                } catch (e: Exception) {
                    errs.add("berkas ${i + 1}: ${e.message ?: e.javaClass.simpleName}")
                }
            }
            trackMsg.value = buildString {
                append("$added aktivitas baru")
                if (attached > 0) append(", $attached dilengkapi rute dan grafik")
                if (skipped > 0) append(", $skipped sudah ada")
                if (errs.isNotEmpty()) append(". Gagal: " + errs.joinToString("; "))
                append(".")
            }
        }
    }

    /** Hubungkan langsung ke jam Huawei melalui protokol Bluetooth JoyoFit/Gadgetbridge yang sudah ada di proyek sumber. */
    fun connectWatch(address: String) {
        watchMessage.value = "Menghubungkan ke jam… konfirmasi permintaan ikatan pada layar jam bila muncul."
        watchBridge.connect(address, object : ProtocolGateway.Callback {
            override fun ok(result: JSONObject) {
                KeepAliveConfig.setWanted(a, true)
                val keep = KeepAliveConfig.start(a)
                watchMessage.value = buildString {
                    append("Terhubung: ").append(result.optString("name", "Huawei Watch"))
                    result.optString("model").takeIf { it.isNotBlank() }?.let { append(" · ").append(it) }
                    append(".")
                    if (keep != null) append(" Penjagaan latar belum aktif: ").append(keep)
                    else append(" Penjagaan koneksi latar aktif.")
                }
                syncWatch(false)
            }
            override fun error(code: String, message: String) {
                watchMessage.value = "Gagal menghubungkan [$code]: $message"
            }
        })
    }

    fun disconnectWatch() {
        KeepAliveConfig.setWanted(a, false)
        KeepAliveConfig.stop(a)
        watchBridge.disconnect()
        watchMessage.value = "Jam diputuskan. Data yang sudah tersimpan tidak dihapus."
    }

    /** Hapus hanya kredensial pairing perangkat terpilih, lalu lakukan pairing ulang seperti aplikasi lama. */
    fun forgetAndReconnectWatch(address: String) {
        if (!watchSyncLock.compareAndSet(false, true)) {
            watchMessage.value = "Operasi jam lain sedang berjalan. Tunggu hingga selesai."
            return
        }
        watchSyncing.value = true
        watchMessage.value = "Memutuskan koneksi dan menghapus kunci pairing lama… data latihan tetap aman."
        KeepAliveConfig.setWanted(a, false)
        KeepAliveConfig.stop(a)
        try {
            watchBridge.disconnect()
            watchBridge.forget(address)
            watchMessage.value = "Kunci pairing lama dihapus. Memulai pairing ulang… konfirmasi di layar jam bila diminta."
            watchBridge.connect(address, object : ProtocolGateway.Callback {
                override fun ok(result: JSONObject) {
                    KeepAliveConfig.setWanted(a, true)
                    val keep = KeepAliveConfig.start(a)
                    watchMessage.value = buildString {
                        append("Pairing ulang berhasil: ").append(result.optString("name", "Huawei Watch"))
                        result.optString("model").takeIf { it.isNotBlank() }?.let { append(" · ").append(it) }
                        append(". Data latihan tidak dihapus.")
                        if (keep != null) append(" Penjagaan latar belum aktif: ").append(keep)
                    }
                    watchSyncing.value = false
                    watchSyncLock.set(false)
                    syncWatch(false)
                }
                override fun error(code: String, message: String) {
                    watchMessage.value = "Pairing ulang gagal [$code]: $message. Kunci lama sudah dihapus; coba Hubungkan lagi. Data latihan tetap aman."
                    watchSyncing.value = false
                    watchSyncLock.set(false)
                }
            })
        } catch (e: Exception) {
            watchMessage.value = "Gagal menyiapkan pairing ulang: ${e.message ?: e.javaClass.simpleName}. Data latihan tidak dihapus."
            watchSyncing.value = false
            watchSyncLock.set(false)
        }
    }

    fun syncWatch(fullHistory: Boolean = false) {
        if (!watchSyncLock.compareAndSet(false, true)) {
            watchMessage.value = "Sinkronisasi sedang berjalan. Tunggu hingga selesai sebelum meminta sinkronisasi berikutnya."
            return
        }
        watchSyncing.value = true
        watchMessage.value = if (fullHistory) "Mengambil seluruh riwayat dari jam…" else "Menyinkronkan data jam…"
        try {
            watchBridge.sync(fullHistory, object : ProtocolGateway.Callback {
                override fun ok(result: JSONObject) {
                    viewModelScope.launch {
                        try {
                            val imported = withContext(Dispatchers.IO) { importWatchData(fullHistory) }
                            val samples = result.optInt("samples", 0)
                            val sleep = result.optInt("sleep", 0)
                            val workouts = result.optInt("workouts", 0)
                            watchMessage.value = "Sinkron selesai: $samples sampel, $sleep segmen tidur, $workouts workout. " +
                                "${imported.first} hari kondisi diperbarui; ${imported.second} aktivitas diimpor."
                        } catch (e: Exception) {
                            watchMessage.value = "Sinkron jam berhasil, tetapi impor ke EnduranceVault gagal: ${e.message ?: e.javaClass.simpleName}"
                        } finally {
                            watchSyncLock.set(false)
                            watchSyncing.value = false
                        }
                    }
                }
                override fun error(code: String, message: String) {
                    watchMessage.value = "Sinkron gagal [$code]: $message"
                    watchSyncLock.set(false)
                    watchSyncing.value = false
                }
            })
        } catch (e: Exception) {
            watchMessage.value = "Sinkron gagal: ${e.message ?: e.javaClass.simpleName}"
            watchSyncLock.set(false)
            watchSyncing.value = false
        }
    }

    fun refreshLiveHr() {
        runCatching { watchBridge.liveHeartRate() }.onSuccess { liveHrJson.value = it }
    }

    fun setLiveHr(active: Boolean) {
        try {
            watchBridge.setLiveHeartRate(active)
            refreshLiveHr()
            watchAdvancedMessage.value = if (active) "Permintaan Live HR dikirim ke jam." else "Live HR dimatikan; HR otomatis jam dipulihkan."
        } catch (e: Exception) {
            watchAdvancedMessage.value = "Live HR gagal: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    fun syncWatchHrZones(settings: PlanSettings) {
        try {
            // Samakan dengan zjPayload() aplikasi lama: HRR memakai lima batas Karvonen;
            // LTHR dikirim sebagai MHR biasa, dengan Z1 = min(50% HRmax, awal Z2 - 1).
            val today = java.time.LocalDate.now().toString()
            val restValues = state.value.daily
                .filter { it.dateIso < today && it.rhr != null }
                .sortedBy { it.dateIso }.takeLast(14).mapNotNull { it.rhr }.sorted()
            val restDefault = restValues.getOrNull(restValues.size / 2) ?: 55
            val cuts = com.endurancevault.app.domain.Zones.cuts(settings, restDefault)
            val method = if (cuts.mode == "hrr") "hrr" else "mhr"
            val lower = if (cuts.mode == "hrr") cuts.lo else {
                val z1 = minOf(kotlin.math.round(cuts.maxHr * 0.5).toInt(), cuts.lo[1] - 1)
                listOf(z1) + cuts.lo.drop(1)
            }
            require(lower.size == 5) { "Batas zona HR tidak lengkap." }
            require(lower.all { it in 1..219 } && lower.zipWithNext().all { it.second > it.first }) {
                "Batas zona harus 1–219 bpm dan naik berurutan."
            }
            require(cuts.maxHr in 100..219 && lower[4] <= cuts.maxHr) { "HR maks atau batas zona di luar rentang jam." }
            val restHr = cuts.rest ?: restDefault
            require(restHr in 30..150 && (method != "hrr" || lower[0] > restHr)) {
                "HR istirahat atau batas Z1 tidak valid untuk jam."
            }
            val payload = JSONObject().put("method", method).put("lower", JSONArray(lower))
                .put("maxHr", cuts.maxHr).put("restHr", restHr)
            watchBridge.setHrZones(payload.toString(), object : ProtocolGateway.Callback {
                override fun ok(result: JSONObject) {
                    watchAdvancedMessage.value = if (result.optBoolean("sent")) "Zona HR tersimpan dan dikirim ke jam (${result.optString("branch")})." else "Zona HR tersimpan di aplikasi; jam belum terhubung atau belum mendukung jalur kirim."
                }
                override fun error(code: String, message: String) { watchAdvancedMessage.value = "Zona HR gagal [$code]: $message" }
            })
        } catch (e: Exception) { watchAdvancedMessage.value = "Zona HR tidak valid: ${e.message ?: e.javaClass.simpleName}" }
    }

    fun pushStructuredWorkout(name: String, warmupMin: Int, repeats: Int, runMin: Int, recoveryMin: Int, cooldownMin: Int) {
        try {
            require(repeats in 1..20 && runMin in 1..180 && warmupMin in 0..60 && recoveryMin in 0..60 && cooldownMin in 0..60) { "Durasi/repetisi di luar batas." }
            val steps = JSONArray()
            if (warmupMin > 0) steps.put(JSONObject().put("kind", "warmup").put("target", "time").put("value", warmupMin * 60).put("intensity", "none"))
            steps.put(JSONObject().put("kind", "run").put("target", "time").put("value", runMin * 60).put("intensity", "none"))
            if (recoveryMin > 0) steps.put(JSONObject().put("kind", "rest").put("target", "time").put("value", recoveryMin * 60).put("intensity", "none"))
            val blocks = JSONArray().put(JSONObject().put("repeat", repeats).put("steps", JSONArray().put(JSONObject().put("kind", "run").put("target", "time").put("value", runMin * 60).put("intensity", "none")).apply {
                if (recoveryMin > 0) put(JSONObject().put("kind", "rest").put("target", "time").put("value", recoveryMin * 60).put("intensity", "none"))
            }))
            val all = JSONArray()
            if (warmupMin > 0) all.put(JSONObject().put("repeat", 1).put("steps", JSONArray().put(JSONObject().put("kind", "warmup").put("target", "time").put("value", warmupMin * 60).put("intensity", "none"))))
            all.put(blocks.getJSONObject(0))
            if (cooldownMin > 0) all.put(JSONObject().put("repeat", 1).put("steps", JSONArray().put(JSONObject().put("kind", "cooldown").put("target", "time").put("value", cooldownMin * 60).put("intensity", "none"))))
            val payload = JSONObject().put("courses", JSONArray().put(JSONObject().put("id", "ev-${System.currentTimeMillis()}").put("name", name.ifBlank { "EnduranceVault Workout" }).put("blocks", all)))
            watchBridge.pushCourses(payload.toString(), object : ProtocolGateway.Callback {
                override fun ok(result: JSONObject) { watchAdvancedMessage.value = "Workout dikirim: ${result.optInt("sent")} berhasil, ${result.optInt("failed")} gagal. Periksa respons jam dan log protokol." }
                override fun error(code: String, message: String) { watchAdvancedMessage.value = "Pengiriman workout gagal [$code]: $message" }
            })
        } catch (e: Exception) { watchAdvancedMessage.value = "Workout tidak valid: ${e.message ?: e.javaClass.simpleName}" }
    }

    fun pushGpxRoute(uri: Uri) {
        viewModelScope.launch {
            try {
                val payload = withContext(Dispatchers.IO) {
                    val xml = a.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("GPX tidak dapat dibuka")
                    val doc = javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(xml.byteInputStream())
                    val nodes = doc.getElementsByTagName("trkpt")
                    val points = JSONArray()
                    for (i in 0 until nodes.length) {
                        val node = nodes.item(i) as org.w3c.dom.Element
                        val lat = node.getAttribute("lat").toDoubleOrNull() ?: continue
                        val lon = node.getAttribute("lon").toDoubleOrNull() ?: continue
                        val eleNode = node.getElementsByTagName("ele")
                        val ele = if (eleNode.length > 0) eleNode.item(0).textContent.toDoubleOrNull() else null
                        points.put(JSONArray().put(lat).put(lon).put(ele ?: JSONObject.NULL))
                    }
                    require(points.length() >= 2) { "GPX harus memiliki minimal dua titik track (trkpt)." }
                    JSONObject().put("name", "EnduranceVault Route").put("points", points).toString()
                }
                watchAdvancedMessage.value = "Mengirim rute GPX ke jam…"
                watchBridge.pushRoute(payload, object : ProtocolGateway.Callback {
                    override fun ok(result: JSONObject) { watchAdvancedMessage.value = if (result.optBoolean("ok")) "Rute terkirim: ${result.optInt("points")} titik, ${result.optInt("bytes")} byte. Status unggah: ${result.optString("uploadStatus")}; jawaban jam: ${result.optBoolean("answered")}." else "Jam belum mengonfirmasi penerimaan rute: $result" }
                    override fun error(code: String, message: String) { watchAdvancedMessage.value = "Rute gagal [$code]: $message" }
                })
            } catch (e: Exception) { watchAdvancedMessage.value = "GPX gagal diproses: ${e.message ?: e.javaClass.simpleName}" }
        }
    }

    private suspend fun importWatchData(fullHistory: Boolean): Pair<Int, Int> {
        val now = System.currentTimeMillis() / 1000L
        val since = if (fullHistory) 0L else now - 45L * 24L * 3600L
        val zone = ZoneId.systemDefault()
        val offsetMin = zone.rules.getOffset(Instant.now()).totalSeconds / 60
        val dailyPayload = watchBridge.readDaily(since, offsetMin)
        val existingDaily = state.value.daily
        val dailyRows = HuaweiWatchImport.daily(dailyPayload, existingDaily, zone)
        dailyRows.forEach { a.db.companion().saveDaily(it) }

        val workoutPayload = watchBridge.readWorkouts(since, if (fullHistory) 100 else 60).optJSONArray("workouts") ?: JSONArray()
        var imported = 0
        for (i in 0 until workoutPayload.length()) {
            val w = workoutPayload.optJSONObject(i) ?: continue
            val start = w.optLong("start", 0L)
            val duration = w.optInt("duration", 0)
            val distanceM = w.optInt("distance", 0)
            val sport = w.optInt("sportType", -1)
            if (start <= 0 || duration <= 0 || distanceM <= 0 || w.optBoolean("complete", true).not()) continue
            val type = when (sport) {
                1, 11 -> "run"
                3 -> "bike"
                else -> continue
            }
            val srcKey = "watch:$start"
            val startAt = Instant.ofEpochSecond(start).atZone(zone)
            val date = startAt.toLocalDate().toString()
            val time = startAt.toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm"))
            val km = distanceM / 1000.0
            // Baca langsung dari Room, bukan hanya StateFlow yang mungkin belum sempat terbarui.
            val dayRows = a.db.activities().byDateAndType(date, type)
            val exactWatch = dayRows.firstOrNull { it.srcKey == srcKey }
            val similarExisting = exactWatch ?: dayRows.firstOrNull { row ->
                watchWorkoutMatches(row, date, time, km, duration, type)
            }
            // Bila sudah ada aktivitas serupa dari backup/manual, gabungkan metadata jam ke baris itu;
            // jangan membuat sesi kedua yang akan menggandakan load/CTL/ATL.
            val points = if (w.optInt("gpsPoints", 0) >= 2 && (similarExisting?.detailFile == null)) {
                runCatching { watchBridge.readWorkoutPoints(start).optJSONArray("points") }.getOrNull()
            } else null

            var detailFile: String? = null
            var gain: Int? = null
            var name = w.optString("sportName", if (type == "bike") "Cycling" else "Huawei Watch Run")
            if (points != null && points.length() >= 2) {
                val gpx = watchPointsToGpx(points, name)
                val built = runCatching {
                    val parsed = TrackParsers.parse(gpx)
                    ActBuilder.build(parsed.pts, parsed.sport, parsed.name)
                }.getOrNull()
                if (built != null) {
                    name = (built["nm"] as? String)?.ifBlank { name } ?: name
                    gain = (built["gain"] as? Double)?.toInt()
                    val base = similarExisting
                    val mergedNote = mergeWatchNote(base?.note.orEmpty(), w)
                    val row = if (base != null) base.copy(
                        avgHr = base.avgHr ?: w.optInt("avgHr").takeIf { it in 30..230 },
                        maxHr = base.maxHr ?: w.optInt("maxHr").takeIf { it in 30..230 },
                        gain = base.gain ?: gain,
                        note = mergedNote,
                    ) else ActivityEntity(
                        dateIso = date, km = km, durationSec = duration,
                        avgHr = w.optInt("avgHr").takeIf { it in 30..230 },
                        maxHr = w.optInt("maxHr").takeIf { it in 30..230 },
                        gain = gain, startTime = time, name = name, type = type, srcKey = srcKey,
                        note = mergedNote,
                    )
                    val id = if (base != null) { a.db.activities().update(row); base.id } else a.db.activities().insert(row)
                    val file = ActStore.importFileName(id)
                    val payload = HashMap(built)
                    payload["watch"] = JSONObject(w.toString()).toString()
                    withContext(Dispatchers.IO) { a.acts.write(file, payload) }
                    a.db.activities().setDetail(id, file)
                    detailFile = file
                }
            }
            if (detailFile == null) {
                if (similarExisting != null) {
                    val merged = similarExisting.copy(
                        avgHr = similarExisting.avgHr ?: w.optInt("avgHr").takeIf { it in 30..230 },
                        maxHr = similarExisting.maxHr ?: w.optInt("maxHr").takeIf { it in 30..230 },
                        note = mergeWatchNote(similarExisting.note, w),
                    )
                    a.db.activities().update(merged)
                } else {
                    a.db.activities().insert(
                        ActivityEntity(
                            dateIso = date, km = km, durationSec = duration,
                            avgHr = w.optInt("avgHr").takeIf { it in 30..230 },
                            maxHr = w.optInt("maxHr").takeIf { it in 30..230 },
                            startTime = time, name = name, type = type, srcKey = srcKey,
                            note = watchWorkoutNote(w),
                        ),
                    )
                }
            }
            imported++
        }
        return dailyRows.size to imported
    }

    private fun mergeWatchNote(previous: String, w: JSONObject): String = JSONObject().apply {
        val old = previous.trim()
        if (old.isNotEmpty() && runCatching { JSONObject(old).optString("source") == "huawei-watch" }.getOrDefault(false)) {
            put("userNote", runCatching { JSONObject(old).optString("userNote") }.getOrDefault(""))
        } else if (old.isNotEmpty()) put("userNote", old)
        put("source", "huawei-watch")
        if (w.has("recoveryHours")) put("recoveryHours", w.optDouble("recoveryHours"))
        if (w.has("workoutLoad")) put("workoutLoad", w.optInt("workoutLoad"))
        if (w.has("aerobicEffect")) put("aerobicEffect", w.optDouble("aerobicEffect"))
        if (w.has("anaerobicEffect")) put("anaerobicEffect", w.optDouble("anaerobicEffect"))
        if (w.has("recoveryHr")) put("recoveryHr", w.optJSONArray("recoveryHr"))
    }.toString()

    private fun watchWorkoutNote(w: JSONObject): String = JSONObject().apply {
        put("source", "huawei-watch")
        if (w.has("recoveryHours")) put("recoveryHours", w.optDouble("recoveryHours"))
        if (w.has("workoutLoad")) put("workoutLoad", w.optInt("workoutLoad"))
        if (w.has("aerobicEffect")) put("aerobicEffect", w.optDouble("aerobicEffect"))
        if (w.has("anaerobicEffect")) put("anaerobicEffect", w.optDouble("anaerobicEffect"))
        if (w.has("recoveryHr")) put("recoveryHr", w.optJSONArray("recoveryHr"))
    }.toString()

    private fun watchPointsToGpx(points: JSONArray, title: String): ByteArray {
        val out = StringBuilder()
        out.append("""<?xml version="1.0" encoding="UTF-8"?><gpx version="1.1" creator="EnduranceVault" xmlns="http://www.topografix.com/GPX/1/1" xmlns:gpxtpx="http://www.garmin.com/xmlschemas/TrackPointExtension/v1"><trk><name>""")
        out.append(title.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))
        out.append("</name><trkseg>")
        for (i in 0 until points.length()) {
            val p = points.optJSONObject(i) ?: continue
            if (p.isNull("lat") || p.isNull("lon")) continue
            val lat = p.optDouble("lat", Double.NaN)
            val lon = p.optDouble("lon", Double.NaN)
            if (!lat.isFinite() || !lon.isFinite() || lat !in -90.0..90.0 || lon !in -180.0..180.0) continue
            out.append("<trkpt lat=\"").append(lat).append("\" lon=\"").append(lon).append("\">")
            if (!p.isNull("alt")) out.append("<ele>").append(p.optDouble("alt")).append("</ele>")
            val ts = p.optLong("ts", 0L)
            if (ts > 0) out.append("<time>").append(Instant.ofEpochSecond(ts).toString()).append("</time>")
            val hr = p.optInt("hr", 0)
            val cad = p.optInt("cad", 0)
            if (hr > 0 || cad > 0) {
                out.append("<extensions><gpxtpx:TrackPointExtension>")
                if (hr > 0) out.append("<gpxtpx:hr>").append(hr).append("</gpxtpx:hr>")
                if (cad > 0) out.append("<gpxtpx:cad>").append(cad).append("</gpxtpx:cad>")
                out.append("</gpxtpx:TrackPointExtension></extensions>")
            }
            out.append("</trkpt>")
        }
        out.append("</trkseg></trk></gpx>")
        return out.toString().toByteArray(Charsets.UTF_8)
    }

    fun clearTrackMsg() { trackMsg.value = null }

    /** Pilih gear (sepatu) untuk satu aktivitas dari layar detail; null = tanpa gear. */
    fun setActivityGear(id: Long, gearId: String?) {
        viewModelScope.launch(Dispatchers.IO) { a.db.activities().setGear(id, gearId) }
    }

    /** Baca detail (rute, split, grafik) satu aktivitas dari berkasnya. */
    suspend fun detailOf(e: ActivityEntity): ActDetail? = withContext(Dispatchers.IO) { e.detailFile?.let { a.acts.read(it) } }

    fun dismissImport() { importState.value = ImportUi.Idle }

    /* ---------- Cadangan lengkap (.zip) ---------- */

    fun backupFileName(): String = NativeBackup.fileName()

    /** Tulis seluruh data aplikasi ke berkas tujuan yang dipilih pengguna. */
    fun exportBackup(uri: Uri) {
        if (backupState.value is BackupUi.Working) return
        backupState.value = BackupUi.Working("Membuat cadangan…")
        viewModelScope.launch {
            backupState.value = try {
                val s = withContext(Dispatchers.IO) {
                    val out = a.contentResolver.openOutputStream(uri, "w") ?: throw BackupException("Berkas tujuan tidak bisa dibuka.")
                    try {
                        out.use { NativeBackup.export(a, it) }
                    } catch (t: Throwable) {
                        runCatching { android.provider.DocumentsContract.deleteDocument(a.contentResolver, uri) }
                        throw t
                    }
                }
                BackupUi.Done(
                    "Cadangan tersimpan (${"%.1f".format(Locale.US, s.sizeBytes / 1_048_576.0)} MB): ${s.activities} aktivitas " +
                        "(${s.activityDetails} dengan rute dan grafik), ${s.sleepSegments} segmen tidur, ${s.stepSamples} sampel langkah/HR, " +
                        "${s.daily} catatan harian, ${s.gear} gear, pengaturan, dan foto profil. " +
                        "Simpan berkasnya di luar ponsel (mis. Google Drive atau komputer).",
                    restored = false,
                )
            } catch (e: BackupException) {
                BackupUi.Failed(e.message ?: "Cadangan gagal dibuat.")
            } catch (e: Exception) {
                BackupUi.Failed("Cadangan gagal dibuat: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    /** Baca berkas cadangan (.zip) dan tampilkan ringkasannya sebelum data diganti. */
    fun startRestore(uri: Uri) {
        if (backupState.value is BackupUi.Working) return
        if (watchSyncing.value) { backupState.value = BackupUi.Failed("Sinkronisasi jam sedang berjalan. Coba lagi setelah selesai."); return }
        backupState.value = BackupUi.Working("Membaca cadangan…")
        viewModelScope.launch {
            val staging = File(a.cacheDir, "restore-staging")
            backupState.value = try {
                val summary = withContext(Dispatchers.IO) {
                    val ins = a.contentResolver.openInputStream(uri) ?: throw BackupException("Berkas tidak bisa dibuka.")
                    ins.use { NativeBackup.stage(it, staging) }
                }
                restoreStaging = staging
                BackupUi.Confirm(summary)
            } catch (e: BackupException) {
                staging.deleteRecursively()
                BackupUi.Failed(e.message ?: "Cadangan tidak bisa dibaca.")
            } catch (e: Exception) {
                staging.deleteRecursively()
                BackupUi.Failed("Gagal membaca berkas: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    fun confirmRestore() {
        val staging = restoreStaging ?: return
        if (backupState.value !is BackupUi.Confirm) return
        if (!watchSyncLock.compareAndSet(false, true)) {
            backupState.value = BackupUi.Failed("Sinkronisasi jam sedang berjalan. Coba lagi setelah selesai.")
            return
        }
        backupState.value = BackupUi.Working("Memulihkan data…")
        viewModelScope.launch {
            backupState.value = try {
                val msg = withContext(Dispatchers.IO) { NativeBackup.restore(a, staging) }
                reloadAfterRestore()
                BackupUi.Done(msg, restored = true)
            } catch (e: BackupException) {
                BackupUi.Failed(e.message ?: "Pemulihan gagal.")
            } catch (e: Exception) {
                BackupUi.Failed("Gagal memulihkan: ${e.message ?: e.javaClass.simpleName}. Data sebelumnya tersimpan di salinan pengaman (folder backups di penyimpanan aplikasi).")
            } finally {
                staging.deleteRecursively(); restoreStaging = null
                watchSyncLock.set(false)
            }
        }
    }

    fun dismissBackup() {
        if (backupState.value is BackupUi.Working) return
        restoreStaging?.deleteRecursively(); restoreStaging = null
        backupState.value = BackupUi.Idle
    }

    /** Muat ulang state yang dipegang ViewModel dari SharedPreferences hasil pemulihan. */
    private fun reloadAfterRestore() {
        settingsFlow.value = a.settings.load()
        weatherLat.value = weatherPrefs.getString("lat", null) ?: "-6.99"
        weatherLon.value = weatherPrefs.getString("lon", null) ?: "110.42"
        weatherPlace.value = weatherPrefs.getString("place", null) ?: "Ungaran, Indonesia"
        weatherPlaceLabel.value = weatherPlace.value
    }
}
