package com.endurancevault.app

import com.endurancevault.app.data.DailyEntity
import com.endurancevault.app.data.HuaweiWatchImport
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant
import java.time.ZoneOffset

class HuaweiWatchImportTest {
    private fun ts(value: String) = Instant.parse(value).epochSecond

    @Test fun importsDirectWatchRhrHrvAndSleepStages() {
        val payload = JSONObject().apply {
            put("days", org.json.JSONArray().put(JSONObject().put("day", "2026-11-05").put("rhrLast", 48)))
            put("sleep", org.json.JSONArray()
                .put(JSONObject().put("start", ts("2026-11-04T22:00:00Z")).put("end", ts("2026-11-04T23:30:00Z")).put("type", 0).put("stage", "deep"))
                .put(JSONObject().put("start", ts("2026-11-04T23:30:00Z")).put("end", ts("2026-11-05T01:00:00Z")).put("type", 0).put("stage", "rem"))
                .put(JSONObject().put("start", ts("2026-11-05T01:00:00Z")).put("end", ts("2026-11-05T01:10:00Z")).put("type", 0).put("stage", "awake"))
                .put(JSONObject().put("start", ts("2026-11-05T02:00:00Z")).put("end", ts("2026-11-05T02:30:00Z")).put("type", 0x5659).put("stage", "light")))
            put("hrv", org.json.JSONArray().put(JSONObject().put("start", ts("2026-11-04T22:00:00Z")).put("end", ts("2026-11-05T02:30:00Z")).put("rmssd", 52.4)))
        }
        val rows = HuaweiWatchImport.daily(payload, emptyList(), ZoneOffset.UTC)
        assertEquals(1, rows.size)
        val row = rows.single()
        assertEquals(48, row.rhr)
        assertEquals(52, row.hrv)
        assertEquals(3.0, row.sleepH!!, 0.001)
        val raw = JSONObject(row.raw)
        assertEquals(90, raw.getInt("deep"))
        assertEquals(90, raw.getInt("rem"))
        assertEquals(30, raw.getInt("nap"))
        assertEquals(1, raw.getInt("wkN"))
        assertEquals("huawei-watch", raw.getString("source"))
    }

    @Test fun manualDailyValuesAreNeverOverwritten() {
        val old = DailyEntity(
            dateIso = "2026-11-05",
            rhr = 55,
            hrv = 61,
            sleepH = 7.25,
            leg = 2,
            mood = 1,
            raw = """{"source":"manual","sleep":7.25}""",
        )
        val payload = JSONObject().put("days", org.json.JSONArray().put(JSONObject().put("day", "2026-11-05").put("rhrLast", 45)))
            .put("hrv", org.json.JSONArray().put(JSONObject().put("end", ts("2026-11-05T02:30:00Z")).put("rmssd", 40.0)))
        val row = HuaweiWatchImport.daily(payload, listOf(old), ZoneOffset.UTC).single()
        assertEquals(55, row.rhr)
        assertEquals(61, row.hrv)
        assertEquals(7.25, row.sleepH!!, 0.001)
        assertEquals(2, row.leg)
        assertEquals(1, row.mood)
        assertEquals(7.25, JSONObject(row.raw).getDouble("sleep"))
    }
    @Test fun importsSleepHeartRateFromDedicatedSleepWindowRows() {
        val payload = JSONObject()
            .put("sleepHr", org.json.JSONArray().put(JSONObject()
                .put("day", "2026-11-05").put("avg", 49.6).put("n", 35)))
        val row = HuaweiWatchImport.daily(payload, emptyList(), ZoneOffset.UTC).single()
        assertEquals(50, JSONObject(row.raw).getDouble("shr").toInt())
        assertEquals("watch-sync", JSONObject(row.raw).getString("huaweiHr_shr"))
    }

    @Test fun selectsLongestMainSleepPerWakeDateInsteadOfSummingFragments() {
        val payload = JSONObject().put("sleep", org.json.JSONArray()
            // Main night: 5h20m
            .put(JSONObject().put("start", ts("2026-11-04T22:00:00Z")).put("end", ts("2026-11-05T03:20:00Z")).put("type", 0).put("stage", "light"))
            // Separate early-evening fragment on same wake date; legacy keeps it out of main-night total.
            .put(JSONObject().put("start", ts("2026-11-04T18:00:00Z")).put("end", ts("2026-11-04T20:00:00Z")).put("type", 0).put("stage", "light")))
        val row = HuaweiWatchImport.daily(payload, emptyList(), ZoneOffset.UTC).single { it.dateIso == "2026-11-05" }
        assertEquals(5.333, row.sleepH!!, 0.02)
    }

    @Test fun dailyAverageRestingHrMatchesLegacyWatchMapping() {
        val payload = JSONObject().put("days", org.json.JSONArray().put(JSONObject()
            .put("day", "2026-11-05").put("rhrLast", 48).put("rhrAvg", 52.7).put("rhrN", 12)))
        val row = HuaweiWatchImport.daily(payload, emptyList(), ZoneOffset.UTC).single()
        assertEquals(52, row.rhr)
    }

}
