package com.endurancevault.app

import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.data.DailyEntity
import com.endurancevault.app.domain.Kinds
import com.endurancevault.app.domain.PDay
import com.endurancevault.app.domain.PWeek
import com.endurancevault.app.domain.Phases
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.domain.TrainingMetrics
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TrainingReadinessTest {
    private val today = LocalDate.of(2026, 11, 6)

    @Test fun sleepScoreIncludesNapAwakeningsAndSleepStages() {
        val daily = DailyEntity(
            dateIso = today.toString(),
            sleepH = 6.0,
            raw = """{"sleep":6,"nap":30,"wkN":2,"wks":[{"m":20,"g":false}],"deep":90,"rem":90,"light":180}"""
        )
        val result = TrainingMetrics.calculate(
            PlanSettings(), emptyList(), listOf(daily), PlanOutcome.Err("no plan"), today
        )
        val sleep = result.readiness!!.parts.first { it.key == "sl" }
        assertEquals(6.5, sleep.detail.substringBefore(" jam").toDouble(), 0.01)
        assertTrue(sleep.score!! in 60..70)
        assertTrue(sleep.detail.contains("2× terbangun"))
        assertTrue(sleep.detail.contains("20 menit terjaga"))
    }

    @Test fun readinessCanRecommendSwappingQualityWhenScoreIsLow() {
        val workout = PDay(today, 3, Kinds.QUALITY, "q", "Sesi kualitas", 10.0, "quality")
        val week = PWeek(0, today.minusDays(1), today.plusDays(5), Phases.BUILD, false, false, false, mutableListOf(workout), 35.0)
        val plan = PlanOutcome.Ok(listOf(week), today.minusDays(1), today.plusDays(60), 9, false, false, true, 0, 0)
        val daily = DailyEntity(today.toString(), leg = 5, mood = 5, sleepH = 4.0, raw = """{"sleep":4}""")
        val result = TrainingMetrics.calculate(PlanSettings(), emptyList(), listOf(daily), plan, today)
        assertNotNull(result.readiness)
        assertTrue(result.readiness!!.score < 50)
        assertNotNull(result.planAdjustment)
        assertEquals("swap", result.planAdjustment!!.action)
        assertTrue(result.planAdjustment!!.suggestedKm in 3.0..6.0)
    }

    @Test fun noAdjustmentWhenReadinessIsHighOrRestDay() {
        val rest = PDay(today, 3, Kinds.REST, "rest", "Istirahat", 0.0, "")
        val week = PWeek(0, today.minusDays(1), today.plusDays(5), Phases.BUILD, false, false, false, mutableListOf(rest), 30.0)
        val plan = PlanOutcome.Ok(listOf(week), today.minusDays(1), today.plusDays(60), 9, false, false, true, 0, 0)
        val daily = DailyEntity(today.toString(), leg = 1, mood = 1, sleepH = 8.0, raw = """{"sleep":8}""")
        val result = TrainingMetrics.calculate(PlanSettings(), emptyList(), listOf(daily), plan, today)
        assertNull(result.planAdjustment)
    }
    @Test fun manualReadinessWeightsChangeTheCompositeScore() {
        val daily = DailyEntity(today.toString(), leg = 5, mood = 1, sleepH = 8.0, raw = """{"sleep":8}""")
        val standard = TrainingMetrics.calculate(PlanSettings(), emptyList(), listOf(daily), PlanOutcome.Err("no plan"), today).readiness!!
        val weighted = TrainingMetrics.calculate(
            PlanSettings(), emptyList(), listOf(daily), PlanOutcome.Err("no plan"), today,
            readinessConfig = com.endurancevault.app.domain.ReadinessConfig(weights = mapOf("leg" to 50.0))
        ).readiness!!
        assertTrue(weighted.score < standard.score)
    }

    @Test fun customSleepNeedChangesSevenDayDebt() {
        val days = (0..2).map { offset ->
            val date = today.minusDays(offset.toLong())
            DailyEntity(date.toString(), sleepH = 6.0, raw = """{"sleep":6}""")
        }
        val standard = TrainingMetrics.calculate(PlanSettings(), emptyList(), days, PlanOutcome.Err("no plan"), today).readiness!!
        val custom = TrainingMetrics.calculate(PlanSettings(), emptyList(), days, PlanOutcome.Err("no plan"), today,
            readinessConfig = com.endurancevault.app.domain.ReadinessConfig(sleepNeedHours = 9.0)).readiness!!
        val standardDebt = standard.parts.first { it.key == "debt" }.score!!
        val customDebt = custom.parts.first { it.key == "debt" }.score!!
        assertTrue(customDebt < standardDebt)
    }

    @Test fun recentPainIsIncludedAndRecurringPainReducesScore() {
        val entries = listOf(
            com.endurancevault.app.domain.PainReadinessEntry(today, "Betis", 3),
            com.endurancevault.app.domain.PainReadinessEntry(today.minusDays(1), "Betis", 2),
            com.endurancevault.app.domain.PainReadinessEntry(today.minusDays(2), "Betis", 2),
        )
        val result = TrainingMetrics.calculate(PlanSettings(), emptyList(), emptyList(), PlanOutcome.Err("no plan"), today,
            readinessConfig = com.endurancevault.app.domain.ReadinessConfig(painEntries = entries)).readiness!!
        val pain = result.parts.first { it.key == "pain" }
        assertEquals(45, pain.score)
        assertTrue(pain.detail.contains("berulang"))
    }

    @Test fun readinessConfigKeepsThresholdOrderingValid() {
        val config = com.endurancevault.app.domain.ReadinessConfig(swapThreshold = 90, lightThreshold = 30, easyThreshold = 70).safe()
        assertTrue(config.swapThreshold in 20..80)
        assertTrue(config.lightThreshold > config.swapThreshold)
        assertTrue(config.easyThreshold <= config.swapThreshold)
    }

}
