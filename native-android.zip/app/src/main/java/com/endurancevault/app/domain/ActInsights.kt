package com.endurancevault.app.domain

import java.util.Locale
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Logika murni untuk layar detail aktivitas (port dari `08-kesesuaian-rute-serupa-detail.js`, `08e`, `08f`,
 * `08g`, `04` dan `15-training-load-te-kebugaran.js`). Tidak bergantung pada Android agar bisa dites JVM.
 */
object ActInsights {
    /** Satu butir hasil cek: [level] salah satu dari ok, warn, bad, info. */
    data class Check(val level: String, val text: String)

    data class Compliance(val items: List<Check>, val level: String, val label: String)

    data class TimeInfo(val moving: String, val elapsed: String?, val pause: String?)

    data class Drift(val pct: Double, val km: Double)

    /** Statistik recovery heart rate 2 menit setelah latihan. */
    class RecHr(val values: List<Int>, val base: Int, val h1: Int?, val h2: Int, val d1: Int?, val d2: Int?, val stepSec: Double) {
        /** HR terinterpolasi pada detik [t] (0..120). */
        fun at(t: Double): Double {
            val n = values.size
            if (n < 2) return values[0].toDouble()
            val f = (t / stepSec).coerceIn(0.0, (n - 1).toDouble())
            val i = floor(f).toInt(); val k = min(n - 1, i + 1)
            return values[i] + (values[k] - values[i]) * (f - i)
        }
    }

    // ---------- format ----------

    /** Angka desimal dengan koma (padanan DS() di web). */
    fun dec(x: Double, digits: Int = 1): String = String.format(Locale.ROOT, "%.${digits}f", x).replace('.', ',')

    fun mmss(minutes: Double): String {
        val s = Js.roundI(abs(minutes) * 60)
        return "${s / 60}:${Js.pad(s % 60)}"
    }

    fun teLabel(v: Double): String = when {
        v >= 4.8 -> "Overreaching"; v >= 4.0 -> "Sangat meningkatkan"; v >= 3.0 -> "Meningkatkan"
        v >= 2.0 -> "Mempertahankan"; v >= 1.0 -> "Efek ringan"; else -> "Tanpa efek"
    }

    fun recoveryDuration(hours: Double): String =
        if (hours >= 48) dec(Js.round(hours / 24 * 10) / 10) + " hari" else "${Js.roundI(hours)} jam"

    private val WEATHER = mapOf(
        0 to "Cerah", 1 to "Cerah berawan", 2 to "Berawan sebagian", 3 to "Mendung", 45 to "Berkabut", 48 to "Berkabut",
        51 to "Gerimis ringan", 53 to "Gerimis", 55 to "Gerimis lebat", 56 to "Gerimis beku", 57 to "Gerimis beku",
        61 to "Hujan ringan", 63 to "Hujan", 65 to "Hujan lebat", 66 to "Hujan beku", 67 to "Hujan beku",
        71 to "Salju ringan", 73 to "Salju", 75 to "Salju lebat", 77 to "Butiran salju",
        80 to "Hujan sesaat", 81 to "Hujan sesaat", 82 to "Hujan sesaat lebat", 85 to "Salju sesaat", 86 to "Salju sesaat",
        95 to "Badai petir", 96 to "Badai petir, es", 99 to "Badai petir, es",
    )

    fun weatherLabel(code: Int?): String? = code?.let { WEATHER[it] }

    // ---------- waktu, langkah, tanjakan ----------

    /** Waktu gerak (bawaan) dan waktu total; waktu total hanya ada bila selisihnya sedikitnya 10 detik. */
    fun timeInfo(movingMin: Double, elapsedMin: Double): TimeInfo {
        val mv = if (movingMin.isFinite()) max(0.0, movingMin) else 0.0
        val el = if (elapsedMin > 0) max(elapsedMin, mv) else 0.0
        val d = el - mv
        val differs = mv > 0 && d >= 1.0 / 6
        return TimeInfo(Js.durStr(mv), if (differs) Js.durStr(el) else null, if (differs) Js.durStr(d) else null)
    }

    /** Panjang langkah (m) dari jarak, waktu gerak, dan kadens rata-rata; null bila tidak masuk akal. */
    fun strideLength(km: Double, movingMin: Double, cadence: Int?): Double? {
        if (cadence == null || cadence <= 0 || km <= 0 || movingMin <= 0) return null
        val m = km * 1000 / movingMin / cadence
        return if (m in 0.3..2.5) m else null
    }

    fun strideOfSplit(s: Split): Double? {
        val c = s.cad ?: return null
        if (c <= 0 || s.pace <= 0) return null
        val m = 1000 / s.pace / c
        return if (m in 0.3..2.5) m else null
    }

    /** Vertical speed: nilai file bila ada, jika tidak dari D+ / waktu (tanjakan sedikitnya 10 m dan 2 menit). */
    /** Rasio ekuivalen usaha: 100 m naik setara 1 km datar. Vertical speed baru relevan bila tanjakan ≥ 15% jarak. */
    const val VERT_MIN_EQUIV_RATIO = 0.15

    /** True bila gain/100 (km ekuivalen) melebihi 15% jarak; mis. 10 km → gain di atas 150 m. */
    fun showVerticalSpeed(gain: Int?, km: Double): Boolean =
        gain != null && km > 0 && gain / 100.0 > VERT_MIN_EQUIV_RATIO * km

    fun verticalSpeed(vam: ActVam?, gain: Int?, movingMin: Double): ActVam? {
        if (vam != null && vam.avg > 0) return vam
        if (gain != null && gain >= 10 && movingMin >= 2) return ActVam(Js.roundI(gain / movingMin * 60))
        return null
    }

    // ---------- pace, GAP, split ----------

    /** Biaya energi Minetti (J/kg/m) pada kemiringan [g] (pecahan, dijepit -0,45..0,45). */
    fun minettiCost(g0: Double): Double {
        val g = g0.coerceIn(-0.45, 0.45)
        return 155.4 * g.pow(5) - 30.4 * g.pow(4) - 43.3 * g.pow(3) + 46.3 * g * g + 19.5 * g + 3.6
    }

    fun splitKm(s: Split): Double {
        val d = if (s.partial) s.k - floor(s.k) else 1.0
        return if (d > .15) d else 1.0
    }

    /** GAP satu split: nilai file bila ada, jika tidak diperkirakan dari tanjakan dan turunannya. */
    fun gapOfSplit(s: Split, hasGain: Boolean): Double? {
        s.gap?.takeIf { it > 0 }?.let { return it }
        if (!hasGain || s.pace <= 0) return null
        val gr = (s.gain - s.loss) / (splitKm(s) * 1000)
        val f = minettiCost(gr) / 3.6
        return if (f > 0) s.pace / f else null
    }

    /**
     * GAP satu segmen (menit/km) diperkirakan dari pace dan kemiringan bersih (gain - loss) per jarak, rumus Minetti yang sama
     * dengan [gapOfSplit]. Null bila segmen terlalu pendek (< 50 m), tanpa pace, atau tanpa data elevasi ([hasGain] false).
     */
    fun gapOfSegment(s: Segment, hasGain: Boolean): Double? {
        if (!hasGain || s.pace <= 0 || s.d < 0.05) return null
        val f = minettiCost((s.gain - s.loss) / (s.d * 1000)) / 3.6
        return if (f > 0) s.pace / f else null
    }

    /** GAP seluruh aktivitas (menit/km), bukan untuk sepeda. */
    fun gapOfActivity(gapPace: Double?, splits: List<Split>, hasGain: Boolean, bike: Boolean): Double? {
        if (bike) return null
        if (gapPace != null && gapPace > 0) return gapPace
        if (!hasGain || splits.isEmpty()) return null
        var tt = 0.0; var te = 0.0
        splits.forEach { s ->
            val g = gapOfSplit(s, true) ?: return@forEach
            if (s.pace <= 0) return@forEach
            val t = s.pace * splitKm(s)
            tt += t; te += t / g
        }
        return if (te > 0) tt / te else null
    }

    /** Km tercepat; km parsial di bawah 0,5 km tidak dihitung agar potongan akhir tidak jadi juara palsu. */
    fun fastestKm(splits: List<Split>, bike: Boolean): Split? {
        if (bike) return null
        var f: Split? = null
        splits.forEach { s -> if (s.pace > 0 && splitKm(s) >= .5 && (f == null || s.pace < f!!.pace)) f = s }
        return f
    }

    /** Segmen tercepat berdasarkan pace; segmen di bawah 100 m diabaikan. */
    fun fastestSegment(segments: List<Segment>, bike: Boolean): Segment? {
        if (bike || segments.size < 2) return null
        return segments.filter { it.d >= 0.1 && it.pace > 0 }.minByOrNull { it.pace }
    }

    /** Efisiensi pace-per-detak paruh akhir dibanding paruh awal (setelah pemanasan); null bila data kurang. */
    fun drift(splits: List<Split>, km: Double, bike: Boolean, skip: Boolean): Drift? {
        if (bike || skip || splits.size < 9) return null
        val sp = splits.toMutableList()
        if (sp.size > 1 && sp[sp.size - 1].k - sp[sp.size - 2].k < .9) sp.removeAt(sp.size - 1)
        val n = sp.size
        if (n < 8) return null
        val ef = sp.map { x ->
            val h = x.hr
            if (x.pace <= 0 || h == null || h <= 60) null
            else {
                val c = minettiCost((x.gain - x.loss) / 1000.0)
                if (c <= 0) null else (1 / x.pace * c / 3.6) / h * 1000
            }
        }
        val st = max(1, Js.roundI(n * .1)); val mid = st + (n - st) / 2
        val a = ArrayList<Double>(); val b = ArrayList<Double>()
        for (i in st until n) { val e = ef[i] ?: continue; if (i < mid) a.add(e) else b.add(e) }
        if (a.size < 3 || b.size < 3) return null
        val e1 = a.average(); val e2 = b.average()
        return Drift(Js.round((e1 - e2) / e1 * 1000) / 10.0, if (km > 0) km else sp[n - 1].k)
    }

    // ---------- kepatuhan terhadap rencana ----------

    private val EASY_LIKE = setOf("easy", "short", "medium", "long", "sub")

    private fun minInBand(h: Map<Int, Double>, lo: Int, hi: Int): Double = h.entries.filter { it.key in lo..hi }.sumOf { it.value } / 60

    /**
     * Cek hasil lari terhadap hari rencananya. [easyCap] = batas HR easy (Z3 − 1 bpm).
     * Null untuk sepeda, hari libur, atau bila tidak ada rencana pada tanggal itu.
     */
    fun compliance(day: PDay?, km: Double, avgHr: Int?, hist: Map<Int, Double>, gain: Int?, easyCap: Int, bike: Boolean): Compliance? {
        if (day == null || bike || km <= 0 || day.kind == "rest") return null
        val items = ArrayList<Check>()
        fun add(l: String, t: String) { items.add(Check(l, t)) }
        val total = hist.values.sum()
        val hasH = total > 60
        if (day.km > 0 && day.kind != "race") {
            val r = km / day.km
            add(
                if (r in .9..1.12) "ok" else if (r in .75..1.3) "warn" else "bad",
                "Jarak ${Js.fmtKm(km)} km dari target ${Js.fmtKm(day.km)} km" + (if (r < .9) " (kurang)" else if (r > 1.12) " (lebih)" else "") + ".",
            )
        }
        val dayGain = day.gain
        if (dayGain != null && dayGain >= 100 && gain != null) {
            val r = gain.toDouble() / dayGain
            add(if (r >= .8) "ok" else if (r >= .55) "warn" else "bad", "Tanjakan ${Js.idn(gain)} m dari rencana ${Js.idn(dayGain)} m" + (if (r < .8) " (kurang)" else "") + ".")
        }
        val steep = dayGain != null && day.km > 0 && dayGain / day.km > 30
        if (day.kind in EASY_LIKE) {
            if (hasH) {
                val up = hist.entries.filter { it.key > easyCap }.sumOf { it.value }
                val pc = up / total
                val okT = if (steep) .12 else .08; val wT = if (steep) .3 else .2
                add(
                    if (pc <= okT) "ok" else if (pc <= wT) "warn" else "bad",
                    "HR rata-rata ${avgHr ?: "–"}, ${Js.roundI(pc * 100)}% waktu di atas batas easy $easyCap" + (if (pc > okT) ". Pelankan atau jalan di tanjakan." else "."),
                )
            } else if (avgHr != null && avgHr > 0) {
                add(if (avgHr <= easyCap) "ok" else if (avgHr <= easyCap + 5) "warn" else "bad", "HR rata-rata $avgHr (batas easy $easyCap). Impor aktivitas untuk melihat sebaran HR.")
            }
        }
        val qk = day.qk; val qMin = day.qMin; val qBand = day.qBand
        if (qk != null && qk != "none" && qMin != null && qMin > 0) {
            if (qk == "hike") add("info", "Mendaki panjang: kesesuaian dilihat dari tanjakan dan durasi.")
            else if (qBand != null && qBand.size >= 2 && hasH) {
                val lo = qBand[0]; val hi = qBand[1]
                val tol = if (qk == "thr" || qk == "rp") 3 else 0
                val mn = minInBand(hist, lo - tol, hi + tol)
                val need = if (qk == "vo2") .35 else .5
                val f = mn / qMin
                val nm = when (qk) { "vo2" -> "zona VO2max (≥ $lo)"; "rp" -> "zona HR pace lomba ($lo–$hi)"; else -> "zona threshold ($lo–$hi)" }
                add(
                    if (f >= need) "ok" else if (f >= need * .6) "warn" else "bad",
                    "${Js.roundI(mn)} mnt di $nm dari target sekitar ${Js.roundI(qMin)} mnt" +
                        (if (f < need) (if (qk == "vo2") ". Usaha interval kurang keras atau terlalu pendek." else ". HR jarang mencapai zona, tambah usaha di bagian utama.") else "."),
                )
                if (qk == "thr" && hi + 8 < 999) {
                    val over = minInBand(hist, hi + 8, 999)
                    if (over >= max(3.0, qMin * .25)) add("warn", "Sekitar ${Js.roundI(over)} mnt HR jauh di atas zona threshold, terlalu keras.")
                }
            } else if (qBand != null) add("info", "Impor aktivitas (GPX/TCX/FIT) untuk memeriksa zona HR sesi ini.")
        } else if (day.kind == "quality" && qk == "none") add("info", "Sesi singkat (strides atau fartlek): HR tidak diperiksa.")
        var lv = "ok"
        items.forEach { if (it.level == "bad") lv = "bad" else if (it.level == "warn" && lv != "bad") lv = "warn" }
        val label = when (lv) { "ok" -> "Sesuai rencana"; "warn" -> "Sebagian sesuai rencana"; else -> "Perlu perhatian" }
        return Compliance(items, lv, label)
    }

    // ---------- komentar otomatis ----------

    class CommentInput(
        val km: Double, val movingMin: Double, val avgHr: Int?, val lthr: Int,
        val dayKind: String?, val dayBench: Boolean,
        val splits: List<Split>, val gain: Int?, val gapPace: Double?, val bike: Boolean,
        /** Load sesi ini (skala aplikasi), rata-rata load sesi lari sebelumnya, dan jumlah sesi pembanding. */
        val sessionLoad: Double?, val previousAvgLoad: Double?, val previousCount: Int,
        val aerobicEffect: Double?,
        /** Repetisi terdeteksi ([IntervalAnalysis.analyze]) dan HR bagian kerja; null bila bukan sesi terstruktur. */
        val interval: IvResult? = null, val workHr: Int? = null,
        /** Cuaca saat sesi (suhu terasa °C dan kelembapan %) untuk konteks panas. */
        val feelsLikeC: Double? = null, val humidityPct: Int? = null,
    )

    private fun intensityLabel(r: Double): String =
        if (r < .8) "sangat ringan" else if (r < .88) "aerobik ringan" else if (r < .95) "sedang" else if (r < 1.02) "sekitar threshold" else "di atas threshold"

    /** Sesi terstruktur bila ada minimal 3 repetisi dari lap/segmen (dari kurva pace perlu 4, karena perkiraan kasar). */
    fun isStructured(iv: IvResult?): Boolean = iv != null && iv.reps.size >= 3 && (iv.src != "kurva" || iv.reps.size >= 4)

    fun comments(c: CommentInput): List<Check> {
        if (c.bike || c.km <= 0) return emptyList()
        val out = ArrayList<Check>()
        val easy = c.dayKind in EASY_LIKE
        val iv = c.interval
        val structured = isStructured(iv)
        val hot = (c.feelsLikeC ?: 0.0) >= 29.0
        // 1. Intensitas
        val hr = c.avgHr
        val wHr = c.workHr
        if (structured && wHr != null && wHr > 0 && c.lthr > 0) {
            // Sesi interval: nilai usaha dari bagian kerja; rata-rata seluruh sesi ikut menghitung pemanasan dan jeda.
            val wr = wHr.toDouble() / c.lthr
            val txt = "Segmen kerja (${iv!!.reps.size} repetisi): HR rata-rata $wHr bpm (${Js.roundI(wr * 100)}% dari LTHR), usaha ${intensityLabel(wr)}." +
                (if (hr != null && hr > 0) " Rata-rata seluruh sesi $hr bpm sudah termasuk pemanasan dan jeda." else "")
            out += when {
                easy -> Check("warn", "$txt Rencana hari ini easy, tetapi ada repetisi cepat; pastikan itu disengaja.")
                wr < .88 -> Check("info", "$txt Usaha kerja masih ringan untuk interval; naikkan bila tujuannya threshold atau VO2max.")
                else -> Check("ok", txt)
            }
        } else if (hr != null && hr > 0 && c.lthr > 0) {
            val r = hr.toDouble() / c.lthr
            val lbl = intensityLabel(r)
            val txt = "HR rata-rata $hr bpm (${Js.roundI(r * 100)}% dari LTHR), intensitas $lbl."
            out += when {
                easy && r >= .92 -> Check("warn", "$txt Untuk sesi easy ini terlalu tinggi; kurangi usaha atau jalan di tanjakan." + (if (hot) " Panas (terasa ${Js.roundI(c.feelsLikeC!!)}°C) ikut menaikkan HR." else ""))
                easy -> Check("ok", "$txt Cocok untuk sesi easy.")
                c.dayKind == "quality" && r < .85 -> Check("info", "$txt Rata-rata sesi kualitas ikut menghitung pemanasan dan jogging, jadi angka ini wajar rendah.")
                else -> Check("info", txt)
            }
        }
        // 2. Pace dan GAP
        if (c.movingMin > 0) {
            val p = c.movingMin / c.km
            val gp = gapOfActivity(c.gapPace, c.splits, c.gain != null, false)
            val sb = StringBuilder("Pace rata-rata ${mmss(p)}/km")
            if (gp != null && gp > 0) {
                val d = (p - gp) * 60
                sb.append(", GAP ${mmss(gp)}/km")
                if (d >= 8) sb.append(" · tanjakan menambah sekitar ${Js.roundI(d)} dtk/km. Usahamu lebih keras dari pace yang terlihat.")
                else if (d <= -8) sb.append(" · turunan membantu sekitar ${Js.roundI(-d)} dtk/km.")
                else sb.append(" · rute relatif datar.")
            }
            val fk = fastestKm(c.splits, false)
            if (fk != null && (p - fk.pace) * 60 >= 15 && !easy && !structured) {
                sb.append(" Km tercepat ${if (fk.partial) Js.fmtKm(fk.k) else fk.k.toInt().toString()} di ${mmss(fk.pace)}/km.")
            }
            out += Check("info", sb.toString())
        }
        // 2b. Repetisi interval: konsistensi pace, fade, dan HR antar repetisi
        if (structured) {
            val reps = iv!!.reps; val st = iv.stats
            val meanTm = reps.map { it.tm }.average(); val meanD = reps.map { it.d }.average()
            val head = "${reps.size} repetisi × ${mmss(meanTm)} (±${dec(meanD, 2)} km), pace rata-rata ${mmss(st.avg)}/km."
            val fade = st.fade; val spread = st.spread
            val hrUp = st.hrFirst != null && st.hrLast != null && st.hrLast - st.hrFirst >= 8
            val (lvl, tail) = when {
                fade >= 8 -> "warn" to " Melambat sekitar ${Js.roundI(fade)} dtk/km dari repetisi pertama ke terakhir: mulai terlalu cepat atau kelelahan."
                fade <= -6 -> "ok" to " Makin cepat sekitar ${Js.roundI(-fade)} dtk/km sepanjang repetisi: kontrol usaha yang bagus."
                spread <= 8 -> "ok" to " Sangat konsisten (selisih terbaik dan terburuk ${Js.roundI(spread)} dtk/km)."
                spread <= 15 -> "info" to " Cukup konsisten (selisih terbaik dan terburuk ${Js.roundI(spread)} dtk/km)."
                else -> "warn" to " Pace antar repetisi bervariasi (selisih ${Js.roundI(spread)} dtk/km); coba tahan usaha lebih rata."
            }
            val hrNote = if (hrUp) " HR naik dari ${st.hrFirst} ke ${st.hrLast} bpm pada pace yang mirip, tanda kelelahan atau panas yang menumpuk." else ""
            out += Check(if (hrUp && lvl == "ok") "info" else lvl, head + tail + hrNote)
        }
        // 2c. Konteks panas: HR dan pace tidak adil dibandingkan dengan hari sejuk
        if (hot) {
            val h = c.humidityPct
            out += Check(
                if ((c.feelsLikeC ?: 0.0) >= 33) "warn" else "info",
                "Suhu terasa ${Js.roundI(c.feelsLikeC!!)}°C" + (if (h != null && h >= 75) " dan lembap $h%" else "") +
                    ". HR cenderung lebih tinggi dan pace lebih lambat dari biasa; bandingkan dengan sesi bersuhu serupa, bukan hanya angka pace.",
            )
        }
        // 3. Konsistensi (tidak dinilai untuk interval/benchmark; interval sudah dinilai per repetisi di atas)
        if (c.dayKind != "quality" && !c.dayBench && !structured) {
            val sp = c.splits.filter { it.pace > 0 && !it.partial }
            if (sp.size >= 6) {
                val v = sp.map { s -> gapOfSplit(s, c.gain != null)?.takeIf { it > 0 } ?: s.pace }
                val h = v.size / 2
                val m1 = v.take(h).average(); val m2 = v.takeLast(h).average()
                val ch = (m2 - m1) / m1
                val mean = v.average()
                val sd = sqrt(v.map { (it - mean) * (it - mean) }.average())
                val cv = if (mean > 0) sd / mean else 0.0
                var txt = when {
                    ch >= .05 -> "Paruh kedua melambat ${Js.roundI(ch * 100)}% (setelah menyesuaikan tanjakan). Tanda mulai terlalu cepat atau kelelahan."
                    ch <= -.03 -> "Negative split: paruh kedua lebih cepat ${Js.roundI(-ch * 100)}%." + (if (easy) " Pastikan HR tetap di batas easy." else "")
                    else -> "Pace stabil dari awal sampai akhir."
                }
                if (cv >= .08 && easy) txt += " Variasi pace antar km cukup besar (${Js.roundI(cv * 100)}%); jaga usaha lebih rata."
                out += Check(if (ch >= .05) "warn" else "ok", txt)
                val dr = drift(c.splits, c.km, false, c.dayKind in setOf("quality", "sub", "race", "event"))
                if (dr != null) {
                    out += when {
                        dr.pct >= 5 -> Check("warn", "Efisiensi turun ${dec(dr.pct)}% di paruh akhir (HR naik pada pace setara). Bisa karena panas, dehidrasi, kurang tidur, atau nutrisi.")
                        dr.pct <= 2 -> Check("ok", "HR drift kecil (${dec(dr.pct)}%): basis aerobik terlihat kuat.")
                        else -> Check("info", "HR drift ${dec(dr.pct)}%: wajar untuk lari panjang.")
                    }
                }
            }
        }
        // 4. Beban dan pemulihan
        val load = c.sessionLoad
        if (load != null && load > 0) {
            val ratio = if (c.previousAvgLoad != null && c.previousCount >= 3 && c.previousAvgLoad > 0) load / c.previousAvgLoad else 0.0
            val sb = StringBuilder("Load sesi ${Js.roundI(load)}")
            val te = c.aerobicEffect
            if (te != null && te > 0) sb.append(", TE ${dec(te)} (${teLabel(te)})")
            sb.append('.')
            var lvl = "info"
            if (ratio > 0) sb.append(" Sekitar ${dec(Js.round(ratio * 10) / 10)}× rata-rata ${c.previousCount} sesi terakhir.")
            if ((te != null && te >= 4) || ratio >= 1.6) {
                lvl = "warn"; sb.append(" Sesi berat: beri 1–2 hari easy atau libur sebelum sesi kualitas berikutnya.")
            } else if (ratio > 0 && ratio <= .6) sb.append(" Ringan; tidak perlu pemulihan ekstra.")
            else if (ratio > 0) sb.append(" Dosis normal untuk polamu.")
            out += Check(lvl, sb.toString())
        }
        return out
    }

    // ---------- recovery heart rate ----------

    /**
     * Jam Huawei mengukur recovery heart rate 2 menit setelah latihan; nilainya dibagi rata sepanjang 2 menit
     * (nilai pertama = detik 0 = HR akhir). Jam tidak mencantumkan jarak antar nilai, jadi ini asumsi.
     */
    fun recoveryHr(raw: List<Int>, endHr: Int? = null): RecHr? {
        val v = raw.filter { it > 0 }
        val n = v.size
        if (n == 0) return null
        val step = if (n > 1) 120.0 / (n - 1) else 0.0
        val base = endHr?.takeIf { it > 0 } ?: v[0]
        val st = RecHr(v, base, null, v[n - 1], null, null, step)
        val h1 = if (n > 1) Js.roundI(st.at(60.0)) else null
        return RecHr(v, base, h1, v[n - 1], if (h1 != null) base - h1 else null, if (n > 1) base - v[n - 1] else null, step)
    }

    // ---------- grafik sesi ----------

    enum class SeriesKey(val label: String, val color: Long, val minSpan: Double) {
        HR("Heart rate", 0xFFE7587A, 30.0), CAD("Kadens", 0xFFE0A41B, 40.0), ELEV("Elevasi", 0xFF22B5C0, 20.0),
        PACE("Pace", 0xFF5B7BD0, 1.5), VERT("Vert. speed", 0xFF8B6BD6, 300.0),
    }

    class ChartSeries(val key: SeriesKey, val points: List<Pair<Double, Double>>) {
        val lo: Double
        val hi: Double
        init {
            var l = points.minOf { it.second }; var h = points.maxOf { it.second }
            val span = key.minSpan
            if (h - l < span) { val mid = (h + l) / 2; l = mid - span / 2; h = mid + span / 2 }
            lo = l; hi = h
        }

        /** Nilai terinterpolasi pada [x]. */
        fun at(x: Double): Double {
            val p = points
            if (x <= p.first().first) return p.first().second
            if (x >= p.last().first) return p.last().second
            var a = 0; var b = p.size - 1
            while (b - a > 1) { val m = (a + b) ushr 1; if (p[m].first <= x) a = m else b = m }
            val dx = p[b].first - p[a].first
            return if (dx <= 0) p[a].second else p[a].second + (x - p[a].first) * (p[b].second - p[a].second) / dx
        }
    }

    /** [xIsTime]: sumbu x dalam detik (data 1 Hz); jika tidak, dalam km. */
    class ChartModel(val xIsTime: Boolean, val xMax: Double, val series: List<ChartSeries>) {
        fun get(key: SeriesKey): ChartSeries? = series.firstOrNull { it.key == key }
    }

    /** Rata-ratakan menjadi paling banyak [max] titik agar grafik ringan digambar. */
    fun downsample(pts: List<Pair<Double, Double>>, max: Int = 480): List<Pair<Double, Double>> {
        if (pts.size <= max) return pts
        val out = ArrayList<Pair<Double, Double>>(max)
        val step = pts.size.toDouble() / max
        for (b in 0 until max) {
            val from = (b * step).toInt(); val to = min(pts.size, ((b + 1) * step).toInt().coerceAtLeast(from + 1))
            var sx = 0.0; var sy = 0.0
            for (i in from until to) { sx += pts[i].first; sy += pts[i].second }
            val n = (to - from).toDouble()
            out.add(sx / n to sy / n)
        }
        return out
    }

    /**
     * Susun deret grafik dari detail aktivitas. Data 1 Hz dipakai bila ada (sumbu waktu); jika tidak,
     * deret ringkas per jarak. Pace dari data 1 Hz dihitung pada jendela 15 detik.
     */
    fun chartModel(d: ActDetail): ChartModel? {
        val ts = d.timeSeries
        val list = ArrayList<ChartSeries>()
        if (ts != null && ts.seconds.size >= 2) {
            val n = ts.seconds.size
            val sec = ts.seconds.map { it.toDouble() }
            fun mk(key: SeriesKey, pts: List<Pair<Double, Double>>) { if (pts.size >= 2) list.add(ChartSeries(key, downsample(pts))) }
            mk(SeriesKey.HR, (0 until n).filter { ts.heartRateBpm[it] > 0 }.map { sec[it] to ts.heartRateBpm[it].toDouble() })
            mk(SeriesKey.CAD, (0 until n).filter { ts.cadenceSpm[it] > 0 }.map { sec[it] to ts.cadenceSpm[it].toDouble() })
            mk(SeriesKey.ELEV, (0 until n).mapNotNull { i -> ts.elevationMeters[i]?.let { sec[i] to it } })
            if (!d.bike) {
                val pace = ArrayList<Pair<Double, Double>>()
                var j = 0
                for (i in 0 until n) {
                    while (j < i && sec[i] - sec[j] > 15) j++
                    val dt = sec[i] - sec[j]; val dd = ts.distanceMeters[i] - ts.distanceMeters[j]
                    if (dt >= 5 && dd >= 5) { val p = dt / 60 / (dd / 1000); if (p in 2.0..20.0) pace.add(sec[i] to p) }
                }
                mk(SeriesKey.PACE, pace)
            }
            val vert = ArrayList<Pair<Double, Double>>()
            var k = 0
            for (i in 0 until n) {
                val ei = ts.elevationMeters[i] ?: continue
                while (k < i && sec[i] - sec[k] > 60) k++
                val ek = ts.elevationMeters[k] ?: continue
                val dt = sec[i] - sec[k]
                if (dt >= 30) vert.add(sec[i] to ((ei - ek) / dt * 3600).coerceIn(-3000.0, 3000.0))
            }
            mk(SeriesKey.VERT, vert)
            if (list.isEmpty()) return null
            return ChartModel(true, sec.last(), list)
        }
        fun fallback(key: SeriesKey, pts: List<Pair<Double, Double>>) { if (pts.size >= 2) list.add(ChartSeries(key, pts)) }
        fallback(SeriesKey.HR, d.hrSeries.ifEmpty { d.splits.filter { (it.hr ?: 0) > 0 }.map { it.k to it.hr!!.toDouble() } })
        fallback(SeriesKey.CAD, d.cadSeries)
        fallback(SeriesKey.ELEV, d.profile)
        fallback(SeriesKey.PACE, if (d.bike) emptyList() else d.paceSeries.ifEmpty { d.splits.map { it.k to it.pace } })
        fallback(SeriesKey.VERT, d.vertSpeedSeries)
        if (list.isEmpty()) return null
        val xMax = list.maxOf { it.points.last().first }.takeIf { it > 0 } ?: return null
        return ChartModel(false, xMax, list)
    }

    fun clock(seconds: Double): String {
        val t = Js.roundI(seconds); val h = t / 3600; val m = (t % 3600) / 60; val s = t % 60
        return if (h > 0) "$h:${Js.pad(m)}:${Js.pad(s)}" else "${Js.pad(m)}:${Js.pad(s)}"
    }
}
