package com.endurancevault.app.domain

import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

/**
 * Aksi yang boleh diusulkan AI Coach untuk mengubah data aplikasi. Coach tidak pernah menulis data sendiri: model hanya
 * mengembalikan "tool call", lalu [CoachActions.parse] memvalidasinya menjadi [CoachAction] dan pengguna harus menyetujui
 * lewat kartu konfirmasi sebelum ViewModel mengeksekusinya. Murni Kotlin (tanpa Android) agar bisa diuji unit.
 */
sealed interface CoachAction {
    /** Kalimat ringkas untuk kartu konfirmasi. */
    val summary: String
    /** Aksi yang menghapus data; kartunya ditandai berbeda. */
    val destructive: Boolean get() = false

    data class AddActivity(
        val dateIso: String, val km: Double, val durationSec: Int, val type: String = "run",
        val name: String = "", val avgHr: Int? = null, val maxHr: Int? = null, val gain: Int? = null,
        val startTime: String? = null, val feel10: Int? = null, val note: String = "",
    ) : CoachAction {
        override val summary: String get() = buildString {
            append("Tambah ${if (type == "bike") "sepeda" else "lari"} $dateIso: ${CoachActions.fmt(km)} km, ${durationSec / 60} mnt")
            if (name.isNotBlank()) append(" \"$name\"")
            avgHr?.let { append(", HR rata-rata $it") }
        }
    }

    /** Ubah nama/catatan/tanggal/jam/tipe aktivitas yang ada; field null dibiarkan. */
    data class EditActivity(
        val id: Long, val name: String? = null, val description: String? = null,
        val dateIso: String? = null, val startTime: String? = null, val type: String? = null,
    ) : CoachAction {
        override val summary: String get() = "Ubah aktivitas #$id" + listOfNotNull(
            name?.let { "nama \"$it\"" }, description?.let { "catatan" }, dateIso?.let { "tanggal $it" },
            startTime?.let { "jam $it" }, type?.let { "tipe $it" },
        ).takeIf { it.isNotEmpty() }?.joinToString(", ", prefix = ": ").orEmpty()
    }

    data class SetActivityFeel(val id: Long, val feel10: Int?) : CoachAction {
        override val summary: String get() = if (feel10 == null) "Hapus rasa setelah lari pada aktivitas #$id" else "Set rasa setelah lari aktivitas #$id: $feel10/10"
    }

    data class DeleteActivity(val id: Long) : CoachAction {
        override val summary: String get() = "Hapus aktivitas #$id (rute dan grafiknya ikut terhapus)"
        override val destructive: Boolean get() = true
    }

    /** Catatan harian; hanya field yang diisi yang menimpa nilai lama. */
    data class SaveDaily(
        val dateIso: String, val sleepH: Double? = null, val rhr: Int? = null, val hrv: Int? = null,
        val leg: Int? = null, val mood: Int? = null,
    ) : CoachAction {
        override val summary: String get() = "Catat kondisi $dateIso: " + listOfNotNull(
            sleepH?.let { "tidur ${CoachActions.fmt(it)} jam" }, rhr?.let { "HR istirahat $it" }, hrv?.let { "HRV $it" },
            leg?.let { "kaki $it/5" }, mood?.let { "mood/stres $it/5" },
        ).joinToString(", ")
    }

    data class AddGear(val name: String, val model: String = "", val km0: Double = 0.0, val limitKm: Double = 0.0) : CoachAction {
        override val summary: String get() = "Tambah gear \"$name\"" + (if (limitKm > 0) ", batas ${CoachActions.fmt(limitKm)} km" else "")
    }

    /** Catat nyeri/cedera (area, sisi, tingkat 1..5, kapan muncul); entri tanggal+area+sisi yang sama diganti. */
    data class LogPain(val area: String, val side: String, val severity: Int, val moment: String, val dateIso: String) : CoachAction {
        override val summary: String get() = "Catat nyeri ${InjuryPrevention.areaName(area)} (${InjuryPrevention.sideName(side)}) $dateIso: $severity/5, ${InjuryPrevention.momentName(moment).lowercase()}"
    }

    /** Pasang gear (sepatu) pada aktivitas. [activityId] null = aktivitas lari terakhir; gear dicari dari [gearName] (tidak peka huruf besar). */
    data class SetActivityGear(val activityId: Long?, val gearName: String) : CoachAction {
        override val summary: String get() = "Pasang gear \"$gearName\" pada " + (activityId?.let { "aktivitas #$it" } ?: "aktivitas lari terakhir")
    }

    /**
     * Sesi latihan terstruktur untuk jam: pemanasan -> [repeats] x (lari + recovery) -> pendinginan. Target intensitas memakai
     * zona HR 1..5 (dikonversi aplikasi dari zona pengguna, bukan angka bpm dari model) atau rentang pace per km ([runPaceFast] <= [runPaceSlow]).
     */
    data class SendWorkout(
        val name: String, val warmupMin: Int, val repeats: Int, val runMin: Int, val recoveryMin: Int, val cooldownMin: Int,
        val runZone: Int? = null, val runPaceFast: Int? = null, val runPaceSlow: Int? = null,
        val warmupZone: Int? = null, val recoveryZone: Int? = null, val cooldownZone: Int? = null,
    ) : CoachAction {
        override val summary: String get() = buildString {
            append("Kirim workout \"$name\" ke jam: ")
            if (warmupMin > 0) append("pemanasan $warmupMin mnt, ")
            append(if (repeats > 1) "$repeats × $runMin mnt lari" else "$runMin mnt lari")
            runZone?.let { append(" (Z$it)") }
            if (runPaceFast != null && runPaceSlow != null) append(" (pace ${StructuredWorkout.formatPace(runPaceFast)}–${StructuredWorkout.formatPace(runPaceSlow)}/km)")
            if (recoveryMin > 0 && repeats > 1) append(", recovery $recoveryMin mnt")
            if (cooldownMin > 0) append(", pendinginan $cooldownMin mnt")
        }
    }

    data class SetSessionDone(val dateIso: String, val done: Boolean) : CoachAction {
        override val summary: String get() = if (done) "Tandai sesi $dateIso selesai" else "Batalkan tanda selesai sesi $dateIso"
    }

    data class SkipSession(val dateIso: String) : CoachAction {
        override val summary: String get() = "Lewati sesi latihan $dateIso (keluar dari target pekan)"
    }

    /** Hanya field yang dicantumkan yang berubah; lihat [CoachActions.SETTING_KEYS]. */
    data class UpdateSettings(val changes: Map<String, Any>) : CoachAction {
        override val summary: String get() = "Ubah pengaturan: " + changes.entries.joinToString(", ") { (k, v) -> "${CoachActions.settingLabel(k)} → $v" }
    }
}

object CoachActions {
    const val MAX_ACTIONS_PER_REPLY = 5

    internal fun fmt(d: Double): String = if (d == d.toLong().toDouble()) d.toLong().toString() else "%.1f".format(java.util.Locale.US, d)

    /** Kunci pengaturan yang boleh diubah coach beserta label tampilannya. Sengaja tidak mencakup zona, rumus, atau jadwal besar. */
    val SETTING_KEYS: Map<String, String> = linkedMapOf(
        "name" to "nama", "goalT" to "target waktu", "pace" to "pace target", "hr" to "HR latihan",
        "hrMax" to "HR maks", "race" to "tanggal lomba", "base" to "km dasar/pekan", "peak" to "km puncak/pekan",
        "days" to "hari lari/pekan", "rest" to "hari libur", "longDay" to "hari long run", "sickUntil" to "sakit sampai",
    )

    fun settingLabel(k: String): String = SETTING_KEYS[k] ?: k

    private fun obj(vararg props: Pair<String, JSONObject>, required: List<String> = emptyList()): JSONObject =
        JSONObject().put("type", "object").put("properties", JSONObject().also { p -> props.forEach { (k, v) -> p.put(k, v) } })
            .put("required", JSONArray(required)).put("additionalProperties", false)

    private fun str(desc: String) = JSONObject().put("type", "string").put("description", desc)
    private fun num(desc: String) = JSONObject().put("type", "number").put("description", desc)
    private fun int(desc: String) = JSONObject().put("type", "integer").put("description", desc)
    private fun bool(desc: String) = JSONObject().put("type", "boolean").put("description", desc)

    private fun fn(name: String, desc: String, params: JSONObject) = JSONObject().put("type", "function")
        .put("function", JSONObject().put("name", name).put("description", desc).put("parameters", params))

    private const val DATE = "Tanggal yyyy-MM-dd"

    /** Tool yang hanya bermakna bila ada rencana latihan aktif (sesi terjadwal yang bisa ditandai atau dilewati). */
    val PLAN_ONLY_TOOLS: Set<String> = setOf("set_session_done", "skip_session")

    /**
     * Definisi tool untuk body request chat completions (format OpenAI/Groq). Bila [planActive] false (mode No plan atau plan error),
     * tool khusus sesi rencana ([PLAN_ONLY_TOOLS]) tidak dikirim agar model tidak mengusulkan aksi yang pasti ditolak.
     */
    fun toolDefinitions(planActive: Boolean = true): JSONArray {
        val all = allToolDefinitions()
        if (planActive) return all
        val out = JSONArray()
        for (i in 0 until all.length()) {
            val name = all.getJSONObject(i).optJSONObject("function")?.optString("name").orEmpty()
            if (name !in PLAN_ONLY_TOOLS) out.put(all.getJSONObject(i))
        }
        return out
    }

    private fun allToolDefinitions(): JSONArray = JSONArray()
        .put(fn("add_activity", "Catat aktivitas lari/sepeda baru. Hanya bila pengguna menyebut jarak dan durasi.", obj(
            "date" to str(DATE), "km" to num("Jarak km"), "duration_min" to num("Durasi menit"),
            "type" to str("run atau bike").put("enum", JSONArray(listOf("run", "bike"))), "name" to str("Nama aktivitas"),
            "avg_hr" to int("HR rata-rata"), "max_hr" to int("HR maks"), "gain_m" to int("Elevasi naik (m)"),
            "start_time" to str("Jam mulai HH:mm"), "feel10" to int("Rasa setelah lari 1..10"), "note" to str("Catatan"),
            required = listOf("date", "km", "duration_min"),
        )))
        .put(fn("edit_activity", "Ubah nama, catatan, tanggal, jam, atau tipe aktivitas yang sudah ada. Gunakan id dari daftar aktivitas.", obj(
            "id" to int("ID aktivitas"), "name" to str("Nama baru"), "description" to str("Catatan/deskripsi baru"),
            "date" to str(DATE), "start_time" to str("HH:mm"), "type" to str("run atau bike").put("enum", JSONArray(listOf("run", "bike"))),
            required = listOf("id"),
        )))
        .put(fn("set_activity_feel", "Set rasa setelah lari (1..10) pada aktivitas.", obj(
            "id" to int("ID aktivitas"), "feel10" to int("1..10"), required = listOf("id", "feel10"),
        )))
        .put(fn("delete_activity", "Hapus aktivitas. Hanya bila pengguna jelas memintanya.", obj("id" to int("ID aktivitas"), required = listOf("id"))))
        .put(fn("save_daily", "Catat kondisi harian (tidur, HR istirahat, HRV, rasa kaki, mood). Isi hanya yang disebut pengguna.", obj(
            "date" to str(DATE), "sleep_h" to num("Jam tidur"), "rhr" to int("HR istirahat"), "hrv" to int("HRV (ms)"),
            "leg" to int("Rasa kaki 1 segar .. 5 sangat berat"), "mood" to int("Stres/mood 1 santai .. 5 stres berat"),
            required = listOf("date"),
        )))
        .put(fn("add_gear", "Tambah gear (sepatu).", obj(
            "name" to str("Nama"), "model" to str("Model"), "km0" to num("Jarak awal km"), "limit_km" to num("Batas pakai km, 0 = tanpa batas"),
            required = listOf("name"),
        )))
        .put(fn("log_pain", "Catat nyeri/cedera pada satu area tubuh. Tanya dulu area, sisi, dan tingkat bila belum disebut.", obj(
            "area" to str("ID area").put("enum", JSONArray(InjuryPrevention.groups.flatMap { g -> g.areas.map { it.first } })),
            "side" to str("k=kiri, r=kanan, b=keduanya").put("enum", JSONArray(InjuryPrevention.sides.map { it.first })),
            "severity" to int("1 ringan .. 5 berat"),
            "moment" to str("sb=sebelum lari, sl=saat lari, sa=setelah lari").put("enum", JSONArray(InjuryPrevention.moments.map { it.first })),
            "date" to str("$DATE; kosong = hari ini"),
            required = listOf("area", "side", "severity"),
        )))
        .put(fn("set_activity_gear", "Pasang gear (sepatu) pada aktivitas lari. Tanpa activity_id = aktivitas lari terakhir. Gunakan nama gear persis dari daftar gear.", obj(
            "gear_name" to str("Nama gear"), "activity_id" to int("ID aktivitas; kosong = lari terakhir"), required = listOf("gear_name"),
        )))
        .put(fn("send_workout_to_watch", "Buat sesi latihan terstruktur (pemanasan, N × lari + recovery, pendinginan) dan kirim ke jam. Target intensitas pakai ZONA HR 1..5 atau rentang pace; jangan menulis angka bpm sendiri, aplikasi yang mengonversi dari zona pengguna. Isi hanya yang jelas dari permintaan atau rencana; tanyakan dulu bila durasi atau jumlah repetisi belum jelas.", obj(
            "name" to str("Nama sesi di jam, singkat"), "warmup_min" to int("Pemanasan menit, 0..60; 0 = tanpa"),
            "repeats" to int("Jumlah repetisi 1..20 (1 = satu blok kontinu seperti tempo)"), "run_min" to int("Durasi lari tiap repetisi, menit 1..180"),
            "recovery_min" to int("Recovery/jog setelah tiap repetisi, menit 0..60"), "cooldown_min" to int("Pendinginan menit, 0..60; 0 = tanpa"),
            "run_zone" to int("Zona HR langkah lari 1..5 (jangan dikombinasikan dengan pace)"),
            "run_pace_fast" to str("Pace tercepat langkah lari m:ss per km"), "run_pace_slow" to str("Pace terlambat langkah lari m:ss per km"),
            "warmup_zone" to int("Zona HR pemanasan 1..5"), "recovery_zone" to int("Zona HR recovery 1..5"), "cooldown_zone" to int("Zona HR pendinginan 1..5"),
            required = listOf("name", "repeats", "run_min"),
        )))
        .put(fn("set_session_done", "Tandai sesi rencana pada tanggal tertentu selesai (atau batalkan tanda).", obj(
            "date" to str(DATE), "done" to bool("true = selesai"), required = listOf("date", "done"),
        )))
        .put(fn("skip_session", "Lewati sesi rencana pada tanggal tertentu (misal lelah/sakit).", obj("date" to str(DATE), required = listOf("date"))))
        .put(fn("update_settings", "Ubah pengaturan latihan. Isi hanya field yang diminta pengguna.", obj(
            "name" to str("Nama"), "goal_time" to str("Target waktu h:mm:ss atau mm:ss"), "pace" to str("Pace target m:ss per km"),
            "hr" to int("HR latihan"), "hr_max" to int("HR maks"), "race_date" to str(DATE), "base_km" to num("Km dasar/pekan"),
            "peak_km" to num("Km puncak/pekan"), "run_days" to int("5 atau 6").put("enum", JSONArray(listOf(5, 6))),
            "rest_day" to int("0=Senin..6=Minggu"), "long_run_day" to int("0=Senin..6=Minggu"), "sick_until" to str(DATE),
        )))

    /** Hasil penguraian satu balasan model. [rejected] berisi alasan tool call yang ditolak (untuk ditampilkan). */
    data class Parsed(val actions: List<CoachAction>, val rejected: List<String>)

    /** Uraikan `message.tool_calls` dari respons. [today] dipakai membatasi tanggal yang tidak masuk akal. */
    fun parse(toolCalls: JSONArray?, today: LocalDate = LocalDate.now()): Parsed {
        val ok = ArrayList<CoachAction>(); val bad = ArrayList<String>()
        if (toolCalls == null) return Parsed(ok, bad)
        for (i in 0 until toolCalls.length()) {
            if (ok.size >= MAX_ACTIONS_PER_REPLY) { bad += "Terlalu banyak aksi sekaligus (maks $MAX_ACTIONS_PER_REPLY)"; break }
            val f = toolCalls.optJSONObject(i)?.optJSONObject("function") ?: continue
            val name = f.optString("name")
            val args = runCatching { JSONObject(f.optString("arguments").ifBlank { "{}" }) }.getOrNull()
            if (args == null) { bad += "$name: argumen bukan JSON"; continue }
            when (val r = build(name, args, today)) {
                is Built.Ok -> ok += r.action
                is Built.Err -> bad += "$name: ${r.msg}"
            }
        }
        return Parsed(ok, bad)
    }

    private sealed interface Built { class Ok(val action: CoachAction) : Built; class Err(val msg: String) : Built }
    private fun err(m: String) = Built.Err(m)

    private fun date(a: JSONObject, key: String, today: LocalDate, allowFuture: Boolean): Pair<String?, String?> {
        val s = a.optString(key).trim()
        val d = runCatching { LocalDate.parse(s) }.getOrNull() ?: return null to "tanggal \"$s\" harus yyyy-MM-dd"
        if (d.isBefore(today.minusYears(5))) return null to "tanggal $s terlalu lama"
        if (!allowFuture && d.isAfter(today)) return null to "tanggal $s di masa depan"
        if (d.isAfter(today.plusYears(2))) return null to "tanggal $s terlalu jauh"
        return d.toString() to null
    }

    private fun optInt(a: JSONObject, k: String, r: IntRange): Pair<Int?, String?> {
        if (!a.has(k) || a.isNull(k)) return null to null
        val d = a.optDouble(k, Double.NaN); if (d.isNaN()) return null to "$k bukan angka"
        val v = Math.round(d).toInt()
        return if (v in r) v to null else null to "$k di luar rentang $r"
    }

    private fun optDbl(a: JSONObject, k: String, r: ClosedFloatingPointRange<Double>): Pair<Double?, String?> {
        if (!a.has(k) || a.isNull(k)) return null to null
        val d = a.optDouble(k, Double.NaN); if (d.isNaN()) return null to "$k bukan angka"
        return if (d in r) d to null else null to "$k di luar rentang $r"
    }

    private fun clean(s: String?, max: Int) = s?.trim()?.take(max)?.takeIf { it.isNotEmpty() }
    private fun time(a: JSONObject): Pair<String?, String?> {
        val t = clean(a.optString("start_time"), 5) ?: return null to null
        return if (Regex("([01]\\d|2[0-3]):[0-5]\\d").matches(t)) t to null else null to "jam harus HH:mm"
    }

    private fun build(name: String, a: JSONObject, today: LocalDate): Built {
        when (name) {
            "add_activity" -> {
                val (d, e1) = date(a, "date", today, false); if (e1 != null) return err(e1)
                val (km, e2) = optDbl(a, "km", 0.1..500.0); if (km == null) return err(e2 ?: "km wajib")
                val (min, e3) = optDbl(a, "duration_min", 1.0..2000.0); if (min == null) return err(e3 ?: "duration_min wajib")
                val type = a.optString("type", "run").ifBlank { "run" }; if (type != "run" && type != "bike") return err("type harus run/bike")
                val (hr, e4) = optInt(a, "avg_hr", 30..230); if (e4 != null) return err(e4)
                val (mx, e5) = optInt(a, "max_hr", 30..250); if (e5 != null) return err(e5)
                val (g, e6) = optInt(a, "gain_m", 0..20000); if (e6 != null) return err(e6)
                val (f, e7) = optInt(a, "feel10", 1..10); if (e7 != null) return err(e7)
                val (t, e8) = time(a); if (e8 != null) return err(e8)
                return Built.Ok(CoachAction.AddActivity(d!!, km, Math.round(min * 60).toInt(), type, clean(a.optString("name"), 60).orEmpty(), hr, mx, g, t, f, clean(a.optString("note"), 500).orEmpty()))
            }
            "edit_activity" -> {
                val id = a.optLong("id", -1); if (id <= 0) return err("id tidak valid")
                var dt: String? = null
                if (a.has("date")) { val (d, e) = date(a, "date", today, false); if (e != null) return err(e); dt = d }
                val (t, et) = time(a); if (et != null) return err(et)
                val type = clean(a.optString("type"), 8); if (type != null && type != "run" && type != "bike") return err("type harus run/bike")
                val act = CoachAction.EditActivity(id, clean(a.optString("name"), 60), clean(a.optString("description"), 500), dt, t, type)
                if (listOf(act.name, act.description, act.dateIso, act.startTime, act.type).all { it == null }) return err("tidak ada yang diubah")
                return Built.Ok(act)
            }
            "set_activity_feel" -> {
                val id = a.optLong("id", -1); if (id <= 0) return err("id tidak valid")
                val (f, e) = optInt(a, "feel10", 1..10); if (f == null) return err(e ?: "feel10 wajib")
                return Built.Ok(CoachAction.SetActivityFeel(id, f))
            }
            "delete_activity" -> {
                val id = a.optLong("id", -1); if (id <= 0) return err("id tidak valid")
                return Built.Ok(CoachAction.DeleteActivity(id))
            }
            "save_daily" -> {
                val (d, e1) = date(a, "date", today, false); if (e1 != null) return err(e1)
                val (s, e2) = optDbl(a, "sleep_h", 0.0..24.0); if (e2 != null) return err(e2)
                val (r, e3) = optInt(a, "rhr", 25..140); if (e3 != null) return err(e3)
                val (h, e4) = optInt(a, "hrv", 1..300); if (e4 != null) return err(e4)
                val (l, e5) = optInt(a, "leg", 1..5); if (e5 != null) return err(e5)
                val (m, e6) = optInt(a, "mood", 1..5); if (e6 != null) return err(e6)
                if (listOf(s, r, h, l, m).all { it == null }) return err("tidak ada nilai yang dicatat")
                return Built.Ok(CoachAction.SaveDaily(d!!, s, r, h, l, m))
            }
            "add_gear" -> {
                val n = clean(a.optString("name"), 60) ?: return err("nama wajib")
                val (k0, e1) = optDbl(a, "km0", 0.0..100000.0); if (e1 != null) return err(e1)
                val (lim, e2) = optDbl(a, "limit_km", 0.0..100000.0); if (e2 != null) return err(e2)
                return Built.Ok(CoachAction.AddGear(n, clean(a.optString("model"), 60).orEmpty(), k0 ?: 0.0, lim ?: 0.0))
            }
            "log_pain" -> {
                val area = a.optString("area").trim()
                if (InjuryPrevention.groups.none { g -> g.areas.any { it.first == area } }) return err("area \"$area\" tidak dikenal")
                val side = a.optString("side").trim(); if (InjuryPrevention.sides.none { it.first == side }) return err("side harus k, r, atau b")
                val (sev, e1) = optInt(a, "severity", 1..5); if (sev == null) return err(e1 ?: "severity wajib")
                val moment = a.optString("moment").trim().ifEmpty { "sl" }; if (InjuryPrevention.moments.none { it.first == moment }) return err("moment harus sb, sl, atau sa")
                val d = if (a.optString("date").isBlank()) today.toString() else { val (x, e) = date(a, "date", today, false); if (e != null) return err(e); x!! }
                return Built.Ok(CoachAction.LogPain(area, side, sev, moment, d))
            }
            "set_activity_gear" -> {
                val g = clean(a.optString("gear_name"), 60) ?: return err("gear_name wajib")
                val id = if (a.has("activity_id") && !a.isNull("activity_id")) a.optLong("activity_id", -1).also { if (it <= 0) return err("activity_id tidak valid") } else null
                return Built.Ok(CoachAction.SetActivityGear(id, g))
            }
            "send_workout_to_watch" -> {
                val n = clean(a.optString("name"), 36) ?: return err("name wajib")
                val (wu, e1) = optInt(a, "warmup_min", 0..60); if (e1 != null) return err(e1)
                val (rp, e2) = optInt(a, "repeats", 1..20); if (rp == null) return err(e2 ?: "repeats wajib")
                val (rm, e3) = optInt(a, "run_min", 1..180); if (rm == null) return err(e3 ?: "run_min wajib")
                val (rc, e4) = optInt(a, "recovery_min", 0..60); if (e4 != null) return err(e4)
                val (cd, e5) = optInt(a, "cooldown_min", 0..60); if (e5 != null) return err(e5)
                val (rz, e6) = optInt(a, "run_zone", 1..5); if (e6 != null) return err(e6)
                val (wz, e7) = optInt(a, "warmup_zone", 1..5); if (e7 != null) return err(e7)
                val (cz, e8) = optInt(a, "recovery_zone", 1..5); if (e8 != null) return err(e8)
                val (dz, e9) = optInt(a, "cooldown_zone", 1..5); if (e9 != null) return err(e9)
                var fast: Int? = null; var slow: Int? = null
                val pf = clean(a.optString("run_pace_fast"), 5); val ps = clean(a.optString("run_pace_slow"), 5)
                if (pf != null || ps != null) {
                    if (pf == null || ps == null) return err("pace butuh run_pace_fast dan run_pace_slow")
                    val x = StructuredWorkout.parsePace(pf) ?: return err("run_pace_fast harus m:ss")
                    val y = StructuredWorkout.parsePace(ps) ?: return err("run_pace_slow harus m:ss")
                    if (x !in 60..900 || y !in 60..900) return err("pace harus 1:00 sampai 15:00 per km")
                    fast = minOf(x, y); slow = maxOf(x, y)
                    if (rz != null) return err("pilih zona HR atau pace untuk langkah lari, bukan keduanya")
                }
                return Built.Ok(CoachAction.SendWorkout(n, wu ?: 0, rp, rm, rc ?: 0, cd ?: 0, rz, fast, slow, wz, cz, dz))
            }
            "set_session_done" -> {
                val (d, e) = date(a, "date", today, true); if (e != null) return err(e)
                if (!a.has("done")) return err("done wajib")
                return Built.Ok(CoachAction.SetSessionDone(d!!, a.optBoolean("done")))
            }
            "skip_session" -> {
                val (d, e) = date(a, "date", today, true); if (e != null) return err(e)
                return Built.Ok(CoachAction.SkipSession(d!!))
            }
            "update_settings" -> {
                val c = LinkedHashMap<String, Any>()
                clean(a.optString("name"), 40)?.let { c["name"] = it }
                clean(a.optString("goal_time"), 8)?.let {
                    if (!Regex("(\\d{1,2}:)?[0-5]?\\d:[0-5]\\d").matches(it)) return err("goal_time harus h:mm:ss atau mm:ss")
                    c["goalT"] = it
                }
                clean(a.optString("pace"), 5)?.let {
                    if (!Regex("\\d{1,2}:[0-5]\\d").matches(it)) return err("pace harus m:ss")
                    c["pace"] = it
                }
                optInt(a, "hr", 80..220).let { (v, e) -> if (e != null) return err(e); v?.let { c["hr"] = it } }
                optInt(a, "hr_max", 120..240).let { (v, e) -> if (e != null) return err(e); v?.let { c["hrMax"] = it } }
                optDbl(a, "base_km", 5.0..300.0).let { (v, e) -> if (e != null) return err(e); v?.let { c["base"] = it } }
                optDbl(a, "peak_km", 5.0..400.0).let { (v, e) -> if (e != null) return err(e); v?.let { c["peak"] = it } }
                optInt(a, "run_days", 5..6).let { (v, e) -> if (e != null) return err(e); v?.let { c["days"] = it } }
                optInt(a, "rest_day", 0..6).let { (v, e) -> if (e != null) return err(e); v?.let { c["rest"] = it } }
                optInt(a, "long_run_day", 0..6).let { (v, e) -> if (e != null) return err(e); v?.let { c["longDay"] = it } }
                for ((src, dst) in listOf("race_date" to "race", "sick_until" to "sickUntil")) if (a.has(src)) {
                    val (d, e) = date(a, src, today, true); if (e != null) return err(e); c[dst] = d!!
                }
                if (c.isEmpty()) return err("tidak ada pengaturan yang diubah")
                val base = c["base"] as? Double; val peak = c["peak"] as? Double
                if (base != null && peak != null && peak < base) return err("peak_km tidak boleh di bawah base_km")
                return Built.Ok(CoachAction.UpdateSettings(c))
            }
        }
        return err("tool tidak dikenal")
    }

    /** Target tiap langkah untuk [w]: zona HR dikonversi dari batas zona pengguna ([lower] = StructuredWorkout.watchLowerBounds), pace langsung dalam detik/km. */
    fun workoutTargets(w: CoachAction.SendWorkout, lower: List<Int>, maxHr: Int): WorkoutTargets {
        fun zone(z: Int?) = if (z == null) StepTarget() else StructuredWorkout.zoneTarget(z, lower, maxHr)
        val run = when {
            w.runPaceFast != null && w.runPaceSlow != null -> StepTarget(StepIntensity.PACE, w.runPaceFast, w.runPaceSlow)
            else -> zone(w.runZone)
        }
        return WorkoutTargets(warmup = zone(w.warmupZone), run = run, recovery = zone(w.recoveryZone), cooldown = zone(w.cooldownZone))
    }

    /** Terapkan perubahan ke [PlanSettings]; nilai sudah divalidasi oleh [parse]. */
    fun applySettings(s: PlanSettings, c: Map<String, Any>): PlanSettings {
        var r = s
        c.forEach { (k, v) ->
            r = when (k) {
                "name" -> r.copy(name = v as String)
                "goalT" -> r.copy(goalT = v as String)
                "pace" -> r.copy(pace = v as String)
                "hr" -> r.copy(hr = v as Int)
                "hrMax" -> r.copy(hrMax = v as Int)
                "base" -> r.copy(base = v as Double)
                "peak" -> r.copy(peak = v as Double)
                "days" -> r.copy(days = v as Int)
                "rest" -> r.copy(rest = v as Int)
                "longDay" -> r.copy(longDay = v as Int)
                "race" -> r.copy(race = LocalDate.parse(v as String))
                "sickUntil" -> r.copy(sickUntil = LocalDate.parse(v as String))
                else -> r
            }
        }
        return r
    }
}
