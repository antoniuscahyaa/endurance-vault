package com.endurancevault.app.domain

import com.endurancevault.app.data.ActivityEntity
import java.time.LocalDate
import kotlin.math.max
import kotlin.math.roundToInt

/** Penyesuaian rencana dari tab Profil; diterapkan ke salinan hasil PlanEngine setiap kalkulasi. */
object ProfilePlanAdjustments {
    private val runKinds = setOf("easy", "short", "medium", "long", "quality", "sub")
    private val trimKinds = setOf("easy", "short", "medium")

    fun apply(plan: PlanOutcome, settings: PlanSettings, activities: List<ActivityEntity>, today: LocalDate = LocalDate.now()): PlanOutcome {
        val r = applyAdjustments(plan, settings, activities, today)
        // km/D+ sesi trail bisa berubah oleh penyesuaian di atas dan oleh SessionAdjust: samakan kalimat targetnya.
        TrailTarget.sync(r)
        return r
    }

    private fun applyAdjustments(plan: PlanOutcome, settings: PlanSettings, activities: List<ActivityEntity>, today: LocalDate): PlanOutcome {
        val ok = plan as? PlanOutcome.Ok ?: return plan
        val monday = today.with(java.time.DayOfWeek.MONDAY)
        val week = ok.weeks.firstOrNull { it.start == monday } ?: return plan
        val doneDates = activities.filter { it.type != "bike" }.map { it.dateIso }.toSet()
        val rows = week.days
        val sick = settings.sickUntil?.let { !it.isBefore(today) } == true
        val sickEnd = settings.sickUntil ?: today.minusDays(1)
        rows.forEach { d ->
            if (d.date.isBefore(today) || d.date.toString() in doneDates || d.kind !in runKinds || d.km <= 0) return@forEach
            if (sick && !d.date.isAfter(sickEnd)) {
                d.kind = Kinds.REST; d.grp = "rest"; d.title = "Istirahat (mode sakit)"; d.km = 0.0
                d.str = null; d.ank = null; d.up = null
                d.detail = "Mode sakit/cedera: istirahat untuk memberi waktu pemulihan. Kembali berlatih bertahap bila kondisi membaik."
            } else {
                val factor = when {
                    sick -> .8
                    settings.weekScale < .999 && settings.weekScaleWeek == monday -> settings.weekScale.coerceIn(.5, 1.0)
                    else -> 1.0
                }
                if (factor < 1.0) {
                    val old = d.km
                    d.km = max(2.0, (old * factor * 10).roundToInt() / 10.0)
                    TrailTarget.scaleGain(d, factor)
                    d.detail = (d.detail + " Penyesuaian beban Profil: ${((1-factor)*100).roundToInt()}% lebih ringan.").trim()
                }
            }
        }
        // Auto-adjust versi native: lari dadakan/kelebihan rencana mengurangi sesi easy berikutnya,
        // tanpa mengubah sesi kualitas atau long run.
        if (settings.autoAdjust && !sick) {
            val recent = activities.filter { it.type != "bike" && it.km > 0 && it.dateIso >= today.minusDays(1).toString() && it.dateIso <= today.toString() }
            recent.forEach { a ->
                val planned = rows.firstOrNull { it.date.toString() == a.dateIso && it.kind in runKinds }
                val heavy = if (planned == null) a.km >= 8.0 || a.durationSec >= 3600
                    else a.km - planned.km >= 5.0 && a.km >= planned.km * 1.3
                if (heavy) {
                    val next = rows.firstOrNull { it.date == LocalDate.parse(a.dateIso).plusDays(1) && it.date >= today && it.kind in trimKinds && it.km > 0 && it.date.toString() !in doneDates }
                    if (next != null) {
                        val old = next.km; next.km = max(3.0, (old * .8 * 10).roundToInt() / 10.0)
                        next.detail = (next.detail + " Penyesuaian otomatis: sesi sebelumnya lebih berat dari rencana; sesi easy ini dikurangi 20%.").trim()
                    }
                }
            }
        }
        week.km.let { _ -> /* total minggu dihitung ulang dari hari setelah penyesuaian */ }
        val newKm = rows.sumOf { it.km }.let { (it * 10).roundToInt() / 10.0 }
        // Ubah km minggu aktif pada objeknya sendiri supaya penanda penyesuaian jadwal (missed, adj80) tidak hilang.
        val adjustedWeeks = ok.weeks.map { if (it.start == monday) { it.km = newKm; it } else it }
        return PlanOutcome.Ok(adjustedWeeks, ok.start, ok.race, ok.n, ok.noRace, ok.none, ok.build, ok.pbCycle, ok.convWk)
    }
}
