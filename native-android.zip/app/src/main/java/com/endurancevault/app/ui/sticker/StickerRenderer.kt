package com.endurancevault.app.ui.sticker

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import com.endurancevault.app.domain.Js
import com.endurancevault.app.domain.SegKind
import com.endurancevault.app.domain.StickerModel
import com.endurancevault.app.domain.StickerNum
import com.endurancevault.app.domain.StickerPrefs
import com.endurancevault.app.domain.Stickers
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Palet stiker (padanan `STK_INK`); [sh] = 0 berarti tanpa bayangan. */
class StickerPalette(val ink: Int, val ink2: Int, val line: Int, val hl: Int, val sh: Int, val bg: Int, val panelLight: Boolean)

private fun rgba(r: Int, g: Int, b: Int, a: Double): Int = Color.argb((a * 255).roundToInt(), r, g, b)

object StickerPalettes {
    private val W = StickerPalette(Color.WHITE, rgba(255, 255, 255, .84), rgba(255, 255, 255, .38), 0xFFC6F432.toInt(), rgba(0, 0, 0, .45), 0xFF2A3A33.toInt(), false)
    private val K = StickerPalette(0xFF111111.toInt(), rgba(17, 17, 17, .74), rgba(17, 17, 17, .3), 0xFF2F7D1F.toInt(), 0, 0xFFE9ECEA.toInt(), true)
    private val L = StickerPalette(0xFFC6F432.toInt(), rgba(227, 248, 160, .95), rgba(198, 244, 50, .42), Color.WHITE, rgba(0, 0, 0, .45), 0xFF2A3A33.toInt(), false)

    /** Palet menurut pilihan warna teks, dengan warna sorotan diganti aksen bila diisi (padanan `stkPal`). */
    fun of(p: StickerPrefs): StickerPalette {
        val b = when (p.ink) { "k" -> K; "l" -> L; else -> W }
        if (p.accent.isEmpty()) return b
        return StickerPalette(b.ink, b.ink2, b.line, Color.parseColor(p.accent), b.sh, b.bg, b.panelLight)
    }
}

/** Satu kanvas stiker: bitmap transparan, panel latar opsional, dan alat gambar kecil. Satuan piksel sama dengan versi web. */
private class Sk(w: Int, h: Int, val pal: StickerPalette, panelLevel: String) {
    val bmp: Bitmap = Bitmap.createBitmap(max(2, w), max(2, h), Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        if (panelLevel == "soft" || panelLevel == "strong") {
            val a = if (panelLevel == "strong") .62 else .38
            val col = if (pal.panelLight) rgba(255, 255, 255, a + .14) else rgba(0, 0, 0, a)
            fillPaint(col, shadow = false)
            val r = min(48f, bmp.height / 4f)
            c.drawRoundRect(RectF(0f, 0f, bmp.width.toFloat(), bmp.height.toFloat()), r, r, p)
        }
    }

    private fun fillPaint(col: Int, alpha: Float = 1f, shadow: Boolean = true) {
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.FILL; p.color = withA(col, alpha)
        if (shadow && pal.sh != 0) p.setShadowLayer(12f, 0f, 3f, pal.sh) else p.clearShadowLayer()
    }

    private fun strokePaint(col: Int, width: Float, alpha: Float = 1f, shadow: Boolean = true) {
        fillPaint(col, alpha, shadow); p.style = Paint.Style.STROKE; p.strokeWidth = width
    }

    private fun face(f: Boolean, wt: Int): Typeface =
        if (f) Typeface.create("sans-serif-condensed", if (wt >= 600) Typeface.BOLD else Typeface.NORMAL)
        else Typeface.create("sans-serif-medium", Typeface.NORMAL)

    /** Lebar teks. [f] true = huruf condensed (angka dan judul), false = huruf isi. */
    fun tw(t: String, px: Float, wt: Int, f: Boolean = false): Float {
        p.reset(); p.isAntiAlias = true; p.typeface = face(f, wt); p.textSize = px
        return p.measureText(t)
    }

    fun text(t: String, px: Float, wt: Int, col: Int, align: Paint.Align, x: Float, y: Float, f: Boolean = false) {
        fillPaint(col); p.typeface = face(f, wt); p.textSize = px; p.textAlign = align
        c.drawText(t, x, y, p)
    }

    /** Potong dengan "…" sampai muat [maxW]. */
    fun ell(t: String, px: Float, wt: Int, maxW: Float, f: Boolean = false): String {
        if (tw(t, px, wt, f) <= maxW) return t
        var s = t
        while (s.length > 1 && tw("$s…", px, wt, f) > maxW) s = s.dropLast(1)
        return "$s…"
    }

    fun rr(x: Float, y: Float, w: Float, h: Float, r: Float, col: Int, alpha: Float = 1f) {
        val rad = max(0f, min(r, min(w / 2, h / 2)))
        fillPaint(col, alpha); c.drawRoundRect(RectF(x, y, x + w, y + h), rad, rad, p)
    }

    fun rect(x: Float, y: Float, w: Float, h: Float, col: Int, alpha: Float = 1f) { fillPaint(col, alpha); c.drawRect(x, y, x + w, y + h, p) }
    fun circle(x: Float, y: Float, r: Float, col: Int, alpha: Float = 1f) { fillPaint(col, alpha); c.drawCircle(x, y, r, p) }

    fun line(x1: Float, y1: Float, x2: Float, y2: Float, col: Int, width: Float, alpha: Float = 1f, dash: FloatArray? = null) {
        strokePaint(col, width, alpha)
        if (dash != null) p.pathEffect = DashPathEffect(dash, 0f)
        c.drawLine(x1, y1, x2, y2, p)
    }

    fun strokeRect(x: Float, y: Float, w: Float, h: Float, col: Int, width: Float) { strokePaint(col, width); c.drawRect(x, y, x + w, y + h, p) }

    /** Garis lewat banyak titik, sudut dan ujung membulat. */
    fun poly(pts: List<Pair<Float, Float>>, col: Int, width: Float, alpha: Float = 1f) {
        if (pts.size < 2) return
        val path = Path(); pts.forEachIndexed { i, q -> if (i == 0) path.moveTo(q.first, q.second) else path.lineTo(q.first, q.second) }
        strokePaint(col, width, alpha); p.strokeJoin = Paint.Join.ROUND; p.strokeCap = Paint.Cap.ROUND
        c.drawPath(path, p)
    }

    /** Isi area di bawah grafik tanpa bayangan (padanan blok save/restore pada grafik elevasi). */
    fun fillArea(pts: List<Pair<Float, Float>>, baseY: Float, col: Int) {
        val path = Path(); path.moveTo(pts.first().first, baseY)
        pts.forEach { path.lineTo(it.first, it.second) }
        path.lineTo(pts.last().first, baseY); path.close()
        fillPaint(col, shadow = false); c.drawPath(path, p)
    }

    /** Teks diputar -90 derajat (naik), titik awal di ([x],[y]). */
    fun textUp(t: String, px: Float, wt: Int, col: Int, x: Float, y: Float, f: Boolean = false) {
        c.save(); c.translate(x, y); c.rotate(-90f)
        text(t, px, wt, col, Paint.Align.LEFT, 0f, 0f, f)
        c.restore()
    }

    fun head(left: String, right: String, w: Int, pad: Int) {
        text(left, 34f, 500, pal.ink2, Paint.Align.LEFT, pad.toFloat(), pad + 34f)
        if (right.isNotEmpty()) text(right, 38f, 700, pal.ink, Paint.Align.RIGHT, (w - pad).toFloat(), pad + 36f, true)
    }
}

private fun withA(col: Int, a: Float): Int = if (a >= 1f) col else (col and 0x00FFFFFF) or ((Color.alpha(col) * a).roundToInt() shl 24)
private fun rgb(v: Int): Int = 0xFF000000.toInt() or v
private val ORANGE = 0xFFE8873A.toInt()
private val GREEN = 0xFF4CAF7D.toInt()
private val RED = 0xFFE5484D.toInt()

private fun f(x: Double) = x.toFloat()
private fun L() = Paint.Align.LEFT
private fun R() = Paint.Align.RIGHT
private fun C() = Paint.Align.CENTER
private fun zn(i: Int) = "Z${i + 1}"

/** Penggambar semua stiker yang sudah diport. Semua fungsi mengembalikan bitmap ARGB transparan. */
object StickerRenderer {

    /** Gambar seluruh stiker yang tersedia untuk [m], kunci = id (urutan sama dengan [Stickers.allIds]). */
    fun renderAll(m: StickerModel, prefs: StickerPrefs): LinkedHashMap<String, Bitmap> {
        val out = LinkedHashMap<String, Bitmap>()
        val pal = StickerPalettes.of(prefs)
        val ks = m.keys(prefs.order)
        Stickers.allIds(m, prefs).forEach { id ->
            val bmp: Bitmap? = runCatching {
                when {
                    id == "n-all" -> nums(ks.mapNotNull { m.num(it) }, pal, prefs.panel, prefs.cols)
                    id.startsWith("n-") -> m.num(id.removePrefix("n-"))?.let { num1(it, pal, prefs.panel) }
                    id == "map" -> map(m, pal, prefs)
                    id == "tabel-segmen" -> segTable(m, pal, prefs)
                    id == "bar-segmen" -> segBar(m, pal, prefs)
                    id == "pace-segmen" -> segPace(m, pal, prefs)
                    id == "split-km" -> split(m, pal, prefs)
                    id == "elevasi" -> elev(m, pal, prefs)
                    id == "zona-hr-sesi" -> zone(m, pal, prefs)
                    id == "zona-hr-tumpuk" -> zoneStack(m, pal, prefs)
                    else -> null
                }
            }.getOrNull()
            if (bmp != null) out[id] = bmp
        }
        return out
    }

    /** Baris angka: [items] label/nilai/satuan, [cols] 2..4. */
    fun nums(items: List<StickerNum>, pal: StickerPalette, panel: String, cols: Int): Bitmap {
        val n = items.size
        val cc = max(1, min(cols, n))
        val colW = when (cc) { 1 -> 520; 2 -> 400; 3 -> 330; else -> 270 }
        val vp = if (cc <= 2) 120 else if (cc == 3) 100 else 80
        val pad = 40
        val rows = ceil(n / cc.toDouble()).toInt()
        val rh = vp + 94
        val s = Sk(pad * 2 + cc * colW, pad * 2 + rows * rh - 30, pal, panel)
        items.forEachIndexed { i, it ->
            val r = i / cc; val k = i % cc
            val x0 = f((pad + k * colW + (if (k > 0) 26 else 0)).toDouble()); val y0 = f((pad + r * rh).toDouble())
            val maxW = f((colW - (if (k > 0) 26 else 0) - 26).toDouble())
            var px = vp.toFloat(); var up = 0f; var vw = 0f; var uw = 0f
            fun meas() { up = (px * .4f).roundToInt().toFloat(); vw = s.tw(it.value, px, 700, true); uw = if (it.unit.isNotEmpty()) s.tw(it.unit, up, 500) + 10 else 0f }
            meas(); while (px > 40 && vw + uw > maxW) { px -= 4; meas() }
            s.text(s.ell(it.label, 30f, 500, maxW), 30f, 500, pal.ink2, L(), x0, y0 + 30)
            s.text(it.value, px, 700, pal.ink, L(), x0, y0 + 36 + px, true)
            if (it.unit.isNotEmpty()) s.text(it.unit, up, 500, pal.ink2, L(), x0 + vw + 10, y0 + 36 + px)
            if (k > 0) s.rect(f((pad + k * colW - 1).toDouble()), y0 + 2, 3f, f((vp + 44).toDouble()), pal.line)
        }
        return s.bmp
    }

    /** Satu angka satu gambar. */
    fun num1(it: StickerNum, pal: StickerPalette, panel: String): Bitmap {
        val pad = 44; val px = 132f; val up = (px * .4f).roundToInt().toFloat()
        val m = Sk(10, 10, pal, "off")
        val vw = m.tw(it.value, px, 700, true); val uw = if (it.unit.isNotEmpty()) m.tw(it.unit, up, 500) + 12 else 0f
        val lw = m.tw(it.label, 34f, 500)
        val w = ceil(max(lw, vw + uw) + pad * 2).toInt(); val h = (pad * 2 + 36 + px + 8).toInt()
        val s = Sk(w, h, pal, panel)
        s.text(it.label, 34f, 500, pal.ink2, L(), pad.toFloat(), pad + 30f)
        s.text(it.value, px, 700, pal.ink, L(), pad.toFloat(), pad + 36 + px, true)
        if (it.unit.isNotEmpty()) s.text(it.unit, up, 500, pal.ink2, L(), pad + vw + 12, pad + 36 + px)
        return s.bmp
    }

    /** Template peta: garis rute (tanpa tile peta, tetap transparan) dengan data di bawah atau di samping. */
    fun map(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs): Bitmap {
        val d = m.detail!!; val rt = d.route
        val mnx = rt.minOf { it.first }.toDouble(); val mxx = rt.maxOf { it.first }.toDouble()
        val mny = rt.minOf { it.second }.toDouble(); val mxy = rt.maxOf { it.second }.toDouble()
        val rw = max(1.0, mxx - mnx); val rh = max(1.0, mxy - mny)
        val fields = Stickers.MAP_KEYS.filter { it in prefs.mapFields }.mapNotNull { m.num(it) }
        val side = prefs.lay == "kiri"
        val pad = 44; val bw = if (side) 500 else 900; val bh = if (side) 500 else 560
        val sc = min((bw - 40) / rw, (bh - 40) / rh); val dw = rw * sc; val dh = rh * sc
        val cellH = 170
        val w: Int; val h: Int; val ox: Double; val oy: Double; val statX: Double; val statY: Double; val cellW: Double; val cols: Int
        if (side) {
            cols = 1; val body = max(bh, fields.size * cellH)
            w = pad * 2 + bw + 40 + 400; h = pad * 2 + body
            ox = pad + (bw - dw) / 2; oy = pad + (body - dh) / 2
            statX = (pad + bw + 40).toDouble(); statY = pad + (body - fields.size * cellH) / 2.0; cellW = 400.0
        } else {
            cols = 2; w = pad * 2 + bw
            val rowsN = ceil(fields.size / 2.0).toInt()
            h = (pad * 2 + dh + 40 + rowsN * cellH).toInt()
            ox = pad + (bw - dw) / 2; oy = pad + 20.0; statX = pad.toDouble(); statY = pad + dh + 60; cellW = bw / 2.0
        }
        val s = Sk(w, h, pal, prefs.panel)
        s.poly(rt.map { f(ox + (it.first - mnx) * sc) to f(oy + (it.second - mny) * sc) }, pal.ink, 14f)
        val p0 = rt.first(); val p1 = rt.last()
        s.circle(f(ox + (p0.first - mnx) * sc), f(oy + (p0.second - mny) * sc), 19f, pal.hl)
        s.circle(f(ox + (p1.first - mnx) * sc), f(oy + (p1.second - mny) * sc), 19f, pal.ink)
        fields.forEachIndexed { i, it ->
            val r = i / cols; val k = i % cols
            val x = f(statX + k * cellW); val y = f(statY + r * cellH); val maxW = f(cellW - 30)
            var px = 84f; var up = 34f
            var vw = s.tw(it.value, px, 700, true); var uw = if (it.unit.isNotEmpty()) s.tw(it.unit, up, 500) + 10 else 0f
            while (px > 44 && vw + uw > maxW) {
                px -= 4; up = (px * .4f).roundToInt().toFloat()
                vw = s.tw(it.value, px, 700, true); uw = if (it.unit.isNotEmpty()) s.tw(it.unit, up, 500) + 10 else 0f
            }
            s.text(it.label, 30f, 500, pal.ink2, L(), x, y + 30)
            s.text(it.value, px, 700, pal.ink, L(), x, y + 36 + px, true)
            if (it.unit.isNotEmpty()) s.text(it.unit, up, 500, pal.ink2, L(), x + vw + 10, y + 36 + px)
        }
        return s.bmp
    }

    /** Tabel segmen (maks. 22 baris). */
    fun segTable(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs): Bitmap {
        val all = m.segRows; val cap = 22; val rows = all.take(cap); val more = all.size - rows.size
        val w = 1000; val pad = 44; val hd = 78; val th = 48; val rh = 62
        val h = pad * 2 + hd + th + rows.size * rh + (if (more > 0) 54 else 0)
        val s = Sk(w, h, pal, prefs.panel)
        val cHr = (w - pad).toFloat(); val cPc = cHr - 110; val cTm = cPc - 170; val cKm = cTm - 170
        val nameX = pad + 38f; val nameMax = cKm - 150 - nameX
        s.head("Per segmen", "", w, pad)
        val y0 = (pad + hd).toFloat()
        s.text("km", 28f, 500, pal.ink2, R(), cKm, y0 + 26); s.text("Waktu", 28f, 500, pal.ink2, R(), cTm, y0 + 26)
        s.text("Pace", 28f, 500, pal.ink2, R(), cPc, y0 + 26); s.text("HR", 28f, 500, pal.ink2, R(), cHr, y0 + 26)
        rows.forEachIndexed { i, r ->
            val y = y0 + th + i * rh
            s.circle(pad + 12f, y + 30, 12f, Stickers.segRgb(r.kind, r.custom)?.let { rgb(it) } ?: pal.ink2)
            s.text(s.ell(r.name, 36f, 500, nameMax), 36f, 500, pal.ink, L(), nameX, y + 42)
            s.text(if (r.d > 0) Stickers.km2(r.d) else "–", 36f, 500, pal.ink2, R(), cKm, y + 42)
            s.text(if (r.min > 0) Js.durStr(r.min) else "–", 38f, 700, pal.ink, R(), cTm, y + 42, true)
            s.text(if (r.pace > 0) Js.paceStr(r.pace) else "–", 42f, 700, pal.ink, R(), cPc, y + 44, true)
            s.text(r.hr?.takeIf { it > 0 }?.toString() ?: "–", 36f, 500, pal.ink2, R(), cHr, y + 42)
        }
        if (more > 0) s.text("+$more segmen lain", 30f, 500, pal.ink2, L(), pad.toFloat(), y0 + th + rows.size * rh + 34)
        return s.bmp
    }

    /** Bar segmen: urutan waktu, warna per label. */
    fun segBar(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs): Bitmap {
        val sg = m.detail!!.segments.filter { it.min > 0 }; val n = sg.size
        val tot = sg.sumOf { it.min }
        val w = 1000; val pad = 44; val bh = 86; val avail = w - pad * 2 - 3 * (n - 1)
        val meter = Sk(10, 10, pal, "off")
        class Lg(val name: String, val rgb: Int?, val x: Float, val y: Int)
        val names = ArrayList<Triple<String, Int?, Unit>>()
        val seen = HashSet<String>()
        sg.forEach { s ->
            val kind = SegKind.normalize(s.type); val text = SegKind.displayLabel(s.label, s.type)
            val nm = text ?: "Tanpa label"
            if (seen.add(nm)) names.add(Triple(nm, Stickers.segRgb(kind, kind == null && text != null), Unit))
        }
        var lx = pad.toFloat(); var ly = 0; val legend = ArrayList<Lg>()
        names.forEach { (nm, col, _) ->
            val lw = meter.tw(nm, 30f, 500) + 44
            if (lx + lw > w - pad) { lx = pad.toFloat(); ly += 46 }
            legend.add(Lg(nm, col, lx, ly)); lx += lw + 24
        }
        val h = pad * 2 + 78 + bh + 30 + ly + 46
        val s = Sk(w, h, pal, prefs.panel)
        s.head("Bar segmen", Js.durStr(tot), w, pad)
        var x = pad.toFloat(); val by = (pad + 78).toFloat()
        sg.forEach { g ->
            val kind = SegKind.normalize(g.type); val text = SegKind.displayLabel(g.label, g.type)
            val bw = max(4f, f(g.min / tot * avail))
            s.rr(x, by, bw, bh.toFloat(), 6f, Stickers.segRgb(kind, kind == null && text != null)?.let { rgb(it) } ?: pal.ink)
            x += bw + 3
        }
        legend.forEach { g ->
            val y = by + bh + 30 + g.y
            s.circle(g.x + 12, y + 22, 12f, g.rgb?.let { rgb(it) } ?: pal.ink)
            s.text(g.name, 30f, 500, pal.ink2, L(), g.x + 34, y + 32)
        }
        return s.bmp
    }

    /**
     * Bar pace per segmen (gaya Bagikan sesi): lebar bar = jarak, tinggi = pace (makin cepat makin tinggi).
     * Bila ada segmen berlabel bawaan, hanya Repetisi dan Progresif yang penuh; sisanya dipudarkan.
     * Opsi: sorot tercepat dan garis rata-rata ([StickerPrefs.highlight]), garis HR ([StickerPrefs.hrLine]).
     */
    fun segPace(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs): Bitmap {
        val sg = m.paceSegments; val n = sg.size; val bike = m.bike
        val tot = sg.sumOf { it.d }
        val kinds = sg.map { SegKind.normalize(it.type) }
        val typed = kinds.any { it != null }
        fun isWork(i: Int) = !typed || kinds[i] == SegKind.REPETITION || kinds[i] == SegKind.PROGRESSIVE
        val vals = sg.map { if (bike) 60 / it.pace else it.pace }
        val mn = vals.min(); val mx = vals.max()
        val sp = max(mx - mn, mn * .04)
        val blo = if (bike) mn - sp * .35 else mn; val bhi = if (bike) mx else mx + sp * .35
        fun fr(v: Double): Double = max(.06, min(1.0, if (bike) (v - blo) / (bhi - blo) else (bhi - v) / (bhi - blo)))
        val w = 1000; val pad = 44; val hd = 78; val ph = 320; val topRoom = 48
        val pool = sg.indices.filter { isWork(it) }
        var best = -1
        pool.forEach { i -> if (best < 0 || (if (bike) vals[i] > vals[best] else vals[i] < vals[best])) best = i }
        val hlOn = prefs.highlight && pool.size >= 2 && best >= 0
        var avgV = 0.0
        if (hlOn) {
            var sd = 0.0; var sp2 = 0.0
            pool.forEach { i -> sd += sg[i].d; sp2 += sg[i].d * sg[i].pace }
            avgV = if (bike) 60 / (sp2 / sd) else sp2 / sd
        }
        val hrs = sg.map { (it.hr ?: 0).toDouble().coerceAtLeast(0.0) }
        val hrOn = prefs.hrLine && hrs.count { it > 0 } >= 2
        // legenda hanya bila ada label bawaan
        val meter = Sk(10, 10, pal, "off")
        class Lg(val name: String, val strong: Boolean, val x: Float, val y: Int)
        val legend = ArrayList<Lg>()
        var lx = pad.toFloat(); var ly = 0
        if (typed) {
            val seen = HashSet<String>()
            sg.forEachIndexed { i, s ->
                val nm = SegKind.displayLabel(s.label, s.type) ?: "Tanpa label"
                if (!seen.add(nm)) return@forEachIndexed
                val lw = meter.tw(nm, 28f, 500) + 44
                if (lx + lw > w - pad) { lx = pad.toFloat(); ly += 42 }
                legend.add(Lg(nm, isWork(i), lx, ly)); lx += lw + 22
            }
        }
        val legH = if (legend.isNotEmpty()) ly + 54 else 0
        val hb = if (hrOn) 118 else 0; val ft = hlOn || hrOn
        val y0 = pad + hd + legH; val bb = y0 + hb + ph
        val h = bb + (if (ft) 136 else 88) + pad
        val s = Sk(w, h, pal, prefs.panel)
        s.head(
            if (bike) "Kecepatan per segmen" else "Pace per segmen",
            m.pace?.let { if (bike) "${(60 / it).roundToInt()} km/j" else Js.paceStr(it) + "/km" } ?: "", w, pad,
        )
        legend.forEach { g ->
            val y = (pad + hd + g.y).toFloat()
            s.rr(g.x, y + 6f, 22f, 22f, 4f, pal.ink, if (g.strong) .95f else .45f)
            s.text(g.name, 28f, 500, pal.ink2, L(), g.x + 32, y + 27)
        }
        val cw = (w - pad * 2).toDouble(); var pk = 0.0; val hmax = ph - topRoom
        class Geo(val x0: Double, val bw: Double, val h: Int, val wide: Boolean, val isB: Boolean)
        val geo = ArrayList<Geo>()
        sg.forEachIndexed { i, g ->
            val x0 = pad + pk / tot * cw; val bw = g.d / tot * cw; pk += g.d
            val gp = min(6.0, bw * .12); val bh = max(6, (fr(vals[i]) * hmax).roundToInt()); val wide = bw > 86
            val bx = x0 + gp / 2; val bwd = max(2.0, bw - gp); val isB = hlOn && i == best
            geo.add(Geo(x0, bw, bh, wide, isB))
            val alpha = if (isB) 1f else if (typed && !isWork(i)) .45f else .95f
            s.rr(f(bx), f((bb - bh).toDouble()), f(bwd), bh.toFloat(), 6f, if (isB) pal.hl else pal.ink, alpha)
        }
        if (hlOn) {
            val ay = f(bb - (fr(avgV) * hmax).roundToInt().toDouble())
            s.line(pad.toFloat(), ay, (w - pad).toFloat(), ay, pal.ink, 3f, .75f, floatArrayOf(14f, 10f))
        }
        sg.forEachIndexed { i, g ->
            val q = geo[i]
            val vt = if (bike) vals[i].roundToInt().toString() else Js.paceStr(g.pace)
            val col = if (q.isB) pal.hl else pal.ink
            val cx = f(q.x0 + q.bw / 2); val top = f((bb - q.h - 14).toDouble())
            if (q.wide) s.text(vt, f(min(40.0, max(28.0, q.bw / 3.4))), 700, col, C(), cx, top, true)
            else s.textUp(vt, 30f, 700, col, cx + 11, top, true)
            if (q.wide || n <= 10 || i % 2 == 0) {
                val nm = SegKind.displayLabel(g.label, g.type) ?: (i + 1).toString()
                val px = if (q.wide) 26f else 22f
                s.text(s.ell(nm, px, 500, max(q.bw.toFloat(), 60f)), px, 500, pal.ink2, C(), cx, bb + 36f)
            }
            if (q.wide) s.text(Js.fmtKm(g.d) + " km", 24f, 500, pal.ink2, C(), cx, bb + 68f)
        }
        if (hrOn) {
            val hv = hrs.filter { it > 0 }; val hlo = hv.min(); val hhi = hv.max(); val top = y0 + 34; val hh = hb - 62
            class Pt(val x: Float, val y: Float, val v: Int)
            val pts = ArrayList<Pt>()
            sg.indices.forEach { i ->
                if (hrs[i] > 0) pts.add(Pt(f(geo[i].x0 + geo[i].bw / 2), f(top + (if (hhi > hlo) 1 - (hrs[i] - hlo) / (hhi - hlo) else .5) * hh), hrs[i].roundToInt()))
            }
            s.poly(pts.map { it.x to it.y }, RED, 5f)
            var maxI = 0; pts.forEachIndexed { i, q -> if (q.v > pts[maxI].v) maxI = i }
            pts.forEachIndexed { i, q ->
                s.circle(q.x, q.y, 8f, RED)
                if (pts.size <= 8 || i == maxI) s.text(q.v.toString(), 26f, 700, pal.ink, C(), q.x, q.y - 16, true)
            }
        }
        if (ft) {
            val fy = (bb + 120).toFloat(); var fx = pad.toFloat()
            class It(val k: String, val t: String)
            val items = ArrayList<It>()
            if (hlOn) items.add(It("avg", (if (typed) "rata-rata kerja " else "rata-rata ") + (if (bike) "${avgV.roundToInt()} km/j" else Js.paceStr(avgV))))
            if (hlOn) items.add(It("best", "tercepat " + (if (bike) "${vals[best].roundToInt()} km/j" else Js.paceStr(sg[best].pace))))
            if (hrOn) items.add(It("hr", "HR bpm"))
            items.forEach { it ->
                val sw = 40f
                when (it.k) {
                    "avg" -> s.line(fx, fy - 9, fx + sw, fy - 9, pal.ink, 3f, .75f, floatArrayOf(10f, 7f))
                    "best" -> s.rr(fx + 8, fy - 24, 24f, 24f, 4f, pal.hl)
                    else -> s.line(fx, fy - 9, fx + sw, fy - 9, RED, 5f)
                }
                s.text(it.t, 26f, 500, pal.ink2, L(), fx + sw + 10, fy)
                fx += sw + 10 + s.tw(it.t, 26f, 500) + 30
            }
        }
        return s.bmp
    }

    /** Split per km. */
    fun split(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs): Bitmap {
        val rows = m.splitRows; val n = rows.size
        val w = 980; val pad = 44; val hd = 78; val rh = 56
        val s = Sk(w, pad * 2 + hd + n * rh, pal, prefs.panel)
        val lo = rows.minOf { it.pace }; val hi = rows.maxOf { it.pace }
        s.head("Split per km", "", w, pad)
        val bx = (pad + 86).toFloat(); val bmax = (w - pad * 2 - 86 - 150).toDouble()
        rows.forEachIndexed { i, r ->
            val y = (pad + hd + i * rh).toFloat()
            val bw = if (hi > lo) (bmax * (.38 + .62 * (hi - r.pace) / (hi - lo))).roundToInt() else (bmax * .7).roundToInt()
            val lab = if (r.partial) (Js.round(r.k * 10) / 10).toString().replace('.', ',') else Js.round(r.k).toInt().toString()
            s.text(lab, 32f, 500, pal.ink2, L(), pad.toFloat(), y + 34)
            s.rr(bx, y + 6, bw.toFloat(), 32f, 6f, if (r.pace == lo) pal.hl else pal.ink)
            s.text(Js.paceStr(r.pace), 38f, 700, pal.ink, R(), (w - pad).toFloat(), y + 37, true)
        }
        return s.bmp
    }

    /** Grafik elevasi. */
    fun elev(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs): Bitmap {
        val pf = m.detail!!.profile
        val w = 1000; val pad = 44; val gh = 300; val hd = 78
        val s = Sk(w, pad * 2 + hd + gh + 60, pal, prefs.panel)
        val mn = pf.minOf { it.second }; val mx = pf.maxOf { it.second }
        val rg = max(10.0, mx - mn); val kmMax = pf.last().first.takeIf { it > 0 } ?: 1.0
        val gx = pad.toDouble(); val gw = (w - pad * 2).toDouble(); val gy = (pad + hd).toDouble()
        fun X(k: Double) = f(gx + k / kmMax * gw)
        fun Y(e: Double) = f(gy + gh - (e - mn) / rg * gh)
        s.head("Elevation Gain", m.gain?.let { "$it m" } ?: "", w, pad)
        val pts = pf.map { X(it.first) to Y(it.second) }
        s.fillArea(pts, f(gy + gh), withA(pal.ink, .25f))
        s.poly(pts, pal.ink, 8f)
        s.text("${mn.roundToInt()} m", 30f, 500, pal.ink2, L(), pad.toFloat(), f(gy + gh + 46))
        s.text("puncak ${mx.roundToInt()} m", 30f, 500, pal.ink2, R(), (w - pad).toFloat(), f(gy + gh + 46))
        return s.bmp
    }

    /** Zona HR sesi: satu bar per zona; [StickerPrefs.hz] memilih durasi, persen, atau keduanya. */
    fun zone(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs): Bitmap {
        val sc = m.zoneSecs; val t = sc.sum().takeIf { it > 0 } ?: 1.0; val bd = m.zc.bands(); val hz = prefs.hz
        val w = 980; val pad = 44; val hd = 78; val rh = 84
        val s = Sk(w, pad * 2 + hd + 5 * rh, pal, prefs.panel)
        val mxv = sc.max().takeIf { it > 0 } ?: 1.0
        val bx = (pad + 300).toFloat(); val tail = if (hz == "both") 250 else if (hz == "dur") 200 else 150
        val bmax = (w - pad * 2 - 300 - tail).toDouble()
        s.head("Zona HR", Js.durStr(t / 60), w, pad)
        sc.forEachIndexed { i, v ->
            val y = (pad + hd + i * rh).toFloat()
            s.text(zn(i), 40f, 700, pal.ink, L(), pad.toFloat(), y + 46, true)
            s.text("${bd[i]} bpm", 26f, 500, pal.ink2, L(), pad + 82f, y + 44)
            if (v > 0) s.rr(bx, y + 10, max(6.0, (bmax * v / mxv).roundToInt().toDouble()).toFloat(), 44f, 6f, rgb(Stickers.ZONE_RGB[i]))
            val dTxt = if (v > 0) Js.durStr(v / 60) else "–"; val pTxt = "${(v / t * 100).roundToInt()}%"
            when (hz) {
                "dur" -> s.text(dTxt, 40f, 700, pal.ink, R(), (w - pad).toFloat(), y + 46, true)
                "pct" -> s.text(if (v > 0) pTxt else "–", 40f, 700, pal.ink, R(), (w - pad).toFloat(), y + 46, true)
                else -> { s.text(dTxt, 38f, 700, pal.ink, R(), (w - pad - 100).toFloat(), y + 46, true); s.text(pTxt, 30f, 500, pal.ink2, R(), (w - pad).toFloat(), y + 46) }
            }
        }
        return s.bmp
    }

    /** Zona HR sebagai satu bar horizontal bertumpuk; label yang berdempetan digeser dan diberi garis penuntun. */
    fun zoneStack(m: StickerModel, pal: StickerPalette, prefs: StickerPrefs): Bitmap {
        val sc = m.zoneSecs; val t = sc.sum().takeIf { it > 0 } ?: 1.0; val hz = prefs.hz
        val w = 980; val pad = 44; val hd = 78; val bh = 76; val gap = 4; val by = pad + hd
        class Sg(val i: Int, val v: Double) { var w = 0.0; var x = 0.0; var cx = 0.0; var pc = ""; var du = "" }
        val segs = sc.mapIndexedNotNull { i, v -> if (v > 0) Sg(i, v) else null }
        val cw = w - pad * 2 - gap * max(0, segs.size - 1)
        val meter = Sk(10, 10, pal, "off")
        var x = pad.toDouble(); var lw = 0f
        segs.forEach { g ->
            g.w = g.v / t * cw; g.x = x; g.cx = x + g.w / 2; x += g.w + gap
            val pc = (g.v / t * 100).roundToInt(); g.pc = (if (pc < 1) "<1" else pc.toString()) + "%"; g.du = Js.durStr(g.v / 60)
            lw = max(lw, max(meter.tw(zn(g.i), 36f, 700, true), max(meter.tw(g.pc, 32f, 700, true), if (hz == "pct") 0f else meter.tw(g.du, 28f, 500))))
        }
        lw += 18
        val lx = segs.map { it.cx }.toDoubleArray()
        for (a in lx.indices) lx[a] = max(lx[a], if (a > 0) lx[a - 1] + lw else pad + lw / 2.0)
        for (b in lx.indices.reversed()) lx[b] = min(lx[b], if (b < lx.size - 1) lx[b + 1] - lw else w - pad - lw / 2.0)
        val h = by + bh + (if (hz == "both") 134 else 96) + pad
        val s = Sk(w, h, pal, prefs.panel)
        s.head("Zona HR", Js.durStr(t / 60), w, pad)
        segs.forEachIndexed { k, g ->
            s.rr(f(g.x), by.toFloat(), max(4f, f(g.w)), bh.toFloat(), 8f, rgb(Stickers.ZONE_RGB[g.i]))
            val cx = f(lx[k])
            if (abs(cx - g.cx) > 6) s.line(f(g.cx), (by + bh + 6).toFloat(), cx, (by + bh + 24).toFloat(), pal.ink2, 2f)
            s.text(zn(g.i), 36f, 700, pal.ink, C(), cx, (by + bh + 58).toFloat(), true)
            if (hz == "dur") s.text(g.du, 30f, 700, pal.ink2, C(), cx, (by + bh + 96).toFloat(), true)
            else {
                s.text(g.pc, 32f, 700, pal.ink2, C(), cx, (by + bh + 96).toFloat(), true)
                if (hz == "both") s.text(g.du, 28f, 500, pal.ink2, C(), cx, (by + bh + 130).toFloat())
            }
        }
        return s.bmp
    }
}
