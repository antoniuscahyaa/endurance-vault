package com.endurancevault.app.domain

import com.google.gson.JsonObject
import com.google.gson.JsonParser
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Video Trail 3D: kartu ala trail dengan "slab" medan 3D bergaya (lingkaran atau poligon), latar pegunungan senja,
 * profil elevasi yang terisi seiring lari, tanda km / puncak / tanjakan, dan panel data. File ini murni Kotlin
 * (tanpa Android) supaya bisa dites JUnit biasa. Penggambaran ada di `ui/video/Trail*.kt`.
 */
object TrailKeys {
    val SHAPES = listOf("circle", "sq", "hex", "oct")
    val LAYOUTS = listOf("classic", "center", "tiles", "compact")
    val PALETTES = listOf("orange", "lime")
    val BACKGROUNDS = listOf("mount", "plain", "solid", "photo")
    val CARDS = listOf("none", "glass", "solid")
    val METRICS = listOf("pace", "hr", "gain", "time", "cad", "gap", "vam")
    /** Gerak kamera: tetap, dolly masuk, tarik mundur, crane, ikuti pelari, spiral. */
    val CAMERA_MOVES = listOf("static", "dolly", "pullback", "crane", "follow", "spiral")

    fun shapeName(s: String) = when (s) { "sq" -> "Persegi"; "hex" -> "Segi enam"; "oct" -> "Segi delapan"; else -> "Lingkaran" }
    fun layoutName(s: String) = when (s) { "center" -> "Tengah"; "tiles" -> "Kartu 2×2"; "compact" -> "Ringkas"; else -> "Klasik" }
    fun cameraMoveName(s: String) = when (s) {
        "dolly" -> "Dolly masuk"; "pullback" -> "Tarik mundur"; "crane" -> "Crane turun"; "follow" -> "Ikuti pelari"
        "spiral" -> "Spiral"; else -> "Tetap"
    }
    fun cameraMoveHint(s: String) = when (s) {
        "dolly" -> "Mulai dari tampilan penuh, lalu pelan-pelan mendekat ke slab."
        "pullback" -> "Mulai dekat di titik start, lalu menjauh sampai seluruh slab terlihat."
        "crane" -> "Mulai dari sudut rendah dan dekat, lalu naik ke kemiringan yang dipilih."
        "follow" -> "Zoom ke pelari dan kamera terus mengikuti posisinya sepanjang rute."
        "spiral" -> "Slab berputar tambahan sambil kamera pelan-pelan mendekat."
        else -> ""
    }
    fun paletteName(s: String) = when (s) { "lime" -> "Lime neon"; else -> "Oranye neon" }
    fun backgroundName(s: String) = when (s) { "plain" -> "Langit polos"; "solid" -> "Warna polos"; "photo" -> "Foto sendiri"; else -> "Pegunungan senja" }
    fun cardName(s: String) = when (s) { "glass" -> "Kaca"; "solid" -> "Pekat"; else -> "Tanpa kartu" }
    fun metricName(s: String) = when (s) {
        "pace" -> "Pace / kecepatan"; "hr" -> "Detak jantung"; "gain" -> "Naik"; "time" -> "Waktu"
        "cad" -> "Cadence"; "gap" -> "GAP"; "vam" -> "VAM"; else -> s
    }

    /** Sisi poligon: 0 = lingkaran. */
    fun sides(shape: String): Int = when (shape) { "sq" -> 4; "hex" -> 6; "oct" -> 8; else -> 0 }
}

/** Pengaturan video Trail 3D (disimpan antar sesi). */
data class TrailPrefs(
    val aspect: String = "9:16",
    val quality: String = "hd",
    /** Lama rute berjalan (detik); ditambah pengantar dan penutup. */
    val durationSec: Int = 20,
    val palette: String = "orange",
    /** Warna aksen sendiri (#RRGGBB); kosong = ikut palet. */
    val accent: String = "",
    val shape: String = "circle",
    val layout: String = "classic",
    /** Kemiringan kamera dari atas (derajat): 0 = lurus dari atas. */
    val tilt: Int = 55,
    /** Tinggi puncak relief sebagai % diameter cakram. */
    val relief: Int = 20,
    /** Sudut putar awal cakram (derajat) dan putaran tambahan sepanjang lari. */
    val rotation: Int = 0,
    val spin: Int = 0,
    /** Zoom kamera, persen (60..250): 100 = slab pas di kotak adegan. */
    val zoom: Int = 100,
    /**
     * Luas cakupan base (slab), persen: 100 = pas melingkupi rute tanpa sisa, 114 = bawaan (margin 14%).
     * Makin besar, makin banyak medan sekitar rute yang ikut tampil. Tidak bisa lebih kecil dari rute supaya rute tidak terpotong.
     */
    val coverage: Int = 114,
    /** Geser base terhadap rute, persen (-100..100) dari ruang gerak yang tersedia: X ke timur, Z ke selatan. */
    val offX: Int = 0,
    val offZ: Int = 0,
    /** Ratakan tepi base, persen (0..100): 0 = tepi mengikuti medan, 100 = tepi rata (dinding dan bibir slab berbentuk asli). */
    val flatEdge: Int = 0,
    /** Potong vertikal: dinding tegak dari tepi medan turun ke dasar rata (seperti blok), bukan pita setebal tetap yang ikut bergelombang. */
    val blockCut: Boolean = false,
    /** Gerak kamera (lihat [TrailKeys.CAMERA_MOVES]) dan kekuatannya, persen (0..100). */
    val camMove: String = "static",
    val camAmount: Int = 60,
    /** Getaran halus ala kamera genggam, persen (0..100). */
    val shake: Int = 0,
    val bgMode: String = "mount",
    val bgColor: String = "#14100E",
    /** Peredam gelap untuk foto latar (0..85). */
    val bgDim: Int = 35,
    val location: String = "",
    val handle: String = "",
    val showWeather: Boolean = true,
    val showBar: Boolean = true,
    val showKm: Boolean = true,
    val showPeak: Boolean = true,
    val showClimbs: Boolean = true,
    val showZones: Boolean = true,
    val showGrade: Boolean = true,
    val extraRow: Boolean = false,
    val autoMetrics: Boolean = true,
    val metrics: List<String> = listOf("pace", "hr", "gain", "time"),
    val card: String = "none",
    /** Kartu di belakang panel data muncul otomatis hanya bila latarnya terang. */
    val autoContrast: Boolean = false,
    val intro: Boolean = true,
    val summary: Boolean = true,
    /** Naikkan panel supaya tidak tertutup kolom balas Story (hanya 9:16). */
    val safeZone: Boolean = false,
    val bgRender: Boolean = true,
    /** Nama daerah sebagai pin kecil di slab (dari OpenStreetMap) dan jumlah maksimalnya (1..6). */
    val showPlaces: Boolean = true,
    val placeCount: Int = 4,
) {
    fun sanitized(): TrailPrefs = copy(
        placeCount = placeCount.coerceIn(1, 6),
        aspect = if (aspect in RouteVideoFormat.ASPECTS) aspect else "9:16",
        quality = if (quality == "sd") "sd" else "hd",
        durationSec = durationSec.coerceIn(6, 60),
        palette = if (palette in TrailKeys.PALETTES) palette else "orange",
        accent = if (HEX.matches(accent)) accent.uppercase(Locale.US) else "",
        shape = if (shape in TrailKeys.SHAPES) shape else "circle",
        layout = if (layout in TrailKeys.LAYOUTS) layout else "classic",
        tilt = tilt.coerceIn(20, 75),
        relief = relief.coerceIn(5, 60),
        rotation = rotation.coerceIn(-180, 180),
        spin = spin.coerceIn(-360, 360),
        zoom = zoom.coerceIn(MIN_ZOOM, MAX_ZOOM),
        coverage = coverage.coerceIn(MIN_COVERAGE, MAX_COVERAGE),
        offX = offX.coerceIn(-100, 100), offZ = offZ.coerceIn(-100, 100), flatEdge = flatEdge.coerceIn(0, 100),
        camMove = if (camMove in TrailKeys.CAMERA_MOVES) camMove else "static",
        camAmount = camAmount.coerceIn(0, 100), shake = shake.coerceIn(0, 100),
        bgMode = if (bgMode in TrailKeys.BACKGROUNDS) bgMode else "mount",
        bgColor = if (HEX.matches(bgColor)) bgColor.uppercase(Locale.US) else "#14100E",
        bgDim = bgDim.coerceIn(0, 85),
        location = location.take(60),
        handle = handle.take(30),
        metrics = metrics.filter { it in TrailKeys.METRICS }.distinct().take(4).ifEmpty { listOf("pace", "hr", "gain", "time") },
        card = if (card in TrailKeys.CARDS) card else "none",
    )

    fun toJson(): String {
        val o = JsonObject()
        o.addProperty("aspect", aspect); o.addProperty("quality", quality); o.addProperty("durationSec", durationSec)
        o.addProperty("palette", palette); o.addProperty("accent", accent); o.addProperty("shape", shape); o.addProperty("layout", layout)
        o.addProperty("tilt", tilt); o.addProperty("relief", relief); o.addProperty("rotation", rotation); o.addProperty("spin", spin)
        o.addProperty("zoom", zoom); o.addProperty("coverage", coverage); o.addProperty("offX", offX); o.addProperty("offZ", offZ); o.addProperty("flatEdge", flatEdge); o.addProperty("blockCut", blockCut)
        o.addProperty("camMove", camMove); o.addProperty("camAmount", camAmount); o.addProperty("shake", shake)
        o.addProperty("bgMode", bgMode); o.addProperty("bgColor", bgColor); o.addProperty("bgDim", bgDim)
        o.addProperty("location", location); o.addProperty("handle", handle); o.addProperty("showWeather", showWeather)
        o.addProperty("showBar", showBar); o.addProperty("showKm", showKm); o.addProperty("showPeak", showPeak)
        o.addProperty("showClimbs", showClimbs); o.addProperty("showZones", showZones); o.addProperty("showGrade", showGrade)
        o.addProperty("extraRow", extraRow); o.addProperty("autoMetrics", autoMetrics)
        o.addProperty("metrics", metrics.joinToString(","))
        o.addProperty("card", card); o.addProperty("autoContrast", autoContrast); o.addProperty("intro", intro)
        o.addProperty("summary", summary); o.addProperty("safeZone", safeZone); o.addProperty("bgRender", bgRender)
        o.addProperty("showPlaces", showPlaces); o.addProperty("placeCount", placeCount)
        return o.toString()
    }

    companion object {
        private val HEX = Regex("#[0-9a-fA-F]{6}")
        const val MIN_ZOOM = 60
        const val MAX_ZOOM = 250
        const val MIN_COVERAGE = 100
        const val MAX_COVERAGE = 250

        fun fromJson(s: String?): TrailPrefs {
            val d = TrailPrefs()
            if (s.isNullOrBlank()) return d
            val o = runCatching { JsonParser.parseString(s).asJsonObject }.getOrNull() ?: return d
            fun str(k: String, def: String) = runCatching { o.get(k)?.takeIf { !it.isJsonNull }?.asString }.getOrNull() ?: def
            fun int(k: String, def: Int) = runCatching { o.get(k)?.takeIf { !it.isJsonNull }?.asInt }.getOrNull() ?: def
            fun bool(k: String, def: Boolean) = runCatching { o.get(k)?.takeIf { !it.isJsonNull }?.asBoolean }.getOrNull() ?: def
            return TrailPrefs(
                aspect = str("aspect", d.aspect), quality = str("quality", d.quality), durationSec = int("durationSec", d.durationSec),
                palette = str("palette", d.palette), accent = str("accent", d.accent), shape = str("shape", d.shape),
                layout = str("layout", d.layout), tilt = int("tilt", d.tilt), relief = int("relief", d.relief),
                rotation = int("rotation", d.rotation), spin = int("spin", d.spin),
                zoom = int("zoom", d.zoom),
                coverage = int("coverage", d.coverage), offX = int("offX", d.offX), offZ = int("offZ", d.offZ), flatEdge = int("flatEdge", d.flatEdge), blockCut = bool("blockCut", d.blockCut), camMove = str("camMove", d.camMove), camAmount = int("camAmount", d.camAmount), shake = int("shake", d.shake),
                bgMode = str("bgMode", d.bgMode),
                bgColor = str("bgColor", d.bgColor), bgDim = int("bgDim", d.bgDim), location = str("location", d.location),
                handle = str("handle", d.handle), showWeather = bool("showWeather", d.showWeather), showBar = bool("showBar", d.showBar),
                showKm = bool("showKm", d.showKm), showPeak = bool("showPeak", d.showPeak), showClimbs = bool("showClimbs", d.showClimbs),
                showZones = bool("showZones", d.showZones), showGrade = bool("showGrade", d.showGrade), extraRow = bool("extraRow", d.extraRow),
                autoMetrics = bool("autoMetrics", d.autoMetrics),
                metrics = str("metrics", d.metrics.joinToString(",")).split(",").map { it.trim() }.filter { it.isNotEmpty() },
                card = str("card", d.card), autoContrast = bool("autoContrast", d.autoContrast), intro = bool("intro", d.intro),
                summary = bool("summary", d.summary), safeZone = bool("safeZone", d.safeZone), bgRender = bool("bgRender", d.bgRender),
                showPlaces = bool("showPlaces", d.showPlaces), placeCount = int("placeCount", d.placeCount),
            ).sanitized()
        }
    }
}

/** Kotak dalam piksel (kiri, atas, lebar, tinggi). */
class TrailBox(val x: Float, val y: Float, val w: Float, val h: Float)

/** Hasil tata letak kartu Trail untuk satu ukuran bingkai (satuan piksel bingkai; [scene] relatif ke bingkai penuh). */
class TrailLay(
    val k: Float, val land: Boolean, val tiltRad: Double,
    val hdr: TrailBox, val chart: TrailBox, val stats: TrailBox, val scene: TrailBox,
    /** Diameter cakram (piksel), pusatnya relatif ke [scene], dan tebal dinding (piksel). */
    val d: Float, val cx: Float, val cy: Float, val wall: Float,
)

object TrailLayout {
    /** Tinggi isi panel data (satuan k) menurut layout; [noBar] = tanpa bar progres sehingga panel lebih pendek. */
    fun slH(layout: String, noBar: Boolean): Int {
        val (a, b) = when (layout) { "center" -> 182 to 30; "tiles" -> 206 to 30; "compact" -> 124 to 28; else -> 170 to 30 }
        return a - if (noBar) b else 0
    }

    /** Apakah panel data memakai ruang kartu (kartu kaca/pekat atau kontras otomatis). */
    fun cardSpace(p: TrailPrefs): Boolean = p.card == "glass" || p.card == "solid" || p.autoContrast

    fun compute(w: Int, h: Int, p: TrailPrefs): TrailLay {
        val k = min(w, h) / 720f
        val th = Math.toRadians(p.tilt.toDouble())
        val ct = cos(th).toFloat(); val sn = sin(th).toFloat()
        val rel = p.relief / 100f
        val wall = 0.045f
        val xe = if (p.extraRow) 64f * k else 0f
        val noBar = !p.showBar
        val dd = (slH(p.layout, noBar) - 170) * k
        val mg = if (p.layout != "classic" || cardSpace(p)) 16f * k else 0f
        val sx = if (p.safeZone && w <= h && h.toFloat() / w > 1.5f) 120f * k else 0f
        val land = w > h
        val hdr: TrailBox; val chart: TrailBox; val stats: TrailBox; val scene: TrailBox
        val wf = w.toFloat(); val hf = h.toFloat()
        fun r(v: Float) = v.roundToInt().toFloat()
        if (land) {
            hdr = TrailBox(40 * k, 58 * k, wf * .46f, 0f)
            chart = TrailBox(40 * k, r(96 * k), wf * .46f, r(200 * k))
            stats = TrailBox(40 * k, r(hf - 190 * k - xe - dd), wf * .46f, r(170 * k + xe + dd))
            scene = TrailBox(r(wf * .5f), r(hf * .05f), r(wf * .5f), r(hf * .9f))
        } else if (hf / wf > 1.5f) {
            val cy = 300 * k; val ch = 190 * k
            val sy = r(hf - 220 * k - xe - dd - sx); val sc = r(cy + ch - 135 * k)
            hdr = TrailBox(40 * k, 80 * k, wf - 80 * k, 0f)
            chart = TrailBox(40 * k, r(cy), wf - 80 * k, r(ch))
            stats = TrailBox(0f, sy, wf, r(170 * k + xe + dd))
            scene = TrailBox(0f, sc, wf, sy - sc - r(18 * k))
        } else {
            val cy2 = 52 * k; val ch2 = 150 * k
            val sy2 = r(hf - 170 * k - xe - dd - mg); val sc2 = r(cy2 + ch2 - 80 * k)
            hdr = TrailBox(40 * k, 38 * k, wf - 80 * k, 0f)
            chart = TrailBox(40 * k, r(cy2), wf - 80 * k, r(ch2))
            stats = TrailBox(0f, sy2, wf, r(160 * k + xe + dd + mg))
            scene = TrailBox(0f, sc2, wf, sy2 - sc2 - r(14 * k))
        }
        val dia = min(scene.w * .89f, (scene.h - 6 * k) / (ct + rel * sn + wall)).coerceAtLeast(40f)
        val cx = scene.w / 2
        val cyy = scene.h - 4 * k - dia * (ct / 2 + wall)
        return TrailLay(k, land, th, hdr, chart, stats, scene, dia, cx, cyy, dia * wall)
    }
}

class TrailCircle(val x: Float, val y: Float, val r: Float)

class TrailRect(val x: Float, val y: Float, val w: Float, val h: Float)

class TrailClimb(val k0: Double, val k1: Double, val gain: Double, val len: Double, val avg: Double, val n: Int)

/** Profil elevasi sepanjang jarak ([ele] merata dari 0 sampai [totalKm]). */
class TrailProfile(val ele: DoubleArray, val totalKm: Double) {
    val lo: Double; val hi: Double; val avg: Double; val kHi: Double

    init {
        var l = Double.MAX_VALUE; var h = -Double.MAX_VALUE; var s = 0.0; var kh = 0.0
        for (i in ele.indices) {
            val v = ele[i]
            s += v
            if (v < l) l = v
            if (v > h) { h = v; kh = totalKm * i / max(1, ele.size - 1) }
        }
        lo = l; hi = h; avg = if (ele.isEmpty()) 0.0 else s / ele.size; kHi = kh
    }

    fun interp(km: Double): Double {
        if (ele.size < 2) return ele.firstOrNull() ?: 0.0
        val f = (km / totalKm.coerceAtLeast(1e-9)).coerceIn(0.0, 1.0) * (ele.size - 1)
        val i = min(ele.size - 2, floor(f).toInt())
        val t = f - i
        return ele[i] + (ele[i + 1] - ele[i]) * t
    }
}

object TrailGeo {
    /** Lingkaran pelingkup (Ritter + pelebaran); jari-jari sudah diberi margin 14%. */
    fun circle(xs: FloatArray, ys: FloatArray): TrailCircle {
        val n0 = xs.size
        if (n0 == 0) return TrailCircle(0f, 0f, 1f)
        val st = max(1, n0 / 400)
        val px = ArrayList<Float>(); val py = ArrayList<Float>()
        var i = 0
        while (i < n0) { px.add(xs[i]); py.add(ys[i]); i += st }
        px.add(xs[n0 - 1]); py.add(ys[n0 - 1])
        val n = px.size
        var a = 0; var b = 0; var best = -1f
        for (q in 0 until n) { val d = hypot(px[q] - px[0], py[q] - py[0]); if (d > best) { best = d; a = q } }
        best = -1f
        for (q in 0 until n) { val d = hypot(px[q] - px[a], py[q] - py[a]); if (d > best) { best = d; b = q } }
        var cx = (px[a] + px[b]) / 2; var cy = (py[a] + py[b]) / 2; var r = best / 2
        for (pass in 0 until 3) for (q in 0 until n) {
            val d = hypot(px[q] - cx, py[q] - cy)
            if (d > r) { val nr = (r + d) / 2; val f = (nr - r) / d; cx += (px[q] - cx) * f; cy += (py[q] - cy) * f; r = nr }
        }
        for (q in 0 until n) { val d = hypot(px[q] - cx, py[q] - cy); if (d > r) r = d }
        return TrailCircle(cx, cy, max(r * 1.14f, 1e-3f))
    }

    /** Interval garis kontur "bulat" (1, 2, 5 × 10^n) terdekat di atas [v]. */
    fun nice(v: Double): Double {
        val p = 10.0.pow(floor(ln(max(v, 1e-6)) / ln(10.0)))
        val f = v / p
        return (if (f <= 1) 1.0 else if (f <= 2) 2.0 else if (f <= 5) 5.0 else 10.0) * p
    }

    fun smooth(x: Double): Double { val t = x.coerceIn(0.0, 1.0); return t * t * (3 - 2 * t) }

    /** Alpha masuk/keluar label aktif di [k0, k1]: naik halus [m] km setelah k0, turun halus [m] km sebelum k1. */
    fun fade(km: Double, k0: Double, k1: Double, m: Double): Double = smooth((km - k0) / m) * smooth((k1 - km) / m)

    /** Langkah penanda km: 1, 2, 5, 10, ... sehingga paling banyak 10 penanda. */
    fun kmStep(totalKm: Double): Int {
        for (c in intArrayOf(1, 2, 5, 10, 20, 50, 100)) if (totalKm / c <= 10) return c
        return 100
    }

    /**
     * Penempatan label tanpa tabrakan: kandidat pertama yang tidak menimpa label yang sudah ada (jarak [gap]); bila semua
     * menimpa, yang tumpang tindihnya paling kecil. Hasil dimasukkan ke [placed].
     */
    fun place(placed: MutableList<TrailRect>, cands: List<TrailRect>, gap: Float): TrailRect? {
        var best: TrailRect? = null; var bo = Float.MAX_VALUE
        for (c in cands) {
            var o = 0f
            for (p in placed) {
                val ox = min(c.x + c.w + gap, p.x + p.w) - max(c.x - gap, p.x)
                val oy = min(c.y + c.h + gap, p.y + p.h) - max(c.y - gap, p.y)
                if (ox > 0 && oy > 0) o += ox * oy
            }
            if (o < bo - 1e-6f) { bo = o; best = c; if (o == 0f) break }
        }
        best?.let { placed.add(TrailRect(it.x, it.y, it.w, it.h)) }
        return best
    }

    /** Jarak ke tepi poligon (satuan apotema) pada arah [th]; lingkaran = 1. */
    fun edgeR(n: Int, th: Double): Double {
        if (n == 0) return 1.0
        var m = -1e9
        for (i in 0 until n) m = max(m, cos(th - i * 2 * PI / n))
        return 1.0 / m
    }

    /** "Jari-jari" poligon di (dx, dy) dibagi apotema: <= 1 berarti di dalam. */
    fun metric(n: Int, dx: Double, dy: Double): Double {
        if (n == 0) return hypot(dx, dy)
        var m = -1e9
        for (i in 0 until n) { val a = i * 2 * PI / n; m = max(m, dx * cos(a) + dy * sin(a)) }
        return m
    }

    /** Ukuran poligon dalam satuan apotema (1 / cos(pi/n) di sudut). */
    fun outer(n: Int): Double = if (n == 0) 1.0 else 1.0 / cos(PI / n)

    /** Tanjakan dari profil: gradien terhaluskan (±100 m) >= 3%, celah <= 150 m digabung, ujung datar dipangkas; lolos bila naik >= 40 m, >= 0,4 km, rata-rata >= 4%. */
    fun climbs(p: TrailProfile?): List<TrailClimb> {
        val out = ArrayList<TrailClimb>()
        if (p == null || p.totalKm <= 0.3 || p.ele.size < 3) return out
        val tk = p.totalKm
        val nn = max(30, min(600, (tk / .05).roundToInt()))
        val ds = tk / nn
        val e = DoubleArray(nn + 1) { p.interp(ds * it) }
        val kk = DoubleArray(nn + 1) { ds * it }
        val w = max(1, (.1 / ds).roundToInt()); val gap = max(1, (.15 / ds).roundToInt())
        val up = BooleanArray(nn + 1) { i ->
            val a0 = max(0, i - w); val b0 = min(nn, i + w)
            (e[b0] - e[a0]) / ((kk[b0] - kk[a0]) * 1000) * 100 >= 3
        }
        var i = 0
        while (i <= nn) {
            if (!up[i]) { i++; continue }
            var a = i; var b = i; var miss = 0
            var j = i + 1
            while (j <= nn) {
                if (up[j]) { b = j; miss = 0 } else { miss++; if (miss > gap) break }
                j++
            }
            i = b + 1
            val step = (e[b] - e[a]) / max(1, b - a)
            while (a < b && e[a + 1] - e[a] < step * .4) a++
            while (b > a && e[b] - e[b - 1] < step * .4) b--
            val g = e[b] - e[a]; val len = kk[b] - kk[a]
            if (g >= 40 && len >= .4 && g / (len * 1000) * 100 >= 4) out.add(TrailClimb(kk[a], kk[b], g, len, g / (len * 1000) * 100, out.size + 1))
        }
        return out
    }
}

/** Data tambahan untuk video Trail yang diturunkan dari jejak: profil, tanjakan, GAP kumulatif, VAM, zona HR, cuaca. */
class TrailData(val track: RouteVideoTrack, val weather: ActWeather?, hrLo: List<Int>?) {
    val lo: List<Int>? = hrLo?.takeIf { it.size >= 5 && it.any { v -> v > 0 } }
    val profile: TrailProfile? =
        if (track.hasEle && track.totalM > 100) TrailProfile(track.profileSamples(240), track.totalM / 1000.0) else null
    val climbs: List<TrailClimb> = TrailGeo.climbs(profile)
    val totalKm: Double = track.totalM / 1000.0

    /** Jarak setara datar (m) kumulatif menurut biaya Minetti, untuk GAP rata-rata sejauh ini. */
    private val gapEq: DoubleArray? = if (track.hasEle && !track.bike) {
        val a = DoubleArray(track.n)
        for (i in 1 until track.n) {
            val d = track.dist[i] - track.dist[i - 1]
            val g = track.gradeS[i].takeIf { it.isFinite() } ?: 0.0
            val f = ActInsights.minettiCost(g / 100.0) / 3.6
            a[i] = a[i - 1] + d * (if (f > 0) f else 1.0)
        }
        a
    } else null

    /** GAP rata-rata (menit/km) sampai [st]; null bila belum cukup jarak atau tanpa elevasi. */
    fun gapPace(st: FrameStats): Double? {
        val eq = gapEq ?: return null
        val i = st.idx.coerceIn(0, track.n - 1)
        if (eq[i] < 50.0 || st.sec <= 0) return null
        return (st.sec / 60.0) / (eq[i] / 1000.0)
    }

    /** VAM (m/jam) pada jendela ±30 detik di sekitar [st]; null tanpa elevasi. */
    fun vam(st: FrameStats): Int? {
        if (!track.hasEle) return null
        val i = st.idx.coerceIn(0, track.n - 1)
        var k = i; var j = i
        while (k > 0 && track.sec[i] - track.sec[k] < 30) k--
        while (j < track.n - 1 && track.sec[j] - track.sec[i] < 30) j++
        val dt = (track.sec[j] - track.sec[k]).toDouble()
        if (dt < 10.0) return null
        return ((track.eleS[j] - track.eleS[k]) / dt * 3600.0).takeIf { it.isFinite() }?.let { max(0.0, it).roundToInt() }
    }

    /** HR rata-rata di sekitar jarak [km]; null bila tidak ada. */
    fun hrAtKm(km: Double): Int? {
        val i = track.indexAtDist(km * 1000.0)
        var s = 0; var c = 0
        for (q in max(0, i - 3)..min(track.n - 1, i + 3)) if (track.hr[q] >= 30) { s += track.hr[q]; c++ }
        return if (c == 0) null else (s.toDouble() / c).roundToInt()
    }

    val hasHr: Boolean = track.hr.any { it >= 30 }

    /** Zona HR 0..4 untuk [bpm]; null bila batas zona tidak diketahui. */
    fun zone(bpm: Int?): Int? {
        val l = lo ?: return null
        if (bpm == null || bpm <= 0) return null
        return Zones.zoneOf(bpm, l)
    }

    fun weatherText(): String? {
        val w = weather ?: return null
        if (!w.tempC.isFinite()) return null
        val t = "${w.tempC.roundToInt()}°C"
        val lab = ActInsights.weatherLabel(w.code)
        return if (lab != null) "$t · $lab" else t
    }
}

/** Satu kolom data di panel: label, nilai, satuan. */
class TrailCol(val label: String, val value: String, val unit: String)

object TrailText {
    fun f(x: Double, dp: Int): String = String.format(Locale.US, "%.${dp}f", x).replace('.', ',')

    /** Waktu: jam:menit (JAM) bila >= 1 jam, selain itu menit:detik (MNT). */
    fun time(sec: Int): Pair<String, String> {
        val s = max(0, sec); val h = s / 3600; val m = s % 3600 / 60; val x = s % 60
        fun p2(v: Int) = if (v < 10) "0$v" else v.toString()
        return if (h > 0) "${p2(h)}:${p2(m)}" to "JAM" else "${p2(m)}:${p2(x)}" to "MNT"
    }

    /** Satu kolom data untuk [id]; nilai "–" bila datanya tidak ada. [live] false = ringkasan akhir (rata-rata). */
    fun metric(id: String, st: FrameStats, data: TrailData, live: Boolean): TrailCol {
        val bike = data.track.bike
        return when (id) {
            "pace" -> {
                val c = RouteVideoText.cell("pace", st, live, bike)!!
                TrailCol(if (bike) (if (live) "KECEPATAN" else "KEC. RATA2") else (if (live) "PACE" else "PACE RATA2"), c.value, c.unit.uppercase(Locale.US))
            }
            "hr" -> TrailCol(if (live) "DENYUT" else "RATA2 HR", st.hr?.toString() ?: "–", "BPM")
            "gain" -> TrailCol("NAIK", "+" + st.gain.roundToInt(), "M")
            "cad" -> TrailCol("CADENCE", st.cad?.toString() ?: "–", "SPM")
            "gap" -> {
                val g = if (live) data.gapPace(st) else data.gapPace(data.track.statsAt(1.0, true))
                TrailCol("GAP", g?.let { Js.paceStr(it) } ?: "–", "/KM")
            }
            "vam" -> TrailCol("VAM", if (live) data.vam(st)?.toString() ?: "–" else "–", "M/J")
            else -> { val t = time(st.sec); TrailCol("WAKTU", t.first, t.second) }
        }
    }

    /** Kolom panel. Otomatis: pace, denyut, naik, waktu (yang tak ada datanya dilewati); pilihan sendiri: slot [TrailPrefs.metrics]. */
    fun columns(p: TrailPrefs, st: FrameStats, data: TrailData, live: Boolean): List<TrailCol> {
        if (!p.autoMetrics) return p.metrics.map { metric(it, st, data, live) }
        val out = ArrayList<TrailCol>()
        out.add(metric("pace", st, data, live))
        if (data.hasHr) out.add(metric("hr", st, data, live))
        if (data.track.hasEle) out.add(metric("gain", st, data, live))
        out.add(metric("time", st, data, live))
        return out
    }

    /** Baris tambahan (VAM / GAP, cadence, naik); hanya yang datanya ada. Pasangan (nilai, satuan). */
    fun extras(st: FrameStats, data: TrailData, live: Boolean): List<Pair<String, String>> {
        val a = data.track
        val out = ArrayList<Pair<String, String>>()
        val climby = data.totalKm > 0 && a.gainCum.last() / data.totalKm >= 30
        val vam = if (live) data.vam(st) else null
        val gap = data.gapPace(if (live) st else a.statsAt(1.0, true))
        if (climby) { if (vam != null) out.add(vam.toString() to "VAM M/J") else if (gap != null) out.add(Js.paceStr(gap) to "GAP /KM") }
        else { if (gap != null) out.add(Js.paceStr(gap) to "GAP /KM") else if (vam != null) out.add(vam.toString() to "VAM M/J") }
        if ((st.cad ?: 0) > 0) out.add(st.cad.toString() to "CAD SPM")
        if (a.hasEle) out.add(("+" + st.gain.roundToInt()) to "NAIK M")
        return out
    }
}

/** Linimasa video Trail: pengantar, lari, lalu penutup (ringkasan). Murni fungsi supaya pratinjau dan hasil identik. */
object TrailTimeline {
    const val FPS = 30
    private const val INTRO_SEC = 0.8
    private const val SUMMARY_FADE = 0.7

    class Pt(
        val t: Double,
        /** Bagian jarak (0..1) yang sudah ditempuh. */
        val frac: Double,
        /** Sudut putar cakram (derajat). */
        val azimuth: Double,
        /** Animasi panel masuk 0..1. */
        val panelIn: Double,
        /** Pemudaran statistik berjalan -> ringkasan, 0..1. */
        val summaryMix: Double,
        /** Pose kamera (zoom, kemiringan, ikuti pelari) pada saat ini; sudut putar tambahannya sudah masuk ke [azimuth]. */
        val cam: TrailCam = TrailCam(),
    )

    fun lead(p: TrailPrefs): Double = if (p.intro) INTRO_SEC else 0.0
    fun tail(p: TrailPrefs): Double = if (p.summary) 3.4 else 0.8
    fun total(p: TrailPrefs): Double = lead(p) + p.durationSec + tail(p)
    fun frames(p: TrailPrefs): Int = max(2, ceil(total(p) * FPS).toInt())

    fun at(t: Double, p: TrailPrefs): Pt {
        val run = p.durationSec.toDouble()
        val u = ((t - lead(p)) / run).coerceIn(0.0, 1.0)
        val ia = if (p.intro) { val q = (t / INTRO_SEC).coerceIn(0.0, 1.0); 1 - (1 - q).pow(3) } else 1.0
        val fx = if (p.summary) ((t - lead(p) - run) / SUMMARY_FADE).coerceIn(0.0, 1.0) else 0.0
        // Setelah lari selesai kamera kembali ke tampilan penuh supaya kartu ringkasan tidak tertutup zoom.
        val ou = ((t - lead(p) - run) / OUTRO_SEC).coerceIn(0.0, 1.0)
        val cam = TrailCamera.at(u, ou, t, p)
        return Pt(t, u, p.rotation + p.spin * u + cam.azDeg, ia, fx, cam)
    }

    private const val OUTRO_SEC = 0.9
}

/** Pose kamera Trail: [zoom] pengali (1 = pas), [tiltDeg] tambahan kemiringan dari atas, [follow] 0..1 bobot ikuti pelari, [azDeg] tambahan putaran. */
class TrailCam(val zoom: Double = 1.0, val tiltDeg: Double = 0.0, val follow: Double = 0.0, val azDeg: Double = 0.0)

/** Gerak kamera Trail sebagai fungsi murni (pratinjau dan hasil render sama). */
object TrailCamera {
    private fun smooth(x: Double): Double { val t = x.coerceIn(0.0, 1.0); return t * t * (3 - 2 * t) }

    /**
     * Pose pada kemajuan lari [u] (0..1), [ou] penutup 0..1 (kamera kembali ke tampilan penuh), dan detik video [sec].
     * Zoom dasar dari pengaturan selalu berlaku; gerak sinematik menambah zoom/kemiringan/ikuti di atasnya.
     */
    fun at(u: Double, ou: Double, sec: Double, p: TrailPrefs): TrailCam {
        val a = p.camAmount.coerceIn(0, 100) / 100.0
        val sm = smooth(u)
        val relax = 1.0 - smooth(ou)
        var extraZoom = 0.0; var tilt = 0.0; var follow = 0.0; var az = 0.0
        when (p.camMove) {
            "dolly" -> { extraZoom = 0.9 * a * sm; follow = 0.35 * a * sm }
            "pullback" -> { extraZoom = 0.9 * a * (1.0 - sm); follow = 0.35 * a * (1.0 - sm) }
            "crane" -> { tilt = 28.0 * a * (1.0 - sm); extraZoom = 0.35 * a * (1.0 - sm) }
            "follow" -> { val k = smooth(u / 0.15); extraZoom = 1.1 * a * k; follow = a * k }
            "spiral" -> { extraZoom = 0.8 * a * sm; follow = 0.4 * a * sm; az = 160.0 * a * sm }
        }
        val base = p.zoom.coerceIn(TrailPrefs.MIN_ZOOM, TrailPrefs.MAX_ZOOM) / 100.0
        val (dAz, dTilt, dZoom) = RouteVideoCamera.handheld(sec, p.shake.coerceIn(0, 100) / 100.0)
        return TrailCam(
            zoom = (base * (1.0 + extraZoom * relax) * (1.0 + dZoom)).coerceIn(0.4, 4.0),
            tiltDeg = tilt * relax + dTilt,
            follow = (follow * relax).coerceIn(0.0, 1.0),
            azDeg = az + dAz,
        )
    }
}
