package com.endurancevault.app.ui.video

import android.content.Context
import com.endurancevault.app.domain.RouteVideoPrefs

/** Penyimpanan pengaturan video rute 3D (termasuk posisi dan ukuran tiap panel). */
class RouteVideoPrefsStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("route_video_prefs", Context.MODE_PRIVATE)
    fun load(): RouteVideoPrefs = RouteVideoPrefs.fromJson(sp.getString("json", null))
    fun save(p: RouteVideoPrefs) { sp.edit().putString("json", p.sanitized().toJson()).apply() }
}
