package com.endurancevault.app.data

import android.content.ContentResolver
import android.net.Uri
import com.endurancevault.app.domain.ActImportException
import com.endurancevault.app.domain.ParsedTrack
import com.endurancevault.app.domain.Pt
import com.google.gson.JsonObject
import com.google.gson.JsonParseException
import com.google.gson.JsonParser
import com.google.gson.stream.JsonReader
import com.google.gson.stream.JsonToken
import net.lingala.zip4j.ZipFile
import net.lingala.zip4j.exception.ZipException
import net.lingala.zip4j.io.inputstream.ZipInputStream
import java.io.EOFException
import java.io.File
import java.io.FilterInputStream
import java.io.InputStream
import java.io.InputStreamReader
import java.time.ZoneId
import java.time.ZoneOffset
import kotlin.math.abs

/**
 * Ekspor data pribadi Huawei Health ("HUAWEI_HEALTH_<tanggal>.zip", dari Pusat Privasi Huawei).
 * Zip ini biasanya dienkripsi (kata sandi dikirim Huawei lewat SMS/email) dan berisi banyak folder besar.
 * Yang dibaca di sini hanya "Motion path detail data": berkas motion_path_detail_data*.json berisi satu larik
 * rekaman latihan, masing-masing dengan ringkasan (summaryData) dan jejak per detik (detailData).
 */
object HuaweiHealthZip {
    /** Kata sandi zip salah, atau zip dienkripsi tetapi kata sandi kosong. */
    class WrongPasswordException : Exception("kata sandi zip salah")

    class Stats {
        var entries = 0
        var jsonFiles = 0
        var records = 0
        var badFiles = 0
    }

    private val MOTION_JSON = Regex("motion[ _]path[ _]detail[ _]data[^/]*\\.json$", RegexOption.IGNORE_CASE)
    private const val MAX_NESTED_ZIP_DEPTH = 2

    /** Nama entri (dengan jalur) adalah berkas JSON jalur gerak. Berkas xlsx deskripsi tidak ikut. */
    fun isMotionJson(entryName: String): Boolean = MOTION_JSON.containsMatchIn(entryName.replace('\\', '/'))

    /** Penutupan aliran pembungkus tidak menutup aliran zip di bawahnya (dipakai untuk zip di dalam zip dan pembaca JSON). */
    private class NoClose(input: InputStream) : FilterInputStream(input) {
        override fun close() {}
    }

    /**
     * Baca semua rekaman jalur gerak di [uri] dan panggil [onRecord] satu per satu (tidak ada yang ditahan di memori).
     * Jalur cepat: zip4j `ZipFile` lewat /proc/self/fd, hanya membuka entri yang perlu, tidak membaca folder Health detail
     * (ratusan MB) sama sekali. Bila penyedia berkas tidak mendukungnya, jatuh ke pembacaan berurutan.
     * @throws WrongPasswordException bila zip dienkripsi dan kata sandi salah
     */
    suspend fun scan(
        resolver: ContentResolver, uri: Uri, password: CharArray?,
        onRecord: suspend (JsonObject) -> Unit,
    ): Stats {
        val stats = Stats()
        var fastFailed: Exception? = null
        val pfd = try { resolver.openFileDescriptor(uri, "r") } catch (e: Exception) { null }
        if (pfd != null) {
            try {
                scanFile(File("/proc/self/fd/${pfd.fd}"), password, onRecord, stats, 0)
                return stats
            } catch (e: WrongPasswordException) {
                throw e
            } catch (e: ZipException) {
                // Jalur cepat gagal (mis. berkas bukan zip biasa): coba pembacaan berurutan di bawah.
                fastFailed = e
            } catch (e: java.io.IOException) {
                fastFailed = e
            } finally {
                runCatching { pfd.close() }
            }
        }
        val input = resolver.openInputStream(uri)
            ?: throw ActImportException(fastFailed?.message ?: "zip tidak bisa dibuka")
        input.use { scanStream(it, password, onRecord, stats, 0) }
        return stats
    }

    private suspend fun scanFile(
        file: File, password: CharArray?, onRecord: suspend (JsonObject) -> Unit, stats: Stats, depth: Int,
    ) {
        try {
            val zf = ZipFile(file, password)
            for (h in zf.fileHeaders) {
                val name = h.fileName ?: continue
                if (name.endsWith("/")) continue
                stats.entries++
                if (isMotionJson(name)) {
                    stats.jsonFiles++
                    zf.getInputStream(h).use { readRecords(it, stats, onRecord) }
                } else if (name.endsWith(".zip", ignoreCase = true) && depth < MAX_NESTED_ZIP_DEPTH) {
                    zf.getInputStream(h).use { scanStream(NoClose(it), password, onRecord, stats, depth + 1) }
                }
            }
        } catch (e: ZipException) {
            throw translate(e)
        }
    }

    private suspend fun scanStream(
        input: InputStream, password: CharArray?, onRecord: suspend (JsonObject) -> Unit, stats: Stats, depth: Int,
    ) {
        val zis = ZipInputStream(input, password)
        try {
            while (true) {
                val h = zis.nextEntry ?: break
                val name = h.fileName ?: continue
                if (name.endsWith("/")) continue
                stats.entries++
                if (isMotionJson(name)) {
                    stats.jsonFiles++
                    readRecords(NoClose(zis), stats, onRecord)
                } else if (name.endsWith(".zip", ignoreCase = true) && depth < MAX_NESTED_ZIP_DEPTH) {
                    scanStream(NoClose(zis), password, onRecord, stats, depth + 1)
                }
                // Entri lain (folder Health detail, Sample sequence, dst.) dilewati oleh zip4j saat nextEntry berikutnya.
            }
        } catch (e: ZipException) {
            throw translate(e)
        } finally {
            runCatching { zis.close() }
        }
    }

    private fun translate(e: ZipException): Exception =
        if (e.type == ZipException.Type.WRONG_PASSWORD) WrongPasswordException() else e

    private fun zipCause(t: Throwable?): ZipException? {
        var c = t
        var n = 0
        while (c != null && n++ < 8) { if (c is ZipException) return c; c = c.cause }
        return null
    }

    /** Larik JSON dibaca per rekaman (JsonReader), jadi berkas puluhan MB tidak dimuat utuh. */
    private suspend fun readRecords(input: InputStream, stats: Stats, onRecord: suspend (JsonObject) -> Unit) {
        val reader = JsonReader(InputStreamReader(input, Charsets.UTF_8))
        try {
            if (reader.peek() != JsonToken.BEGIN_ARRAY) { stats.badFiles++; return }
            reader.beginArray()
            while (reader.hasNext()) {
                val el = JsonParser.parseReader(reader)
                if (el.isJsonObject) { stats.records++; onRecord(el.asJsonObject) }
            }
        } catch (e: JsonParseException) {
            // Gson membungkus IOException dari aliran zip (mis. kata sandi salah) sebagai JsonIOException.
            val z = zipCause(e)
            if (z != null) throw translate(z)
            stats.badFiles++
        } catch (e: EOFException) {
            stats.badFiles++
        } catch (e: java.io.IOException) {
            val z = zipCause(e)
            if (z != null) throw translate(z)
            stats.badFiles++
        } catch (e: IllegalStateException) {
            stats.badFiles++
        }
    }
}

/**
 * Satu rekaman Huawei "motion path" menjadi [ParsedTrack] untuk ActBuilder.
 * Format detailData: baris "tp=<tag>;k=<kunci>;v=<nilai>;" (lihat Motion_path_detail_data-Data_Field_Description.xlsx):
 *  - tp=lbs  : lat, lon, alt, t (detik epoch, notasi ilmiah mis. 1.791626734E9). Titik terakhir sering penanda tak valid 90,-80.
 *  - tp=h-r  : k = epoch milidetik, v = detak jantung (-1 = tak valid)
 *  - tp=alti : k = epoch milidetik, v = ketinggian meter (tiap 5 dtk). Alt di baris lbs biasanya 0, jadi tidak dipakai.
 *  - tp=cad  : k = epoch milidetik, v = kadens (0 pada sepeda tanpa sensor)
 * Catatan satuan di summaryData: creepingWave dan mTotalDescent dalam desimeter, totalCalories dalam kal (bukan kkal).
 */
object HuaweiMotionPath {
    class Converted(val track: ParsedTrack, val zone: ZoneId, val startMs: Long)

    /** Rekaman sengaja dilewati (bukan galat): jenis olahraga belum didukung atau tidak ada jejak GPS. */
    class Skip(val reason: String) : Exception(reason)

    /**
     * Kode jenis olahraga Huawei menjadi nama olahraga yang dipahami ActBuilder. Kolom subType dan sportType di berkas deskripsi
     * memakai dua rangkaian kode (4/258 lari, 3/259 sepeda), jadi keduanya diterima.
     */
    fun sportOf(code: Int): String? = when (code) {
        4, 258, 118, 280, 221, 227 -> "running"
        3, 259 -> "biking"
        2, 260, 282 -> "hiking"
        else -> null
    }

    private fun JsonObject.str(k: String): String? = get(k)?.takeIf { it.isJsonPrimitive }?.asString
    private fun JsonObject.long(k: String): Long? = str(k)?.toDoubleOrNull()?.toLong()
    private fun JsonObject.int(k: String): Int? = str(k)?.toDoubleOrNull()?.toInt()

    fun startMs(rec: JsonObject): Long? = rec.long("startTime")

    private fun summaryOf(rec: JsonObject): JsonObject? =
        rec.str("summaryData")?.let { s -> try { JsonParser.parseString(s).asJsonObject } catch (e: Exception) { null } }

    /** Sampel (waktu epoch ms, nilai) terurut waktu; dibaca maju dengan penunjuk (waktu kueri harus naik). */
    private class Held(pairs: List<Pair<Long, Double>>) {
        private val k = LongArray(pairs.size)
        private val v = DoubleArray(pairs.size)
        private var i = -1
        init {
            val s = pairs.sortedBy { it.first }
            for (j in s.indices) { k[j] = s[j].first; v[j] = s[j].second }
        }
        val isEmpty get() = k.isEmpty()
        /** Nilai sampel terakhir dengan waktu <= [t] dan umur <= [maxAgeMs]; kalau tidak ada, NaN. */
        fun at(t: Long, maxAgeMs: Long): Double {
            while (i + 1 < k.size && k[i + 1] <= t) i++
            return if (i >= 0 && t - k[i] <= maxAgeMs) v[i] else Double.NaN
        }
    }

    private fun fields(line: String): Map<String, String> {
        val m = HashMap<String, String>(8)
        for (part in line.split(';')) {
            val i = part.indexOf('=')
            if (i > 0) m[part.substring(0, i)] = part.substring(i + 1)
        }
        return m
    }

    private fun zoneOf(rec: JsonObject): ZoneId {
        val tz = rec.str("timeZone")?.trim().orEmpty()
        return runCatching { ZoneOffset.of(tz) as ZoneId }.getOrElse { ZoneId.systemDefault() }
    }

    private fun validLoc(la: Double, lo: Double) =
        !la.isNaN() && !lo.isNaN() && abs(la) < 90.0 && abs(lo) <= 180.0 && !(la == 0.0 && lo == 0.0)

    /** @throws Skip jenis tidak didukung / tanpa GPS; @throws ActImportException data rusak */
    fun convert(rec: JsonObject): Converted {
        val summary = summaryOf(rec)
        val code = summary?.int("sportType") ?: rec.int("subType") ?: 0
        val sport = sportOf(code) ?: rec.int("subType")?.let { sportOf(it) }
            ?: throw Skip("jenis olahraga $code belum didukung")
        val startMs = startMs(rec) ?: throw ActImportException("tidak ada waktu mulai")
        val detail = rec.str("detailData") ?: throw Skip("tanpa titik GPS")

        class Loc(val tMs: Long, val la: Double, val lo: Double, val alt: Double)
        val locs = ArrayList<Loc>()
        val hr = ArrayList<Pair<Long, Double>>()
        val alti = ArrayList<Pair<Long, Double>>()
        val cad = ArrayList<Pair<Long, Double>>()
        for (line in detail.split('\n')) {
            when {
                line.startsWith("tp=lbs;") -> {
                    val f = fields(line)
                    val la = f["lat"]?.toDoubleOrNull() ?: continue
                    val lo = f["lon"]?.toDoubleOrNull() ?: continue
                    if (!validLoc(la, lo)) continue
                    val tSec = f["t"]?.toDoubleOrNull()
                    val k = f["k"]?.toLongOrNull()
                    val tMs = if (tSec != null && tSec > 1e8) Math.round(tSec * 1000) else if (k != null) startMs + k * 1000 else continue
                    locs.add(Loc(tMs, la, lo, f["alt"]?.toDoubleOrNull() ?: Double.NaN))
                }
                line.startsWith("tp=h-r;") -> fields(line).let { f ->
                    val k = f["k"]?.toLongOrNull(); val v = f["v"]?.toDoubleOrNull()
                    if (k != null && v != null && v in 30.0..250.0) hr.add(k to v)
                }
                line.startsWith("tp=alti;") -> fields(line).let { f ->
                    val k = f["k"]?.toLongOrNull(); val v = f["v"]?.toDoubleOrNull()
                    if (k != null && v != null) alti.add(k to v)
                }
                line.startsWith("tp=cad;") -> fields(line).let { f ->
                    val k = f["k"]?.toLongOrNull(); val v = f["v"]?.toDoubleOrNull()
                    if (k != null && v != null && v > 0.0 && v < 250.0) cad.add(k to v)
                }
            }
        }
        if (locs.size < 2) throw Skip("tanpa titik GPS")
        locs.sortBy { it.tMs }

        val hrS = Held(hr); val altS = Held(alti); val cadS = Held(cad)
        // Alt di baris lbs hanya dipakai bila ada nilai bukan nol (biasanya selalu 0.0 dan ketinggian ada di tp=alti).
        val lbsAltReal = altS.isEmpty && locs.any { !it.alt.isNaN() && it.alt != 0.0 }
        val pts = ArrayList<Pt>(locs.size)
        var lastT = Long.MIN_VALUE
        for (p in locs) {
            if (p.tMs == lastT) continue
            lastT = p.tMs
            pts.add(Pt(
                la = p.la, lo = p.lo, t = p.tMs.toDouble(),
                e = if (lbsAltReal) p.alt else altS.at(p.tMs, 15_000),
                h = hrS.at(p.tMs, 15_000),
                c = cadS.at(p.tMs, 15_000),
            ))
        }
        val name = if (code == 118 || code == 280) "Trail run" else ""
        return Converted(ParsedTrack(pts, sport, name), zoneOf(rec), startMs)
    }
}
