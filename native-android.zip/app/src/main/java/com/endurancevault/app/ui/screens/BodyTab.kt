package com.endurancevault.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Bedtime
import androidx.compose.material.icons.outlined.Equalizer
import androidx.compose.material.icons.outlined.FitnessCenter
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.endurancevault.app.data.DailyEntity
import com.endurancevault.app.domain.Js
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.ui.StrengthWorkoutRecord
import com.endurancevault.app.ui.UiState
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.TextStyle as JTextStyle
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Tab Body, memakai sistem kartu yang sama dengan Rekap dan Fitness. Tiga kartu, semuanya selebar layar,
 * dengan Tidur & kondisi paling atas: Tidur & kondisi, Strength progress, Strength balance.
 * Grafik Tidur & kondisi satu panel: tidur = batang, HR istirahat = garis biru, HRV = garis oranye;
 * tiap seri bisa dimatikan (minimal satu tetap menyala).
 */
@Composable
internal fun BodyTab(state: UiState) {
    val today = LocalDate.now()
    val daily = remember(state.daily) { state.daily.sortedBy { it.dateIso } }
    val win = remember(daily, today) {
        val by = daily.associateBy { it.dateIso }
        (13 downTo 0).map { by[today.minusDays(it.toLong()).toString()] }
    }
    val sw = remember(state.strengthWorkouts) { state.strengthWorkouts.filter { !it.deleted }.sortedBy { it.dateIso } }
    val plannedDays = remember(state.plan) {
        (state.plan as? PlanOutcome.Ok)?.weeks.orEmpty().flatMap { it.days }.count { it.str != null || it.ank != null || it.up != null }
    }

    var oSl by rememberSaveable { mutableStateOf(false) }
    var oSt by rememberSaveable { mutableStateOf(false) }
    var oBal by rememberSaveable { mutableStateOf(false) }
    var showSl by rememberSaveable { mutableStateOf(true) }
    var showRh by rememberSaveable { mutableStateOf(true) }
    var showHv by rememberSaveable { mutableStateOf(true) }
    val onSeries: (Int) -> Unit = { i ->
        val next = booleanArrayOf(showSl, showRh, showHv)
        next[i] = !next[i]
        if (next.any { it }) { showSl = next[0]; showRh = next[1]; showHv = next[2] }
    }

    BdSleep(daily, win, today, showSl, showRh, showHv, onSeries, oSl, { oSl = !oSl }, Modifier.fillMaxWidth())
    BdStrength(sw, plannedDays, today, oSt, { oSt = !oSt }, Modifier.fillMaxWidth())
    BdBalance(sw, today, oBal, { oBal = !oBal }, Modifier.fillMaxWidth())
}

// ===================== helper kecil =====================

private val BD_LOC = Locale("id", "ID")
private val BD_RHR = Color(0xFF4C8FE0)
private val BD_HRV = Color(0xFFF2600A)

private fun bdF1(x: Double): String = String.format(Locale.US, "%.1f", x).replace('.', ',')
private fun bdH(h: Double): String = "${bdF1(h)} j"
private fun bdDate(d: LocalDate): String = "${d.dayOfMonth} ${d.month.getDisplayName(JTextStyle.SHORT, BD_LOC)}"
private fun bdDateIso(iso: String): String = runCatching { bdDate(LocalDate.parse(iso)) }.getOrDefault(iso)
private fun bdDur(min: Int): String = if (min >= 60) "${min / 60}j ${min % 60}m" else "${min}m"

private fun DailyEntity.hasData(): Boolean = sleepH != null || rhr != null || hrv != null || leg != null || mood != null

@Composable
private fun BdStat(modifier: Modifier, label: String, value: String, sub: String?) {
    val cs = MaterialTheme.colorScheme
    Column(modifier, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label.uppercase(Locale.ROOT), style = monoStyle(9f, .4f), color = cs.onSurfaceVariant, maxLines = 1)
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1)
        if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1)
    }
}

@Composable
private fun BdChip(label: String, color: Color, on: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(99.dp)
    Row(
        Modifier.clip(shape).border(.8.dp, if (on) color else cs.outlineVariant, shape)
            .background(if (on) color.copy(alpha = .14f) else Color.Transparent)
            .clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(if (on) color else cs.outlineVariant))
        Text(label, style = MaterialTheme.typography.labelMedium, color = if (on) cs.onSurface else cs.onSurfaceVariant, maxLines = 1)
    }
}

@Composable
private fun BdToggles(sl: Boolean, rh: Boolean, hv: Boolean, onSeries: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        BdChip("Tidur", MaterialTheme.colorScheme.primary, sl) { onSeries(0) }
        BdChip("HR istirahat", BD_RHR, rh) { onSeries(1) }
        BdChip("HRV", BD_HRV, hv) { onSeries(2) }
    }
}

/** Grafik gabungan 14 hari: tidur = batang, HR istirahat dan HRV = garis (tiap garis berskala sendiri). */
@Composable
private fun BdCombo(win: List<DailyEntity?>, sl: Boolean, rh: Boolean, hv: Boolean, height: Int) {
    val cs = MaterialTheme.colorScheme
    val grid = cs.outlineVariant
    val barC = cs.primary.copy(alpha = .45f)
    val n = win.size
    if (n == 0) return
    val sleepV = win.map { it?.sleepH }
    val rhrV = win.map { it?.rhr?.toDouble() }
    val hrvV = win.map { it?.hrv?.toDouble() }
    Canvas(Modifier.fillMaxWidth().height(height.dp)) {
        val padV = 8.dp.toPx(); val h = size.height - 2 * padV
        val slot = size.width / n
        repeat(3) { i ->
            val gy = padV + h * i / 2f
            drawLine(grid.copy(alpha = .55f), Offset(0f, gy), Offset(size.width, gy), 1.dp.toPx())
        }
        if (sl) {
            val mx = max(9.0, sleepV.filterNotNull().maxOrNull() ?: 0.0)
            sleepV.forEachIndexed { i, v ->
                if (v != null && v > 0.0) {
                    val bh = (v / mx * h).toFloat(); val bw = slot * .55f
                    drawRoundRect(barC, Offset(i * slot + (slot - bw) / 2f, padV + h - bh), Size(bw, bh), CornerRadius(3.dp.toPx()))
                }
            }
        }
        fun line(vals: List<Double?>, c: Color) {
            val f = vals.filterNotNull()
            if (f.isEmpty()) return
            val lo = f.minOrNull() ?: 0.0; val hi = f.maxOrNull() ?: 1.0
            var path = Path(); var started = false
            vals.forEachIndexed { i, v ->
                if (v == null) {
                    if (started) { drawPath(path, c, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)); path = Path(); started = false }
                } else {
                    val t = if (hi - lo < 1e-9) 0.5 else (v - lo) / (hi - lo)
                    val x = i * slot + slot / 2f; val y = padV + h * (1f - t.toFloat())
                    if (!started) { path.moveTo(x, y); started = true } else path.lineTo(x, y)
                    drawCircle(c, 2.5.dp.toPx(), Offset(x, y))
                }
            }
            if (started) drawPath(path, c, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        if (rh) line(rhrV, BD_RHR)
        if (hv) line(hrvV, BD_HRV)
    }
}

/** Batang mini per pekan (8 pekan), pekan terakhir beraksen. */
@Composable
private fun BdBars(values: List<Int>, height: Int = 34) {
    val acc = MaterialTheme.colorScheme.primary
    val dim = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = .35f)
    Canvas(Modifier.fillMaxWidth().height(height.dp)) {
        val mx = values.maxOrNull() ?: 0
        if (mx <= 0 || values.isEmpty()) return@Canvas
        val gap = 4.dp.toPx(); val bw = (size.width - gap * (values.size - 1)) / values.size
        values.forEachIndexed { i, v ->
            val h = if (v > 0) max(size.height * .08f, v.toFloat() / mx * size.height) else 3.dp.toPx()
            drawRoundRect(if (i == values.lastIndex) acc else dim, Offset(i * (bw + gap), size.height - h), Size(bw, h), CornerRadius(3.dp.toPx()))
        }
    }
}

// ===================== 1. Tidur & kondisi =====================

@Composable
private fun BdSleep(
    daily: List<DailyEntity>, win: List<DailyEntity?>, today: LocalDate,
    sl: Boolean, rh: Boolean, hv: Boolean, onSeries: (Int) -> Unit,
    open: Boolean, onToggle: () -> Unit, modifier: Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val hasAny = daily.any { it.hasData() }
    val lastSleep = daily.lastOrNull { it.sleepH != null }?.sleepH
    val lastRhr = daily.lastOrNull { it.rhr != null }?.rhr
    val lastHrv = daily.lastOrNull { it.hrv != null }?.hrv
    val avgSleep = win.mapNotNull { it?.sleepH }.takeIf { it.isNotEmpty() }?.average()
    val avgRhr = win.mapNotNull { it?.rhr }.takeIf { it.isNotEmpty() }?.average()
    val avgHrv = win.mapNotNull { it?.hrv }.takeIf { it.isNotEmpty() }?.average()
    val first = bdDate(today.minusDays(13))
    RcCard(Icons.Outlined.Bedtime, "TIDUR & KONDISI", open, onToggle, modifier,
        headText = daily.lastOrNull { it.hasData() }?.let { bdDateIso(it.dateIso) },
        summary = {
            if (!hasAny) {
                RcMuted("Belum ada data harian. Isi Kondisi pagi atau sinkronkan jam.")
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    BdStat(Modifier.weight(1f), "Tidur", lastSleep?.let { bdH(it) } ?: "–", avgSleep?.let { "rata-rata ${bdH(it)}" })
                    BdStat(Modifier.weight(1f), "HR istirahat", lastRhr?.let { "$it bpm" } ?: "–", avgRhr?.let { "rata-rata ${it.roundToInt()}" })
                    BdStat(Modifier.weight(1f), "HRV", lastHrv?.let { "$it ms" } ?: "–", avgHrv?.let { "rata-rata ${it.roundToInt()}" })
                }
                BdToggles(sl, rh, hv, onSeries)
                BdCombo(win, sl, rh, hv, 96)
                RcLegend(first, "hari ini")
            }
        },
        body = {
            if (!hasAny) {
                RcMuted("Belum ada data harian. Isi Kondisi pagi atau sinkronkan jam.")
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    BdStat(Modifier.weight(1f), "Tidur", lastSleep?.let { bdH(it) } ?: "–", avgSleep?.let { "rata-rata ${bdH(it)}" })
                    BdStat(Modifier.weight(1f), "HR istirahat", lastRhr?.let { "$it bpm" } ?: "–", avgRhr?.let { "rata-rata ${it.roundToInt()}" })
                    BdStat(Modifier.weight(1f), "HRV", lastHrv?.let { "$it ms" } ?: "–", avgHrv?.let { "rata-rata ${it.roundToInt()}" })
                }
                BdToggles(sl, rh, hv, onSeries)
                RcInner {
                    BdCombo(win, sl, rh, hv, 140)
                    RcLegend(first, "hari ini")
                }
                RcMono("Tidur = batang (jam) · HR istirahat = biru · HRV = oranye. Tiap garis memakai skala sendiri.")

                Text("RASA KAKI & MOOD · 14 HARI", style = monoStyle(9f, .4f), color = cs.onSurfaceVariant)
                RcInner {
                    RtLines(
                        listOf(
                            "Kaki" to win.map { it?.leg?.toFloat() ?: Float.NaN },
                            "Mood/stres" to win.map { it?.mood?.toFloat() ?: Float.NaN },
                        ),
                        unit = "(1 baik · 5 berat)", fmt = { it.roundToInt().toString() },
                    )
                }

                Text("RIWAYAT", style = monoStyle(9f, .4f), color = cs.onSurfaceVariant)
                RcInner {
                    val w = listOf(1.2f, 1f, 1f, 1f, .8f, .8f)
                    RcTableRow(listOf("Tanggal", "Tidur", "RHR", "HRV", "Kaki", "Mood"), w, head = true)
                    daily.filter { it.hasData() }.takeLast(14).asReversed().forEach { d ->
                        RcTableRow(listOf(
                            bdDateIso(d.dateIso), d.sleepH?.let { bdF1(it) } ?: "–", d.rhr?.toString() ?: "–",
                            d.hrv?.toString() ?: "–", d.leg?.toString() ?: "–", d.mood?.toString() ?: "–",
                        ), w)
                    }
                }
                RcInfo("Rasa kaki: 1 = segar sampai 5 = sangat berat. Mood/stres: 1 = santai sampai 5 = stres berat. Rata-rata dihitung dari 14 hari terakhir yang terisi.")
            }
        })
}

// ===================== 2. Strength progress =====================

@Composable
private fun BdStrength(
    sw: List<StrengthWorkoutRecord>, plannedDays: Int, today: LocalDate,
    open: Boolean, onToggle: () -> Unit, modifier: Modifier,
) {
    val total = sw.sumOf { it.minutes }
    val weekMin = remember(sw, today) {
        val monday = today.with(DayOfWeek.MONDAY)
        (7 downTo 0).map { k ->
            val from = monday.minusWeeks(k.toLong()); val to = from.plusDays(7)
            sw.filter { w -> runCatching { LocalDate.parse(w.dateIso) }.getOrNull()?.let { !it.isBefore(from) && it.isBefore(to) } == true }
                .sumOf { it.minutes }
        }
    }
    val last7 = sw.count { w -> runCatching { LocalDate.parse(w.dateIso) }.getOrNull()?.let { !it.isBefore(today.minusDays(6)) && !it.isAfter(today) } == true }
    RcCard(Icons.Outlined.FitnessCenter, "STRENGTH PROGRESS", open, onToggle, modifier,
        headText = "${sw.size} sesi",
        summary = {
            if (sw.isEmpty()) {
                RcMuted("Belum ada workout strength dari jam.")
            } else {
                RcBig("${sw.size}", "Sesi selesai · ${bdDur(total)}", "7 hari: $last7")
                BdBars(weekMin)
                RcLegend("8 pekan lalu", "pekan ini")
            }
        },
        body = {
            if (sw.isEmpty()) {
                RcMuted("Belum ada workout strength dari jam.")
            } else {
                RcStats(listOf(
                    "Total" to bdDur(total),
                    "Rata-rata" to "${(total.toDouble() / sw.size).roundToInt()} m",
                    "Terjadwal" to "$plannedDays hari",
                ))
                BdBars(weekMin, 48)
                RcLegend("8 pekan lalu", "pekan ini")
                RcInner {
                    val w = listOf(1.2f, .8f, .8f, .9f, 1.1f)
                    RcTableRow(listOf("Tanggal", "Menit", "HR", "Kkal", "Tipe"), w, head = true)
                    sw.takeLast(20).asReversed().forEach { x ->
                        RcTableRow(listOf(
                            bdDateIso(x.dateIso), "${x.minutes}", x.avgHr?.toString() ?: "–", x.calories?.toString() ?: "–",
                            when { x.free -> "Free"; x.linkedKey != null -> "Terhubung"; else -> "Impor" },
                        ), w)
                    }
                }
                RcInfo("Workout strength tetap terpisah dari aktivitas lari dan tidak masuk mileage, PR, atau training load. Tipe: Free = tanpa rencana, Terhubung = dikaitkan ke sesi di rencana, Impor = dari jam tanpa tautan.")
            }
        })
}

// ===================== 3. Strength balance =====================

@Composable
private fun BdBalance(sw: List<StrengthWorkoutRecord>, today: LocalDate, open: Boolean, onToggle: () -> Unit, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val total = sw.sumOf { it.minutes }
    val avgHr = sw.mapNotNull { it.avgHr }.takeIf { it.isNotEmpty() }?.average()
    val maxHr = sw.mapNotNull { it.maxHr }.maxOrNull()
    val kcal = sw.mapNotNull { it.calories }.sum()
    val recent = remember(sw, today) {
        val from = today.with(DayOfWeek.MONDAY).minusWeeks(7)
        sw.filter { w -> runCatching { LocalDate.parse(w.dateIso) }.getOrNull()?.let { !it.isBefore(from) } == true }
    }
    val perWeek = recent.size / 8.0
    val minPerWeek = recent.sumOf { it.minutes } / 8.0
    RcCard(Icons.Outlined.Equalizer, "STRENGTH BALANCE", open, onToggle, modifier,
        headText = "${sw.count { it.avgHr != null }} catatan HR",
        summary = {
            if (sw.isEmpty()) {
                RcMuted("Belum ada riwayat sesi strength dari jam.")
            } else {
                RcStats(listOf(
                    "Durasi" to bdDur(total),
                    "HR rata-rata" to (avgHr?.let { "${it.roundToInt()}" } ?: "–"),
                    "Sesi/pekan" to bdF1(perWeek),
                ))
            }
        },
        body = {
            if (sw.isEmpty()) {
                RcMuted("Belum ada riwayat sesi strength dari jam.")
            } else {
                RcStatGrid(listOf(
                    "Total durasi" to bdDur(total), "Sesi/pekan" to bdF1(perWeek), "Menit/pekan" to "${minPerWeek.roundToInt()}",
                    "HR rata-rata" to (avgHr?.let { "${it.roundToInt()}" } ?: "–"), "HR maks" to (maxHr?.toString() ?: "–"),
                    "Kalori" to (if (kcal > 0) Js.idn(kcal) else "–"),
                ))
                Text("JENIS SESI", style = monoStyle(9f, .4f), color = cs.onSurfaceVariant)
                RcInner {
                    val rows = listOf(
                        Triple("Free strength", sw.count { it.free }, cs.primary),
                        Triple("Terhubung rencana", sw.count { !it.free && it.linkedKey != null }, cs.tertiary),
                        Triple("Impor jam", sw.count { !it.free && it.linkedKey == null }, cs.secondary),
                    )
                    rows.forEach { (label, n, c) ->
                        Column(Modifier.padding(vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(Modifier.fillMaxWidth()) {
                                Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                                Text("$n", style = monoStyle(11f, 0f), color = cs.onSurfaceVariant)
                            }
                            RcCompare(listOf((n * 100f / sw.size) to c), h = 6)
                        }
                    }
                }
                RcInfo("Distribusi kelompok otot belum dapat dihitung karena workout dari jam tidak menyimpan set, repetisi, atau identitas gerakan. Sesi/pekan dan menit/pekan dihitung dari 8 pekan terakhir.")
            }
        })
}
