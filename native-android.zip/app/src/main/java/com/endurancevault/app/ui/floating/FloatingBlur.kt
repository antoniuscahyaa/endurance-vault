package com.endurancevault.app.ui.floating

import android.os.Build
import android.view.View
import android.view.WindowManager
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.material3.AlertDialogDefaults
import androidx.compose.material3.BottomSheetDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheetProperties
import androidx.compose.material3.ModalBottomSheetDefaults
import androidx.compose.material3.SheetState
import androidx.compose.material3.contentColorFor
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider

/** Callback dari floating window untuk mengaktifkan snapshot blur pada konten halaman di belakangnya. */
internal val LocalFloatingBlurRegistration = compositionLocalOf<(Boolean) -> Unit> { { _: Boolean -> } }

@Composable
private fun FloatingBlurSignal() {
    val register = LocalFloatingBlurRegistration.current
    DisposableEffect(register) {
        register(true)
        onDispose { register(false) }
    }
}

/*
 * Semua jendela melayang (dialog, AlertDialog, bottom sheet) di-blur latarnya lewat tiga pembungkus di sini.
 * Pakai `import com.endurancevault.app.ui.floating.AlertDialog` (dst.) alih-alih versi bawaan Compose.
 * Blur lintas jendela butuh Android 12 (API 31) dan perangkat yang mendukungnya; di tempat lain latar hanya digelapkan seperti biasa.
 */

/** Radius blur latar di belakang jendela melayang. */
val FloatingBlurRadius: Dp = 20.dp

/** Pasang blur-di-belakang pada jendela yang menampung composable ini (Dialog atau ModalBottomSheet). Tidak menggambar apa pun. */
@Composable
fun BlurBehindWindow(radius: Dp = FloatingBlurRadius) {
    val view = LocalView.current
    SideEffect {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return@SideEffect
        val px = (radius.value * view.resources.displayMetrics.density).toInt()
        val dialogWindow = (view.parent as? DialogWindowProvider)?.window
        if (dialogWindow != null) {
            dialogWindow.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
            val lp = dialogWindow.attributes
            if (lp.blurBehindRadius != px) { lp.blurBehindRadius = px; dialogWindow.attributes = lp }
            return@SideEffect
        }
        // Bottom sheet: jendelanya adalah View yang ditambahkan langsung ke WindowManager.
        var target: View? = view
        while (target != null && target.layoutParams !is WindowManager.LayoutParams) target = target.parent as? View
        val lp = target?.layoutParams as? WindowManager.LayoutParams ?: return@SideEffect
        if (lp.blurBehindRadius == px && (lp.flags and WindowManager.LayoutParams.FLAG_BLUR_BEHIND) != 0) return@SideEffect
        lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
        lp.blurBehindRadius = px
        runCatching { target.context.getSystemService(WindowManager::class.java).updateViewLayout(target, lp) }
    }
}

@Composable
fun Dialog(
    onDismissRequest: () -> Unit,
    properties: DialogProperties = DialogProperties(),
    content: @Composable () -> Unit,
) {
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismissRequest, properties = properties) {
        FloatingBlurSignal()
        BlurBehindWindow()
        content()
    }
}

@Composable
fun AlertDialog(
    onDismissRequest: () -> Unit,
    confirmButton: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    dismissButton: @Composable (() -> Unit)? = null,
    icon: @Composable (() -> Unit)? = null,
    title: @Composable (() -> Unit)? = null,
    text: @Composable (() -> Unit)? = null,
    shape: Shape = AlertDialogDefaults.shape,
    containerColor: Color = AlertDialogDefaults.containerColor,
    iconContentColor: Color = AlertDialogDefaults.iconContentColor,
    titleContentColor: Color = AlertDialogDefaults.titleContentColor,
    textContentColor: Color = AlertDialogDefaults.textContentColor,
    tonalElevation: Dp = AlertDialogDefaults.TonalElevation,
    properties: DialogProperties = DialogProperties(),
) {
    FloatingBlurSignal()
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismissRequest,
        confirmButton = { BlurBehindWindow(); confirmButton() },
        modifier = modifier,
        dismissButton = dismissButton,
        icon = icon,
        title = title,
        text = text,
        shape = shape,
        containerColor = containerColor,
        iconContentColor = iconContentColor,
        titleContentColor = titleContentColor,
        textContentColor = textContentColor,
        tonalElevation = tonalElevation,
        properties = properties,
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModalBottomSheet(
    onDismissRequest: () -> Unit,
    modifier: Modifier = Modifier,
    sheetState: SheetState = rememberModalBottomSheetState(),
    sheetMaxWidth: Dp = BottomSheetDefaults.SheetMaxWidth,
    shape: Shape = BottomSheetDefaults.ExpandedShape,
    containerColor: Color = BottomSheetDefaults.ContainerColor,
    contentColor: Color = contentColorFor(containerColor),
    tonalElevation: Dp = BottomSheetDefaults.Elevation,
    scrimColor: Color = BottomSheetDefaults.ScrimColor,
    dragHandle: @Composable (() -> Unit)? = { BottomSheetDefaults.DragHandle() },
    properties: ModalBottomSheetProperties = ModalBottomSheetDefaults.properties,
    content: @Composable ColumnScope.() -> Unit,
) {
    FloatingBlurSignal()
    androidx.compose.material3.ModalBottomSheet(
        onDismissRequest = onDismissRequest,
        modifier = modifier,
        sheetState = sheetState,
        sheetMaxWidth = sheetMaxWidth,
        shape = shape,
        containerColor = containerColor,
        contentColor = contentColor,
        tonalElevation = tonalElevation,
        scrimColor = scrimColor,
        dragHandle = dragHandle,
        // Material3 2024.09.03 ModalBottomSheet does not expose a windowInsets parameter.
        properties = properties,
    ) {
        BlurBehindWindow()
        content()
    }
}
