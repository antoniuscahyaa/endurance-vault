package com.endurancevault.app.domain

import com.endurancevault.app.data.ActivityEntity
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.Locale
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * Entri `mv` seperti di versi web (rencana-lari), disimpan di tabel kv dengan kunci "mv" supaya ikut cadangan web:
 *  - "sw:YYYY-MM-DD" -> t="sw", to=tanggal lain di minggu yang sama (dua hari saling bertukar isi sesi)
 *  - "YYYY-MM-DD"    -> t="spread" (libur dadakan, km dibagi ke [spread]), t="mv" (geser sesi terlewat ke [to]) atau t="skip" (lewati)
 * Entri dengan t tak dikenal disimpan apa adanya di [raw] dan tidak diproses.
 */
class MvEntry(
    val t: String,
    val to: String? = null,
    val why: String? = null,
    val km: Double = 0.0,
    val f: Double = 1.0,
    val spread: List<Pair<String, Double>> = emptyList(),
    val raw: String? = null,
)

/**
 * Masukan penyesuaian. [done] = kunci centang manual ("2026-11-04", "2026-11-04:s", ":a", ":u").
 * [loggedKm] = tanggal -> km lari yang memenuhi sesi hari itu (lihat [SessionAdjust.loggedKm]). [easyHr] = batas HR easy untuk teks.
 */
class AdjInput(
    val today: LocalDate,
    val mv: Map<String, MvEntry>,
    val done: Set<String>,
    val loggedKm: Map<String, Double>,
    val easyHr: Int = 150,
)

/** Satu hari tujuan pembagian km (libur dadakan). x = tambahan km, cap = batas per hari, nx = minggu depan. */
class SpItem(val c: PDay, var x: Double, val cap: Double, val nx: Boolean, val done: Boolean = false)

class SpResult(val items: MutableList<SpItem>, val left: Double, val allow: Double)

/** Pratinjau panel Libur dadakan. lv: 0 normal, 1 batas dipotong setengah, 2 km tidak dibagi. */
class SpPreview(
    val src: PDay, val km: Double, val lv: Int, val items: List<SpItem>, val allow: Double, val hasNext: Boolean,
)

/**
 * Port logika pertukaran dan pembagian jadwal dari rencana-lari (03-perencana-gear-statistik.js: swapDays, swLists, spDist,
 * spApply, adjust). Murni dan tanpa Android supaya bisa diuji di JVM. Semua fungsi memutasi PDay/PWeek hasil PlanEngine
 * (objek baru tiap perhitungan), jadi tidak ada keadaan tersembunyi selain entri mv dan done.
 *
 * Ringkasan aturan:
 *  - Tukar hari: dua hari di MINGGU YANG SAMA saling bertukar isi sesi (termasuk hari libur). Tanggal, urutan, peran slot dan
 *    blok strength/ankle/upper tetap di harinya. Hanya sesi dalam 14 hari ke depan (hari ini sampai +13), belum selesai, belum punya
 *    penyesuaian lain, bukan lomba/event. Peringatan bila tukar melahirkan dua sesi berat berurutan yang sebelumnya tidak ada.
 *  - Libur dadakan: km sesi easy/short/medium biasa dibagi ke hari easy/long lain (batas +40%/+25% per hari, min +2 km), sisa boleh
 *    ke easy minggu depan (maks +10% total minggu itu). Kondisi buruk (nyeri aktif, kesiapan rendah, alasan sakit) memotong/mematikan.
 *  - Sesi terlewat: otomatis digeser (quality ke easy berikutnya, long run ke hari libur berikutnya) atau ditandai terlewat dengan
 *    pilihan Geser ke / Tukar libur / Lewati / Pilih hari lain. Minggu berikutnya dikurangi 20% bila terlewat banyak.
 */
object SessionAdjust {
    const val SP_CAP = .4
    const val SP_CAPL = .25
    const val SP_MIN = 2.0
    const val SP_WK = .10

    private val DOW = listOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min")
    private val MON = listOf("Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des")
    private val FREE_KEY = Regex(".+~f\\d+$")
    private val HARD = setOf(Kinds.QUALITY, Kinds.LONG, "sub", Kinds.EVENT, Kinds.RACE)
    private val RUNK = setOf(Kinds.EASY, "short", Kinds.QUALITY, Kinds.MEDIUM, Kinds.LONG, "sub")
    val WHY_LABEL = mapOf("sibuk" to "Sibuk", "capek" to "Capek", "sakit" to "Sakit/nyeri", "lain" to "Lainnya")

    // ---------- format ----------
    fun label(dt: LocalDate): String = DOW[dt.dayOfWeek.value - 1] + " " + dt.dayOfMonth + " " + MON[dt.monthValue - 1]
    fun dlabel(d: PDay): String = label(d.date)
    fun ds(x: Double): String = if (x == floor(x)) x.toLong().toString() else String.format(Locale.US, "%.1f", x).replace('.', ',')
    private fun daysBetween(from: LocalDate, to: LocalDate): Long = ChronoUnit.DAYS.between(from, to)
    private fun r1(x: Double) = Js.round(x * 10) / 10

    // ---------- penyelesaian sesi ----------
    /** Lari utama pada tanggal itu: yang bertaut (srcKey = tanggal), kalau tidak ada lari terpanjang. Lari bebas (~f1, ~f2) tidak dihitung. */
    fun primaryRun(acts: List<ActivityEntity>, dateIso: String): ActivityEntity? {
        val runs = acts.filter { it.dateIso == dateIso && it.type.equals("run", ignoreCase = true) && it.km > 0.0 && !FREE_KEY.matches(it.srcKey) }
        return runs.firstOrNull { it.srcKey == dateIso } ?: runs.maxByOrNull { it.km }
    }

    /** tanggal -> km lari utama. Lari dari jam atau input manual (srcKey kosong / watch:...) ikut memenuhi sesi hari itu. */
    fun loggedKm(acts: List<ActivityEntity>): Map<String, Double> =
        acts.filter { it.type.equals("run", ignoreCase = true) && it.km > 0.0 }.groupBy { it.dateIso }
            .mapNotNull { (date, list) -> primaryRun(list, date)?.let { date to it.km } }.toMap()

    fun isDone(inp: AdjInput, d: PDay): Boolean = isDoneKey(inp, d.date.toString())
    fun isDoneKey(inp: AdjInput, key: String): Boolean = key in inp.done || (inp.loggedKm[key] ?: 0.0) > 0.0

    // ---------- tukar hari ----------
    fun swHard(d: PDay?): Boolean = d != null && d.kind in HARD

    /** true bila menukar a dan b melahirkan pasangan sesi berat berurutan yang sebelumnya tidak ada. */
    fun swWarn(all: List<PDay>, a: PDay, b: PDay): Boolean {
        val ia = all.indexOf(a); val ib = all.indexOf(b)
        if (ia < 0 || ib < 0) return false
        val lo = max(0, min(ia, ib) - 1); val hi = min(all.size - 2, max(ia, ib))
        fun at(j: Int): PDay = if (j == ia) all[ib] else if (j == ib) all[ia] else all[j]
        for (i in lo..hi) {
            if (swHard(at(i)) && swHard(at(i + 1)) && !(swHard(all[i]) && swHard(all[i + 1]))) return true
        }
        return false
    }

    fun swOk(a: PDay?, b: PDay?): Boolean {
        if (a == null || b == null || a === b || a.week !== b.week || a.adj != null || b.adj != null) return false
        return a.kind != Kinds.RACE && a.kind != Kinds.EVENT && b.kind != Kinds.RACE && b.kind != Kinds.EVENT
    }

    private inline fun <T> swap(x: () -> T, setX: (T) -> Unit, y: () -> T, setY: (T) -> Unit) {
        val t = x(); setX(y()); setY(t)
    }

    /** Tukar isi sesi; tanggal, urutan, peran slot, blok strength/ankle/upper dan penanda penyesuaian tetap di harinya. */
    private fun swapContent(a: PDay, b: PDay) {
        swap({ a.kind }, { a.kind = it }, { b.kind }, { b.kind = it })
        swap({ a.grp }, { a.grp = it }, { b.grp }, { b.grp = it })
        swap({ a.title }, { a.title = it }, { b.title }, { b.title = it })
        swap({ a.km }, { a.km = it }, { b.km }, { b.km = it })
        swap({ a.detail }, { a.detail = it }, { b.detail }, { b.detail = it })
        swap({ a.bikeReplacement }, { a.bikeReplacement = it }, { b.bikeReplacement }, { b.bikeReplacement = it })
        swap({ a.replacedRunTitle }, { a.replacedRunTitle = it }, { b.replacedRunTitle }, { b.replacedRunTitle = it })
        swap({ a.replacedRunKind }, { a.replacedRunKind = it }, { b.replacedRunKind }, { b.replacedRunKind = it })
        swap({ a.replacedRunKm }, { a.replacedRunKm = it }, { b.replacedRunKm }, { b.replacedRunKm = it })
        swap({ a.replacedRunDetail }, { a.replacedRunDetail = it }, { b.replacedRunDetail }, { b.replacedRunDetail = it })
        swap({ a.gain }, { a.gain = it }, { b.gain }, { b.gain = it })
        swap({ a.b2b }, { a.b2b = it }, { b.b2b }, { b.b2b = it })
        swap({ a.qk }, { a.qk = it }, { b.qk }, { b.qk = it })
        swap({ a.qMin }, { a.qMin = it }, { b.qMin }, { b.qMin = it })
        swap({ a.qBand }, { a.qBand = it }, { b.qBand }, { b.qBand = it })
        swap({ a.sim }, { a.sim = it }, { b.sim }, { b.sim = it })
        swap({ a.bench }, { a.bench = it }, { b.bench }, { b.bench = it })
        swap({ a.xtra }, { a.xtra = it }, { b.xtra }, { b.xtra = it })
        swap({ a.altMins }, { a.altMins = it }, { b.altMins }, { b.altMins = it })
        swap({ a.altKm }, { a.altKm = it }, { b.altKm }, { b.altKm = it })
        swap({ a.est }, { a.est = it }, { b.est }, { b.est = it })
        swap({ a.q2 }, { a.q2 = it }, { b.q2 }, { b.q2 = it })
        swap({ a.mod }, { a.mod = it }, { b.mod }, { b.mod = it })
        swap({ a.tm }, { a.tm = it }, { b.tm }, { b.tm = it })
        swap({ a.glock }, { a.glock = it }, { b.glock }, { b.glock = it })
        swap({ a.bd }, { a.bd = it }, { b.bd }, { b.bd = it })
        swap({ a.mk }, { a.mk = it }, { b.mk }, { b.mk = it })
    }

    private fun swapDays(a: PDay, b: PDay, key: String, all: List<PDay>) {
        val warn = swWarn(all, a, b)
        swapContent(a, b)
        val w = if (warn) ". Dua sesi berat jadi berurutan." else ""
        a.adj = DayAdj("sw", "Ditukar dengan ${dlabel(b)}$w")
        b.adj = DayAdj("sw", "Ditukar dengan ${dlabel(a)}$w")
        a.mvUndo = true; b.mvUndo = true; a.mvSw = key; b.mvSw = key
    }

    private fun whatOf(c: PDay) = if (c.kind == Kinds.REST) "Libur" else c.title

    /** Isi d.swList: hari lain di minggu yang sama yang belum lewat, belum selesai dan belum punya penyesuaian; hanya 14 hari ke depan. */
    private fun swLists(all: List<PDay>, inp: AdjInput) {
        fun free(c: PDay) = !c.date.isBefore(inp.today) && c.adj == null && c.kind != Kinds.RACE && c.kind != Kinds.EVENT && !isDone(inp, c)
        for (d in all) {
            d.swList = emptyList()
            if (d.kind == Kinds.REST || !free(d) || daysBetween(inp.today, d.date) > 13) continue
            d.swList = d.week!!.days.filter { it !== d && free(it) }.map { DayOption(it.date, dlabel(it), whatOf(it), swWarn(all, d, it)) }
        }
    }

    // ---------- libur dadakan ----------
    fun spKind(c: PDay): Boolean = c.kind == Kinds.EASY || c.kind == "short" || (c.kind == Kinds.MEDIUM && c.b2b == null && !c.glock && !c.bench)
    private fun spTgt(c: PDay): Boolean = spKind(c) || (c.kind == Kinds.MEDIUM && !c.glock && !c.bench) || (c.kind == Kinds.LONG && !c.bench)
    private fun spWkOk(w: PWeek?): Boolean = w != null && !w.race && w.phase != Phases.TAPER

    /** 0 normal, 1 batas dipotong setengah, 2 tidak dibagi. */
    fun spLevel(pain: Boolean, score: Int, swapTh: Int, lightTh: Int, why: String): Int {
        var lv = 0
        if (score >= 0) { if (score < swapTh) lv = 2 else if (score < lightTh) lv = 1 }
        if (pain || why == "sakit") lv = 2 else if (why == "capek" && lv < 1) lv = 1
        return lv
    }

    private fun spOk(c: PDay, d: PDay, nx: Boolean, ap: Boolean, inp: AdjInput): Boolean {
        val dn = isDone(inp, c)
        if (c === d || !spTgt(c) || !(c.km > 0) || (c.adj != null && c.adj!!.type != "sw") || c.bikeReplacement != null) return false
        val past = c.date.isBefore(inp.today)
        if (if (ap) (past && !dn) else (past || dn)) return false
        val cw = c.week; val dw = d.week
        if (cw === dw) return spWkOk(cw)
        return nx && cw != null && dw != null && cw.i == dw.i + 1 && spKind(c) && spWkOk(cw)
    }

    fun spCap(c: PDay, f: Double): Double =
        max(SP_MIN, Js.round(c.km * (if (c.kind == Kinds.LONG || c.b2b != null) SP_CAPL else SP_CAP) * f * 2) / 2)

    fun spAllow(w: PWeek): Double = floor(w.km * SP_WK * 2) / 2

    /** Hari tujuan urut tanggal. Minggu ini diisi rata dahulu; sisanya (bila [next]) ke easy minggu depan dalam jatahnya. */
    fun spDist(all: List<PDay>, d: PDay, next: Boolean, f: Double, inp: AdjInput): SpResult {
        var left = floor(d.km * 2) / 2
        val items = mutableListOf<SpItem>()
        var allow = 0.0
        var nw: PWeek? = null
        for (c in all) {
            if (spOk(c, d, next, false, inp)) {
                val n = c.week !== d.week
                items.add(SpItem(c, 0.0, spCap(c, f), n))
                if (n) nw = c.week
            }
        }
        // Kredit: hari tujuan minggu yang sama, sesudah hari libur, yang sudah dilari lebih jauh dari rencananya.
        for (c in all) {
            val lg = inp.loggedKm[c.date.toString()] ?: 0.0
            val ex = if (lg > 0 && isDone(inp, c)) floor((lg - c.km) * 2) / 2 else 0.0
            if (c.week !== d.week || !c.date.isAfter(d.date) || c.date.isAfter(inp.today) || !(ex >= .5) || !spTgt(c) ||
                !(c.km > 0) || (c.adj != null && c.adj!!.type != "sw") || c.bikeReplacement != null) continue
            val x = min(min(ex, floor(left * 2) / 2), 20.0)
            if (!(x >= .5)) continue
            items.add(SpItem(c, x, x, false, true)); left -= x
        }
        items.sortBy { it.c.date }
        fun fill(list: List<SpItem>, lim: Double) {
            var guard = 0
            var rem = min(left, lim)
            while (rem >= .5 && guard++ < 60) {
                val open = list.filter { it.x < it.cap }
                if (open.isEmpty()) break
                val sh = max(.5, floor(rem / open.size * 2) / 2)
                for (q in open) {
                    val a = min(min(sh, q.cap - q.x), rem)
                    if (a > 0) { q.x += a; rem -= a; left -= a }
                }
            }
        }
        fill(items.filter { !it.nx }, left)
        nw?.let { allow = spAllow(it); fill(items.filter { q -> q.nx }, allow) }
        return SpResult(items, left, allow)
    }

    /** Menjepit angka ubahan manual: 0..batas per hari (kelipatan 0,5), total minggu depan <= jatah, total <= km sumber. Mengembalikan sisa km. */
    fun spClamp(items: List<SpItem>, km: Double, allow: Double): Double {
        var tot = 0.0; var tn = 0.0
        items.forEach { q -> q.x = max(0.0, min(q.cap, Js.round(q.x * 2) / 2)) }
        for (i in items.indices.reversed()) {
            val q = items[i]
            if (q.nx) {
                val ex = tn + q.x - allow
                if (ex > 0) q.x = max(0.0, q.x - ex)
                tn += q.x
            }
        }
        items.forEach { tot += it.x }
        var j = items.size - 1
        while (j >= 0 && tot > km) {
            val cut = min(items[j].x, tot - km)
            items[j].x -= cut; tot -= cut; j--
        }
        return Js.round((km - tot) * 2) / 2
    }

    private fun spApply(all: List<PDay>, d: PDay, o: MvEntry, inp: AdjInput) {
        val ap = mutableListOf<String>()
        var tot = 0.0
        val byDate = all.associateBy { it.date.toString() }
        val dw = d.week!!
        val nw = all.firstOrNull { it.week!!.i == dw.i + 1 }?.week
        var nxLeft = nw?.let { spAllow(it) } ?: 0.0
        for ((dateKey, x0) in o.spread) {
            val c = byDate[dateKey] ?: continue
            var x = Js.round(x0 * 2) / 2
            if (!(x > 0 && x <= 20) || !spOk(c, d, true, true, inp)) continue
            val cw = c.week!!
            if (cw !== dw) { x = min(x, nxLeft); if (!(x > 0)) continue; nxLeft -= x }
            val k1 = c.km
            c.km = r1(c.km + x)
            val g = c.gain ?: 0
            if ((c.kind == Kinds.LONG || c.kind == Kinds.MEDIUM) && g > 0 && k1 > 0) c.gain = (Js.round(g * c.km / k1 / 50) * 50).toInt()
            cw.km = r1(cw.km + x)
            val swT = if (c.adj?.type == "sw") " · ${c.adj!!.text}" else ""
            c.adj = DayAdj("in", "Tambahan +${ds(x)} km dari ${dlabel(d)} (libur dadakan)$swT")
            ap.add("${dlabel(c)} +${ds(x)}"); tot += x
        }
        val rm = d.km
        val k0 = if (o.km > 0 && o.km <= rm) o.km else rm
        val left = r1(k0 - tot)
        val whyTxt = WHY_LABEL[o.why]?.let { " · $it" } ?: ""
        val text = if (ap.isNotEmpty())
            "Libur dadakan: ${ds(k0)} km dibagi ke ${ap.joinToString(", ")}" + (if (left >= .5) ". Sisa ${ds(left)} km tidak dikejar" else "")
        else "Libur dadakan, km tidak dikejar"
        d.adj = DayAdj("spread", text + whyTxt)
        d.mvUndo = true; d.mvKm = rm; d.mvGain = d.gain; d.gain = 0
        dw.km = r1(dw.km - rm); d.km = 0.0
    }

    private fun spLists(all: List<PDay>, inp: AdjInput) {
        for (d in all) {
            d.spOpt = false
            if (d.date.isAfter(inp.today) || daysBetween(d.date, inp.today) > 7 || (d.adj != null && d.adj!!.type != "miss") ||
                !spKind(d) || !(d.km > 0) || d.bikeReplacement != null || isDone(inp, d)) continue
            d.spOpt = true
        }
    }

    /** Pratinjau panel Libur dadakan untuk hari [date]; null bila hari itu tidak bisa diliburkan. */
    fun spPreview(
        plan: PlanOutcome.Ok, inp: AdjInput, date: LocalDate, why: String, next: Boolean,
        pain: Boolean, score: Int, swapTh: Int = 50, lightTh: Int = 65,
    ): SpPreview? {
        val all = flatten(plan)
        val d = all.firstOrNull { it.date == date } ?: return null
        if (!(d.km > 0)) return null
        val km = floor(d.km * 2) / 2
        val lv = spLevel(pain, score, swapTh, lightTh, why)
        val hasNext = spDist(all, d, true, 1.0, inp).items.any { it.nx }
        if (lv >= 2) return SpPreview(d, km, lv, emptyList(), 0.0, hasNext)
        val r = spDist(all, d, next, if (lv == 1) .5 else 1.0, inp)
        spClamp(r.items, km, r.allow)
        return SpPreview(d, km, lv, r.items, r.allow, hasNext)
    }

    /** Riwayat libur dadakan 28 hari terakhir (terbaru dahulu) untuk panel. */
    fun spHistory(mv: Map<String, MvEntry>, today: LocalDate, n: Int = 28): List<Pair<String, MvEntry>> {
        val lo = today.minusDays(n.toLong()).toString(); val hi = today.toString()
        return mv.filter { (k, o) -> o.t == "spread" && !k.startsWith("sw:") && k >= lo && k <= hi }.toList().sortedByDescending { it.first }
    }

    // ---------- penerapan ----------
    fun flatten(plan: PlanOutcome.Ok): List<PDay> {
        val all = ArrayList<PDay>()
        plan.weeks.forEach { w -> w.days.forEach { it.week = w; all.add(it) } }
        return all
    }

    private fun copyForMove(from: PDay, to: PDay) {
        to.title = from.title; to.detail = from.detail; to.km = from.km; to.kind = from.kind; to.grp = from.grp
        to.bench = from.bench; to.qk = from.qk; to.qMin = from.qMin; to.qBand = from.qBand; to.est = from.est
        to.altMins = from.altMins; to.altKm = from.altKm; to.mod = from.mod; to.gain = from.gain
        to.bikeReplacement = from.bikeReplacement; to.tm = from.tm
    }

    /**
     * Terapkan entri mv dan penanganan sesi terlewat ke [plan] (diubah di tempat). Urutan sama dengan web: tukar hari dahulu
     * (tetap berlaku setelah tanggalnya lewat), lalu libur dadakan, lalu sesi terlewat, lalu daftar pilihan tombol.
     */
    fun apply(plan: PlanOutcome, inp: AdjInput): PlanOutcome {
        val ok = plan as? PlanOutcome.Ok ?: return plan
        val all = flatten(ok)
        val today = inp.today

        for ((k, o) in inp.mv) {
            if (!k.startsWith("sw:") || o.t != "sw") continue
            val da = k.substring(3)
            val a = all.firstOrNull { it.date.toString() == da }
            val b = all.firstOrNull { it.date.toString() == o.to }
            if (swOk(a, b)) swapDays(a!!, b!!, k, all)
        }
        for ((k, o) in inp.mv) {
            if (o.t != "spread" || k.startsWith("sw:")) continue
            val d = all.firstOrNull { it.date.toString() == k } ?: continue
            if (d.adj == null && spKind(d) && d.km > 0 && d.bikeReplacement == null && !isDone(inp, d)) spApply(all, d, o, inp)
        }

        val miss = HashMap<Int, Int>(); val hq = HashSet<Int>(); val hl = HashSet<Int>()
        fun mvAny(c: PDay?) = c != null && !c.date.isBefore(today) && c.kind != Kinds.RACE && c.kind != Kinds.EVENT && c.adj == null && !isDone(inp, c)
        fun mvOk(c: PDay?) = c != null && !c.date.isBefore(today) && (c.kind == Kinds.EASY || c.kind == "short" || c.kind == Kinds.REST) && c.adj == null && !isDone(inp, c)

        for (i in all.indices) {
            val d = all[i]
            if (!d.date.isBefore(today)) break
            val w = d.week!!
            if (d.kind != Kinds.REST && d.kind != Kinds.RACE && !isDone(inp, d) && d.adj?.type != "spread") {
                val nx = all.getOrNull(i + 1); val af = all.getOrNull(i + 2)
                var handled = false
                val ov = inp.mv[d.date.toString()]
                if (ov?.t == "skip") {
                    d.adj = DayAdj("skip", "Dilewati, keluar dari target"); d.mvUndo = true; d.mvKm = d.km
                    if (w.km >= d.km) w.km -= d.km
                    d.km = 0.0; d.mvGain = d.gain; d.gain = 0; handled = true
                } else if (ov != null && ov.t == "mv") {
                    val tg0 = all.drop(i + 1).firstOrNull { it.date.toString() == ov.to }
                    if (mvAny(tg0)) {
                        val t0 = tg0!!
                        val ok0 = t0.km
                        t0.adj = DayAdj("in", "Digeser dari ${dlabel(d)} (" + (if (t0.kind == Kinds.REST) "menukar hari libur" else "menggantikan ${t0.title}") + ")")
                        copyForMove(d, t0)
                        t0.week!!.km += t0.km - ok0
                        d.adj = DayAdj("out", "Digeser ke ${dlabel(t0)}"); d.mvUndo = true; d.mvKm = d.km
                        w.km -= d.km; d.km = 0.0; d.mvGain = d.gain; d.gain = 0; handled = true
                    }
                }
                if (d.kind == Kinds.QUALITY && d.adj == null) {
                    if (nx != null && nx.week === w && !nx.date.isBefore(today) && (nx.kind == Kinds.EASY || nx.kind == "short") && nx.adj == null &&
                        !isDone(inp, nx) && !(af != null && (af.kind == Kinds.QUALITY || af.kind == Kinds.LONG || af.kind == Kinds.EVENT || af.kind == Kinds.RACE || af.kind == "sub"))) {
                        nx.adj = DayAdj("in", "Digeser dari ${dlabel(d)}")
                        nx.title = d.title; nx.detail = d.detail; nx.km = d.km; nx.kind = Kinds.QUALITY; nx.grp = Kinds.QUALITY
                        nx.bench = d.bench; nx.qk = d.qk; nx.qMin = d.qMin; nx.qBand = d.qBand; nx.est = d.est
                        nx.altMins = null; nx.altKm = null; nx.mod = null; nx.gain = null
                        d.adj = DayAdj("out", "Digeser ke ${dlabel(nx)}"); handled = true
                    }
                } else if (d.kind == Kinds.LONG && d.adj == null) {
                    if (nx != null && nx.kind == Kinds.REST && !nx.date.isBefore(today)) {
                        nx.kind = "sub"; nx.grp = Kinds.LONG; nx.title = "Pengganti long run"; nx.km = max(5.0, Js.round(d.km * .7))
                        nx.detail = "Easy panjang, HR ≤ ${inp.easyHr}, tanpa mengejar tanjakan. Menggantikan hari libur."
                        nx.adj = DayAdj("in", "Digeser dari ${dlabel(d)}"); d.adj = DayAdj("out", "Digeser ke ${dlabel(nx)}"); handled = true
                    }
                }
                if (!handled) {
                    d.adj = DayAdj("miss", if (d.adj?.type == "in") "Digeser lalu terlewat" else "Terlewat, tidak dikejar")
                    if (daysBetween(d.date, today) <= 7) {
                        for (q2 in i + 1 until all.size) {
                            val c2 = all[q2]
                            if (c2.date.isBefore(today)) continue
                            if (daysBetween(today, c2.date) > 6) break
                            if (mvOk(c2)) {
                                if (c2.kind == Kinds.REST) { if (d.mvOptR == null) d.mvOptR = DayOption(c2.date, dlabel(c2), "Libur") }
                                else if (d.mvOpt == null) d.mvOpt = DayOption(c2.date, dlabel(c2), c2.title)
                                if (d.mvOpt != null && d.mvOptR != null) break
                            }
                        }
                        val lst = ArrayList<DayOption>()
                        for (q3 in i + 1 until all.size) {
                            val c3 = all[q3]
                            if (c3.date.isBefore(today)) continue
                            if (daysBetween(today, c3.date) > 13) break
                            if (mvAny(c3)) lst.add(DayOption(c3.date, dlabel(c3), whatOf(c3)))
                        }
                        d.mvList = lst
                    }
                    miss[w.i] = (miss[w.i] ?: 0) + 1
                    if (d.kind == Kinds.QUALITY) hq.add(w.i)
                    if (d.kind == Kinds.LONG) hl.add(w.i)
                }
            }
            // blok strength / ankle / upper yang terlewat
            if (d.str != null && d.kind != Kinds.REST && "${d.date}:s" !in inp.done) {
                var tg: PDay? = null
                if (d.str!!.adj == null) {
                    var j = i + 1
                    while (j < all.size && all[j].week === w) {
                        val c = all[j]
                        if (!c.date.isBefore(today) && (c.role == "easy" || c.role == "short") && c.str == null) { tg = c; break }
                        j++
                    }
                }
                if (tg != null) {
                    tg.str = d.str!!.withAdj(DayAdj("in", "Digeser dari ${dlabel(d)}"))
                    d.str = d.str!!.withAdj(DayAdj("out", "Digeser ke ${dlabel(tg)}"))
                } else d.str = d.str!!.withAdj(DayAdj("miss", "Terlewat"))
            }
            if (d.ank != null && d.kind != Kinds.REST && "${d.date}:a" !in inp.done) d.ank = d.ank!!.withAdj(DayAdj("miss", "Terlewat"))
            if (d.up != null && d.kind != Kinds.REST && "${d.date}:u" !in inp.done) d.up = d.up!!.withAdj(DayAdj("miss", "Terlewat"))
        }

        ok.weeks.forEachIndexed { k, w ->
            w.missed = miss[w.i] ?: 0
            val nxw = ok.weeks.getOrNull(k + 1)
            if (nxw != null && (w.missed >= 3 || (w.i in hq && w.i in hl))) {
                nxw.adj80 = true
                nxw.days.forEach { dd -> if (dd.kind in RUNK && dd.km > 0 && !isDone(inp, dd)) dd.km = max(3.0, Js.round(dd.km * .8)) }
                nxw.km = nxw.days.sumOf { it.km }
            }
        }
        swLists(all, inp)
        spLists(all, inp)
        return ok
    }
}
