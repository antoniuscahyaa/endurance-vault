package com.endurancevault.app.domain

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Rekomendasi sesi lari hari ini untuk mode "No Race" (rtype = "none"), dari pola lari 28 hari terakhir.
 * Murni Kotlin (tanpa Android) agar bisa diuji unit.
 *
 * Urutan keputusan: (1) sudah lari hari ini, (2) keselamatan (nyeri, readiness rendah), (3) data terlalu sedikit,
 * (4) beban berlebih / sudah cukup sering lari -> istirahat, (5) pemulihan setelah sesi berat, (6) long run bila hari
 * ini hari long run kebiasaan atau sudah waktunya, (7) lari easy. Jarak dibatasi agar volume pekan ini tidak melewati
 * sekitar 110% dari kebiasaan.
 */
object FreeRunRecommender {
    const val WINDOW_DAYS = 28
    const val MIN_RUN_DAYS = 3

    data class Run(val date: LocalDate, val km: Double, val minutes: Double, val avgHr: Int?, val gain: Int? = null)

    enum class Kind { DONE, REST, RECOVERY, EASY, LONG, START }

    data class Input(
        val runs: List<Run>,
        val today: LocalDate,
        /** Batas HR easy (zona 2 atas); null bila zona belum valid. */
        val easyHrCap: Int? = null,
        /** Pace easy terbaru (menit per km); null bila belum ada lari easy yang memenuhi syarat. */
        val easyPaceMin: Double? = null,
        val fallbackPaceMin: Double = 6.5,
        val readinessScore: Int? = null,
        val readinessEasyThreshold: Int = 35,
        val readinessSwapThreshold: Int = 50,
        /** ATL:CTL; 0 atau null = belum ada. */
        val acwr: Double? = null,
        /** Nyeri terparah (1..5) dalam 3 hari terakhir; 0 = tidak ada. */
        val recentPain: Int = 0,
    )

    data class Rec(
        val kind: Kind,
        val title: String,
        val km: Double,
        val minutes: Int?,
        val hrLimit: Int?,
        val paceText: String?,
        val summary: String,
        val reasons: List<String>,
        val basis: String,
    )

    /** [maxKm] = lari tunggal terpanjang di hari itu; dipakai sebagai acuan long run agar dua lari di hari yang sama tidak terhitung satu lari panjang. */
    private class Day(val date: LocalDate, val km: Double, val minutes: Double, val hr: Double?, val maxKm: Double = km)

    private val DAY_NAMES = listOf("Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu")

    private fun r05(x: Double) = (x * 2).roundToInt() / 2.0
    private fun kmStr(x: Double) = if (x == Math.floor(x)) x.toLong().toString() else "%.1f".format(java.util.Locale.US, x).replace('.', ',')
    private fun oneDec(x: Double) = "%.1f".format(java.util.Locale.US, x).replace('.', ',')

    private fun paceStr(minPerKm: Double): String {
        val s = (minPerKm * 60).roundToInt()
        return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
    }

    /**
     * Buang entri ganda (mis. file yang sama terimpor dua kali): pada tanggal yang sama, lari yang jaraknya beda < 0,3 km dan
     * durasinya beda < 3 menit dari lari yang sudah dipertahankan dianggap satu lari. Dua lari berbeda di hari yang sama tetap dihitung.
     */
    internal fun dropNearDuplicates(runs: List<Run>): List<Run> {
        val kept = ArrayList<Run>()
        for (r in runs.sortedWith(compareBy<Run>({ it.date }, { -it.km }))) {
            val dup = kept.any { k -> k.date == r.date && abs(k.km - r.km) < 0.3 && abs(k.minutes - r.minutes) < 3.0 }
            if (!dup) kept += r
        }
        return kept
    }

    private fun median(v: List<Double>): Double {
        if (v.isEmpty()) return 0.0
        val s = v.sorted()
        return if (s.size % 2 == 1) s[s.size / 2] else (s[s.size / 2 - 1] + s[s.size / 2]) / 2
    }

    fun recommend(i: Input): Rec {
        val today = i.today
        if (i.runs.any { it.date == today && it.km > 0 }) {
            return Rec(Kind.DONE, "Sesi hari ini selesai", 0.0, null, null, null,
                "Lari hari ini sudah tercatat. Pulihkan diri dengan baik.", emptyList(), "")
        }

        // Satu entri per hari (dua lari di hari yang sama digabung), hanya 28 hari sebelum hari ini.
        val from = today.minusDays(WINDOW_DAYS.toLong())
        val byDay: Map<LocalDate, Day> = dropNearDuplicates(i.runs
            .filter { it.km > 0 && !it.date.isBefore(from) && it.date.isBefore(today) })
            .groupBy { it.date }
            .mapValues { (d, v) ->
                val km = v.sumOf { it.km }
                val mins = v.sumOf { it.minutes }
                val hrRuns = v.filter { it.avgHr != null && it.avgHr > 0 && it.minutes > 0 }
                val hr = if (hrRuns.isEmpty()) null else hrRuns.sumOf { it.avgHr!! * it.minutes } / hrRuns.sumOf { it.minutes }
                Day(d, km, mins, hr, v.maxOf { it.km })
            }
        val days = byDay.values.sortedBy { it.date }
        val n = days.size
        val totalKm = days.sumOf { it.km }
        val perWeekRuns = n / 4.0
        val weeklyKm = totalKm / 4.0
        val recent14 = days.filter { ChronoUnit.DAYS.between(it.date, today) in 1L..14L }.sumOf { it.km }
        val baseWeekly = if (n == 0) 0.0 else recent14 / 2.0 * 0.6 + weeklyKm * 0.4
        val load6 = days.filter { ChronoUnit.DAYS.between(it.date, today) in 1L..6L }.sumOf { it.km }
        val runs6 = days.count { ChronoUnit.DAYS.between(it.date, today) in 1L..6L }
        val freq = perWeekRuns.roundToInt().coerceIn(2, 6)
        val med = median(days.map { it.km })
        val longThr = max(med * 1.4, med + 2.0)
        val isLong = { d: Day -> n >= 5 && d.km >= longThr }
        val cap = i.easyHrCap?.takeIf { it in 100..220 }
        val isHard = { d: Day -> cap != null && d.hr != null && d.hr > cap + 3 }
        val yesterday = byDay[today.minusDays(1)]
        val lastDay = days.lastOrNull()
        val daysSinceLast = lastDay?.let { ChronoUnit.DAYS.between(it.date, today) }
        var streak = 0
        while (byDay.containsKey(today.minusDays(streak + 1L))) streak++
        val longDays = days.filter(isLong)
        val lastLong = longDays.lastOrNull()
        val daysSinceLong = lastLong?.let { ChronoUnit.DAYS.between(it.date, today) }
        val dow = today.dayOfWeek
        val dowName = DAY_NAMES[dow.value - 1]
        val dowRuns = days.count { it.date.dayOfWeek == dow }
        val longToday = longDays.any { it.date.dayOfWeek == dow }

        val basis = if (n == 0) "Belum ada lari tercatat dalam 28 hari terakhir."
        else "Dari $n lari dalam 28 hari terakhir (rata-rata ${oneDec(perWeekRuns)} lari dan ${oneDec(weeklyKm)} km per pekan)."

        val paceBase = i.easyPaceMin?.takeIf { it in 3.0..12.0 }
            ?: days.filter { !isHard(it) && it.km > 0 && it.minutes > 0 }.let { e ->
                val km = e.sumOf { it.km }; if (km > 0) e.sumOf { it.minutes } / km else null
            }?.takeIf { it in 3.0..12.0 }
            ?: i.fallbackPaceMin
        fun paceRange(p: Double) = "${paceStr(p - 0.25)}–${paceStr(p + 0.25)} /km"

        fun rest(reasons: List<String>) = Rec(Kind.REST, "Istirahat", 0.0, null, null, null,
            "Beri tubuhmu libur hari ini. Jalan santai atau mobilitas ringan boleh.", reasons, basis)

        val score = i.readinessScore
        val acwr = i.acwr?.takeIf { it > 0 }

        // (2) keselamatan
        if (i.recentPain >= 4) return rest(listOf("Nyeri ${i.recentPain}/5 tercatat dalam 3 hari terakhir."))
        if (score != null && score < i.readinessEasyThreshold) {
            return rest(listOf("Readiness $score di bawah batas ${i.readinessEasyThreshold}."))
        }

        // (3) data terlalu sedikit
        if (n < MIN_RUN_DAYS) {
            val rs = mutableListOf("Data lari masih sedikit, jadi mulai dengan durasi dan HR rendah.")
            if (score != null && score < i.readinessSwapThreshold) rs.add("Readiness $score belum penuh, jadi sesi dibuat ringan.")
            return Rec(Kind.START, "Lari santai", 0.0, 25, cap, paceRange(paceBase + 0.2),
                "Mulai dengan lari santai 20–30 menit dan catat hasilnya agar saran makin akurat.", rs, basis)
        }

        // (4) istirahat karena beban atau frekuensi
        val yLong = yesterday != null && isLong(yesterday)
        val yHard = yesterday != null && isHard(yesterday)
        if (streak >= 4 || (streak >= 3 && (yLong || yHard))) {
            return rest(listOf("Sudah lari $streak hari berturut-turut."))
        }
        if (acwr != null && acwr >= 1.5 && yesterday != null) {
            return rest(listOf("ACWR ${"%.2f".format(java.util.Locale.US, acwr)} di atas rentang optimal dan kemarin kamu lari."))
        }
        if (yesterday != null && runs6 >= freq + 1) {
            return rest(listOf("$runs6 lari dalam 6 hari terakhir, lebih banyak dari kebiasaanmu (sekitar $freq per pekan)."))
        }
        if (n >= 8 && dowRuns == 0 && yesterday != null && runs6 >= freq - 1) {
            return rest(listOf("Biasanya kamu tidak lari pada hari $dowName."))
        }
        val budget = if (baseWeekly > 0) baseWeekly * 1.10 - load6 else Double.MAX_VALUE
        if (budget < 2.0 && runs6 >= freq) {
            return rest(listOf("Volume pekan ini sudah mencapai kebiasaanmu (${kmStr(load6)} km dari sekitar ${kmStr(baseWeekly)} km)."))
        }

        val easyDays = days.filter { !isLong(it) }
        val easyMed = median(easyDays.map { it.km }).takeIf { it > 0 } ?: med
        fun capKm(x: Double, reasons: MutableList<String>): Double {
            if (budget == Double.MAX_VALUE) return x
            val allowed = max(budget, 2.5)
            return if (x > allowed) {
                reasons.add("Jarak dibatasi agar volume pekan ini tidak melewati sekitar ${kmStr(baseWeekly * 1.1)} km.")
                allowed
            } else x
        }

        // (5) pemulihan
        val needRecovery = yLong || yHard || (score != null && score < i.readinessSwapThreshold) ||
            (acwr != null && acwr > 1.3) || i.recentPain == 3
        if (needRecovery) {
            val rs = mutableListOf<String>()
            if (yLong) rs.add("Kemarin lari panjang (${kmStr(yesterday!!.km)} km).")
            if (yHard) rs.add("Kemarin HR rata-rata di atas batas easy.")
            if (score != null && score < i.readinessSwapThreshold) rs.add("Readiness $score belum penuh, jadi sesi dibuat ringan.")
            if (acwr != null && acwr > 1.3) rs.add("ACWR ${"%.2f".format(java.util.Locale.US, acwr)} di atas rentang optimal.")
            if (i.recentPain == 3) rs.add("Nyeri 3/5 tercatat dalam 3 hari terakhir.")
            val km = r05(capKm((easyMed * 0.6).coerceIn(2.5, 6.0), rs)).coerceAtLeast(2.0)
            val p = paceBase + 0.4
            rs.add("Pace easy dari lari terakhir sekitar ${paceStr(paceBase)} /km; pemulihan dibuat lebih pelan.")
            return Rec(Kind.RECOVERY, "Lari pemulihan", km, (km * p).roundToInt(), cap?.let { it - 5 }, paceRange(p),
                "Lari sangat santai untuk memulihkan kaki.", rs, basis)
        }

        // (6) long run
        val longDue = daysSinceLong != null && daysSinceLong >= 7 && n >= 6
        if (yesterday == null && (longToday || longDue) && (daysSinceLong == null || daysSinceLong >= 5)) {
            val rs = mutableListOf<String>()
            if (longToday) rs.add("Hari $dowName biasanya hari long run kamu.") else rs.add("Lari panjang terakhir $daysSinceLong hari lalu.")
            val ref = lastLong?.maxKm ?: (med * 1.4)
            var km = max(ref * 1.05, easyMed + 1.0)
            km = min(km, ref + max(1.0, ref * 0.10))
            if (baseWeekly > 0) km = min(km, max(baseWeekly * 0.40, easyMed + 1.0))
            km = r05(capKm(km, rs)).coerceAtLeast(3.0)
            rs.add("Jarak naik bertahap dari long run terakhir (${kmStr(ref)} km).")
            val p = paceBase + 0.15
            rs.add("Pace easy dari lari terakhir sekitar ${paceStr(paceBase)} /km.")
            return Rec(Kind.LONG, "Long run", km, (km * p).roundToInt(), cap, paceRange(p),
                "Lari panjang pelan untuk membangun daya tahan.", rs, basis)
        }

        // (7) lari easy
        val rs = mutableListOf<String>()
        rs.add("Jarak mengikuti lari easy biasa kamu (median ${kmStr(easyMed)} km).")
        var km = easyMed
        if (acwr != null && acwr < 0.8) { km *= 1.10; rs.add("Beban 7 hari di bawah kebiasaan, jadi jarak naik sedikit.") }
        else if (acwr != null && acwr > 1.2) { km *= 0.90; rs.add("Beban 7 hari mulai tinggi, jadi jarak dikurangi sedikit.") }
        km = r05(capKm(km, rs)).coerceAtLeast(2.0)
        rs.add("Pace easy dari lari terakhir sekitar ${paceStr(paceBase)} /km.")
        if (streak >= 2) rs.add("Sudah lari $streak hari berturut-turut, jadi jaga tetap ringan.")
        return Rec(Kind.EASY, "Lari easy", km, (km * paceBase).roundToInt(), cap, paceRange(paceBase),
            "Lari santai di zona 2, tanpa memaksa pace.", rs, basis)
    }
}
