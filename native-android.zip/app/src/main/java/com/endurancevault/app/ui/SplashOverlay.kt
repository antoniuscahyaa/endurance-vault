package com.endurancevault.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import kotlinx.coroutines.delay

/**
 * Splash tahap 2. Tahap 1 (splash sistem Android) hanya warna aksen tanpa ikon
 * (lihat Theme.EnduranceVault.Splash). Di sini: area gelap naik dari bawah dengan tepi atas
 * berupa garis siluet, logo (warna asli ikon) muncul di tengah layar, lalu semuanya memudar.
 *
 * Logo terkunci di tengah layar, lebar LOGO_WIDTH_FRAC x lebar layar.
 * Garis siluet (RIDGE) disimpan sebagai pasangan (dx, dy) dalam px layar referensi 324 x 724,
 * relatif terhadap PUSAT layar, lalu diskalakan w / 324. Dengan begitu jarak siluet ke logo
 * selalu sama di semua ukuran/rasio layar (siluet mengikuti logo, bukan tinggi layar).
 *
 * Huruf E diberi outline gelap setebal E_OUTLINE_REF_PX, hanya di bagian yang menempel pada latar oranye
 * (di atas garis siluet); di area gelap outline menyatu dan tidak terlihat.
 *
 * Bagian kanan garis adalah offset berjarak tetap (~13 px referensi) dari tepi atas V dan panah.
 * Ubah RIDGE lewat editor siluet, jangan diedit manual.
 */
private const val REF_W = 324f
private const val SYM_W = 860f
private const val SYM_H = 590f
private const val LOGO_WIDTH_FRAC = 0.55f
private const val E_OUTLINE_REF_PX = 3.5f // tebal outline huruf E di area oranye (px referensi 324, diskalakan w / 324)
private const val RISE_MS = 450
private const val FADE_MS = 250
private const val HOLD_MS = 700L

private val SplashBg = Color(0xFFEA5F0A)
private val SplashInk = Color(0xFF0B0C0F)

private val RIDGE = floatArrayOf(-162.0f, 30.4f, -109.2f, -11.6f, -83.6f, 14.5f, -44.1f, -3.6f, -29.2f, -16.0f, -28.5f, -20.4f, -26.8f, -23.7f, -23.8f, -26.6f, -20.2f, -28.4f, -16.5f, -29.0f, 9.5f, -29.0f, 14.0f, -27.8f, 18.0f, -25.0f, 26.8f, -11.4f, 44.8f, -40.2f, 45.2f, -53.8f, 46.5f, -57.3f, 48.8f, -60.4f, 53.8f, -63.5f, 85.2f, -73.7f, 89.0f, -74.2f, 162.0f, -84.7f)
private const val RIDGE_MIN_DY = -84.7f

// Logo: warna sama dengan ikon launcher (res/drawable/ic_launcher_foreground.xml)
private val LG_MTN_RIGHT = floatArrayOf(340f, 455f, 360f, 442f, 411f, 465f, 434f, 438f, 512f, 583f, 415f, 583f)
private val LG_MTN_MID = floatArrayOf(98f, 583f, 146f, 534f, 224f, 579f, 315f, 482f, 378f, 577f)
private val LG_BAR = floatArrayOf(562f, 583f, 655f, 583f, 852f, 245f, 803f, 182f)
private val LG_TRI = floatArrayOf(160f, 431f, 248f, 437f, 210f, 470f)
private val LG_E = floatArrayOf(0f, 18f, 390f, 18f, 443f, 130f, 113f, 130f, 113f, 225f, 310f, 225f, 365f, 332f, 113f, 332f, 113f, 429f, 127f, 435f, 0f, 549f)
private val LG_TREND = floatArrayOf(7f, 583f, 140f, 453f, 218f, 500f, 337f, 372f, 418f, 415f, 402f, 442f, 347f, 420f, 219f, 547f, 143f, 503f, 60f, 583f)
private val LG_V = floatArrayOf(352f, 218f, 472f, 218f, 557f, 362f, 737f, 75f, 710f, 48f, 860f, 0f, 838f, 165f, 795f, 130f, 558f, 528f, 540f, 548f)
private val LgLight = Color(0xFFC9CACD)
private val LgMid = Color(0xFF9A9CA1)
private val LgE = Color(0xFFF5F5F6)
private val LgOrange = Color(0xFFFC6808)

private fun polyPath(p: FloatArray, s: Float, ox: Float, oy: Float): Path {
    val path = Path()
    path.moveTo(ox + p[0] * s, oy + p[1] * s)
    var i = 2
    while (i < p.size) {
        path.lineTo(ox + p[i] * s, oy + p[i + 1] * s)
        i += 2
    }
    path.close()
    return path
}

private fun DrawScope.poly(p: FloatArray, color: Color, s: Float, ox: Float, oy: Float, alpha: Float) {
    drawPath(polyPath(p, s, ox, oy), color, alpha = alpha)
}

@Composable
fun SplashOverlay() {
    // rememberSaveable: tidak diputar ulang saat rotasi layar
    var visible by rememberSaveable { mutableStateOf(true) }
    if (!visible) return
    val rise = remember { Animatable(0f) }
    val fade = remember { Animatable(1f) }
    LaunchedEffect(Unit) {
        rise.animateTo(1f, tween(RISE_MS, easing = FastOutSlowInEasing))
        delay(HOLD_MS)
        fade.animateTo(0f, tween(FADE_MS))
        visible = false
    }
    Canvas(
        Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = fade.value }
            // selama tampil, sentuhan tidak diteruskan ke layar di bawahnya
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) awaitPointerEvent().changes.forEach { it.consume() }
                }
            }
    ) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val cy = h / 2f
        drawRect(SplashBg)

        // Area gelap: tepi atas = RIDGE, penuh ke bawah. Naik dari bawah layar.
        val k = w / REF_W
        val ridgeTop = cy + RIDGE_MIN_DY * k
        val offset = (1f - rise.value) * (h - ridgeTop + 4f)
        val dark = Path()
        dark.moveTo(cx + RIDGE[0] * k, cy + RIDGE[1] * k + offset)
        var i = 2
        while (i < RIDGE.size) {
            dark.lineTo(cx + RIDGE[i] * k, cy + RIDGE[i + 1] * k + offset)
            i += 2
        }
        dark.lineTo(w, h + offset + 1f)
        dark.lineTo(0f, h + offset + 1f)
        dark.close()
        drawPath(dark, SplashInk)

        // Logo terkunci di tengah layar; muncul memudar saat area gelap naik
        val a = ((rise.value - 0.35f) / 0.65f).coerceIn(0f, 1f)
        val s = LOGO_WIDTH_FRAC * w / SYM_W
        val ox = cx - SYM_W / 2f * s
        val oy = cy - SYM_H / 2f * s
        poly(LG_MTN_RIGHT, LgLight, s, ox, oy, a)
        poly(LG_MTN_MID, LgMid, s, ox, oy, a)
        poly(LG_BAR, LgLight, s, ox, oy, a)
        poly(LG_TRI, LgLight, s, ox, oy, a)
        // Outline E: hanya di luar area gelap (= area oranye), digambar sebelum isi E
        clipPath(dark, clipOp = ClipOp.Difference) {
            drawPath(
                polyPath(LG_E, s, ox, oy),
                SplashInk,
                alpha = a,
                style = Stroke(width = 2f * E_OUTLINE_REF_PX * k, join = StrokeJoin.Round),
            )
        }
        poly(LG_E, LgE, s, ox, oy, a)
        poly(LG_TREND, LgOrange, s, ox, oy, a)
        poly(LG_V, LgOrange, s, ox, oy, a)
    }
}
