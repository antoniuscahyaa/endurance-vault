package com.endurancevault.app.domain

import java.time.LocalDate
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * Port dari plan(s) di versi web (src/js/main/02-i18n-penyimpanan-perencana.js dan 05-lomba-tema-prediksi.js).
 *
 * Sudah ada: semua jenis lomba (5K, 10K, HM, FM, No Race, Performance Build, Trail, Ultra road), konversi dan pemulihan
 * Performance Build, mulai ulang mileage (pbAk), minggu lomba, event latihan, minggu sepeda (6 hari), estimasi jarak sesi
 * kualitas, jalur long run trail (loop Ungaran) dengan D+ per sesi.
 * Tahap 1b: sesi quality kedua (QualityTwo.kt), metode latihan pyramidal/polarized/MAF (TrainingMethod.kt), dan
 * penempatan strength/ankle/upper (Strength.kt).
 * Penghalus D+ mingguan (GainSpread.kt) aktif untuk trail kecuali gSmooth=false.
 * Pace easy dari log lewat parameter easyPace (EasyPace.kt). Belum ada: terjemahan Inggris.
 */
object PlanEngine {
    private const val UNG_KM = 7.0
    private const val UNG_GAIN = 750
    private val REST_OK = listOf(6, 5, 3, 2)

    /* ---------- hari libur dan peran mingguan ---------- */
    internal class RestCfg(val L: Int, val five: Boolean, val ks: List<Int>)

    internal fun restCfgOf(s: PlanSettings): RestCfg = restCfg(s)

    private fun restCfg(s: PlanSettings): RestCfg {
        val L = if (s.longDay in 0..6) s.longDay else 6
        val five = s.days == 5
        fun kOf(d: Int) = ((L - d) % 7 + 7) % 7
        var k1 = kOf(s.rest); if (k1 !in REST_OK) k1 = 6
        val ks = mutableListOf(k1)
        if (five) {
            var k2 = kOf(s.rest2)
            if (k2 !in REST_OK || k2 == k1) k2 = listOf(2, 6, 5, 3).first { it != k1 }
            ks.add(k2)
        }
        return RestCfg(L, five, ks)
    }

    internal fun weekRoles(s: PlanSettings): List<String> {
        val c = restCfg(s)
        val t = mutableListOf("long", "medium", "short", "easy", "quality", "easy", "rest")
        var cur = listOf(6)
        if (c.five) { t[2] = "rest"; cur = listOf(6, 2) }
        val drop = cur.filter { it !in c.ks }; val pick = c.ks.filter { it !in cur }
        drop.forEachIndexed { i, k -> t[k] = t[pick[i]]; t[pick[i]] = "rest" }
        return (0 until 7).map { d -> t[((c.L - d) % 7 + 7) % 7] }
    }

    /* ---------- bobot ---------- */
    private class Weights(val map: Map<String, Double>, val isDefault: Boolean) {
        fun wt(r: String, ph: String): Double {
            if (ph == Phases.PEAK && isDefault) { if (r == "long") return .30; if (r == "medium") return .26 }
            return map[r] ?: map.getValue("easy")
        }
    }

    /* ---------- Performance Build ---------- */
    private fun pbPostWeeks(s: PlanSettings, st0: LocalDate, n: Int, lvl: Double): List<PWeek> {
        val roles = weekRoles(s)
        val fr = if (n == 1) listOf(.5) else listOf(.4, .6)
        val wtm = mapOf("long" to 1.3, "medium" to 1.1, "short" to .8, "easy" to 1.0, "quality" to 1.0)
        val out = mutableListOf<PWeek>()
        for (i in 0 until n) {
            val ws = st0.plusDays(i * 7L)
            val km = max(10.0, Js.round(lvl * fr[i]))
            val run = (0 until 7).filter { roles[it] != "rest" }.toMutableList()
            val free = if (i == 0) run.removeAt(0) else -1
            var sum = 0.0
            run.forEach { sum += wtm[roles[it]] ?: 1.0 }
            val days = mutableListOf<PDay>(); var tot = 0.0
            for (d in 0 until 7) {
                val o = PDay(ws.plusDays(d.toLong()), d, Kinds.REST, "rest", "Libur", 0.0, "Istirahat total.")
                if (d == free) {
                    o.title = "Libur pemulihan"
                    o.detail = "Hari pertama sesudah lomba: istirahat total, boleh jalan kaki santai."
                } else if (d in run) {
                    o.kind = Kinds.EASY; o.grp = "easy"; o.role = roles[d]; o.title = "Easy pemulihan"
                    o.km = max(3.0, Js.round(km * (wtm[roles[d]] ?: 1.0) / sum))
                    o.detail = "Pemulihan pasca-lomba: lari sangat santai, HR ≤ ${s.hr} (lebih rendah lebih baik), tanpa tanjakan dan tanpa strides. Boleh diganti jalan kaki atau sepeda santai. Berhenti bila ada nyeri."
                }
                tot += o.km; days.add(o)
            }
            out.add(PWeek(i, ws, ws.plusDays(6), Phases.BASE, false, true, false, days, Js.round(tot * 10) / 10))
        }
        return out
    }

    private class Ak(val a: Int, val km: Double)

    /** @return Ak, null, atau pesan galat (String) */
    private fun pbAkOf(s: PlanSettings, start: LocalDate, n: Int, peak: Double): Any? {
        val c = s.pbAk ?: return null
        if (s.rtype != "pb") return null
        val km = c.km
        if (!(km >= 10 && km <= 200)) return null
        val a = Js.roundI(Js.diffDays(c.wk, start) / 7.0)
        if (!(a >= 0 && a < n)) return null
        if (km > peak) return "Km mulai ulang (${Js.n(km)}) tidak boleh melebihi Km mingguan puncak (${Js.n(peak)})."
        return Ak(a, km)
    }

    private fun pbAkLevel(ak: Ak, i: Int, peak: Double, step: Double, pbL: Int): Double {
        val lv = if ((ak.a + 1) % pbL == 0) min(peak, ak.km / .8) else ak.km
        return if (i == ak.a) ak.km else min(peak, lv + step * (i - ak.a))
    }

    /* ---------- plan() ---------- */
    /** @param easyPace pace easy (menit/km) dari lari tercatat ([EasyPace.estimate]); null = pakai pengaturan pace. */
    fun plan(s: PlanSettings, today: LocalDate = LocalDate.now(), easyPace: Double? = null): PlanOutcome {
        val pr = if (s.rtype == "pb" && s.pbPost != null && s.pbPost.rec > 0) s.pbPost else null
        if (pr != null) {
            val rn = min(2, max(1, Js.roundI(pr.rec)))
            val st0 = Js.mondayOf(s.start)
            val inn = plan(s.copy(pbPost = null, start = st0.plusDays(rn * 7L)), today, easyPace)
            if (inn is PlanOutcome.Err) return inn
            inn as PlanOutcome.Ok
            inn.weeks.forEach { it.i += rn }
            val lvl = if (pr.lvl != 0.0) pr.lvl else s.base
            return PlanOutcome.Ok(
                pbPostWeeks(s, st0, rn, lvl) + inn.weeks, st0, inn.race, inn.n + rn,
                inn.noRace, inn.none, inn.build, inn.pbCycle, inn.convWk,
            )
        }
        val start = Js.mondayOf(s.start)
        if (s.rtype == "none") {
            val nw = max(6, floorDiv(Js.diffDays(today, start), 7) + 4)
            val ws0 = (0 until nw).map { wi ->
                val wst = start.plusDays(wi * 7L)
                val dys = (0 until 7).map { di -> PDay(wst.plusDays(di.toLong()), di, Kinds.REST, "rest", "Libur", 0.0, "") }.toMutableList()
                PWeek(wi, wst, wst.plusDays(6), Phases.BASE, false, false, false, dys, 0.0)
            }
            return PlanOutcome.Ok(ws0, start, start.plusDays(nw * 7L - 1), nw, true, true, false, 0, 0)
        }
        val pb = s.rtype == "pb"
        val cv = if (!pb && s.pbConv != null && s.pbConv.wk > 0) s.pbConv else null
        val bd = cv?.wk ?: 0
        val noRace = pb || s.race == null
        val pbN = if (pb) min(104, max(16, floorDiv(Js.diffDays(today, start), 7) + 13)) else 16
        val race = if (noRace) start.plusDays(pbN * 7L - 1) else s.race!!
        val n = floorDiv(Js.diffDays(race, start), 7) + 1
        if (!(race.isAfter(start)) || n - bd < 6) {
            return PlanOutcome.Err(
                if (cv != null) "Tanggal lomba harus minimal 6 minggu dari minggu transisi Performance Build."
                else "Tanggal lomba harus minimal 6 minggu setelah tanggal mulai.",
            )
        }
        if (n - bd > 70 && !pb) return PlanOutcome.Err("Rencana maksimal 70 minggu.")
        val base = s.base
        val peak = max(s.peak, base)
        val roles = weekRoles(s)
        val pbL = if (pb || cv != null) pbLen(s) else 4
        val rc = rcOf(s)
        val q = if (pb) 13 else n - rc.taper
        val rampEnd = if (pb) pbL * 3 else max(1, q - 3)
        val cw = if (pb) Weights(pbWeights(rc.w, pbFocusOf(s)), false) else Weights(rc.w, rc.w === W)
        val akRaw = if (pb) pbAkOf(s, start, n, peak) else null
        if (akRaw is String) return PlanOutcome.Err(akRaw)
        val ak = akRaw as Ak?
        var akStep = 0.0
        if (ak != null) {
            akStep = (peak - base) / rampEnd
            if (!(akStep > 0)) akStep = (peak - ak.km) / rampEnd
        }
        val weeks = mutableListOf<PWeek>()
        val gs: GainState? = if (rc.trail && s.gSmooth) GainState() else null
        for (i in 0 until n) {
            val ws = start.plusDays(i * 7L)
            val phase: String
            var cut = false
            phase = when {
                pb -> if (i < pbL) Phases.BASE else Phases.BUILD
                cv != null && i < bd -> Phases.BASE
                i >= q -> Phases.TAPER
                i >= q - 3 -> Phases.PEAK
                else -> if (i < Js.roundI((q - 3) * 0.4)) Phases.BASE else Phases.BUILD
            }
            val frac = if (cv != null) {
                if (i < bd) min(1.0, i.toDouble() / (pbL * 3)) else min(1.0, max(0.0, (i - bd).toDouble() / max(1, (q - 3) - bd)))
            } else min(1.0, i.toDouble() / rampEnd)
            var km: Double
            if (phase == Phases.TAPER) km = rc.tf[min(rc.tf.size - 1, i - q)] * peak
            else if (phase == Phases.PEAK) km = doubleArrayOf(.95, 1.0, .9)[min(2, max(0, i - (q - 3)))] * peak
            else {
                val kb = if (cv != null && i < bd) cv.b0 else base
                val kp = if (cv != null && i < bd) max(cv.p0, cv.b0) else peak
                km = kb + (kp - kb) * frac
                if (ak != null && i >= ak.a) km = pbAkLevel(ak, i, peak, akStep, pbL)
                if ((i + 1) % pbL == 0) { km = if (ak != null && i == ak.a) ak.km else km * .8; cut = true }
            }
            val raceOff = Js.diffDays(race, ws)
            val isRaceWeek = !pb && raceOff in 0..6
            val days = mutableListOf<PDay>()
            if (isRaceWeek) {
                raceWeek(s, ws, race, raceOff, km, roles, noRace, days)
            } else {
                normalWeek(s, rc, cw, roles, ws, i, q, phase, cut, km, frac, race, days, pb, pbL, bd, gs, easyPace)
            }
            var tot = 0.0; days.forEach { tot += it.km }
            tot = Js.round(tot * 10) / 10
            weeks.add(PWeek(i, ws, ws.plusDays(6), phase, cut, false, isRaceWeek, days, tot))
        }
        return PlanOutcome.Ok(weeks, start, race, n, noRace, false, pb, if (pb) pbL - 1 else 0, bd)
    }

    private fun floorDiv(a: Int, b: Int) = Math.floorDiv(a, b)

    private fun raceWeek(
        s: PlanSettings, ws: LocalDate, race: LocalDate, raceOff: Int, km: Double,
        roles: List<String>, noRace: Boolean, days: MutableList<PDay>,
    ) {
        val elig = (0 until raceOff).filter { roles[it] != "rest" }
        val rest = max(0.0, km - 3)
        val others = max(1, elig.size - 1)
        for (d2 in 0 until 7) {
            val dt = ws.plusDays(d2.toLong())
            if (dt.isAfter(race)) break
            val o = PDay(dt, d2, Kinds.REST, "rest", "Libur", 0.0, "Istirahat total.")
            if (d2 == raceOff) {
                o.kind = Kinds.RACE; o.grp = "race"
                if (noRace) {
                    o.title = "Akhir rencana"; o.km = max(5.0, Js.round(s.base * .2))
                    o.detail = "Rencana sementara 16 minggu berakhir di sini. Isi tanggal lomba di tab Atur agar rencana menyesuaikan."
                } else {
                    o.title = if (s.name.isNotEmpty()) "Lomba: ${s.name}" else "Lomba"
                    o.km = raceKmOf(s); o.detail = raceDetail(s)
                }
            } else if (d2 in elig) {
                val last = elig.last(); val prev = if (elig.size >= 2) elig[elig.size - 2] else -1
                o.kind = Kinds.EASY; o.grp = "easy"
                if (d2 == last) { o.title = "Shakeout"; o.km = 3.0; o.detail = "20–30 menit sangat santai, 3 strides." }
                else {
                    o.title = if (d2 == prev) "Easy + strides" else "Easy"
                    o.km = max(3.0, Js.round(rest / others))
                    o.detail = (if (d2 == prev) "Strides 4×20 dtk. " else "") + "HR ≤ ${s.hr}."
                }
            }
            days.add(o)
        }
    }

    private fun normalWeek(
        s: PlanSettings, rc: RC, cw: Weights, roles: List<String>, ws: LocalDate, i: Int, q: Int, phase: String,
        cut: Boolean, km: Double, frac: Double, race: LocalDate, days: MutableList<PDay>,
        pb: Boolean, pbL: Int, bd: Int, gs: GainState?, easyPace: Double?,
    ) {
        val tg = rc.trail && (!rc.road || (s.raceGain ?: 0.0) > 0)
        val gf = if (tg) min(2.0, max(.5, (s.raceGain?.takeIf { it != 0.0 } ?: 2400.0) / (s.raceKm?.takeIf { it != 0.0 } ?: 40.0) / 60)) else 0.0
        val g = if (tg) (25 + 35 * frac) * gf else 0.0
        val gm = if (tg) (20 + 25 * frac) * gf else 0.0
        var ws2 = 0.0
        roles.forEach { if (it != "rest") ws2 += cw.wt(it, phase) }
        val bikeWeek = s.days == 6 && (phase == Phases.BASE || phase == Phases.BUILD)
        val lAdj = mutableMapOf("long" to 1.0, "medium" to 1.0, "easy" to 1.0)
        if (s.days == 5 && ws2 > 0) {
            val cap5 = .35
            var lw5 = 0.0; var ow5 = 0.0
            roles.forEach { r ->
                if (r == "long") lw5 += cw.wt(r, phase) else if (r == "medium" || r == "easy") ow5 += cw.wt(r, phase)
            }
            if (lw5 > 0 && ow5 > 0 && lw5 / ws2 > cap5) {
                val nl5 = cap5 * ws2
                lAdj["long"] = nl5 / lw5; val x = (ow5 + lw5 - nl5) / ow5; lAdj["medium"] = x; lAdj["easy"] = x
            }
        }
        for (d3 in 0 until 7) {
            val role = roles[d3]; val dt3 = ws.plusDays(d3.toLong())
            val o3 = PDay(dt3, d3, role, "easy", "", 0.0, "")
            o3.role = role
            if (role == "rest") { o3.grp = "rest"; o3.title = "Libur"; o3.detail = "Istirahat total."; days.add(o3); continue }
            var kmr = max(3.0, Js.round(km * cw.wt(role, phase) * (lAdj[role] ?: 1.0) / ws2)).toInt()
            o3.km = kmr.toDouble()
            when (role) {
                "easy" -> { o3.title = "Easy"; o3.detail = "HR ≤ ${s.hr}." + (if (rc.road) "" else " Tanjakan boleh jalan.") }
                "short" -> { o3.title = "Easy pendek"; o3.detail = "HR ≤ ${s.hr}. Pemulihan sebelum akhir pekan." }
                "quality" -> quality(o3, s, rc, phase, i, cut, q)
                "medium" -> medium(o3, s, rc, phase, i, q, kmr, gm)
                "long" -> kmr = longRun(o3, s, rc, phase, i, q, kmr, g, gs != null)
            }
            days.add(o3)
        }
        val q2st = q2Stage(s, phase, cut, i, q, pb, pbL, bd)
        if (q2st > 0) q2Apply(days, s, rc, q2st, easyPace)
        TrainingMethod.methodQuality(days, s, rc, phase, cut)
        val evHit = s.evOn && s.evDate != null && s.evKm > 0 && s.evDate.isBefore(race) && days.any { it.date == s.evDate }
        if (!evHit) qualBalance(days, s, gm, easyPace)
        if (bikeWeek) {
            fun mkBike(dd: PDay, mins: Int, ttl: String) {
                val abk = Js.round(mins / 60.0 * s.bspd * 10) / 10
                val pm = Js.parsePaceStr(s.pace)
                val rd = max(5.0, Js.round(dd.km * pm / 5) * 5)
                dd.altMins = mins; dd.altKm = abk; dd.title = ttl
                val runTxt = "A · Lari: ${Js.n(dd.km)} km, sekitar ${Js.n(rd)} menit, HR ≤ ${s.hr}."
                dd.detail = "Pilih salah satu. $runTxt B · Sepeda: $mins menit (sekitar ${Js.fmtKm(abk)} km), zona 1–2, napas masih bisa bercakap, HR sekitar ${s.hr - 15}–${s.hr - 5} bpm. Rute datar atau tanjakan landai, gigi ringan, kadens 85–95."
            }
            val bm = 60 + min(15, Js.roundI(frac * 3) * 5)
            days.forEach { if (it.role == "short") mkBike(it, bm, "Easy pendek atau sepeda") }
            if (cut) days.firstOrNull { it.role == "easy" }?.let { mkBike(it, 60, "Easy atau sepeda") }
        }
        if (gs != null) {
            val rawG = GainSpread.gSum(days)
            if (rawG > 0) {
                val tfk = rc.tf[min(rc.tf.size - 1, max(0, i - q))]
                val third = phase == Phases.PEAK && (i - (q - 3)) == 2
                val tg2 = GainSpread.gainTarget(
                    gs.full, rawG, phase, cut, third, tfk, if (s.gBase > 0) s.gBase else 0.0,
                    GainSpread.GAIN_CEIL * (s.raceGain?.takeIf { it != 0.0 } ?: 2400.0),
                )
                if (tg2 > 0) {
                    var evi = -1; var evg = 0.0
                    if (s.evOn && s.evDate != null) {
                        for (y in days.indices) if (days[y].date == s.evDate) evi = y
                        if (evi > -1 && s.evKm > 0 && s.evDate.isBefore(race)) evg = s.evGain else evi = -1
                    }
                    val got = min(GainSpread.spread(days, tg2, evi, evg), tg2)
                    if (phase != Phases.TAPER && !cut && !third) gs.full = got
                }
            }
        }
        TrainingMethod.methodEasy(days, s, rc, phase, cut, easyPace)
        days.forEach { it.mk = null; it.mkLong = null; it.lk = 0; it.bd = null; it.glock = false }
        placeStrength(days, phase, i, q, cut, s)
        if (s.evOn && s.evDate != null) {
            val ei = days.indexOfFirst { it.date == s.evDate }
            if (ei > -1 && s.evKm > 0 && s.evDate.isBefore(race)) {
                days.forEachIndexed { idx, dd -> if (idx != ei && dd.km > 0) dd.km = max(3.0, Js.round(dd.km * .6)) }
                val gainTxt = if (s.evGain > 0) "Sekitar +${Js.idn(s.evGain.toInt())} m. " else ""
                val ev = PDay(
                    s.evDate, ei, Kinds.EVENT, "race",
                    (if (rc.road) "Event latihan: road " else "Event latihan: trail ") + Js.n(s.evKm) + " km", s.evKm,
                    if (rc.road) gainTxt + "Berlaku bila dapat slot. Mulai pelan, HR dekat batas easy."
                    else "Sekitar +${Js.idn(s.evGain.toInt())} m. Berlaku bila dapat slot; tujuannya sertifikat trail baru. Jalan santai di tanjakan, HR dekat batas easy.",
                )
                ev.gain = s.evGain.toInt()
                days[ei] = ev
            }
        }
    }

    private fun quality(o3: PDay, s: PlanSettings, rc: RC, phase: String, i: Int, cut: Boolean, q: Int) {
        o3.grp = "quality"
        if (rc.trail) {
            o3.title = when (phase) {
                Phases.BASE -> if (!cut && i % 2 == 0) "Threshold ringan" else "Easy + pendek-cepat"
                Phases.BUILD -> "Sesi kualitas"
                Phases.PEAK -> if (rc.road) "Sesi tempo" else "Sesi tanjakan"
                else -> "Easy + strides"
            }
            o3.detail = qDetail(phase, i, cut, s, rc.road)
            qParse(o3, s)
        } else {
            val rq = roadQ(s, rc, phase, i, cut, q)
            o3.title = rq.title; o3.detail = rq.detail; o3.qk = rq.k; o3.qMin = rq.min; o3.qBand = rq.band
        }
        if (cut && (phase == Phases.BASE || phase == Phases.BUILD)) {
            o3.title = "Uji kebugaran · loop 6,3 km"; o3.bench = true; o3.qk = "none"; o3.qMin = 0.0
            o3.km = max(o3.km, 6.3)
            o3.detail = "Tanpa pemanasan: mulai langsung dari titik awal loop Ambarawa 6,3 km (+65 m), full easy dengan HR di sekitar batas easy (${s.hr}). Pace dan HR loop dianalisa sendiri di ringkasan akhir siklus dan dibandingkan dengan siklus sebelumnya. Kekurangan jarak sesi ditambahkan easy sesudah loop, di sesi yang sama."
        }
    }

    private fun medium(o3: PDay, s: PlanSettings, rc: RC, phase: String, i: Int, q: Int, kmr: Int, gm: Double) {
        if (!rc.trail || phase == Phases.BASE || (rc.road && phase != Phases.PEAK)) {
            o3.title = "Easy sedang"
            o3.detail = "HR ≤ ${s.hr}." + (if (!rc.trail && (phase == Phases.BUILD || phase == Phases.PEAK)) " Boleh ditutup dengan strides 4×20 dtk." else "")
        } else if (rc.road && !(gm > 0)) {
            o3.title = "Back-to-back · hari 1"; o3.b2b = 1
            o3.detail = "Easy di jalan datar, HR ≤ ${s.hr}. Long run pertama dari dua hari berturut-turut: bawa perlengkapan seperti hari lomba. Besok long run dalam keadaan lelah, jadi jangan kejar pace."
        } else {
            val mg = Js.r50(kmr * gm); o3.gain = mg
            if (phase == Phases.PEAK) {
                o3.title = "Back-to-back · hari 1"; o3.b2b = 1
                val mk = { gg: Int ->
                    o3.gain = if (gg > 0) gg else null
                    o3.detail = (if (gg > 0) "Di jalan bergelombang, sekitar +${Js.idn(gg)} m, easy. " else "Easy. ") +
                        "Long run pertama dari dua hari berturut-turut: bawa perlengkapan seperti hari lomba. Besok long run dalam keadaan lelah, jadi jangan kejar pace."
                }
                o3.mk = mk; mk(mg)
            } else if (phase == Phases.BUILD && i % 2 == 0) {
                val bs = Js.roundI((q - 3) * 0.4); val k = max(0, i - bs) / 2
                val full = k >= 2
                val dn = if (k < 2) 4 else min(5, 3 + (k - 2) / 2)
                val dm = if (full) 112 else 55
                o3.title = "Turunan Panjang–Kebonsari"; o3.gain = dn * dm; o3.glock = true
                o3.detail = "Rute Panjang–Kebonsari: 1,4 km, +112 m, rata-rata 7,6%. $dn ulangan turun " +
                    (if (full) "penuh dari Kebonsari (±112 m, 5–7 mnt)" else "mulai dari titik 1,0 km (±55 m), hindari bagian curam di ujung atas") +
                    ", total turun sekitar ${dn * dm} m. Naik kembali dengan jalan santai, HR ≤ ${s.hr}, dan tunggu HR turun sebelum ulangan berikutnya. Turun dengan usaha 5–6 dari 10, abaikan HR: langkah pendek dan cepat, kaki mendarat di bawah pinggul, jangan mengerem keras dengan tumit. Pemanasan dan pendinginan easy."
            } else {
                o3.title = "Easy bergelombang"
                val mk = { gg: Int ->
                    o3.gain = if (gg > 0) gg else null
                    o3.detail = (if (gg > 0) "Naik turun terkendali, sekitar +${Js.idn(gg)} m. " else "") + "HR ≤ ${s.hr} di datar."
                }
                o3.mk = mk; mk(mg)
            }
        }
    }

    /** @return kmr (jarak long run) yang mungkin berubah oleh loop trail */
    private fun longRun(o3: PDay, s: PlanSettings, rc: RC, phase: String, i: Int, q: Int, kmrIn: Int, g: Double, smooth: Boolean): Int {
        var kmr = kmrIn
        o3.grp = "long"
        val trail = !rc.road && (phase == Phases.PEAK || (phase == Phases.BUILD && i % 2 == 0))
        val loops = if (trail && rc.trail) max(1, Js.roundI(kmr / UNG_KM)) else 0
        val loc = if (trail) (if (loops > 0) "Ungaran via Perantunan · $loops loop" else "Ungaran via Perantunan (trail)") else "Ambarawa (jalan)"
        var lg = Js.r50(kmr * g)
        if (loops > 0) { kmr = Js.roundI(loops * UNG_KM); lg = loops * UNG_GAIN; o3.km = kmr.toDouble(); o3.trail = loops }
        val sim = phase == Phases.PEAK && ((i - (q - 3)) % 2 == 0)
        val detTail = if (rc.road) {
            when (phase) {
                Phases.BASE -> "Di jalan datar, jangan kejar pace."
                Phases.PEAK -> "Hari 2 back-to-back: mulai dengan kaki lelah, jaga usaha tetap terkendali."
                else -> "Jaga usaha terkendali dan evaluasi respons tubuh."
            }
        } else {
            when (phase) {
                Phases.BASE -> "Naik pelan, jangan kejar pace."
                Phases.PEAK -> "Hari 2 back-to-back: mulai dengan kaki lelah, jaga usaha terkendali saat menuruni medan."
                else -> "Jaga usaha terkendali saat menuruni medan."
            }
        }
        val simT = " Simulasi hari lomba: mulai pada jam start lomba (kalau start pagi buta, lari gelap dengan headlamp), pakai sepatu, tas, tongkat, dan perlengkapan wajib yang akan dipakai, dan jaga perlengkapan sesuai kebutuhan lomba."
        o3.title = (if (sim) "Simulasi lomba · " else "Long run · ") + loc + (if (phase == Phases.PEAK) " (hari 2)" else "")
        o3.gain = lg
        o3.detail = (if (loops > 0) "Ungaran via Perantunan, $loops loop (±${Js.n(UNG_KM)} km dan +$UNG_GAIN m per loop), total ±$kmr km. " else "") +
            (if (rc.road && !(lg > 0)) "" else "Sekitar +${Js.idn(lg)} m. ") + "HR ≤ ${s.hr}. " + detTail
        if (rc.road && !(lg > 0)) o3.gain = null
        if (phase == Phases.PEAK) o3.b2b = 2
        if (smooth && rc.trail) {
            val kmr0 = kmrIn
            o3.lk = loops
            o3.mkLong = { g2: Int, lp: Int ->
                val full = lp >= loops
                val k2 = if (lp > 0 && full) Js.roundI(lp * UNG_KM) else kmr0
                o3.km = k2.toDouble(); o3.gain = if (g2 > 0) g2 else null; o3.trail = if (lp > 0) lp else null
                o3.title = (if (sim) "Simulasi lomba · " else "Long run · ") +
                    (if (lp > 0) "Ungaran via Perantunan · $lp loop" else "Ambarawa (jalan)") + (if (phase == Phases.PEAK) " (hari 2)" else "")
                o3.detail = (if (lp > 0) "Ungaran via Perantunan, $lp loop (±${Js.n(UNG_KM)} km dan +$UNG_GAIN m per loop), " +
                    (if (full) "" else "sisa jarak easy di jalan datar Ambarawa, ") + "total ±$k2 km. " else "") +
                    (if (g2 > 0) "Sekitar +${Js.idn(g2)} m. " else "") + "HR ≤ ${s.hr}. " + detTail + (if (sim) simT else "")
            }
        }
        if (sim) { o3.sim = true; o3.detail += simT }
        if (!rc.trail) {
            o3.gain = null; o3.title = "Long run · Ambarawa (jalan)"
            o3.detail = roadLong(s, rc, phase, i, q, kmr, o3)
        }
        return kmr
    }
}
