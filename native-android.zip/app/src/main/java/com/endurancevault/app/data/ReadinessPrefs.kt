package com.endurancevault.app.data

import android.content.SharedPreferences
import com.endurancevault.app.domain.PainReadinessEntry
import com.endurancevault.app.domain.ReadinessConfig
import java.time.LocalDate

/**
 * Memuat [ReadinessConfig] dari SharedPreferences "readiness_settings". Satu sumber untuk layar Today dan AI Coach,
 * sehingga skor readiness yang dikirim ke AI sama dengan yang tampil di aplikasi.
 */
object ReadinessPrefs {
    const val FILE = "readiness_settings"

    fun load(prefs: SharedPreferences): ReadinessConfig = ReadinessConfig(
        swapThreshold = prefs.getInt("swap", 50),
        lightThreshold = prefs.getInt("light", 65),
        easyThreshold = prefs.getInt("easy", 35),
        sleepNeedHours = prefs.getFloat("sleep_need_hours", 7.5f).toDouble(),
        bikeHrOffset = prefs.getInt("bike_hr_offset", 8),
        bikeModeFactor = prefs.getFloat("bike_mode_factor", 1.25f).toDouble(),
        normalizeBikeLoad = prefs.getBoolean("normalize_bike_load", true),
        painEntries = runCatching {
            val arr = org.json.JSONArray(prefs.getString("pain_entries", "[]"))
            (0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i)?.let { o ->
                val rawArea = o.optString("area", "Lainnya")
                val area = mapOf("Betis" to "betis", "Tulang kering" to "tibia", "Ankle" to "ankle", "Achilles" to "achilles", "Tumit" to "tumit", "Plantar" to "plantar", "Punggung kaki" to "pkaki", "Lutut" to "lutut", "IT band" to "itband", "Paha depan" to "pahad", "Paha belakang" to "pahab", "Pangkal paha" to "groin", "Glute" to "glute", "Punggung bawah" to "pbawah", "Bahu" to "bahu").entries.firstOrNull { it.key.equals(rawArea, true) }?.value ?: rawArea.lowercase()
                val rawSide = o.optString("side", "b")
                val side = mapOf("Kiri" to "k", "Kanan" to "r", "Keduanya" to "b").entries.firstOrNull { it.key.equals(rawSide, true) }?.value ?: rawSide
                PainReadinessEntry(LocalDate.parse(o.getString("date")), area, o.optInt("severity", 1), side, o.optString("when", "sl"))
            } }
        }.getOrDefault(emptyList()),
        weights = if (prefs.getString("weight_mode", "default") == "default") emptyMap() else listOf("rec", "load", "sl", "debt", "hrv", "rhr", "shr", "pain", "leg", "mood")
            .mapNotNull { key -> if (prefs.contains("weight_$key")) key to prefs.getFloat("weight_$key", 0f).toDouble() else null }.toMap()
    )
}
