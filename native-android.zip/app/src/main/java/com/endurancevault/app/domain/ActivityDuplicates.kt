package com.endurancevault.app.domain

import com.endurancevault.app.data.ActivityEntity
import kotlin.math.abs

/**
 * Deteksi aktivitas ganda (mis. file yang sama terimpor dua kali, atau lari dari jam dan catatan manual).
 * Satu sumber aturan untuk impor, pemindaian manual, dan pemindaian otomatis. Murni, tanpa Android.
 */
object ActivityDuplicates {
    /** Selisih jarak maksimal (km) antara dua catatan yang sama; juga dipakai impor saat mencocokkan jejak ke catatan manual. */
    const val KM_TOL = 0.3
    /** Selisih durasi maksimal (detik) bila jam mulai tidak tersedia di salah satu catatan. */
    const val DUR_TOL_SEC = 180
    /** Selisih jam mulai maksimal (menit). */
    const val START_TOL_MIN = 1

    private fun minuteOfDay(value: String?): Int? {
        val v = value?.trim()?.takeIf { it.isNotEmpty() } ?: return null
        val parts = v.split(":")
        if (parts.size < 2) return null
        val h = parts[0].toIntOrNull() ?: return null
        val m = parts[1].toIntOrNull() ?: return null
        if (h !in 0..23 || m !in 0..59) return null
        return h * 60 + m
    }

    /** Kandidat duplikat: tanggal dan tipe sama, lalu jam mulai ≤ 1 menit; bila jam tidak ada, jarak dan durasi hampir sama. */
    fun sameActivity(a: ActivityEntity, b: ActivityEntity): Boolean {
        if (a.dateIso != b.dateIso || a.type != b.type) return false
        val ma = minuteOfDay(a.startTime); val mb = minuteOfDay(b.startTime)
        if (ma != null && mb != null) return abs(ma - mb) <= START_TOL_MIN
        return a.km > 0.0 && b.km > 0.0 && abs(a.km - b.km) < KM_TOL && abs(a.durationSec - b.durationSec) < DUR_TOL_SEC
    }

    /** Jejak impor ([date], [startTime], [km], [durationSec]) cocok dengan catatan [existing]; dipakai alur impor GPX/FIT. */
    fun matchesImport(existing: ActivityEntity, date: String, startTime: String?, km: Double, durationSec: Int, type: String): Boolean {
        val probe = ActivityEntity(dateIso = date, km = km, durationSec = durationSec, startTime = startTime, type = type)
        return sameActivity(existing, probe) && abs(existing.km - km) < KM_TOL
    }

    /**
     * Cukup yakin untuk digabung otomatis tanpa konfirmasi: kedua jam mulai ada dan ≤ 1 menit, jarak dan durasi hampir identik,
     * dan paling banyak satu catatan yang membawa berkas detail (supaya detail jam/rute tidak ada yang terbuang).
     */
    fun highConfidence(a: ActivityEntity, b: ActivityEntity): Boolean {
        if (!sameActivity(a, b)) return false
        val ma = minuteOfDay(a.startTime); val mb = minuteOfDay(b.startTime)
        if (ma == null || mb == null) return false
        if (a.detailFile != null && b.detailFile != null) return false
        return abs(a.km - b.km) < 0.1 && abs(a.durationSec - b.durationSec) < 120
    }

    /** Semua pasangan kandidat (pemilik detail lebih dulu, lalu id terkecil); tidak lagi mensyaratkan salah satu punya detail. */
    fun findPairs(rows: List<ActivityEntity>): List<Pair<ActivityEntity, ActivityEntity>> {
        val pairs = mutableListOf<Pair<ActivityEntity, ActivityEntity>>()
        rows.groupBy { it.dateIso to it.type }.values.forEach { group ->
            val sorted = group.sortedWith(compareByDescending<ActivityEntity> { it.detailFile != null }.thenBy { it.id })
            for (i in sorted.indices) for (j in i + 1 until sorted.size) {
                if (sameActivity(sorted[i], sorted[j])) pairs += sorted[i] to sorted[j]
            }
        }
        return pairs
    }
}
