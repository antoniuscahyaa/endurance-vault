package com.endurancevault.app.domain

/** Peran satu segmen pada grafik pace kartu harian. */
enum class SegRole { REP, STRIDE, PROGRESSIVE, WARMUP, COOLDOWN, REST, CUSTOM, OTHER }

/** Satu segmen untuk grafik: [km] panjangnya, [pace] menit/km, [label] teks untuk legenda. */
class ShareSeg(val startKm: Double, val km: Double, val pace: Double, val role: SegRole, val label: String)

/**
 * Menyusun segmen untuk grafik pace harian. Murni, tanpa Android.
 * - Segmen berjenis/berlabel (Repetisi, Stride, Progresif, label sendiri) dipakai apa adanya.
 * - Segmen tanpa label: bila [laps] (hasil deteksi lap cepat-lambat dari [IntervalAnalysis]) diberikan, lap di dalam
 *   repetisi menjadi Repetisi, di antaranya Istirahat, sebelum repetisi pertama Pemanasan, sesudah yang terakhir Pendinginan.
 * - Kurang dari dua segmen valid: hasil kosong, dan kartu memakai grafik pace per km.
 * [IvRep.from] dan [IvRep.to] adalah indeks pada daftar [sg] asli.
 */
object ShareSegments {
    fun build(sg: List<Segment>, laps: List<IvRep>?): List<ShareSeg> {
        if (sg.size < 2) return emptyList()
        val first = laps?.minOfOrNull { it.from }
        val last = laps?.maxOfOrNull { it.to }
        val out = ArrayList<ShareSeg>()
        sg.forEachIndexed { i, s ->
            if (!(s.d > 0.0 && s.pace > 0.0)) return@forEachIndexed
            val kind = SegKind.normalize(s.type)
            val custom = SegKind.clean(s.label)
            var role = when {
                kind == SegKind.REPETITION -> SegRole.REP
                kind == SegKind.STRIDE -> SegRole.STRIDE
                kind == SegKind.PROGRESSIVE -> SegRole.PROGRESSIVE
                custom != null -> SegRole.CUSTOM
                else -> SegRole.OTHER
            }
            if (role == SegRole.OTHER && laps != null && first != null && last != null) {
                role = when {
                    laps.any { i >= it.from && i <= it.to } -> SegRole.REP
                    i < first -> SegRole.WARMUP
                    i > last -> SegRole.COOLDOWN
                    else -> SegRole.REST
                }
            }
            val label = SegKind.displayLabel(s.label, s.type) ?: defaultLabel(role)
            out.add(ShareSeg((s.k - s.d).coerceAtLeast(0.0), s.d, s.pace, role, label))
        }
        return if (out.size >= 2) out else emptyList()
    }

    fun defaultLabel(r: SegRole): String = when (r) {
        SegRole.REP -> "Repetisi"
        SegRole.WARMUP -> "Pemanasan"
        SegRole.COOLDOWN -> "Pendinginan"
        SegRole.REST -> "Istirahat"
        SegRole.STRIDE -> "Stride"
        SegRole.PROGRESSIVE -> "Progresif"
        else -> "Segmen"
    }
}
