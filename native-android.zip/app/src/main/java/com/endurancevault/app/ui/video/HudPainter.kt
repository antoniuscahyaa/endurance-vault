package com.endurancevault.app.ui.video

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import com.endurancevault.app.domain.HudPrefs
import com.endurancevault.app.domain.HudValues
import com.endurancevault.app.domain.VideoHud
import com.endurancevault.app.ui.sticker.StickerFonts
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Menggambar HUD data lari di atas bingkai video. Satu [HudPainter] per ukuran bingkai; [draw] dipanggil tiap bingkai ke
 * bitmap transparan lalu bitmap itu ditempel di atas video. Dua gaya: "two" (kolom kiri dengan HR, jarak, pace, waktu, elevasi,
 * kemiringan; kolom kanan dengan minimap rute dan gauge kecepatan) dan "min" (pace besar dengan satu baris angka).
 */
class HudPainter(
    private val w: Int, private val h: Int, private val prefs: HudPrefs, private val mini: VideoHud.MiniMap, private val fonts: StickerFonts,
) {
    private val k = min(w, h) / 720f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private val accent = runCatching { Color.parseColor(prefs.accent) }.getOrDefault(0xFFFF6A13.toInt())
    private val ink = Color.WHITE
    private val dim = 0xB3FFFFFF.toInt()

    private fun face(display: Boolean): Typeface = if (display) fonts.num ?: Typeface.create("sans-serif-condensed", Typeface.BOLD)
    else fonts.body ?: Typeface.create("sans-serif-medium", Typeface.BOLD)

    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, align: Paint.Align = Paint.Align.LEFT, display: Boolean = false, ls: Float = 0f): Float {
        paint.reset(); paint.isAntiAlias = true
        paint.typeface = face(display); paint.textSize = size; paint.letterSpacing = ls
        paint.color = color; paint.textAlign = align
        paint.setShadowLayer(size * 0.22f, 0f, size * 0.07f, Color.argb(170, 0, 0, 0))
        c.drawText(s, x, y, paint)
        val wd = paint.measureText(s)
        paint.clearShadowLayer()
        return wd
    }

    private fun measure(s: String, size: Float, display: Boolean, ls: Float = 0f): Float {
        paint.reset(); paint.isAntiAlias = true
        paint.typeface = face(display); paint.textSize = size; paint.letterSpacing = ls
        return paint.measureText(s)
    }

    /** Gambar HUD untuk nilai [v] ke [c] (ukuran [w] x [h]); [c] harus sudah dibersihkan. */
    fun draw(c: Canvas, v: HudValues) {
        val dimA = (prefs.dim * 2.55f).roundToInt()
        if (dimA > 0) {
            // Peredam gelap atas dan bawah supaya angka terbaca di atas pemandangan apa pun
            val bh = h * 0.32f
            paint.reset()
            paint.shader = LinearGradient(0f, h - bh, 0f, h.toFloat(), Color.TRANSPARENT, Color.argb(dimA, 0, 0, 0), Shader.TileMode.CLAMP)
            c.drawRect(0f, h - bh, w.toFloat(), h.toFloat(), paint)
            paint.shader = LinearGradient(0f, 0f, 0f, bh * 0.6f, Color.argb(dimA / 2, 0, 0, 0), Color.TRANSPARENT, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w.toFloat(), bh * 0.6f, paint)
            paint.shader = null
        }
        if (prefs.style == "min") drawMin(c, v) else drawTwo(c, v)
    }

    private fun drawTwo(c: Canvas, v: HudValues) {
        val margin = 36f * k
        val land = w > h
        val rows = listOf(
            Triple("DETAK JANTUNG", v.hr, "BPM"), Triple("JARAK", v.km, "KM"), Triple("PACE", v.pace, "/KM"),
            Triple("WAKTU", v.time, ""), Triple("ELEVASI", v.ele, "M"), Triple("KEMIRINGAN", v.slope, "%"),
        )
        val bigSize = (if (land) 40f else 46f) * k
        val rowH = bigSize * 1.9f
        val total = rowH * 3
        val y0 = h - margin - total
        // Dua kolom data di kiri: tiga baris kali dua
        val colW = (if (land) 230f else 270f) * k
        for (i in rows.indices) {
            val col = i / 3; val row = i % 3
            val x = margin + col * colW; val y = y0 + row * rowH
            text(c, rows[i].first, x, y + bigSize * 0.55f, 13f * k, dim, ls = 0.1f)
            val vw = text(c, rows[i].second, x, y + bigSize * 1.45f, bigSize, ink, display = true)
            if (rows[i].third.isNotEmpty()) text(c, rows[i].third, x + vw + 6f * k, y + bigSize * 1.45f, 15f * k, accent, ls = 0.08f)
        }
        // Kolom kanan: minimap dan gauge kecepatan
        var rx = w - margin
        val side = (if (land) 190f else 220f) * k
        if (prefs.minimap) {
            drawMini(c, rx - side, h - margin - side, side, v)
            rx -= side + 16f * k
        }
        if (prefs.gauge) {
            val gs = side * 0.82f
            drawGauge(c, rx - gs, h - margin - gs, gs, v)
        }
    }

    private fun drawMin(c: Canvas, v: HudValues) {
        val margin = 40f * k
        val big = (if (w > h) 110f else 132f) * k
        val y = h - margin - 64f * k
        val pw = text(c, v.pace, margin, y, big, ink, display = true)
        text(c, "/KM", margin + pw + 10f * k, y, 22f * k, accent, ls = 0.08f)
        val labels = listOf("HR" to v.hr, "KM" to v.km, "WAKTU" to v.time, "ELEV" to v.ele)
        var x = margin
        for ((l, value) in labels) {
            text(c, l, x, y + 30f * k, 13f * k, dim, ls = 0.1f)
            val vw = text(c, value, x, y + 62f * k, 30f * k, ink, display = true)
            x += max(vw, measure(l, 13f * k, false, 0.1f)) + 30f * k
        }
        if (prefs.minimap) drawMini(c, w - margin - 150f * k, h - margin - 150f * k, 150f * k, v)
    }

    private fun drawMini(c: Canvas, x: Float, y: Float, side: Float, v: HudValues) {
        rect.set(x, y, x + side, y + side)
        paint.reset(); paint.isAntiAlias = true
        paint.color = Color.argb(110, 0, 0, 0); c.drawRoundRect(rect, 18f * k, 18f * k, paint)
        val pad = 16f * k
        val inner = side - 2 * pad
        val ox = x + pad + (inner - mini.w * inner) / 2; val oy = y + pad + (inner - mini.h * inner) / 2
        val n = mini.x.size
        fun px(i: Int) = ox + mini.x[i] * inner
        fun py(i: Int) = oy + mini.y[i] * inner
        val (idx, t) = VideoHud.miniPos(mini, v.frac)
        // Jejak penuh redup
        path.reset(); path.moveTo(px(0), py(0))
        for (i in 1 until n) path.lineTo(px(i), py(i))
        paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.STROKE; paint.strokeWidth = 3.2f * k
        paint.strokeJoin = Paint.Join.ROUND; paint.strokeCap = Paint.Cap.ROUND
        paint.color = Color.argb(110, 255, 255, 255); c.drawPath(path, paint)
        // Bagian tertempuh
        val cx = px(idx) + (px(min(idx + 1, n - 1)) - px(idx)) * t
        val cy = py(idx) + (py(min(idx + 1, n - 1)) - py(idx)) * t
        path.reset(); path.moveTo(px(0), py(0))
        for (i in 1..idx) path.lineTo(px(i), py(i))
        path.lineTo(cx, cy)
        paint.color = accent; paint.strokeWidth = 4.4f * k; c.drawPath(path, paint)
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(90, Color.red(accent), Color.green(accent), Color.blue(accent)); c.drawCircle(cx, cy, 11f * k, paint)
        paint.color = Color.WHITE; c.drawCircle(cx, cy, 6.2f * k, paint)
        paint.color = accent; c.drawCircle(cx, cy, 3.6f * k, paint)
    }

    private fun drawGauge(c: Canvas, x: Float, y: Float, size: Float, v: HudValues) {
        val cx = x + size / 2; val cy = y + size / 2; val r = size / 2 - 10f * k
        rect.set(cx - r, cy - r, cx + r, cy + r)
        val start = 135f; val sweep = 270f
        paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.STROKE; paint.strokeWidth = 11f * k; paint.strokeCap = Paint.Cap.ROUND
        paint.color = Color.argb(70, 255, 255, 255)
        c.drawArc(rect, start, sweep, false, paint)
        if (v.speedFrac > 0.005f) {
            paint.color = accent
            c.drawArc(rect, start, sweep * v.speedFrac, false, paint)
        }
        text(c, v.speed, cx, cy + 12f * k, size * 0.26f, ink, Paint.Align.CENTER, display = true)
        text(c, "KM/J", cx, cy + size * 0.26f, 12f * k, dim, Paint.Align.CENTER, ls = 0.1f)
    }
}
