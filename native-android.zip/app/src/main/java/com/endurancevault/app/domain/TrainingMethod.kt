package com.endurancevault.app.domain

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Metode latihan (padanan 02b-metode-latihan.js): 'default', 'pyramidal', 'polarized', 'maf'.
 *
 * Metode lain tidak membuat rencana baru; ia menyesuaikan sesi yang sudah dibuat plan() per hari, memakai zona HR
 * (LTHR atau HRR), pita threshold, HR maks, pace lomba, dan batas HR easy. Km per hari tidak diubah oleh metode.
 * Hook di plan(): [methodQuality] (sebelum qualBalance) dan [methodEasy] (setelah penghalusan tanjakan).
 * Teks Indonesia saja; terjemahan masuk tahap 10.
 */

object TrainingMethod {
    val KEYS = listOf("default", "pyramidal", "polarized", "maf")

    /** Target persen waktu Z1-2 / Z3 / Z4-5 untuk kartu distribusi intensitas. */
    class PctTarget(val lo: IntArray, val mid: IntArray, val hi: IntArray)
    val TARGET = mapOf(
        "pyramidal" to PctTarget(intArrayOf(65, 80), intArrayOf(12, 28), intArrayOf(4, 15)),
        "polarized" to PctTarget(intArrayOf(75, 92), intArrayOf(0, 10), intArrayOf(8, 22)),
        "maf" to PctTarget(intArrayOf(88, 100), intArrayOf(0, 8), intArrayOf(0, 6)),
    )

    fun of(s: PlanSettings): String = if (s.method in KEYS) s.method else "default"

    fun name(m: String): String = when (m) {
        "default" -> "Bawaan"
        "pyramidal" -> "Pyramidal"
        "polarized" -> "Polarized"
        "maf" -> "Base ringan (MAF)"
        else -> m
    }

    fun info(m0: String): String {
        val m = if (m0 in KEYS) m0 else "default"
        return when (m) {
            "pyramidal" -> "Pyramidal: banyak easy, sebagian di zona 3 (steady), sedikit keras. Di fase Bangun dan Puncak, easy sedang dan long run jalan ditutup 15–25 menit di zona 3, dan interval VO2max diganti tempo. Tidak ada sesi VO2max. Target waktu sekitar 65–80% Z1–2, 12–28% Z3, 4–15% Z4–5."
            "polarized" -> "Polarized: easy dan keras, tanpa zona sedang. Di fase Bangun dan Puncak, sesi threshold dan tempo diganti interval keras (zona 4–5) yang lebih pendek; easy dan long run tetap di batas HR easy. Sesi pace lomba dan mendaki panjang tidak berubah. Beban keras lebih tinggi, jadi hati-hati bila lutut atau pergelangan kaki sedang pulih."
            "maf" -> "Base ringan (MAF): di fase Fondasi tanpa sesi keras. Sesi kualitas diganti strides dan tanjakan pendek, semua lari lain easy di batas HR easy. Fase Bangun dan seterusnya sama dengan Bawaan. Cocok saat membangun ulang fondasi setelah cedera."
            else -> "Bawaan: periodisasi Fondasi, Bangun, Puncak, Taper. Satu sesi kualitas per pekan (threshold, tempo, atau sesuai jenis lomba), sisanya easy dengan batas HR. Tidak ada yang berubah dari sebelumnya."
        }
    }

    /** Batas HR zona 3 dari zona yang dipakai app (LTHR atau HRR). */
    private fun z3(s: PlanSettings): List<Int> { val lo = Zones.cuts(s).lo; return listOf(lo[2], lo[3] - 1) }

    private fun q2(d: PDay, title: String, detail: String) {
        val n = d.q2
        if (n != null) { d.title = "Sesi kedua · $title"; d.detail = detail + Q2_NOTE[n] }
        else { d.title = title; d.detail = detail }
    }

    /** Strides dan tanjakan pendek: teks sama dengan sesi base ganjil bawaan, supaya ekspor ke jam membacanya sebagai strides. */
    private fun strides(d: PDay, s: PlanSettings) {
        d.title = "Strides dan tanjakan pendek"; d.qk = "none"; d.qMin = 0.0; d.qBand = null; d.est = null
        d.detail = "Easy, lalu tanjakan pendek 6×10 dtk sprint (jalan turun), kemudian strides 6×20 dtk. Sisanya easy, HR ≤ ${s.hr}."
        d.tm = "maf"
    }

    /** Interval VO2max (bawaan pyramidal tidak mau) menjadi tempo. */
    private fun tempo(d: PDay, b: List<Int>, rp: RacePaces?) {
        val q0 = d.qMin?.takeIf { it != 0.0 } ?: 15.0
        val m = min(40, max(20, 5 * Js.roundI(1.4 * q0 / 5))); val lo = b[0] - 4; val hi = b[1] - 2
        d.qk = "thr"; d.qMin = m.toDouble(); d.qBand = listOf(lo, hi); d.est = null
        q2(d, "Tempo", "Tempo $m mnt tanpa henti di HR $lo–$hi (sedikit di bawah threshold)." +
            (if (rp != null) " Pace sekitar ${Js.paceStr((rp.thr + rp.phm) / 2)}/km." else "") +
            " Pemanasan 15 mnt easy, pendinginan 10 mnt easy.")
        d.tm = "pyr"
    }

    private val HARD = listOf(5 to 3, 6 to 3, 5 to 4, 6 to 4, 4 to 5, 5 to 5)

    /** Threshold/tempo menjadi interval keras. Menit keras kira-kira setengah menit threshold semula. */
    private fun hard(d: PDay, mx: Int, rp: RacePaces?, trail: Boolean) {
        val q0 = d.qMin?.takeIf { it != 0.0 } ?: 24.0
        val h = max(12, Js.roundI(q0 * 0.5))
        var best = HARD[0]
        for (i in 1 until HARD.size) {
            if (abs(HARD[i].first * HARD[i].second - h) < abs(best.first * best.second - h)) best = HARD[i]
        }
        d.qk = "vo2"; d.qMin = (best.first * best.second).toDouble(); d.qBand = listOf(Js.roundI(.9 * mx), 999); d.est = null
        q2(d, if (trail) "Interval keras" else "Interval VO2max",
            "Interval keras ${best.first}×${best.second} mnt (zona 4–5), jog 2 mnt antar set. Usaha 8–9 dari 10; HR baru naik di repetisi ke-2 dan seterusnya, itu normal." +
                (if (rp != null) " Pace sekitar ${Js.paceStr(rp.p5)}/km (usaha 3K–5K)." else "") +
                (if (trail) " Di medan bergelombang pegang usaha dan napas, bukan pace." else "") +
                " Pemanasan 15 mnt easy, pendinginan 10 mnt easy.")
        d.tm = "pol"
    }

    /** Hook 1: sesi kualitas (sebelum qualBalance, agar estimasi km memakai isi sesi baru). */
    internal fun methodQuality(days: List<PDay>, s: PlanSettings, rc: RC, phase: String, cut: Boolean) {
        val m = of(s)
        if (m == "default" || cut || phase == Phases.TAPER) return
        if (m == "maf") {
            if (phase != Phases.BASE) return
            days.forEach { if (it.role == "quality" && !it.bench && it.altMins == null) strides(it, s) }
            return
        }
        if (phase != Phases.BUILD && phase != Phases.PEAK) return
        val b = thrBand(s) ?: listOf(164, 172); val mx = hrMaxEst(s); val rp = racePaces(s)
        days.forEach { d ->
            if (d.role != "quality" || d.bench || d.altMins != null) return@forEach
            if (m == "pyramidal" && d.qk == "vo2") tempo(d, b, rp)
            else if (m == "polarized" && d.qk == "thr") hard(d, mx, rp, rc.trail)
        }
    }

    /** Hook 2: easy sedang dan long run jalan ditutup di zona 3 (pyramidal). Dipanggil setelah teks hari final. */
    internal fun methodEasy(days: List<PDay>, s: PlanSettings, rc: RC, phase: String, cut: Boolean, easyPace: Double? = null) {
        if (of(s) != "pyramidal" || cut || (phase != Phases.BUILD && phase != Phases.PEAK)) return
        val z = z3(s)
        val ep = easyPace?.takeIf { it > 0 } ?: Js.parsePaceStr(s.pace)
        val steady = if (phase == Phases.BUILD) 15 else 20
        days.forEach { d ->
            if (d.mod != null || d.bench || d.altMins != null || d.b2b != null || d.glock || d.sim ||
                d.kind == Kinds.RACE || d.kind == Kinds.EVENT || !(d.km > 0)) return@forEach
            val gain = d.gain ?: 0
            val mins = d.km * ep + gain / 100.0 * 3
            fun tail(n: Int) = " Di $n mnt terakhir naik ke zona 3 (HR ${z[0]}–${z[1]}): usaha nyaman-keras, masih bisa bicara pendek. Sisanya easy, HR ≤ ${s.hr}." + (if (gain > 0) " Di tanjakan pegang napas dan usaha, HR tertinggal 15–30 detik." else "")
            if (d.role == "medium" && d.title.startsWith("Easy")) {
                if (mins < steady + 25) return@forEach
                d.mod = DayMod(steady, z, 3); d.title += " + steady"; d.detail += tail(steady); d.tm = "pyr"
            } else if (d.role == "long" && !rc.trail) {
                val st = min(25, steady + 5)
                if (mins < st + 50) return@forEach
                d.mod = DayMod(st, z, 3); d.title += " + steady"; d.detail += tail(st); d.tm = "pyr"
            }
        }
    }

    class Advice(val kind: String, val text: String)

    /**
     * Saran distribusi intensitas menurut metode terpilih.
     * @param secs detik per zona Z1 sampai Z5; null untuk metode bawaan (saran 80/20 lama).
     */
    fun advice(secs: DoubleArray, hrEasy: Int, s: PlanSettings): Advice? {
        val m = of(s); val tg = TARGET[m] ?: return null
        val t = secs.sum()
        val lo = (secs[0] + secs[1]) / t * 100; val mid = secs[2] / t * 100; val hi = (secs[3] + secs[4]) / t * 100
        fun r(x: Double) = Js.roundI(x)
        val nm = name(m)
        val now = "Z1–2 ${r(lo)}%, Z3 ${r(mid)}%, Z4–5 ${r(hi)}%"
        val tgt = "target $nm: Z1–2 ${tg.lo[0]}–${tg.lo[1]}%, Z3 ${tg.mid[0]}–${tg.mid[1]}%, Z4–5 ${tg.hi[0]}–${tg.hi[1]}%"
        if (lo < tg.lo[0]) return Advice("hard", "Terlalu banyak intensitas untuk metode $nm ($now; $tgt). Perbanyak lari ringan.")
        if (mid > tg.mid[1]) return Advice("gray", "Zona 3 menyita ${r(mid)}% waktu, di atas batas metode $nm ($now; $tgt). Biasanya easy run terlalu cepat; tahan HR easy di bawah ${hrEasy + 1} bpm.")
        if (hi > tg.hi[1]) return Advice("hard", "Z4–5 ${r(hi)}% melebihi batas metode $nm ($now; $tgt). Kurangi sesi keras atau pendekkan.")
        if (m == "pyramidal" && mid < tg.mid[0]) return Advice("easy", "Z3 baru ${r(mid)}% ($now; $tgt). Isi blok steady di easy sedang dan long run sesuai rencana.")
        if (m == "polarized" && hi < tg.hi[0]) return Advice("easy", "Z4–5 baru ${r(hi)}% ($now; $tgt). Wajar di fase Fondasi; di Bangun dan Puncak sesi interval keras ikut menaikkannya.")
        return Advice("ok", "Sesuai target metode $nm ($now; $tgt). Pertahankan.")
    }
}
