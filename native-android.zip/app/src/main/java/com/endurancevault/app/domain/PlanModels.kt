package com.endurancevault.app.domain

import java.time.LocalDate

/** Padanan objek pengaturan `S` di versi web (hanya bagian yang dipakai perencana). */
data class PbPost(val rec: Double, val lvl: Double)
data class PbConv(val wk: Int, val b0: Double, val p0: Double)
data class PbAk(val wk: LocalDate, val km: Double)

data class EasyRunConfig(
    val warm: Int = 2, val easyTolerance: Int = 4, val easyBand: Int = 6,
    val easyPass: Int = 95, val easyOk: Int = 85,
    val longTolerance: Int = 8, val longBand: Int = 8,
    val longPass: Int = 85, val longOk: Int = 80,
    val strideCount: Int = 2, val stridePercent: Int = 30,
    val strideMinSec: Int = 10, val strideMaxSec: Int = 50,
    val heatEnabled: Boolean = false, val heatThreshold: Int = 26, val heatCut: Int = 2,
    val sleepEnabled: Boolean = false,
)

data class PlanSettings(
    val name: String = "",
    val rtype: String = "none",          // 5k,10k,hm,fm,none,pb,ultra,ultrar
    val start: LocalDate = LocalDate.now(),
    val race: LocalDate? = null,
    val raceKm: Double? = null,          // hanya untuk trail/ultra
    val raceGain: Double? = null,
    val goalT: String = "",              // h:mm:ss atau mm:ss
    val base: Double = 40.0,
    val peak: Double = 65.0,
    val days: Int = 5,                   // 5 atau 6 hari lari
    val rest: Int = 0,                   // hari libur utama (0=Senin..6=Minggu)
    val rest2: Int = 4,                  // libur kedua (hanya bila 5 hari)
    val longDay: Int = 6,                // hari long run (0=Senin..6=Minggu)
    val hr: Int = 150,
    val thr: String = "164–172",
    val pace: String = "6:30",
    val hrMax: Int? = null,
    val bspd: Double = 20.0,             // kecepatan sepeda km/jam (minggu 6 hari)
    val pbCycle: String = "3",
    val pbFocus: String = "mix",         // mix, thr, vo2, vol
    val pbPost: PbPost? = null,
    val pbConv: PbConv? = null,
    val pbAk: PbAk? = null,
    val evOn: Boolean = false,
    val evDate: LocalDate? = null,
    val evKm: Double = 0.0,
    val evGain: Double = 0.0,
    // zona HR
    val zm: String = "lthr",             // lthr | hrr
    val lthr: Double? = null,
    val rhr: Double? = null,
    val zl: List<Double> = listOf(85.0, 90.0, 95.0, 100.0),
    val zr: List<Double> = listOf(50.0, 60.0, 70.0, 80.0, 90.0),
    // tahap 1b: metode latihan, sesi quality kedua, strength
    val method: String = "default",      // default | pyramidal | polarized | maf
    val qSess: String = "1",             // "1" atau "2" sesi quality per pekan (2 hanya 5K/10K/HM/FM/PB, 6 hari)
    val sLeg: Boolean = true,            // strength kaki (A dan B)
    val sAnk: Boolean = true,            // strength ankle
    val sUp: String = "auto",            // upper body: auto | off | 1 | 2
    // penghalus D+ mingguan (trail): gSmooth=false mematikan, gBase = D+ awal rantai (0 = otomatis)
    val gSmooth: Boolean = true,
    val gBase: Double = 0.0,
    val easyRun: EasyRunConfig = EasyRunConfig(),
    /** Penyesuaian beban pekan aktif dari tab Profil. */
    val weekScale: Double = 1.0,
    val weekScaleWeek: LocalDate? = null,
    /** Skala load CTL/ATL buatan pengguna (tab Load); null = bawaan. */
    val loadScale: Double? = null,
    val sickUntil: LocalDate? = null,
    val autoAdjust: Boolean = true,
    /** Threshold asli pengguna; terisi hanya pada salinan planRaw (padanan thrSrc di web). Tidak disimpan. */
    val thrSrc: String? = null,
    /** HR maks tertinggi dari log aktivitas (padanan log[k].hrMax di hrMaxEst web). Diisi saat kalkulasi, tidak disimpan. */
    val logHrMax: Int = 0,
)

object Kinds {
    const val REST = "rest"; const val EASY = "easy"; const val QUALITY = "quality"
    const val MEDIUM = "medium"; const val LONG = "long"; const val RACE = "race"; const val EVENT = "event"
}

object Phases { const val BASE = "base"; const val BUILD = "build"; const val PEAK = "peak"; const val TAPER = "taper" }

/** Blok latihan penunjang (strength kaki, ankle, upper) yang menempel pada satu hari. */
class StrengthBlock(val title: String, val mins: Int, val note: String, val lines: List<String>) {
    /** Penanda geser/terlewat (padanan `adj` pada blok strength di web). */
    var adj: DayAdj? = null
    fun withAdj(a: DayAdj?): StrengthBlock = StrengthBlock(title, mins, note, lines).also { it.adj = a }
}

/** Bagian steady di zona 3 (metode pyramidal): menit, rentang HR, nomor zona. */
class DayMod(val min: Int, val band: List<Int>, val z: Int)

class QEst(val min: Int, val km: Int, val old: Double, val ep: Double, val wp: Double)

/** Satu hari rencana. Field opsional sama dengan properti hari di versi web. */
class PDay(
    var date: LocalDate, var d: Int, var kind: String, var grp: String,
    var title: String, var km: Double, var detail: String,
) {
    var role: String? = null
    var bikeReplacement: BikePlan? = null
    var replacedRunTitle: String? = null
    var replacedRunKind: String? = null
    var replacedRunKm: Double? = null
    var replacedRunDetail: String? = null
    var gain: Int? = null
    var b2b: Int? = null
    var qk: String? = null
    var qMin: Double? = null
    var qBand: List<Int>? = null
    var sim: Boolean = false
    var bench: Boolean = false
    var xtra: Int? = null
    var altMins: Int? = null
    var altKm: Double? = null
    var est: QEst? = null
    var q2: Int? = null                 // tahap sesi quality kedua (1..3)
    var mod: DayMod? = null
    var tm: String? = null              // penanda metode: pyr | pol | maf
    var str: StrengthBlock? = null
    var ank: StrengthBlock? = null
    var up: StrengthBlock? = null
    /** Penyesuaian jadwal (tukar hari, libur dadakan, geser, lewati); diisi SessionAdjust, padanan `d.adj` di web. */
    var adj: DayAdj? = null
    var mvUndo: Boolean = false          // true: ada tombol Batalkan
    var mvSw: String? = null             // kunci mv "sw:tanggal" bila hasil tukar hari
    var mvKm: Double? = null             // km semula sebelum dicabut (libur dadakan / lewati / digeser)
    var mvGain: Int? = null
    var swList: List<DayOption> = emptyList()   // tujuan tukar hari (14 hari ke depan, minggu sama)
    var spOpt: Boolean = false           // tombol Libur dadakan tersedia
    var mvOpt: DayOption? = null         // saran geser sesi terlewat ke hari easy
    var mvOptR: DayOption? = null        // saran tukar dengan hari libur
    var mvList: List<DayOption> = emptyList()   // semua tujuan geser untuk sesi terlewat
    internal var week: PWeek? = null                    // minggu pemilik hari ini (diisi SessionAdjust)
    internal var mk: ((Int) -> Unit)? = null
    internal var glock: Boolean = false
    internal var bd: String? = null                     // detail dasar sebelum D+ ditulis ulang
}

class PWeek(
    var i: Int, val start: LocalDate, val end: LocalDate, val phase: String, val cut: Boolean,
    val rec: Boolean, val race: Boolean, val days: MutableList<PDay>, var km: Double,
) {
    var missed: Int = 0
    var adj80: Boolean = false
}

/** Penanda penyesuaian pada satu hari. type: sw | in | out | miss | skip | spread. */
class DayAdj(val type: String, val text: String)

/** Satu hari tujuan pada pilihan tukar/geser. warn: menukar melahirkan dua sesi berat berurutan. */
class DayOption(val date: LocalDate, val label: String, val what: String, val warn: Boolean = false)

sealed interface PlanOutcome {
    class Ok(
        val weeks: List<PWeek>, val start: LocalDate, val race: LocalDate, val n: Int,
        val noRace: Boolean, val none: Boolean, val build: Boolean, val pbCycle: Int, val convWk: Int,
    ) : PlanOutcome
    class Err(val message: String) : PlanOutcome
}
