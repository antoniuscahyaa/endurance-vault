package com.endurancevault.app.ui.video

import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.view.Surface
import com.endurancevault.app.data.TerrainScene
import com.endurancevault.app.domain.RouteVideoFormat
import com.endurancevault.app.domain.TrailData
import com.endurancevault.app.domain.TrailKeys
import com.endurancevault.app.domain.TrailLayout
import com.endurancevault.app.domain.TrailPrefs
import com.endurancevault.app.domain.TrailTimeline
import com.endurancevault.app.ui.sticker.StickerFonts
import java.io.File
import java.util.concurrent.CancellationException
import java.util.concurrent.Executors
import kotlinx.coroutines.asCoroutineDispatcher

/** Semua yang dibutuhkan untuk menggambar satu bingkai Trail pada ukuran [w] x [h]; dibuat dan dipakai di thread GL. */
class TrailRig(
    val w: Int, val h: Int, val prefs: TrailPrefs, val data: TrailData, scene: TerrainScene,
    fonts: StickerFonts, photo: Bitmap?, title: String, dateText: String,
) {
    private val lay = TrailLayout.compute(w, h, prefs)
    private val pal = TrailPalette.of(prefs.palette, prefs.accent)
    private val ts = TrailScene(scene, TrailKeys.sides(prefs.shape), prefs.relief, prefs.coverage, prefs.offX, prefs.offZ, prefs.flatEdge, prefs.blockCut)
    private val gl = TrailGl(w, h)
    private val painter: TrailPainter

    init {
        gl.init()
        // Kamera dihitung sekali untuk seluruh rentang putaran (termasuk putaran tambahan gerak spiral) supaya zoom tidak bergoyang.
        val azs = if (prefs.spin == 0 && prefs.camMove != "spiral") doubleArrayOf(prefs.rotation.toDouble())
        else DoubleArray(13) { TrailTimeline.at(TrailTimeline.total(prefs) * it / 12.0, prefs).azimuth }
        gl.prepare(ts, lay, prefs.tilt, pal, azs)
        painter = TrailPainter(w, h, prefs, data, ts, gl, lay, pal, fonts, photo, title, dateText)
        gl.setStatic(painter.staticLayer())
    }

    /** Gambar bingkai pada detik video [t] ke konteks yang sedang aktif. */
    fun draw(t: Double) {
        val pt = TrailTimeline.at(t, prefs)
        // Kamera diatur dulu: penanda di lapisan atas diproyeksikan dengan kamera yang sama dengan slab.
        gl.setCamera(pt.cam, pt.frac.toFloat())
        val chart = painter.chartLayer(pt.frac, pt.panelIn.toFloat())
        val over = painter.overLayer(pt)
        gl.frame(pt.azimuth, pt.frac.toFloat(), chart, painter.chartBox, over)
    }

    fun read(): Bitmap = gl.readFrame()

    fun release() {
        runCatching { painter.release() }
        runCatching { gl.release() }
    }
}

/** Render video Trail 3D ke MP4 (H.264, 30 fps) dan foto bingkai. Berjalan blocking di thread pemanggil, yang juga thread GL-nya. */
object TrailEncoder {
    fun encode(
        scene: TerrainScene, data: TrailData, prefs: TrailPrefs, fonts: StickerFonts, photo: Bitmap?,
        title: String, dateText: String, out: File, isActive: () -> Boolean, onProgress: (Float) -> Unit,
    ): Result<Unit> {
        out.parentFile?.mkdirs(); out.delete()
        val (W, H) = RouteVideoFormat.size(prefs.aspect, prefs.quality)
        var codec: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var egl: EglCore? = null
        var rig: TrailRig? = null
        var inputSurface: Surface? = null
        var muxerStarted = false
        var trackIndex = -1
        var ok = false
        try {
            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, W, H).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, (W.toLong() * H * 7).coerceAtMost(40_000_000L).toInt())
                setInteger(MediaFormat.KEY_FRAME_RATE, TrailTimeline.FPS)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }
            val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            codec = enc
            enc.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = enc.createInputSurface()
            enc.start()
            val mux = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = mux

            val eg = EglCore(inputSurface, W, H)
            egl = eg
            eg.makeCurrent()
            val r = TrailRig(W, H, prefs, data, scene, fonts, photo, title, dateText)
            rig = r

            val info = MediaCodec.BufferInfo()
            fun drain(endOfStream: Boolean) {
                while (true) {
                    val i = enc.dequeueOutputBuffer(info, if (endOfStream) 10_000 else 0)
                    when {
                        i == MediaCodec.INFO_TRY_AGAIN_LATER -> { if (!endOfStream) return }
                        i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            check(!muxerStarted) { "Format keluaran berubah dua kali." }
                            trackIndex = mux.addTrack(enc.outputFormat); mux.start(); muxerStarted = true
                        }
                        i >= 0 -> {
                            val buf = enc.getOutputBuffer(i)
                            if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                            if (info.size > 0 && buf != null && muxerStarted) {
                                buf.position(info.offset); buf.limit(info.offset + info.size)
                                mux.writeSampleData(trackIndex, buf, info)
                            }
                            enc.releaseOutputBuffer(i, false)
                            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                        }
                    }
                }
            }

            val frames = TrailTimeline.frames(prefs)
            for (f in 0 until frames) {
                if (!isActive()) throw CancellationException("Render dibatalkan.")
                r.draw(f.toDouble() / TrailTimeline.FPS)
                eg.setPresentationTime(f * 1_000_000_000L / TrailTimeline.FPS)
                check(eg.swap()) { "Gagal menukar buffer EGL." }
                drain(false)
                onProgress((f + 1f) / frames)
            }
            enc.signalEndOfInputStream()
            drain(true)
            check(muxerStarted) { "Encoder tidak menghasilkan data." }
            ok = true
        } catch (e: Throwable) {
            if (e is OutOfMemoryError) return Result.failure(IllegalStateException("Memori tidak cukup untuk membuat video. Coba kualitas 720p."))
            return Result.failure(e)
        } finally {
            runCatching { rig?.release() }
            runCatching { egl?.release() }
            runCatching { inputSurface?.release() }
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { if (muxerStarted) muxer?.stop() }
            runCatching { muxer?.release() }
            if (!ok) out.delete()
        }
        return Result.success(Unit)
    }

    /** Satu bingkai penuh (ukuran sama dengan video) pada posisi [pos] (0..1) linimasa; memakai pbuffer sendiri. */
    fun renderStill(
        scene: TerrainScene, data: TrailData, prefs: TrailPrefs, fonts: StickerFonts, photo: Bitmap?,
        title: String, dateText: String, pos: Double,
    ): Result<Bitmap> {
        val (W, H) = RouteVideoFormat.size(prefs.aspect, prefs.quality)
        var egl: EglCore? = null
        var rig: TrailRig? = null
        return try {
            val eg = EglCore(null, W, H)
            egl = eg
            eg.makeCurrent()
            val r = TrailRig(W, H, prefs, data, scene, fonts, photo, title, dateText)
            rig = r
            r.draw(pos.coerceIn(0.0, 1.0) * TrailTimeline.total(prefs))
            Result.success(r.read())
        } catch (e: Throwable) {
            Result.failure(if (e is OutOfMemoryError) IllegalStateException("Memori tidak cukup untuk foto penuh. Coba kualitas 720p.") else e)
        } finally {
            runCatching { rig?.release() }
            runCatching { egl?.release() }
        }
    }
}

/**
 * Pratinjau Trail: satu thread GL dengan konteks pbuffer dan [TrailRig] yang dibangun ulang hanya bila [key] berubah.
 * [frame] harus dipanggil lewat [dispatcher]; [close] aman dipanggil dari thread mana pun.
 */
class TrailPreviewHost {
    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "trail-video-preview") }
    val dispatcher = executor.asCoroutineDispatcher()
    private var egl: EglCore? = null
    private var rig: TrailRig? = null
    private var key: Any? = null
    private var kw = 0; private var kh = 0

    fun frame(w: Int, h: Int, newKey: Any, prefs: TrailPrefs, pos: Double, factory: () -> TrailRig): Bitmap {
        if (egl != null && runCatching { egl!!.makeCurrent() }.isFailure) dropAll()
        if (egl == null || kw != w || kh != h) {
            dropAll()
            egl = EglCore(null, w, h).also { it.makeCurrent() }
            kw = w; kh = h
        }
        if (rig == null || key != newKey) {
            runCatching { rig?.release() }
            rig = null
            rig = factory()
            key = newKey
        }
        val r = rig!!
        r.draw(pos.coerceIn(0.0, 1.0) * TrailTimeline.total(prefs))
        return r.read()
    }

    private fun dropAll() {
        runCatching { rig?.release() }; runCatching { egl?.release() }
        rig = null; egl = null; key = null
    }

    fun close() {
        runCatching { executor.execute { dropAll() } }
        executor.shutdown()
    }
}
