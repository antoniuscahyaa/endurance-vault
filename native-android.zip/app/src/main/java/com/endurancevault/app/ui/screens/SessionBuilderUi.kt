package com.endurancevault.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.endurancevault.app.domain.ActivityTimeSeries
import com.endurancevault.app.domain.SegmentSplit
import com.endurancevault.app.domain.SessionBuilder
import com.endurancevault.app.ui.theme.Ember
import kotlinx.coroutines.launch

// ---- state isian (teks mentah, supaya ketikan setengah jadi tidak hilang) ----

private data class AmtUi(val text: String, val byDistance: Boolean)

private sealed interface BlockUi {
    val id: Int
    val title: String
}

private data class PlainUi(override val id: Int, override val title: String, val amt: AmtUi) : BlockUi

private data class RepeatUi(
    override val id: Int, override val title: String, val count: String,
    val work: AmtUi, val rest: AmtUi, val restAfterLast: Boolean,
) : BlockUi

/** Isian ke angka; null bila tidak valid. Istirahat ([allowZero]) boleh kosong atau 0 = tanpa istirahat. */
private fun parseAmt(a: AmtUi, allowZero: Boolean): SessionBuilder.Amount? {
    if (a.text.isBlank()) return if (allowZero) SessionBuilder.Amount(0.0, a.byDistance) else null
    return if (a.byDistance) SegmentSplit.parseMeters(a.text)?.let { SessionBuilder.Amount(it, true) }
    else SegmentSplit.parseSeconds(a.text)?.takeIf { it > 0 || allowZero }?.let { SessionBuilder.Amount(it.toDouble(), false) }
}

private fun parseCount(t: String): Int? = t.trim().toIntOrNull()?.takeIf { it in 1..SessionBuilder.MAX_REPEAT }

private fun toDomain(b: BlockUi): SessionBuilder.Block = when (b) {
    is PlainUi -> SessionBuilder.Block.Plain(b.title, parseAmt(b.amt, false))
    is RepeatUi -> SessionBuilder.Block.Repeat(
        b.title, parseCount(b.count), parseAmt(b.work, false), parseAmt(b.rest, true), b.restAfterLast,
    )
}

/** Susunan awal 15:00 + 3 × (8:00 kerja / 2:00 istirahat) + 10:00; diperkecil bila sesi lebih pendek dari 55 menit. */
private fun defaultBlocks(totalSec: Int): List<BlockUi> {
    val f = (totalSec / 3300.0).coerceAtMost(1.0)
    fun sc(sec: Int) = maxOf(5, (sec * f).toInt() / 5 * 5)
    fun t(sec: Int) = AmtUi(SegmentSplit.fmtSeconds(sec), false)
    return listOf(
        PlainUi(0, "Pemanasan", t(sc(900))),
        RepeatUi(1, "Ulangi", "3", t(sc(480)), t(sc(120)), true),
        PlainUi(2, "Pendinginan", t(sc(600))),
    )
}

/** Pindah satuan waktu <-> jarak dengan kecepatan rata-rata sesi ([mps], m/dtk), supaya isian tidak kosong. */
private fun convert(a: AmtUi, toDistance: Boolean, mps: Double): AmtUi {
    if (a.byDistance == toDistance) return a
    if (mps <= 0) return AmtUi("", toDistance)
    val text = if (toDistance) {
        SegmentSplit.parseSeconds(a.text)?.takeIf { it > 0 }?.let { (Math.round(it * mps / 10.0) * 10).coerceAtLeast(10L).toString() }
    } else {
        SegmentSplit.parseMeters(a.text)?.let { SegmentSplit.fmtSeconds(Math.round(it / mps).toInt().coerceAtLeast(1)) }
    }
    return AmtUi(text ?: "", toDistance)
}

private fun amtLabel(a: AmtUi) = a.text.trim() + if (a.byDistance && a.text.isNotBlank()) " m" else ""

private fun blockLabel(b: BlockUi): String = when (b) {
    is PlainUi -> amtLabel(b.amt)
    is RepeatUi -> "${b.count.trim()} × ${amtLabel(b.work)}" + if (b.rest.text.isNotBlank()) " / ${amtLabel(b.rest)}" else ""
}

private fun rangeLabel(r: IntRange?): String = when {
    r == null -> ""
    r.first == r.last -> "Segmen ${r.first}"
    else -> "Segmen ${r.first}–${r.last}"
}

// ---- komponen ----

@Composable
private fun AmountRow(label: String, a: AmtUi, allowZero: Boolean, onChange: (AmtUi) -> Unit, onUnit: (Boolean) -> Unit) {
    val bad = parseAmt(a, allowZero) == null
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = a.text, onValueChange = { onChange(a.copy(text = it)) },
            isError = bad, singleLine = true,
            label = { Text("$label (${if (a.byDistance) "m" else "m:ss"})") },
            modifier = Modifier.weight(1f),
        )
        FilterChip(selected = !a.byDistance, onClick = { onUnit(false) }, label = { Text("Waktu", maxLines = 1) })
        FilterChip(selected = a.byDistance, onClick = { onUnit(true) }, label = { Text("Jarak", maxLines = 1) })
    }
}

@Composable
private fun BlockCard(
    block: BlockUi, range: IntRange?, mps: Double,
    canUp: Boolean, canDown: Boolean, canDelete: Boolean,
    onChange: (BlockUi) -> Unit, onMove: (Int) -> Unit, onDelete: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val dot = if (block is RepeatUi) Ember else MaterialTheme.colorScheme.onSurface.copy(alpha = .7f)
    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).background(dot, CircleShape))
                Spacer(Modifier.width(8.dp))
                Text(block.title, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(rangeLabel(range), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Box {
                    TextButton(onClick = { menu = true }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("⋯") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Naikkan") }, enabled = canUp, onClick = { menu = false; onMove(-1) })
                        DropdownMenuItem(text = { Text("Turunkan") }, enabled = canDown, onClick = { menu = false; onMove(1) })
                        DropdownMenuItem(
                            text = { Text("Hapus blok", color = MaterialTheme.colorScheme.error) },
                            enabled = canDelete, onClick = { menu = false; onDelete() },
                        )
                    }
                }
            }
            Column(Modifier.padding(end = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                when (block) {
                    is PlainUi -> AmountRow(
                        if (block.amt.byDistance) "Jarak" else "Waktu", block.amt, false,
                        onChange = { onChange(block.copy(amt = it)) },
                        onUnit = { onChange(block.copy(amt = convert(block.amt, it, mps))) },
                    )
                    is RepeatUi -> {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = block.count,
                                onValueChange = { v -> onChange(block.copy(count = v.filter { it.isDigit() }.take(2))) },
                                isError = parseCount(block.count) == null, singleLine = true,
                                label = { Text("Jumlah") }, suffix = { Text("×") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.width(120.dp),
                            )
                            Text("putaran kerja + istirahat", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        AmountRow(
                            "Kerja", block.work, false,
                            onChange = { onChange(block.copy(work = it)) },
                            onUnit = { onChange(block.copy(work = convert(block.work, it, mps))) },
                        )
                        AmountRow(
                            "Istirahat", block.rest, true,
                            onChange = { onChange(block.copy(rest = it)) },
                            onUnit = { onChange(block.copy(rest = convert(block.rest, it, mps))) },
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Istirahat setelah putaran terakhir", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                            FilterChip(
                                selected = block.restAfterLast, onClick = { onChange(block.copy(restAfterLast = !block.restAfterLast)) },
                                label = { Text(if (block.restAfterLast) "Ya" else "Tidak") },
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Penyusun sesi: pemanasan, blok ulangi (jumlah putaran, kerja, istirahat), dan pendinginan, masing-masing dalam waktu atau
 * jarak. Segmen hasilnya tanpa label; jenis (repetisi, stride, progresif) diisi sendiri lewat pill setelah segmen jadi.
 * [onSave] menyimpan segmen (null = berhasil, selain itu pesan galat); [onAdvanced] membuka editor manual dengan susunan ini.
 */
@Composable
internal fun SessionBuilderPanel(
    ts: ActivityTimeSeries,
    onSave: suspend (List<SegmentSplit.Draft>) -> String?,
    onClose: () -> Unit,
    onCancel: () -> Unit,
    onAdvanced: (List<SegmentSplit.Draft>?) -> Unit,
) {
    val total = remember(ts) { SegmentSplit.totalSec(ts) }
    val mps = remember(ts) { (ts.distanceMeters.last() - ts.distanceMeters.first()) / total.coerceAtLeast(1) }
    val blocks = remember { mutableStateListOf<BlockUi>().also { it.addAll(defaultBlocks(total)) } }
    var nextId by remember { mutableStateOf(3) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    val snapshot = blocks.toList()
    val plan = remember(ts, snapshot) { SessionBuilder.resolve(ts, snapshot.map(::toDomain)) }
    val count = plan.isWork.size
    val ready = plan.error == null && plan.drafts.isNotEmpty()

    Text("Susun sesi", style = MaterialTheme.typography.titleMedium)

    // ---- grafik: kecepatan sesi, segmen kerja diwarnai, label tiap blok di bawahnya ----
    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(vertical = 12.dp, horizontal = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            val work = Ember.copy(alpha = .22f)
            if (plan.drafts.isNotEmpty()) {
                SegmentStrip(ts, plan.drafts.map { it.endSec }, plan.isWork.map { if (it) work else Color.Transparent })
            } else {
                SegmentStrip(ts, listOf(total), listOf(Color.Transparent))
            }
            if (plan.blockSec.size == snapshot.size) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp)) {
                    snapshot.forEachIndexed { i, b ->
                        Box(Modifier.weight(maxOf(1, plan.blockSec[i]).toFloat()), contentAlignment = Alignment.Center) {
                            Text(
                                blockLabel(b), style = MaterialTheme.typography.labelMedium, softWrap = false, maxLines = 1,
                                modifier = Modifier.wrapContentWidth(unbounded = true),
                            )
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("$count segmen", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    "Total susunan " + if (count == 0) "–" else SegmentSplit.fmtSeconds(plan.composedSec),
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }

    // ---- blok ----
    snapshot.forEachIndexed { i, b ->
        key(b.id) {
            BlockCard(
                block = b, range = plan.segments.getOrNull(i), mps = mps,
                canUp = i > 0, canDown = i < snapshot.lastIndex, canDelete = snapshot.size > 1,
                onChange = { nb -> blocks[i] = nb },
                onMove = { d -> val j = i + d; if (j in blocks.indices) { val x = blocks[i]; blocks[i] = blocks[j]; blocks[j] = x } },
                onDelete = { blocks.removeAt(i) },
            )
        }
    }

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(
            onClick = { blocks.add(PlainUi(nextId++, "Segmen biasa", AmtUi("5:00", false))) },
            modifier = Modifier.weight(1f),
        ) { Text("+ Segmen biasa", maxLines = 1) }
        OutlinedButton(
            onClick = { blocks.add(RepeatUi(nextId++, "Ulangi", "4", AmtUi("1:00", false), AmtUi("1:00", false), true)) },
            modifier = Modifier.weight(1f),
        ) { Text("+ Blok ulangi", maxLines = 1) }
    }

    // ---- ringkasan dan catatan ----
    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (plan.error != null) {
                Text(plan.error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
            } else {
                val last = snapshot.last()
                val lastSec = plan.drafts.last().endSec - (plan.drafts.getOrNull(plan.drafts.lastIndex - 1)?.endSec ?: 0)
                val where = if (last is RepeatUi) "${last.title}, segmen terakhir" else last.title
                Text(
                    "Sesi aktual ${SegmentSplit.fmtSeconds(total)}." +
                        if (plan.extraSec > 0) " Selisih ${SegmentSplit.fmtSeconds(plan.extraSec)} masuk ke blok terakhir ($where jadi ${SegmentSplit.fmtSeconds(lastSec)})." else "",
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
            Text(
                "Label repetisi, stride, atau progresif tetap diisi manual lewat pill setelah segmen jadi.",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }

    error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = onCancel, enabled = !busy, modifier = Modifier.weight(1f)) { Text("Batal") }
        Button(
            enabled = ready && !busy, modifier = Modifier.weight(1f),
            onClick = {
                busy = true; error = null
                // Satu segmen tanpa label sama dengan tidak ada pembagian.
                val toSave = if (plan.drafts.size == 1) emptyList() else plan.drafts
                scope.launch {
                    val err = onSave(toSave)
                    busy = false
                    if (err == null) onClose() else error = err
                }
            },
        ) { Text(if (busy) "Menyimpan…" else "Terapkan $count segmen", maxLines = 1) }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
        TextButton(onClick = { onAdvanced(plan.drafts.takeIf { it.isNotEmpty() }) }, enabled = !busy) {
            Text("Atur batas manual (mode lanjutan)")
        }
    }
}
