package com.endurancevault.app.domain

import com.google.gson.JsonElement
import com.google.gson.JsonObject
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Tata letak bernama: panel beserta pilihan tampilan yang menyertainya. */
data class LayoutPreset(
    val name: String,
    val panels: List<VideoPanel>,
    val ink: String = "w",
    val panelBg: String = "off",
    val live: Boolean = true,
    val lineMode: String = "solid",
    val kmMarkers: Boolean = true,
    val flagEnds: Boolean = true,
    val flagPeak: Boolean = true,
    val flagSteep: Boolean = true,
) {
    fun sanitized(): LayoutPreset = copy(
        name = name.trim().take(24),
        panels = RouteVideoPrefs.sanitizePanels(panels),
        ink = if (ink in setOf("w", "k", "l")) ink else "w",
        panelBg = if (panelBg == "soft" || panelBg == "strong") panelBg else "off",
        lineMode = if (lineMode in RouteVideoColors.MODES) lineMode else "solid",
    )

    fun toJsonObject(): JsonObject = JsonObject().also {
        it.addProperty("n", name); it.add("p", RouteVideoPrefs.panelsToJson(panels))
        it.addProperty("ink", ink); it.addProperty("bg", panelBg); it.addProperty("live", live)
        it.addProperty("lm", lineMode); it.addProperty("km", kmMarkers)
        it.addProperty("fe", flagEnds); it.addProperty("fp", flagPeak); it.addProperty("fs", flagSteep)
    }

    companion object {
        fun fromJson(e: JsonElement): LayoutPreset? {
            val o = e.takeIf { it.isJsonObject }?.asJsonObject ?: return null
            val name = o.get("n")?.takeIf { it.isJsonPrimitive }?.asString ?: return null
            val panels = o.get("p")?.takeIf { it.isJsonArray }?.asJsonArray?.let { RouteVideoPrefs.panelsFromJson(it) } ?: return null
            fun str(k: String, d: String) = o.get(k)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isString }?.asString ?: d
            fun bool(k: String, d: Boolean) = o.get(k)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isBoolean }?.asBoolean ?: d
            val legacy = bool("lb", true)
            return LayoutPreset(
                name, panels, str("ink", "w"), str("bg", "off"), bool("live", true), str("lm", "solid"), bool("km", true),
                bool("fe", legacy), bool("fp", legacy), bool("fs", legacy),
            ).sanitized()
        }
    }
}

fun RouteVideoPrefs.withPreset(p: LayoutPreset): RouteVideoPrefs = copy(
    panels = p.panels, ink = p.ink, panelBg = p.panelBg, live = p.live,
    lineMode = p.lineMode, kmMarkers = p.kmMarkers, flagEnds = p.flagEnds, flagPeak = p.flagPeak, flagSteep = p.flagSteep,
).sanitized()

fun RouteVideoPrefs.asPreset(name: String): LayoutPreset =
    LayoutPreset(name, panels, ink, panelBg, live, lineMode, kmMarkers, flagEnds, flagPeak, flagSteep).sanitized()

object RouteVideoPresets {
    val BUILT_IN: List<LayoutPreset> = listOf(
        LayoutPreset(
            "Minimal",
            listOf(
                VideoPanel("judul", 6.0, 4.5, 100), VideoPanel("jarak", 5.0, 86.0, 80),
                VideoPanel("waktu", 36.0, 86.0, 80), VideoPanel("pace", 67.0, 86.0, 80),
            ),
            ink = "w", panelBg = "off", live = true, lineMode = "solid", kmMarkers = false,
            flagEnds = false, flagPeak = false, flagSteep = false,
        ),
        LayoutPreset(
            "Lengkap",
            listOf(
                VideoPanel("judul", 6.0, 4.5, 100), VideoPanel("profil", 6.0, 45.0, 100),
                VideoPanel("jarak", 6.0, 62.0, 100), VideoPanel("waktu", 52.0, 62.0, 100),
                VideoPanel("pace", 6.0, 70.5, 100), VideoPanel("hr", 52.0, 70.5, 100),
                VideoPanel("grad", 6.0, 79.0, 100), VideoPanel("elev", 52.0, 79.0, 100),
                VideoPanel("gain", 6.0, 87.5, 100), VideoPanel("cad", 52.0, 87.5, 100),
            ),
            ink = "w", panelBg = "soft", live = true, lineMode = "hr", kmMarkers = true,
            flagEnds = true, flagPeak = true, flagSteep = true,
        ),
        LayoutPreset(
            "Gaya Coros",
            listOf(
                VideoPanel("judul", 6.0, 4.5, 100), VideoPanel("profil", 6.0, 71.0, 100),
                VideoPanel("jarak", 4.0, 87.0, 65), VideoPanel("waktu", 28.0, 87.0, 65),
                VideoPanel("pace", 52.0, 87.0, 65), VideoPanel("hr", 76.0, 87.0, 65),
            ),
            ink = "w", panelBg = "soft", live = true, lineMode = "pace", kmMarkers = true,
            flagEnds = false, flagPeak = false, flagSteep = false,
        ),
    )

    fun isBuiltIn(name: String) = BUILT_IN.any { it.name == name }
}

/** Ukuran keluaran per rasio dan kualitas. Dimensi genap; panel diskalakan menurut sisi pendek bingkai. */
object RouteVideoFormat {
    val ASPECTS = listOf("9:16", "4:5", "1:1", "16:9")

    fun size(aspect: String, quality: String): Pair<Int, Int> {
        val hd = quality != "sd"
        return when (aspect) {
            "4:5" -> if (hd) 1080 to 1350 else 720 to 900
            "1:1" -> if (hd) 1080 to 1080 else 720 to 720
            "16:9" -> if (hd) 1920 to 1080 else 1280 to 720
            else -> if (hd) 1080 to 1920 else 720 to 1280
        }
    }

    /** Ukuran pratinjau: setengah dari ukuran HD, rasio sama. */
    fun previewSize(aspect: String): Pair<Int, Int> = size(aspect, "hd").let { it.first / 2 to it.second / 2 }

    fun ratio(aspect: String): Float = size(aspect, "hd").let { it.first.toFloat() / it.second }
}

/** Warna garis rute menurut data: rampa biru (rendah) - hijau - kuning - merah (tinggi). */
object RouteVideoColors {
    val MODES = listOf("solid", "hr", "pace", "grade")

    fun modeName(m: String): String = when (m) {
        "hr" -> "Detak jantung"; "pace" -> "Pace"; "grade" -> "Gradien"; else -> "Satu warna"
    }

    private val STOPS = intArrayOf(0xFF2F80ED.toInt(), 0xFF2ECC71.toInt(), 0xFFF2C94C.toInt(), 0xFFEB4D4B.toInt())
    private const val NEUTRAL = 0xFFB0B0B0.toInt()

    /** Warna ARGB untuk [t] di 0..1. */
    fun ramp(t: Double): Int {
        val x = t.coerceIn(0.0, 1.0) * 3.0
        val i = min(2, x.toInt()); val f = x - i
        val a = STOPS[i]; val b = STOPS[i + 1]
        fun ch(shift: Int): Int = ((((a shr shift) and 255) * (1 - f)) + (((b shr shift) and 255) * f)).roundToInt().coerceIn(0, 255)
        return (0xFF shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }

    /** Nilai per sampel, rentang rampa, dan teks legenda. */
    class Info(val values: DoubleArray, val lo: Double, val hi: Double, val title: String, val loText: String, val hiText: String)

    private fun pct(v: DoubleArray): Pair<Double, Double> {
        val f = v.filter { it.isFinite() }.sorted()
        if (f.isEmpty()) return 0.0 to 1.0
        val lo = f[(f.size * 0.05).toInt()]
        val hi = f[min(f.size - 1, (f.size * 0.95).toInt())]
        return if (hi - lo < 1e-9) (lo - 1.0) to (hi + 1.0) else lo to hi
    }

    private fun paceText(speedMs: Double): String = if (speedMs > 0.1) Js.paceStr(1000.0 / speedMs / 60.0) else "–"

    /** Null untuk mode "solid". Hasil disimpan di cache jejak. */
    fun info(t: RouteVideoTrack, mode: String): Info? {
        if (mode !in MODES || mode == "solid") return null
        return t.cache.getOrPut("col:$mode") { build(t, mode) } as Info
    }

    private fun build(t: RouteVideoTrack, mode: String): Info {
        val n = t.n
        return when (mode) {
            "hr" -> {
                val v = RouteVideoTrack.smooth(DoubleArray(n) { if (t.hr[it] >= 30) t.hr[it].toDouble() else Double.NaN }, 5)
                val (lo, hi) = pct(v)
                Info(v, lo, hi, "DETAK JANTUNG", "${lo.roundToInt()} bpm", "${hi.roundToInt()} bpm")
            }
            "pace" -> {
                val sp = DoubleArray(n) { i ->
                    val k = max(0, i - 10); val j = min(n - 1, i + 10)
                    val dd = t.dist[j] - t.dist[k]; val dt = (t.sec[j] - t.sec[k]).toDouble()
                    if (dd >= 8.0 && dt > 0) dd / dt else Double.NaN
                }
                val v = RouteVideoTrack.smooth(sp, 5)
                val (lo, hi) = pct(v)
                if (t.bike) Info(v, lo, hi, "KECEPATAN", String.format(java.util.Locale.US, "%.1f km/j", lo * 3.6).replace('.', ','), String.format(java.util.Locale.US, "%.1f km/j", hi * 3.6).replace('.', ','))
                else Info(v, lo, hi, "PACE", paceText(lo), paceText(hi))
            }
            else -> Info(t.gradeS, -10.0, 10.0, "GRADIEN", "-10%", "+10%")
        }
    }

    fun colorOf(mode: String, v: Double, info: Info): Int {
        if (!v.isFinite()) return NEUTRAL
        if (mode == "grade") {
            val t = if (v >= 0) 0.33 + 0.67 * min(v / 10.0, 1.0) else 0.33 - 0.33 * min(-v / 10.0, 1.0)
            return ramp(t)
        }
        return ramp((v - info.lo) / (info.hi - info.lo))
    }

    /** Warna per titik rute (menurut [fracs], bagian jarak). Mode "solid" memberi [accent] di semua titik. */
    fun colors(t: RouteVideoTrack, mode: String, accent: Int, fracs: FloatArray): IntArray {
        val info = info(t, mode) ?: return IntArray(fracs.size) { accent }
        return IntArray(fracs.size) { colorOf(mode, info.values[t.indexAtDist(fracs[it] * t.totalM)], info) }
    }

    /** [steps] warna dari rendah (kiri) ke tinggi (kanan) untuk batang legenda. */
    fun legendColors(mode: String, steps: Int): IntArray {
        val dummy = Info(DoubleArray(0), 0.0, 1.0, "", "", "")
        return IntArray(steps) { i ->
            val x = i.toDouble() / (steps - 1).coerceAtLeast(1)
            if (mode == "grade") colorOf(mode, -10.0 + 20.0 * x, dummy) else ramp(x)
        }
    }
}

/** Titik penting di rute yang diberi bendera di peta 3D. [kind]: start, finish, km, peak, steep. */
class Anchor(val kind: String, val idx: Int, val frac: Double, val km: Int = 0, val value: Double = Double.NaN)

/** Jarak antar bendera km: 1 km, atau 2/5/10 km untuk rute panjang (maksimal ±20 bendera). */
fun RouteVideoTrack.kmStep(): Int {
    val km = totalM / 1000.0
    return when { km <= 20 -> 1; km <= 45 -> 2; km <= 110 -> 5; else -> 10 }
}

fun RouteVideoTrack.allAnchors(): List<Anchor> {
    val out = ArrayList<Anchor>()
    out += Anchor("start", 0, 0.0)
    out += Anchor("finish", n - 1, 1.0)
    val step = kmStep()
    var k = step
    while (k * 1000.0 <= totalM - 300.0) {
        val i = indexAtDist(k * 1000.0)
        out += Anchor("km", i, dist[i] / totalM, km = k)
        k += step
    }
    if (hasEle) {
        var pk = -1
        for (i in 0 until n) if (eleS[i].isFinite() && (pk < 0 || eleS[i] > eleS[pk])) pk = i
        val lo = eleS.filter { it.isFinite() }.minOrNull() ?: 0.0
        if (pk >= 0 && eleS[pk] - lo >= 15.0) out += Anchor("peak", pk, dist[pk] / totalM, value = eleS[pk])
        var bestG = 0.0; var bestMid = -1
        for (i in 0 until n step 5) {
            val j = indexAtDist(dist[i] + 100.0)
            val dd = dist[j] - dist[i]
            if (dd < 80.0) continue
            val g = (eleS[j] - eleS[i]) / dd * 100.0
            if (g.isFinite() && g > bestG) { bestG = g; bestMid = (i + j) / 2 }
        }
        if (bestMid >= 0 && bestG >= 4.0) out += Anchor("steep", bestMid, dist[bestMid] / totalM, value = bestG)
    }
    return out
}

/** Pace (menit/km) pada [Anchor] km: rata-rata [kmStep] km terakhir. */
fun RouteVideoTrack.kmPace(a: Anchor): Double? {
    val step = kmStep()
    val i0 = if (a.km - step <= 0) 0 else indexAtDist((a.km - step) * 1000.0)
    val dd = dist[a.idx] - dist[i0]; val dt = (sec[a.idx] - sec[i0]).toDouble()
    return if (dd > 50.0 && dt > 0) dt / 60.0 / (dd / 1000.0) else null
}

/** Balapan dengan ghost: kemajuan dihitung menurut waktu gerak yang sama, bukan menurut jarak. */
class RouteVideoRace(val main: RouteVideoTrack, val ghost: RouteVideoTrack) {
    val tMax: Double = max(main.totalSec, ghost.totalSec).toDouble().coerceAtLeast(1.0)

    /** (bagian jarak utama, bagian jarak ghost) saat [r] (0..1) dari total waktu balapan. */
    fun fractions(r: Double): Pair<Double, Double> {
        val t = r.coerceIn(0.0, 1.0) * tMax
        return main.fracAtTime(t) to ghost.fracAtTime(t)
    }

    /** Selisih detik pada jarak yang sama; positif = aktivitas utama unggul (lebih cepat tiba). */
    fun gapSeconds(mainFrac: Double): Double {
        val i = main.indexAtDist(mainFrac.coerceIn(0.0, 1.0) * main.totalM)
        return ghost.timeAtDist(main.dist[i]) - main.sec[i]
    }
}

class GhostInfo(val name: String, val gapSec: Double)
