package com.endurancevault.app.ui

import android.graphics.Bitmap
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.ContentScale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * Pengganti `Modifier.blur` untuk Android < 12 (API < 31), yang tidak punya RenderEffect.
 *
 * Cara kerja: konten direkam ke GraphicsLayer. Begitu [active] menjadi true (drawer mulai dibuka),
 * layer diambil sebagai bitmap, dikecilkan, dikaburkan di thread background, lalu ditampilkan
 * sebagai overlay yang memudar masuk di bawah scrim drawer. Hasilnya snapshot statis.
 *
 * Gunakan hanya bila `Build.VERSION.SDK_INT < 31`; di API 31+ pakai `Modifier.blur`.
 */
@Composable
internal fun LegacyBlurBehind(
    active: Boolean,
    modifier: Modifier = Modifier,
    downscale: Int = 4,
    radius: Int = 6,
    content: @Composable () -> Unit,
) {
    val layer = rememberGraphicsLayer()
    var blurred by remember { mutableStateOf<Bitmap?>(null) }
    val overlayAlpha by animateFloatAsState(if (active && blurred != null) 1f else 0f, label = "legacyBlurAlpha")

    LaunchedEffect(active) {
        if (active) {
            val result = runCatching {
                val captured = layer.toImageBitmap().asAndroidBitmap()
                withContext(Dispatchers.Default) { blurBitmap(captured, downscale, radius) }
            }.getOrNull()
            blurred = result
        } else {
            // Beri waktu animasi fade-out selesai sebelum bitmap dilepas.
            delay(350)
            blurred = null
        }
    }

    Box(modifier) {
        Box(
            Modifier
                .fillMaxSize()
                .drawWithContent {
                    layer.record { this@drawWithContent.drawContent() }
                    drawLayer(layer)
                },
        ) { content() }

        val bmp = blurred
        if (bmp != null && overlayAlpha > 0f) {
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.fillMaxSize().alpha(overlayAlpha),
            )
        }
    }
}

/** Kecilkan bitmap lalu kaburkan dengan box blur 3 kali (mendekati gaussian). */
private fun blurBitmap(source: Bitmap, downscale: Int, radius: Int): Bitmap {
    val sw = if (source.config == Bitmap.Config.HARDWARE) source.copy(Bitmap.Config.ARGB_8888, false) else source
    val w = (sw.width / downscale).coerceAtLeast(1)
    val h = (sw.height / downscale).coerceAtLeast(1)
    val small = Bitmap.createScaledBitmap(sw, w, h, true)
    val px = IntArray(w * h)
    small.getPixels(px, 0, w, 0, 0, w, h)
    var a = px
    var b = IntArray(px.size)
    repeat(3) {
        boxPass(a, b, w, h, radius, horizontal = true)
        boxPass(b, a, w, h, radius, horizontal = false)
    }
    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    out.setPixels(a, 0, w, 0, 0, w, h)
    return out
}

private fun boxPass(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
    val len = if (horizontal) w else h
    val lines = if (horizontal) h else w
    val stride = if (horizontal) 1 else w
    val div = 2 * r + 1
    for (line in 0 until lines) {
        val base = if (horizontal) line * w else line
        var sa = 0; var sr = 0; var sg = 0; var sb = 0
        for (k in -r..r) {
            val p = src[base + k.coerceIn(0, len - 1) * stride]
            sa += p ushr 24; sr += (p shr 16) and 0xFF; sg += (p shr 8) and 0xFF; sb += p and 0xFF
        }
        for (i in 0 until len) {
            dst[base + i * stride] = ((sa / div) shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
            val o = src[base + (i - r).coerceIn(0, len - 1) * stride]
            val n = src[base + (i + r + 1).coerceIn(0, len - 1) * stride]
            sa += (n ushr 24) - (o ushr 24)
            sr += ((n shr 16) and 0xFF) - ((o shr 16) and 0xFF)
            sg += ((n shr 8) and 0xFF) - ((o shr 8) and 0xFF)
            sb += (n and 0xFF) - (o and 0xFF)
        }
    }
}
