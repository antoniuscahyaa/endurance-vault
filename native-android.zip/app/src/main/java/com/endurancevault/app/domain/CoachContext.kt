package com.endurancevault.app.domain

import java.time.LocalDate
import java.time.temporal.ChronoUnit

/**
 * Potongan konteks untuk system prompt AI Coach. Murni Kotlin (tanpa Android) agar bisa diuji unit.
 *
 * Padanan native dari `aiContext()` di modul web 18b-ai-coach.js: sesi hari ini, tren 4 minggu bergulir, readiness dan beban
 * latihan, serta libur dadakan 28 hari. Ditambah ringkasan kebiasaan hari dalam seminggu (khusus native).
 *
 * Latar belakang: pilihan "No plan" (rtype = "none") membuat [PlanEngine.plan] mengembalikan minggu-minggu yang semua harinya
 * [Kinds.REST] ("Libur", 0 km). Bila itu dikirim apa adanya sebagai "Rencana mendatang", model menganggap hari ini jadwal libur.
 */
object CoachContext {
    private val DAY_NAMES = listOf("Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu")

    /** Jendela kebiasaan: 28 hari terakhir (tanpa hari ini) = tepat 4 kali tiap hari dalam seminggu. */
    const val HABIT_WINDOW_DAYS = 28

    /** Jumlah jendela 7 hari pada tren (sama dengan web: 4 minggu bergulir). */
    const val TREND_WEEKS = 4

    /** Kalimat yang sama dengan web saat tidak ada sesi terjadwal hari ini. */
    const val NO_SESSION_STATUS = "Tidak ada sesi terjadwal hari ini."

    const val NO_PLAN_NOTE = NO_SESSION_STATUS +
        " Pengguna TIDAK memakai rencana latihan (mode No plan): tidak ada jadwal lari atau hari libur yang ditetapkan, " +
        "jadi jangan menganggap hari ini atau hari lain sebagai hari libur. Beri saran latihan dari tren 4 minggu, " +
        "kebiasaan latihan, readiness, dan beban latihan di bawah. Sarankan istirahat hanya bila ada alasan dari data " +
        "(readiness rendah, nyeri, beban sangat tinggi, lari berat berturut-turut, atau hari ini memang biasanya tidak lari)."

    /** Panduan keputusan latihan, diambil dari prompt AI Coach web. */
    const val DECISION_GUIDE =
        "Untuk keputusan latihan, prioritaskan keselamatan, riwayat nyeri, pemulihan, dan rencana; jangan mengubah jadwal " +
            "otomatis tanpa persetujuan. Jangan mendiagnosis. Bedakan data aktual, estimasi, dan saran. Saat menjawab latihan " +
            "hari ini, sebutkan jenis, jarak, dan durasi bila tersedia, beserta alasan rekomendasi."

    fun dayName(d: LocalDate): String = DAY_NAMES[d.dayOfWeek.value - 1]

    /** Rencana aktif = ada jadwal sungguhan (bukan mode No plan, bukan plan error). */
    fun planActive(plan: PlanOutcome): Boolean = plan is PlanOutcome.Ok && !plan.none

    /** Apakah ada sesi latihan (bukan libur) pada [dateIso] di rencana aktif. Dipakai untuk aksi lewati/tandai selesai. */
    fun hasSessionOn(plan: PlanOutcome, dateIso: String): Boolean =
        plan is PlanOutcome.Ok && !plan.none &&
            plan.weeks.any { w -> w.days.any { it.date.toString() == dateIso && it.kind != Kinds.REST } }

    /** Satu lari (bukan sepeda) untuk ringkasan tren. [minutes] = durasi menit, [avgHr] = HR rata-rata bila ada. */
    data class RunPoint(val date: LocalDate, val km: Double, val minutes: Double, val avgHr: Int?)

    private fun paceStr(minPerKm: Double): String {
        val s = Math.round(minPerKm * 60).toInt()
        return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
    }

    /**
     * Ringkasan [TREND_WEEKS] jendela 7 hari bergulir dari [today] (terbaru dahulu), setara aiTrendContext() di web:
     * jumlah sesi, km, menit, pace rata-rata, dan HR rata-rata (berbobot menit). Lari dengan km <= 0 dilewati.
     */
    fun trendSummary(runs: List<RunPoint>, today: LocalDate): String {
        class W { var n = 0; var km = 0.0; var min = 0.0; var hw = 0.0; var hm = 0.0 }
        val ws = List(TREND_WEEKS) { W() }
        for (r in runs) {
            val off = ChronoUnit.DAYS.between(r.date, today).toInt()
            if (off < 0 || off >= TREND_WEEKS * 7 || r.km <= 0.0) continue
            val w = ws[off / 7]
            w.n++; w.km += r.km; w.min += r.minutes
            val hr = r.avgHr
            if (hr != null && hr > 0 && r.minutes > 0.0) { w.hw += hr * r.minutes; w.hm += r.minutes }
        }
        val lines = ws.mapIndexed { i, w ->
            val label = "${i * 7}-${i * 7 + 6} hari lalu"
            if (w.n == 0) "- $label: tidak ada lari"
            else buildString {
                append("- $label: ${w.n} sesi, ${"%.1f".format(java.util.Locale.US, w.km)} km, ${Math.round(w.min)} menit")
                if (w.km > 0) append(", pace ${paceStr(w.min / w.km)} /km")
                if (w.hm > 0) append(", HR rata-rata ${Math.round(w.hw / w.hm)}")
            }
        }
        return "Tren lari ${TREND_WEEKS} minggu (jendela 7 hari bergulir dari hari ini, terbaru dahulu, tanpa sepeda):\n" + lines.joinToString("\n")
    }

    /** Readiness (skor, faktor, saran) dan beban latihan (fitness/fatigue/form) dari hasil [TrainingMetrics.calculate]. */
    fun recoverySummary(m: TrainingMetricsResult?): String {
        val r = m?.readiness
        return buildString {
            if (r == null) append("Readiness: belum tersedia (data belum cukup). Jangan menebak angka readiness.")
            else {
                append("Readiness hari ini ${r.score}/100 (${r.tier}), dari ${r.dataDays} hari data. Saran aplikasi: ${r.advice}")
                val parts = r.parts.filter { it.score != null }
                if (parts.isNotEmpty()) append("\nFaktor: " + parts.joinToString("; ") { "${it.label} ${it.score}/100 (${it.detail})" })
                r.sleepDebtHours?.let { append("\nUtang tidur 7 hari: ${"%.1f".format(java.util.Locale.US, it)} jam") }
            }
            if (m != null && m.days.isNotEmpty()) {
                append("\nBeban latihan: fitness ${m.fitness}, fatigue ${m.fatigue}, form ${m.form}. Status: ${m.status}. ${m.statusDetail}")
                if (m.recoveryRemainingHours > 0) append(" Sisa pemulihan sekitar ${m.recoveryRemainingHours} jam.")
            }
        }
    }

    /** Libur dadakan (spread) 28 hari terakhir, dari [SessionAdjust.spHistory]; setara `unplannedRests` di web. */
    fun unplannedRestsSummary(items: List<Pair<String, MvEntry>>): String =
        if (items.isEmpty()) "tidak ada"
        else items.joinToString("; ") { (date, e) ->
            "$date: libur dadakan, ${"%.1f".format(java.util.Locale.US, e.km)} km dibagi ke ${e.spread.size} hari"
        }

    /**
     * Ringkasan kebiasaan lari dari [runDates] (tanggal lari saja, bukan sepeda) selama [HABIT_WINDOW_DAYS] hari sebelum [today].
     * Berisi hitungan per hari dalam seminggu, apakah hari ini sudah ada lari, dan jeda sejak lari terakhir.
     */
    fun habitSummary(runDates: List<LocalDate>, today: LocalDate): String {
        val from = today.minusDays(HABIT_WINDOW_DAYS.toLong())
        val inWindow = runDates.filter { !it.isBefore(from) && it.isBefore(today) }
        val perDay = IntArray(7)
        inWindow.forEach { perDay[it.dayOfWeek.value - 1]++ }
        val weeks = HABIT_WINDOW_DAYS / 7
        val counts = DAY_NAMES.indices.joinToString(", ") { "${DAY_NAMES[it]} ${perDay[it]}x" }
        val todayRun = runDates.any { it == today }
        val last = runDates.filter { !it.isAfter(today) }.maxOrNull()
        val sinceLast = last?.let { ChronoUnit.DAYS.between(it, today) }
        return buildString {
            append("Kebiasaan latihan (lari, $HABIT_WINDOW_DAYS hari terakhir tanpa hari ini; tiap hari muncul $weeks kali): ")
            if (inWindow.isEmpty()) append("belum ada lari tercatat. ") else append("$counts. Rata-rata ${"%.1f".format(java.util.Locale.US, inWindow.size.toDouble() / weeks)} lari/pekan. ")
            append("Hari ini ${dayName(today)} ($today): ")
            append(if (todayRun) "sudah ada lari tercatat. " else "belum ada lari tercatat. ")
            when {
                sinceLast == null -> {}
                sinceLast == 0L -> append("Lari terakhir hari ini.")
                else -> append("Lari terakhir $sinceLast hari lalu (${dayName(last!!)}).")
            }
        }.trim()
    }
}
