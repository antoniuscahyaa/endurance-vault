package com.endurancevault.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.domain.ActDetail
import com.endurancevault.app.domain.ActInsights
import com.endurancevault.app.domain.ActivityAnalytics
import com.endurancevault.app.domain.EasyRunAnalytics
import com.endurancevault.app.domain.Js
import com.endurancevault.app.domain.PDay
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.RouteAnalytics
import com.endurancevault.app.domain.TrainingMetricsResult
import com.endurancevault.app.domain.Zones
import com.endurancevault.app.ui.UiState
import com.endurancevault.app.ui.theme.Ember
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import org.json.JSONObject

private val DAY_SHORT = arrayOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min")

/**
 * Detail aktivitas: tiga halaman seperti di rencana-lari.
 * Ringkasan (statistik, rute, elevasi, grafik sesi, cuaca, komentar), Zona dan beban (zona HR, training effect,
 * load, recovery, recovery HR, easy run), Per km (cek rencana, split, segmen).
 * Bagikan aktivitas, peta dasar, rute serupa, dan hapus impor belum dimigrasi.
 */
@Composable
fun ActivityDetailScreen(
    state: UiState, id: Long, load: suspend (ActivityEntity) -> ActDetail?,
    metrics: TrainingMetricsResult?, onSetGear: (Long, String?) -> Unit, onBack: () -> Unit,
) {
    val e = state.activities.firstOrNull { it.id == id }
    var page by rememberSaveable { mutableStateOf(0) }
    var showElapsed by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp),
    ) {
        TextButton(onClick = onBack) { Text("‹ Kembali") }
        if (e == null) { Text("Aktivitas tidak ditemukan."); return@Column }
        val loaded by produceState<Pair<Boolean, ActDetail?>>(false to null, e.id, e.detailFile) { value = true to load(e) }
        val d = loaded.second
        val bike = e.type == "bike"
        val dateOnly = e.dateIso.take(10)
        val planDay: PDay? = remember(state.plan, dateOnly) {
            (state.plan as? PlanOutcome.Ok)?.weeks?.flatMap { it.days }?.firstOrNull { it.date.toString() == dateOnly }
        }
        val watchMeta = remember(e.note) { runCatching { JSONObject(e.note).takeIf { it.optString("source") == "huawei-watch" } }.getOrNull() }
        val sessionMetric = metrics?.sessions?.firstOrNull { it.activityId == e.id }
        val hist: Map<Int, Double> = d?.hrHist?.takeIf { it.isNotEmpty() } ?: state.hrHistByActivity[e.id].orEmpty()

        // Statistik utama: pakai detail bila ada, jika tidak pakai catatan
        val km = d?.km?.takeIf { it > 0 } ?: e.km
        val movingMin = d?.movingMin?.takeIf { it > 0 } ?: (e.durationSec / 60.0)
        val avgHr = d?.hr ?: e.avgHr
        val maxHr = d?.hrMax ?: e.maxHr
        val gain = d?.gain ?: e.gain
        val splits = d?.splits.orEmpty()
        val gap = ActInsights.gapOfActivity(d?.gapPace, splits, gain != null, bike)
        val timeInfo = ActInsights.timeInfo(movingMin, d?.elapsedMin ?: 0.0)
        val stride = ActInsights.strideLength(km, movingMin, d?.cad)
        val fastest = ActInsights.fastestKm(splits, bike)
        val vert = ActInsights.verticalSpeed(d?.vam, gain, movingMin)

        // ---- judul ----
        Text(e.name.ifBlank { if (bike) "Sepeda" else "Lari" }, style = MaterialTheme.typography.headlineSmall)
        val weather = d?.weather
        val subtitle = buildString {
            append(e.dateIso)
            e.startTime?.let { append(" · ").append(it) }
            if (planDay != null && planDay.km > 0) append(" · rencana ${Js.fmtKm(planDay.km)} km")
            if (weather != null) {
                append(" · ").append(Js.roundI(weather.tempC)).append("°C")
                ActInsights.weatherLabel(weather.code)?.let { append(' ').append(it) }
            }
        }
        Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)

        // ---- hero: jarak, waktu, pace ----
        EvPanel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f)) {
                        Text("Jarak", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(fmtKmUi(Math.round(km * 100) / 100.0), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                            Text("km", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(bottom = 4.dp))
                        }
                    }
                    Column(Modifier.weight(1f)) {
                        val elapsedShown = showElapsed && timeInfo.elapsed != null
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(if (elapsedShown) "Waktu total" else "Waktu gerak", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            if (timeInfo.elapsed != null) {
                                Text("⇄", color = Ember, modifier = Modifier.clickable { showElapsed = !showElapsed }.padding(horizontal = 4.dp))
                            }
                        }
                        Text(if (elapsedShown) timeInfo.elapsed ?: timeInfo.moving else timeInfo.moving, style = MaterialTheme.typography.titleLarge)
                        if (timeInfo.pause != null) Text("jeda ${timeInfo.pause}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Column(Modifier.weight(1f)) {
                        val elapsedShown = showElapsed && timeInfo.elapsed != null
                        val minutes = if (elapsedShown) (d?.elapsedMin ?: movingMin) else movingMin
                        Text(
                            if (bike) (if (elapsedShown) "Kecepatan total" else "Kecepatan") else (if (elapsedShown) "Pace total" else "Pace"),
                            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Text(
                            if (km > 0 && minutes > 0) (if (bike) "${ActInsights.dec(km / (minutes / 60))} km/j" else Js.paceStr(minutes / km) + "/km") else "–",
                            style = MaterialTheme.typography.titleLarge,
                        )
                    }
                }
                if (planDay != null && planDay.km > 0 && !bike) {
                    val onPlan = Math.abs(km - planDay.km) / planDay.km <= 0.05
                    Box(Modifier.background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 4.dp)) {
                        Text(
                            if (onPlan) "Sesuai rencana ${Js.fmtKm(planDay.km)} km" else "Rencana ${Js.fmtKm(planDay.km)} km",
                            style = MaterialTheme.typography.labelMedium,
                        )
                    }
                }
            }
        }

        // ---- kelompok statistik ----
        DStatGroup(
            if (bike) "Kecepatan" else "Pace",
            listOf(
                Triple("GAP pace", gap?.let { Js.paceStr(it) + "/km" }, null),
                Triple("Km tercepat", fastest?.let { Js.paceStr(it.pace) + "/km" }, fastest?.let { "km " + if (it.partial) fmtKmUi(it.k) else it.k.toInt().toString() }),
                Triple("Segmen tercepat", ActInsights.fastestSegment(d?.segments.orEmpty(), bike)?.let { Js.paceStr(it.pace) + "/km" }, ActInsights.fastestSegment(d?.segments.orEmpty(), bike)?.name),
            ),
        )
        DStatGroup(
            "Jantung",
            listOf(
                Triple("HR rata-rata", avgHr?.toString() ?: "–", metrics?.lthr?.let { l -> avgHr?.let { "${Js.roundI(it * 100.0 / l)}% LTHR" } }),
                Triple("HR maks", maxHr?.toString() ?: "–", null),
            ),
        )
        DStatGroup(
            "Elevasi",
            listOf(
                Triple("Elev. Gain", gain?.let { "${Js.idn(it)} m" }, null),
                Triple("Elev. Loss", (d?.loss ?: watchMeta?.takeIf { it.has("elevationLoss") }?.optDouble("elevationLoss")?.takeIf { it.isFinite() && it >= 0 }?.let { Js.roundI(it) })?.let { "${Js.idn(it)} m" }, null),
                Triple("Vertical speed", vert?.let { "${Js.idn(it.avg)} m/j" }, vert?.best?.let { b -> "terbaik ${Js.idn(b)} m/j" + (vert?.windowMin?.let { w -> " per $w mnt" } ?: "") }),
            ),
        )
        DStatGroup(
            "Teknik",
            listOf(
                Triple("Kadens", d?.cad?.let { "$it ${if (bike) "rpm" else "spm"}" }, null),
                Triple("Panjang langkah", stride?.let { ActInsights.dec(it, 2) + " m" }, null),
            ),
        )

        // ---- data dari jam ----
        if (watchMeta != null) {
            Text("Data tersinkron langsung dari Huawei Watch", color = MaterialTheme.colorScheme.onSurfaceVariant)
            d?.battery?.let { b ->
                DCaption("Baterai jam terpakai ${if (b.approx) "~" else ""}−${b.usedPct}% (${b.startPct}% → ${b.endPct}%)" + (b.perHour?.takeIf { it > 0 }?.let { " · ${ActInsights.dec(it)}%/jam" } ?: ""))
            }
            watchMeta.optString("userNote").takeIf { it.isNotBlank() }?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        } else if (e.note.isNotBlank()) Text(e.note, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (d == null && loaded.first.not()) Text("Memuat detail…", color = MaterialTheme.colorScheme.onSurfaceVariant)

        // ---- gear ----
        if (!bike) GearPicker(state, e, onSetGear)

        // ---- pilih halaman ----
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Ringkasan", "Zona & beban", "Per km").forEachIndexed { i, label ->
                FilterChip(selected = page == i, onClick = { page = i }, label = { Text(label) }, modifier = Modifier.weight(1f))
            }
        }

        when (page) {
            0 -> SummaryPage(state, e, d, loaded.first, metrics, planDay, avgHr, gain, splits, bike, km, movingMin, hist)
            1 -> ZonesLoadPage(state, e, d, metrics, sessionMetric, watchMeta, hist)
            else -> KmPage(state, e, d, planDay, hist, avgHr, gain, km, bike)
        }
    }
}

@Composable
private fun GearPicker(state: UiState, e: ActivityEntity, onSetGear: (Long, String?) -> Unit) {
    if (state.gear.isEmpty()) {
        DCaption("Belum ada gear. Tambahkan sepatu di tab Profil agar bisa dipilih di sini.")
        return
    }
    var open by remember { mutableStateOf(false) }
    val current = state.gear.firstOrNull { it.id == e.gearId }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text("Gear (sepatu)", style = MaterialTheme.typography.bodyMedium)
        Box {
            OutlinedButton(onClick = { open = true }) { Text((current?.name ?: "Tanpa gear") + if (current?.retired == true) " (pensiun)" else "") }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                DropdownMenuItem(text = { Text("Tanpa gear") }, onClick = { open = false; onSetGear(e.id, null) })
                state.gear.filter { !it.retired || it.id == e.gearId }.forEach { g ->
                    DropdownMenuItem(text = { Text(g.name + if (g.retired) " (pensiun)" else "") }, onClick = { open = false; onSetGear(e.id, g.id) })
                }
            }
        }
    }
}

// ============================ Halaman 1: Ringkasan ============================

@Composable
private fun SummaryPage(
    state: UiState, e: ActivityEntity, d: ActDetail?, loadedDone: Boolean, metrics: TrainingMetricsResult?, planDay: PDay?,
    avgHr: Int?, gain: Int?, splits: List<com.endurancevault.app.domain.Split>, bike: Boolean, km: Double, movingMin: Double,
    hist: Map<Int, Double>,
) {
    if (e.detailFile == null) {
        DCaption("Aktivitas ini belum punya rute dan grafik. Impor berkas FIT, GPX, atau TCX dari tab Progres, atau sinkronkan dari jam, untuk menambahkannya.")
    } else if (loadedDone && d == null) {
        Text("Detail aktivitas tidak bisa dibaca.", color = MaterialTheme.colorScheme.error)
    }
    if (d != null) {
        if (d.hasRoute) { DSection("Rute"); DRouteView(d) }
        val denseElevation = d.timeSeries?.let { ts -> ts.distanceMeters.indices.mapNotNull { i -> ts.elevationMeters[i]?.let { ts.distanceMeters[i] / 1000.0 to it } } }.orEmpty()
        val elevationChart = if (denseElevation.size >= 2) ActInsights.downsample(denseElevation, 600) else d.profile
        if (elevationChart.size >= 2) {
            DSection("Profil elevasi")
            DLineChart(elevationChart, Color8FA3B8, invert = false)
            RouteAnalytics.summarize(d.profile.ifEmpty { elevationChart })?.let { s ->
                EvMetricRow(listOf("Tertinggi" to "${Math.round(s.maxMeters)} m", "Terendah" to "${Math.round(s.minMeters)} m", "Rentang" to "${Math.round(s.rangeMeters)} m"))
                EvMetricRow(listOf("Tanjakan tercuram" to (s.steepestUpPercent?.let { "+%.1f%%".format(it) } ?: "–"), "Turunan tercuram" to (s.steepestDownPercent?.let { "%.1f%%".format(it) } ?: "–")))
            }
            DCaption("Kemiringan dihitung antar titik profil berjarak minimal 20 m.")
        }
        val chart = remember(d) { ActInsights.chartModel(d) }
        if (chart != null) {
            DSection("Grafik sesi", if (chart.xIsTime) "Sumbu waktu · data per detik" else "Sumbu jarak")
            DSessionChart(chart, bike)
            if ((d.cad ?: 0) > 0 && chart.get(ActInsights.SeriesKey.CAD) == null) {
                DCaption("Kadens rata-rata ${d.cad} ${if (bike) "rpm" else "spm"} dari ringkasan jam. Jam belum mengirim kadens per detik untuk sesi ini, jadi belum ada garis kadens.")
            }
        }
        // Cuaca
        DSection("Cuaca saat lari")
        val w = d.weather
        if (w != null) {
            EvMetricRow(
                listOfNotNull(
                    "Suhu" to "${Js.roundI(w.tempC)}°C",
                    w.feelsLikeC?.let { "Terasa" to "${Js.roundI(it)}°C" },
                    w.humidityPct?.let { "Kelembapan" to "$it%" },
                ),
            )
            EvMetricRow(
                listOfNotNull(
                    w.windKmh?.let { "Angin" to "${Js.roundI(it)} km/j" },
                    "Hujan" to ((w.rainMm ?: 0.0).let { if (it > 0) ActInsights.dec(it) + " mm" else "0 mm" }),
                    ActInsights.weatherLabel(w.code)?.let { "Kondisi" to it },
                ),
            )
            w.watchTempC?.let { DCaption("Sensor jam ${Js.roundI(it)}°C (biasanya lebih tinggi dari udara karena panas tubuh).") }
            DCaption("Data cuaca di titik awal dan jam lari, dari Open-Meteo.com. Ini perkiraan model, bukan sensor.")
        } else {
            DCaption("Belum ada data cuaca untuk aktivitas ini. Pengambilan cuaca otomatis belum dimigrasi.")
        }
    }
    // Komentar otomatis
    if (!bike && km > 0) {
        val previous = remember(metrics, e.id, state.activities) {
            val byId = state.activities.associateBy { it.id }
            val date = runCatching { LocalDate.parse(e.dateIso.take(10)) }.getOrNull()
            metrics?.sessions.orEmpty()
                .filter { s -> s.activityId != e.id && date != null && s.date.isBefore(date) && byId[s.activityId]?.type != "bike" && s.load > 0 }
                .sortedByDescending { it.date }.take(10)
        }
        val mine = metrics?.sessions?.firstOrNull { it.activityId == e.id }
        val comments = ActInsights.comments(
            ActInsights.CommentInput(
                km = km, movingMin = movingMin, avgHr = avgHr, lthr = metrics?.lthr ?: Zones.cuts(state.settings).lthr ?: 0,
                dayKind = planDay?.kind, dayBench = planDay?.bench == true, splits = splits, gain = gain, gapPace = d?.gapPace, bike = false,
                sessionLoad = mine?.load, previousAvgLoad = previous.takeIf { it.isNotEmpty() }?.map { it.load }?.average(), previousCount = previous.size,
                aerobicEffect = mine?.aerobicEffect,
            ),
        )
        if (comments.isNotEmpty()) {
            DSection("Komentar otomatis")
            DCheckList(comments)
            DCaption("Komentar dihitung otomatis dari data sesi dan riwayatmu. Ini perkiraan, bukan saran medis.")
        }
    }
}

private val Color8FA3B8 = androidx.compose.ui.graphics.Color(0xFF8FA3B8)

// ============================ Halaman 2: Zona dan beban ============================

@Composable
private fun ZonesLoadPage(
    state: UiState, e: ActivityEntity, d: ActDetail?, metrics: TrainingMetricsResult?,
    sm: com.endurancevault.app.domain.TrainingSessionMetric?, watchMeta: JSONObject?, hist: Map<Int, Double>,
) {
    DSection("Zona HR")
    if (hist.isNotEmpty() && hist.values.sum() > 60) DZoneBlock(state, hist) else DCaption("Tanpa data HR per detik untuk sesi ini, jadi sebaran zona belum bisa dihitung.")

    // Training effect
    val teA = sm?.aerobicEffect; val teN = sm?.anaerobicEffect
    if (sm != null && (teA ?: 0.0) > 0) {
        DSection(if (sm.fromWatch) "Training effect dari jam" else "Training effect (perkiraan aplikasi)")
        EvPanel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                DEffectRow("Aerobik", teA ?: 0.0, DetailGreen)
                if ((teN ?: 0.0) > 0) DEffectRow("Anaerob", teN ?: 0.0, Ember)
            }
        }
        DCaption(if (sm.fromWatch) "Angka TE diambil dari jam Huawei." else "Dihitung dari load sesi dan kebugaran (CTL); anaerob dari menit di atas LTHR bila histogram HR ada.")
    } else if (!e.type.equals("bike")) {
        DSection("Training effect dan recovery")
        DCaption("Belum ada data training effect untuk sesi ini. Angka dari jam muncul setelah jam tersinkron.")
    }

    // Training load
    if (sm != null) {
        DSection("Training load", "Skala aplikasi · sumber: ${sm.source}")
        val day = metrics?.days?.firstOrNull { it.date == sm.date }
        EvMetricRow(listOfNotNull("Load sesi" to Js.roundI(sm.load).toString(), sm.watchLoad?.let { "Load jam" to it.toString() }))
        if (day != null) {
            EvMetricRow(listOf("Fitness (CTL)" to Js.roundI(day.fitness).toString(), "Fatigue (ATL)" to Js.roundI(day.fatigue).toString(), "Form" to Js.roundI(day.form).toString()))
            DCaption("Fitness, fatigue, dan form adalah nilai pada hari sesi ini (total semua sesi hari itu).")
        }
        if (sm.watchLoad != null) DCaption("Load jam adalah angka dari Huawei Watch dan tidak sama skalanya dengan load aplikasi.")
    }

    // Recovery
    if (sm != null && sm.recoveryHours > 0) {
        DSection(if (sm.fromWatch && (watchMeta?.optDouble("recoveryHours", 0.0) ?: 0.0) > 0) "Recovery dari jam" else "Recovery")
        val end = runCatching {
            val date = LocalDate.parse(e.dateIso.take(10))
            val t = e.startTime?.let { LocalTime.parse(it) } ?: LocalTime.NOON
            LocalDateTime.of(date, t).plusSeconds(e.durationSec.toLong())
        }.getOrNull()
        val ready = end?.plusSeconds((sm.recoveryHours * 3600).toLong())
        val cells = ArrayList<Pair<String, String>>()
        cells += "Waktu recovery" to ActInsights.recoveryDuration(sm.recoveryHours)
        if (ready != null) cells += "Pulih penuh" to (DAY_SHORT[ready.dayOfWeek.value - 1] + " " + Js.pad(ready.hour) + ":" + Js.pad(ready.minute))
        cells += "Sisa sekarang" to (if (sm.recoveryRemainingHours < 1.0) "Sudah pulih" else ActInsights.recoveryDuration(sm.recoveryRemainingHours))
        EvMetricRow(cells)
        DCaption(if (sm.fromWatch) "Angka recovery jam menggantikan rumus aplikasi untuk sesi ini di pil Recovery dan kartu readiness." else "Perkiraan aplikasi dari load sesi dan kebugaranmu.")
    }

    // Recovery heart rate (dari jam)
    val rawRec = remember(watchMeta) {
        watchMeta?.optJSONArray("recoveryHr")?.let { arr -> (0 until arr.length()).map { arr.optInt(it) } }.orEmpty()
    }
    val rec = remember(rawRec) { ActInsights.recoveryHr(rawRec) }
    if (rec != null) {
        DSection("Recovery heart rate")
        val cells = ArrayList<Pair<String, String>>()
        cells += "HR akhir latihan" to "${rec.base} bpm"
        rec.h1?.let { cells += "HR menit ke-1" to "$it bpm" }
        rec.d1?.let { cells += "Turun 1 menit" to (if (it > 0) "−" else "+") + Math.abs(it) + " bpm" }
        cells.chunked(3).forEach { EvMetricRow(it) }
        if (rec.values.size > 1) {
            EvMetricRow(listOf("HR menit ke-2" to "${rec.h2} bpm", "Turun 2 menit" to ((rec.d2 ?: 0).let { (if (it > 0) "−" else "+") + Math.abs(it) } + " bpm")))
            DRecoveryHrChart(rec)
        }
        DCaption(
            "Penurunan 1 menit di atas 12 bpm umumnya dianggap normal; makin besar umumnya makin baik, tetapi bergantung pada intensitas dan kondisi hari itu. " +
                "Jam Huawei mengukur recovery heart rate selama 2 menit; ${rec.values.size} nilai dari jam dibagi rata sepanjang 2 menit" +
                (if (rec.stepSec > 0) " (sekitar ${ActInsights.dec(rec.stepSec)} detik per nilai)" else "") + " karena jam tidak mencantumkan jaraknya. Bukan penilaian medis.",
        )
    }

    // Easy run
    val lthr = metrics?.lthr ?: Zones.cuts(state.settings).lthr ?: 0
    val easy = remember(state.detailsByActivity, lthr, state.settings.easyRun) {
        if (d?.easyRun?.enabled == true && lthr > 0) EasyRunAnalytics.calculate(state.detailsByActivity, lthr, state.settings.easyRun).firstOrNull { it.activityId == e.id } else null
    }
    if (easy != null) {
        DSection("Evaluasi easy run", if (easy.kind == "long") "Long run" else "Easy run")
        val verdict = when (easy.verdict) { "good" -> "Bagus"; "ok" -> "Cukup"; "hard" -> "Terlalu berat"; else -> "–" }
        EvMetricRow(listOf("Skor" to (easy.score?.toString() ?: "–"), "Kepatuhan HR" to (easy.compliancePct?.let { "%.1f%%".format(it) } ?: "–"), "Hasil" to verdict))
        EvMetricRow(listOf("Drift" to (easy.driftPct?.let { "%.1f%%".format(it) } ?: "–"), "Stabilitas" to (easy.stabilityCv?.let { "%.1f%%".format(it) } ?: "–"), "Di atas batas" to "${Js.roundI(easy.overLimitMinutes)} mnt"))
        DCaption("Dinilai dari ${Js.roundI(easy.evaluatedMinutes)} menit setelah pemanasan" + if (easy.legacyHistogramOnly) " (hanya histogram HR; data lama)." else ".")
    }
}

// ============================ Halaman 3: Per km ============================

@Composable
private fun KmPage(
    state: UiState, e: ActivityEntity, d: ActDetail?, planDay: PDay?, hist: Map<Int, Double>, avgHr: Int?, gain: Int?, km: Double, bike: Boolean,
) {
    val zc = remember(state.settings) { Zones.cuts(state.settings) }
    val compliance = ActInsights.compliance(planDay, km, avgHr, hist, gain, Zones.sessionRefs(zc).first, bike)
    if (compliance != null) {
        DSection("Cek terhadap rencana", compliance.label)
        DCheckList(compliance.items)
    }
    if (d == null || (d.splits.isEmpty() && d.segments.isEmpty())) {
        DSection("Per kilometer")
        DCaption("Belum ada data per kilometer untuk aktivitas ini.")
        return
    }
    val splits = d.splits
    if (splits.isNotEmpty()) {
        DSection("Per kilometer")
        val hasGain = d.gain != null
        val fastest = ActInsights.fastestKm(splits, bike)
        val slowestPace = splits.filter { !it.partial }.maxOfOrNull { it.pace } ?: splits.maxOf { it.pace }
        val fastestPace = splits.filter { it.pace > 0 }.minOfOrNull { it.pace } ?: 1.0
        ActivityAnalytics.compareHalves(splits)?.let { halves ->
            val delta = if (halves.changePercent >= 0) "+%.1f%%".format(halves.changePercent) else "%.1f%%".format(halves.changePercent)
            EvPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Perbandingan paruh", style = MaterialTheme.typography.titleSmall)
                    Text("Awal ${Js.paceStr(halves.firstPace)} · akhir ${Js.paceStr(halves.secondPace)}")
                    Text(
                        if (halves.changePercent > 1.0) "Paruh kedua melambat $delta" else if (halves.changePercent < -1.0) "Paruh kedua lebih cepat $delta" else "Pace kedua paruh relatif stabil ($delta)",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        val drift = ActInsights.drift(splits, km, bike, planDay?.kind in setOf("quality", "sub", "race", "event") || planDay?.bench == true)
        if (drift != null) {
            val lv = if (drift.pct <= 5) "ok" to "stabil" else if (drift.pct <= 8) "info" to "sedang" else "warn" to "tinggi"
            DCheckList(listOf(ActInsights.Check(lv.first, "HR drift ${ActInsights.dec(drift.pct)}% (${lv.second}). Efisiensi pace per detak di paruh akhir dibanding paruh awal. Di bawah 5% berarti stabil; di atas 8% tanda kelelahan, panas, atau dehidrasi.")))
        }
        EvPanel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth()) {
                    val head = MaterialTheme.typography.labelMedium
                    val headColor = MaterialTheme.colorScheme.onSurfaceVariant
                    Text("km", Modifier.weight(.5f), color = headColor, style = head, maxLines = 1)
                    Text(if (bike) "Kecepatan" else "Pace", Modifier.weight(1.1f), color = headColor, style = head, maxLines = 1)
                    Text("HR", Modifier.weight(.6f), color = headColor, style = head, maxLines = 1)
                    Text("Elev. Gain", Modifier.weight(1f), color = headColor, style = head, maxLines = 1, softWrap = false)
                    Text("Elev. Loss", Modifier.weight(1f), color = headColor, style = head, maxLines = 1, softWrap = false)
                }
                splits.forEach { sp ->
                    val isFast = sp === fastest
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(if (sp.partial) fmtKmUi(sp.k) else sp.k.toInt().toString(), Modifier.weight(.5f), fontWeight = FontWeight.SemiBold)
                            Text(
                                if (bike) "${ActInsights.dec(if (sp.pace > 0) 60 / sp.pace else 0.0)} km/j" else Js.paceStr(sp.pace) + "/km", Modifier.weight(1.1f),
                                color = if (isFast) Ember else MaterialTheme.colorScheme.onSurface, fontWeight = if (isFast) FontWeight.Bold else FontWeight.Normal,
                            )
                            Text(sp.hr?.toString() ?: "–", Modifier.weight(.6f))
                            Text("+${sp.gain} m", Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("−${sp.loss} m", Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        // bar pace relatif: lebih panjang = lebih cepat
                        if (!bike && sp.pace > 0 && slowestPace > fastestPace) {
                            val frac = (1.0 - (sp.pace - fastestPace) / (slowestPace - fastestPace) * 0.7).coerceIn(0.25, 1.0).toFloat()
                            Row(Modifier.fillMaxWidth().height(4.dp)) {
                                Box(Modifier.weight(frac).height(4.dp).background(if (isFast) Ember else MaterialTheme.colorScheme.primary.copy(alpha = .45f), RoundedCornerShape(2.dp)))
                                if (frac < 1f) Box(Modifier.weight(1f - frac).height(4.dp))
                            }
                        }
                        val extra = ArrayList<String>()
                        ActInsights.gapOfSplit(sp, hasGain)?.takeIf { it > 0 }?.let { extra += "GAP ${Js.paceStr(it)}" }
                        sp.cad?.takeIf { it > 0 }?.let { extra += "kadens $it" }
                        if (!bike) ActInsights.strideOfSplit(sp)?.let { extra += "langkah " + ActInsights.dec(it, 2) }
                        if (extra.isNotEmpty()) Text(extra.joinToString(" · "), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        if (splits.any { ActInsights.gapOfSplit(it, hasGain) != null }) DCaption("GAP dihitung dari kemiringan tiap segmen jalur (rumus Minetti).")
    }
    if (d.segments.isNotEmpty()) {
        DSection("Per segmen", "Dari lap berkas FIT/jam")
        val fastSeg = ActInsights.fastestSegment(d.segments, bike)
        EvPanel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth()) {
                    listOf("Segmen" to 1.3f, "Jarak" to 1f, "Waktu" to 1f, "Pace" to .9f, "HR" to .7f).forEach { (h, w) ->
                        Text(h, Modifier.weight(w), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
                    }
                }
                d.segments.forEach { s ->
                    val name = if (s.name.matches(Regex("\\d+"))) "Segmen ${s.name}" else s.name
                    Row(Modifier.fillMaxWidth()) {
                        Text(name, Modifier.weight(1.3f), style = MaterialTheme.typography.bodyMedium)
                        Text("${ActInsights.dec(s.d, 2)} km", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        Text(Js.durStr(s.min), Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        Text(Js.paceStr(s.pace), Modifier.weight(.9f), style = MaterialTheme.typography.bodyMedium, color = if (s === fastSeg) Ember else MaterialTheme.colorScheme.onSurface)
                        Text(s.hr?.toString() ?: "–", Modifier.weight(.7f), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
        DCaption("Segmen tercepat diberi warna oranye (segmen di bawah 100 m diabaikan). Penyuntingan tipe segmen belum dimigrasi.")
    }
}
