package com.endurancevault.app.domain

data class HudVideoPrefs(
    val style: String = "two",
    val format: String = "mp4",
    val accent: String = "#FF6A13",
    val showMap: Boolean = true,
    val showGauge: Boolean = true,
    val dim: Int = 25,
    val keepAudio: Boolean = true,
) {
    fun sanitized() = copy(
        style = if (style == "min") "min" else "two",
        format = if (format == "rec") "rec" else "mp4",
        accent = if (accent.matches(Regex("#[0-9a-fA-F]{6}"))) accent.uppercase() else "#FF6A13",
        dim = dim.coerceIn(0,60),
    )
}
