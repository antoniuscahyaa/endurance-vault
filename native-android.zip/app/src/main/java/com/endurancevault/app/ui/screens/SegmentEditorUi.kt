package com.endurancevault.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.endurancevault.app.domain.ActInsights
import com.endurancevault.app.domain.ActivityTimeSeries
import com.endurancevault.app.domain.Js
import com.endurancevault.app.domain.SegKind
import com.endurancevault.app.domain.Segment
import com.endurancevault.app.domain.SegmentSplit
import com.endurancevault.app.ui.theme.Ember
import kotlinx.coroutines.launch

/** Warna jenis segmen; null (tanpa label) memakai warna netral dari tema. */
@Composable
internal fun segKindColor(kind: String?): Color = when (kind) {
    SegKind.REPETITION -> Ember
    SegKind.STRIDE -> DetailBlue
    SegKind.PROGRESSIVE -> DetailGreen
    else -> MaterialTheme.colorScheme.outline
}

/**
 * Satu pill per segmen: jenis (repetisi, stride, progresif) atau "Tanpa label". Bila [onPick] ada, ketukan membuka
 * menu pilihan; null = hanya tampilan.
 */
@Composable
internal fun SegmentKindPill(kind: String?, onPick: ((String?) -> Unit)?) {
    var open by remember { mutableStateOf(false) }
    val c = segKindColor(kind)
    Surface(
        shape = CircleShape,
        color = if (kind != null) c.copy(alpha = .16f) else MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(0.8.dp, if (kind != null) c.copy(alpha = .55f) else MaterialTheme.colorScheme.outlineVariant),
        modifier = if (onPick != null) Modifier.clickable { open = true } else Modifier,
    ) {
        Text(
            SegKind.label(kind) + if (onPick != null) " ▾" else "",
            Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
            style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold,
            color = if (kind != null) c else MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1,
        )
    }
    if (onPick != null) DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
        SegKind.ALL.forEach { k ->
            DropdownMenuItem(text = { Text(SegKind.label(k)) }, onClick = { open = false; onPick(k) })
        }
        if (kind != null) DropdownMenuItem(text = { Text("Hapus label") }, onClick = { open = false; onPick(null) })
    }
}

/** Kecepatan (m/dtk) per titik, dihaluskan 10 dtk, dikurangi ke ±240 titik untuk digambar. */
private fun stripSeries(ts: ActivityTimeSeries): List<Pair<Float, Float>> {
    val t0 = ts.seconds.first(); val d0 = ts.distanceMeters.first()
    val raw = ArrayList<Pair<Float, Float>>()
    var j = 0
    for (i in ts.seconds.indices) {
        while (ts.seconds[i] - ts.seconds[j] > 10) j++
        val dt = ts.seconds[i] - ts.seconds[j]
        if (dt > 0) raw += (ts.seconds[i] - t0).toFloat() to ((ts.distanceMeters[i] - ts.distanceMeters[j]) / dt).toFloat().coerceAtLeast(0f)
    }
    if (raw.size <= 240) return raw
    val step = raw.size / 240.0
    return (0 until 240).map { raw[(it * step).toInt()] } + raw.last()
}

/** Kecepatan sepanjang sesi dengan latar tiap segmen diwarnai menurut jenisnya dan garis batas di antaranya. */
@Composable
private fun SegmentStrip(ts: ActivityTimeSeries, drafts: List<SegmentSplit.Draft>) {
    val series = remember(ts) { stripSeries(ts) }
    val total = SegmentSplit.totalSec(ts).coerceAtLeast(1).toFloat()
    val line = MaterialTheme.colorScheme.onSurface
    val divider = MaterialTheme.colorScheme.outline
    val neutral = MaterialTheme.colorScheme.onSurface.copy(alpha = .05f)
    val colors = drafts.map { k -> if (k.kind == null) neutral else segKindColor(k.kind).copy(alpha = .22f) }
    Canvas(Modifier.fillMaxWidth().height(110.dp).padding(horizontal = 10.dp)) {
        val w = size.width; val h = size.height
        var start = 0f
        drafts.forEachIndexed { i, d ->
            val x0 = start / total * w; val x1 = d.endSec / total * w
            drawRect(colors[i], Offset(x0, 0f), Size((x1 - x0).coerceAtLeast(0f), h))
            if (i > 0) drawLine(divider, Offset(x0, 0f), Offset(x0, h), strokeWidth = 1.dp.toPx())
            start = d.endSec.toFloat()
        }
        if (series.size >= 2) {
            val hi = series.maxOf { it.second }.coerceAtLeast(0.5f)
            val pad = 8.dp.toPx()
            val path = Path()
            series.forEachIndexed { i, p ->
                val o = Offset(p.first / total * w, h - pad - p.second / hi * (h - 2 * pad))
                if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y)
            }
            drawPath(path, line, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}

private fun paceText(bike: Boolean, pace: Double?): String =
    if (pace == null || pace <= 0) "–" else if (bike) ActInsights.dec(60 / pace) + " km/j" else Js.paceStr(pace) + "/km"

/**
 * Editor pembagian segmen manual. Batas segmen bisa diketik dalam waktu (m:ss) atau jarak (km), digeser per langkah,
 * dipisah di tengah, atau digabung dengan segmen berikutnya. Tiap segmen diberi jenis (repetisi, stride, progresif).
 * [onSave] menerima segmen dan mengembalikan null bila berhasil atau pesan galat.
 */
@Composable
internal fun SegmentEditor(
    ts: ActivityTimeSeries, existing: List<Segment>,
    onSave: suspend (List<SegmentSplit.Draft>) -> String?,
    onClose: () -> Unit,
) {
    val total = remember(ts) { SegmentSplit.totalSec(ts) }
    val initial = remember(ts, existing) {
        SegmentSplit.draftsFromSegments(ts, existing) ?: listOf(SegmentSplit.Draft(total, null))
    }
    var drafts by remember { mutableStateOf(initial) }
    var rev by remember { mutableStateOf(0) }          // naik tiap perubahan non-ketik, supaya isian teks disegarkan
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val stats = remember(ts, drafts) { SegmentSplit.stats(ts, drafts) }
    val problem = SegmentSplit.validate(ts, drafts)

    fun replace(i: Int, d: SegmentSplit.Draft) { drafts = drafts.toMutableList().also { it[i] = d } }
    fun startOf(i: Int) = if (i == 0) 0 else drafts[i - 1].endSec
    fun nudgeEnd(i: Int, deltaSec: Int, deltaM: Double) {
        val cur = drafts[i].endSec
        val target = if (drafts[i].byDistance) SegmentSplit.secAtMeters(ts, (SegmentSplit.metersAt(ts, cur) + deltaM).coerceAtLeast(0.0)) else cur + deltaSec
        val lo = startOf(i) + SegmentSplit.MIN_SEG_SEC; val hi = drafts[i + 1].endSec - SegmentSplit.MIN_SEG_SEC
        val next = target.coerceIn(lo, hi.coerceAtLeast(lo))
        if (next in lo..hi && next != cur) { replace(i, SegmentSplit.Draft(next, drafts[i].kind, drafts[i].byDistance)); rev++ }
    }

    Text("Bagi segmen", style = MaterialTheme.typography.titleMedium)
    DCaption(
        "Tentukan panjang tiap segmen dalam waktu atau jarak, boleh dicampur (mis. repetisi 400 m, jeda 90 dtk), lalu beri jenisnya: " +
            "repetisi, stride, atau progresif. Pace, HR, kadens, dan elevasi tiap segmen dihitung dari data per detik.",
    )
    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(vertical = 12.dp, horizontal = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            SegmentStrip(ts, drafts)
            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("0:00", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    "${SegmentSplit.fmtSeconds(total)} · ${trimNum(ts.distanceMeters.let { it.last() - it.first() } / 1000.0, 2)} km",
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
    drafts.forEachIndexed { i, d ->
        val st = stats[i]
        val isLast = i == drafts.lastIndex
        EvPanel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Segmen ${i + 1}", style = MaterialTheme.typography.titleSmall)
                    Text(
                        "${trimNum(st.km, 2)} km · ${Js.durStr(st.seconds / 60.0)} · ${paceText(false, st.pace)}" + (st.avgHr?.let { " · HR $it" } ?: ""),
                        style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SegKind.ALL.forEach { k ->
                        FilterChip(
                            selected = d.kind == k,
                            onClick = { replace(i, SegmentSplit.Draft(d.endSec, if (d.kind == k) null else k, d.byDistance)) },
                            label = { Text(SegKind.label(k), maxLines = 1) },
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = !d.byDistance, onClick = { replace(i, SegmentSplit.Draft(d.endSec, d.kind, false)); rev++ }, label = { Text("Waktu") })
                    FilterChip(selected = d.byDistance, onClick = { replace(i, SegmentSplit.Draft(d.endSec, d.kind, true)); rev++ }, label = { Text("Jarak") })
                }
                val byDist = d.byDistance
                val start = startOf(i)
                val shown = if (byDist) Math.round(st.meters).toString() else SegmentSplit.fmtSeconds(st.seconds)
                var text by remember(rev, byDist, i, drafts.size) { mutableStateOf(shown) }
                val lo = start + SegmentSplit.MIN_SEG_SEC
                val hi = if (isLast) total else drafts[i + 1].endSec - SegmentSplit.MIN_SEG_SEC
                fun endFor(v: String): Int? =
                    if (byDist) SegmentSplit.parseMeters(v)?.let { SegmentSplit.secAtMeters(ts, SegmentSplit.metersAt(ts, start) + it) }
                    else SegmentSplit.parseSeconds(v)?.let { start + it }
                val parsed: Int? = if (isLast) total else endFor(text)
                val bad = !isLast && (parsed == null || parsed !in lo..hi)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = text,
                        onValueChange = { v ->
                            text = v
                            val sec = endFor(v)
                            if (sec != null && sec in lo..hi) replace(i, SegmentSplit.Draft(sec, drafts[i].kind, drafts[i].byDistance))
                        },
                        enabled = !isLast, isError = bad, singleLine = true,
                        label = { Text(if (isLast) "Panjang (sisa sesi)" else if (byDist) "Panjang segmen (m)" else "Panjang segmen (m:ss)") },
                        modifier = Modifier.weight(1f),
                    )
                    if (!isLast) {
                        OutlinedButton({ nudgeEnd(i, -5, -50.0) }) { Text(if (byDist) "−50 m" else "−5 dtk", maxLines = 1) }
                        OutlinedButton({ nudgeEnd(i, 5, 50.0) }) { Text(if (byDist) "+50 m" else "+5 dtk", maxLines = 1) }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    val mid = (startOf(i) + d.endSec) / 2
                    TextButton(
                        enabled = mid - startOf(i) >= SegmentSplit.MIN_SEG_SEC && d.endSec - mid >= SegmentSplit.MIN_SEG_SEC,
                        onClick = {
                            val l = drafts.toMutableList()
                            l[i] = SegmentSplit.Draft(mid, d.kind, d.byDistance); l.add(i + 1, SegmentSplit.Draft(d.endSec, d.kind, d.byDistance))
                            drafts = l; rev++
                        },
                    ) { Text("Pisah di tengah") }
                    if (!isLast) TextButton(onClick = {
                        val l = drafts.toMutableList()
                        l[i] = SegmentSplit.Draft(l[i + 1].endSec, d.kind, d.byDistance); l.removeAt(i + 1)
                        drafts = l; rev++
                    }) { Text("Gabung ke berikutnya") }
                }
            }
        }
    }

    (error ?: problem)?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    DCaption("Pembagian hanya menambah rincian segmen; jarak, waktu, dan statistik sesi utuh tidak berubah.")
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = onClose, enabled = !busy, modifier = Modifier.weight(1f)) { Text("Batal") }
        Button(
            enabled = !busy && problem == null, modifier = Modifier.weight(1f),
            onClick = {
                busy = true; error = null
                // Satu segmen tanpa label sama dengan tidak ada pembagian.
                val toSave = if (drafts.size == 1 && drafts[0].kind == null) emptyList() else drafts
                scope.launch {
                    val err = onSave(toSave)
                    busy = false
                    if (err == null) onClose() else error = err
                }
            },
        ) { Text(if (busy) "Menyimpan…" else "Simpan segmen") }
    }
    if (existing.isNotEmpty()) TextButton(onClick = { confirmClear = true }, enabled = !busy) {
        Text("Hapus semua segmen", color = MaterialTheme.colorScheme.error)
    }
    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false },
        title = { Text("Hapus semua segmen?") },
        text = { Text("Daftar segmen (termasuk lap dari jam atau berkas FIT) dihapus dari aktivitas ini. Data per detik dan statistik sesi tidak berubah.") },
        confirmButton = {
            TextButton(onClick = {
                confirmClear = false; busy = true; error = null
                scope.launch {
                    val err = onSave(emptyList())
                    busy = false
                    if (err == null) onClose() else error = err
                }
            }) { Text("Hapus", color = MaterialTheme.colorScheme.error) }
        },
        dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Batal") } },
    )
}
