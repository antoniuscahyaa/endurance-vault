package com.endurancevault.app.data

import com.endurancevault.app.domain.CourseStrategy.Pt
import com.endurancevault.app.domain.ExPlace
import com.endurancevault.app.domain.ExRoute
import com.endurancevault.app.domain.ExploreGeo
import com.endurancevault.app.domain.RouteGeo
import android.content.Context
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * Penyimpanan rute dan lokasi Explore sebagai JSON di tabel kv (kunci [ROUTES_KEY] dan [PLACES_KEY]),
 * sehingga otomatis ikut cadangan dan pemulihan data aplikasi.
 */
object ExploreStore {
    const val ROUTES_KEY = "explore.routes"
    const val PLACES_KEY = "explore.places"
    /** Pasangan tanggal sesi → id rute (rute dipasang ke sesi latihan). */
    const val LINKS_KEY = "explore.links"
    /** Pasangan id rute → waktu (ms) terakhir terkirim ke jam. */
    const val SENT_KEY = "explore.sent"

    fun parseStringMap(json: String?): Map<String, String> {
        val o = runCatching { JSONObject(json ?: "{}") }.getOrNull() ?: return emptyMap()
        val out = LinkedHashMap<String, String>()
        o.keys().forEach { k -> out[k] = o.optString(k) }
        return out
    }

    fun stringMapToJson(m: Map<String, String>): String {
        val o = JSONObject()
        m.forEach { (k, v) -> o.put(k, v) }
        return o.toString()
    }

    fun parseLongMap(json: String?): Map<String, Long> {
        val o = runCatching { JSONObject(json ?: "{}") }.getOrNull() ?: return emptyMap()
        val out = LinkedHashMap<String, Long>()
        o.keys().forEach { k -> out[k] = o.optLong(k) }
        return out
    }

    fun longMapToJson(m: Map<String, Long>): String {
        val o = JSONObject()
        m.forEach { (k, v) -> o.put(k, v) }
        return o.toString()
    }

    fun parseRoutes(json: String?): List<ExRoute> {
        val arr = runCatching { JSONArray(json ?: "[]") }.getOrNull() ?: return emptyList()
        val out = ArrayList<ExRoute>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val p = o.optJSONArray("p") ?: continue
            val pts = ArrayList<Pt>(p.length())
            for (j in 0 until p.length()) {
                val q = p.optJSONArray(j) ?: continue
                val e = if (q.length() > 2 && !q.isNull(2)) q.optDouble(2).takeIf { it.isFinite() } else null
                pts.add(Pt(q.optDouble(0), q.optDouble(1), e))
            }
            if (pts.size < 2) continue
            val ai = o.optJSONArray("ai")
            val idx = if (ai == null) listOf(0, pts.size - 1) else (0 until ai.length()).map { ai.optInt(it).coerceIn(0, pts.size - 1) }
            out.add(
                ExRoute(
                    o.optString("id"), o.optString("name", "Rute"), o.optString("mode", "run"), o.optString("src", "app"),
                    o.optLong("t"), pts, idx,
                ),
            )
        }
        return out
    }

    fun routesToJson(list: List<ExRoute>): String {
        val arr = JSONArray()
        for (r in list) {
            val p = JSONArray()
            for (pt in r.pts) {
                val q = JSONArray().put(Math.round(pt.lat * 1e5) / 1e5).put(Math.round(pt.lon * 1e5) / 1e5)
                val e = pt.ele
                if (e != null && e.isFinite()) q.put(Math.round(e * 10) / 10.0) else q.put(JSONObject.NULL)
                p.put(q)
            }
            arr.put(
                JSONObject().put("id", r.id).put("name", r.name).put("mode", r.mode).put("src", r.source).put("t", r.createdMs)
                    .put("ai", JSONArray(r.anchorIdx)).put("p", p),
            )
        }
        return arr.toString()
    }

    fun parsePlaces(json: String?): List<ExPlace> {
        val arr = runCatching { JSONArray(json ?: "[]") }.getOrNull() ?: return emptyList()
        val out = ArrayList<ExPlace>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(ExPlace(o.optString("id"), o.optString("name", "Lokasi"), o.optDouble("lat"), o.optDouble("lon")))
        }
        return out
    }

    fun placesToJson(list: List<ExPlace>): String {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("name", it.name).put("lat", it.lat).put("lon", it.lon)) }
        return arr.toString()
    }
}

/**
 * Menempelkan jalur ke jalan/jalur yang ada. Dua penyedia (data OpenStreetMap, layanan gratis dengan batas wajar):
 * - "osrm": OSRM FOSSGIS (routing.openstreetmap.de), profil kaki dan sepeda.
 * - "brouter": BRouter (brouter.de), profil trekking untuk lari dan fastbike untuk sepeda; lebih paham jalur setapak/gunung.
 * [leg] mencoba penyedia pilihan, lalu yang satunya; null bila keduanya gagal (pemanggil memakai garis lurus).
 */
object ExploreRouting {
    private const val USER_AGENT = "EnduranceVault/0.5.75 (Android; personal fitness route planner)"

    suspend fun leg(mode: String, from: RouteGeo.LatLon, to: RouteGeo.LatLon, provider: String = "osrm"): List<Pt>? {
        val order = if (provider == "brouter") listOf("brouter", "osrm") else listOf("osrm", "brouter")
        for (p in order) {
            val r = if (p == "brouter") brouter(mode, from, to) else osrm(mode, from, to)
            if (r != null) return r
        }
        return null
    }

    private suspend fun osrm(mode: String, from: RouteGeo.LatLon, to: RouteGeo.LatLon): List<Pt>? = withContext(Dispatchers.IO) {
        val profile = if (mode == "ride") "routed-bike" else "routed-foot"
        val url = "https://routing.openstreetmap.de/$profile/route/v1/driving/" +
            String.format(Locale.ROOT, "%.6f,%.6f;%.6f,%.6f", from.lon, from.lat, to.lon, to.lat) +
            "?overview=full&geometries=geojson&steps=false"
        val j = getJson(url) ?: return@withContext null
        try {
            if (j.optString("code") != "Ok") return@withContext null
            parseCoords(j.getJSONArray("routes").getJSONObject(0).getJSONObject("geometry").getJSONArray("coordinates"))
        } catch (_: Exception) { null }
    }

    private suspend fun brouter(mode: String, from: RouteGeo.LatLon, to: RouteGeo.LatLon): List<Pt>? = withContext(Dispatchers.IO) {
        val profile = if (mode == "ride") "fastbike" else "trekking"
        val url = "https://brouter.de/brouter?lonlats=" +
            String.format(Locale.ROOT, "%.6f,%.6f|%.6f,%.6f", from.lon, from.lat, to.lon, to.lat) +
            "&profile=$profile&alternativeidx=0&format=geojson"
        val j = getJson(url) ?: return@withContext null
        try {
            parseCoords(j.getJSONArray("features").getJSONObject(0).getJSONObject("geometry").getJSONArray("coordinates"))
        } catch (_: Exception) { null }
    }

    /** Koordinat GeoJSON [lon, lat(, ele)]; elevasi diabaikan (diisi ulang dari model elevasi agar konsisten). */
    private fun parseCoords(c: JSONArray): List<Pt>? {
        val out = ArrayList<Pt>(c.length())
        for (i in 0 until c.length()) {
            val q = c.getJSONArray(i)
            out.add(Pt(q.getDouble(1), q.getDouble(0), null))
        }
        return if (out.size >= 2) out else null
    }

    private fun getJson(url: String): JSONObject? {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8_000; readTimeout = 15_000
                setRequestProperty("User-Agent", USER_AGENT)
            }
            if (conn.responseCode != 200) null else JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
        } catch (_: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }
}

/**
 * Peta offline: mengunduh ubin di sepanjang rute (koridor ±1 ubin, zoom 12–16, dibatasi [MAX_TILES]) ke cache disk
 * [MapTiles] untuk gaya peta terpilih. Sengaja hanya koridor rute, bukan seluruh area: server ubin publik membatasi
 * pengunduhan massal. Unduhan berurutan dengan jeda kecil.
 */
object ExploreTiles {
    const val MAX_TILES = 1200

    fun corridor(pts: List<Pt>, style: MapStyle): List<RouteGeo.TileId> {
        if (pts.size < 2) return emptyList()
        val set = LinkedHashSet<RouteGeo.TileId>()
        for (z in 12..minOf(16, style.maxNative)) {
            val n = 1 shl z
            val step = maxOf(1, pts.size / 1500)
            var i = 0
            while (i < pts.size) {
                val p = pts[i]
                val tx = (RouteGeo.worldX(p.lon, z) / RouteGeo.TILE).toInt()
                val ty = (RouteGeo.worldY(p.lat, z) / RouteGeo.TILE).toInt()
                for (dx in -1..1) for (dy in -1..1) {
                    val x = tx + dx; val y = ty + dy
                    if (x in 0 until n && y in 0 until n) set.add(RouteGeo.TileId(z, x, y))
                }
                i += step
            }
            // titik terakhir selalu ikut
            val q = pts.last()
            val lx = (RouteGeo.worldX(q.lon, z) / RouteGeo.TILE).toInt(); val ly = (RouteGeo.worldY(q.lat, z) / RouteGeo.TILE).toInt()
            if (lx in 0 until n && ly in 0 until n) set.add(RouteGeo.TileId(z, lx, ly))
        }
        // terlalu banyak: buang zoom tertinggi dulu
        var list = set.toList()
        var zMax = minOf(16, style.maxNative)
        while (list.size > MAX_TILES && zMax > 12) { zMax--; list = list.filter { it.z <= zMax } }
        return list
    }

    /**
     * Semua ubin zoom 11..15 di kotak sekitar [pts] (diperlebar [padKm] ke tiap sisi), untuk dipakai tanpa sinyal di area gunung.
     * Zoom tertinggi dikurangi bila jumlah ubin melewati [maxTiles].
     */
    fun area(pts: List<Pt>, style: MapStyle, padKm: Double = 3.0, maxTiles: Int = 2500): List<RouteGeo.TileId> {
        if (pts.isEmpty()) return emptyList()
        val lat0 = pts.minOf { it.lat } - padKm / 111.0
        val lat1 = pts.maxOf { it.lat } + padKm / 111.0
        val lonPad = padKm / (111.0 * Math.cos(Math.toRadians((lat0 + lat1) / 2)).coerceAtLeast(0.05))
        val lon0 = pts.minOf { it.lon } - lonPad
        val lon1 = pts.maxOf { it.lon } + lonPad
        val out = ArrayList<RouteGeo.TileId>()
        for (z in 11..minOf(15, style.maxNative)) {
            val n = 1 shl z
            val x0 = (RouteGeo.worldX(lon0, z) / RouteGeo.TILE).toInt().coerceIn(0, n - 1)
            val x1 = (RouteGeo.worldX(lon1, z) / RouteGeo.TILE).toInt().coerceIn(0, n - 1)
            val y0 = (RouteGeo.worldY(lat1, z) / RouteGeo.TILE).toInt().coerceIn(0, n - 1)
            val y1 = (RouteGeo.worldY(lat0, z) / RouteGeo.TILE).toInt().coerceIn(0, n - 1)
            if (out.size + (x1 - x0 + 1) * (y1 - y0 + 1) > maxTiles) break
            for (x in x0..x1) for (y in y0..y1) out.add(RouteGeo.TileId(z, x, y))
        }
        return out
    }

    /** Unduh [tiles]; [onProgress] dipanggil dengan (selesai, total). Mengembalikan jumlah ubin yang gagal. */
    suspend fun download(context: Context, tiles: List<RouteGeo.TileId>, style: MapStyle, onProgress: (Int, Int) -> Unit): Int {
        var failed = 0
        tiles.forEachIndexed { i, t ->
            val bmp = MapTiles.load(context, t, style)
            if (bmp == null) failed++
            onProgress(i + 1, tiles.size)
            kotlinx.coroutines.delay(40)
        }
        return failed
    }
}

/**
 * Elevasi rute dari model elevasi digital Open-Meteo (Copernicus DEM 90 m, hingga 100 titik per permintaan).
 * Disampel tiap ±[STEP_M] meter di sepanjang jalur (dibatasi [MAX_SAMPLES]), diinterpolasi untuk titik lain,
 * lalu dihaluskan ringan agar derau DEM tidak menggelembungkan total naik. Hasil disimpan di cache memori per koordinat.
 */
object ExploreElevation {
    private const val STEP_M = 50.0
    private const val MAX_SAMPLES = 600
    private val cache = java.util.concurrent.ConcurrentHashMap<String, Double>()

    private fun key(p: Pt) = String.format(Locale.ROOT, "%.4f,%.4f", p.lat, p.lon)

    /** Elevasi sejajar dengan [pts]; null bila layanan tidak terjangkau (offline). */
    suspend fun fetch(pts: List<Pt>): List<Double?>? = withContext(Dispatchers.IO) {
        if (pts.size < 2) return@withContext null
        // indeks sampel: titik pertama, lalu tiap kelipatan STEP_M (atau lebih renggang bila terlalu panjang), dan titik terakhir
        val total = ExploreGeo.length(pts)
        val step = maxOf(STEP_M, total / MAX_SAMPLES)
        val idx = ArrayList<Int>()
        idx.add(0)
        var acc = 0.0
        var next = step
        for (i in 1 until pts.size) {
            acc += ExploreGeo.dist(pts[i - 1], pts[i])
            if (acc >= next) { idx.add(i); next = acc + step }
        }
        if (idx.last() != pts.size - 1) idx.add(pts.size - 1)

        val missing = idx.filter { cache[key(pts[it])] == null }.distinctBy { key(pts[it]) }
        for (chunk in missing.chunked(100)) {
            val lat = chunk.joinToString(",") { String.format(Locale.ROOT, "%.5f", pts[it].lat) }
            val lon = chunk.joinToString(",") { String.format(Locale.ROOT, "%.5f", pts[it].lon) }
            val got = request(lat, lon, chunk.size) ?: return@withContext null
            chunk.forEachIndexed { k, i -> cache[key(pts[i])] = got[k] }
        }
        val raw = idx.map { cache[key(pts[it])] ?: return@withContext null }
        // penghalusan jendela 3 titik pada sampel (ujung dipertahankan)
        val smooth = raw.mapIndexed { i, v ->
            if (i == 0 || i == raw.lastIndex) v else (raw[i - 1] + v * 2 + raw[i + 1]) / 4.0
        }
        // interpolasi linear menurut jarak untuk titik di antara sampel
        val cum = DoubleArray(pts.size)
        for (i in 1 until pts.size) cum[i] = cum[i - 1] + ExploreGeo.dist(pts[i - 1], pts[i])
        val out = arrayOfNulls<Double>(pts.size)
        for (s in 0 until idx.size - 1) {
            val a = idx[s]; val b = idx[s + 1]
            val span = cum[b] - cum[a]
            for (i in a..b) {
                val f = if (span > 0) (cum[i] - cum[a]) / span else 0.0
                out[i] = smooth[s] + (smooth[s + 1] - smooth[s]) * f
            }
        }
        out.toList()
    }

    private fun request(lat: String, lon: String, n: Int): List<Double>? {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL("https://api.open-meteo.com/v1/elevation?latitude=$lat&longitude=$lon").openConnection() as HttpURLConnection).apply {
                connectTimeout = 8_000; readTimeout = 12_000
                setRequestProperty("User-Agent", "EnduranceVault/0.5.75 (Android; personal fitness route planner)")
            }
            if (conn.responseCode != 200) return null
            val arr = JSONObject(conn.inputStream.bufferedReader().use { it.readText() }).getJSONArray("elevation")
            if (arr.length() != n) null else (0 until n).map { arr.getDouble(it) }
        } catch (_: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }
}
