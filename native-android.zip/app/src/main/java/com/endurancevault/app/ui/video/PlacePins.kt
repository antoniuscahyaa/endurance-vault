package com.endurancevault.app.ui.video

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import kotlin.math.acos
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Pin nama daerah di layar. [x],[y] = titik tanah (ujung pin) dalam piksel bingkai; [scale] = skala perspektif (jauh = kecil);
 * [alpha] = keterlihatan (0..1: memudar saat tertutup relief, di tepi bingkai, atau belum waktunya muncul).
 */
class ScreenPlace(val name: String, val x: Float, val y: Float, val scale: Float, val alpha: Float)

/**
 * Menggambar pin bergaya 3D untuk nama daerah: bayangan lonjong di tanah (menempel ke medan), pin tetesan dengan gradasi
 * berkilau, dan label kecil berhalo tipis di sampingnya (tanpa kotak, supaya tidak tampak seperti tempelan). Label menghindari
 * area yang diberikan ([avoid]) dan pin lain; yang tidak mendapat tempat dilewati, bukan ditumpuk.
 */
object PlacePins {
    // Pratinjau (thread UI/GL pratinjau) dan render video berjalan bersamaan, jadi tiap thread punya Paint dan Path sendiri.
    private val paintTL = ThreadLocal.withInitial { Paint(Paint.ANTI_ALIAS_FLAG) }
    private val pathTL = ThreadLocal.withInitial { Path() }
    private val paint: Paint get() = paintTL.get()!!
    private val path: Path get() = pathTL.get()!!

    private fun ca(c: Int, a: Float): Int = Color.argb((Color.alpha(c) * a.coerceIn(0f, 1f)).roundToInt(), Color.red(c), Color.green(c), Color.blue(c))

    private fun mix(c: Int, to: Int, t: Float): Int = Color.rgb(
        (Color.red(c) + (Color.red(to) - Color.red(c)) * t).roundToInt(),
        (Color.green(c) + (Color.green(to) - Color.green(c)) * t).roundToInt(),
        (Color.blue(c) + (Color.blue(to) - Color.blue(c)) * t).roundToInt(),
    )

    private fun lum(c: Int): Float = (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f

    /**
     * Gambar [items] (urut prioritas) dan kembalikan kotak yang terpakai. [u] = satuan skala (sisi pendek 1080 px = 1);
     * ukuran huruf sengaja kecil (±18 u) dan lebih kecil dari label bendera.
     */
    fun draw(c: Canvas, items: List<ScreenPlace>, w: Int, h: Int, u: Float, accent: Int, face: Typeface, avoid: List<RectF>): List<RectF> {
        val placed = ArrayList<RectF>()
        for (pl in items) {
            if (pl.alpha < 0.03f) continue
            val s = pl.scale
            val r = 10.5f * u * s            // jari-jari kepala pin
            val tipToCenter = 31f * u * s    // tinggi pin
            val ts = max(13f * u, 18.5f * u * s)
            val gap = 6f * u * s
            val label = fit(pl.name, ts, face, 300f * u)
            val tw = measure(label, ts, face)
            val cx = pl.x; val cy = pl.y - tipToCenter
            val textTop = cy - ts * 0.62f

            // Label di kanan pin; bila tidak muat atau bertabrakan, coba di kiri.
            var right = true
            var box: RectF? = null
            for (side in 0..1) {
                val onRight = side == 0
                val x0 = if (onRight) cx + r + gap else cx - r - gap - tw
                val b = RectF(min(cx - r, x0) - 3f * u, min(cy - r, textTop) - 2f * u, max(cx + r, x0 + tw) + 3f * u, pl.y + 4f * u * s)
                if (b.left < 0 || b.right > w || b.top < 0 || b.bottom > h) continue
                if (avoid.any { a -> RectF.intersects(a, b) } || placed.any { a -> RectF.intersects(a, b) }) continue
                box = b; right = onRight; break
            }
            if (box == null) continue
            placed.add(box)
            val a = pl.alpha

            // 1) Bayangan di tanah: lingkaran berpendar yang dipipihkan jadi lonjong (kamera miring), supaya pin tampak berdiri di medan.
            val sr = 12f * u * s
            c.save(); c.scale(1f, 0.36f, pl.x, pl.y)
            paint.reset(); paint.isAntiAlias = true
            paint.shader = RadialGradient(pl.x, pl.y, sr, intArrayOf(ca(Color.BLACK, 0.5f * a), ca(Color.BLACK, 0f)), null, Shader.TileMode.CLAMP)
            c.drawCircle(pl.x, pl.y, sr, paint)
            paint.shader = null
            c.restore()

            // 2) Badan pin (tetesan): ujung di titik tanah, kepala bulat di atasnya.
            val ang = acos((r / tipToCenter).coerceIn(0f, 0.99f))   // sudut garis singgung dari sumbu bawah
            val deg = Math.toDegrees(ang.toDouble()).toFloat()
            val sinA = sin(ang)
            val cosA = cos(ang)
            path.reset()
            path.moveTo(cx, pl.y)
            path.lineTo(cx - r * sinA, cy + r * cosA)
            path.arcTo(RectF(cx - r, cy - r, cx + r, cy + r), 90f + deg, 360f - 2f * deg, false)
            path.close()
            val dark = mix(accent, Color.BLACK, 0.5f); val light = mix(accent, Color.WHITE, 0.55f)
            paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.FILL
            paint.setShadowLayer(3.5f * u * s, 0f, 2f * u * s, ca(Color.BLACK, 0.45f * a))
            paint.shader = RadialGradient(
                cx - 0.35f * r, cy - 0.42f * r, r * 1.75f,
                intArrayOf(ca(light, a), ca(accent, a), ca(dark, a)), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP,
            )
            c.drawPath(path, paint)
            paint.shader = null; paint.clearShadowLayer()
            paint.style = Paint.Style.STROKE; paint.strokeWidth = max(1f, 1.3f * u * s); paint.color = ca(Color.BLACK, 0.4f * a)
            c.drawPath(path, paint)

            // 3) Lubang di kepala pin, dengan bayangan kecil di sisi atas supaya tampak cekung.
            val inner = if (lum(accent) > 0.82f) 0xFF222222.toInt() else Color.WHITE
            paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.FILL
            paint.color = ca(Color.BLACK, 0.35f * a); c.drawCircle(cx, cy - 0.5f * u * s, r * 0.44f, paint)
            paint.color = ca(inner, 0.96f * a); c.drawCircle(cx, cy + 0.6f * u * s, r * 0.40f, paint)

            // 4) Kilau di kiri atas kepala.
            c.save(); c.rotate(-35f, cx - 0.5f * r, cy - 0.58f * r)
            paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.FILL; paint.color = ca(Color.WHITE, 0.55f * a)
            c.drawOval(RectF(cx - 0.5f * r - 0.3f * r, cy - 0.58f * r - 0.17f * r, cx - 0.5f * r + 0.3f * r, cy - 0.58f * r + 0.17f * r), paint)
            c.restore()

            // 5) Label: halo gelap tipis lalu isi putih; tanpa kotak.
            val tx = if (right) cx + r + gap else cx - r - gap
            val ty = cy + ts * 0.34f
            paint.reset(); paint.isAntiAlias = true; paint.typeface = face; paint.textSize = ts
            paint.textAlign = if (right) Paint.Align.LEFT else Paint.Align.RIGHT
            paint.letterSpacing = 0.02f
            paint.style = Paint.Style.STROKE; paint.strokeWidth = max(2f, 3.4f * u * s); paint.strokeJoin = Paint.Join.ROUND
            paint.color = ca(Color.BLACK, 0.55f * a); c.drawText(label, tx, ty, paint)
            paint.style = Paint.Style.FILL; paint.color = ca(Color.WHITE, a)
            c.drawText(label, tx, ty, paint)
        }
        return placed
    }

    private fun measure(s: String, px: Float, face: Typeface): Float {
        paint.reset(); paint.isAntiAlias = true; paint.typeface = face; paint.textSize = px; paint.letterSpacing = 0.02f
        return paint.measureText(s)
    }

    private fun fit(s: String, px: Float, face: Typeface, maxW: Float): String {
        if (measure(s, px, face) <= maxW) return s
        var t = s
        while (t.length > 1 && measure("$t…", px, face) > maxW) t = t.dropLast(1)
        return "$t…"
    }
}
