package com.endurancevault.app.ui.video

import android.content.Context
import com.endurancevault.app.domain.HudPrefs
import com.endurancevault.app.domain.TrailPrefs

/** Penyimpanan pengaturan video Trail 3D. */
class TrailPrefsStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("trail_video_prefs", Context.MODE_PRIVATE)
    fun load(): TrailPrefs = TrailPrefs.fromJson(sp.getString("json", null))
    fun save(p: TrailPrefs) { sp.edit().putString("json", p.sanitized().toJson()).apply() }
}

/** Penyimpanan pengaturan video HUD. */
class HudPrefsStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("hud_video_prefs", Context.MODE_PRIVATE)
    fun load(): HudPrefs = HudPrefs.fromJson(sp.getString("json", null))
    fun save(p: HudPrefs) { sp.edit().putString("json", p.sanitized().toJson()).apply() }
}
