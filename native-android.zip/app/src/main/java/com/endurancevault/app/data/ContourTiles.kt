package com.endurancevault.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.util.LruCache
import com.endurancevault.app.domain.RouteGeo.TileId
import java.io.ByteArrayOutputStream
import kotlin.math.PI
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Peta kontur untuk mendaki. Satu ubin dirender di perangkat dari ubin elevasi Terrarium (AWS Terrain Tiles, tanpa kunci API,
 * cache yang sama dengan video rute 3D): tinta ketinggian lembut, bayangan relief, garis kontur tipis (interval menurut zoom)
 * dan garis indeks tebal tiap 5 interval bertuliskan ketinggian (m). Laut (elevasi ≤ 0) berwarna biru muda.
 *
 * Hasil berupa bitmap 512x512 (dua kali ubin biasa, supaya garis tetap tajam saat diperbesar) yang disimpan ke cache disk
 * oleh [MapTiles]. Sungai, jalan, dan nama puncak tidak ada di gaya ini (data elevasi saja); rute Anda tetap digambar di atasnya.
 */
object ContourTiles {
    private const val DEM_MAX_Z = 15
    private const val RES = 512
    private const val GRID = 256
    private const val N = GRID + 1

    private val demCache = object : LruCache<String, FloatArray>(12 * 1024) { // KB
        override fun sizeOf(key: String, value: FloatArray): Int = value.size * 4 / 1024
    }

    private fun dem(ctx: Context, z: Int, x: Int, y: Int): FloatArray? {
        val k = "$z/$x/$y"
        demCache.get(k)?.let { return it }
        val px = TerrariumTiles.load(ctx, z, x, y) ?: return null
        val out = FloatArray(px.size) { i ->
            val p = px[i]
            ((p shr 16) and 255) * 256f + ((p shr 8) and 255) + (p and 255) / 256f - 32768f
        }
        demCache.put(k, out)
        return out
    }

    /** Interval garis kontur (m) untuk zoom [z]; garis indeks tiap 5 interval. */
    fun intervalFor(z: Int): Double = when {
        z <= 9 -> 200.0
        z <= 11 -> 100.0
        z <= 13 -> 50.0
        z == 14 -> 25.0
        z == 15 -> 25.0
        else -> 12.5
    }

    /** PNG ubin kontur, atau null bila ubin elevasi tidak bisa dimuat (offline dan belum ada di cache). */
    fun render(ctx: Context, t: TileId): ByteArray? {
        val grid = sampleGrid(ctx, t) ?: return null
        val bmp = draw(grid, t)
        val out = ByteArrayOutputStream(96 * 1024)
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        bmp.recycle()
        return out.toByteArray()
    }

    /** Grid tinggi (N x N titik, tepi ke tepi ubin) dari ubin elevasi; null bila ada ubin elevasi yang tidak tersedia. */
    private fun sampleGrid(ctx: Context, t: TileId): FloatArray? {
        val f = max(0, t.z - DEM_MAX_Z)
        val dz = t.z - f
        val scale = (1 shl f).toDouble()
        val ox = t.x * 256.0 / scale
        val oy = t.y * 256.0 / scale
        val gx0 = floor(ox / 256.0).toInt()
        val gy0 = floor(oy / 256.0).toInt()
        val world = 1 shl dz
        val tiles = arrayOfNulls<FloatArray>(4)
        for (dy in 0..1) for (dx in 0..1) {
            val tx = Math.floorMod(gx0 + dx, world)
            val ty = (gy0 + dy).coerceIn(0, world - 1)
            tiles[dy * 2 + dx] = dem(ctx, dz, tx, ty) ?: return null
        }
        // piksel elevasi pada koordinat piksel dunia (px, py) relatif ke ubin elevasi (gx0, gy0); batas ubin kedua diklem
        fun pix(px: Int, py: Int): Float {
            val tx = (px shr 8).coerceIn(0, 1)
            val ty = (py shr 8).coerceIn(0, 1)
            val a = tiles[ty * 2 + tx]!!
            return a[(py and 255) * 256 + (px and 255)]
        }
        val bx = ox - gx0 * 256.0
        val by = oy - gy0 * 256.0
        val g = FloatArray(N * N)
        for (j in 0 until N) {
            val py = by + j / scale
            val iy = floor(py).toInt()
            val fy = (py - iy).toFloat()
            val iy1 = if (fy > 0f) iy + 1 else iy
            for (i in 0 until N) {
                val px = bx + i / scale
                val ix = floor(px).toInt()
                val fx = (px - ix).toFloat()
                val ix1 = if (fx > 0f) ix + 1 else ix
                val top = pix(ix, iy) * (1 - fx) + pix(ix1, iy) * fx
                val bot = pix(ix, iy1) * (1 - fx) + pix(ix1, iy1) * fx
                g[j * N + i] = top * (1 - fy) + bot * fy
            }
        }
        if (f == 0) smoothInterior(g)
        return g
    }

    /** Rata-rata 3x3 untuk titik dalam (tepi dibiarkan agar ubin bertetangga tetap menyambung tanpa celah). */
    private fun smoothInterior(g: FloatArray) {
        val src = g.copyOf()
        for (j in 1 until N - 1) for (i in 1 until N - 1) {
            var s = 0f
            for (dj in -1..1) for (di in -1..1) s += src[(j + dj) * N + i + di]
            g[j * N + i] = s / 9f
        }
    }

    private fun lerp(a: Int, b: Int, f: Float): Int {
        val r = (Color.red(a) + (Color.red(b) - Color.red(a)) * f).toInt()
        val gr = (Color.green(a) + (Color.green(b) - Color.green(a)) * f).toInt()
        val bl = (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * f).toInt()
        return Color.rgb(r, gr, bl)
    }

    private val TINT_H = floatArrayOf(0f, 150f, 500f, 1200f, 2000f, 3000f, 4000f)
    private val TINT_C = intArrayOf(0xFFDDE8C8.toInt(), 0xFFE6EBCF.toInt(), 0xFFEEECD2.toInt(), 0xFFE9DEC3.toInt(), 0xFFDDCDB2.toInt(), 0xFFD0C2AC.toInt(), 0xFFEDEBE8.toInt())
    private const val WATER = 0xFFC3DCEB.toInt()

    private fun tint(h: Float): Int {
        if (h <= 0f) return WATER
        if (h >= TINT_H.last()) return TINT_C.last()
        var k = 0
        while (k < TINT_H.size - 2 && h > TINT_H[k + 1]) k++
        return lerp(TINT_C[k], TINT_C[k + 1], (h - TINT_H[k]) / (TINT_H[k + 1] - TINT_H[k]))
    }

    private fun draw(g: FloatArray, t: TileId): Bitmap {
        // ukuran sel grid dalam meter (untuk kemiringan)
        val n = (1 shl t.z).toDouble()
        val latRad = atan(kotlin.math.sinh(PI * (1 - 2 * (t.y + 0.5) / n)))
        val cell = 156_543.03392 * cos(latRad) / n // meter per piksel ubin
        val zf = 1.5
        val zen = (90.0 - 45.0) * PI / 180.0
        val az = 135.0 * PI / 180.0 // cahaya dari barat laut (azimut 315°) dalam sudut matematika, rumus ESRI

        // tinta + bayangan relief pada resolusi grid
        val px = IntArray(GRID * GRID)
        for (j in 0 until GRID) for (i in 0 until GRID) {
            val h = g[j * N + i]
            val iw = max(i - 1, 0); val ie = min(i + 1, GRID)
            val jn = max(j - 1, 0); val js = min(j + 1, GRID)
            val dzdx = (g[j * N + ie] - g[j * N + iw]) / ((ie - iw) * cell)
            val dzdy = (g[js * N + i] - g[jn * N + i]) / ((js - jn) * cell)
            val slope = atan(zf * sqrt(dzdx * dzdx + dzdy * dzdy))
            val aspect = if (dzdx != 0.0 || dzdy != 0.0) atan2(dzdy, -dzdx) else 0.0
            var shade = cos(zen) * cos(slope) + sin(zen) * sin(slope) * cos(az - aspect)
            if (h <= 0f) shade = 0.707
            val factor = (0.55 + 0.6 * shade).coerceIn(0.5, 1.0).toFloat()
            val c = tint(h)
            px[j * GRID + i] = Color.rgb(
                (Color.red(c) * factor).toInt().coerceIn(0, 255),
                (Color.green(c) * factor).toInt().coerceIn(0, 255),
                (Color.blue(c) * factor).toInt().coerceIn(0, 255),
            )
        }
        val base = Bitmap.createBitmap(GRID, GRID, Bitmap.Config.ARGB_8888)
        base.setPixels(px, 0, GRID, 0, 0, GRID, GRID)
        val bmp = Bitmap.createBitmap(RES, RES, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        cv.drawBitmap(base, null, android.graphics.Rect(0, 0, RES, RES), Paint(Paint.FILTER_BITMAP_FLAG))
        base.recycle()

        // garis kontur (marching squares)
        val step = intervalFor(t.z)
        val sc = (RES / GRID).toFloat()
        val thin = Path()
        val index = Path()
        class Label(val x: Float, val y: Float, val ang: Float, val level: Int)
        val labels = ArrayList<Label>()
        val seen = HashSet<Long>()
        val ex = FloatArray(4)
        val ey = FloatArray(4)

        fun seg(isIndex: Boolean, k: Int, L: Float, p: Int, q: Int) {
            val x1 = ex[p] * sc; val y1 = ey[p] * sc; val x2 = ex[q] * sc; val y2 = ey[q] * sc
            val path = if (isIndex) index else thin
            path.moveTo(x1, y1); path.lineTo(x2, y2)
            if (isIndex) {
                val mx = (x1 + x2) / 2f; val my = (y1 + y2) / 2f
                if (mx in 30f..482f && my in 30f..482f) {
                    val key = (k.toLong() shl 8) or ((mx / 128f).toInt().toLong() shl 4) or (my / 128f).toInt().toLong()
                    if (seen.add(key)) {
                        var ang = Math.toDegrees(atan2((y2 - y1).toDouble(), (x2 - x1).toDouble())).toFloat()
                        if (ang > 90f) ang -= 180f
                        if (ang <= -90f) ang += 180f
                        labels.add(Label(mx, my, ang, Math.round(L)))
                    }
                }
            }
        }

        for (j in 0 until GRID) for (i in 0 until GRID) {
            val a = g[j * N + i]; val b = g[j * N + i + 1]
            val c = g[(j + 1) * N + i + 1]; val d = g[(j + 1) * N + i]
            val lo = min(min(a, b), min(c, d)); val hi = max(max(a, b), max(c, d))
            if (hi <= 0f) continue
            val kLo = max(1, floor(lo / step).toInt() + 1)
            val kHi = floor(hi / step).toInt()
            if (kLo > kHi) continue
            val mean = (a + b + c + d) / 4f
            for (k in kLo..kHi) {
                val L = (k * step).toFloat()
                val code = (if (a >= L) 1 else 0) or (if (b >= L) 2 else 0) or (if (c >= L) 4 else 0) or (if (d >= L) 8 else 0)
                if (code == 0 || code == 15) continue
                // titik potong di sisi atas, kanan, bawah, kiri
                ex[0] = i + (L - a) / (b - a); ey[0] = j.toFloat()
                ex[1] = (i + 1).toFloat(); ey[1] = j + (L - b) / (c - b)
                ex[2] = i + (L - d) / (c - d); ey[2] = (j + 1).toFloat()
                ex[3] = i.toFloat(); ey[3] = j + (L - a) / (d - a)
                val isIndex = k % 5 == 0
                when (code) {
                    1, 14 -> seg(isIndex, k, L, 3, 0)
                    2, 13 -> seg(isIndex, k, L, 0, 1)
                    3, 12 -> seg(isIndex, k, L, 3, 1)
                    4, 11 -> seg(isIndex, k, L, 1, 2)
                    6, 9 -> seg(isIndex, k, L, 0, 2)
                    7, 8 -> seg(isIndex, k, L, 3, 2)
                    5 -> if (mean >= L) { seg(isIndex, k, L, 0, 1); seg(isIndex, k, L, 3, 2) } else { seg(isIndex, k, L, 3, 0); seg(isIndex, k, L, 1, 2) }
                    10 -> if (mean >= L) { seg(isIndex, k, L, 3, 0); seg(isIndex, k, L, 1, 2) } else { seg(isIndex, k, L, 0, 1); seg(isIndex, k, L, 3, 2) }
                }
            }
        }

        val thinPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 1.1f; color = 0xBFA8683A.toInt(); strokeCap = Paint.Cap.ROUND
        }
        val indexPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 2.3f; color = 0xFF8A4A1F.toInt(); strokeCap = Paint.Cap.ROUND
        }
        cv.drawPath(thin, thinPaint)
        cv.drawPath(index, indexPaint)

        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 17f; color = 0xFF6B3410.toInt(); typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER }
        val halo = Paint(fill).apply { style = Paint.Style.STROKE; strokeWidth = 4.5f; color = 0xE6F3EEDC.toInt() }
        for (lb in labels) {
            cv.save()
            cv.rotate(lb.ang, lb.x, lb.y)
            val txt = lb.level.toString()
            val yy = lb.y + 6f
            cv.drawText(txt, lb.x, yy, halo)
            cv.drawText(txt, lb.x, yy, fill)
            cv.restore()
        }
        return bmp
    }
}
