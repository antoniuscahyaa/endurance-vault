package com.endurancevault.app.ui.video

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.RectF
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.net.Uri
import android.opengl.GLES20
import android.opengl.GLUtils
import android.os.Build
import com.endurancevault.app.domain.HudVideoPrefs
import com.endurancevault.app.domain.RouteVideoTrack
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.CancellationException
import kotlin.math.max
import kotlin.math.min

/**
 * Exporter HUD native: decode frame video, composite HUD pada timestamp eksak, encode H.264,
 * lalu copy AAC asli tanpa re-encode bila track audio tersedia.
 */
object HudVideoEncoder {
    private const val FPS = 30
    fun encode(
        context: Context, uri: Uri, track: RouteVideoTrack, offsetSec: Int, prefs: HudVideoPrefs, out: File,
        active: () -> Boolean = { true }, progress: (Float) -> Unit = {},
    ): Result<Unit> = if (prefs.format == "rec") {
        encodeRecorder(context, uri, track, offsetSec, prefs, out, active, progress)
    } else {
        encodeCodec(context, uri, track, offsetSec, prefs, out, active, progress)
    }

    private fun encodeCodec(
        context: Context, uri: Uri, track: RouteVideoTrack, offsetSec: Int, prefs: HudVideoPrefs, out: File,
        active: () -> Boolean = { true }, progress: (Float) -> Unit = {},
    ): Result<Unit> {
        var retriever: MediaMetadataRetriever? = null
        var extractor: MediaExtractor? = null
        var encoder: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var egl: EglCore? = null
        var gl: HudGl? = null
        var inputSurface: android.view.Surface? = null
        var canvasBitmap: Bitmap? = null
        var muxStarted = false
        var videoTrack = -1
        var audioTrackOut = -1
        var ok = false
        try {
            out.parentFile?.mkdirs(); out.delete()
            val mr = MediaMetadataRetriever().also { retriever = it; it.setDataSource(context, uri) }
            val durationMs = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?.coerceAtLeast(1L)
                ?: error("Durasi video tidak terbaca.")
            require(durationMs <= 900_000L) { "Video HUD dibatasi maksimal 15 menit." }
            val sourceW = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 720
            val sourceH = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 1280
            val rotation = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            val swapDimensions = rotation == 90 || rotation == 270
            val applyRotation = rotation == 90 || rotation == 180 || rotation == 270
            val maxDim = 1280f
            val factor = min(1f, maxDim / max(sourceW, sourceH).toFloat())
            val w0 = (sourceW * factor).toInt().coerceAtLeast(2)
            val h0 = (sourceH * factor).toInt().coerceAtLeast(2)
            val w = (if (swapDimensions) h0 else w0).let { it - it % 2 }
            val h = (if (swapDimensions) w0 else h0).let { it - it % 2 }
            val frames = max(1, (durationMs / 1000.0 * FPS).toInt())
            val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, (w.toLong() * h * 6).coerceIn(2_000_000L, 18_000_000L).toInt())
                setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }
            val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC).also { encoder = it }
            enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val surface = enc.createInputSurface()
            inputSurface = surface
            enc.start()
            val mux = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4).also { muxer = it }

            // Tambahkan audio track lebih dulu; audio AAC disalin apa adanya bila diminta dan tersedia.
            val ex = if (prefs.keepAudio) MediaExtractor().also { extractor = it } else null
            var audioTrackIn = -1
            if (ex != null) {
                ex.setDataSource(context, uri, null)
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    if (f.getString(MediaFormat.KEY_MIME) == MediaFormat.MIMETYPE_AUDIO_AAC) {
                        audioTrackIn = i
                        audioTrackOut = mux.addTrack(f)
                        ex.selectTrack(i)
                        break
                    }
                }
                if (audioTrackIn < 0) {
                    error("Audio asli tidak dapat dipertahankan karena video tidak memiliki track AAC yang kompatibel. Nonaktifkan opsi Audio asli untuk mengekspor tanpa suara.")
                }
            }

            val eg = EglCore(surface, w, h).also { egl = it }
            eg.makeCurrent()
            val renderer = HudGl().also { gl = it; it.init() }
            val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { canvasBitmap = it }
            val canvas = Canvas(bitmap)
            val info = MediaCodec.BufferInfo()

            fun startMuxIfReady() {
                if (!muxStarted && videoTrack >= 0) { mux.start(); muxStarted = true }
            }
            val audioMax = runCatching {
                if (ex != null && audioTrackIn >= 0) ex.getTrackFormat(audioTrackIn).getInteger(MediaFormat.KEY_MAX_INPUT_SIZE).coerceAtLeast(256 * 1024)
                else 1024 * 1024
            }.getOrDefault(1024 * 1024).coerceAtMost(8 * 1024 * 1024)
            val audioBuffer = ByteBuffer.allocateDirect(audioMax)
            fun copyAudioUntil(untilUs: Long) {
                if (!muxStarted || ex == null || audioTrackIn < 0 || audioTrackOut < 0) return
                val buf = audioBuffer
                while (ex.sampleTrackIndex >= 0 && ex.sampleTime >= 0 && ex.sampleTime <= untilUs) {
                    buf.clear()
                    val size = ex.readSampleData(buf, 0)
                    if (size < 0) break
                    val bi = MediaCodec.BufferInfo().apply {
                        set(0, size, ex.sampleTime, ex.sampleFlags)
                    }
                    buf.position(0); buf.limit(size)
                    mux.writeSampleData(audioTrackOut, buf, bi)
                    ex.advance()
                }
            }
            fun drain(end: Boolean) {
                while (true) {
                    val index = enc.dequeueOutputBuffer(info, if (end) 10_000 else 2_000)
                    when {
                        index == MediaCodec.INFO_TRY_AGAIN_LATER -> { if (!end) return }
                        index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            check(videoTrack < 0) { "Format video berubah lebih dari sekali." }
                            videoTrack = mux.addTrack(enc.outputFormat)
                            startMuxIfReady()
                        }
                        index >= 0 -> {
                            val data = enc.getOutputBuffer(index)
                            if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                            if (info.size > 0 && data != null) {
                                startMuxIfReady()
                                if (muxStarted) {
                                    data.position(info.offset); data.limit(info.offset + info.size)
                                    copyAudioUntil(info.presentationTimeUs)
                                    mux.writeSampleData(videoTrack, data, info)
                                }
                            }
                            val eos = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                            enc.releaseOutputBuffer(index, false)
                            if (eos) return
                        }
                    }
                }
            }

            for (frame in 0 until frames) {
                if (!active()) throw CancellationException("Ekspor dibatalkan.")
                val timeUs = min(durationMs * 1000L - 1, frame.toLong() * 1_000_000L / FPS)
                val source = (if (Build.VERSION.SDK_INT >= 27) {
                    mr.getScaledFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST,
                        if (swapDimensions) h else w, if (swapDimensions) w else h)
                } else mr.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST))
                    ?: error("Tidak dapat membaca frame pada ${timeUs / 1_000_000.0} detik.")
                canvas.drawColor(android.graphics.Color.BLACK)
                val rotatedBitmap = if (applyRotation) rotate(source, rotation) else source
                val scale = max(w / rotatedBitmap.width.toFloat(), h / rotatedBitmap.height.toFloat())
                val dw = rotatedBitmap.width * scale; val dh = rotatedBitmap.height * scale
                canvas.drawBitmap(rotatedBitmap, null, RectF((w-dw)/2f,(h-dh)/2f,(w+dw)/2f,(h+dh)/2f), android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
                val seconds = timeUs / 1_000_000.0
                HudVideoOverlay.drawOverlay(canvas, w, h, track, seconds, offsetSec, prefs)
                renderer.draw(bitmap)
                eg.setPresentationTime(frame.toLong() * 1_000_000_000L / FPS)
                check(eg.swap()) { "Gagal menulis frame HUD." }
                drain(false)
                if (rotatedBitmap !== source) rotatedBitmap.recycle()
                source.recycle()
                progress((frame + 1f) / frames * 0.95f)
            }
            bitmap.recycle(); canvasBitmap = null
            enc.signalEndOfInputStream()
            drain(true)
            if (muxStarted && ex != null && audioTrackIn >= 0) copyAudioUntil(durationMs * 1000L)
            check(muxStarted) { "Encoder tidak menghasilkan video." }
            progress(1f)
            ok = true
            return Result.success(Unit)
        } catch (t: Throwable) {
            out.delete()
            return Result.failure(t)
        } finally {
            runCatching { canvasBitmap?.recycle() }
            runCatching { gl?.release() }
            runCatching { egl?.release() }
            runCatching { inputSurface?.release() }
            runCatching { encoder?.stop() }; runCatching { encoder?.release() }
            runCatching { muxer?.let { if (muxStarted) it.stop(); it.release() } }
            runCatching { extractor?.release() }
            runCatching { retriever?.release() }
        }
    }

    private fun encodeRecorder(
        context: Context, uri: Uri, track: RouteVideoTrack, offsetSec: Int, prefs: HudVideoPrefs, out: File,
        active: () -> Boolean, progress: (Float) -> Unit,
    ): Result<Unit> {
        var retriever: MediaMetadataRetriever? = null
        var recorder: MediaRecorder? = null
        var inputSurface: android.view.Surface? = null
        var egl: EglCore? = null
        var gl: HudGl? = null
        var bitmap: Bitmap? = null
        val temp = File(out.parentFile ?: context.cacheDir, "hud-rec-${System.currentTimeMillis()}.mp4")
        try {
            out.parentFile?.mkdirs(); out.delete(); temp.delete()
            val mr = MediaMetadataRetriever().also { retriever = it; it.setDataSource(context, uri) }
            val durationMs = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?.coerceAtLeast(1L)
                ?: error("Durasi video tidak terbaca.")
            require(durationMs <= 900_000L) { "Video HUD dibatasi maksimal 15 menit." }
            val sourceW = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 720
            val sourceH = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 1280
            val rotation = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            val swap = rotation == 90 || rotation == 270
            val applyRotation = rotation == 90 || rotation == 180 || rotation == 270
            val factor = min(1f, 1280f / max(sourceW, sourceH).toFloat())
            val w0 = (sourceW * factor).toInt().coerceAtLeast(2)
            val h0 = (sourceH * factor).toInt().coerceAtLeast(2)
            val w = (if (swap) h0 else w0).let { it - it % 2 }
            val h = (if (swap) w0 else h0).let { it - it % 2 }
            val frames = max(1, (durationMs / 1000.0 * FPS).toInt())

            if (prefs.keepAudio) requireAacTrack(context, uri)
            val rec = MediaRecorder().also { recorder = it }
            rec.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setVideoEncoder(MediaRecorder.VideoEncoder.DEFAULT)
            rec.setVideoSize(w, h)
            rec.setVideoFrameRate(FPS)
            rec.setVideoEncodingBitRate((w.toLong() * h * 6).coerceIn(2_000_000L, 18_000_000L).toInt())
            rec.setOutputFile(temp.absolutePath)
            rec.prepare()
            val surface = rec.surface
            inputSurface = surface
            rec.start()

            val eg = EglCore(surface, w, h).also { egl = it }
            eg.makeCurrent()
            val renderer = HudGl().also { gl = it; it.init() }
            val frameBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { bitmap = it }
            val canvas = Canvas(frameBitmap)
            for (frame in 0 until frames) {
                if (!active()) throw CancellationException("Ekspor dibatalkan.")
                val timeUs = min(durationMs * 1000L - 1, frame.toLong() * 1_000_000L / FPS)
                val source = (if (Build.VERSION.SDK_INT >= 27) {
                    mr.getScaledFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST,
                        if (swap) h else w, if (swap) w else h)
                } else mr.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST))
                    ?: error("Tidak dapat membaca frame pada ${timeUs / 1_000_000.0} detik.")
                val oriented = if (applyRotation) rotate(source, rotation) else source
                canvas.drawColor(android.graphics.Color.BLACK)
                val fit = max(w / oriented.width.toFloat(), h / oriented.height.toFloat())
                val dw = oriented.width * fit; val dh = oriented.height * fit
                canvas.drawBitmap(oriented, null, RectF((w-dw)/2f,(h-dh)/2f,(w+dw)/2f,(h+dh)/2f),
                    android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
                HudVideoOverlay.drawOverlay(canvas, w, h, track, timeUs / 1_000_000.0, offsetSec, prefs)
                renderer.draw(frameBitmap)
                eg.setPresentationTime(frame.toLong() * 1_000_000_000L / FPS)
                check(eg.swap()) { "Recorder tidak menerima frame." }
                if (oriented !== source) oriented.recycle()
                source.recycle()
                progress((frame + 1f) / frames * 0.95f)
            }
            frameBitmap.recycle(); bitmap = null
            rec.stop()
            rec.release(); recorder = null
            renderer.release(); gl = null
            eg.release(); egl = null
            inputSurface?.release(); inputSurface = null
            if (prefs.keepAudio) muxRecorderVideoWithAudio(context, temp, uri, out, durationMs * 1000L)
            else temp.copyTo(out, overwrite = true)
            temp.delete()
            progress(1f)
            return Result.success(Unit)
        } catch (t: Throwable) {
            out.delete(); temp.delete()
            return Result.failure(t)
        } finally {
            runCatching { bitmap?.recycle() }
            runCatching { gl?.release() }
            runCatching { egl?.release() }
            runCatching { inputSurface?.release() }
            runCatching { recorder?.stop() }
            runCatching { recorder?.release() }
            runCatching { retriever?.release() }
            runCatching { temp.delete() }
        }
    }

    private fun requireAacTrack(context: Context, uri: Uri) {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(context, uri, null)
            val found = (0 until ex.trackCount).any { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME) == MediaFormat.MIMETYPE_AUDIO_AAC }
            require(found) { "Audio asli tidak dapat dipertahankan karena video tidak memiliki track AAC yang kompatibel. Nonaktifkan opsi Audio asli untuk mengekspor tanpa suara." }
        } finally { ex.release() }
    }

    private fun muxRecorderVideoWithAudio(context: Context, videoFile: File, sourceUri: Uri, out: File, durationUs: Long) {
        val videoEx = MediaExtractor()
        val audioEx = MediaExtractor()
        var muxer: MediaMuxer? = null
        var started = false
        try {
            videoEx.setDataSource(videoFile.absolutePath)
            audioEx.setDataSource(context, sourceUri, null)
            var vi = -1; var ai = -1
            for (i in 0 until videoEx.trackCount) if (videoEx.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true) { vi = i; break }
            for (i in 0 until audioEx.trackCount) if (audioEx.getTrackFormat(i).getString(MediaFormat.KEY_MIME) == MediaFormat.MIMETYPE_AUDIO_AAC) { ai = i; break }
            check(vi >= 0 && ai >= 0) { "Track video atau AAC tidak ditemukan saat menggabungkan audio." }
            val vf = videoEx.getTrackFormat(vi); val af = audioEx.getTrackFormat(ai)
            val mux = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4).also { muxer = it }
            val vo = mux.addTrack(vf); val ao = mux.addTrack(af)
            videoEx.selectTrack(vi); audioEx.selectTrack(ai)
            mux.start(); started = true
            val vCap = max(256 * 1024, runCatching { vf.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE) }.getOrDefault(1024 * 1024)).coerceAtMost(8 * 1024 * 1024)
            val aCap = max(256 * 1024, runCatching { af.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE) }.getOrDefault(1024 * 1024)).coerceAtMost(8 * 1024 * 1024)
            val vb = ByteBuffer.allocateDirect(vCap); val ab = ByteBuffer.allocateDirect(aCap)
            while (true) {
                val vt = if (videoEx.sampleTrackIndex >= 0) videoEx.sampleTime else -1L
                val at = if (audioEx.sampleTrackIndex >= 0 && audioEx.sampleTime <= durationUs) audioEx.sampleTime else -1L
                if (vt < 0 && at < 0) break
                val useVideo = at < 0 || (vt >= 0 && vt <= at)
                val ex = if (useVideo) videoEx else audioEx
                val buf = if (useVideo) vb else ab
                val cap = if (useVideo) vCap else aCap
                val trackOut = if (useVideo) vo else ao
                buf.clear()
                val size = ex.readSampleData(buf, 0)
                if (size < 0) { ex.advance(); continue }
                val info = MediaCodec.BufferInfo().apply { set(0, size, ex.sampleTime, ex.sampleFlags) }
                buf.position(0); buf.limit(size)
                mux.writeSampleData(trackOut, buf, info)
                ex.advance()
            }
            mux.stop(); started = false
        } finally {
            runCatching { muxer?.let { if (started) it.stop(); it.release() } }
            videoEx.release(); audioEx.release()
        }
    }

    private fun rotate(b:Bitmap,degrees:Int):Bitmap {
        val m=android.graphics.Matrix().apply { postRotate(degrees.toFloat()) }
        return Bitmap.createBitmap(b,0,0,b.width,b.height,m,true)
    }
}

private class HudGl {
    private var program=0
    private var texture=0
    private var pos=0
    private var uv=0
    private var sampler=0
    private val vertices=ByteBuffer.allocateDirect(16*4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
        put(floatArrayOf(-1f,-1f,0f,1f, 1f,-1f,1f,1f, -1f,1f,0f,0f, 1f,1f,1f,0f));position(0)
    }
    fun init(){
        val vs="attribute vec2 aPos; attribute vec2 aUv; varying vec2 vUv; void main(){gl_Position=vec4(aPos,0.0,1.0);vUv=aUv;}"
        val fs="precision mediump float; varying vec2 vUv; uniform sampler2D uTex; void main(){gl_FragColor=texture2D(uTex,vUv);}"
        val v=shader(GLES20.GL_VERTEX_SHADER,vs);val f=shader(GLES20.GL_FRAGMENT_SHADER,fs)
        program=GLES20.glCreateProgram();GLES20.glAttachShader(program,v);GLES20.glAttachShader(program,f);GLES20.glLinkProgram(program)
        val ok=IntArray(1);GLES20.glGetProgramiv(program,GLES20.GL_LINK_STATUS,ok,0);check(ok[0]!=0){"Shader HUD gagal."}
        pos=GLES20.glGetAttribLocation(program,"aPos");uv=GLES20.glGetAttribLocation(program,"aUv");sampler=GLES20.glGetUniformLocation(program,"uTex")
        val ids=IntArray(1);GLES20.glGenTextures(1,ids,0);texture=ids[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D,texture)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D,GLES20.GL_TEXTURE_MIN_FILTER,GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D,GLES20.GL_TEXTURE_MAG_FILTER,GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D,GLES20.GL_TEXTURE_WRAP_S,GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D,GLES20.GL_TEXTURE_WRAP_T,GLES20.GL_CLAMP_TO_EDGE)
    }
    fun draw(bitmap:Bitmap){
        GLES20.glViewport(0,0,bitmap.width,bitmap.height);GLES20.glClearColor(0f,0f,0f,1f);GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glUseProgram(program);GLES20.glBindTexture(GLES20.GL_TEXTURE_2D,texture);GLUtils.texImage2D(GLES20.GL_TEXTURE_2D,0,bitmap,0)
        vertices.position(0);GLES20.glEnableVertexAttribArray(pos);GLES20.glVertexAttribPointer(pos,2,GLES20.GL_FLOAT,false,16,vertices)
        vertices.position(2);GLES20.glEnableVertexAttribArray(uv);GLES20.glVertexAttribPointer(uv,2,GLES20.GL_FLOAT,false,16,vertices)
        GLES20.glUniform1i(sampler,0);GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP,0,4)
        GLES20.glDisableVertexAttribArray(pos);GLES20.glDisableVertexAttribArray(uv)
    }
    fun release(){if(texture!=0)GLES20.glDeleteTextures(1,intArrayOf(texture),0);if(program!=0)GLES20.glDeleteProgram(program)}
    private fun shader(type:Int,source:String):Int{
        val id=GLES20.glCreateShader(type);GLES20.glShaderSource(id,source);GLES20.glCompileShader(id)
        val ok=IntArray(1);GLES20.glGetShaderiv(id,GLES20.GL_COMPILE_STATUS,ok,0);check(ok[0]!=0){"Shader HUD compile gagal: ${GLES20.glGetShaderInfoLog(id)}"};return id
    }
}
