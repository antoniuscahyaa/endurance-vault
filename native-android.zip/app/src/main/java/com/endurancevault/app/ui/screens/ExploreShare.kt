package com.endurancevault.app.ui.screens

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import com.endurancevault.app.domain.ExRoute
import com.endurancevault.app.domain.Js
import com.endurancevault.app.ui.ExCalib
import com.endurancevault.app.ui.i18n.Lang
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min

/**
 * Kartu bagikan rute 4:5 (1080x1350) yang digambar langsung ke bitmap: bentuk rute, judul, jarak/naik/turun, dan profil elevasi.
 * Tanpa ubin peta (hanya garis rute), jadi tidak bergantung jaringan dan bebas masalah lisensi ubin.
 */
object ExploreShare {
    enum class Skin(val label: String) { MINIMAL("Minimalis"), SPORTY("Sporty"), ELEGAN("Elegan") }

    private const val W = 1080
    private const val H = 1350
    private const val M = 72f

    private class Theme(
        val bg: Int, val ink: Int, val sub: Int, val route: Int, val casing: Int, val grid: Int,
        val title: Typeface, val num: Typeface, val label: Typeface, val frame: Boolean, val bigNum: Boolean, val upper: Boolean,
    )

    private fun theme(s: Skin) = when (s) {
        Skin.MINIMAL -> Theme(
            0xFFFAFAF7.toInt(), 0xFF1C1C1E.toInt(), 0xFF8A8A8E.toInt(), 0xFF1C1C1E.toInt(), 0xFFFAFAF7.toInt(), 0xFFE6E6E2.toInt(),
            Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD), Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD), Typeface.SANS_SERIF,
            frame = false, bigNum = false, upper = false,
        )
        Skin.SPORTY -> Theme(
            0xFF101114.toInt(), 0xFFFFFFFF.toInt(), 0xFF9A9AA2.toInt(), 0xFFFF5A1F.toInt(), 0xFF101114.toInt(), 0xFF24262B.toInt(),
            Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD_ITALIC), Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD_ITALIC), Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD),
            frame = false, bigNum = true, upper = true,
        )
        Skin.ELEGAN -> Theme(
            0xFFF3EBDD.toInt(), 0xFF2F3A2E.toInt(), 0xFF7B7261.toInt(), 0xFF3F5B3A.toInt(), 0xFFF3EBDD.toInt(), 0xFFE4D9C4.toInt(),
            Typeface.create(Typeface.SERIF, Typeface.BOLD), Typeface.create(Typeface.SERIF, Typeface.NORMAL), Typeface.create(Typeface.SERIF, Typeface.ITALIC),
            frame = true, bigNum = false, upper = false,
        )
    }

    private fun paint(color: Int, size: Float, tf: Typeface, align: Paint.Align = Paint.Align.LEFT, spacing: Float = 0f) =
        Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; textSize = size; typeface = tf; textAlign = align; letterSpacing = spacing }

    private fun ellipsize(text: String, p: Paint, maxW: Float): String {
        if (p.measureText(text) <= maxW) return text
        var t = text
        while (t.length > 1 && p.measureText("$t…") > maxW) t = t.dropLast(1)
        return "$t…"
    }

    fun render(route: ExRoute, skin: Skin, calib: ExCalib? = null): Bitmap {
        val th = theme(skin)
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(th.bg)
        val st = route.stats
        val tr = { s: String -> Lang.tr(s) }

        if (th.frame) {
            val fp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f; color = th.sub }
            c.drawRect(RectF(36f, 36f, W - 36f, H - 36f), fp)
        }

        // judul dan keterangan
        val titleP = paint(th.ink, 66f, th.title)
        val name = ellipsize(if (th.upper) route.name.uppercase() else route.name, titleP, W - 2 * M)
        c.drawText(name, M, 150f, titleP)
        val mode = when (route.mode) { "ride" -> tr("Sepeda"); "manual" -> tr("Manual"); else -> tr("Lari") }
        c.drawText(if (th.upper) mode.uppercase() else mode, M, 205f, paint(th.sub, 34f, th.label, spacing = if (th.upper) 0.12f else 0.02f))

        // bentuk rute (proyeksi ekirektangular, skala seragam)
        val box = RectF(M, 250f, W - M, 930f)
        val gp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f; color = th.grid }
        for (k in 0..4) { val y = box.top + box.height() * k / 4f; c.drawLine(box.left, y, box.right, y, gp) }
        for (k in 0..4) { val x = box.left + box.width() * k / 4f; c.drawLine(x, box.top, x, box.bottom, gp) }

        val pts = route.pts
        val lat0 = pts.map { it.lat }.average()
        val kx = cos(Math.toRadians(lat0))
        val xs = pts.map { it.lon * kx }
        val ys = pts.map { -it.lat }
        val minX = xs.min(); val maxX = xs.max(); val minY = ys.min(); val maxY = ys.max()
        val spanX = max(maxX - minX, 1e-9); val spanY = max(maxY - minY, 1e-9)
        val pad = 40f
        val sc = min((box.width() - 2 * pad) / spanX, (box.height() - 2 * pad) / spanY).toFloat()
        val ox = box.left + (box.width() - (spanX * sc).toFloat()) / 2f
        val oy = box.top + (box.height() - (spanY * sc).toFloat()) / 2f
        fun px(i: Int) = ox + ((xs[i] - minX) * sc).toFloat()
        fun py(i: Int) = oy + ((ys[i] - minY) * sc).toFloat()
        val path = Path()
        for (i in pts.indices) if (i == 0) path.moveTo(px(i), py(i)) else path.lineTo(px(i), py(i))
        val casing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 20f; color = th.casing; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 11f; color = th.route; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
        c.drawPath(path, casing)
        c.drawPath(path, line)
        val last = pts.lastIndex
        val dot = Paint(Paint.ANTI_ALIAS_FLAG)
        dot.color = th.bg; c.drawCircle(px(0), py(0), 22f, dot)
        dot.color = 0xFF2E9E5B.toInt(); c.drawCircle(px(0), py(0), 14f, dot)
        dot.color = th.bg; c.drawCircle(px(last), py(last), 22f, dot)
        dot.color = th.ink; c.drawCircle(px(last), py(last), 14f, dot)

        // statistik
        val up = calib?.up ?: st.up
        val down = calib?.down ?: st.down
        val cols = listOf(
            Triple(Js.fmtKm(st.km), "km", tr("Jarak")),
            Triple(if (st.hasEle) Js.idn(up) else "–", "m", tr("Naik")),
            Triple(if (st.hasEle) Js.idn(down) else "–", "m", tr("Turun")),
        )
        val numSize = if (th.bigNum) 96f else 80f
        val colW = (W - 2 * M) / cols.size
        cols.forEachIndexed { i, (v, u, l) ->
            val x = M + colW * i
            val np = paint(th.ink, numSize, th.num)
            c.drawText(v, x, 1040f, np)
            val w = np.measureText(v)
            c.drawText(u, x + w + 10f, 1040f, paint(th.sub, 34f, th.label))
            c.drawText(if (th.upper) l.uppercase() else l, x, 1086f, paint(th.sub, 30f, th.label, spacing = if (th.upper) 0.12f else 0.02f))
        }

        // profil elevasi
        val prof = st.prof
        val area = RectF(M, 1130f, W - M, 1262f)
        if (prof.size >= 2) {
            val pk = prof.last()[0].let { if (it > 0) it else 1.0 }
            var lo = prof.minOf { it[1] }; var hi = prof.maxOf { it[1] }
            if (hi - lo < 20) { val mid = (hi + lo) / 2; lo = mid - 10; hi = mid + 10 }
            val area0 = Path()
            val top = Path()
            prof.forEachIndexed { i, p ->
                val x = area.left + (p[0] / pk * area.width()).toFloat()
                val y = area.bottom - ((p[1] - lo) / (hi - lo) * area.height()).toFloat()
                if (i == 0) { area0.moveTo(x, area.bottom); area0.lineTo(x, y); top.moveTo(x, y) } else { area0.lineTo(x, y); top.lineTo(x, y) }
            }
            area0.lineTo(area.right, area.bottom); area0.close()
            c.drawPath(area0, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = (th.route and 0x00FFFFFF) or 0x33000000 })
            c.drawPath(top, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 5f; color = th.route; strokeJoin = Paint.Join.ROUND })
            val lp = paint(th.sub, 26f, th.label)
            c.drawText("${Js.idn(lo.toInt())} m", area.left, area.bottom + 34f, lp)
            val hp = paint(th.sub, 26f, th.label, Paint.Align.RIGHT)
            c.drawText("${Js.idn(hi.toInt())} m", area.right, area.bottom + 34f, hp)
        }

        c.drawText("EnduranceVault", W / 2f, H - 52f, paint(th.sub, 28f, th.label, Paint.Align.CENTER, 0.1f))
        return bmp
    }
}
