package com.endurancevault.app.ui.screens

import android.Manifest
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.endurancevault.app.domain.Wx
import com.endurancevault.app.domain.WxSnapshot
import com.endurancevault.app.ui.i18n.Lang
import com.endurancevault.app.ui.i18n.Text
import org.json.JSONObject
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

private fun t(s: String) = Lang.tr(s)

/** Kategori US AQI + warna penanda. */
private fun aqiInfo(aqi: Int): Pair<String, Color> = when {
    aqi <= 50 -> "Baik" to Color(0xFF2E9E5B)
    aqi <= 100 -> "Sedang" to Color(0xFFC9A400)
    aqi <= 150 -> "Tidak sehat (sensitif)" to Color(0xFFEA7B0A)
    aqi <= 200 -> "Tidak sehat" to Color(0xFFD64545)
    aqi <= 300 -> "Sangat tidak sehat" to Color(0xFF8E44AD)
    else -> "Berbahaya" to Color(0xFF7B1E3A)
}

/** Nama ikon cuaca di jam (enum WeatherIcon) -> teks sumber Indonesia. */
private fun watchCondLabel(name: String): String = when (name.uppercase()) {
    "SUNNY" -> "Cerah"
    "CLOUDY" -> "Berawan"
    "OVERCAST" -> "Mendung"
    "LIGHT_RAIN", "SHOWERS" -> "Gerimis"
    "RAIN", "LIGHT_TO_MODERATE_RAIN" -> "Hujan"
    "HEAVY_RAIN", "MODERATE_TO_HEAVY_RAIN", "HEAVY_TO_SEVERE_RAIN", "HEAVY_TO_TORRENTIAL_RAIN", "SEVERE_TO_TORRENTIAL_RAIN" -> "Hujan lebat"
    "THUNDERSTORMS", "RAIN_STORM", "HEAVY_RAIN_STORMS", "SEVERE_RAIN_STORMS", "THUNDER_AND_HAIL" -> "Badai petir"
    "FOG", "HAZY" -> "Berkabut"
    "LIGHT_SNOW", "SNOW", "HEAVY_SNOW", "SNOW_FLURRIES", "SNOWSTORMS" -> "Salju"
    else -> name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercase() }
}

private fun JSONObject.str(key: String): String? =
    if (!has(key) || isNull(key)) null else optString(key).takeIf { it.isNotBlank() && it != "null" }

private fun hhmm(ms: Long): String =
    Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("HH:mm"))

/**
 * Halaman pengaturan cuaca (Pengaturan → Cuaca), dipecah jadi tiga kartu:
 * 1) cuaca saat ini + prakiraan 7 hari, 2) lokasi (cari kota, GPS, koordinat manual), 3) sinkron ke Huawei Watch.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun WeatherSettingsSection(
    snapshot: WxSnapshot?,
    placeLabel: String,
    busy: Boolean,
    error: String?,
    notice: String?,
    message: String,
    lat: String,
    lon: String,
    watchStatus: String,
    watchBusy: Boolean,
    watchNote: String,
    onRefresh: () -> Unit,
    onApplyCoords: (Double, Double, String) -> Unit,
    onSearchCity: (String) -> Unit,
    onUseLocation: () -> Unit,
    onWeatherToWatch: (Double, Double, String) -> Unit,
) {
    val ctx = LocalContext.current
    var latText by remember(lat) { mutableStateOf(lat) }
    var lonText by remember(lon) { mutableStateOf(lon) }
    var nameText by remember { mutableStateOf("") }
    var city by remember { mutableStateOf("") }
    var manualOpen by rememberSaveable { mutableStateOf(false) }
    val w = remember(watchStatus) { runCatching { JSONObject(watchStatus) }.getOrNull() }
    val locationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants[Manifest.permission.ACCESS_FINE_LOCATION] == true || grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true) onUseLocation()
    }
    val savedLat = lat.replace(',', '.').toDoubleOrNull()
    val savedLon = lon.replace(',', '.').toDoubleOrNull()
    val statusMsg = message.takeIf { it.isNotBlank() && !it.startsWith("CUACA SAAT INI") && it != "Cuaca diperbarui." }
    val doSearch = { if (!busy && city.isNotBlank()) onSearchCity(city.trim()) }

    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Cuaca & kualitas udara", style = MaterialTheme.typography.titleLarge)
        Text(
            "Prakiraan 7 hari, peluang hujan, angin, dan indeks kualitas udara. Sumber: Open-Meteo.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        // ── 1. Cuaca saat ini ─────────────────────────────────────────────────────────────
        EvPanel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Filled.LocationOn, contentDescription = null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
                            Text(
                                placeLabel.ifBlank { "Lokasi saya" }, style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                            )
                        }
                        Text(
                            if (snapshot != null) t("Diperbarui") + " " + hhmm(snapshot.fetchedAtMs) else "Belum ada data cuaca",
                            style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    FilledTonalButton(enabled = !busy && !watchBusy, onClick = onRefresh) {
                        Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (busy) "Memuat…" else "Perbarui")
                    }
                }

                if (snapshot != null) {
                    val night = Wx.isNight(snapshot.currentTime, snapshot.sunrise, snapshot.sunset)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("${snapshot.temp.roundToInt()}°C", fontSize = 44.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-1.5).sp, maxLines = 1)
                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                WxGlyph(snapshot.code, night, Modifier.size(22.dp))
                                Text(Wx.label(snapshot.code), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                            }
                            Text(t("Terasa") + " ${snapshot.feels.roundToInt()}°C", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        snapshot.humidity?.let { InfoChip(t("Kelembapan") + " $it%") }
                        snapshot.wind?.let { InfoChip(t("Angin") + " ${"%.1f".format(Locale.US, it)} km/jam") }
                        InfoChip("↑ ${Wx.clock(snapshot.sunrise)}   ↓ ${Wx.clock(snapshot.sunset)}")
                    }
                    val aqi = snapshot.usAqi
                    if (aqi != null || snapshot.pm25 != null) {
                        val info = aqi?.let { aqiInfo(it) }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (info != null) Box(Modifier.size(10.dp).clip(CircleShape).background(info.second))
                            Column {
                                Text(
                                    if (aqi != null && info != null) "US AQI $aqi · " + t(info.first) else t("Kualitas udara"),
                                    style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold,
                                )
                                snapshot.pm25?.let {
                                    Text("PM2.5 ${it.roundToInt()} µg/m³", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                } else {
                    Text(
                        if (busy) "Memuat cuaca…" else "Cuaca belum dimuat. Ketuk Perbarui atau pilih lokasi di bawah.",
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }

                if (error != null) {
                    Text("Data belum bisa diambil. Periksa koneksi dan coba lagi.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
                notice?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }

                if (snapshot != null && snapshot.days.isNotEmpty()) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    Text("7 hari ke depan", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    DailyList(snapshot)
                }
            }
        }

        // ── 2. Lokasi ─────────────────────────────────────────────────────────────────────
        EvPanel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Lokasi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = city, onValueChange = { city = it }, modifier = Modifier.fillMaxWidth(), singleLine = true,
                    label = { Text("Cari kota / kabupaten") },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { doSearch() }),
                    trailingIcon = {
                        IconButton(enabled = !busy && city.isNotBlank(), onClick = { doSearch() }) {
                            Icon(Icons.Filled.Search, contentDescription = t("Cari lokasi"))
                        }
                    },
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        modifier = Modifier.weight(1f), enabled = !busy,
                        onClick = { locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) },
                    ) { Text("Gunakan GPS") }
                    OutlinedButton(
                        modifier = Modifier.weight(1f),
                        onClick = { ctx.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) },
                    ) { Text("Pengaturan lokasi", maxLines = 1) }
                }
                statusMsg?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }

                TextButton(onClick = { manualOpen = !manualOpen }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp)) {
                    Text("Koordinat manual")
                    Text(if (manualOpen) "  ▴" else "  ▾")
                    Spacer(Modifier.weight(1f))
                    if (savedLat != null && savedLon != null) {
                        Text(
                            "${"%.4f".format(Locale.US, savedLat)}, ${"%.4f".format(Locale.US, savedLon)}",
                            style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.End,
                        )
                    }
                }
                AnimatedVisibility(manualOpen) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                latText, { latText = it }, label = { Text("Latitude") }, modifier = Modifier.weight(1f), singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            )
                            OutlinedTextField(
                                lonText, { lonText = it }, label = { Text("Longitude") }, modifier = Modifier.weight(1f), singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            )
                        }
                        OutlinedTextField(nameText, { nameText = it }, label = { Text("Nama lokasi") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        val x = latText.replace(',', '.').toDoubleOrNull()
                        val y = lonText.replace(',', '.').toDoubleOrNull()
                        val valid = x != null && y != null && x in -90.0..90.0 && y in -180.0..180.0
                        OutlinedButton(modifier = Modifier.fillMaxWidth(), enabled = !busy && valid, onClick = { if (valid) onApplyCoords(x!!, y!!, nameText.trim()) }) {
                            Text("Terapkan koordinat")
                        }
                    }
                }
            }
        }

        // ── 3. Huawei Watch ───────────────────────────────────────────────────────────────
        EvPanel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Cuaca di jam", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                val err = w?.str("lastError")
                val cond = w?.str("lastCondition")
                val temp = if (w != null && w.has("lastTemperatureC") && !w.isNull("lastTemperatureC")) w.optDouble("lastTemperatureC", Double.NaN).takeUnless { it.isNaN() } else null
                val pushAt = if (w != null && w.has("lastPushAt") && !w.isNull("lastPushAt")) w.optLong("lastPushAt", 0L) else 0L
                val enabled = w?.optBoolean("enabled", false) == true
                val interval = w?.optInt("intervalMinutes", 60) ?: 60
                InfoRow(
                    "Status",
                    when {
                        err != null -> err
                        cond != null -> t(watchCondLabel(cond)) + (temp?.let { " · ${it.roundToInt()}°" } ?: "")
                        else -> t("Belum ada pengiriman")
                    },
                    if (err != null) MaterialTheme.colorScheme.error else null,
                )
                w?.str("lastLocationName")?.let { InfoRow("Lokasi di jam", it) }
                if (pushAt > 0L) InfoRow("Terakhir dikirim", hhmm(pushAt * 1000L))
                InfoRow("Kirim otomatis", if (enabled) t("Aktif") + " · " + t("tiap") + " $interval " + t("menit") else t("Mati"))
                Button(
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !busy && !watchBusy && savedLat != null && savedLon != null,
                    onClick = { if (savedLat != null && savedLon != null) onWeatherToWatch(savedLat, savedLon, "Lokasi latihan") },
                ) { Text(if (watchBusy) "Mengirim…" else "Kirim lokasi & cuaca ke jam") }
                if (watchNote.isNotBlank()) {
                    Text(watchNote, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun InfoChip(text: String) {
    Box(
        Modifier.clip(CircleShape).background(MaterialTheme.colorScheme.onSurface.copy(alpha = .08f)).padding(horizontal = 10.dp, vertical = 5.dp),
    ) { Text(text, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 1) }
}

@Composable
private fun InfoRow(label: String, value: String, valueColor: Color? = null) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            value, modifier = Modifier.weight(1f), textAlign = TextAlign.End, style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold, color = valueColor ?: Color.Unspecified,
        )
    }
}
