package com.endurancevault.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.data.MapStyle
import com.endurancevault.app.data.TerrainTexture
import com.endurancevault.app.data.TerrainBuilder
import com.endurancevault.app.data.TerrainScene
import com.endurancevault.app.domain.ActDetail
import com.endurancevault.app.domain.GhostInfo
import com.endurancevault.app.domain.Js
import com.endurancevault.app.domain.RouteVideoCamera
import com.endurancevault.app.domain.RouteVideoColors
import com.endurancevault.app.domain.RouteVideoFormat
import com.endurancevault.app.domain.RouteVideoKeys
import com.endurancevault.app.domain.RouteVideoLayout
import com.endurancevault.app.domain.RouteVideoPresets
import com.endurancevault.app.domain.RouteVideoPrefs
import com.endurancevault.app.domain.RouteVideoRace
import com.endurancevault.app.domain.RouteVideoText
import com.endurancevault.app.domain.RouteVideoTimeline
import com.endurancevault.app.domain.RouteVideoTrack
import com.endurancevault.app.domain.asPreset
import com.endurancevault.app.domain.withPreset
import com.endurancevault.app.ui.UiState
import com.endurancevault.app.ui.i18n.Text
import com.endurancevault.app.ui.sticker.StickerFontStore
import com.endurancevault.app.ui.sticker.StickerFonts
import com.endurancevault.app.ui.sticker.StickerPrefsStore
import com.endurancevault.app.ui.video.PreviewFrame
import com.endurancevault.app.ui.video.PreviewHost
import com.endurancevault.app.ui.video.RenderState
import com.endurancevault.app.ui.video.RouteVideoEncoder
import com.endurancevault.app.ui.video.RouteVideoIo
import com.endurancevault.app.ui.video.RouteVideoJobs
import com.endurancevault.app.ui.video.RouteVideoOverlay
import com.endurancevault.app.ui.video.RouteVideoPrefsStore
import java.io.File
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.roundToInt

private val LAY_SIZE_RANGE = RouteVideoLayout.MIN_SIZE.toFloat()..RouteVideoLayout.MAX_SIZE.toFloat()
private val TEXT_COLORS = listOf("Putih" to "#FFFFFF", "Hitam" to "#111111", "Lime" to "#C6F432", "Oranye" to "#FF7A1A", "Cyan" to "#27D3FF", "Kuning" to "#FFD60A", "Merah" to "#FF3B4E")
private val HEX_RE = Regex("#[0-9a-fA-F]{6}")
private val LINE_COLORS = listOf("Lime" to "#C6F432", "Oranye" to "#FF7A1A", "Cyan" to "#27D3FF", "Merah" to "#FF3B4E", "Putih" to "#FFFFFF")

/**
 * Video rute 3D: peta satelit berelief sesuai elevasi, rute tergambar bertahap (bisa berwarna menurut HR, pace, atau
 * gradien), bendera km/start/finish/puncak, dan panel data yang posisi dan ukurannya bisa diatur dengan menggeser di
 * pratinjau. Bisa membalap aktivitas lain (ghost). Render berjalan di latar belakang dengan notifikasi progres.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RouteVideoScreen(state: UiState, id: Long, load: suspend (ActivityEntity) -> ActDetail?, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val appCtx = ctx.applicationContext
    val scope = rememberCoroutineScope()
    val store = remember { RouteVideoPrefsStore(appCtx) }
    var prefs by remember { mutableStateOf(store.load()) }
    fun update(p: RouteVideoPrefs, persist: Boolean = true) { prefs = p.sanitized(); if (persist) store.save(prefs) }
    fun setLayout(f: (RouteVideoLayout) -> RouteVideoLayout) = update(prefs.withLayout(f))
    val lay = prefs.layout

    // Pratinjau memakai thread GL sendiri; render video punya thread dan konteks sendiri di RouteVideoJobs.
    val host = remember { PreviewHost() }
    DisposableEffect(Unit) { onDispose { host.close() } }

    val stk = remember { StickerPrefsStore(appCtx).load() }
    val fontStore = remember { StickerFontStore(appCtx) }
    val fonts = remember(stk.fontNum, stk.fontBody) { StickerFonts(fontStore.typeface(stk.fontNum), fontStore.typeface(stk.fontBody)) }

    var pos by remember { mutableStateOf(0.5f) }
    var status by remember { mutableStateOf("Menyiapkan peta…") }
    var ghostId by remember { mutableStateOf<Long?>(null) }
    var ghostMsg by remember { mutableStateOf("") }
    var showGhostPicker by remember { mutableStateOf(false) }
    var showSave by remember { mutableStateOf(false) }
    var showManage by remember { mutableStateOf(false) }
    var presetName by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var prefetchMsg by remember { mutableStateOf("") }
    var prefetching by remember { mutableStateOf(false) }
    var askedPerm by remember { mutableStateOf(false) }
    var stilling by remember { mutableStateOf(false) }
    var stillFile by remember { mutableStateOf<File?>(null) }

    val e = state.activities.firstOrNull { it.id == id }
    fun nameOf(a: ActivityEntity) = a.name.ifBlank { if (a.type == "bike") "Gowes" else "Lari" }

    val loaded by produceState<Pair<Boolean, ActDetail?>>(false to null, e?.id, e?.detailFile, e?.km, e?.durationSec, e?.type) {
        value = true to e?.let { load(it) }
    }
    val track = remember(loaded.second, e?.name) {
        val d = loaded.second
        if (e != null && d != null) RouteVideoTrack.from(d, nameOf(e), RouteVideoText.dateId(e.dateIso)) else null
    }

    // Ghost: pasangan (id yang selesai dimuat, jejaknya).
    val ghostEntity = state.activities.firstOrNull { it.id == ghostId }
    val ghostRes by produceState<Pair<Long?, RouteVideoTrack?>>(null to null, ghostId) {
        val ge = ghostEntity
        value = if (ge == null) null to null
        else ge.id to load(ge)?.let { RouteVideoTrack.from(it, nameOf(ge), RouteVideoText.dateId(ge.dateIso)) }
    }
    val ghostTrack = if (ghostId != null && ghostRes.first == ghostId) ghostRes.second else null
    LaunchedEffect(ghostRes, ghostId) {
        if (ghostId != null && ghostRes.first == ghostId && ghostRes.second == null) {
            ghostMsg = "Aktivitas itu tidak punya rute GPS dan data per detik, jadi tidak bisa jadi ghost."
            ghostId = null
        }
    }

    // Medan 3D: dibangun ulang bila jejak atau ghost berubah; pasangan (jejak, medan) menandai medan milik jejak yang mana.
    // Tekstur peta di atas relief: satelit atau kontur (diingat antar sesi).
    var texStyle by remember {
        mutableStateOf(
            if (appCtx.getSharedPreferences("route_video_map", android.content.Context.MODE_PRIVATE).getString("tex", "SATELLITE") == "CONTOUR") MapStyle.CONTOUR else MapStyle.SATELLITE,
        )
    }
    TerrainTexture.style = texStyle
    val sceneRes by produceState<Pair<RouteVideoTrack?, TerrainScene?>>(null to null, track, ghostTrack, texStyle) {
        val t = track
        value = if (t == null) null to null else t to TerrainBuilder.build(appCtx, t, ghostTrack) { status = it }
    }
    val scene = if (track != null && sceneRes.first === track) sceneRes.second else null
    val sceneLoading = track != null && sceneRes.first !== track
    val race = remember(track, ghostTrack, scene) {
        if (track != null && ghostTrack != null && scene?.ghostX != null) RouteVideoRace(track, ghostTrack) else null
    }

    val accent = remember(prefs.lineColor) { RouteVideoOverlay.accentOf(prefs) }
    val colors = remember(scene, track, prefs.lineMode, accent) {
        if (scene != null && track != null) RouteVideoColors.colors(track, prefs.lineMode, accent, scene.routeFrac) else IntArray(0)
    }
    val (pw, ph) = RouteVideoFormat.previewSize(prefs.aspect)
    val frameRes by produceState<Pair<PreviewFrame?, String?>>(
        null to null, scene, prefs.tilt, prefs.exaggeration, prefs.orbit, pos, accent, prefs.lineMode, prefs.aspect, race, colors,
        prefs.hillshade, prefs.fog, prefs.lineWidth, prefs.cameraMode, prefs.summary, prefs.durationSec,
    ) {
        val sc = scene
        if (sc == null) value = null to null
        else {
            val cam = RouteVideoCamera.at(RouteVideoTimeline.at(pos.toDouble(), prefs).p, prefs, race, track)
            val key = "${prefs.lineMode}/$accent"
            val ex = prefs.exaggeration.toFloat()
            val shade = prefs.hillshade; val fogOn = prefs.fog; val lw = prefs.lineWidth / 100f
            value = withContext(host.dispatcher) {
                val r = runCatching { host.frame(pw, ph, sc, ex, cam, colors, key, accent, shade, fogOn, lw) }
                if (r.isSuccess) Pair<PreviewFrame?, String?>(r.getOrNull(), null)
                else Pair<PreviewFrame?, String?>(null, r.exceptionOrNull()?.message ?: "OpenGL gagal")
            }
        }
    }
    val composed = remember(frameRes.first, prefs, pos, fonts, track, race, ghostTrack, scene) {
        val fr = frameRes.first; val t = track; val sc = scene
        if (fr == null || t == null || sc == null) null
        else fr.bitmap.copy(Bitmap.Config.ARGB_8888, true)?.let { bmp ->
            val pt = RouteVideoTimeline.at(pos.toDouble(), prefs)
            val cam = RouteVideoCamera.at(pt.p, prefs, race, t)
            val st = t.statsAt(cam.routeFrac, prefs.live)
            val marks = RouteVideoOverlay.marksFor(sc, fr.points, t, prefs, cam.routeFrac)
            val gi = if (race != null && ghostTrack != null) GhostInfo(ghostTrack.title, race.gapSeconds(cam.routeFrac)) else null
            RouteVideoOverlay.draw(AndroidCanvas(bmp), bmp.width, bmp.height, prefs, t, st, cam.routeFrac, fonts, marks, gi, pt.summaryAlpha)
            bmp
        }
    }
    // Render latar belakang
    val job by RouteVideoJobs.state.collectAsState()
    val myKey = id.toString()
    val bgRef = rememberUpdatedState(prefs.bgRender)
    DisposableEffect(Unit) { onDispose { if (!bgRef.value) RouteVideoJobs.cancelFor(myKey) } }
    val startRender = {
        val a = e; val t = track; val sc = scene
        if (a != null && t != null && sc != null) {
            RouteVideoJobs.clearResult()
            val out = File(RouteVideoIo.cacheDir(appCtx), "rute-${a.dateIso.take(10)}-${a.id}.mp4")
            val started = RouteVideoJobs.start(appCtx, myKey, nameOf(a), sc, t, ghostTrack.takeIf { sc.ghostX != null }, prefs, fonts, out, prefs.bgRender)
            msg = if (started) "" else "Masih ada render lain yang berjalan."
        }
    }
    val startRef = rememberUpdatedState(startRender)
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { startRef.value() }

    Column(
        Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton(onClick = onBack) { Text("‹ Kembali") }
            Text("Video rute 3D", style = MaterialTheme.typography.titleMedium)
        }
        if (e == null) { Text("Aktivitas tidak ditemukan."); return@Column }
        if (!loaded.first) { CircularProgressIndicator(Modifier.size(24.dp)); return@Column }
        if (track == null) {
            Text("Video 3D butuh rute GPS dan data per detik. Aktivitas ini tidak punya keduanya (mis. latihan indoor atau data lama).")
            return@Column
        }
        if (scene == null) {
            if (sceneLoading) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(22.dp)); Text(status)
                }
            } else Text("Peta 3D gagal disiapkan. Coba lagi saat tersambung internet.")
            return@Column
        }

        // Pratinjau dan slider waktu disematkan di atas (tidak ikut menggulir); tingginya dibatasi ±38% layar
        // supaya menu pengaturan di bawahnya tetap punya ruang.
        BoxWithConstraints(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        val previewRatio = RouteVideoFormat.ratio(prefs.aspect)
        val maxPreviewH = (LocalConfiguration.current.screenHeightDp * 0.38f).dp
        val previewW = minOf(maxWidth, maxPreviewH * previewRatio)
        Box(
            Modifier.width(previewW).aspectRatio(previewRatio)
                .clip(RoundedCornerShape(12.dp)).background(Color.Black),
            contentAlignment = Alignment.Center,
        ) {
            val c = composed
            if (c == null) { if (frameRes.second == null) CircularProgressIndicator(Modifier.size(28.dp)) }
            else Image(c.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
        }
        }
        RvSlider("Posisi pratinjau (waktu video)", pos, 0f..1f, "${(pos * RouteVideoTimeline.totalSec(prefs)).roundToInt()} dtk") { pos = it }

        // ---- Semua yang di bawah ini menggulir sendiri; pratinjau di atas tetap diam ----
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
        if (!scene.demOk) RvNote("Data elevasi belum terunduh (offline?), jadi medan tampil datar. Buka lagi saat online.")
        if (scene.satellite == null) RvNote("Citra peta belum terunduh (offline?), jadi medan tampil polos. Buka lagi saat online.")
        if (ghostId != null && ghostTrack == null) RvNote("Memuat ghost…")
        if (ghostTrack != null && scene.ghostX == null) RvNote("Memuat ulang peta untuk ghost…")
        frameRes.second?.let { RvNote("Pratinjau 3D gagal: $it") }

        // ---- Render ----
        val running = job as? RenderState.Running
        val done = (job as? RenderState.Done)?.takeIf { it.key == myKey }
        val failed = (job as? RenderState.Failed)?.takeIf { it.key == myKey }
        if (running != null) {
            LinearProgressIndicator(progress = { running.progress }, modifier = Modifier.fillMaxWidth())
            Text(
                if (running.key == myKey) "Membuat video… ${(running.progress * 100).roundToInt()}%. Boleh tutup layar ini; render lanjut di latar belakang."
                else "Masih membuat video “${running.label}” (${(running.progress * 100).roundToInt()}%).",
                style = MaterialTheme.typography.bodyMedium,
            )
            if (running.key == myKey) OutlinedButton(onClick = { RouteVideoJobs.cancel() }) { Text("Batal") }
        } else {
            val (vw, vh) = RouteVideoFormat.size(prefs.aspect, prefs.quality)
            Button(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    if (prefs.bgRender && Build.VERSION.SDK_INT >= 33 && !askedPerm &&
                        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                    ) { askedPerm = true; permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
                    else startRender()
                },
            ) { Text("Buat video ($vw×$vh)") }
            if (failed != null) Text("Gagal membuat video: ${failed.message}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            if (done != null) {
                Text("Video siap.", style = MaterialTheme.typography.bodyMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        RouteVideoIo.saveToGallery(appCtx, done.file, done.file.name)
                            .onSuccess { msg = "Tersimpan di $it." }.onFailure { msg = "Gagal menyimpan: ${it.message}" }
                    }) { Text("Simpan ke galeri") }
                    OutlinedButton(onClick = { RouteVideoIo.share(ctx, done.file).onFailure { msg = "Gagal membagikan: ${it.message}" } }) { Text("Bagikan") }
                }
            }
        }
        if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(enabled = !stilling, onClick = {
                val a = e; val t = track; val sc = scene
                if (a != null && t != null && sc != null) scope.launch {
                    stilling = true; stillFile = null
                    try {
                        val posNow = pos.toDouble(); val snap = prefs
                        val name = "foto-rute-${a.dateIso.take(10)}-${a.id}-${(posNow * 100).roundToInt()}.jpg"
                        val r = withContext(host.dispatcher) {
                            RouteVideoEncoder.renderStill(sc, t, ghostTrack.takeIf { sc.ghostX != null }, snap, fonts, posNow)
                                .map { bmp -> val f = RouteVideoIo.writePhoto(appCtx, bmp, name); bmp.recycle(); f }
                        }
                        r.onSuccess { stillFile = it; msg = "Foto siap." }.onFailure { msg = "Gagal membuat foto: ${it.message}" }
                    } finally { stilling = false }
                }
            }) { Text(if (stilling) "Membuat foto…" else "Foto bingkai ini") }
            val sf = stillFile
            if (sf != null) {
                OutlinedButton(onClick = {
                    RouteVideoIo.savePhotoToGallery(appCtx, sf, sf.name)
                        .onSuccess { msg = "Tersimpan di $it." }.onFailure { msg = "Gagal menyimpan: ${it.message}" }
                }) { Text("Simpan foto") }
                OutlinedButton(onClick = { RouteVideoIo.share(ctx, sf, "Bagikan foto", "image/jpeg").onFailure { msg = "Gagal membagikan: ${it.message}" } }) { Text("Bagikan foto") }
            }
        }
        FilterChip(
            selected = prefs.bgRender, onClick = { update(prefs.copy(bgRender = !prefs.bgRender)) },
            label = { Text("Lanjut di latar belakang (notifikasi)") },
        )
        if (!prefs.bgRender) {
            Text("Mati: render berhenti bila layar ini ditutup dan tidak ada notifikasi progres.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        // ---- Tata letak (preset) ----
        RvSection("Tata letak", "Pilih susunan siap pakai atau simpan susunanmu sendiri.") {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                (RouteVideoPresets.BUILT_IN + prefs.presets).forEach { pr ->
                    FilterChip(
                        selected = prefs.asPreset(pr.name) == pr,
                        onClick = { update(prefs.withPreset(pr)) },
                        label = { Text(pr.name) },
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { presetName = ""; showSave = true }) { Text("Simpan tata letak ini") }
                if (prefs.presets.isNotEmpty()) OutlinedButton(onClick = { showManage = true }) { Text("Hapus…") }
            }
        }

        // ---- Judul dan ringkasan (posisi tetap di kiri atas) ----
        RvSection("Judul dan ringkasan", "Selalu di kiri atas video; hanya ukuran dan warna huruf yang bisa diatur. Kosongkan judul untuk memakai nama aktivitas.") {
            OutlinedTextField(
                value = prefs.titleText, onValueChange = { update(prefs.copy(titleText = it.take(60))) },
                label = { Text("Judul") }, placeholder = { Text(nameOf(e)) }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = prefs.subtitle, onValueChange = { update(prefs.copy(subtitle = it.take(80))) },
                label = { Text("Ringkasan (baris kedua: lokasi, nama event, dll.)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            )
            FilterChip(selected = prefs.showDate, onClick = { update(prefs.copy(showDate = !prefs.showDate)) }, label = { Text("Tampilkan tanggal") })
            RvSlider("Ukuran huruf", lay.titleSize.toFloat(), LAY_SIZE_RANGE, "${lay.titleSize}%") { setLayout { l -> l.copy(titleSize = it.roundToInt()) } }
            RvColorPick("Warna huruf", lay.titleColor) { c -> setLayout { l -> l.copy(titleColor = c) } }
        }

        // ---- Data di bawah video ----
        RvSection("Data di bawah video", "Pilih data yang tampil. Susunannya selalu di bagian bawah video.") {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                RouteVideoKeys.STAT.forEach { k ->
                    val on = k in lay.stats
                    FilterChip(
                        selected = on,
                        onClick = { setLayout { l -> l.copy(stats = RouteVideoKeys.STAT.filter { if (it == k) !on else it in l.stats }) } },
                        label = { Text(RouteVideoKeys.name(k)) },
                    )
                }
            }
            RvLabel("Susunan")
            RvChips(listOf("rows" to "Baris (1–2 baris, video vertikal)", "cols" to "Kolom (2–4 kolom, video horizontal)"), lay.statMode) { m ->
                setLayout { l -> l.copy(statMode = m) }
            }
            if (lay.statMode == "cols") {
                RvSlider("Jumlah kolom", lay.statCols.toFloat(), RouteVideoLayout.MIN_COLS.toFloat()..RouteVideoLayout.MAX_COLS.toFloat(), "${lay.statCols}") {
                    setLayout { l -> l.copy(statCols = it.roundToInt()) }
                }
            } else {
                RvSlider("Jumlah baris", lay.statRows.toFloat(), RouteVideoLayout.MIN_ROWS.toFloat()..RouteVideoLayout.MAX_ROWS.toFloat(), "${lay.statRows}") {
                    setLayout { l -> l.copy(statRows = it.roundToInt()) }
                }
            }
            RvSlider("Ukuran huruf", lay.statSize.toFloat(), LAY_SIZE_RANGE, "${lay.statSize}%") { setLayout { l -> l.copy(statSize = it.roundToInt()) } }
            Text("Huruf mengecil otomatis bila tidak muat di kolomnya. Kurangi jumlah data atau kolom bila ingin huruf lebih besar.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            RvColorPick("Warna huruf", lay.statColor) { c -> setLayout { l -> l.copy(statColor = c) } }
            RvSlider("Padding horizontal (antar kolom)", lay.padX.toFloat(), 0f..RouteVideoLayout.MAX_PAD.toFloat(), "${lay.padX}") { setLayout { l -> l.copy(padX = it.roundToInt()) } }
            RvSlider("Padding vertikal (antar baris)", lay.padY.toFloat(), 0f..RouteVideoLayout.MAX_PAD.toFloat(), "${lay.padY}") { setLayout { l -> l.copy(padY = it.roundToInt()) } }
        }

        // ---- Grafik ----
        RvSection("Grafik", "Tepat di atas data. Tombol tukar memindahkan grafik ke bawah data.") {
            FilterChip(selected = lay.showChart, onClick = { setLayout { l -> l.copy(showChart = !l.showChart) } }, label = { Text("Tampilkan grafik") })
            if (lay.showChart) {
                RvChips(RouteVideoKeys.CHARTS.map { it to RouteVideoKeys.name(it) }, lay.chartKind) { k -> setLayout { l -> l.copy(chartKind = k) } }
                RvSlider("Lebar grafik", lay.chartW.toFloat(), RouteVideoLayout.MIN_CHART_W.toFloat()..100f, "${lay.chartW}%") { setLayout { l -> l.copy(chartW = it.roundToInt()) } }
                RvSlider("Tinggi grafik", lay.chartH.toFloat(), RouteVideoLayout.MIN_CHART_H.toFloat()..RouteVideoLayout.MAX_CHART_H.toFloat(), "${lay.chartH}") { setLayout { l -> l.copy(chartH = it.roundToInt()) } }
                RvSlider("Jarak grafik ke data", lay.chartGap.toFloat(), 0f..RouteVideoLayout.MAX_PAD.toFloat(), "${lay.chartGap}") { setLayout { l -> l.copy(chartGap = it.roundToInt()) } }
            }
            FilterChip(selected = lay.legend, onClick = { setLayout { l -> l.copy(legend = !l.legend) } }, label = { Text("Legenda warna garis") })
            if (prefs.lineMode == "solid" && lay.legend) {
                Text("Legenda hanya tampil bila warna garis memakai data (HR, pace, atau gradien).", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            OutlinedButton(onClick = { setLayout { l -> l.copy(swap = !l.swap) } }) { Text("⇅ Tukar posisi grafik dan data") }
            Text(
                if (lay.swap) "Sekarang: data di atas, grafik di bawah." else "Sekarang: grafik di atas, data di bawah.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        // ---- Margin ----
        RvSection("Margin dan latar", "Jarak blok grafik dan data dari tepi video, serta gradasi di belakangnya agar teks lebih jelas.") {
            RvSlider("Margin kiri dan kanan", lay.marginX.toFloat(), 0f..RouteVideoLayout.MAX_MARGIN_X.toFloat(), "${lay.marginX}") { setLayout { l -> l.copy(marginX = it.roundToInt()) } }
            RvSlider("Margin bawah", lay.marginBottom.toFloat(), 0f..RouteVideoLayout.MAX_MARGIN_BOTTOM.toFloat(), "${lay.marginBottom}") { setLayout { l -> l.copy(marginBottom = it.roundToInt()) } }
            FilterChip(selected = lay.scrim, onClick = { setLayout { l -> l.copy(scrim = !l.scrim) } }, label = { Text("Latar gradasi tipis di bawah") })
            if (lay.scrim) {
                RvSlider("Kepekatan gradasi", lay.scrimOpacity.toFloat(), 0f..100f, "${lay.scrimOpacity}%") { setLayout { l -> l.copy(scrimOpacity = it.roundToInt()) } }
            }
            OutlinedButton(onClick = { setLayout { RouteVideoLayout() } }) { Text("Reset semua tata letak") }
        }

        // ---- Format ----
        RvSection("Format", "Rasio 9:16 untuk Story/Reels, 4:5 dan 1:1 untuk feed, 16:9 untuk layar lebar.") {
            RvChips(RouteVideoFormat.ASPECTS.map { it to it }, prefs.aspect) { update(prefs.copy(aspect = it)) }
            RvChips(listOf("hd" to "HD (1080 px)", "sd" to "Ringan (720 px)"), prefs.quality) { update(prefs.copy(quality = it)) }
        }

        // ---- Garis rute ----
        RvSection("Garis rute", null) {
            RvLabel("Warna menurut")
            RvChips(RouteVideoColors.MODES.map { it to RouteVideoColors.modeName(it) }, prefs.lineMode) { update(prefs.copy(lineMode = it)) }
            RvLabel(if (prefs.lineMode == "solid") "Warna garis" else "Warna penanda posisi")
            RvChips(LINE_COLORS.map { it.second to it.first }, LINE_COLORS.firstOrNull { it.second.equals(prefs.lineColor, true) }?.second ?: "") { update(prefs.copy(lineColor = it)) }
            RvSlider("Ketebalan garis", prefs.lineWidth.toFloat(), 50f..250f, "${prefs.lineWidth}%") { update(prefs.copy(lineWidth = it.roundToInt())) }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = prefs.kmMarkers, onClick = { update(prefs.copy(kmMarkers = !prefs.kmMarkers)) }, label = { Text("Bendera per km") })
                FilterChip(selected = prefs.flagEnds, onClick = { update(prefs.copy(flagEnds = !prefs.flagEnds)) }, label = { Text("Start dan finish") })
                FilterChip(selected = prefs.flagPeak, onClick = { update(prefs.copy(flagPeak = !prefs.flagPeak)) }, label = { Text("Puncak") })
                FilterChip(selected = prefs.flagSteep, onClick = { update(prefs.copy(flagSteep = !prefs.flagSteep)) }, label = { Text("Tanjakan terberat") })
                FilterChip(selected = prefs.flagFast, onClick = { update(prefs.copy(flagFast = !prefs.flagFast)) }, label = { Text("1 km tercepat") })
                FilterChip(selected = prefs.flagHrMax, onClick = { update(prefs.copy(flagHrMax = !prefs.flagHrMax)) }, label = { Text("HR tertinggi") })
            }
        }

        // ---- Ghost ----
        RvSection("Balapan dengan ghost", "Bandingkan dengan aktivitas lain di rute serupa. Keduanya berjalan menurut waktu yang sama.") {
            if (ghostTrack != null) {
                Text(
                    "Ghost: ${ghostTrack.title} · ${RouteVideoText.dateId(ghostEntity?.dateIso ?: "")} · ${Js.fmtKm(ghostTrack.totalM / 1000.0)} km · ${Js.durStr(ghostTrack.totalSec / 60.0)}",
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { ghostMsg = ""; showGhostPicker = true }) { Text(if (ghostTrack != null) "Ganti ghost" else "Pilih ghost") }
                if (ghostId != null) OutlinedButton(onClick = { ghostId = null; ghostMsg = "" }) { Text("Hapus ghost") }
            }
            if (ghostMsg.isNotEmpty()) RvNote(ghostMsg)
        }

        // ---- Peta 3D ----
        RvSection("Peta 3D", null) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(MapStyle.SATELLITE to "Tekstur satelit", MapStyle.CONTOUR to "Tekstur kontur").forEach { (st, n) ->
                    FilterChip(
                        selected = texStyle == st,
                        onClick = {
                            texStyle = st
                            appCtx.getSharedPreferences("route_video_map", android.content.Context.MODE_PRIVATE).edit().putString("tex", st.name).apply()
                        },
                        label = { Text(n) },
                    )
                }
            }
            RvSlider("Kemiringan kamera", prefs.tilt.toFloat(), 20f..80f, "${prefs.tilt}°") { update(prefs.copy(tilt = it.roundToInt())) }
            RvSlider("Skala elevasi (1× = sesuai aslinya)", prefs.exaggeration.toFloat(), 1f..4f, String.format(java.util.Locale.US, "%.1f×", prefs.exaggeration)) {
                update(prefs.copy(exaggeration = (it * 10).roundToInt() / 10.0))
            }
            RvLabel("Mode kamera")
            RvChips(RouteVideoKeys.CAMERA_MODES.map { it to RouteVideoKeys.cameraName(it) }, prefs.cameraMode) { update(prefs.copy(cameraMode = it)) }
            if (prefs.cameraMode == "orbit") {
                RvSlider("Putaran kamera", prefs.orbit.toFloat(), 0f..180f, "${prefs.orbit}°") { update(prefs.copy(orbit = it.roundToInt())) }
            } else if (prefs.cameraMode == "chase") {
                Text("Kamera mengikuti arah lari dari belakang pelari; kemiringan dari slider di atas.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                Text("Kamera menghadap lurus ke bawah dengan utara di atas.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            RvSlider("Durasi video" + if (prefs.summary) " (belum termasuk 3 dtk ringkasan)" else "", prefs.durationSec.toFloat(), 6f..40f, "${prefs.durationSec} dtk") { update(prefs.copy(durationSec = it.roundToInt())) }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = prefs.hillshade, onClick = { update(prefs.copy(hillshade = !prefs.hillshade)) }, label = { Text("Bayangan relief") })
                FilterChip(selected = prefs.fog, onClick = { update(prefs.copy(fog = !prefs.fog)) }, label = { Text("Kabut jarak") })
            }
        }

        // ---- Tampilan ----
        RvSection("Tampilan", null) {
            RvLabel("Angka")
            RvChips(listOf("live" to "Berjalan", "total" to "Total / rata-rata"), if (prefs.live) "live" else "total") { update(prefs.copy(live = it == "live")) }
            FilterChip(selected = prefs.summary, onClick = { update(prefs.copy(summary = !prefs.summary)) }, label = { Text("Kartu ringkasan di akhir video") })
        }

        // ---- Offline ----
        RvSection("Peta offline", "Unduh ubin satelit dan elevasi sekarang supaya video bisa dibuat tanpa internet. Tersimpan di cache aplikasi (sistem bisa membersihkannya saat penyimpanan penuh).") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(enabled = !prefetching, onClick = {
                    scope.launch {
                        prefetching = true
                        try {
                            val failedTiles = TerrainBuilder.prefetch(appCtx, listOfNotNull(track, ghostTrack)) { prefetchMsg = it }
                            prefetchMsg = if (failedTiles == 0) "Peta aktivitas ini tersimpan untuk offline." else "$failedTiles ubin gagal diunduh. Coba lagi saat sinyal baik."
                        } finally { prefetching = false }
                    }
                }) { Text("Aktivitas ini") }
                OutlinedButton(enabled = !prefetching, onClick = {
                    scope.launch {
                        prefetching = true
                        try {
                            val recent = state.activities.filter { it.detailFile != null && it.km > 0 }.sortedByDescending { it.dateIso }.take(10)
                            val tracks = ArrayList<RouteVideoTrack>()
                            recent.forEachIndexed { i, a ->
                                prefetchMsg = "Membaca aktivitas ${i + 1}/${recent.size}…"
                                load(a)?.let { d -> RouteVideoTrack.from(d, nameOf(a), "")?.let { tracks.add(it) } }
                            }
                            val failedTiles = TerrainBuilder.prefetch(appCtx, tracks) { prefetchMsg = it }
                            prefetchMsg = if (failedTiles == 0) "Peta ${tracks.size} aktivitas terakhir tersimpan untuk offline." else "$failedTiles ubin gagal diunduh. Coba lagi saat sinyal baik."
                        } finally { prefetching = false }
                    }
                }) { Text("10 aktivitas terakhir") }
            }
            if (prefetching) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            if (prefetchMsg.isNotEmpty()) Text(prefetchMsg, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Text(
            "Peta satelit © Esri, Maxar, Earthstar Geographics · elevasi dari AWS Terrain Tiles (Mapzen, SRTM, dll.).",
            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        // ---- Dialog ----
        if (showSave) {
            val clash = RouteVideoPresets.isBuiltIn(presetName.trim())
            AlertDialog(
                onDismissRequest = { showSave = false },
                title = { Text("Simpan tata letak") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = presetName, onValueChange = { presetName = it.take(24) }, label = { Text("Nama") }, singleLine = true)
                        if (clash) RvNote("Nama itu dipakai tata letak bawaan.")
                        Text("Menyimpan susunan judul, grafik, dan data (ukuran, warna, margin, padding), mode angka, serta pilihan garis dan bendera.", style = MaterialTheme.typography.bodySmall)
                    }
                },
                confirmButton = {
                    TextButton(enabled = presetName.isNotBlank() && !clash, onClick = {
                        val pr = prefs.asPreset(presetName.trim())
                        update(prefs.copy(presets = (prefs.presets.filter { it.name != pr.name } + pr).takeLast(12)))
                        showSave = false
                    }) { Text("Simpan") }
                },
                dismissButton = { TextButton(onClick = { showSave = false }) { Text("Batal") } },
            )
        }
        if (showManage) {
            AlertDialog(
                onDismissRequest = { showManage = false },
                title = { Text("Hapus tata letak") },
                text = {
                    Column(Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        if (prefs.presets.isEmpty()) Text("Tidak ada tata letak buatanmu.")
                        prefs.presets.forEach { pr ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text(pr.name, Modifier.weight(1f))
                                TextButton(onClick = { update(prefs.copy(presets = prefs.presets.filter { it.name != pr.name })) }) { Text("Hapus") }
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showManage = false }) { Text("Selesai") } },
            )
        }
        if (showGhostPicker) {
            val candidates = state.activities
                .filter { it.id != e.id && it.type == e.type && it.detailFile != null && it.km > 0 && abs(it.km - e.km) <= e.km * 0.3 }
                .sortedByDescending { it.dateIso }.take(30)
            AlertDialog(
                onDismissRequest = { showGhostPicker = false },
                title = { Text("Pilih ghost") },
                text = {
                    Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("Aktivitas sejenis dengan jarak serupa (±30%). Pilih yang rutenya sama agar balapannya berarti.", style = MaterialTheme.typography.bodySmall)
                        if (candidates.isEmpty()) Text("Belum ada aktivitas yang cocok.", style = MaterialTheme.typography.bodyMedium)
                        candidates.forEach { a ->
                            Text(
                                "${RouteVideoText.dateId(a.dateIso)} · ${nameOf(a)} · ${Js.fmtKm(a.km)} km · ${Js.durStr(a.durationSec / 60.0)}",
                                Modifier.fillMaxWidth().clickable { ghostId = a.id; ghostMsg = ""; showGhostPicker = false }.padding(vertical = 10.dp),
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showGhostPicker = false }) { Text("Batal") } },
            )
        }
        }
    }
}

@Composable
private fun RvLabel(t: String) = Text(t, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

@Composable
private fun RvNote(t: String) = Text(t, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RvChips(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (k, n) -> FilterChip(selected = selected == k, onClick = { onSelect(k) }, label = { Text(n) }) }
    }
}

@Composable
private fun RvSection(title: String, sub: String?, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        content()
    }
}

@Composable
private fun RvSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, valueText: String, onChange: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            RvLabel(label); RvLabel(valueText)
        }
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range)
    }
}

/** Pilihan warna huruf: palet siap pakai ditambah kolom kode hex (#RRGGBB) untuk warna bebas. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RvColorPick(label: String, value: String, onChange: (String) -> Unit) {
    RvLabel(label)
    RvChips(TEXT_COLORS.map { it.second to it.first }, TEXT_COLORS.firstOrNull { it.second.equals(value, true) }?.second ?: "") { onChange(it) }
    var text by remember(value) { mutableStateOf(value) }
    OutlinedTextField(
        value = text,
        onValueChange = { t ->
            val v = t.take(7).let { if (it.isNotEmpty() && !it.startsWith("#")) "#$it" else it }
            text = v
            if (HEX_RE.matches(v)) onChange(v.uppercase())
        },
        label = { Text("Kode warna (#RRGGBB)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
    )
}
