package com.endurancevault.app.domain

import com.google.gson.JsonObject
import com.google.gson.JsonParser
import java.util.Locale
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Video HUD: data lari yang bergerak (HR, pace, jarak, waktu, elevasi, kemiringan, kecepatan, posisi di rute) ditempel di atas
 * video POV dari galeri. Waktu video + offset sinkron = detik sejak lari dimulai, lalu detik itu diubah jadi keadaan lari
 * (jarak, pace, dst). Murni Kotlin supaya bisa dites JUnit; penggambaran dan ekspor ada di `ui/video/Hud*.kt`.
 */
data class HudPrefs(
    /** "two" = dua kolom (minimap + gauge), "min" = pace besar + satu baris angka. */
    val style: String = "two",
    val accent: String = "#FF6A13",
    val minimap: Boolean = true,
    val gauge: Boolean = true,
    /** Peredam gelap atas dan bawah (0..60). */
    val dim: Int = 25,
    /** Bawa suara asli video (hanya AAC dalam MP4/MOV). */
    val audio: Boolean = true,
) {
    fun sanitized(): HudPrefs = copy(
        style = if (style == "min") "min" else "two",
        accent = if (HEX.matches(accent)) accent.uppercase(Locale.US) else "#FF6A13",
        dim = dim.coerceIn(0, 60),
    )

    fun toJson(): String {
        val o = JsonObject()
        o.addProperty("style", style); o.addProperty("accent", accent); o.addProperty("minimap", minimap)
        o.addProperty("gauge", gauge); o.addProperty("dim", dim); o.addProperty("audio", audio)
        return o.toString()
    }

    companion object {
        private val HEX = Regex("#[0-9a-fA-F]{6}")
        val ACCENTS = listOf("Oranye" to "#FF6A13", "Lime" to "#CBFD00", "Putih" to "#FFFFFF", "Biru" to "#4CC3FF")

        fun fromJson(s: String?): HudPrefs {
            val d = HudPrefs()
            if (s.isNullOrBlank()) return d
            val o = runCatching { JsonParser.parseString(s).asJsonObject }.getOrNull() ?: return d
            fun str(k: String, def: String) = runCatching { o.get(k)?.takeIf { !it.isJsonNull }?.asString }.getOrNull() ?: def
            fun int(k: String, def: Int) = runCatching { o.get(k)?.takeIf { !it.isJsonNull }?.asInt }.getOrNull() ?: def
            fun bool(k: String, def: Boolean) = runCatching { o.get(k)?.takeIf { !it.isJsonNull }?.asBoolean }.getOrNull() ?: def
            return HudPrefs(
                style = str("style", d.style), accent = str("accent", d.accent), minimap = bool("minimap", d.minimap),
                gauge = bool("gauge", d.gauge), dim = int("dim", d.dim), audio = bool("audio", d.audio),
            ).sanitized()
        }
    }
}

/** Nilai teks HUD pada satu saat. [speedFrac] 0..1 untuk gauge. */
class HudValues(
    val hr: String, val km: String, val pace: String, val time: String, val ele: String, val slope: String,
    val speed: String, val speedFrac: Float, val kmOfTotal: String,
    /** Posisi di minimap (x, y dinormalkan 0..1 di kotak rute) dan jarak tempuh (0..1). */
    val frac: Double,
)

object VideoHud {
    /** Batas durasi video yang diproses (detik). */
    const val MAX_SEC = 900
    private const val MIN_OFFSET = -120

    /** Panjang lari dalam detik (waktu total bila ada, selain itu waktu gerak). */
    fun span(d: ActDetail): Int = max(60, ((if (d.elapsedMin > 0) d.elapsedMin else d.movingMin) * 60).roundToInt())

    fun offsetRange(spanSec: Int): IntRange = MIN_OFFSET..max(0, spanSec)

    /**
     * Tebak offset (detik sejak lari mulai) dari jam berkas video: aplikasi kamera mengisi waktu ubah saat rekaman selesai, jadi
     * awal rekaman = [fileTimeMs] - durasi. Null bila di luar jam lari atau datanya tidak ada.
     */
    fun guessOffset(startEpochMs: Long, fileTimeMs: Long, durSec: Double, spanSec: Int): Int? {
        if (startEpochMs <= 0L || fileTimeMs <= 0L || !(durSec > 0.0)) return null
        val off = ((fileTimeMs - durSec * 1000.0 - startEpochMs) / 1000.0).roundToInt()
        return if (off in offsetRange(spanSec)) off else null
    }

    /** Kecepatan puncak (km/jam) untuk skala gauge: dari pace tercepat pada jendela ±10 sampel, dibulatkan ke atas 15%. */
    fun vmax(t: RouteVideoTrack): Double {
        var best = 0.0
        var i = 0
        while (i + 10 < t.n) {
            val dd = t.dist[i + 10] - t.dist[i]; val dt = (t.sec[i + 10] - t.sec[i]).toDouble()
            if (dd >= 8.0 && dt > 0) { val v = dd / dt * 3.6; if (v > best) best = v }
            i += 5
        }
        val v = if (best > 0) best * 1.15 else 14.0
        return v.coerceIn(10.0, 45.0)
    }

    /** Keadaan lari pada detik video [tSec] dengan [offset] sinkron; di luar rentang lari ditahan di awal atau akhir. */
    fun stateAt(t: RouteVideoTrack, tSec: Double, offset: Int): FrameStats {
        val s = (tSec + offset).coerceIn(0.0, t.totalSec.toDouble())
        return t.statsAt(t.fracAtTime(s), true)
    }

    fun values(t: RouteVideoTrack, st: FrameStats, vmax: Double): HudValues {
        val pace = st.pace?.takeIf { it > 0 && it < 60 }
        val spd = if (pace != null) 60.0 / pace else 0.0
        val total = t.totalM / 1000.0
        val tm = RouteVideoText.cell("waktu", st, true, false)!!.value
        return HudValues(
            hr = st.hr?.takeIf { it > 0 }?.toString() ?: "--",
            km = dec(st.distM / 1000.0, 2),
            pace = if (pace != null) Js.paceStr(pace) else "--",
            time = tm,
            ele = st.ele?.let { it.roundToInt().toString() } ?: "--",
            slope = st.grade?.let { (if (it > 0.5) "+" else "") + it.roundToInt() } ?: "--",
            speed = if (spd > 0) dec(spd, 1) else "--",
            speedFrac = (spd / vmax).coerceIn(0.0, 1.0).toFloat(),
            kmOfTotal = dec(st.distM / 1000.0, 1) + " dari " + dec(total, 1),
            frac = st.frac,
        )
    }

    private fun dec(x: Double, dp: Int): String = String.format(Locale.US, "%.${dp}f", x).replace('.', ',')

    /** Titik rute untuk minimap, dinormalkan ke kotak 0..1 dengan rasio asli (lebar atau tinggi terpanjang = 1). */
    class MiniMap(val x: FloatArray, val y: FloatArray, val w: Float, val h: Float)

    fun miniMap(t: RouteVideoTrack, maxPoints: Int = 300): MiniMap {
        val step = max(1, t.n / maxPoints)
        val xs = ArrayList<Double>(); val ys = ArrayList<Double>()
        val lat0 = (t.lat.min() + t.lat.max()) / 2
        val kx = cos(Math.toRadians(lat0)).coerceAtLeast(0.05)
        var i = 0
        while (i < t.n) { xs.add(t.lon[i] * kx); ys.add(-t.lat[i]); i += step }
        xs.add(t.lon[t.n - 1] * kx); ys.add(-t.lat[t.n - 1])
        val x0 = xs.min(); val x1 = xs.max(); val y0 = ys.min(); val y1 = ys.max()
        val span = max(max(x1 - x0, y1 - y0), 1e-9)
        return MiniMap(
            FloatArray(xs.size) { ((xs[it] - x0) / span).toFloat() },
            FloatArray(ys.size) { ((ys[it] - y0) / span).toFloat() },
            ((x1 - x0) / span).toFloat(), ((y1 - y0) / span).toFloat(),
        )
    }

    /** Indeks titik minimap pada bagian jarak [frac] (0..1), dengan pecahan antar titik. */
    fun miniPos(m: MiniMap, frac: Double): Pair<Int, Float> {
        val n = m.x.size
        val f = frac.coerceIn(0.0, 1.0) * (n - 1)
        val i = min(n - 2, f.toInt()).coerceAtLeast(0)
        return i to (f - i).toFloat()
    }
}
