package com.endurancevault.app.ui.sticker

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas

/** Menyimpan judul kartu dan template terakhir yang dipakai. Judul kosong = bawaan "EnduranceVault". */
class ShareStatsPrefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("share_stats_prefs", Context.MODE_PRIVATE)

    var title: String
        get() = sp.getString("title", ShareBrand.DEFAULT_TITLE) ?: ShareBrand.DEFAULT_TITLE
        set(v) { sp.edit().putString("title", v.take(ShareBrand.MAX_LEN)).apply() }

    var template: ShareTemplate
        get() = runCatching { ShareTemplate.valueOf(sp.getString("template", ShareTemplate.CLASSIC.name) ?: "") }.getOrDefault(ShareTemplate.CLASSIC)
        set(v) { sp.edit().putString("template", v.name).apply() }

    companion object {
        /** Judul yang dipakai di kartu: dipangkas, dan kosong jatuh ke bawaan. */
        fun effectiveTitle(raw: String): String = raw.trim().take(ShareBrand.MAX_LEN).ifEmpty { ShareBrand.DEFAULT_TITLE }
    }
}

object ShareBrandIo {
    /** Ikon aplikasi (launcher) sebagai bitmap 192 px untuk dipasang di sebelah kiri judul kartu; null bila gagal. */
    fun appIcon(ctx: Context): Bitmap? = runCatching {
        val d = ctx.packageManager.getApplicationIcon(ctx.packageName)
        val bmp = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, 192, 192)
        d.draw(Canvas(bmp))
        bmp
    }.getOrNull()
}
