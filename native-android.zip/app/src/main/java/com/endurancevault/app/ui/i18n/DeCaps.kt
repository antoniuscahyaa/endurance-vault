package com.endurancevault.app.ui.i18n

/**
 * Mengubah teks yang seluruhnya HURUF BESAR menjadi huruf normal (sentence case).
 * Dipakai di pembungkus Text supaya label berhuruf kapital (literal di kode, hasil .uppercase(), maupun
 * terjemahan di en.tsv) tampil normal tanpa mengubah kunci terjemahan.
 *
 * Aturan:
 *  - teks yang sudah punya huruf kecil dibiarkan;
 *  - teks dengan kurang dari 3 huruf dibiarkan (mis. "HR", "PR");
 *  - singkatan umum (HR, HRV, GPS, TSS, VO2, 5K, ...) dan token tanpa vokal sampai 5 huruf tetap kapital;
 *  - singkatan hari/bulan menjadi Title Case ("FRI" -> "Fri");
 *  - huruf pertama teks dan huruf pertama setiap potongan setelah " · " dikapitalkan.
 */
internal object DeCaps {
    private val KEEP = setOf(
        "HR", "HRV", "GPS", "AGPS", "TSS", "CTL", "ATL", "TSB", "FTP", "LTHR", "BPM", "RPE", "RPM", "TRIMP", "BMI",
        "RHR", "SPO2", "VO2", "VO2MAX", "GAP", "NGP", "PB", "PR", "AI", "UI", "ID", "EN", "VS", "BLE", "USB", "GPX",
        "TCX", "FIT", "PDF", "ECG", "EF", "AM", "PM", "UTC", "GMT", "OK", "TV", "SD", "HD", "LED", "NFC",
    )
    private val DATE_WORDS = setOf(
        "MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN", "SEN", "SEL", "RAB", "KAM", "JUM", "SAB",
        "JAN", "FEB", "MAR", "APR", "MEI", "MAY", "JUN", "JUL", "AGU", "AGS", "AUG", "SEP", "OKT", "OCT", "NOV", "DES", "DEC",
    )
    private val VOWELS = "AEIOU"
    private val SPLIT = Regex("(\\s+)")
    private val cache = java.util.concurrent.ConcurrentHashMap<String, String>()

    fun apply(s: String): String {
        if (s.length < 3) return s
        cache[s]?.let { return it }
        val r = convert(s)
        if (cache.size > 4000) cache.clear()
        cache[s] = r
        return r
    }

    private fun convert(s: String): String {
        var letters = 0
        for (c in s) {
            if (c.isLowerCase()) return s
            if (c.isLetter()) letters++
        }
        if (letters < 3) return s
        val parts = SPLIT.split(s)
        val seps = SPLIT.findAll(s).map { it.value }.toList()
        val sb = StringBuilder()
        for (i in parts.indices) {
            sb.append(token(parts[i]))
            if (i < seps.size) sb.append(seps[i])
        }
        return capitalizeSegments(sb.toString())
    }

    private fun token(t: String): String {
        if (t.isEmpty() || t.none { it.isLetter() }) return t
        val core = t.trim { !it.isLetterOrDigit() }
        if (core.isEmpty()) return t
        if (t.startsWith("#")) return t
        if (core.any { it.isDigit() }) return t
        if (core.length == 1) return t
        if (core in KEEP) return t
        if (core == "KM") return t.replace("KM", "km")
        if (core in DATE_WORDS) return t.lowercase().replaceFirstChar { it.uppercase() }
        if (core.length <= 5 && core.none { it in VOWELS }) return t
        return t.lowercase()
    }

    private fun capitalizeSegments(s: String): String {
        val sb = StringBuilder(s.length)
        var atStart = true
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (atStart && c.isLetter()) {
                sb.append(c.uppercaseChar()); atStart = false
            } else {
                sb.append(c)
                if (c.isLetterOrDigit()) atStart = false
            }
            if (c == '·' || c == '\n') atStart = true
            i++
        }
        return sb.toString()
    }
}
