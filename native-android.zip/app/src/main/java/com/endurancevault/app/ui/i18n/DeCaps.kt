package com.endurancevault.app.ui.i18n

/**
 * Mengubah teks yang seluruhnya HURUF BESAR menjadi huruf normal (sentence case).
 * Dipakai di pembungkus Text supaya label berhuruf kapital (literal di kode, hasil .uppercase(), maupun
 * terjemahan di en.tsv) tampil normal tanpa mengubah kunci terjemahan.
 *
 * Aturan:
 *  - teks yang sudah punya huruf kecil dibiarkan (kecuali "SpO₂"/"SpO2", yang tidak dihitung sebagai huruf kecil);
 *  - teks dengan kurang dari 3 huruf dibiarkan (mis. "HR", "PR");
 *  - singkatan umum (HR, HRV, GPS, ACWR, RAI, VDOT, REM, ...) dan token tanpa vokal sampai 5 huruf tetap kapital;
 *  - token gabungan dengan "-", "/", "−", "–" diproses per bagian ("A-GPS" tetap, "HR/PACE" menjadi "HR/pace");
 *  - "KM" dan "VS" menjadi "km" dan "vs", juga di awal teks;
 *  - singkatan hari/bulan menjadi Title Case ("FRI" -> "Fri");
 *  - huruf pertama teks dan huruf pertama setiap potongan setelah " · " dikapitalkan.
 */
internal object DeCaps {
    private val KEEP = setOf(
        "HR", "HRV", "GPS", "AGPS", "TSS", "CTL", "ATL", "TSB", "FTP", "LTHR", "BPM", "RPE", "RPM", "TRIMP", "BMI",
        "RHR", "SPO2", "VO2", "VO2MAX", "GAP", "NGP", "PB", "PR", "AI", "UI", "ID", "EN", "BLE", "USB", "GPX",
        "TCX", "FIT", "PDF", "ECG", "EF", "AM", "PM", "UTC", "GMT", "OK", "TV", "SD", "HD", "LED", "NFC",
        // Singkatan metrik/fitur yang mengandung vokal sehingga tidak tertangkap aturan "tanpa vokal".
        "ACWR", "RAI", "VDOT", "VAM", "MAF", "REM", "REC", "SL", "TE", "AQI", "US", "EU", "UV",
        "OSM", "OSRM", "OSS",
    )
    private val DATE_WORDS = setOf(
        "MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN", "SEN", "SEL", "RAB", "KAM", "JUM", "SAB",
        "JAN", "FEB", "MAR", "APR", "MEI", "MAY", "JUN", "JUL", "AGU", "AGS", "AUG", "SEP", "OKT", "OCT", "NOV", "DES", "DEC",
    )
    /** Satuan/kata kecil yang tetap huruf kecil, termasuk saat berada di awal teks. */
    private val LOWER_WORDS = mapOf("KM" to "km", "VS" to "vs")
    private val VOWELS = "AEIOU"
    private val SPLIT = Regex("(\\s+)")
    private val cache = java.util.concurrent.ConcurrentHashMap<String, String>()

    fun apply(s: String): String {
        if (s.length < 3) return s
        cache[s]?.let { return it }
        val r = convert(s)
        if (cache.size > 4000) cache.clear()
        cache[s] = r
        return r
    }

    private fun convert(original: String): String {
        // "SpO₂" punya huruf kecil sehingga akan menggagalkan konversi; diganti penanda "SPO2" (ada angka, jadi tidak diubah) lalu dikembalikan.
        val spo = if (original.contains("SpO₂")) "SpO₂" else "SpO2"
        val hasSpo = original.contains(spo)
        val s = if (hasSpo) original.replace(spo, "SPO2") else original
        var letters = 0
        for (c in s) {
            if (c.isLowerCase()) return original
            if (c.isLetter()) letters++
        }
        if (letters < 3) return original
        val parts = SPLIT.split(s)
        val seps = SPLIT.findAll(s).map { it.value }.toList()
        val sb = StringBuilder()
        for (i in parts.indices) {
            sb.append(token(parts[i]))
            if (i < seps.size) sb.append(seps[i])
        }
        val out = capitalizeSegments(sb.toString())
        return if (hasSpo) out.replace("SPO2", spo) else out
    }

    private fun isJoiner(c: Char) = c == '-' || c == '/' || c == '−' || c == '–'

    /** Token gabungan ("A-GPS", "HR/PACE", "B−A") diproses per bagian agar singkatan di dalamnya tetap kapital. */
    private fun token(t: String): String {
        if (t.none { isJoiner(it) }) return word(t)
        val sb = StringBuilder()
        val cur = StringBuilder()
        for (c in t) {
            if (isJoiner(c)) {
                sb.append(word(cur.toString())); cur.clear(); sb.append(c)
            } else cur.append(c)
        }
        sb.append(word(cur.toString()))
        return sb.toString()
    }

    private fun word(t: String): String {
        if (t.isEmpty() || t.none { it.isLetter() }) return t
        val core = t.trim { !it.isLetterOrDigit() }
        if (core.isEmpty()) return t
        if (t.startsWith("#")) return t
        if (core.any { it.isDigit() }) return t
        if (core.length == 1) return t
        if (core in KEEP) return t
        LOWER_WORDS[core]?.let { return t.replace(core, it) }
        if (core in DATE_WORDS) return t.lowercase().replaceFirstChar { it.uppercase() }
        if (core.length <= 5 && core.none { it in VOWELS }) return t
        return t.lowercase()
    }

    private fun capitalizeSegments(s: String): String {
        val sb = StringBuilder(s.length)
        var atStart = true
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (atStart && c.isLetter()) {
                var j = i
                while (j < s.length && s[j].isLetter()) j++
                val w = s.substring(i, j)
                if (w in LOWER_WORDS.values) {
                    sb.append(w); i = j; atStart = false
                    continue
                }
                sb.append(c.uppercaseChar()); atStart = false
            } else {
                sb.append(c)
                if (c.isLetterOrDigit()) atStart = false
            }
            if (c == '·' || c == '\n') atStart = true
            i++
        }
        return sb.toString()
    }
}
