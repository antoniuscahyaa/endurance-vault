package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.i18n.Text
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.LocalFireDepartment
import androidx.compose.material.icons.outlined.Timeline
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.endurancevault.app.domain.AcuteChronic
import com.endurancevault.app.domain.DatedHist
import com.endurancevault.app.domain.IntensityDistribution
import com.endurancevault.app.domain.Js
import com.endurancevault.app.domain.LoadDay
import com.endurancevault.app.domain.LoadView
import com.endurancevault.app.domain.MonotonyStrain
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.domain.ProgressAnalytics
import com.endurancevault.app.domain.TrainingMetrics
import com.endurancevault.app.domain.TrainingMetricsResult
import com.endurancevault.app.domain.TrainingMethod
import com.endurancevault.app.domain.WeekStrain
import com.endurancevault.app.domain.ZoneCuts
import com.endurancevault.app.domain.ZonePeriod
import com.endurancevault.app.domain.Zones
import com.endurancevault.app.domain.Phases
import com.endurancevault.app.ui.UiState
import java.time.LocalDate
import java.time.format.TextStyle as JTextStyle
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

/**
 * Tab Load, memakai sistem kartu yang sama dengan Rekap dan Fitness (RcCard: ringkasan saat tertutup, detail saat dibuka).
 * Empat kartu: Training load, ACWR · Monotony · Strain, Intensitas 80/20, dan HR zones.
 * Tiga kartu pertama mengalir berpasangan setengah lebar selama keduanya tertutup (kartu terbuka selalu selebar layar);
 * HR zones selalu selebar layar. Readiness ada di header Profil, bukan di tab ini.
 */
@Composable
internal fun LoadTab(state: UiState, onSaveSettings: (PlanSettings) -> Unit = {}) {
    val today = LocalDate.now()
    val m = remember(state.settings, state.activities, state.daily, state.plan, state.hrHistByActivity) {
        runCatching {
            TrainingMetrics.calculate(state.settings, state.activities, state.daily, state.plan, hrHistByActivity = state.hrHistByActivity)
        }.getOrNull()
    }
    if (m == null) {
        RcMuted("Training load belum bisa dihitung dari data saat ini.")
        return
    }
    val acwr = remember(m) { ProgressAnalytics.acuteChronic(m.days, today) }
    val ms = remember(m) { ProgressAnalytics.monotonyStrain(m.days, today) }
    val weeks = remember(m) { LoadView.weeklyStrain(m.days, today, 7) }
    val hists = remember(state.activities, state.hrHistByActivity) { ldHists(state) }
    val dist4 = remember(hists, m) { LoadView.distribution(hists, today.minusDays(27), today, m.lthr, m.hrMax) }
    val zc = remember(state.settings) { Zones.cuts(state.settings) }
    val runs = remember(state.plan) {
        (state.plan as? PlanOutcome.Ok)?.weeks?.map { Triple(it.start, it.end, it.phase) }?.let { LoadView.phaseRuns(it) }.orEmpty()
    }
    val method = TrainingMethod.of(state.settings)
    val names = remember(state.activities) { state.activities.associate { it.id to it.name } }

    // status buka/tutup di-hoist supaya kartu tahu kapan harus berpasangan atau melebar
    var oLd by rememberSaveable { mutableStateOf(false) }
    var oAc by rememberSaveable { mutableStateOf(false) }
    var oIn by rememberSaveable { mutableStateOf(false) }
    var oHr by rememberSaveable { mutableStateOf(false) }

    val cards = listOf(
        LdCard(oLd) { mod -> LdLoad(m, names, state.settings, onSaveSettings, oLd, { oLd = !oLd }, mod) },
        LdCard(oAc) { mod -> LdAcwr(acwr, ms, weeks, oAc, { oAc = !oAc }, mod) },
        LdCard(oIn) { mod -> LdIntensity(dist4, hists, runs, method, m.lthr, m.hrMax, today, oIn, { oIn = !oIn }, mod) },
    )
    var i = 0
    while (i < cards.size) {
        val card = cards[i]
        val next = cards.getOrNull(i + 1)
        if (!card.open && next != null && !next.open) {
            RcPair(false, false, left = card.content, right = next.content)
            i += 2
        } else {
            card.content(Modifier.fillMaxWidth())
            i += 1
        }
    }
    LdHrZones(hists, zc, today, oHr, { oHr = !oHr }, Modifier.fillMaxWidth())
}

private class LdCard(val open: Boolean, val content: @Composable (Modifier) -> Unit)

// ===================== helper kecil =====================

private val LD_LOC = com.endurancevault.app.ui.i18n.Lang.locale
private fun ldF1(x: Double): String = String.format(Locale.US, "%.1f", x).replace('.', ',')
private fun ldF2(x: Double): String = String.format(Locale.US, "%.2f", x).replace('.', ',')
private fun ldDate(d: LocalDate): String = "${d.dayOfMonth} ${d.month.getDisplayName(JTextStyle.SHORT, LD_LOC)}"
private fun ldSigned(x: Int): String = if (x > 0) "+$x" else x.toString()
private fun ldPhase(p: String): String = when (p) {
    Phases.BASE -> "BASE"; Phases.BUILD -> "BUILD"; Phases.PEAK -> "PEAK"; else -> "TAPER"
}

private val LD_BLUE = Color(0xFF7F9CD6)
private val LD_GREEN = Color(0xFF3F9E86)
private val LD_AMBER = Color(0xFFD8B04A)
private val LD_RED = Color(0xFFC84B3B)

/** Histogram HR per aktivitas beserta tanggalnya (hanya yang punya histogram). */
internal fun ldHists(state: UiState): List<DatedHist> = state.activities.mapNotNull { a ->
    val h = state.hrHistByActivity[a.id]?.takeIf { it.isNotEmpty() } ?: return@mapNotNull null
    val d = runCatching { LocalDate.parse(a.dateIso.take(10)) }.getOrNull() ?: return@mapNotNull null
    DatedHist(d, h)
}

@Composable
private fun LdDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(Modifier.size(8.dp).clip(RoundedCornerShape(2.dp)).background(color))
        Text(label, style = monoStyle(9.5f, 0f), color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
    }
}

@Composable
private fun LdLegend(items: List<Pair<String, Color>>) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        items.forEach { (l, c) -> LdDot(c, l) }
    }
}

/** Kotak bertepi dengan teks penjelasan; [title] opsional (huruf besar tebal, atau label mono kecil bila [monoTitle]). */
@Composable
private fun LdCallout(text: String, title: String? = null, monoTitle: Boolean = false) {
    val cs = MaterialTheme.colorScheme
    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), color = cs.surfaceVariant, border = BorderStroke(.8.dp, cs.outlineVariant)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            if (title != null) {
                if (monoTitle) Text(title.uppercase(Locale.ROOT), style = monoStyle(10f, .4f), color = cs.onSurfaceVariant)
                else Text(title.uppercase(LD_LOC), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            Text(text, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun LdSub(title: String) =
    Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

/** Garis mini Fitness (primer) dan Fatigue (error) untuk ringkasan kartu tertutup. */
@Composable
private fun LdSpark(days: List<LoadDay>) {
    if (days.size < 2) return
    val fit = MaterialTheme.colorScheme.primary
    val fat = MaterialTheme.colorScheme.error
    Canvas(Modifier.fillMaxWidth().height(44.dp)) {
        val mx = max(1.0, days.maxOf { max(it.fitness, it.fatigue) })
        val mn = minOf(0.0, days.minOf { minOf(it.fitness, it.fatigue) })
        val span = (mx - mn).takeIf { it > 0.0 } ?: 1.0
        val pad = 4.dp.toPx()
        fun x(i: Int) = i * size.width / (days.size - 1)
        fun y(v: Double) = size.height - pad - ((v - mn) / span).toFloat() * (size.height - 2 * pad)
        fun line(sel: (LoadDay) -> Double, c: Color) {
            val p = Path()
            days.forEachIndexed { i, d -> if (i == 0) p.moveTo(x(i), y(sel(d))) else p.lineTo(x(i), y(sel(d))) }
            drawPath(p, c, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        line({ it.fitness }, fit); line({ it.fatigue }, fat)
    }
}

/** Grafik 12 pekan: batang load harian, garis Fitness dan Fatigue, sumbu Y berlabel dan tanggal awal/akhir di bawah. */
@Composable
private fun LdLoadChart(days: List<LoadDay>) {
    if (days.size < 2) { RcMuted("Belum cukup hari untuk grafik."); return }
    val cs = MaterialTheme.colorScheme
    val bar = cs.onSurfaceVariant.copy(alpha = .45f); val fit = cs.primary; val fat = cs.error; val grid = cs.outlineVariant
    val ticks = remember(days) { LoadView.axisTicks(days.maxOf { max(it.load, max(it.fitness, it.fatigue)) }) }
    val top = ticks.last().coerceAtLeast(1).toFloat()
    val tick = tickStyle().copy(lineHeight = 12.sp)
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.fillMaxWidth().height(162.dp)) {
            Column(Modifier.fillMaxHeight().width(30.dp), verticalArrangement = Arrangement.SpaceBetween, horizontalAlignment = Alignment.End) {
                ticks.asReversed().forEach { Text(it.toString(), style = tick, maxLines = 1) }
            }
            Spacer(Modifier.width(4.dp))
            Canvas(Modifier.weight(1f).fillMaxHeight().padding(vertical = 6.dp)) {
                val xs = size.width / days.size
                fun y(v: Double) = size.height - (v.toFloat() / top * size.height)
                ticks.forEach { t ->
                    val gy = y(t.toDouble())
                    drawLine(grid.copy(alpha = .6f), Offset(0f, gy), Offset(size.width, gy), 1.dp.toPx())
                }
                days.forEachIndexed { i, d ->
                    if (d.load > 0) drawLine(bar, Offset(i * xs + xs / 2, size.height), Offset(i * xs + xs / 2, y(d.load)), max(1.5.dp.toPx(), xs * .6f))
                }
                fun line(sel: (LoadDay) -> Double, c: Color) {
                    val p = Path()
                    days.forEachIndexed { i, d -> if (i == 0) p.moveTo(xs / 2, y(sel(d))) else p.lineTo(i * xs + xs / 2, y(sel(d))) }
                    drawPath(p, c, style = Stroke(2.2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
                line({ it.fitness }, fit); line({ it.fatigue }, fat)
            }
        }
        Row(Modifier.fillMaxWidth().padding(start = 34.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(ldDate(days.first().date), style = tick); Text(ldDate(days.last().date), style = tick)
        }
    }
}

/** Satu batang bertumpuk Z1–2 / Z3 / Z4–5 (hijau / kuning / merah), ujung membulat. */
@Composable
private fun LdStack(d: IntensityDistribution, h: Int = 10) {
    val track = MaterialTheme.colorScheme.outlineVariant
    val colors = listOf(LD_GREEN, LD_AMBER, LD_RED)
    Row(Modifier.fillMaxWidth().height(h.dp).clip(RoundedCornerShape(99.dp)).background(track)) {
        listOf(d.z1z2, d.z3, d.z4z5).forEachIndexed { i, pct ->
            if (pct > 0.05) Box(Modifier.weight(pct.toFloat()).fillMaxHeight().background(colors[i]))
        }
    }
}

/** Batang lima zona (Z1..Z5) yang lebarnya [fraction] dari lebar tersedia. */
@Composable
private fun LdZoneStack(secs: DoubleArray, fraction: Float) {
    Row(Modifier.fillMaxWidth(fraction.coerceIn(.04f, 1f)).height(12.dp).clip(RoundedCornerShape(99.dp))) {
        secs.forEachIndexed { i, s -> if (s > 0.0) Box(Modifier.weight(s.toFloat()).fillMaxHeight().background(DetailZoneColors[i])) }
    }
}

// ===================== 1. Training load =====================

@Composable
private fun LdLoad(
    m: TrainingMetricsResult, names: Map<Long, String>, settings: PlanSettings, onSaveSettings: (PlanSettings) -> Unit,
    open: Boolean, onToggle: () -> Unit, modifier: Modifier,
) {
    val form = ldSigned(m.form)
    RcCard(Icons.Outlined.LocalFireDepartment, "TRAINING LOAD", open, onToggle, modifier,
        headText = "LTHR ${m.lthr} bpm · Scale ×${ldF2(m.scale)}",
        summary = {
            if (m.days.isEmpty()) {
                RcMuted(m.statusDetail)
            } else {
                RcStats(listOf("Fitness" to "${m.fitness}", "Fatigue" to "${m.fatigue}"))
                LdSpark(m.days.takeLast(56))
            }
        },
        body = {
            if (m.days.isEmpty()) {
                RcMuted(m.statusDetail)
            } else {
                RcStatGrid(listOf(
                    "7-day load" to "${m.weeklyLoad}", "Fitness (CTL)" to "${m.fitness}", "Fatigue (ATL)" to "${m.fatigue}",
                    "Form (TSB)" to form, "ATL:CTL ratio" to (if (m.ratio > 0) ldF2(m.ratio) else "–"),
                    "Optimal range" to "${m.optimalRange.first}–${m.optimalRange.last}",
                ))
                LdScaleEditor(m.scale, settings, onSaveSettings)
                LdCallout(m.statusDetail, title = m.status)
                RcInfo("Status beban membandingkan Fatigue (ATL, rerata 7 hari) dengan Fitness (CTL, rerata 42 hari). Rasio ATL:CTL di bawah 0,8 = beban turun, 0,8–1,3 = optimal, 1,3–1,5 = tinggi, di atas 1,5 = sangat tinggi. Form (TSB) = Fitness − Fatigue. Kisaran optimal = 80–130% dari Fitness × 7. Bukan penilaian medis.")
                RcInner {
                    LdLoadChart(m.days.takeLast(84))
                    LdLegend(listOf("Daily load" to MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = .45f),
                        "Fitness (CTL)" to MaterialTheme.colorScheme.primary, "Fatigue (ATL)" to MaterialTheme.colorScheme.error))
                }
                if (m.sessions.isNotEmpty()) LdSessions(m, names)
            }
        })
}

/** Kolom skala load yang bisa diubah + tombol reset; disimpan di pengaturan. */
@Composable
private fun LdScaleEditor(scale: Double, settings: PlanSettings, onSave: (PlanSettings) -> Unit) {
    val cs = MaterialTheme.colorScheme
    var text by remember(scale) { mutableStateOf(ldF2(scale)) }
    var bad by remember { mutableStateOf(false) }
    var wasFocused by remember { mutableStateOf(false) }
    fun commit() {
        val v = text.replace(',', '.').trim().toDoubleOrNull()
        if (v == null || v < .5 || v > 6.0) { bad = true; return }
        bad = false
        if (abs(v - scale) > 0.005) onSave(settings.copy(loadScale = v))
    }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("LOAD SCALE", style = monoStyle(9f, .4f), color = cs.onSurfaceVariant)
        OutlinedTextField(
            value = text, onValueChange = { text = it.filter { c -> c.isDigit() || c == ',' || c == '.' }.take(5); bad = false },
            modifier = Modifier.width(130.dp).onFocusChanged { if (wasFocused && !it.isFocused) commit(); wasFocused = it.isFocused },
            singleLine = true, isError = bad,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { commit() }),
            textStyle = monoStyle(14f, 0f).copy(color = cs.onSurface),
        )
        if (bad) RcMuted("Isi angka 0,5–6,0.")
        RcPill("Reset scale", enabled = settings.loadScale != null) { bad = false; onSave(settings.copy(loadScale = null)) }
        RcInfo("Skala mengubah satuan Load, Fitness, dan Fatigue (bukan bentuk grafiknya). Bawaan ×2,70. Perubahan ikut memengaruhi kisaran optimal dan skor readiness yang memakai rasio ATL:CTL.")
    }
}

@Composable
private fun LdSessions(m: TrainingMetricsResult, names: Map<Long, String>) {
    val cs = MaterialTheme.colorScheme
    Text("RECENT SESSIONS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    RcInner {
        val w = listOf(.7f, 2.3f, .8f, 1f, 1.2f)
        RcTableRow(listOf("Date", "Sessions", "Load", "Aerobic", "Anaerobic"), w, head = true, leftCols = 2)
        m.sessions.take(10).forEach { s ->
            val title = names[s.activityId]?.takeIf { it.isNotBlank() } ?: s.source
            RcTableRow(listOf(
                "${s.date.dayOfMonth}\n${s.date.month.getDisplayName(JTextStyle.SHORT, LD_LOC)}", title, "${s.load.toInt()}",
                ldF1(s.aerobicEffect), s.anaerobicEffect?.let { ldF1(it) } ?: "–",
            ), w, leftCols = 2)
        }
    }
    RcInfo("Aerobic dan Anaerobic = Training Effect (skala 0–5). TE, recovery, dan watch load memakai angka jam bila tersedia. Load CTL/ATL tetap dihitung dengan skala internal agar satuan beban jam tidak tercampur tanpa kalibrasi. Kolom Sessions memakai nama aktivitas.")
}

// ===================== 2. ACWR · Monotony · Strain =====================

@Composable
private fun LdAcwr(
    acwr: AcuteChronic?, ms: MonotonyStrain?, weeks: List<WeekStrain>,
    open: Boolean, onToggle: () -> Unit, modifier: Modifier,
) {
    RcCard(Icons.Outlined.Timeline, "ACWR, MONOTONY & STRAIN", open, onToggle, modifier, labelLines = 2,
        headText = "7 hari, dari load harian",
        summary = {
            RcStats(listOf("Monotony" to (ms?.let { ldF1(it.monotony) } ?: "–"), "Strain" to (ms?.let { Js.idn(Js.roundI(it.strain)) } ?: "–")))
            if (ms != null) LdMonoMeter(ms.monotony)
        },
        body = {
            LdSub("ACWR")
            LdCallout(LoadView.acwrMessage(acwr?.ratio))
            LdAcwrGauge(acwr?.ratio)
            RcInfo("ACWR = total load 7 hari dibagi rata-rata mingguan 28 hari. Zona umum: di bawah 0,8 rendah, 0,8–1,3 optimal, 1,3–1,5 waspada, di atas 1,5 tinggi. Acuan umum, bukan penilaian medis." +
                (acwr?.let { " Sekarang: acute ${ldF1(it.acute)}, chronic ${ldF1(it.chronic)}." } ?: ""))
            LdSub("MONOTONY & STRAIN")
            LdCallout(LoadView.monotonyMessage(ms?.monotony))
            LdStrainRows(ms, weeks)
            RcInfo("Monotony = rerata load harian dibagi simpangan baku 7 hari (makin tinggi, makin seragam). Strain = total load 7 hari × monotony. Baris pekan memakai Senin–Minggu; M = monotony. Di atas 1,5 mulai seragam, di atas 2,0 tinggi.")
        })
}

/** Meter monotony kartu tertutup: label status, jalur gradasi, penanda posisi (skala 0–3). */
@Composable
private fun LdMonoMeter(monotony: Double) {
    val cs = MaterialTheme.colorScheme
    val track = cs.outlineVariant
    val warm = cs.primary
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(LoadView.monotonyLabel(monotony), style = monoStyle(9f, .3f), color = cs.onSurfaceVariant, maxLines = 1)
        Canvas(Modifier.weight(1f).height(16.dp)) {
            val h = 10.dp.toPx(); val top = (size.height - h) / 2
            drawRoundRect(Brush.horizontalGradient(listOf(track.copy(alpha = .7f), warm.copy(alpha = .45f), warm)), Offset(0f, top), Size(size.width, h), CornerRadius(h / 2))
            val mw = 3.dp.toPx()
            val x = ((monotony / 3.0).coerceIn(0.0, 1.0).toFloat() * size.width - mw / 2).coerceIn(0f, size.width - mw)
            drawRoundRect(cs.onSurface, Offset(x, 0f), Size(mw, size.height), CornerRadius(mw / 2))
        }
    }
}

/** Gauge ACWR 0–2+: biru (<0,8), hijau (0,8–1,3), kuning (1,3–1,5), merah (>1,5) dengan penanda posisi. */
@Composable
private fun LdAcwrGauge(ratio: Double?) {
    val cs = MaterialTheme.colorScheme
    val tick = tickStyle()
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(Modifier.fillMaxWidth().height(18.dp)) {
            Row(Modifier.align(Alignment.Center).fillMaxWidth().height(10.dp).clip(RoundedCornerShape(99.dp))) {
                listOf(.8f to LD_BLUE, .5f to LD_GREEN, .2f to LD_AMBER, .5f to LD_RED).forEach { (w, c) ->
                    Box(Modifier.weight(w).fillMaxHeight().background(c))
                }
            }
            if (ratio != null) {
                Canvas(Modifier.fillMaxSize()) {
                    val mw = 5.dp.toPx()
                    val x = ((ratio / 2.0).coerceIn(0.0, 1.0).toFloat() * size.width - mw / 2).coerceIn(0f, size.width - mw)
                    drawRoundRect(cs.surface, Offset(x - 1.dp.toPx(), 0f), Size(mw + 2.dp.toPx(), size.height), CornerRadius(3.dp.toPx()))
                    drawRoundRect(cs.onSurface, Offset(x, 1.dp.toPx()), Size(mw, size.height - 2.dp.toPx()), CornerRadius(2.5.dp.toPx()))
                }
            }
        }
        Box(Modifier.fillMaxWidth()) {
            listOf(0.0 to "0", .4 to "0,8", .65 to "1,3", .75 to "1,5", 1.0 to "2+").forEach { (f, t) ->
                Text(t, Modifier.align(BiasAlignment((2 * f - 1).toFloat(), 0f)), style = tick)
            }
        }
    }
}

/** Baris "7 hari terakhir" dan 7 pekan penuh: label, batang strain relatif, nilai strain, dan monotony (M). */
@Composable
private fun LdStrainRows(ms: MonotonyStrain?, weeks: List<WeekStrain>) {
    val cs = MaterialTheme.colorScheme
    val rows = buildList {
        add(Triple("7 hari terakhir", ms?.strain ?: 0.0, ms?.monotony))
        weeks.forEach { add(Triple("${ldDate(it.start)} – ${ldDate(it.end)}", it.strain, it.monotony)) }
    }
    val mx = max(1.0, rows.maxOf { it.second })
    val shape = RoundedCornerShape(99.dp)
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        rows.forEach { (label, strain, mono) ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(label, Modifier.width(112.dp), style = monoStyle(10f, 0f), color = cs.onSurfaceVariant, maxLines = 1)
                Box(Modifier.weight(1f).height(10.dp).clip(shape).background(cs.outlineVariant)) {
                    if (strain > 0) Box(Modifier.fillMaxWidth((strain / mx).toFloat().coerceIn(.03f, 1f)).fillMaxHeight().clip(shape).background(cs.primary))
                }
                Column(Modifier.width(48.dp), horizontalAlignment = Alignment.End) {
                    Text(Js.idn(Js.roundI(strain)), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text("M ${mono?.let { ldF1(it) } ?: "–"}", style = monoStyle(9f, 0f), color = cs.onSurfaceVariant, maxLines = 1)
                }
            }
        }
    }
}

// ===================== 3. Intensitas 80/20 =====================

@Composable
private fun LdIntensity(
    dist4: IntensityDistribution?, hists: List<DatedHist>, runs: List<com.endurancevault.app.domain.PhaseRun>,
    method: String, lthr: Int, hrMax: Int, today: LocalDate,
    open: Boolean, onToggle: () -> Unit, modifier: Modifier,
) {
    val cs = MaterialTheme.colorScheme
    var mode by rememberSaveable { mutableStateOf(0) }
    RcCard(Icons.Outlined.Add, "80/20 INTENSITY DISTRIBUTION", open, onToggle, modifier, labelLines = 2,
        headText = "Z1–2 · Z3 · Z4–5, ${TrainingMethod.name(method)}",
        summary = {
            if (dist4 == null) {
                RcBig("–", "4 pekan terakhir")
                RcMuted("Belum ada histogram HR.")
            } else {
                val a = Js.roundI(dist4.z1z2)
                RcBig("$a/${100 - a}", "4 pekan terakhir")
                LdStack(dist4)
            }
        },
        body = {
            RcSeg(listOf("Week", "Phase"), mode) { mode = it }
            if (dist4 == null) {
                LdCallout("Belum ada histogram HR aktivitas dalam 4 pekan terakhir.", title = "Last 4 weeks", monoTitle = true)
            } else {
                LdCallout(LoadView.intensityAdvice(method, dist4.z1z2, dist4.z3, dist4.z4z5).second, title = "Last 4 weeks", monoTitle = true)
            }
            if (mode == 0) {
                val monday = today.with(java.time.DayOfWeek.MONDAY)
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    (0 until 8).forEach { k ->
                        val start = monday.minusWeeks(k.toLong())
                        LdDistRow(ldDate(start), null, LoadView.distribution(hists, start, start.plusDays(6), lthr, hrMax))
                    }
                }
            } else {
                val started = runs.filter { !it.start.isAfter(today) }.takeLast(6).asReversed()
                if (started.isEmpty()) {
                    RcMuted("Belum ada fase rencana yang berjalan.")
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        started.forEach { r ->
                            val end = if (r.end.isAfter(today)) today else r.end
                            LdDistRow(ldPhase(r.phase), ldDate(r.start), LoadView.distribution(hists, r.start, end, lthr, hrMax))
                        }
                    }
                }
            }
            LdLegend(listOf("Z1–2" to LD_GREEN, "Z3" to LD_AMBER, "Z4–5" to LD_RED))
            RcInfo("Z1–2 di bawah LTHR; Z3 dari LTHR sampai 35% menuju HRmax; Z4–5 di atasnya. Angka di kanan = Z1–2/Z3/Z4–5 (%). Sesi tanpa histogram HR tidak dimasukkan. Ringkasan kartu = Z1–2 berbanding sisanya selama 4 pekan terakhir. Target mengikuti metode latihan di pengaturan rencana. Hanya saran; rencana latihan tidak diubah.")
        })
}

@Composable
private fun LdDistRow(label: String, sub: String?, d: IntensityDistribution?) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Column(Modifier.width(58.dp)) {
            Text(label, style = monoStyle(10.5f, 0f), color = cs.onSurfaceVariant, maxLines = 1)
            if (sub != null) Text(sub, style = tickStyle(), maxLines = 1)
        }
        Box(Modifier.weight(1f)) {
            if (d != null) LdStack(d, 14)
            else Box(Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(99.dp)).background(cs.outlineVariant))
        }
        Text(d?.let { "${Js.roundI(it.z1z2)}/${Js.roundI(it.z3)}/${Js.roundI(it.z4z5)}" } ?: "–", Modifier.width(64.dp),
            style = monoStyle(10.5f, 0f), color = cs.onSurface, textAlign = TextAlign.End, maxLines = 1)
    }
}

// ===================== 4. HR zones =====================

@Composable
private fun LdHrZones(
    hists: List<DatedHist>, zc: ZoneCuts, today: LocalDate,
    open: Boolean, onToggle: () -> Unit, modifier: Modifier,
) {
    val cs = MaterialTheme.colorScheme
    var mode by rememberSaveable { mutableStateOf(0) }
    var selKey by rememberSaveable { mutableStateOf("") }
    val weeks = remember(hists, zc, today) { LoadView.zonePeriods(hists, zc, today, false, 8) }
    val months = remember(hists, zc, today) { LoadView.zonePeriods(hists, zc, today, true, 6) }
    val latest = weeks.firstOrNull { it.hasData }
    val head = if (zc.mode == "lthr") "LTHR ${zc.lthr} bpm · HR zones" else "HRR · HR zones"
    RcCard(Icons.Outlined.FavoriteBorder, "HR ZONES", open, onToggle, modifier, headText = head,
        summary = {
            val d = latest?.distribution()
            if (d == null) {
                RcMuted("Belum ada histogram HR aktivitas.")
            } else {
                RcStats(listOf("Z1-2" to "${Js.roundI(d.z1z2)}%", "Z3" to "${Js.roundI(d.z3)}%", "Z4-5" to "${Js.roundI(d.z4z5)}%"))
                LdStack(d)
            }
        },
        body = {
            val periods = if (mode == 0) weeks else months
            fun label(p: ZonePeriod): String =
                if (mode == 0) "${ldDate(p.start)} – ${ldDate(p.end)}" else "${p.start.month.getDisplayName(JTextStyle.SHORT, LD_LOC)} ${p.start.year}"
            RcSeg(listOf("Week", "Month"), mode) { mode = it; selKey = "" }
            if (periods.none { it.hasData }) {
                RcMuted("Belum ada histogram HR aktivitas pada rentang ini.")
            } else {
                val maxTotal = periods.maxOf { it.total }.coerceAtLeast(1.0)
                val selected = periods.firstOrNull { it.start.toString() == selKey && it.hasData } ?: periods.firstOrNull { it.hasData }
                RcInner {
                    periods.forEach { p ->
                        val on = p === selected
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                .then(if (on) Modifier.background(cs.onSurface.copy(alpha = .08f)) else Modifier)
                                .clickable(enabled = p.hasData) { selKey = p.start.toString() }
                                .padding(horizontal = 8.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Text(label(p), Modifier.width(104.dp), style = monoStyle(10.5f, 0f),
                                color = if (p.hasData) cs.onSurface else cs.onSurfaceVariant.copy(alpha = .6f), maxLines = 1)
                            Box(Modifier.weight(1f)) { if (p.hasData) LdZoneStack(p.secs, (p.total / maxTotal).toFloat()) }
                            Text(if (p.hasData) LoadView.duration(p.total) else "–", Modifier.width(52.dp),
                                style = monoStyle(10.5f, 0f), textAlign = TextAlign.End, maxLines = 1)
                        }
                    }
                    if (selected != null) {
                        HorizontalDivider(color = cs.outlineVariant, thickness = .8.dp, modifier = Modifier.padding(vertical = 4.dp))
                        Text("${label(selected)} · ${selected.sessions} sesi · ${LoadView.duration(selected.total)}",
                            style = monoStyle(10.5f, 0f), color = cs.onSurfaceVariant, modifier = Modifier.padding(horizontal = 8.dp))
                        val bands = zc.bands()
                        Column(Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            (0 until 5).forEach { i ->
                                val s = selected.secs[i]
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Box(Modifier.size(12.dp).clip(RoundedCornerShape(3.dp)).background(DetailZoneColors[i]))
                                    Row(Modifier.weight(1f), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text("Z${i + 1}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                        Text("${bands[i]} bpm", style = monoStyle(10f, 0f), color = cs.onSurfaceVariant, maxLines = 1)
                                    }
                                    Text(if (s > 0.0) LoadView.clock(s) else "–", Modifier.width(64.dp), style = monoStyle(11f, 0f), textAlign = TextAlign.End, maxLines = 1)
                                    Text("${Js.roundI(s / selected.total * 100)}%", Modifier.width(40.dp), style = monoStyle(11f, 0f), color = cs.onSurfaceVariant, textAlign = TextAlign.End, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }
            RcInfo("Waktu di tiap zona dari histogram HR aktivitas, memakai batas zona di pengaturan HR (bpm di samping Z1–Z5). Panjang batang = total waktu relatif terhadap periode terpanjang; ketuk satu baris untuk rincian. Ringkasan kartu = pekan terbaru yang punya data.")
        })
}
