package com.endurancevault.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Equalizer
import androidx.compose.material.icons.outlined.MonitorHeart
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.Timeline
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.endurancevault.app.domain.AcuteChronic
import com.endurancevault.app.domain.IntensityDistribution
import com.endurancevault.app.domain.Js
import com.endurancevault.app.domain.LoadDay
import com.endurancevault.app.domain.MonotonyStrain
import com.endurancevault.app.domain.ProgressAnalytics
import com.endurancevault.app.domain.ProgressTabs
import com.endurancevault.app.domain.TrainingMetrics
import com.endurancevault.app.domain.TrainingMetricsResult
import com.endurancevault.app.ui.UiState
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.TextStyle as JTextStyle
import java.util.Locale
import kotlin.math.max

/**
 * Tab Load, memakai sistem kartu yang sama dengan Rekap dan Fitness (RcCard: ringkasan saat tertutup, detail saat dibuka).
 * Empat kartu: Training readiness, Training load, ACWR · Monotony · Strain, dan Intensitas 80/20.
 * Readiness dan Training load selebar layar; ACWR dan 80/20 berpasangan (melebar bila salah satu dibuka).
 */
@Composable
internal fun LoadTab(state: UiState) {
    val today = LocalDate.now()
    val m = remember(state.settings, state.activities, state.daily, state.plan, state.hrHistByActivity) {
        runCatching {
            TrainingMetrics.calculate(state.settings, state.activities, state.daily, state.plan, hrHistByActivity = state.hrHistByActivity)
        }.getOrNull()
    }
    if (m == null) {
        RcMuted("Training load belum bisa dihitung dari data saat ini.")
        return
    }
    val acwr = remember(m) { ProgressAnalytics.acuteChronic(m.days, today) }
    val ms = remember(m) { ProgressAnalytics.monotonyStrain(m.days, today) }
    val dist = remember(m, state.hrHistByActivity) { ProgressAnalytics.intensity(state.hrHistByActivity.values, m.lthr, m.hrMax) }
    val weekly = remember(m, state.activities, state.hrHistByActivity) { ldWeekly(state, m.lthr, m.hrMax) }

    // status buka/tutup di-hoist supaya pasangan setengah lebar tahu kapan harus melebar
    var oRd by rememberSaveable { mutableStateOf(false) }
    var oLd by rememberSaveable { mutableStateOf(false) }
    var oAc by rememberSaveable { mutableStateOf(false) }
    var oIn by rememberSaveable { mutableStateOf(false) }

    LdReadiness(m, oRd, { oRd = !oRd }, Modifier.fillMaxWidth())
    LdLoad(m, oLd, { oLd = !oLd }, Modifier.fillMaxWidth())
    RcPair(oAc, oIn,
        left = { mod -> LdAcwr(acwr, ms, oAc, { oAc = !oAc }, mod) },
        right = { mod -> LdIntensity(dist, weekly, oIn, { oIn = !oIn }, mod) })
}

// ===================== helper kecil =====================

private val LD_LOC = Locale("id", "ID")
private fun ldF1(x: Double): String = String.format(Locale.US, "%.1f", x).replace('.', ',')
private fun ldF2(x: Double): String = String.format(Locale.US, "%.2f", x).replace('.', ',')
private fun ldDate(d: LocalDate): String = "${d.dayOfMonth} ${d.month.getDisplayName(JTextStyle.SHORT, LD_LOC)}"
private fun ldSigned(x: Int): String = if (x > 0) "+$x" else x.toString()

/** Distribusi intensitas per pekan (Senin) dari aktivitas yang punya histogram HR; 8 pekan terakhir. */
private fun ldWeekly(state: UiState, lthr: Int, hrMax: Int): List<Pair<LocalDate, IntensityDistribution>> =
    state.activities
        .filter { state.hrHistByActivity[it.id]?.isNotEmpty() == true }
        .mapNotNull { a -> runCatching { LocalDate.parse(a.dateIso) }.getOrNull()?.let { it.with(DayOfWeek.MONDAY) to a } }
        .groupBy({ it.first }, { it.second })
        .entries.sortedBy { it.key }
        .mapNotNull { (week, acts) ->
            ProgressAnalytics.intensity(acts.mapNotNull { state.hrHistByActivity[it.id] }, lthr, hrMax)?.let { week to it }
        }
        .takeLast(8)

@Composable
private fun ldTone(score: Int): Color {
    val cs = MaterialTheme.colorScheme
    return when { score >= 60 -> cs.primary; score >= 40 -> cs.tertiary; else -> cs.error }
}

@Composable
private fun LdDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Text(label.uppercase(Locale.ROOT), style = monoStyle(9f, .3f), color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
    }
}

@Composable
private fun LdLegend(items: List<Pair<String, Color>>) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        items.forEach { (l, c) -> LdDot(c, l) }
    }
}

/** Gauge bulat berisi skor di tengah. */
@Composable
private fun LdGauge(score: Int, color: Color) {
    val track = MaterialTheme.colorScheme.outlineVariant
    Box(Modifier.size(64.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = 6.dp.toPx(); val inset = sw / 2
            val tl = Offset(inset, inset); val sz = Size(size.width - sw, size.height - sw)
            drawArc(track, 0f, 360f, false, tl, sz, style = Stroke(sw))
            drawArc(color, -90f, 360f * score.coerceIn(0, 100) / 100f, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
        }
        Text(score.toString(), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    }
}

/** Garis mini Fitness (primer) dan Fatigue (error) untuk ringkasan kartu tertutup. */
@Composable
private fun LdSpark(days: List<LoadDay>) {
    if (days.size < 2) return
    val fit = MaterialTheme.colorScheme.primary
    val fat = MaterialTheme.colorScheme.error
    Canvas(Modifier.fillMaxWidth().height(38.dp)) {
        val mx = max(1.0, days.maxOf { max(it.fitness, it.fatigue) })
        val mn = minOf(0.0, days.minOf { minOf(it.fitness, it.fatigue) })
        val span = (mx - mn).takeIf { it > 0.0 } ?: 1.0
        val pad = 4.dp.toPx()
        fun x(i: Int) = i * size.width / (days.size - 1)
        fun y(v: Double) = size.height - pad - ((v - mn) / span).toFloat() * (size.height - 2 * pad)
        fun line(sel: (LoadDay) -> Double, c: Color) {
            val p = Path()
            days.forEachIndexed { i, d -> if (i == 0) p.moveTo(x(i), y(sel(d))) else p.lineTo(x(i), y(sel(d))) }
            drawPath(p, c, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        line({ it.fitness }, fit); line({ it.fatigue }, fat)
    }
}

/** Grafik 56 hari: batang load harian, garis Fitness dan Fatigue. */
@Composable
private fun LdLoadChart(days: List<LoadDay>) {
    if (days.size < 2) { RcMuted("Belum cukup hari untuk grafik."); return }
    val cs = MaterialTheme.colorScheme
    val bar = cs.tertiary; val fit = cs.primary; val fat = cs.error; val grid = cs.outlineVariant
    Canvas(Modifier.fillMaxWidth().height(150.dp)) {
        val maxY = max(1.0, days.maxOf { max(it.load, max(it.fitness, it.fatigue)) } * 1.12).toFloat()
        val xs = size.width / (days.size - 1).coerceAtLeast(1)
        fun y(v: Double) = size.height - (v.toFloat() / maxY * size.height)
        repeat(3) { i ->
            val gy = size.height * i / 2f
            drawLine(grid.copy(alpha = .55f), Offset(0f, gy), Offset(size.width, gy), 1.dp.toPx())
        }
        days.forEachIndexed { i, d ->
            if (d.load > 0) drawLine(bar.copy(alpha = .4f), Offset(i * xs, size.height), Offset(i * xs, y(d.load)), 2.dp.toPx())
        }
        fun line(sel: (LoadDay) -> Double, c: Color) {
            val p = Path()
            days.forEachIndexed { i, d -> if (i == 0) p.moveTo(0f, y(sel(d))) else p.lineTo(i * xs, y(sel(d))) }
            drawPath(p, c, style = Stroke(2.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        line({ it.fitness }, fit); line({ it.fatigue }, fat)
    }
}

/** Satu batang bertumpuk Z1–2 / Z3 / Z4–5. */
@Composable
private fun LdStack(d: IntensityDistribution, h: Int = 10) {
    val c1 = MaterialTheme.colorScheme.tertiary
    val c2 = MaterialTheme.colorScheme.primary
    val c3 = MaterialTheme.colorScheme.error
    val track = MaterialTheme.colorScheme.outlineVariant
    Canvas(Modifier.fillMaxWidth().height(h.dp)) {
        val r = CornerRadius(size.height / 2)
        drawRoundRect(track, Offset.Zero, size, r)
        var x = 0f
        listOf(d.z1z2 to c1, d.z3 to c2, d.z4z5 to c3).forEach { (pct, c) ->
            val w = size.width * (pct / 100.0).toFloat()
            if (w > 0.5f) drawRect(c, Offset(x, 0f), Size(w, size.height))
            x += w
        }
    }
}

/** Batang bertumpuk per pekan (maksimum 8). */
@Composable
private fun LdIntensityBars(values: List<IntensityDistribution>) {
    val cs = MaterialTheme.colorScheme
    val colors = listOf(cs.tertiary, cs.primary, cs.error)
    Canvas(Modifier.fillMaxWidth().height(92.dp)) {
        val gap = 6.dp.toPx(); val n = values.size.coerceAtLeast(1)
        val bw = ((size.width - gap * (n - 1)) / n).coerceAtLeast(2f)
        values.forEachIndexed { i, v ->
            var y = size.height
            listOf(v.z1z2, v.z3, v.z4z5).forEachIndexed { j, pct ->
                val h = size.height * (pct / 100.0).toFloat(); y -= h
                if (h > 0f) drawRect(colors[j], Offset(i * (bw + gap), y), Size(bw, h))
            }
        }
    }
}

// ===================== 1. Training readiness =====================

@Composable
private fun LdReadiness(m: TrainingMetricsResult, open: Boolean, onToggle: () -> Unit, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val r = m.readiness
    val col = if (r == null) cs.onSurfaceVariant else ldTone(r.score)
    RcCard(Icons.Outlined.MonitorHeart, "TRAINING READINESS", open, onToggle, modifier,
        headPill = if (m.planAdjustment != null) ({ RcTag("Saran sesi", 0) }) else null,
        headText = r?.let { "${it.score}/100" },
        summary = {
            if (r == null) {
                RcMuted("Belum cukup data kondisi harian. Isi tidur, HRV, HR istirahat, rasa kaki atau mood untuk menghitung readiness.")
            } else {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    LdGauge(r.score, col)
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(r.tier, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(r.advice, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 3, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        },
        body = {
            if (r == null) {
                RcMuted("Belum cukup data kondisi harian. Isi tidur, HRV, HR istirahat, rasa kaki atau mood untuk menghitung readiness.")
            } else {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    LdGauge(r.score, col)
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(r.tier, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(r.advice, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    }
                }
                RcInner {
                    r.parts.forEach { p ->
                        Column(Modifier.padding(vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text(p.label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                                Text(p.score?.let { "$it/100" } ?: "–", style = monoStyle(11f, 0f), color = cs.onSurfaceVariant)
                            }
                            val sc = p.score
                            if (sc != null) RcCompare(listOf(sc.toFloat() to ldTone(sc)), h = 6)
                            RcMuted(p.detail)
                        }
                    }
                }
                m.planAdjustment?.let { a ->
                    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), color = cs.secondaryContainer) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Penyesuaian sesi hari ini", style = MaterialTheme.typography.titleSmall, color = cs.onSecondaryContainer)
                            Text(a.plannedTitle, style = MaterialTheme.typography.bodyMedium, color = cs.onSecondaryContainer)
                            Text(
                                if (a.action == "swap") "Saran: ganti dengan easy ${ldF1(a.suggestedKm)} km"
                                else "Saran: kurangi target menjadi ${ldF1(a.suggestedKm)} km",
                                style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = cs.onSecondaryContainer,
                            )
                            Text(a.reason, style = MaterialTheme.typography.bodySmall, color = cs.onSecondaryContainer)
                        }
                    }
                }
                RcInfo("Estimasi kebugaran dari ${r.dataDays} hari data, bukan penilaian medis. Saran sesi hanya rekomendasi; jadwal tidak diubah otomatis.")
            }
        })
}

// ===================== 2. Training load =====================

@Composable
private fun LdLoad(m: TrainingMetricsResult, open: Boolean, onToggle: () -> Unit, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val form = ldSigned(m.form)
    RcCard(Icons.Outlined.Timeline, "TRAINING LOAD", open, onToggle, modifier,
        headText = "CTL ${m.fitness} · ATL ${m.fatigue}",
        summary = {
            if (m.days.isEmpty()) {
                RcMuted(m.statusDetail)
            } else {
                RcBig("${m.weeklyLoad}", "Load 7 hari · ${m.status}", "Form $form", neg = m.form < 0)
                RcStats(listOf("Fitness · CTL" to "${m.fitness}", "Fatigue · ATL" to "${m.fatigue}", "Recovery" to "${m.recoveryRemainingHours} j"))
                LdSpark(m.days.takeLast(28))
            }
        },
        body = {
            if (m.days.isEmpty()) {
                RcMuted(m.statusDetail)
            } else {
                RcMuted(m.statusDetail)
                RcStatGrid(listOf(
                    "Load 7 hari" to "${m.weeklyLoad}", "Fitness · CTL" to "${m.fitness}", "Fatigue · ATL" to "${m.fatigue}",
                    "Form · TSB" to form, "ATL : CTL" to (if (m.ratio > 0) ldF2(m.ratio) else "–"), "Recovery" to "${m.recoveryRemainingHours} j",
                ))
                RcInner {
                    LdLoadChart(m.days.takeLast(56))
                    LdLegend(listOf("Load" to cs.tertiary, "Fitness" to cs.primary, "Fatigue" to cs.error))
                }
                RcMuted("Kisaran beban mingguan indikatif ${m.optimalRange.first}–${m.optimalRange.last}. LTHR ${m.lthr} bpm · HRmax estimasi ${m.hrMax} bpm · skala ×${ldF2(m.scale)}.")
                if (m.sessions.isNotEmpty()) {
                    Text("TRAINING EFFECT · SESI TERAKHIR", style = monoStyle(9f, .4f), color = cs.onSurfaceVariant)
                    RcInner {
                        val w = listOf(1.5f, 1f, 1f, 1f)
                        RcTableRow(listOf("Sesi", "Load", "TE aerob", "TE anaerob"), w, head = true)
                        m.sessions.take(7).forEach { s ->
                            RcTableRow(listOf(
                                "${ldDate(s.date)}\n${s.source}", "${s.load.toInt()}",
                                "${ldF1(s.aerobicEffect)}/5", s.anaerobicEffect?.let { "${ldF1(it)}/5" } ?: "–",
                            ), w)
                        }
                    }
                    RcInfo("TE aerobik, TE anaerobik, recovery, dan watch load memakai angka jam bila tersedia. Load CTL/ATL EnduranceVault tetap dihitung dengan skala internal agar satuan beban jam tidak tercampur tanpa kalibrasi.")
                }
            }
        })
}

// ===================== 3. ACWR · Monotony · Strain =====================

@Composable
private fun LdAcwr(acwr: AcuteChronic?, ms: MonotonyStrain?, open: Boolean, onToggle: () -> Unit, modifier: Modifier) {
    RcCard(Icons.Outlined.Speed, "ACWR · STRAIN", open, onToggle, modifier,
        headText = acwr?.let { ldF2(it.ratio) },
        summary = {
            if (acwr == null) {
                RcStats(listOf("ACWR" to "–", "Monotony" to (ms?.let { ldF2(it.monotony) } ?: "–")))
                RcMuted("Belum cukup hari ber-load.")
            } else {
                RcBig(ldF2(acwr.ratio), "Acute : chronic · 28 hari", ProgressTabs.acwrZone(acwr.ratio), neg = !ProgressTabs.acwrOk(acwr.ratio))
                RcStats(listOf("Monotony" to (ms?.let { ldF2(it.monotony) } ?: "–"), "Strain" to (ms?.let { Js.idn(Js.roundI(it.strain)) } ?: "–")))
            }
        },
        body = {
            RcStatGrid(listOf(
                "Acute 7 hari" to (acwr?.let { ldF1(it.acute) } ?: "–"),
                "Chronic 28 hari" to (acwr?.let { ldF1(it.chronic) } ?: "–"),
                "Monotony 7 hari" to (ms?.let { ldF2(it.monotony) } ?: "–"),
                "Strain" to (ms?.let { Js.idn(Js.roundI(it.strain)) } ?: "–"),
            ), cols = 2)
            if (acwr != null) RcMuted("Zona ${ProgressTabs.acwrZone(acwr.ratio).lowercase(LD_LOC)}: acuan umum 0,8–1,3 optimal, di atas 1,5 tinggi.")
            RcInfo("ACWR = total load 7 hari dibagi rata-rata mingguan 28 hari. Monotony = rerata load harian / simpangan baku 7 hari; strain = total load × monotony. Zona hanya acuan umum dan bukan penilaian medis.")
        })
}

// ===================== 4. Intensitas 80/20 =====================

@Composable
private fun LdIntensity(
    dist: IntensityDistribution?, weekly: List<Pair<LocalDate, IntensityDistribution>>,
    open: Boolean, onToggle: () -> Unit, modifier: Modifier,
) {
    val cs = MaterialTheme.colorScheme
    RcCard(Icons.Outlined.Equalizer, "INTENSITAS 80/20", open, onToggle, modifier,
        headText = dist?.let { "Z1–2 ${it.z1z2.toInt()}%" },
        summary = {
            if (dist == null) {
                RcMuted("Belum ada histogram HR aktivitas yang cukup.")
            } else {
                LdStack(dist)
                RcStats(listOf("Z1–2" to "${Js.roundI(dist.z1z2)}%", "Z3" to "${Js.roundI(dist.z3)}%", "Z4–5" to "${Js.roundI(dist.z4z5)}%"))
            }
        },
        body = {
            if (dist == null) {
                RcMuted("Belum ada histogram HR aktivitas yang cukup.")
            } else {
                LdStack(dist, 12)
                RcStatGrid(listOf("Z1–2" to "${ldF1(dist.z1z2)}%", "Z3" to "${ldF1(dist.z3)}%", "Z4–5" to "${ldF1(dist.z4z5)}%"))
                val adv = ProgressTabs.intensityAdvice(dist.z1z2, dist.z3)
                Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
                    color = if (adv.first == 1) WARN.copy(alpha = .16f) else cs.primary.copy(alpha = .10f)) {
                    Text(adv.second + " Hanya saran; rencana latihan tidak diubah.", Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall)
                }
                if (weekly.isNotEmpty()) {
                    Text("TREN PER PEKAN · ${weekly.size} PEKAN", style = monoStyle(9f, .4f), color = cs.onSurfaceVariant)
                    RcInner {
                        LdIntensityBars(weekly.map { it.second })
                        LdLegend(listOf("Z1–2" to cs.tertiary, "Z3" to cs.primary, "Z4–5" to cs.error))
                    }
                    RcInner {
                        val w = listOf(1.2f, 1f, 1f, 1f)
                        RcTableRow(listOf("Pekan", "Z1–2", "Z3", "Z4–5"), w, head = true)
                        weekly.asReversed().forEach { (wk, d) ->
                            RcTableRow(listOf(ldDate(wk), "${Js.roundI(d.z1z2)}%", "${Js.roundI(d.z3)}%", "${Js.roundI(d.z4z5)}%"), w)
                        }
                    }
                }
                RcInfo("Total sampel ${ldF1(dist.totalSeconds / 3600.0)} jam. Z1–2 di bawah LTHR; Z3 dari LTHR sampai 35% menuju HRmax; Z4–5 di atasnya. Sesi tanpa histogram HR tidak dimasukkan. Saran: Z3 di atas 15% atau Z1–2 di bawah 75% ditandai.")
            }
        })
}
