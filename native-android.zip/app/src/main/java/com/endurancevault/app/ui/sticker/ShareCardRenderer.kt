package com.endurancevault.app.ui.sticker

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import com.endurancevault.app.domain.PeriodSummary
import com.endurancevault.app.domain.SegRole
import com.endurancevault.app.domain.SharePeriod
import com.endurancevault.app.domain.ShareSeg
import com.endurancevault.app.ui.i18n.Lang
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Latar kartu: gelap solid, foto pilihan (diberi lapisan gelap tipis), atau transparan (PNG seperti stiker). */
enum class ShareBg { DARK, PHOTO, CLEAR }

/** Ukuran gambar: Feed 4:5 (1080 x 1350) atau Story Instagram 9:16 (1080 x 1920). */
enum class ShareSize(val w: Int, val h: Int) { FEED(1080, 1350), STORY(1080, 1920) }

/** Data tambahan untuk kartu harian: rute, pace per km, dan segmen dari aktivitas yang dibuka. */
class ShareDayExtra(
    val route: List<Pair<Int, Int>>,
    /** Pace per km (menit/km), satu per split; split terakhir boleh pendek ([lastPartial]). */
    val splitPace: List<Double>,
    val lastPartial: Boolean,
    /** Segmen (repetisi, istirahat, dst.). Dua atau lebih: grafik pace memakai segmen, bukan per km. */
    val segs: List<ShareSeg> = emptyList(),
)

/**
 * Menggambar kartu statistik lari 1080 x 1350 (4:5) untuk dibagikan.
 * Mingguan = Senin..Minggu, bulanan = tanggal 1..akhir bulan; periodenya sudah ditentukan di [PeriodSummary].
 */
object ShareCardRenderer {
    const val W = 1080
    /** Tinggi area isi kartu; pada Story isi ditaruh di tengah supaya aman dari bilah atas dan bawah Instagram. */
    const val CONTENT_H = 1350
    private const val PAD = 72f

    private val EM = Color.parseColor("#EA5F0A")
    private val EM2 = Color.parseColor("#FF8A26")
    private val DAYS = arrayOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min")
    private val MONTHS = arrayOf("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember")
    private val MONTHS_SHORT = arrayOf("Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des")

    private class Ink(val ink: Int, val mute: Int, val empty: Int, val line: Int, val shadow: Boolean)

    private fun inkFor(bg: ShareBg): Ink = when (bg) {
        ShareBg.DARK -> Ink(Color.parseColor("#F5F5F7"), Color.parseColor("#9A9AA0"), Color.parseColor("#1C1C1E"), Color.parseColor("#2C2C2F"), false)
        else -> Ink(Color.WHITE, Color.argb(215, 255, 255, 255), Color.argb(46, 255, 255, 255), Color.argb(90, 255, 255, 255), true)
    }

    fun km1(km: Double): String = String.format(Locale.ROOT, "%.1f", km).replace('.', ',')
    fun km2(km: Double): String = String.format(Locale.ROOT, "%.2f", km).replace('.', ',')

    fun pace(minPerKm: Double?): String {
        if (minPerKm == null || minPerKm <= 0) return "-"
        val s = (minPerKm * 60).roundToInt()
        return "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
    }

    fun duration(sec: Int): String {
        val h = sec / 3600; val m = (sec % 3600) / 60; val s = sec % 60
        return if (h > 0) "${h}j ${m.toString().padStart(2, '0')}m" else "$m:${s.toString().padStart(2, '0')}"
    }

    /** Teks periode di bawah judul: "Rab, 11 Nov 2026", "Sen 9 Nov – Min 15 Nov 2026", "Oktober 2026". */
    fun periodLabel(sm: PeriodSummary): String = when (sm.period) {
        SharePeriod.DAY -> "${DAYS[sm.start.dayOfWeek.value - 1]}, ${sm.start.dayOfMonth} ${MONTHS_SHORT[sm.start.monthValue - 1]} ${sm.start.year}"
        SharePeriod.WEEK -> {
            val a = sm.start; val b = sm.end
            val left = "Sen ${a.dayOfMonth}" + if (a.monthValue != b.monthValue) " ${MONTHS_SHORT[a.monthValue - 1]}" else ""
            "$left – Min ${b.dayOfMonth} ${MONTHS_SHORT[b.monthValue - 1]} ${b.year}"
        }
        SharePeriod.MONTH -> "${MONTHS[sm.start.monthValue - 1]} ${sm.start.year}"
    }

    fun tag(p: SharePeriod): String = when (p) { SharePeriod.DAY -> "HARIAN"; SharePeriod.WEEK -> "MINGGUAN"; SharePeriod.MONTH -> "BULANAN" }

    /** Bitmap kartu. [photo] hanya dipakai bila [bg] = PHOTO (dipotong tengah ke rasio [size]). */
    fun render(sm: PeriodSummary, bg: ShareBg, photo: Bitmap? = null, day: ShareDayExtra? = null, size: ShareSize = ShareSize.FEED): Bitmap {
        val out = Bitmap.createBitmap(size.w, size.h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val ink = inkFor(bg)
        when (bg) {
            ShareBg.DARK -> c.drawColor(Color.parseColor("#111112"))
            ShareBg.PHOTO -> {
                if (photo != null) drawCover(c, photo, size) else c.drawColor(Color.parseColor("#2A3A33"))
                c.drawColor(Color.argb(105, 0, 0, 0))
            }
            ShareBg.CLEAR -> Unit
        }
        c.translate(0f, (size.h - CONTENT_H) / 2f)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        fun shadow() { if (ink.shadow) p.setShadowLayer(14f, 0f, 3f, Color.argb(130, 0, 0, 0)) else p.clearShadowLayer() }
        fun text(s: String, x: Float, y: Float, size: Float, color: Int, weight: Boolean = false, align: Paint.Align = Paint.Align.LEFT, spacing: Float = 0f) {
            p.reset(); p.isAntiAlias = true; p.textSize = size; p.color = color; p.textAlign = align; p.letterSpacing = spacing
            p.typeface = Typeface.create(if (weight) "sans-serif-medium" else "sans-serif", Typeface.NORMAL)
            shadow(); c.drawText(s, x, y, p)
        }
        fun width(s: String, size: Float, weight: Boolean = false, spacing: Float = 0f): Float {
            p.reset(); p.isAntiAlias = true; p.textSize = size; p.letterSpacing = spacing
            p.typeface = Typeface.create(if (weight) "sans-serif-medium" else "sans-serif", Typeface.NORMAL)
            return p.measureText(s)
        }

        // Kepala: merek di kiri, jenis periode di kanan.
        p.reset(); p.isAntiAlias = true; p.color = EM; shadow(); c.drawCircle(PAD + 10f, 106f, 10f, p)
        text("EnduranceVault", PAD + 32f, 117f, 32f, ink.mute)
        text(tag(sm.period), W - PAD, 117f, 32f, EM2, true, Paint.Align.RIGHT, 0.12f)
        text(periodLabel(sm), PAD, 196f, 42f, ink.mute)

        // Angka utama.
        val heroTxt = if (sm.period == SharePeriod.DAY) km2(sm.km) else km1(sm.km)
        var hs = 230f
        while (hs > 120f && width(heroTxt, hs, true) + 28f + width("km", 68f) > W - 2 * PAD) hs -= 10f
        val heroW = width(heroTxt, hs, true)
        text(heroTxt, PAD - 6f, 196f + 40f + hs * 0.82f, hs, ink.ink, true)
        text("km", PAD - 6f + heroW + 24f, 196f + 40f + hs * 0.82f, 68f, ink.mute)

        // Visual per periode, di kotak y = 520..900.
        val box = RectF(PAD, 520f, W - PAD, 900f)
        when (sm.period) {
            SharePeriod.DAY -> drawDay(c, p, box, ink, day)
            SharePeriod.WEEK -> drawWeek(c, p, box, ink, sm)
            SharePeriod.MONTH -> drawMonth(c, p, box, ink, sm)
        }

        // Garis pemisah dan empat statistik (2 x 2).
        p.reset(); p.isAntiAlias = true; p.color = ink.line; p.strokeWidth = 2f
        c.drawLine(PAD, 950f, W - PAD, 950f, p)
        val last = if (sm.period == SharePeriod.DAY && sm.avgHr != null) "Detak jantung" to "${sm.avgHr}" else
            if (sm.period == SharePeriod.DAY) "Terpanjang" to km2(sm.longestKm) else "Sesi lari" to "${sm.sessions}"
        val lastUnit = when (last.first) { "Detak jantung" -> "bpm"; "Terpanjang" -> "km"; else -> "kali" }
        val cells = listOf(
            Triple(Lang.tr("Durasi"), duration(sm.durationSec), ""),
            Triple(Lang.tr("Pace rata-rata"), pace(sm.avgPace), "/km"),
            Triple(Lang.tr("Elevasi"), "+${sm.gain}", "m"),
            Triple(Lang.tr(last.first), last.second, lastUnit),
        )
        val colW = (W - 2 * PAD) / 2f
        cells.forEachIndexed { i, (label, value, unit) ->
            val x = PAD + (i % 2) * colW
            val y = 1000f + (i / 2) * 170f
            text(label, x, y + 30f, 32f, ink.mute)
            text(value, x, y + 104f, 70f, ink.ink, true)
            if (unit.isNotEmpty()) text(unit, x + width(value, 70f, true) + 12f, y + 104f, 34f, ink.mute)
        }
        return out
    }

    private fun drawCover(c: Canvas, photo: Bitmap, size: ShareSize) {
        val target = size.w.toFloat() / size.h
        val r = photo.width.toFloat() / photo.height
        val src = if (r > target) {
            val sw = (photo.height * target).roundToInt(); val sx = (photo.width - sw) / 2
            Rect(sx, 0, sx + sw, photo.height)
        } else {
            val sh = (photo.width / target).roundToInt(); val sy = (photo.height - sh) / 2
            Rect(0, sy, photo.width, sy + sh)
        }
        c.drawBitmap(photo, src, Rect(0, 0, size.w, size.h), Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
    }

    /** Harian: rute di kiri, batang pace per km di kanan (batang lebih tinggi = lebih cepat). */
    private fun drawDay(c: Canvas, p: Paint, box: RectF, ink: Ink, day: ShareDayExtra?) {
        if (day == null) return
        val routeBox = RectF(box.left, box.top, box.left + 360f, box.bottom)
        val rt = day.route
        if (rt.size >= 2) {
            val mnx = rt.minOf { it.first }.toFloat(); val mxx = rt.maxOf { it.first }.toFloat()
            val mny = rt.minOf { it.second }.toFloat(); val mxy = rt.maxOf { it.second }.toFloat()
            val rw = max(1f, mxx - mnx); val rh = max(1f, mxy - mny)
            val sc = min((routeBox.width() - 30f) / rw, (routeBox.height() - 30f) / rh)
            val ox = routeBox.left + (routeBox.width() - rw * sc) / 2f; val oy = routeBox.top + (routeBox.height() - rh * sc) / 2f
            val path = Path()
            rt.forEachIndexed { i, pt ->
                val x = ox + (pt.first - mnx) * sc; val y = oy + (pt.second - mny) * sc
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.strokeWidth = 9f; p.color = EM
            p.strokeJoin = Paint.Join.ROUND; p.strokeCap = Paint.Cap.ROUND
            if (ink.shadow) p.setShadowLayer(12f, 0f, 3f, Color.argb(130, 0, 0, 0))
            c.drawPath(path, p)
            p.reset(); p.isAntiAlias = true; p.style = Paint.Style.FILL
            val a = rt.first(); val z = rt.last()
            p.color = Color.parseColor("#4CC38A"); c.drawCircle(ox + (a.first - mnx) * sc, oy + (a.second - mny) * sc, 14f, p)
            p.color = ink.ink; c.drawCircle(ox + (z.first - mnx) * sc, oy + (z.second - mny) * sc, 14f, p)
        }
        val area = RectF(box.left + 400f, box.top, box.right, box.bottom)
        if (day.segs.size >= 2) { drawSegChart(c, p, area, ink, day.segs); return }
        val sp = day.splitPace
        if (sp.isEmpty()) return
        val gap = 10f
        val bw = min(44f, (area.width() - gap * (sp.size - 1)) / sp.size)
        val total = bw * sp.size + gap * (sp.size - 1)
        val lo = sp.minOrNull() ?: 0.0; val hi = sp.maxOrNull() ?: 0.0
        val span = max(0.25, hi - lo)
        sp.forEachIndexed { i, pc ->
            val h = (60f + (1f - ((pc - lo) / span).toFloat()) * (area.height() - 60f)).coerceIn(30f, area.height())
            val x = area.right - total + i * (bw + gap)
            val w = if (day.lastPartial && i == sp.lastIndex) bw * 0.5f else bw
            p.reset(); p.isAntiAlias = true; p.color = if (pc == lo) EM2 else EM
            c.drawRoundRect(RectF(x, area.bottom - h, x + w, area.bottom), 8f, 8f, p)
        }
    }


    private fun roleColor(r: SegRole, ink: Ink): Int = when (r) {
        SegRole.REP -> EM
        SegRole.STRIDE -> Color.parseColor("#7F9CD6")
        SegRole.PROGRESSIVE -> Color.parseColor("#3F9E86")
        SegRole.CUSTOM -> Color.parseColor("#9B7FD1")
        else -> Color.argb(150, Color.red(ink.mute), Color.green(ink.mute), Color.blue(ink.mute))
    }

    /**
     * Grafik pace per segmen: lebar batang sebanding dengan jarak segmen, tinggi menurut kecepatan (lebih cepat = lebih tinggi),
     * warna menurut peran. Pace ditulis di atas batang repetisi bila muat (bila tidak, hanya di repetisi tercepat). Legenda di bawah.
     */
    private fun drawSegChart(c: Canvas, p: Paint, area: RectF, ink: Ink, segs: List<ShareSeg>) {
        val tp = Paint(Paint.ANTI_ALIAS_FLAG)
        fun tw(s: String, size: Float): Float { tp.reset(); tp.isAntiAlias = true; tp.textSize = size; return tp.measureText(s) }

        // Legenda: satu entri per label berbeda, dibungkus ke baris baru bila melebihi lebar.
        val entries = segs.map { it.role to it.label }.distinct().take(6)
        val lineH = 40f; val legSize = 26f
        var lines = 1; var cx = 0f
        entries.forEach { (_, label) ->
            val w = 22f + tw(label, legSize) + 26f
            if (cx + w > area.width() && cx > 0f) { lines++; cx = 0f }
            cx += w
        }
        val legendH = lines * lineH

        val chartTop = area.top + 36f
        val chartBottom = area.bottom - legendH - 14f
        val chartH = chartBottom - chartTop
        val n = segs.size
        val gap = 4f
        val avail = area.width() - gap * (n - 1)
        val totalKm = segs.sumOf { it.km }
        val raw = segs.map { max(8f, (it.km / totalKm * avail).toFloat()) }
        val k = min(1f, avail / raw.sum())
        val lo = segs.minOf { it.pace }; val hi = segs.maxOf { it.pace }
        val span = max(0.25, hi - lo)
        val reps = segs.filter { it.role == SegRole.REP }
        val fastest = reps.minByOrNull { it.pace }
        val labelAll = reps.isNotEmpty() && raw.indices.all { i -> segs[i].role != SegRole.REP || raw[i] * k >= 56f }

        var x = area.left
        segs.forEachIndexed { i, sg ->
            val w = raw[i] * k
            val h = (46f + (1f - ((sg.pace - lo) / span).toFloat()) * (chartH - 46f)).coerceIn(24f, chartH)
            p.reset(); p.isAntiAlias = true; p.color = roleColor(sg.role, ink)
            c.drawRoundRect(RectF(x, chartBottom - h, x + w, chartBottom), min(8f, w / 2f), min(8f, w / 2f), p)
            if (sg.role == SegRole.REP && (labelAll || sg === fastest)) {
                p.reset(); p.isAntiAlias = true; p.textSize = 26f; p.color = ink.ink; p.textAlign = Paint.Align.CENTER
                p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                if (ink.shadow) p.setShadowLayer(12f, 0f, 3f, Color.argb(130, 0, 0, 0))
                c.drawText(pace(sg.pace), (x + w / 2f).coerceIn(area.left + 30f, area.right - 30f), chartBottom - h - 10f, p)
            }
            x += w + gap
        }

        var lx = area.left; var ly = area.bottom - legendH + lineH - 10f
        entries.forEach { (role, label) ->
            val w = 22f + tw(label, legSize) + 26f
            if (lx + w > area.right + 1f && lx > area.left) { lx = area.left; ly += lineH }
            p.reset(); p.isAntiAlias = true; p.color = roleColor(role, ink)
            c.drawCircle(lx + 7f, ly - 9f, 7f, p)
            p.reset(); p.isAntiAlias = true; p.textSize = legSize; p.color = ink.mute
            if (ink.shadow) p.setShadowLayer(12f, 0f, 3f, Color.argb(130, 0, 0, 0))
            c.drawText(label, lx + 22f, ly, p)
            lx += w
        }
    }

    /** Mingguan: tujuh batang Senin..Minggu, nilai km di atas batang, hari terpanjang disorot. */
    private fun drawWeek(c: Canvas, p: Paint, box: RectF, ink: Ink, sm: PeriodSummary) {
        val n = 7
        val colW = box.width() / n
        val bw = colW * 0.66f
        val mx = max(1.0, sm.dailyKm.maxOrNull() ?: 1.0)
        val base = box.bottom - 50f
        val maxH = base - box.top - 44f
        for (i in 0 until n) {
            val v = sm.dailyKm.getOrElse(i) { 0.0 }
            val cx = box.left + colW * i + colW / 2f
            if (v > 0) {
                val h = (v / mx * (maxH - 8f)).toFloat() + 8f
                p.reset(); p.isAntiAlias = true; p.color = if (v == mx) EM2 else EM
                c.drawRoundRect(RectF(cx - bw / 2f, base - h, cx + bw / 2f, base), 12f, 12f, p)
                p.reset(); p.isAntiAlias = true; p.textSize = 30f; p.color = ink.ink; p.textAlign = Paint.Align.CENTER
                p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                if (ink.shadow) p.setShadowLayer(12f, 0f, 3f, Color.argb(130, 0, 0, 0))
                c.drawText(km1(v), cx, base - h - 14f, p)
            } else {
                p.reset(); p.isAntiAlias = true; p.color = ink.empty; c.drawCircle(cx, base - 8f, 7f, p)
            }
            p.reset(); p.isAntiAlias = true; p.textSize = 30f; p.color = ink.mute; p.textAlign = Paint.Align.CENTER
            if (ink.shadow) p.setShadowLayer(12f, 0f, 3f, Color.argb(130, 0, 0, 0))
            c.drawText(DAYS[i], cx, box.bottom - 6f, p)
        }
    }

    /** Bulanan: kalender mulai tanggal 1 (kolom Senin..Minggu), warna sel menurut jarak hari itu. */
    private fun drawMonth(c: Canvas, p: Paint, box: RectF, ink: Ink, sm: PeriodSummary) {
        val offset = sm.start.dayOfWeek.value - 1
        val rows = (offset + sm.dailyKm.size + 6) / 7
        val gap = 10f
        val cw = (box.width() - gap * 6) / 7f
        val ch = min(cw * 0.62f, (box.height() - 44f - gap * (rows - 1)) / rows)
        p.reset(); p.isAntiAlias = true; p.textSize = 28f; p.color = ink.mute; p.textAlign = Paint.Align.CENTER
        if (ink.shadow) p.setShadowLayer(12f, 0f, 3f, Color.argb(130, 0, 0, 0))
        for (i in 0 until 7) c.drawText(DAYS[i].take(1), box.left + i * (cw + gap) + cw / 2f, box.top + 26f, p)
        val top = box.top + 44f
        sm.dailyKm.forEachIndexed { i, v ->
            val pos = offset + i
            val x = box.left + (pos % 7) * (cw + gap); val y = top + (pos / 7) * (ch + gap)
            val col = when {
                v <= 0 -> ink.empty
                v < 6.5 -> Color.parseColor("#5A2A0B")
                v < 10 -> Color.parseColor("#A8470A")
                v < 15 -> EM
                else -> EM2
            }
            p.reset(); p.isAntiAlias = true; p.color = col
            c.drawRoundRect(RectF(x, y, x + cw, y + ch), 8f, 8f, p)
        }
    }
}
