package com.endurancevault.app.ui.video

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import com.endurancevault.app.domain.FrameStats
import com.endurancevault.app.domain.TrailBox
import com.endurancevault.app.domain.TrailData
import com.endurancevault.app.domain.TrailGeo
import com.endurancevault.app.domain.TrailLay
import com.endurancevault.app.domain.TrailPrefs
import com.endurancevault.app.domain.TrailRect
import com.endurancevault.app.domain.TrailText
import com.endurancevault.app.domain.TrailTimeline
import com.endurancevault.app.ui.sticker.StickerFonts
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Lapisan 2D video Trail 3D. Tiga bitmap dipakai ulang: [staticLayer] (latar, sekali), [chartLayer] (grafik elevasi,
 * tiap bingkai, hanya sebesar kotak grafik), dan [overLayer] (header, label, penanda, panel data, tiap bingkai).
 */
class TrailPainter(
    private val W: Int, private val H: Int,
    private val prefs: TrailPrefs, private val data: TrailData,
    private val ts: TrailScene, private val gl: TrailGl,
    private val lay: TrailLay, private val pal: TrailPalette,
    private val fonts: StickerFonts, private val photo: Bitmap?,
    private val title: String, private val dateText: String,
) {
    private val k = lay.k
    private val track = data.track
    private val total = data.totalKm
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()

    private val chartW = lay.chart.w.toInt().coerceAtLeast(2)
    private val chartH = lay.chart.h.toInt().coerceAtLeast(2)
    val chartBox = TrailBox(lay.chart.x, lay.chart.y, chartW.toFloat(), chartH.toFloat())

    private var staticBmp: Bitmap? = null
    private var chartBmp: Bitmap? = null
    private var overBmp: Bitmap? = null

    private val tp = 30f * k      // ruang atas grafik (label puncak)
    private val bp = 26f * k      // ruang bawah grafik (jalur zona dan label km)
    private val ph = chartH - tp - bp
    private val prof = data.profile
    private val plo: Double = prof?.let { it.lo - 0.08 * max(10.0, it.hi - it.lo) } ?: 0.0
    private val phi: Double = prof?.let { it.hi + 0.12 * max(10.0, it.hi - it.lo) } ?: 1.0

    private val zoneColors = intArrayOf(0xFF7F9CD6.toInt(), 0xFF3F9E86.toInt(), 0xFFD8B04A.toInt(), 0xFFE8844F.toInt(), 0xFFC84B3B.toInt())

    /** Kecerahan latar (0..1) di belakang panel data, untuk kartu otomatis. */
    private val bgBright: Float = when (prefs.bgMode) {
        "solid" -> luminance(parse(prefs.bgColor, 0xFF14100E.toInt()))
        "photo" -> photo?.let { photoBrightness(it) } ?: 0.1f
        else -> 0.1f
    }

    fun release() {
        staticBmp?.recycle(); chartBmp?.recycle(); overBmp?.recycle()
        staticBmp = null; chartBmp = null; overBmp = null
    }

    // ---------------------------------------------------------------- util

    private fun parse(hex: String, def: Int): Int = runCatching { Color.parseColor(hex) }.getOrDefault(def)
    private fun luminance(c: Int): Float = (0.2126f * Color.red(c) + 0.7152f * Color.green(c) + 0.0722f * Color.blue(c)) / 255f
    private fun photoBrightness(b: Bitmap): Float {
        val s = Bitmap.createScaledBitmap(b, 12, 12, true)
        var sum = 0f
        for (y in 0 until 12) for (x in 0 until 12) sum += luminance(s.getPixel(x, y))
        if (s !== b) s.recycle()
        return sum / 144f
    }
    private fun ca(c: Int, a: Float): Int = Color.argb((Color.alpha(c) * a.coerceIn(0f, 1f)).roundToInt(), Color.red(c), Color.green(c), Color.blue(c))

    private fun face(display: Boolean, bold: Boolean): Typeface = if (display) {
        fonts.num ?: Typeface.create("sans-serif-condensed", Typeface.BOLD)
    } else {
        fonts.body ?: Typeface.create("sans-serif-medium", if (bold) Typeface.BOLD else Typeface.NORMAL)
    }

    /** Teks satu baris; bila lebih lebar dari [maxW] (> 0) ukurannya diperkecil. Mengembalikan lebar yang tergambar. */
    private fun text(
        c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, align: Paint.Align = Paint.Align.LEFT,
        display: Boolean = false, bold: Boolean = true, ls: Float = 0f, maxW: Float = 0f, shadow: Boolean = false,
    ): Float {
        paint.reset(); paint.isAntiAlias = true
        paint.typeface = face(display, bold)
        paint.textSize = size
        paint.letterSpacing = ls
        var w = paint.measureText(s)
        if (maxW > 0 && w > maxW) { paint.textSize = size * maxW / w; w = maxW }
        paint.color = color
        paint.textAlign = align
        if (shadow) paint.setShadowLayer(size * 0.25f, 0f, size * 0.08f, Color.argb(150, 0, 0, 0))
        c.drawText(s, x, y, paint)
        paint.clearShadowLayer()
        return w
    }

    private fun measure(s: String, size: Float, display: Boolean = false, bold: Boolean = true, ls: Float = 0f): Float {
        paint.reset(); paint.isAntiAlias = true
        paint.typeface = face(display, bold); paint.textSize = size; paint.letterSpacing = ls
        return paint.measureText(s)
    }

    private fun fmtKm(km: Double, dp: Int = 2) = TrailText.f(km, dp)

    // ---------------------------------------------------------------- latar

    private fun ridge(c: Canvas, baseY: Float, amp: Float, seed: Float, freq: Float, color: Int, bottom: Int) {
        path.reset()
        path.moveTo(0f, H.toFloat())
        var x = 0f
        while (x <= W + 6f) {
            val t = x / W
            val n = 0.5 * sin((t * freq * 2 * PI + seed).toDouble()) + 0.3 * sin((t * freq * 5.1 * 2 * PI + seed * 1.7).toDouble()) +
                0.2 * sin((t * freq * 11.3 * 2 * PI + seed * 2.3).toDouble())
            val v = ((n + 1) / 2).coerceIn(0.0, 1.0).pow(1.5).toFloat()
            path.lineTo(x, baseY - amp * v)
            x += 6f
        }
        path.lineTo(W.toFloat(), H.toFloat()); path.close()
        paint.reset(); paint.isAntiAlias = true
        paint.shader = LinearGradient(0f, baseY - amp, 0f, baseY + amp * 0.6f, color, bottom, Shader.TileMode.CLAMP)
        c.drawPath(path, paint)
        paint.shader = null
    }

    private fun drawBackground(c: Canvas) {
        val mode = if (prefs.bgMode == "photo" && photo == null) "mount" else prefs.bgMode
        val hy = lay.scene.y + lay.scene.h * 0.30f
        when (mode) {
            "solid" -> c.drawColor(parse(prefs.bgColor, pal.base))
            "photo" -> {
                c.drawColor(Color.BLACK)
                val ph0 = photo!!
                val s = max(W.toFloat() / ph0.width, H.toFloat() / ph0.height)
                val dw = ph0.width * s; val dh = ph0.height * s
                rect.set((W - dw) / 2, (H - dh) / 2, (W + dw) / 2, (H + dh) / 2)
                paint.reset(); paint.isFilterBitmap = true
                c.drawBitmap(ph0, null, rect, paint)
                c.drawColor(Color.argb((prefs.bgDim * 2.55f).roundToInt(), 0, 0, 0))
            }
            else -> {
                paint.reset(); paint.isAntiAlias = true
                paint.shader = LinearGradient(0f, 0f, 0f, hy, intArrayOf(pal.skyTop, pal.skyMid, pal.skyLow), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
                c.drawRect(0f, 0f, W.toFloat(), hy + 2f, paint)
                paint.shader = null
                c.drawRect(0f, hy, W.toFloat(), H.toFloat(), paint.apply { color = pal.base })
                if (mode == "mount") {
                    val sr = min(W, H) * 0.085f
                    val sx = W * 0.72f; val sy = hy - min(W, H) * 0.10f
                    paint.shader = RadialGradient(sx, sy, sr * 3.2f, ca(pal.sun, 0.55f), Color.TRANSPARENT, Shader.TileMode.CLAMP)
                    c.drawCircle(sx, sy, sr * 3.2f, paint)
                    paint.shader = null
                    paint.color = pal.sun; c.drawCircle(sx, sy, sr, paint)
                    val hh = H.toFloat()
                    ridge(c, hy - 0.010f * hh, 0.15f * hh, 1.3f, 1.7f, pal.ranges[0], pal.base)
                    ridge(c, hy + 0.030f * hh, 0.13f * hh, 4.1f, 2.3f, pal.ranges[1], pal.base)
                    ridge(c, hy + 0.070f * hh, 0.11f * hh, 7.7f, 3.1f, pal.ranges[2], pal.base)
                }
            }
        }
        // Peredam bawah supaya panel data terbaca di atas latar apa pun
        val y0 = lay.stats.y - 70f * k
        paint.reset()
        paint.shader = LinearGradient(0f, y0, 0f, H.toFloat(), Color.TRANSPARENT, Color.argb(170, 0, 0, 0), Shader.TileMode.CLAMP)
        c.drawRect(0f, y0, W.toFloat(), H.toFloat(), paint)
        paint.shader = null
    }

    fun staticLayer(): Bitmap {
        val b = staticBmp ?: Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888).also { staticBmp = it }
        b.eraseColor(0)
        drawBackground(Canvas(b))
        return b
    }

    // ---------------------------------------------------------------- grafik elevasi

    private fun cxOf(km: Double): Float = (chartW * (km / total.coerceAtLeast(1e-9))).toFloat()
    private fun cyOf(e: Double): Float = (tp + ph - ((e - plo) / (phi - plo)) * ph).toFloat()

    private fun profilePath(upToKm: Double, close: Boolean): Path {
        val p = Path()
        val pr = prof ?: return p
        val n = pr.ele.size
        var started = false
        var lastX = 0f
        for (i in 0 until n) {
            val km = total * i / (n - 1)
            if (km > upToKm) break
            val x = cxOf(km); val y = cyOf(pr.ele[i])
            if (!started) { if (close) { p.moveTo(x, tp + ph); p.lineTo(x, y) } else p.moveTo(x, y); started = true } else p.lineTo(x, y)
            lastX = x
        }
        if (started && upToKm < total) {
            val x = cxOf(upToKm); val y = cyOf(pr.interp(upToKm))
            p.lineTo(x, y); lastX = x
        }
        if (started && close) { p.lineTo(lastX, tp + ph); p.close() }
        return p
    }

    /** Grafik elevasi (bagian bawah): profil redup, bagian tertempuh menyala, jalur zona HR, dan label km. */
    fun chartLayer(frac: Double, alpha: Float): Bitmap {
        val b = chartBmp ?: Bitmap.createBitmap(chartW, chartH, Bitmap.Config.ARGB_8888).also { chartBmp = it }
        b.eraseColor(0)
        val c = Canvas(b)
        val km = frac * total
        val a = alpha.coerceIn(0f, 1f)
        if (a <= 0f) return b
        val layer = c.saveLayerAlpha(0f, 0f, chartW.toFloat(), chartH.toFloat(), (a * 255).roundToInt())
        // Garis dasar
        paint.reset(); paint.isAntiAlias = true
        paint.color = ca(pal.ink, 0.18f); paint.strokeWidth = 1.5f * k
        c.drawLine(0f, tp + ph, chartW.toFloat(), tp + ph, paint)
        if (prof != null) {
            // Pita tanjakan
            if (prefs.showClimbs) for (cl in data.climbs) {
                paint.reset(); paint.color = ca(pal.accent, 0.10f)
                c.drawRect(cxOf(cl.k0), tp, cxOf(cl.k1), tp + ph, paint)
            }
            // Profil penuh (redup)
            val full = profilePath(total, true)
            paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.FILL; paint.color = ca(pal.ink, 0.10f)
            c.drawPath(full, paint)
            paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f * k; paint.color = ca(pal.ink, 0.32f)
            paint.strokeJoin = Paint.Join.ROUND
            c.drawPath(profilePath(total, false), paint)
            // Bagian tertempuh
            if (km > 0.001) {
                val lit = profilePath(km, true)
                paint.reset(); paint.isAntiAlias = true
                paint.shader = LinearGradient(0f, tp, 0f, tp + ph, ca(pal.accent, 0.62f), ca(pal.accent, 0.04f), Shader.TileMode.CLAMP)
                c.drawPath(lit, paint)
                paint.shader = null
                paint.style = Paint.Style.STROKE; paint.strokeWidth = 3.4f * k; paint.color = pal.accent; paint.strokeJoin = Paint.Join.ROUND
                c.drawPath(profilePath(km, false), paint)
            }
        }
        // Jalur zona HR di bawah garis dasar
        if (prefs.showZones && data.lo != null && data.hasHr) {
            val ns = 64
            val y0 = tp + ph + 4f * k; val hh = 6f * k
            for (i in 0 until ns) {
                val k0 = total * i / ns; val k1 = total * (i + 1) / ns
                val z = data.zone(data.hrAtKm((k0 + k1) / 2)) ?: continue
                val passed = (k0 + k1) / 2 <= km
                paint.reset(); paint.color = ca(zoneColors[z], if (passed) 0.95f else 0.28f)
                c.drawRect(cxOf(k0), y0, cxOf(k1) + 0.6f, y0 + hh, paint)
            }
        }
        // Label km
        val step = TrailGeo.kmStep(total)
        var q = 0
        while (q <= total + 1e-6) {
            val x = cxOf(q.toDouble())
            val al = if (q == 0) Paint.Align.LEFT else if (x > chartW - 24f * k) Paint.Align.RIGHT else Paint.Align.CENTER
            text(c, if (q == 0) "0" else q.toString(), x, chartH - 3f * k, 15f * k, pal.inkDim, al, bold = false)
            q += step
        }
        c.restoreToCount(layer)
        return b
    }

    // ---------------------------------------------------------------- lapisan atas

    private class Mark(val x: Float, val y: Float)

    private fun scenePt(f: Double, az: Double, lift: Float = 0f): Mark? {
        val p = ts.locate(f.toFloat().coerceIn(0f, 1f))
        val pr = gl.project(p[0], p[1] + lift + gl.metersPerPixel() * 3f, p[2], az) ?: return null
        // Saat zoom, titik di luar kotak adegan disembunyikan supaya penanda tidak melayang di atas judul atau panel data.
        val sc = lay.scene; val m = 12f * k
        if (pr[0] < sc.x - m || pr[0] > sc.x + sc.w + m || pr[1] < sc.y - m || pr[1] > sc.y + sc.h + m) return null
        return Mark(pr[0], pr[1])
    }

    private fun bubble(c: Canvas, label: String, sub: String?, cx: Float, cy: Float, a: Float, fill: Int, ink: Int, placed: MutableList<TrailRect>): Boolean {
        if (a <= 0.01f) return false
        val ts1 = 17f * k; val ts2 = 14f * k
        val w1 = measure(label, ts1, false, true, 0.06f); val w2 = if (sub != null) measure(sub, ts2, false, false) else 0f
        val bw = max(w1, w2) + 22f * k; val bh = (if (sub != null) 46f else 30f) * k
        val cands = listOf(
            TrailRect(cx - bw / 2, cy - bh - 14f * k, bw, bh),
            TrailRect(cx + 10f * k, cy - bh - 8f * k, bw, bh),
            TrailRect(cx - bw - 10f * k, cy - bh - 8f * k, bw, bh),
            TrailRect(cx - bw / 2, cy + 14f * k, bw, bh),
        )
        val pick = TrailGeo.place(placed, cands, 6f * k) ?: return false
        val bx = (pick.x).coerceIn(6f * k, W - bw - 6f * k)
        val by = pick.y.coerceIn(6f * k, H - bh - 6f * k)
        val layer = c.saveLayerAlpha(0f, 0f, W.toFloat(), H.toFloat(), (a.coerceIn(0f, 1f) * 255).roundToInt())
        paint.reset(); paint.isAntiAlias = true
        paint.color = ca(Color.BLACK, 0.55f); paint.strokeWidth = 1.6f * k
        c.drawLine(cx, cy, bx + bw / 2, if (by < cy) by + bh else by, paint)
        rect.set(bx, by, bx + bw, by + bh)
        paint.style = Paint.Style.FILL; paint.color = fill
        c.drawRoundRect(rect, 9f * k, 9f * k, paint)
        text(c, label, bx + bw / 2, by + (if (sub != null) 20f else 21f) * k, ts1, ink, Paint.Align.CENTER, ls = 0.06f)
        if (sub != null) text(c, sub, bx + bw / 2, by + 38f * k, ts2, ca(ink, 0.8f), Paint.Align.CENTER, bold = false)
        c.restoreToCount(layer)
        return true
    }

    /** Nama daerah terpilih (sekali per rig): di dalam bentuk slab, jenis penting dan dekat rute lebih dulu, saling berjauhan. */
    private val pickedPlaces: List<com.endurancevault.app.data.ScenePlace> =
        if (!prefs.showPlaces) emptyList()
        else com.endurancevault.app.data.PlaceLabels.select(ts.src.places, prefs.placeCount, ts.apothem * 0.7f) { p ->
            TrailGeo.metric(ts.sides, (p.x - ts.cx).toDouble(), (p.z - ts.cz).toDouble()) <= ts.apothem * 0.86
        }

    /** Pin nama daerah di atas slab: menempel di permukaan medan, mengecil bila jauh, memudar bila tertutup relief. */
    private fun placePins(c: Canvas, frac: Double, az: Double, placed: MutableList<TrailRect>) {
        if (pickedPlaces.isEmpty()) return
        val sc = lay.scene; val m = 14f * k
        val items = ArrayList<ScreenPlace>()
        for (p in pickedPlaces) {
            val reveal = com.endurancevault.app.data.PlaceLabels.reveal(true, frac, p.frac)
            if (reveal <= 0.01f) continue
            val lx = p.x - ts.cx; val lz = p.z - ts.cz
            val y = ts.worldY(lx, lz) + gl.metersPerPixel() * 2f
            val pr = gl.project(lx, y, lz, az) ?: continue
            if (pr[0] < sc.x + m || pr[0] > sc.x + sc.w - m || pr[1] < sc.y + m || pr[1] > sc.y + sc.h - m) continue
            val dep = gl.placeDepth(lx, y, lz, az) { sx, sz ->
                if (TrailGeo.metric(ts.sides, sx.toDouble(), sz.toDouble()) <= ts.apothem) ts.worldY(sx, sz) else -1e9f
            }
            items.add(ScreenPlace(p.name, pr[0], pr[1], dep[0], dep[1] * reveal))
        }
        val avoid = placed.map { RectF(it.x, it.y, it.x + it.w, it.y + it.h) }
        val drawn = PlacePins.draw(c, items, W, H, k * 0.85f, pal.accent, face(false, false), avoid)
        for (r in drawn) placed.add(TrailRect(r.left, r.top, r.width(), r.height()))
    }

    private fun dot(c: Canvas, x: Float, y: Float, r: Float, fill: Int, ring: Int, a: Float) {
        paint.reset(); paint.isAntiAlias = true
        paint.color = ca(ring, a); c.drawCircle(x, y, r + 2.4f * k, paint)
        paint.color = ca(fill, a); c.drawCircle(x, y, r, paint)
    }

    private fun drawHeader(c: Canvas) {
        val hx = lay.hdr.x; val hw = lay.hdr.w
        val squarish = !lay.land && lay.stats.y > 0 && (H.toFloat() / W <= 1.5f)
        val name = title.ifBlank { "Lari" }.uppercase(Locale.getDefault())
        val sub = listOfNotNull(prefs.location.takeIf { it.isNotBlank() }, dateText.takeIf { it.isNotBlank() }).joinToString("  ·  ")
        val wx = if (prefs.showWeather) data.weatherText() else null
        if (squarish) {
            val y = lay.hdr.y + 16f * k
            val w = text(c, name, hx, y, 24f * k, pal.ink, display = true, ls = 0.02f, maxW = hw * 0.62f, shadow = true)
            if (sub.isNotEmpty()) text(c, sub, hx + w + 14f * k, y, 15f * k, pal.inkDim, bold = false, maxW = hw - w - 20f * k)
            if (prefs.handle.isNotBlank()) text(c, prefs.handle, hx + hw, y, 16f * k, pal.accent, Paint.Align.RIGHT)
            return
        }
        val big = if (lay.land) 34f else 56f
        val y1 = lay.hdr.y + (if (lay.land) 12f else 46f) * k
        text(c, name, hx, y1, big * k, pal.ink, display = true, ls = 0.02f, maxW = hw, shadow = true)
        val sz = (if (lay.land) 17f else 24f) * k
        var y2 = y1 + (if (lay.land) 24f else 36f) * k
        if (sub.isNotEmpty()) { text(c, sub, hx, y2, sz, pal.inkDim, bold = false, maxW = hw); y2 += sz * 1.45f }
        if (wx != null && !lay.land) { text(c, wx, hx, y2, sz * 0.92f, ca(pal.accent, 0.95f), bold = false, maxW = hw) }
        if (prefs.handle.isNotBlank()) {
            val hy = if (lay.land) lay.hdr.y + 12f * k else lay.hdr.y + 10f * k
            text(c, prefs.handle, hx + hw, hy, (if (lay.land) 17f else 22f) * k, pal.accent, Paint.Align.RIGHT, maxW = hw * 0.4f)
        }
    }

    private fun chartAnnotations(c: Canvas, km: Double, st: FrameStats, az: Double, placed: MutableList<TrailRect>) {
        val cx0 = lay.chart.x; val cy0 = lay.chart.y
        val pr = prof
        if (pr != null) {
            // Puncak
            if (prefs.showPeak && km >= pr.kHi - 0.001) {
                val x = cx0 + cxOf(pr.kHi); val y = cy0 + cyOf(pr.hi)
                dot(c, x, y, 5.5f * k, pal.ink, Color.BLACK, 0.9f)
                val label = "PUNCAK ${pr.hi.roundToInt()} M"
                val w = measure(label, 15f * k, false, true, 0.06f)
                val tx = (x - w / 2).coerceIn(cx0, cx0 + lay.chart.w - w)
                text(c, label, tx, y - 12f * k, 15f * k, pal.ink, ls = 0.06f, shadow = true)
                placed.add(TrailRect(tx, y - 28f * k, w, 20f * k))
            }
            // Tanjakan aktif
            if (prefs.showClimbs) for (cl in data.climbs) {
                val a = TrailGeo.fade(km, cl.k0, cl.k1, max(0.05, (cl.k1 - cl.k0) * 0.25)).toFloat()
                if (a <= 0.02f) continue
                val mid = (cl.k0 + cl.k1) / 2
                val x = cx0 + cxOf(mid)
                val label = "TANJAKAN ${cl.n}  +${cl.gain.roundToInt()} M  ·  ${TrailText.f(cl.avg, 0)}%"
                val w = measure(label, 14f * k, false, true, 0.05f)
                val tx = (x - w / 2).coerceIn(cx0, cx0 + lay.chart.w - w)
                val layer = c.saveLayerAlpha(0f, 0f, W.toFloat(), H.toFloat(), (a * 255).roundToInt())
                text(c, label, tx, cy0 + tp - 6f * k, 14f * k, pal.accent, ls = 0.05f, shadow = true)
                c.restoreToCount(layer)
            }
            // Posisi sekarang + gradien
            val e = pr.interp(km)
            val x = cx0 + cxOf(km); val y = cy0 + cyOf(e)
            paint.reset(); paint.isAntiAlias = true
            paint.color = ca(pal.accent, 0.25f); c.drawCircle(x, y, 13f * k, paint)
            dot(c, x, y, 6.5f * k, pal.accent, Color.WHITE, 1f)
            if (prefs.showGrade && st.grade != null) {
                val g = st.grade!!
                val lbl = (if (g > 0.4) "+" else "") + g.roundToInt() + "%"
                val w = measure(lbl, 15f * k, false, true) + 18f * k
                val bx = (x - w / 2).coerceIn(cx0, cx0 + lay.chart.w - w)
                val by = (y - 36f * k).coerceAtLeast(cy0 - 4f * k)
                rect.set(bx, by, bx + w, by + 24f * k)
                paint.reset(); paint.isAntiAlias = true
                paint.color = ca(if (g > 2) 0xFFC84B3B.toInt() else if (g < -2) 0xFF3F9E86.toInt() else 0xFF55606B.toInt(), 0.92f)
                c.drawRoundRect(rect, 12f * k, 12f * k, paint)
                text(c, lbl, bx + w / 2, by + 17.5f * k, 15f * k, Color.WHITE, Paint.Align.CENTER)
            }
        }
    }

    private fun sceneMarks(c: Canvas, km: Double, frac: Double, az: Double, placed: MutableList<TrailRect>) {
        // Start
        val s0 = scenePt(0.0, az)
        if (s0 != null) dot(c, s0.x, s0.y, 6f * k, Color.WHITE, Color.BLACK, 0.95f)
        if (s0 != null && prefs.showKm) bubble(c, "START", null, s0.x, s0.y, 1f, ca(Color.BLACK, 0.55f), Color.WHITE, placed)
        // Km
        if (prefs.showKm) {
            val step = TrailGeo.kmStep(total)
            var q = step
            while (q < total - 0.25 * step) {
                val f = q / total
                val passed = km >= q
                val m = scenePt(f, az)
                if (m != null) {
                    if (passed) {
                        dot(c, m.x, m.y, 5.5f * k, pal.accent, Color.BLACK, 0.95f)
                        bubble(c, "$q KM", null, m.x, m.y, 1f, ca(pal.accent, 0.92f), Color.BLACK, placed)
                    } else dot(c, m.x, m.y, 4f * k, Color.WHITE, Color.BLACK, 0.35f)
                }
                q += step
            }
        }
        // Puncak
        val pr = prof
        if (pr != null && prefs.showPeak) {
            val m = scenePt(pr.kHi / total, az)
            if (m != null && km >= pr.kHi - 0.001) bubble(c, "PUNCAK", "${pr.hi.roundToInt()} m", m.x, m.y, 1f, ca(Color.BLACK, 0.6f), Color.WHITE, placed)
        }
        // Finish
        val fin = scenePt(1.0, az)
        if (fin != null) {
            val reached = frac >= 0.995
            dot(c, fin.x, fin.y, 6f * k, if (reached) pal.accent else Color.WHITE, Color.BLACK, if (reached) 1f else 0.45f)
            if (reached && prefs.showKm) bubble(c, "FINISH", "${fmtKm(total)} km", fin.x, fin.y, 1f, ca(pal.accent, 0.92f), Color.BLACK, placed)
        }
        // Pelari
        val cur = scenePt(frac, az)
        if (cur != null) {
            paint.reset(); paint.isAntiAlias = true
            paint.shader = RadialGradient(cur.x, cur.y, 26f * k, ca(pal.accent, 0.55f), Color.TRANSPARENT, Shader.TileMode.CLAMP)
            c.drawCircle(cur.x, cur.y, 26f * k, paint); paint.shader = null
            dot(c, cur.x, cur.y, 8f * k, pal.accent, Color.WHITE, 1f)
        }
    }

    // ---------------------------------------------------------------- panel data

    private fun cardOn(): Boolean = prefs.card != "none" || (prefs.autoContrast && bgBright > 0.55f)

    private fun drawStatsCard(c: Canvas) {
        if (!cardOn()) return
        val solid = prefs.card == "solid"
        val x = lay.stats.x + 14f * k; val w = lay.stats.w - 28f * k
        val y = lay.stats.y - 6f * k; val h = lay.stats.h + 6f * k
        rect.set(x, y, x + w, y + h)
        paint.reset(); paint.isAntiAlias = true
        paint.color = if (solid) ca(Color.BLACK, 0.82f) else ca(Color.BLACK, 0.38f)
        c.drawRoundRect(rect, 22f * k, 22f * k, paint)
        if (!solid) { paint.style = Paint.Style.STROKE; paint.strokeWidth = 1.4f * k; paint.color = ca(Color.WHITE, 0.16f); c.drawRoundRect(rect, 22f * k, 22f * k, paint) }
    }

    private fun drawBar(c: Canvas, x0: Float, x1: Float, y: Float, km: Double, withText: Boolean) {
        val h = 8f * k
        rect.set(x0, y, x1, y + h)
        paint.reset(); paint.isAntiAlias = true
        paint.color = ca(Color.WHITE, 0.16f); c.drawRoundRect(rect, h / 2, h / 2, paint)
        val fw = (x1 - x0) * (km / total.coerceAtLeast(1e-9)).coerceIn(0.0, 1.0).toFloat()
        if (fw > 0.5f) { rect.set(x0, y, x0 + max(fw, h), y + h); paint.color = pal.accent; c.drawRoundRect(rect, h / 2, h / 2, paint) }
        if (withText) {
            text(c, "${fmtKm(km)} KM", x0, y + h + 22f * k, 16f * k, pal.ink, ls = 0.04f)
            text(c, "${fmtKm(total)} KM", x1, y + h + 22f * k, 16f * k, pal.inkDim, Paint.Align.RIGHT, ls = 0.04f)
        }
    }

    private fun colValue(c: Canvas, col: com.endurancevault.app.domain.TrailCol, cx: Float, y: Float, valSize: Float, labSize: Float, a: Float, labelAbove: Boolean = true) {
        val aa = a.coerceIn(0f, 1f)
        if (aa <= 0f) return
        val layer = c.saveLayerAlpha(0f, 0f, W.toFloat(), H.toFloat(), (aa * 255).roundToInt())
        text(c, col.label, cx, y - valSize - (if (labelAbove) 8f * k else 0f), labSize, pal.inkDim, Paint.Align.CENTER, ls = 0.08f)
        text(c, col.value, cx, y, valSize, pal.ink, Paint.Align.CENTER, display = true, maxW = 150f * k, shadow = true)
        if (col.unit.isNotEmpty()) text(c, col.unit, cx, y + labSize * 1.55f, labSize, ca(pal.accent, 0.95f), Paint.Align.CENTER, ls = 0.08f)
        c.restoreToCount(layer)
    }

    private fun drawStats(c: Canvas, st: FrameStats, sum: FrameStats, km: Double, mix: Float) {
        val oa = (1f - mix * 2f).coerceAtLeast(0f); val sa = (mix * 2f - 1f).coerceAtLeast(0f)
        val live = TrailText.columns(prefs, st, data, true)
        val fin = TrailText.columns(prefs, sum, data, false)
        val x0 = lay.stats.x + (if (lay.stats.x > 0f) 0f else 40f * k)
        val cw = lay.stats.w - (if (lay.stats.x > 0f) 0f else 80f * k)
        val y0 = lay.stats.y
        val bar = prefs.showBar
        drawStatsCard(c)

        fun colsRow(cols: List<com.endurancevault.app.domain.TrailCol>, a: Float, baseY: Float, vs: Float, ls: Float) {
            val n = cols.size.coerceAtLeast(1)
            for (i in cols.indices) colValue(c, cols[i], x0 + cw * (i + 0.5f) / n, baseY, vs, ls, a)
        }

        when (prefs.layout) {
            "center" -> {
                val headKm = if (mix >= 0.5f) sum.distM / 1000.0 else km
                text(c, fmtKm(headKm), x0 + cw / 2, y0 + 60f * k, 66f * k, pal.ink, Paint.Align.CENTER, display = true, shadow = true)
                text(c, "KM", x0 + cw / 2 + measure(fmtKm(headKm), 66f * k, true) / 2 + 8f * k, y0 + 60f * k, 20f * k, pal.accent, ls = 0.08f)
                colsRow(live, oa, y0 + 132f * k, 40f * k, 14f * k)
                colsRow(fin, sa, y0 + 132f * k, 40f * k, 14f * k)
                if (bar) drawBar(c, x0, x0 + cw, y0 + 168f * k, if (mix >= 0.5f) total else km, false)
            }
            "tiles" -> {
                val gap = 10f * k
                val tw = (cw - gap) / 2; val th = 76f * k
                val set = if (mix >= 0.5f) fin else live
                val aa = if (mix >= 0.5f) max(sa, 0.0001f) else oa
                for (i in 0 until min(4, set.size)) {
                    val cx = x0 + (i % 2) * (tw + gap); val cy = y0 + (i / 2) * (th + gap)
                    rect.set(cx, cy, cx + tw, cy + th)
                    paint.reset(); paint.isAntiAlias = true; paint.color = ca(Color.WHITE, 0.10f)
                    c.drawRoundRect(rect, 16f * k, 16f * k, paint)
                    val layer = c.saveLayerAlpha(0f, 0f, W.toFloat(), H.toFloat(), (aa.coerceIn(0f, 1f) * 255).roundToInt())
                    text(c, set[i].label, cx + 16f * k, cy + 24f * k, 14f * k, pal.inkDim, ls = 0.08f)
                    val vw = text(c, set[i].value, cx + 16f * k, cy + 62f * k, 40f * k, pal.ink, display = true, maxW = tw * 0.62f)
                    text(c, set[i].unit, cx + 16f * k + vw + 8f * k, cy + 62f * k, 15f * k, pal.accent, ls = 0.08f)
                    c.restoreToCount(layer)
                }
                if (bar) drawBar(c, x0, x0 + cw, y0 + 2 * th + gap + 14f * k, if (mix >= 0.5f) total else km, false)
            }
            "compact" -> {
                colsRow(live, oa, y0 + 74f * k, 36f * k, 13f * k)
                colsRow(fin, sa, y0 + 74f * k, 36f * k, 13f * k)
                if (bar) drawBar(c, x0, x0 + cw, y0 + 102f * k, if (mix >= 0.5f) total else km, false)
            }
            else -> {
                colsRow(live, oa, y0 + 84f * k, 52f * k, 15f * k)
                colsRow(fin, sa, y0 + 84f * k, 52f * k, 15f * k)
                if (bar) drawBar(c, x0, x0 + cw, y0 + 126f * k, if (mix >= 0.5f) total else km, true)
            }
        }
        // Baris tambahan
        if (prefs.extraRow) {
            val ex = com.endurancevault.app.domain.TrailLayout.slH(prefs.layout, !bar) * k
            val set = if (mix >= 0.5f) TrailText.extras(sum, data, false) else TrailText.extras(st, data, true)
            val n = set.size
            for (i in 0 until n) {
                val cx = x0 + cw * (i + 0.5f) / n
                text(c, set[i].first, cx, y0 + ex + 34f * k, 30f * k, pal.ink, Paint.Align.CENTER, display = true, maxW = cw / n * 0.9f)
                text(c, set[i].second, cx, y0 + ex + 54f * k, 12f * k, pal.inkDim, Paint.Align.CENTER, ls = 0.08f)
            }
        }
    }

    /** Lapisan atas penuh bingkai pada titik linimasa [pt]. */
    fun overLayer(pt: TrailTimeline.Pt): Bitmap {
        val b = overBmp ?: Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888).also { overBmp = it }
        b.eraseColor(0)
        val c = Canvas(b)
        val a = pt.panelIn.toFloat().coerceIn(0f, 1f)
        val dy = (1f - a) * 26f * k
        val km = pt.frac * total
        val st = track.statsAt(pt.frac, true)
        val sum = track.statsAt(1.0, false)
        val placed = ArrayList<TrailRect>()

        // Header
        run {
            val layer = c.saveLayerAlpha(0f, 0f, W.toFloat(), H.toFloat(), (a * 255).roundToInt())
            c.translate(0f, -dy)
            drawHeader(c)
            c.restoreToCount(layer)
        }
        // Anotasi grafik (bergeser mengikuti grafik)
        run {
            val layer = c.saveLayerAlpha(0f, 0f, W.toFloat(), H.toFloat(), (a * 255).roundToInt())
            c.translate(0f, -dy)
            chartAnnotations(c, km, st, pt.azimuth, placed)
            c.restoreToCount(layer)
        }
        // Penanda di adegan
        if (a > 0.3f) {
            val layer = c.saveLayerAlpha(0f, 0f, W.toFloat(), H.toFloat(), (a * 255).roundToInt())
            sceneMarks(c, km, pt.frac, pt.azimuth, placed)
            placePins(c, pt.frac, pt.azimuth, placed)
            c.restoreToCount(layer)
        }
        // Panel data
        run {
            val layer = c.saveLayerAlpha(0f, 0f, W.toFloat(), H.toFloat(), (a * 255).roundToInt())
            c.translate(0f, dy)
            drawStats(c, st, sum, km, pt.summaryMix.toFloat())
            c.restoreToCount(layer)
        }
        return b
    }
}
