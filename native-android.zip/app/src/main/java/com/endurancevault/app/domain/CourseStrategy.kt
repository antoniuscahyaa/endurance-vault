package com.endurancevault.app.domain

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Strategi pacing berbasis medan dari jalur GPX (port dari 35-rute-ke-jam.js `rjPacing` dan 05b-strategi-medan.js `terrainStrategy`).
 *
 * Profil elevasi dipecah menjadi ruas tanjakan/turunan/datar, tiap ruas diberi pace dengan usaha setara (GAP Minetti),
 * lalu dinormalkan ke target waktu total. Turunan dinilai dari kemiringan dan permukaan; beban turunan kumulatif memperlambat turunan curam berikutnya.
 *
 * Belum diport dari web: zona HR per ruas dan kartu intensitas (butuh data zona dan riwayat lari), faktor lelah/panas
 * (rjPacing di web juga tidak memakainya, jadi hasilnya sama).
 */
object CourseStrategy {

    /** Titik jalur: lintang, bujur, elevasi (null bila tidak ada). */
    class Pt(val lat: Double, val lon: Double, val ele: Double?)

    /** Profil jalur: [ep] = pasangan (km, elevasi m) jarang-jarang, dihaluskan. */
    class CourseProfile(val km: Double, val gain: Double?, val noEle: Boolean, val ep: List<DoubleArray>)

    class Seg(var a: Int, var b: Int, var from: Double, var to: Double, var dz: Double) {
        var len = 0.0; var g = 0.0; var type = "flat"; var gain = 0.0; var loss = 0.0; var gMax = 0.0
        var pos = 0.0; var sf = 1.0; var qf = 1.0; var w = 0.0
        var gnd0 = 0.0; var ecc0 = 0.0; var ef = 0.0
        var kn = ""; var band = "flat"; var rec = false
        var min = 0.0; var pace = 0.0; var eta = 0.0
        var ext = false; var pr: DoubleArray? = null
    }

    class Result(
        val segs: List<Seg>, val big: Seg?, val longDn: Seg?, val steep: Seg?,
        val cmpUp: Double, val cmpDown: Double, val cmpFlat: Double,
        val gain: Double, val loss: Double, val km: Double, val strat: String, val tp: Double, val surf: String,
        val dnRunKm: Double, val dnRunN: Int, val dnCtlKm: Double, val dnCtlN: Int,
        val knSteep: Double, val knHi: Double, val knRec: Seg?, val knQf: Double,
        val minSwingM: Int,
    )

    /** Hasil rjPacing: [result] atau [err] = "waktu" | "elevasi" | "pendek". */
    class Outcome(val result: Result?, val err: String?)

    // ---------- profil jalur ----------

    fun courseProfile(pts: List<Pt>): CourseProfile? {
        if (pts.size < 2) return null
        val cum = DoubleArray(pts.size)
        for (i in 1 until pts.size) cum[i] = cum[i - 1] + ActBuilder.hav(pts[i - 1].lat, pts[i - 1].lon, pts[i].lat, pts[i].lon)
        val tot = cum[cum.size - 1]
        if (!(tot >= 500.0)) return null
        val has = pts.count { it.ele != null && it.ele.isFinite() }
        if (has < pts.size * 0.8) return CourseProfile(tot / 1000.0, null, true, emptyList())

        val raw = arrayOfNulls<Double>(pts.size)
        var last: Double? = null
        for (i in pts.indices) { val v = pts[i].ele; if (v != null && v.isFinite()) last = v; raw[i] = last }
        val first = raw.firstOrNull { it != null }
        for (i in raw.indices) { if (raw[i] == null) raw[i] = first else break }
        val r = raw.map { it ?: 0.0 }
        val sm = DoubleArray(r.size) { k ->
            var a = 0.0; var n = 0
            for (j in max(0, k - 2)..min(r.size - 1, k + 2)) { a += r[j]; n++ }
            a / n
        }
        var gain = 0.0; var ref = sm[0]
        for (i in 1 until sm.size) {
            if (sm[i] - ref >= 3) { gain += sm[i] - ref; ref = sm[i] } else if (ref - sm[i] >= 3) ref = sm[i]
        }
        fun eleAt(x: Double): Double {
            var lo = 0; var hi = cum.size - 1
            while (hi - lo > 1) { val m = (lo + hi) shr 1; if (cum[m] <= x) lo = m else hi = m }
            val d = cum[hi] - cum[lo]
            return if (d > 0) sm[lo] + (sm[hi] - sm[lo]) * min(1.0, max(0.0, (x - cum[lo]) / d)) else sm[lo]
        }
        // profil jarang untuk analisis medan: tiap >= 100 m, maks ~800 titik, dihaluskan 3 titik
        val stp = max(100.0, tot / 800.0)
        val e0 = ArrayList<DoubleArray>()
        var xx = 0.0
        while (xx < tot) { e0.add(doubleArrayOf(xx, eleAt(xx))); xx += stp }
        e0.add(doubleArrayOf(tot, eleAt(tot)))
        val ep = e0.mapIndexed { k, q ->
            val a = e0[max(0, k - 1)][1]; val b = q[1]; val c = e0[min(e0.size - 1, k + 1)][1]
            doubleArrayOf(Js.round(q[0] / 10) / 100, Js.round((a + b + c) / 3 * 10) / 10)
        }
        return CourseProfile(tot / 1000.0, gain, false, ep)
    }

    // ---------- ruas medan ----------

    private fun fin(s: Seg): Seg {
        s.len = s.to - s.from
        s.g = if (s.len > 0) s.dz / (s.len * 1000) else 0.0
        s.type = if (s.g >= 0.025) "up" else if (s.g <= -0.025) "down" else "flat"
        s.gain = max(0.0, s.dz); s.loss = max(0.0, -s.dz)
        return s
    }

    fun terrainSegs(ep: List<DoubleArray>, minVIn: Double = 0.0, minLenIn: Double = 0.0): List<Seg> {
        val n = ep.size
        if (n < 3) return emptyList()
        val tot = ep[n - 1][0] - ep[0][0]
        val minV = if (minVIn > 0) minVIn else (if (tot <= 25) 15.0 else if (tot <= 60) 25.0 else 40.0)
        val minLen = if (minLenIn > 0) minLenIn else (if (tot <= 25) 0.3 else 0.5)
        fun z(i: Int) = ep[i][1]

        // 1. titik balik zigzag: ayunan vertikal >= minV memutar arah
        val tp = arrayListOf(0)
        var dir = 0; var hi = 0; var lo = 0
        for (i in 1 until n) {
            val zi = z(i)
            if (zi > z(hi)) hi = i
            if (zi < z(lo)) lo = i
            when (dir) {
                0 -> {
                    if (zi - z(lo) >= minV) { if (lo != 0) tp.add(lo); dir = 1; hi = i }
                    else if (z(hi) - zi >= minV) { if (hi != 0) tp.add(hi); dir = -1; lo = i }
                }
                1 -> if (z(hi) - zi >= minV) { tp.add(hi); dir = -1; lo = i }
                else -> if (zi - z(lo) >= minV) { tp.add(lo); dir = 1; hi = i }
            }
        }
        if (dir == 1 && tp.last() != hi) tp.add(hi) else if (dir == -1 && tp.last() != lo) tp.add(lo)
        if (tp.last() != n - 1) tp.add(n - 1)

        // 2. ruas antar titik balik
        val segs = ArrayList<Seg>()
        fun push(a: Int, b: Int) { segs.add(Seg(a, b, ep[a][0], ep[b][0], z(b) - z(a))) }
        for (i in 1 until tp.size) {
            val a0 = tp[i - 1]; val b0 = tp[i]
            var a = a0; var b = b0
            val dz0 = z(b0) - z(a0); val sg = if (dz0 >= 0) 1 else -1; val tol = max(3.0, 0.04 * abs(dz0))
            while (a + 1 < b && sg * (z(a + 1) - z(a0)) <= tol) a++
            while (b - 1 > a && sg * (z(b0) - z(b - 1)) <= tol) b--
            if (a >= b) { a = a0; b = b0 }
            if (a > a0) push(a0, a)
            push(a, b)
            if (b < b0) push(b, b0)
        }
        segs.forEach { fin(it) }

        // 3. gabungkan ruas pendek dan ruas bertipe sama yang berurutan
        fun mergeInto(x: Seg, y: Seg): Seg {
            val s = Seg(min(x.a, y.a), max(x.b, y.b), min(x.from, y.from), max(x.to, y.to), 0.0)
            s.dz = z(s.b) - z(s.a)
            return fin(s)
        }
        var changed = true; var guard = 0
        while (changed && segs.size > 1 && guard++ < 500) {
            changed = false
            for (i in segs.indices) {
                val s = segs[i]; var nb: Seg? = null; var ni = -1
                if (i > 0 && segs[i - 1].type == s.type) { nb = segs[i - 1]; ni = i - 1 }
                else if (i < segs.size - 1 && segs[i + 1].type == s.type) { nb = segs[i + 1]; ni = i + 1 }
                else if (s.len < minLen && abs(s.dz) < minV * 1.5) {
                    ni = if (i == 0) 1 else if (i == segs.size - 1) i - 1 else if (segs[i - 1].len >= segs[i + 1].len) i - 1 else i + 1
                    nb = segs[ni]
                }
                if (nb != null) {
                    val m = mergeInto(s, nb); val l = min(i, ni)
                    segs.removeAt(l); segs.removeAt(l); segs.add(l, m)
                    changed = true; break
                }
            }
        }
        // 4. kemiringan tertinggi (jendela >= 0,25 km) untuk menandai bagian yang perlu hike
        segs.forEach { it.gMax = segMaxG(ep, it) }
        return segs
    }

    private fun segMaxG(ep: List<DoubleArray>, s: Seg): Double {
        var mx = 0.0
        for (j in s.a until s.b) {
            for (k in j + 1..s.b) {
                val dl = ep[k][0] - ep[j][0]
                if (dl >= 0.25) { val g = (ep[k][1] - ep[j][1]) / (dl * 1000); if (abs(g) > abs(mx)) mx = g; break }
            }
        }
        return mx
    }

    /** Pecah turunan panjang (>= 0,6 km) menurut kelas kemiringan: <2,5%, 2,5-6%, 6-9%, >= 9%. */
    fun dnSplit(segs: List<Seg>, ep: List<DoubleArray>): List<Seg> {
        class W(var a: Int, var b: Int, var c: Int = 0)
        fun cls(g: Double): Int { val a = -g; return if (a < 0.025) 0 else if (a < 0.06) 1 else if (a < 0.09) 2 else 3 }
        fun ln(x: W) = ep[x.b][0] - ep[x.a][0]
        fun gr(x: W): Double { val d = ln(x); return if (d > 0) (ep[x.b][1] - ep[x.a][1]) / (d * 1000) else 0.0 }
        fun coalesce(r: List<W>): MutableList<W> {
            val o = ArrayList<W>()
            r.forEach { x -> val q = o.lastOrNull(); if (q != null && q.c == x.c) q.b = x.b else o.add(W(x.a, x.b, x.c)) }
            return o
        }
        val out = ArrayList<Seg>()
        for (s in segs) {
            if (s.type != "down" || s.len < 0.6 || s.b - s.a < 4) { out.add(s); continue }
            val w = ArrayList<W>(); var a = s.a
            for (k in s.a + 1..s.b) { if (ep[k][0] - ep[a][0] >= 0.25 || k == s.b) { w.add(W(a, k)); a = k } }
            if (w.size >= 2 && ln(w.last()) < 0.12) { w[w.size - 2].b = w.last().b; w.removeAt(w.size - 1) }
            w.forEach { it.c = cls(gr(it)) }
            var r = coalesce(w); var guard = 0
            while (r.size > 1 && guard++ < 200) {
                var mi = -1; var ml = 1e9
                for (i in r.indices) { val l = ln(r[i]); if (l < 0.3 && l < ml) { ml = l; mi = i } }
                if (mi < 0) break
                val ni = if (mi == 0) 1 else if (mi == r.size - 1) mi - 1
                else if (abs(r[mi - 1].c - r[mi].c) <= abs(r[mi + 1].c - r[mi].c)) mi - 1 else mi + 1
                val m = W(min(r[mi].a, r[ni].a), max(r[mi].b, r[ni].b)); m.c = cls(gr(m))
                val l = min(mi, ni)
                r.removeAt(l); r.removeAt(l); r.add(l, m)
                r = coalesce(r)
            }
            if (r.size < 2) { out.add(s); continue }
            for (x in r) {
                val n = Seg(x.a, x.b, ep[x.a][0], ep[x.b][0], ep[x.b][1] - ep[x.a][1])
                fin(n); n.gMax = segMaxG(ep, n); out.add(n)
            }
        }
        return out
    }

    // ---------- permukaan dan kemampuan lari di turunan ----------

    private val TH = mapOf("dry" to doubleArrayOf(.05, .09, .16), "norm" to doubleArrayOf(.04, .08, .13), "slip" to doubleArrayOf(.03, .05, .09))
    private val FLOOR = mapOf("dry" to .72, "norm" to .72, "slip" to .85)
    private val KK = mapOf("dry" to 5.0, "norm" to 6.0, "slip" to 8.0)

    fun surfKey(v: String?): String = if (v == "dry" || v == "slip") v else "norm"
    fun surfLbl(k: String): String = when (surfKey(k)) { "dry" -> "padat/kering"; "slip" -> "licin (basah/lumpur/berbatu)"; else -> "trail biasa" }

    private fun dnEff(g: Double, gm: Double) = max(abs(g), 0.8 * abs(gm))
    private fun dnBand(g: Double, gm: Double, surf: String): String {
        val t = TH.getValue(surfKey(surf)); val e = dnEff(g, gm)
        return if (e < t[0]) "easy" else if (e < t[1]) "fast" else if (e < t[2]) "careful" else "technical"
    }

    /** Bobot waktu relatif terhadap datar. Keuntungan turunan dibatasi (lantai), turunan curam dihukum, makin licin makin berat. */
    fun gradeCost(g: Double, surf: String): Double {
        val base = ActInsights.minettiCost(g) / 3.6
        if (g >= 0) return base
        val k = surfKey(surf); val a = -g
        var w = max(base, FLOOR.getValue(k)); val th = TH.getValue(k)[1]
        if (a > th) w = max(w, FLOOR.getValue(k) + (a - th) * KK.getValue(k))
        return w
    }

    private fun tsBand(s: Seg, surf: String): String {
        val g = abs(s.g); val gm = abs(s.gMax)
        return when (s.type) {
            "up" -> if (g >= 0.12 || (gm >= 0.18 && s.len <= 1.5)) "hike" else if (g >= 0.08) "steep" else if (g >= 0.05) "mid" else "gentle"
            "down" -> dnBand(s.g, s.gMax, surf)
            else -> "flat"
        }
    }

    // ---------- strategi ----------

    /** [tp] = target waktu total (menit), [strat] = even | neg | cons, [surf] = dry | norm | slip. */
    fun terrainStrategy(km: Double, tp: Double, prof: CourseProfile, strat: String = "even", surf: String = "norm"): Result? {
        val ep = prof.ep
        if (ep.size < 3 || !(km > 0)) return null
        val sk = surfKey(surf)
        val segs = dnSplit(terrainSegs(ep), ep)
        if (segs.isEmpty()) return null
        val epEnd = ep.last()[0]; val scl = if (epEnd > 0) km / epEnd else 1.0

        var wsum = 0.0; var tot = 0.0; var ecc = 0.0; var gnd = 0.0; var qfMax = 1.0
        for (s in segs) {
            s.from *= scl; s.to *= scl; s.len = s.to - s.from
            val pos = (s.from + s.to) / 2 / km
            var sf = 1.0; var qf = 1.0
            if (strat == "neg") sf = 1.04 - 0.08 * pos else if (strat == "cons") sf = if (pos < .15) 1.05 else 1.0
            s.gnd0 = gnd; s.ecc0 = ecc
            if (s.type == "down") {
                val ef = dnEff(s.g, s.gMax); s.ef = ef
                if (ef >= 0.05) qf = 1 + min(0.08, 0.008 * ecc / 100)
                s.kn = if (ef >= 0.09 && s.loss >= 40) "hi" else if (ef >= 0.06 && s.loss >= 30) (if (ecc >= 400) "hi" else "mid") else ""
                s.band = tsBand(s, sk)
                s.rec = ef < 0.06 && s.len >= 0.4 && (s.band == "easy" || s.band == "fast") && gnd >= 30 && s.kn.isEmpty()
                if (s.rec) qf = 1.06 // recovery: sengaja 6% lebih pelan dari usaha rata supaya HR turun
                ecc += s.loss * (if (ef >= 0.06) 1.0 else 0.3)
            } else if (s.type == "up") gnd += s.gain
            if (qf > qfMax && !s.rec) qfMax = qf
            s.qf = qf; s.pos = pos; s.sf = sf
            s.w = s.len * gradeCost(s.g, sk) * sf * qf
            wsum += s.w; tot += s.len
        }
        val base = tp / wsum
        var cum = 0.0; var up = 0.0; var dn = 0.0; var flat = 0.0
        for (s in segs) {
            s.min = base * s.w; s.pace = if (s.len > 0) s.min / s.len else 0.0
            cum += s.min; s.eta = cum; s.band = tsBand(s, sk)
            s.rec = s.type == "down" && s.ef < 0.06 && s.len >= 0.4 && (s.band == "easy" || s.band == "fast") && s.gnd0 >= 30 && s.kn.isEmpty()
            when (s.type) { "up" -> up += s.len; "down" -> dn += s.len; else -> flat += s.len }
            // kemiringan sangat curam: rumus GAP kurang andal, beri kisaran kasar
            val ex = max(abs(s.g), 0.8 * abs(s.gMax))
            s.ext = ex >= 0.2
            if (s.ext) { val u = if (ex >= 0.3) 0.15 else 0.10; s.pr = doubleArrayOf(s.pace * (1 - u), s.pace * (1 + u * 1.5)) }
        }
        var big: Seg? = null; var longDn: Seg? = null; var steep: Seg? = null
        for (s in segs) {
            if (s.type == "up" && (big == null || s.gain > big.gain)) big = s
            if (s.type == "down" && (longDn == null || s.loss > longDn.loss)) longDn = s
            if (steep == null || abs(s.gMax) > abs(steep.gMax)) steep = s
        }
        var kl = 0.0; var kh = 0.0; var rk: Seg? = null
        for (s in segs) {
            if (s.kn.isNotEmpty()) { kl += s.loss; if (s.kn == "hi") kh += s.loss }
            if (s.rec && (rk == null || s.len > rk.len)) rk = s
        }
        var dr = 0.0; var dc = 0.0; var drN = 0; var dcN = 0
        for (s in segs) {
            if (s.type != "down") continue
            if (s.band == "easy" || s.band == "fast") { dr += s.len; drN++ } else { dc += s.len; dcN++ }
        }
        val swing = if (km <= 25) 15 else if (km <= 60) 25 else 40
        return Result(
            segs, big, longDn, steep, up / tot, dn / tot, flat / tot,
            segs.sumOf { it.gain }, segs.sumOf { it.loss }, km, strat, tp, sk,
            dr, drN, dc, dcN, kl, kh, rk, (qfMax - 1) * 100, swing,
        )
    }

    /** Padanan rjPacing: target waktu teks ("h:mm:ss", "mm:ss", menit). */
    fun pacing(pts: List<Pt>, target: String, strat: String, surf: String): Outcome {
        val m = Js.parseDur(target)
        if (m.isNaN() || !(m > 0)) return Outcome(null, "waktu")
        val prof = courseProfile(pts)
        if (prof == null || prof.noEle || prof.ep.isEmpty()) return Outcome(null, if (prof != null && prof.noEle) "elevasi" else "pendek")
        val r = terrainStrategy(prof.km, m, prof, strat, surf) ?: return Outcome(null, "pendek")
        return Outcome(r, null)
    }

    fun errText(code: String?): String = when (code) {
        "waktu" -> "Isi target waktu, mis. 5:30:00, untuk melihat pace per ruas."
        "elevasi" -> "Berkas ini tidak punya data elevasi, jadi pace per medan tidak bisa dihitung."
        else -> "Rute terlalu pendek atau terlalu datar untuk dipecah menjadi ruas medan."
    }

    // ---------- teks ----------

    private fun ds(x: Double): String = Js.n(x).replace('.', ',')
    private fun pct(g: Double): String = ds(Js.round(abs(g) * 1000) / 10)

    fun segLabel(s: Seg): String {
        if (s.type == "down" && s.band != "technical") {
            if (s.rec) return "recovery"
            if (s.kn == "hi") return "hemat lutut"
            if (s.kn == "mid" && s.band != "easy") return "terkontrol"
        }
        return bandLabel(s.band)
    }

    fun bandLabel(b: String): String = when (b) {
        "hike" -> "hike"; "steep" -> "curam"; "mid" -> "sedang"; "gentle" -> "landai"; "technical" -> "teknis"
        "careful" -> "waspada"; "fast" -> "lari-able"; "easy" -> "landai"; "flat" -> "datar"; else -> ""
    }

    /** Arahan satu ruas. */
    fun tip(s: Seg, r: Result): String {
        val late = s.pos >= .7; val early = s.pos < .25
        if (s.type == "down" && s.band != "technical") {
            if (s.rec) return "Segmen recovery: turun landai setelah tanjakan. Jangan dikejar; biarkan HR turun, minum dan makan di sini, langkah ringan."
            if (s.kn == "hi") return if (late || s.ecc0 >= 400)
                "Turunan curam di saat kuadriseps sudah terbebani. Hemat lutut: langkah pendek, kadens tinggi, rem dari pinggul, jangan buka langkah. Pace bukan prioritas, boleh jalan di bagian terjal."
            else "Turunan curam: beban terbesar ada di lutut dan kuadriseps, bukan napas. Jangan tergoda membuang waktu di sini; langkah pendek, kadens tinggi, tahan kecepatan di bawah yang terasa bebas."
            if (s.kn == "mid" && s.band != "easy") return "Turunan sedang-curam: masih lari-able tapi kontrol. Kadens tinggi, jangan membuka langkah, dan hemat kuadriseps untuk ruas berikutnya."
        }
        val slip = r.surf == "slip"
        return when (s.band) {
            "hike" -> "Hike bertenaga, langkah pendek, tangan di paha. Jangan paksa lari: usaha lebih mahal daripada waktu yang didapat."
            "steep" -> if (early) "Tahan di awal: ini terlalu curam untuk dipakai membuang tenaga. Lari pelan atau hike selang-seling."
            else "Curam. Lari pelan atau selang-seling hike, jaga napas tetap bisa bicara pendek."
            "mid" -> if (early) "Jangan terpancing. Usaha di bawah pace lomba datar, nikmati dulu."
            else "Usaha stabil. Pendekkan langkah, naikkan kadens, bahu rileks."
            "gentle" -> "Tanjakan landai: mudah terlalu cepat. Tetap di usaha rata."
            "technical" -> if (slip) "Turunan curam dan licin: tidak realistis dilari. Turun dengan langkah pendek, lutut menekuk, pegang pohon/tali bila ada; jalan kaki lebih cepat daripada jatuh."
            else "Turunan curam/teknis: langkah pendek, pandangan 3–4 m ke depan, rem dari pinggul. Boleh jalan di bagian terjal. Hemat quad untuk akhir lomba."
            "careful" -> if (slip) "Turunan lumayan curam di medan licin: bisa dilari pelan, tapi rem aktif, langkah pendek, jangan percaya cengkeram sepatu. Pace tidak dikejar."
            else "Turunan cukup curam: masih bisa dilari tapi dikontrol. Langkah pendek, kadens tinggi, jangan membuka langkah. Pace tidak sebebas turunan landai."
            "fast" -> (if (slip) "Turunan landai-sedang di medan licin: masih lari-able, tapi cek cengkeram tiap beberapa langkah. " else "") +
                (if (late) "Turunan enak di paruh akhir: bila kaki masih segar, ini tempat membayar waktu."
                else "Turunan lari-able: biarkan gravitasi bekerja, tapi jangan sprint di paruh awal. Kuadriseps harus cukup sampai finis.")
            "easy" -> "Turun landai: pulihkan napas dan makan/minum di sini."
            else -> if (late) "Datar/bergelombang di paruh akhir: pertahankan ritme, ini ujian disiplin."
            else "Datar/bergelombang: cari ritme usaha yang konstan, jangan kejar pace jam."
        }
    }

    /** Poin-poin ringkasan strategi (padanan tsSummary tanpa bagian zona HR). */
    fun summary(r: Result): List<String> {
        val ln = ArrayList<String>()
        fun f(x: Double) = ds(Js.round(x * 100))
        ln.add("Komposisi jalur: ${f(r.cmpUp)}% menanjak, ${f(r.cmpDown)}% menurun, ${f(r.cmpFlat)}% datar/bergelombang. Total naik +${Js.roundI(r.gain)} m, turun −${Js.roundI(r.loss)} m.")
        r.big?.let { b ->
            if (b.gain >= 30) {
                val where = if (b.pos < .33) "di sepertiga awal" else if (b.pos < .66) "di tengah lomba" else "di sepertiga akhir"
                val adv = if (b.pos < .33) "Jangan habiskan tenaga sebelum dan di tanjakan ini; targetkan usaha lebih rendah dari rasa mampu."
                else if (b.pos < .66) "Masuk dengan tenaga dan nutrisi yang terisi: makan 10–15 menit sebelum kakinya."
                else "Hemat dari awal supaya masih punya kaki untuk tanjakan ini; di sinilah lomba sering diputuskan."
                ln.add("Tanjakan penentu: km ${Js.fmtKm(b.from)}–${Js.fmtKm(b.to)} (+${Js.roundI(b.gain)} m, rata-rata ${pct(b.g)}%), $where. $adv")
            }
        }
        r.longDn?.let { d ->
            if (d.loss >= 40) ln.add("Turunan terpanjang: km ${Js.fmtKm(d.from)}–${Js.fmtKm(d.to)} (−${Js.roundI(d.loss)} m). " +
                (if (d.pos < .5) "Terlalu cepat di sini menguras kuadriseps untuk sisa lomba." else "Bila kaki masih baik, ruas ini bisa dipakai menambah kecepatan."))
        }
        if (r.dnRunN + r.dnCtlN > 0) {
            fun f1(x: Double) = ds(Js.round(x * 10) / 10)
            ln.add("Cek turunan (permukaan ${surfLbl(r.surf)}): ${r.dnRunN} ruas lari-able (${f1(r.dnRunKm)} km), ${r.dnCtlN} ruas perlu dikontrol atau teknis (${f1(r.dnCtlKm)} km). " +
                "Pace turunan dibatasi supaya tidak terlalu optimis; di medan licin keuntungan turunan jauh lebih kecil.")
        }
        if (r.loss >= 100) {
            val lvl = if (r.knSteep >= 600) "tinggi" else if (r.knSteep >= 250) "sedang" else "ringan"
            val fh = r.segs.firstOrNull { it.kn == "hi" }
            ln.add("Beban lutut turunan: $lvl. Total turun −${Js.roundI(r.loss)} m, ${Js.roundI(r.knSteep)} m di antaranya di turunan ≥ 6–9% (beban eksentrik terbesar)" +
                (if (fh != null) ", pertama di km ${Js.fmtKm(fh.from)}" + (if (fh.pos < .4) " (awal lomba: tahan)" else "") else "") + ". " +
                (if (r.knQf >= 0.5) "Pace turunan curam di paruh akhir sengaja diperlambat sampai +${ds(Js.round(r.knQf))}% karena kuadriseps makin lelah. " else "") +
                "Patokan umum, bukan hukum.")
            val rc = r.knRec
            if (rc != null) ln.add("Segmen recovery: km ${Js.fmtKm(rc.from)}–${Js.fmtKm(rc.to)} (−${Js.roundI(rc.loss)} m, ${pct(rc.g)}%), turun landai setelah tanjakan. Turunkan HR, minum dan makan di sini.")
            else ln.add("Tidak ada turunan landai (2,5–6%, ≥ 0,4 km) setelah tanjakan yang cocok untuk recovery; recovery bisa diambil di datar atau saat hike.")
        }
        val fl = r.segs.filter { it.type == "flat" && it.len >= 1 }
        if (fl.size >= 2) {
            val f0 = fl.first(); val f1 = fl.last(); val rr = f1.pace / f0.pace
            if (f0.pace > 0 && abs(rr - 1) >= 0.03) {
                val rs = ArrayList<String>()
                val gc = gradeCost(f1.g, r.surf) / gradeCost(f0.g, r.surf)
                if (r.strat == "neg") rs.add("negative split (awal sengaja lebih lambat)")
                else if (r.strat == "cons" && f0.pos < .15) rs.add("start hati-hati di awal")
                if (abs(gc - 1) >= 0.02) rs.add("kemiringan berbeda (${pct(f0.g)}% vs ${pct(f1.g)}%)")
                if (rs.isNotEmpty()) ln.add("Pace datar berubah dari ${Js.paceStr(f0.pace)} (km ${Js.fmtKm(f0.from)}) ke ${Js.paceStr(f1.pace)} (km ${Js.fmtKm(f1.from)}) pada usaha yang sama: ${rs.joinToString(", ")}.")
            }
        }
        if (r.segs.any { it.ext }) ln.add("Ada ruas dengan kemiringan ≥ 20%: rumus GAP kurang akurat di kemiringan ekstrem, jadi pace ruas itu ditampilkan dengan kisaran kasar (±10–15%), bukan angka pasti.")
        val last = r.segs.last()
        if (last.len >= 0.5) ln.add(when (last.type) {
            "up" -> "Finis menanjak (km ${Js.fmtKm(last.from)}–${Js.fmtKm(last.to)}): simpan tenaga untuk ruas ini."
            "down" -> "Finis menurun: kesempatan untuk menutup lebih cepat bila kaki masih ada."
            else -> "Finis datar: tutup dengan sisa tenaga, bukan dengan pace jam."
        })
        if (r.strat == "neg") ln.add("Negative split: paruh pertama sengaja sedikit lebih lambat dari usaha rata, paruh kedua lebih cepat.")
        return ln
    }

    /** Teks polos untuk dibagikan / disalin. */
    fun plainText(r: Result): List<String> {
        val ln = arrayListOf("STRATEGI MEDAN")
        summary(r).forEach { ln.add("• $it") }
        ln.add("")
        r.segs.forEach { s ->
            val icon = when (s.type) { "up" -> "▲"; "down" -> "▼"; else -> "▬" }
            val sign = if (s.g > 0) "+" else if (s.g < 0) "−" else ""
            ln.add("$icon km ${Js.fmtKm(s.from)}–${Js.fmtKm(s.to)} · $sign${pct(s.g)}% · ${Js.paceStr(s.pace)}/km" +
                (if (s.band == "hike") " (hike)" else if (s.type == "down") " (${segLabel(s)})" else "") +
                (s.pr?.let { " (≈ ${Js.paceStr(it[0])}–${Js.paceStr(it[1])})" } ?: "") + " · ${Js.durStr(s.eta)}")
        }
        return ln
    }
}
