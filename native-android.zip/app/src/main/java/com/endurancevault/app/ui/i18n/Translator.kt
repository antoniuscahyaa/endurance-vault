package com.endurancevault.app.ui.i18n

import android.content.Context
import java.util.concurrent.ConcurrentHashMap

/**
 * Penerjemah Indonesia -> Inggris berbasis kamus (assets/i18n/en.tsv, format: kunci<TAB>terjemahan, escape \n \t \\).
 *
 * Urutan pencarian untuk satu teks:
 *  1. kecocokan persis;
 *  2. kecocokan setelah spasi di tepi dibuang;
 *  3. templat dengan placeholder ({} atau %d/%s/%.1f di kunci; {} atau {1},{2}.. di terjemahan), isi placeholder ikut diterjemahkan;
 *  4. pecah per baris / " · " / kalimat lalu terjemahkan tiap potongan.
 * Teks yang tidak ditemukan dikembalikan apa adanya.
 */
internal object Translator {
    private val PH = Regex("""\{\d*\}|%(?:\.\d+)?[sdf]""")

    private class Template(val regex: Regex, val out: String, val weight: Int)

    @Volatile private var exact: Map<String, String> = emptyMap()
    @Volatile private var templates: List<Template> = emptyList()
    @Volatile private var loaded = false
    private val cache = ConcurrentHashMap<String, String>()

    @Synchronized
    fun load(ctx: Context) {
        if (loaded) return
        val ex = HashMap<String, String>(4096)
        val tp = ArrayList<Template>()
        ctx.assets.open("i18n/en.tsv").bufferedReader(Charsets.UTF_8).useLines { lines ->
            for (line in lines) {
                val tab = line.indexOf('\t')
                if (tab <= 0) continue
                val key = unescape(line.substring(0, tab))
                val value = unescape(line.substring(tab + 1))
                if (PH.containsMatchIn(key)) {
                    val parts = PH.split(key)
                    val pattern = parts.joinToString("(.*?)") { Regex.escape(it) }
                    tp.add(Template(Regex("^$pattern$", RegexOption.DOT_MATCHES_ALL), value, parts.sumOf { it.length }))
                } else ex[key] = value
            }
        }
        tp.sortWith(compareByDescending<Template> { it.weight })
        exact = ex
        templates = tp
        loaded = true
    }

    fun en(s: String): String {
        if (!loaded || s.isEmpty() || !hasLetter(s)) return s
        cache[s]?.let { return it }
        val r = translate(s, 0)
        if (cache.size > 8000) cache.clear()
        cache[s] = r
        return r
    }

    private fun translate(s: String, depth: Int): String {
        exact[s]?.let { return it }
        for (tp in templates) {
            val m = tp.regex.matchEntire(s) ?: continue
            return fill(tp.out, m.groupValues, depth)
        }
        // spasi di tepi (mis. potongan teks yang digabung di kode): coba tanpa spasi lalu pasang lagi
        val t = s.trim()
        if (t.isNotEmpty() && t.length != s.length) {
            val r = translate(t, depth)
            if (r != t) return s.substring(0, s.length - s.trimStart().length) + r + s.substring(s.trimEnd().length)
        }
        if (depth < 2) {
            for (sep in SEPARATORS) {
                if (!s.contains(sep)) continue
                val parts = s.split(sep)
                val tr = parts.map { if (hasLetter(it)) translate(it, depth + 1) else it }
                if (tr != parts) return tr.joinToString(sep)
            }
        }
        return s
    }

    private fun fill(out: String, groups: List<String>, depth: Int): String {
        var next = 1
        return PH.replace(out) { m ->
            val tok = m.value
            val idx = if (tok.length > 2 && tok[0] == '{' && tok[1].isDigit()) tok.substring(1, tok.length - 1).toInt() else next++
            val g = groups.getOrNull(idx) ?: ""
            if (depth < 2 && hasLetter(g)) translate(g, depth + 1) else g
        }
    }

    private fun hasLetter(s: String): Boolean {
        for (c in s) if (c.isLetter()) return true
        return false
    }

    private fun unescape(s: String): String {
        if (s.indexOf('\\') < 0) return s
        val sb = StringBuilder(s.length)
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '\\' && i + 1 < s.length) {
                when (s[i + 1]) {
                    'n' -> { sb.append('\n'); i += 2; continue }
                    't' -> { sb.append('\t'); i += 2; continue }
                    '\\' -> { sb.append('\\'); i += 2; continue }
                }
            }
            sb.append(c); i++
        }
        return sb.toString()
    }

    private val SEPARATORS = listOf("\n", " · ", " | ", ". ", "; ")
}
