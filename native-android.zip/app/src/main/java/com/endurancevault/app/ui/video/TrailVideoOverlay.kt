package com.endurancevault.app.ui.video

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import com.endurancevault.app.data.TerrainScene
import com.endurancevault.app.domain.RouteVideoPrefs
import com.endurancevault.app.domain.RouteVideoTrack
import com.endurancevault.app.domain.TrailVideoPrefs
import kotlin.math.*

/**
 * Native Trail composition renderer. The same drawing path is used by live preview, still export
 * and MP4 frame export so the rendered composition remains consistent.
 */
object TrailVideoOverlay {
    private val paintTL = ThreadLocal.withInitial { Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    } }
    private val p: Paint get() = paintTL.get()!!
    @Volatile private var cachedPhotoPath = ""
    @Volatile private var cachedPhoto: Bitmap? = null

    private data class Projector(
        val cx: Float, val cy: Float, val radius: Float, val tilt: Float,
        val rotation: Float, val heightScale: Float,
    )
    private data class Climb(val midM: Double, val midEle: Double)

    fun draw(
        canvas: Canvas, width: Int, height: Int, scene: TerrainScene, track: RouteVideoTrack,
        prefs: RouteVideoPrefs, progress: Double, summaryAlpha: Double = 0.0,
    ) {
        if (width <= 0 || height <= 0) return
        val v = prefs.trail.sanitized()
        val k = min(width, height) / 720f
        val accent = parseColor(v.accent.ifBlank { if (v.palette == "lime") "#CBFD00" else "#FF6A13" },
            if (v.palette == "lime") 0xFFCBFD00.toInt() else 0xFFFF6A13.toInt())
        drawBackground(canvas, width, height, k, v)
        val landscape = width > height
        val portrait = height.toFloat() / width > 1.5f
        val headerY = if (landscape) 58f * k else if (portrait) 80f * k else 38f * k
        if (v.showHeader) {
            val title = v.title.ifBlank { prefs.titleText.ifBlank { track.title } }
            val headerWidth = if (landscape) width * .46f else width - 80f * k
            val weatherWidth = if (v.showWeather && track.weatherTempC != null) headerWidth * .30f else 0f
            drawTextFit(canvas, title, 40f * k, headerY, headerWidth - weatherWidth - 28f * k, 25f * k, 12f * k, Color.WHITE)
            val sub = listOf(v.location.ifBlank { prefs.subtitle }, v.handle).filter { it.isNotBlank() }.joinToString("  ·  ")
            if (v.showLocation && sub.isNotBlank()) text(canvas, sub, 40f * k, headerY + 27f * k, 14f * k, 0xD9FFFFFF.toInt())
            if (v.showWeather && track.weatherTempC != null) {
                val condition = when (track.weatherCode) {
                    0 -> "Cerah"; 1 -> "Cerah berawan"; 2 -> "Berawan sebagian"; 3 -> "Mendung"
                    45, 48 -> "Berkabut"; 51, 53, 55 -> "Gerimis"; 61, 63, 65 -> "Hujan"
                    71, 73, 75 -> "Salju"; 80, 81, 82 -> "Hujan lokal"; 95, 96, 99 -> "Badai"
                    else -> ""
                }
                val weather = "${track.weatherTempC.roundToInt()}°C" + if (condition.isNotBlank()) " · $condition" else ""
                text(canvas, weather, width - 40f * k, headerY, 16f * k, Color.WHITE, true, Paint.Align.RIGHT)
            }
        }
        if (v.showElevationChart) drawElevation(canvas, width, height, track, progress, k, accent, v)
        drawTerrain(canvas, width, height, scene, track, progress, k, accent, v)
        val stats = track.statsAt(progress.coerceIn(0.0, 1.0), true)
        drawStats(canvas, width, height, track, stats.distM / 1000.0, stats.sec / 60.0,
            stats.pace, stats.hr, stats.gain, stats.cad, progress, summaryAlpha, k, accent, v)
    }

    private fun drawBackground(c: Canvas, w: Int, h: Int, k: Float, v: TrailVideoPrefs) {
        val top = if (v.palette == "lime") 0xFF141E23.toInt() else 0xFF161214.toInt()
        val bottom = if (v.palette == "lime") 0xFF38413A.toInt() else 0xFF3D2A22.toInt()
        when (v.background) {
            "solid" -> c.drawColor(parseColor(v.solidBackground, top))
            "photo" -> {
                val photo = photoFor(v.photoPath)
                if (photo == null) c.drawColor(top) else {
                    val factor = max(w / photo.width.toFloat(), h / photo.height.toFloat())
                    val dw = photo.width * factor; val dh = photo.height * factor
                    p.shader = null
                    c.drawBitmap(photo, null, RectF((w-dw)/2f,(h-dh)/2f,(w+dw)/2f,(h+dh)/2f), p)
                    p.color = Color.argb(v.darkenPhoto * 255 / 100, 0, 0, 0)
                    c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
                }
            }
            else -> {
                p.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), top, bottom, Shader.TileMode.CLAMP)
                c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p); p.shader = null
                if (v.background == "mountain") drawMountains(c, w, h, v.palette)
                else {
                    p.shader = LinearGradient(0f, h * .45f, w * .6f, h.toFloat(),
                        0x44FFFFFF, Color.TRANSPARENT, Shader.TileMode.CLAMP)
                    c.drawRect(0f, h * .4f, w.toFloat(), h.toFloat(), p); p.shader = null
                }
            }
        }
    }

    private fun photoFor(path: String): Bitmap? {
        if (path.isBlank()) return null
        if (cachedPhotoPath == path && cachedPhoto?.isRecycled == false) return cachedPhoto
        synchronized(this) {
            if (cachedPhotoPath == path && cachedPhoto?.isRecycled == false) return cachedPhoto
            runCatching { cachedPhoto?.recycle() }
            cachedPhoto = runCatching { BitmapFactory.decodeFile(path) }.getOrNull()
            cachedPhotoPath = path
            return cachedPhoto
        }
    }

    private fun drawMountains(c: Canvas, w: Int, h: Int, palette: String) {
        val colors = if (palette == "lime")
            intArrayOf(0xFF25352F.toInt(), 0xFF18251D.toInt(), 0xFF101A14.toInt())
        else intArrayOf(0xFF39251F.toInt(), 0xFF251710.toInt(), 0xFF170E0A.toInt())
        for (layer in 0..2) {
            val path = Path()
            val base = h * (.55f + layer * .10f)
            path.moveTo(0f, h.toFloat()); path.lineTo(0f, base)
            for (i in 0..36) {
                val x = w * i / 36f
                val ridge = sin(i * .71 + layer * 1.7) * h * (.035f + layer * .012f) +
                    sin(i * 1.93 + layer) * h * .018f
                val peak = if (i in (8 + layer * 3)..(15 + layer * 3)) -h * (.12f - layer * .025f) else 0f
                path.lineTo(x, base + ridge + peak)
            }
            path.lineTo(w.toFloat(), h.toFloat()); path.close()
            p.shader = null; p.color = colors[layer]; p.style = Paint.Style.FILL; c.drawPath(path, p)
        }
        p.shader = RadialGradient(w * .78f, h * .53f, w * .55f,
            intArrayOf(0x44FF8A36, 0x00FF8A36), null, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p); p.shader = null
    }

    private fun drawTerrain(
        c: Canvas, w: Int, h: Int, scene: TerrainScene, track: RouteVideoTrack,
        progress: Double, k: Float, accent: Int, v: TrailVideoPrefs,
    ) {
        val landscape = w > h
        val portrait = h.toFloat() / w > 1.5f
        val statsY = if (landscape) h - 190f*k else if (portrait) h - 220f*k - (if (v.safeStory) 120f*k else 0f) else h - 170f*k
        val sceneX = if (landscape) w * .5f else 0f
        val sceneY = if (landscape) h * .05f else if (portrait) 355f*k else 122f*k
        val sceneW = if (landscape) w * .5f else w.toFloat()
        val sceneH = if (landscape) h * .9f else (statsY - sceneY - (if (portrait) 18f else 14f)*k).coerceAtLeast(120f*k)
        val tilt = Math.toRadians(v.tilt.toDouble()).toFloat()
        val ct = cos(tilt); val sn = sin(tilt); val rel = v.reliefPercent / 100f; val wallRatio = .045f
        val diameter = min(sceneW * .89f, (sceneH - 6f*k).coerceAtLeast(80f*k) / (ct + rel*sn + wallRatio)) * v.zoomPercent / 100f
        val q = progress.coerceIn(0.0, 1.0).toFloat()
        val motionRot = when (v.motion) { "orbit" -> 360f*q; "swing" -> 36f*(q-.5f); "auto" -> 12f*(q-.5f); else -> 0f }
        val motionScale = when (v.motion) { "reveal" -> .82f+.18f*q; "dive" -> 1.22f-.22f*q; else -> 1f }
        val radius = diameter * .5f * motionScale
        val cx = sceneX + sceneW*.5f + v.centerX/100f*radius
        val cy = sceneY + sceneH - 4f*k - diameter*(ct*.5f+wallRatio) + v.centerY/100f*radius + v.baseY*k
        val routeRadius = max(1f, (scene.routeX.indices.maxOfOrNull { i -> hypot(scene.routeX[i], scene.routeZ[i]) } ?: 1f) * v.terrainScale)
        val range = max(1f, scene.maxH-scene.minH)
        val projector = Projector(cx, cy, radius, tilt, Math.toRadians((v.rotation+motionRot).toDouble()).toFloat(), diameter*rel/range)
        fun project(x: Float, z: Float, elev: Float): Pair<Float,Float> {
            val xx=x/routeRadius; val zz=z/routeRadius
            val rx=xx*cos(projector.rotation)-zz*sin(projector.rotation)
            val rz=xx*sin(projector.rotation)+zz*cos(projector.rotation)
            return (projector.cx+rx*projector.radius) to (projector.cy+rz*projector.radius*cos(projector.tilt)-elev*projector.heightScale)
        }

        val shape = Path()
        val sides = when(v.shape) { "square" -> 4; "hex" -> 6; "oct" -> 8; else -> 0 }
        val points = if (sides == 0) 96 else sides
        for (i in 0..points) {
            val a=2*PI*i/points
            val rr=if(sides==0)1.0 else 1.0/cos(PI/sides)
            val pt=project((cos(a)*rr*routeRadius).toFloat(),(sin(a)*rr*routeRadius).toFloat(),0f)
            if(i==0)shape.moveTo(pt.first,pt.second) else shape.lineTo(pt.first,pt.second)
        }
        shape.close()
        p.shader=null;p.color=0x99000000.toInt();p.style=Paint.Style.FILL
        c.drawOval(RectF(cx-radius*1.05f,cy-radius*.12f,cx+radius*1.05f,cy+radius*.82f),p)
        val wall=Path(shape);wall.offset(0f,diameter*wallRatio)
        p.color=if(v.palette=="lime")0xFF15241B.toInt() else 0xFF32190E.toInt();c.drawPath(wall,p)
        p.color=0x99FFFFFF.toInt();p.style=Paint.Style.STROKE;p.strokeWidth=1.2f*k;c.drawPath(wall,p);p.style=Paint.Style.FILL

        c.save();c.clipPath(shape)
        val n=scene.n;val minH=scene.minH;val elevRange=max(1f,scene.maxH-minH)
        val step=max(1,n/48)
        for(j in 0 until n-step step step) for(i in 0 until n-step step step) {
            val idx=i+j*n
            val h00=scene.heights[idx];val h10=scene.heights[idx+step]
            val h01=scene.heights[idx+step*n];val h11=scene.heights[idx+step*n+step]
            val x0=(i.toFloat()/(n-1)-.5f)*scene.sizeM
            val z0=(j.toFloat()/(n-1)-.5f)*scene.sizeM
            val dx=scene.sizeM*step/(n-1)
            val a=project(x0,z0,h00-minH);val b=project(x0+dx,z0,h10-minH)
            val d=project(x0,z0+dx,h01-minH);val e=project(x0+dx,z0+dx,h11-minH)
            val avg=((h00+h10+h01+h11)*.25f-minH)/elevRange
            val base=if(v.palette=="lime")intArrayOf(0xFF183A2A.toInt(),0xFF38613A.toInt(),0xFFB2D65A.toInt())
                else intArrayOf(0xFF3D2114.toInt(),0xFF92502A.toInt(),0xFFFFA34C.toInt())
            var col=if(avg<.5f)blend(base[0],base[1],avg*2)else blend(base[1],base[2],(avg-.5f)*2)
            if(v.hillshade){
                val gx=(h10-h00)/max(.01f,dx);val gz=(h01-h00)/max(.01f,dx)
                val shade=(.76f+.24f*((-gx*.35f-gz*.55f)/max(1f,hypot(gx,gz))).coerceIn(-1f,1f)).coerceIn(.55f,1f)
                col=shadeColor(col,shade)
            }
            p.color=col;p.style=Paint.Style.FILL
            c.drawPath(Path().apply{moveTo(a.first,a.second);lineTo(b.first,b.second);lineTo(e.first,e.second);close()},p)
            c.drawPath(Path().apply{moveTo(a.first,a.second);lineTo(e.first,e.second);lineTo(d.first,d.second);close()},p)
        }
        if(v.contour){
            p.color=if(v.palette=="lime")0x887FD69A.toInt() else 0x88FFD0A0.toInt()
            p.style=Paint.Style.STROKE;p.strokeWidth=.7f*k
            for(band in 1..8){
                val threshold=minH+elevRange*band/9f
                for(j in 0 until n step step){
                    val path=Path();var active=false
                    for(i in 0 until n step step){
                        val idx=i+j*n
                        if(scene.heights[idx]>=threshold){
                            val x=(i.toFloat()/(n-1)-.5f)*scene.sizeM
                            val z=(j.toFloat()/(n-1)-.5f)*scene.sizeM
                            val pt=project(x,z,threshold-minH)
                            if(!active){path.moveTo(pt.first,pt.second);active=true}else path.lineTo(pt.first,pt.second)
                        }else active=false
                    }
                    c.drawPath(path,p)
                }
            }
        }

        val count=scene.routeX.size
        if(count>1){
            val upto=scene.routeFrac.indexOfLast { it <= progress.toFloat() }.coerceIn(1,count-1)
            val route=Path()
            fun routePoint(i:Int):Pair<Float,Float>{
                val ix=((scene.routeX[i]/scene.sizeM+.5f)*(scene.n-1)).roundToInt().coerceIn(0,scene.n-1)
                val iz=((scene.routeZ[i]/scene.sizeM+.5f)*(scene.n-1)).roundToInt().coerceIn(0,scene.n-1)
                return project(scene.routeX[i],scene.routeZ[i],scene.heights[iz*scene.n+ix]-minH+1.5f)
            }
            for(i in 0..upto){val pt=routePoint(i);if(i==0)route.moveTo(pt.first,pt.second)else route.lineTo(pt.first,pt.second)}
            p.color=(accent and 0x00FFFFFF) or 0x66000000;p.style=Paint.Style.STROKE;p.strokeWidth=18f*k;c.drawPath(route,p)
            p.color=0xAA000000.toInt();p.strokeWidth=10f*k;c.drawPath(route,p)
            p.color=accent;p.strokeWidth=5.5f*k;c.drawPath(route,p)
            p.style=Paint.Style.FILL
            val start=routePoint(0);p.color=0xFFB8F34A.toInt();c.drawCircle(start.first,start.second,7f*k,p)
            if(progress>=.995){val end=routePoint(count-1);p.color=0xFFFF6655.toInt();c.drawCircle(end.first,end.second,8f*k,p)}
            val current=routePoint(upto);p.color=Color.WHITE;c.drawCircle(current.first,current.second,7f*k,p)
            p.color=accent;p.style=Paint.Style.STROKE;p.strokeWidth=3f*k;c.drawCircle(current.first,current.second,10f*k,p);p.style=Paint.Style.FILL
            val sample=(progress.coerceIn(0.0,1.0)*(track.n-1)).roundToInt().coerceIn(0,track.n-1)
            val grade=track.gradeS[sample]
            if(v.showGradePill&&grade.isFinite()){
                val label="${if(grade>0)"+" else ""}${grade.roundToInt()}%"
                round(c,current.first+14*k,current.second-34*k,current.first+78*k,current.second-8*k,10*k,0xCC20150A.toInt())
                text(c,label,current.first+46*k,current.second-16*k,13*k,Color.WHITE,true,Paint.Align.CENTER)
            }
            if(v.showKmMarkers&&track.totalM>0){
                val stepKm=max(1,kotlin.math.ceil(track.totalM/10000.0).toInt())
                for(km in stepKm..(track.totalM/1000.0).toInt() step stepKm){
                    val f=km*1000.0/track.totalM
                    val found=scene.routeFrac.indexOfFirst { it >= f.toFloat() }
                    val idx=(if(found>=0)found else count-1).coerceIn(0,count-1)
                    val pt=routePoint(idx);p.color=0xDDFFFFFF.toInt();c.drawCircle(pt.first,pt.second,4f*k,p)
                }
            }
        }
        c.restore()
        p.color=0x99FFFFFF.toInt();p.style=Paint.Style.STROKE;p.strokeWidth=1.2f*k;c.drawPath(shape,p);p.style=Paint.Style.FILL
    }

    private fun drawElevation(c:Canvas,w:Int,h:Int,t:RouteVideoTrack,progress:Double,k:Float,accent:Int,v:TrailVideoPrefs){
        val landscape=w>h;val portrait=h.toFloat()/w>1.5f
        val x=40f*k;val y=if(landscape)96f*k else if(portrait)300f*k else 52f*k
        val ww=if(landscape)w*.46f else w-80f*k;val hh=if(landscape)200f*k else if(portrait)190f*k else 150f*k
        val values=t.eleS.filter{it.isFinite()};if(values.size<3)return
        val lo=values.minOrNull()?:0.0;val hi=max(lo+1.0,values.maxOrNull()?:1.0)
        val avg=values.average()
        round(c,x-8*k,y-8*k,x+ww+8*k,y+hh+10*k,14*k,0x5520100A)
        text(c,"MIN ${lo.roundToInt()} m",x,y-12*k,9*k,0xCCFFFFFF.toInt())
        text(c,"AVG ${avg.roundToInt()} m",x+ww*.5f,y-12*k,9*k,0xCCFFFFFF.toInt(),false,Paint.Align.CENTER)
        text(c,"MAX ${hi.roundToInt()} m",x+ww,y-12*k,9*k,0xCCFFFFFF.toInt(),false,Paint.Align.RIGHT)
        val path=Path();val fill=Path()
        values.forEachIndexed{i,e->val xx=x+i.toFloat()/(values.size-1)*ww;val yy=y+hh-(e-lo)/(hi-lo)*hh
            if(i==0){path.moveTo(xx,yy);fill.moveTo(xx,y+hh);fill.lineTo(xx,yy)}else{path.lineTo(xx,yy);fill.lineTo(xx,yy)}}
        val cx=x+ww*progress.toFloat().coerceIn(0f,1f);fill.lineTo(cx,y+hh);fill.close()
        p.color=0x22FFFFFF;p.style=Paint.Style.FILL;c.drawPath(fill,p)
        p.color=accent;p.style=Paint.Style.STROKE;p.strokeWidth=2.4f*k;c.drawPath(path,p)
        if(v.showKmMarkers&&t.totalM>0){
            p.color=0x99FFFFFF.toInt();p.strokeWidth=1f*k
            val stepKm=max(1,kotlin.math.ceil(t.totalM/10000.0).toInt())
            for(km in stepKm..(t.totalM/1000.0).toInt() step stepKm){
                val xx=x+ww*(km*1000.0/t.totalM).toFloat();c.drawLine(xx,y+hh-3*k,xx,y+hh+4*k,p)
                text(c,km.toString(),xx,y+hh+15*k,8*k,0xCCFFFFFF.toInt(),false,Paint.Align.CENTER)
            }
        }
        if(v.showPeak){
            val pi=values.indices.maxByOrNull{values[it]}?:0;val px=x+pi.toFloat()/(values.size-1)*ww;val py=y+hh-(values[pi]-lo)/(hi-lo)*hh
            p.color=0xFFFFD166.toInt();p.style=Paint.Style.STROKE;p.strokeWidth=1.5f*k;c.drawLine(px,py-12*k,px,py+hh*.02f,p);p.style=Paint.Style.FILL
            text(c,"PUNCAK",px+4*k,py-5*k,9*k,0xFFFFD166.toInt(),true)
        }
        if(v.showClimbLabels){
            detectClimbs(t).take(4).forEachIndexed{index,cl->
                val f=(cl.midM/t.totalM).coerceIn(0.0,1.0).toFloat();val xx=x+ww*f;val yy=y+hh-((cl.midEle-lo)/(hi-lo)).toFloat()*hh
                round(c,xx-25*k,yy-20*k,xx+25*k,yy-7*k,6*k,0xAA20150A.toInt())
                text(c,"CLIMB ${index+1}",xx,yy-10*k,7*k,Color.WHITE,true,Paint.Align.CENTER)
            }
        }
        val ix=(progress*(values.size-1)).roundToInt().coerceIn(0,values.size-1)
        p.color=Color.WHITE;c.drawCircle(cx,y+hh-(values[ix]-lo)/(hi-lo)*hh,4*k,p)
    }

    private fun detectClimbs(t:RouteVideoTrack):List<Climb>{
        val out=ArrayList<Climb>();var start=-1;var last=-1
        fun finish(){if(start<0||last<=start)return
            val len=t.dist[last]-t.dist[start];val gain=t.eleS[last]-t.eleS[start]
            val grade=if(len>0)gain/len*100.0 else 0.0
            if(len>=400&&gain>=40&&grade>=4)out.add(Climb((t.dist[start]+t.dist[last])/2,(t.eleS[start]+t.eleS[last])/2))}
        for(i in 0 until t.n){val up=t.gradeS[i].isFinite()&&t.gradeS[i]>=3.0
            if(up){if(start<0)start=i;last=i}else if(start>=0&&last>=0&&t.dist[i]-t.dist[last]>150){finish();start=-1;last=-1}}
        finish();return out
    }

    private fun drawStats(c:Canvas,w:Int,h:Int,t:RouteVideoTrack,km:Double,minutes:Double,pace:Double?,hr:Int?,gain:Double,cad:Int?,progress:Double,summaryAlpha:Double,k:Float,accent:Int,v:TrailVideoPrefs){
        val compact=v.statLayout=="compact";val tiles=v.statLayout=="tiles";val center=v.statLayout=="center"
        val landscape=w>h;val portrait=h.toFloat()/w>1.5f
        val left=if(landscape)40f*k else 24f*k;val right=if(landscape)left+w*.46f else w-left
        val panelH=(when(v.statLayout){"center"->182f*k;"tiles"->206f*k;"compact"->124f*k;else->170f*k})-(if(v.progressBar)0f else 30f*k)
        val y=if(landscape)h-190f*k else if(portrait)h-220f*k-(if(v.safeStory)120f*k else 0f)else h-170f*k
        val total=t.totalM/1000.0;val fade=summaryAlpha.coerceIn(0.0,1.0)
        val avgPace=if(total>0&&t.totalSec>0)t.totalSec/60.0/total else null
        val livePace=pace?.takeIf{it>0}?:avgPace
        val shownPace=if(livePace!=null&&avgPace!=null)livePace+(avgPace-livePace)*fade else livePace
        val avgHr=t.hr.filter{it>=30}.takeIf{it.isNotEmpty()}?.average()
        val shownHr=if(hr!=null&&avgHr!=null)(hr+(avgHr-hr)*fade).roundToInt()else hr?:avgHr?.roundToInt()
        val totalGain=t.gainCum.lastOrNull()?:gain;val shownGain=gain+(totalGain-gain)*fade
        val shownDist=km+(total-km)*fade;val shownMin=minutes+(t.totalSec/60.0-minutes)*fade
        val paceText=shownPace?.takeIf{it>0}?.let{String.format(java.util.Locale.US,"%d:%02d",it.toInt(),(it*60).roundToInt()%60)}?:"--:--"
        val timeText=String.format(java.util.Locale.US,"%02d:%02d",shownMin.toInt(),(shownMin*60).roundToInt()%60)
        val title=if(fade>=.5)"SELESAI" else "${"%.2f".format(shownDist)} / ${"%.1f".format(total)} KM"
        val maxGrade=t.gradeS.filter{it.isFinite()}.maxOrNull()?.takeIf{it>=3}
        val head=if(v.showClimbLabels&&maxGrade!=null&&fade<.5)"TANJAKAN ${maxGrade.roundToInt()}%"else title
        val entrance=if(v.panelEntrance)(progress.coerceIn(0.0,1.0)/.04).coerceIn(0.0,1.0).let{it*it*(3-2*it)}.toFloat()else 1f
        c.save();c.translate(0f,(1f-entrance)*40f*k)
        if(v.cardStyle!="none"){
            val cc=when(v.cardStyle){"solid"->0xEE20150F.toInt();"auto"->0xAA20150F.toInt();else->0x66302018}
            round(c,left-10*k,y-12*k,right+10*k,y+panelH+10*k,18*k,cc)
        }
        text(c,head,if(center)(left+right)/2 else left,y+(if(center)24f else 35f)*k,if(center)13f*k else 24f*k,if(head.startsWith("TANJAKAN"))accent else Color.WHITE,true,if(center)Paint.Align.CENTER else Paint.Align.LEFT)
        if(v.progressBar&&fade<.5){round(c,left,y+50*k,right,y+56*k,3*k,0x66FFFFFF);round(c,left,y+50*k,left+(right-left)*(shownDist/total).toFloat(),y+56*k,3*k,accent)}
        val metricKeys=if(v.metricMode=="auto")listOf("pace","hr","gain","time")else v.metrics
        val labels=metricKeys.mapNotNull{key->when(key){
            "pace"->"PACE" to paceText
            "hr"->"HR" to (shownHr?.toString()?:"--")
            "gain"->"NAIK" to "${shownGain.roundToInt()} m"
            "time"->"WAKTU" to timeText
            "cad"->"CADENCE" to (cad?.toString()?:"--")
            "gap"->"GAP" to (t.gapPace?.takeIf{it>0}?.let{String.format(java.util.Locale.US,"%d:%02d",it.toInt(),(it*60).roundToInt()%60)}?:"--:--")
            "vam"->"VAM" to (t.vamAvg?.takeIf{it>0}?.roundToInt()?.toString()?:"--")
            else->null}}
        val cols=if(tiles)2 else max(1,labels.size)
        labels.forEachIndexed{i,item->val col=i%cols;val row=i/cols;val xx=left+(right-left)*(col+.5f)/cols
            val yy=y+(if(center)82f else if(tiles)100f else if(compact)82f else 104f)*k+row*46f*k
            text(c,item.second,xx,yy,if(compact)18f*k else 22f*k,if(i==0)accent else Color.WHITE,true,Paint.Align.CENTER)
            text(c,item.first,xx,yy+17f*k,10f*k,0xCCFFFFFF.toInt(),false,Paint.Align.CENTER)}
        if(v.extraMetrics){val extra="TOTAL NAIK ${totalGain.roundToInt()} m   ·   MAX HR ${t.hr.maxOrNull()?.takeIf{it>0}?:"--"}"
            text(c,extra,(left+right)/2,y+panelH-8*k,9*k,0xCCFFFFFF.toInt(),false,Paint.Align.CENTER)}
        c.restore()
    }

    private fun blend(a:Int,b:Int,t:Float):Int{val q=t.coerceIn(0f,1f);return Color.rgb((Color.red(a)+(Color.red(b)-Color.red(a))*q).roundToInt(),(Color.green(a)+(Color.green(b)-Color.green(a))*q).roundToInt(),(Color.blue(a)+(Color.blue(b)-Color.blue(a))*q).roundToInt())}
    private fun shadeColor(color:Int,f:Float)=Color.rgb((Color.red(color)*f).roundToInt().coerceIn(0,255),(Color.green(color)*f).roundToInt().coerceIn(0,255),(Color.blue(color)*f).roundToInt().coerceIn(0,255))
    private fun parseColor(hex:String,fallback:Int)=runCatching{Color.parseColor(hex)}.getOrDefault(fallback)
    private fun text(c:Canvas,s:String,x:Float,y:Float,size:Float,col:Int,bold:Boolean=false,align:Paint.Align=Paint.Align.LEFT){
        p.shader=null;p.style=Paint.Style.FILL;p.color=col;p.textSize=size;p.textAlign=align;p.clearShadowLayer()
        p.typeface=android.graphics.Typeface.create("sans-serif",if(bold)android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL);c.drawText(s,x,y,p)
    }
    private fun drawTextFit(c:Canvas,s:String,x:Float,y:Float,maxWidth:Float,size:Float,minSize:Float,col:Int){
        p.shader=null;p.style=Paint.Style.FILL;p.color=col;p.textAlign=Paint.Align.LEFT;p.typeface=android.graphics.Typeface.create("sans-serif",android.graphics.Typeface.BOLD)
        var fs=size;p.textSize=fs;while(p.measureText(s)>maxWidth&&fs>minSize){fs-=1f;p.textSize=fs};c.drawText(s,x,y,p)
    }
    private fun round(c:Canvas,l:Float,t:Float,r:Float,b:Float,rad:Float,col:Int){p.shader=null;p.color=col;p.style=Paint.Style.FILL;c.drawRoundRect(l,t,r,b,rad,rad,p)}
}
