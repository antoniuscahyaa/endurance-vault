package com.endurancevault.app.domain

/**
 * Mengubah sesi quality dari jadwal (teks detail PDay) menjadi bentuk structured workout yang bisa dikirim ke jam:
 * pemanasan -> N x (lari + recovery) -> pendinginan. Murni, tanpa Android, supaya bisa dites.
 *
 * Teks detail dibuat oleh QualityText.kt / QualityTwo.kt dengan pola tetap ("Threshold 3×10 mnt (HR ...), jog 2 mnt antar set",
 * "Tempo 30 mnt tanpa henti", "5×3 mnt di usaha 3K–5K", "6×800 m ...", "Fartlek 8×1 mnt kencang, 1 mnt easy"). Sesi tanpa struktur
 * interval (strides, tanjakan pendek dalam detik) mengembalikan null, sehingga tombol kirim tidak muncul untuknya.
 */
object QualityWorkout {
    /** Lama pemanasan/pendinginan bila teks hanya menulis "Pemanasan dan pendinginan easy" tanpa menit. */
    const val DEFAULT_WARMUP_MIN = 10
    const val DEFAULT_COOLDOWN_MIN = 10
    const val DEFAULT_RECOVERY_MIN = 2

    /** [assumed] berisi catatan asumsi (menit tidak ada di teks rencana) untuk ditampilkan di dialog konfirmasi. */
    class Spec(
        val warmupMin: Int, val repeats: Int, val runMin: Int, val recoveryMin: Int, val cooldownMin: Int,
        /** Rentang HR langkah lari dalam bpm (dari rencana) atau null bila langkah lari tanpa target. */
        val runBand: List<Int>?,
        val assumed: List<String>,
    ) {
        /** Total menit seperti yang dibangun StructuredWorkout.buildPayload (recovery ikut setelah tiap repetisi). */
        val totalMin: Int get() = warmupMin + repeats * (runMin + recoveryMin) + cooldownMin
    }

    private fun num(x: String) = x.replace(',', '.').toDouble()

    /** Spec untuk hari quality [d], atau null bila bukan sesi quality berstruktur. */
    fun fromDay(d: PDay): Spec? {
        if (d.kind != Kinds.QUALITY || d.bench) return null
        return parse(d.detail, d.qMin, d.qBand, d.qk)
    }

    fun parse(detail: String, qMin: Double?, qBand: List<Int>?, qk: String?): Spec? {
        val t = detail
        val assumed = mutableListOf<String>()

        var repeats: Int
        var runMin: Int
        var rounded = false
        val m = Regex("(\\d+)×([\\d.,]+) (mnt|m|km)\\b").find(t)
        if (m != null) {
            repeats = m.groupValues[1].toInt()
            val v = num(m.groupValues[2])
            val paceMin = Regex("Pace sekitar (\\d+):(\\d{2})/km").find(t)?.let { it.groupValues[1].toDouble() + it.groupValues[2].toDouble() / 60 }
            val minutes = when (m.groupValues[3]) {
                "mnt" -> v
                "km" -> if (paceMin != null) v * paceMin else (qMin ?: return null) / repeats
                else -> if (paceMin != null) v / 1000 * paceMin else (qMin ?: return null) / repeats
            }
            runMin = Math.round(minutes).toInt().coerceAtLeast(1)
            if (m.groupValues[3] != "mnt" || minutes != runMin.toDouble()) rounded = true
            if (rounded) assumed += "Repetisi jarak dikonversi ke waktu (≈$runMin mnt per repetisi); jam menghitung langkah berdasarkan waktu."
        } else {
            val tp = Regex("Tempo (\\d+) mnt").find(t)
            val hk = Regex("Mendaki panjang (\\d+)(?:–(\\d+))? mnt").find(t)
            val ht = Regex("Tanjakan tempo (\\d+)×(\\d+) mnt").find(t)
            when {
                tp != null -> { repeats = 1; runMin = tp.groupValues[1].toInt() }
                hk != null -> { repeats = 1; runMin = (hk.groupValues[2].ifEmpty { hk.groupValues[1] }).toInt() }
                ht != null -> { repeats = ht.groupValues[1].toInt(); runMin = ht.groupValues[2].toInt() }
                else -> return null
            }
        }
        if (repeats !in 1..20 || runMin !in 1..180) return null

        // recovery antar repetisi: "jog 2 mnt", "jog 2–3 mnt" (ambil yang pertama), atau fartlek "kencang, 1 mnt easy"
        val jog = Regex("[Jj]og (\\d+)(?:–\\d+)? mnt").find(t)?.groupValues?.get(1)?.toInt()
            ?: Regex("kencang, (\\d+) mnt easy").find(t)?.groupValues?.get(1)?.toInt()
        val recovery = when {
            repeats == 1 -> 0
            jog != null -> jog
            else -> { assumed += "Recovery tidak ditulis di rencana; dipakai $DEFAULT_RECOVERY_MIN mnt jog."; DEFAULT_RECOVERY_MIN }
        }

        val wuTxt = Regex("[Pp]emanasan(?: easy)? (\\d+) mnt").find(t)?.groupValues?.get(1)?.toInt()
        val cdTxt = Regex("pendinginan(?: easy)? (\\d+) mnt").find(t)?.groupValues?.get(1)?.toInt()
        if (wuTxt == null || cdTxt == null) assumed += "Pemanasan/pendinginan tidak ditulis menitnya di rencana; dipakai $DEFAULT_WARMUP_MIN mnt masing-masing."
        val wu = wuTxt ?: DEFAULT_WARMUP_MIN
        val cd = cdTxt ?: DEFAULT_COOLDOWN_MIN

        // Interval pendek (VO2max/fartlek) tidak diberi target HR: HR baru naik di repetisi ke-2, alarm jam akan terus bunyi.
        val band = if (qk == "vo2" || qBand == null || qBand.size < 2) null else qBand
        return Spec(wu, repeats, runMin, recovery, cd, band, assumed)
    }

    /** bpm -> % HR maks (20..100) untuk target jam. */
    private fun pct(bpm: Int, maxHr: Int) = Math.round(bpm * 100.0 / maxHr).toInt().coerceIn(20, 100)

    /**
     * Target tiap langkah: lari = rentang HR sesi (bila ada), pemanasan dan pendinginan = dari 50% HR maks sampai batas easy,
     * recovery tanpa target (HR tertinggal dari usaha).
     */
    fun targets(spec: Spec, easyHr: Int, maxHr: Int): WorkoutTargets {
        if (maxHr <= 0) return WorkoutTargets()
        val easy = if (easyHr > 0) {
            val hi = pct(easyHr, maxHr); val lo = minOf(pct((maxHr * 0.5).toInt(), maxHr), hi)
            StepTarget(StepIntensity.HR_PERCENT, lo, hi)
        } else StepTarget()
        val run = spec.runBand?.let {
            val lo = pct(minOf(it[0], it[1]), maxHr); val hi = pct(minOf(maxOf(it[0], it[1]), maxHr), maxHr)
            StepTarget(StepIntensity.HR_PERCENT, minOf(lo, hi), maxOf(lo, hi))
        } ?: StepTarget()
        return WorkoutTargets(warmup = easy, run = run, recovery = StepTarget(), cooldown = easy)
    }

    /** Nama di jam (batas 64 byte di protokol): tanggal pendek + judul sesi, dipotong aman. */
    fun watchName(dateLabel: String, title: String): String {
        val raw = "EV $dateLabel $title".trim()
        return if (raw.length <= 36) raw else raw.take(35).trimEnd() + "…"
    }
}
