package com.endurancevault.app.domain

/** Membandingkan baris log protokol "HR zones: sent via …" dengan zona LTHR di app. Murni, tanpa Android. */
object ZoneLogCheck {
    private val LTHR = Regex("""LTHR (\d+)/(\d+)/(\d+)/(\d+)/(\d+) of (\d+) \(current method (\w+)\)""")

    /**
     * @param lines baris log protokol, urut dari lama ke baru
     * @param appLthr LTHR yang dipakai app; [appLower] batas bawah Z1..Z5 persis seperti yang dikirim (watchLowerBounds)
     * @param manual true bila LTHR diisi manual (hanya itu yang dikirim sebagai metode LTHR)
     */
    fun report(lines: List<String>, appLthr: Int, appLower: List<Int>, manual: Boolean): String {
        val sent = lines.lastOrNull { it.contains("HR zones: sent via") && LTHR.containsMatchIn(it) }
        if (sent == null) {
            val fitness = lines.lastOrNull { it.contains("HR zones: sent 07/") }
            return if (fitness != null) {
                "Jam ini memakai jalur FitnessData, bukan track, jadi tidak ada slot LTHR dan label LTHR tidak bisa dikirim. Log terakhir: $fitness"
            } else {
                "Belum ada log pengiriman zona jalur track. Kirim zona dulu (tekan lama tombol LTHR), lalu tekan Cek lagi."
            }
        }
        val g = LTHR.find(sent)!!.groupValues
        val bounds = (1..5).map { g[it].toInt() }
        val thr = g[6].toInt()
        val method = g[7]
        val head = "Terkirim ke jam: LTHR $thr bpm, batas Z1–Z5 ${bounds.joinToString("/")}, metode $method.\n" +
            "Di app: LTHR $appLthr bpm, batas Z1–Z5 ${appLower.joinToString("/")}."
        val verdict = when {
            method != "LTHR" -> "Metode yang dikirim bukan LTHR (" +
                (if (!manual) "LTHR belum diisi manual" else "mode zona bukan LTHR, atau zona belum dikirim ulang") +
                "); angka LTHR di atas hanya bawaan umur, bukan LTHR Anda."
            thr == appLthr && bounds == appLower -> "✓ Sama dengan app."
            else -> "✗ Berbeda dari app. Kirim ulang zona lalu cek lagi."
        }
        return "$head\n$verdict\n(Ini isi paket yang dikirim; belum membuktikan jam menerimanya.)"
    }
}
