package com.endurancevault.app.domain

import java.time.LocalDate
import java.time.YearMonth
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Port logika tab "Rekap" dari rencana lari (web):
 * 03-perencana-gear-statistik.js (Progres), 20-zona-log-bulanan-pr-cadangan.js (grafik mingguan, log bulanan),
 * 24b-kepatuhan-rencana.js, 04-kondisi-pagi-ulasan-bandingkan.js (ulasan mingguan, streak, pencapaian),
 * 22-statistik-data.js (heatmap tahunan, kalender konsistensi), 05-lomba-tema-prediksi.js (prediksi).
 * Murni Kotlin tanpa Android agar bisa diuji di JVM. Tidak mengubah rumus beban/readiness yang sudah ada.
 */

/** Satu aktivitas, dipetakan dari ActivityEntity oleh lapisan UI. `loss` dari detail aktivitas bila ada. */
data class RecapRun(
    val id: Long, val date: LocalDate, val km: Double, val min: Double, val hr: Int?,
    val gain: Double, val loss: Double?, val bike: Boolean, val name: String = "",
)
data class RecapPlanDay(val date: LocalDate, val kind: String, val km: Double)
data class RecapPlanWeek(val index: Int, val start: LocalDate, val km: Double, val days: List<RecapPlanDay>)
/** PR sebagai patokan: label ("1 km","5K","10K","Half marathon"), durasi menit, tanggal. */
data class RecapPr(val label: String, val distanceKm: Double, val minutes: Double, val date: LocalDate)

data class WeekBucket(
    val start: LocalDate, val km: Double, val min: Double, val gain: Double, val loss: Double,
    val vamGain: Double, val vamMin: Double, val n: Int, val ids: List<Long>,
) {
    val end: LocalDate get() = start.plusDays(6)
    val vam: Int get() = RecapAnalytics.vam(vamGain, vamMin)
}
enum class WeeklyMetric { KM, MIN, GAIN, LOSS, VAM }
data class Spike(val i: Int, val from: Int, val pct: Int, val high: Boolean)

data class WeekStat(val n: Int, val km: Double, val min: Double, val pace: Double?, val hr: Double?)
data class ProgressRow(val week: RecapPlanWeek, val st: WeekStat)

data class AdhRow(val i: Int, val due: Int, val done: Int) {
    val miss: Int get() = due - done
    val pct: Int? get() = if (due > 0) floor(done * 100.0 / due + 0.5).toInt() else null
}
data class AdhScan(val pct: Int?, val cur: AdhRow?, val trend: List<AdhRow>, val avg: Int?, val prevAvg: Int?, val dir: String?)
data class AdhOffer(val cur: Boolean, val miss: Int, val pct: Int)

data class WeekReview(
    val mon: LocalDate, val end: LocalDate, val n: Int, val km: Double, val min: Double, val gain: Double,
    val longKm: Double, val load: Double, val hr: Double?, val planKm: Double?, val planN: Int?, val cons: Int?,
    val prs: List<Pair<String, Double>>, val recLong: Boolean, val recWeek: Boolean, val prevKm: Double,
)
data class Achievement(val on: Boolean, val text: String)

data class DayAgg(val km: Double, val min: Double, val gain: Double, val n: Int)
data class MonthAgg(val km: Double, val min: Double, val gain: Double, val days: Int)
data class GridCell(val date: LocalDate, val week: Int, val row: Int, val inYear: Boolean)

object RecapAnalytics {
    const val SPK_PCT = 10
    const val SPK_HI = 20
    const val ADH_LOW = 60
    const val ADH_LOW2 = 70

    private fun jsRound(x: Double): Int = floor(x + 0.5).toInt()
    fun monday(d: LocalDate): LocalDate = d.minusDays((d.dayOfWeek.value - 1).toLong())

    /** VAM (m/jam): hanya bila tanjakan >= 100 m dan waktu >= 10 menit. */
    fun vam(gain: Double, min: Double): Int = if (gain >= 100 && min >= 10) jsRound(gain / (min / 60.0)) else 0

    // ---------- Grafik mingguan ----------
    fun weeklyBuckets(runs: List<RecapRun>, today: LocalDate, weeks: Int = 16): List<WeekBucket> {
        val cur = monday(today)
        val starts = (weeks - 1 downTo 0).map { cur.minusWeeks(it.toLong()) }
        val idx = starts.withIndex().associate { it.value to it.index }
        val km = DoubleArray(weeks); val mn = DoubleArray(weeks); val gn = DoubleArray(weeks); val ls = DoubleArray(weeks)
        val n = IntArray(weeks); val ids = List(weeks) { mutableListOf<Long>() }
        runs.filter { !it.bike }.forEach { r ->
            val i = idx[monday(r.date)] ?: return@forEach
            km[i] += r.km; mn[i] += r.min; gn[i] += r.gain
            if ((r.loss ?: 0.0) > 0) ls[i] += r.loss!!
            n[i]++; ids[i].add(r.id)
        }
        return starts.mapIndexed { i, s -> WeekBucket(s, km[i], mn[i], gn[i], ls[i], gn[i], mn[i], n[i], ids[i]) }
    }

    fun WeekBucket.value(m: WeeklyMetric): Double = when (m) {
        WeeklyMetric.KM -> km; WeeklyMetric.MIN -> min / 60.0; WeeklyMetric.GAIN -> gain
        WeeklyMetric.LOSS -> loss; WeeklyMetric.VAM -> vam.toDouble()
    }

    fun niceMax(v: Double): Double {
        if (!(v > 0)) return 1.0
        val p = 10.0.pow(floor(kotlin.math.log10(v))); val f = v / p
        return (if (f <= 1) 1.0 else if (f <= 2) 2.0 else if (f <= 5) 5.0 else 10.0) * p
    }

    /** Lonjakan > 10% dari minggu pembanding (melewati minggu pemulihan), seperti spikeScan web. */
    fun spikeScan(vals: List<Double>, cuts: List<Boolean>, min: Double): List<Spike> {
        val out = mutableListOf<Spike>()
        for (i in 1 until vals.size) {
            if (cuts[i]) continue
            var j = i - 1
            while (j > 0 && cuts[j]) j--
            val base = vals[j]; val v = vals[i]
            if (cuts[j] || !(base > 0) || !(v > base)) continue
            val r = jsRound((v / base - 1) * 100)
            if (r > SPK_PCT && v - base >= min) out.add(Spike(i, j, r, r >= SPK_HI))
        }
        return out
    }

    // ---------- Progres ----------
    fun weekStats(w: RecapPlanWeek, runs: List<RecapRun>): WeekStat {
        val wr = runs.filter { !it.bike && it.km > 0 && !it.date.isBefore(w.start) && !it.date.isAfter(w.start.plusDays(6)) }
        val easyDates = w.days.filter { it.kind == Kinds.EASY || it.kind == "short" }.map { it.date }.toSet()
        var ekm = 0.0; var emin = 0.0; var hw = 0.0; var ht = 0.0
        wr.forEach { r ->
            if (r.date in easyDates && r.min > 0) {
                ekm += r.km; emin += r.min
                if ((r.hr ?: 0) > 0) { hw += r.hr!! * r.min; ht += r.min }
            }
        }
        return WeekStat(wr.size, wr.sumOf { it.km }, wr.sumOf { it.min }, if (ekm > 0) emin / ekm else null, if (ht > 0) hw / ht else null)
    }

    fun progressRows(weeks: List<RecapPlanWeek>, runs: List<RecapRun>): List<ProgressRow> =
        weeks.mapNotNull { w -> weekStats(w, runs).takeIf { it.n > 0 }?.let { ProgressRow(w, it) } }

    private fun fk(x: Double) = if (x == floor(x)) x.toLong().toString() else "%.1f".format(x).replace('.', ',')
    private fun pace(m: Double): String = Js.paceStr(m)

    fun progressEval(rows: List<ProgressRow>, currentWeekIndex: Int): List<String> {
        if (rows.isEmpty()) return emptyList()
        val last = rows.last(); val txt = mutableListOf<String>()
        val pct = if (last.week.km > 0) jsRound(last.st.km / last.week.km * 100) else 0
        txt += "M${last.week.index + 1}${if (last.week.index == currentWeekIndex) " sejauh ini" else ""}: ${fk(last.st.km)} km tercatat dari rencana ${fk(last.week.km)} km ($pct%)."
        val wp = rows.filter { it.st.pace != null }
        if (wp.isNotEmpty()) {
            val a = wp.last()
            txt += "Pace easy M${a.week.index + 1}: ${pace(a.st.pace!!)}/km${a.st.hr?.let { " di HR rata-rata ${jsRound(it)}" } ?: ""}."
            if (wp.size > 1) {
                val b = wp[wp.size - 2]
                val dp = jsRound((a.st.pace!! - b.st.pace!!) * 60)
                val dh = if (a.st.hr != null && b.st.hr != null) jsRound(a.st.hr - b.st.hr) else null
                val v = when {
                    dp <= -3 && (dh == null || dh <= 1) -> "Membaik: lebih cepat di HR yang sama atau lebih rendah."
                    dp >= 5 && dh != null && dh >= 2 -> "Waspada: lebih lambat dengan HR lebih tinggi. Cek tidur, beban, dan pemulihan."
                    else -> "Stabil."
                }
                txt += "Dibanding M${b.week.index + 1}: ${if (dp == 0) "pace sama" else "${kotlin.math.abs(dp)} dtk/km ${if (dp < 0) "lebih cepat" else "lebih lambat"}"}" +
                    (if (dh == null) "" else ", HR ${if (dh == 0) "sama" else "${kotlin.math.abs(dh)} bpm ${if (dh < 0) "lebih rendah" else "lebih tinggi"}"}") + ". $v"
            }
        }
        return txt
    }

    /** Δ pace (detik) terhadap minggu ber-pace sebelumnya; null bila tidak ada pembanding. */
    fun paceDeltas(rows: List<ProgressRow>): List<Int?> {
        var pp: Double? = null
        return rows.map { r ->
            val p = r.st.pace
            val d = if (p != null && pp != null) jsRound((p - pp!!) * 60) else null
            if (p != null) pp = p
            d
        }
    }

    // ---------- Riwayat pace easy ----------
    data class EasyWeek(val week: LocalDate, val pace: Double, val hr: Double, val n: Int, val km: Double)
    /** Lari easy = HR <= batas easy, tanjakan <= 20 m/km (easyWeeks web). */
    fun easyWeeks(runs: List<RecapRun>, easyHrMax: Int): List<EasyWeek> {
        class A { var km = 0.0; var min = 0.0; var n = 0; var hw = 0.0 }
        val m = sortedMapOf<LocalDate, A>()
        runs.forEach { r ->
            val hr = r.hr ?: return@forEach
            if (r.bike || !(r.km > 0 && r.min > 0 && hr > 0 && hr <= easyHrMax)) return@forEach
            if (r.gain / r.km > 20) return@forEach
            val o = m.getOrPut(monday(r.date)) { A() }
            o.km += r.km; o.min += r.min; o.n++; o.hw += hr * r.min
        }
        return m.map { (w, o) -> EasyWeek(w, o.min / o.km, o.hw / o.min, o.n, o.km) }
    }

    // ---------- Prediksi lomba (indeks kemampuan + PR) ----------
    fun vo2f(v: Double) = -4.6 + 0.182258 * v + 0.000104 * v * v
    fun pmaxf(t: Double) = .8 + .1894393 * exp(-.012778 * t) + .2989558 * exp(-.1932605 * t)
    fun vdotOf(dm: Double, t: Double) = vo2f(dm / t) / pmaxf(t)
    /** Waktu (menit) untuk jarak dm (meter) pada VDOT vd. */
    fun raceTimeV(vd: Double, dm: Double): Double {
        var lo = dm / 600; var hi = dm / 50
        repeat(60) { val mid = (lo + hi) / 2; if (vdotOf(dm, mid) > vd) lo = mid else hi = mid }
        return (lo + hi) / 2
    }
    fun riegel(t1: Double, d1: Double, d2: Double, e: Double = 1.06) = t1 * (d2 / d1).pow(e)
    data class PrRef(val label: String, val d: Double, val t: Double, val vdot: Double)
    /** PR patokan: VDOT tertinggi di antara 5K, 10K, half (1 km terlalu pendek). */
    fun bestPrRef(prs: List<RecapPr>): PrRef? {
        var ref: PrRef? = null
        listOf("5K" to 5.0, "10K" to 10.0, "Half marathon" to 21.0975).forEach { (lb, d) ->
            val b = prs.firstOrNull { it.label == lb } ?: return@forEach
            if (!(b.minutes > 0)) return@forEach
            val v = vdotOf(d * 1000, b.minutes)
            if (ref == null || v > ref!!.vdot) ref = PrRef(lb, d, b.minutes, v)
        }
        return ref
    }

    // ---------- Kepatuhan rencana ----------
    fun adhWeekRow(w: RecapPlanWeek, runDates: Set<LocalDate>, today: LocalDate, excluded: Set<LocalDate>): AdhRow {
        var due = 0; var dn = 0
        w.days.forEach { d ->
            if (d.kind == Kinds.REST || d.kind == Kinds.RACE || d.kind == Kinds.EVENT || d.date in excluded) return@forEach
            val ok = d.date in runDates
            if (d.date.isAfter(today) || (d.date == today && !ok)) return@forEach
            due++; if (ok) dn++
        }
        return AdhRow(w.index, due, dn)
    }
    fun adhPct(r: AdhRow?): Int? = if (r != null && r.due > 0) jsRound(r.done * 100.0 / r.due) else null

    /** Baris 4 minggu terakhir sampai minggu ini (terbaru di akhir). */
    fun adhRows(weeks: List<RecapPlanWeek>, runDates: Set<LocalDate>, today: LocalDate, excluded: Set<LocalDate>): List<AdhRow> {
        val mon = monday(today); val k = weeks.indexOfFirst { it.start == mon }
        if (k < 0) return emptyList()
        return (maxOf(0, k - 3)..k).map { adhWeekRow(weeks[it], runDates, today, excluded) }
    }

    fun adhScan(rows: List<AdhRow>): AdhScan {
        val cur = rows.lastOrNull(); val tr = mutableListOf<AdhRow>()
        var dn = 0; var du = 0; var ea = 0; var ed = 0
        val pc = adhPct(cur)
        rows.takeLast(4).forEach { r ->
            if (adhPct(r) == null) return@forEach
            tr += r; dn += r.done; du += r.due
            if (cur == null || r.i != cur.i) { ea += r.done; ed += r.due }
        }
        val pv = if (ed > 0) jsRound(ea * 100.0 / ed) else null
        val dir = if (pc != null && pv != null) (if (pc - pv >= 5) "up" else if (pv - pc >= 5) "down" else "flat") else null
        return AdhScan(pc, cur, tr, if (du > 0) jsRound(dn * 100.0 / du) else null, pv, dir)
    }

    /** Kapan geser rencana layak disarankan (ambang sama dengan web). */
    fun adhOffer(rows: List<AdhRow>): AdhOffer? {
        val full = rows.filter { it.due >= 2 }; val n = full.size
        val c = full.lastOrNull(); val b = if (n > 1) full[n - 2] else null; val cur = rows.lastOrNull()
        if (c != null && cur != null && c.i == cur.i && c.due >= 3 && c.miss >= 2 && (adhPct(c) ?: 100) < ADH_LOW) return AdhOffer(true, c.miss, adhPct(c)!!)
        if (c != null && b != null && c.i - b.i == 1 && (adhPct(c) ?: 100) < ADH_LOW2 && (adhPct(b) ?: 100) < ADH_LOW2 && b.miss + c.miss >= 3) return AdhOffer(false, b.miss + c.miss, adhPct(c)!!)
        return null
    }

    // ---------- Ulasan mingguan, streak, pencapaian ----------
    fun rvMet(o: WeekReview): Boolean = if (o.planKm != null && o.planKm > 0) o.km >= 0.8 * o.planKm else o.n >= 1

    /** pr* = PR terbaik pada akhir minggu dan sebelum minggu itu; PR baru bila diraih di dalam minggu dan lebih cepat. */
    fun newPrsIn(mon: LocalDate, atEnd: List<RecapPr>, atStart: List<RecapPr>): List<Pair<String, Double>> {
        val end = mon.plusDays(6)
        return atEnd.filter { b -> !b.date.isBefore(mon) && !b.date.isAfter(end) &&
            (atStart.firstOrNull { it.label == b.label }?.let { b.minutes < it.minutes - 1e-9 } ?: true) }
            .map { it.label to it.minutes }
    }

    fun weekReview(
        mon: LocalDate, runs: List<RecapRun>, weeks: List<RecapPlanWeek>, runDates: Set<LocalDate>,
        loadByDate: Map<LocalDate, Double> = emptyMap(), prs: List<Pair<String, Double>> = emptyList(), lite: Boolean = false,
    ): WeekReview {
        val end = mon.plusDays(6)
        var n = 0; var km = 0.0; var min = 0.0; var gain = 0.0; var longKm = 0.0; var hw = 0.0; var ht = 0.0; var prevMax = 0.0
        val wk = mutableMapOf<LocalDate, Double>()
        runs.forEach { r ->
            if (r.bike || !(r.km > 0)) return@forEach
            if (!r.date.isBefore(mon) && !r.date.isAfter(end)) {
                n++; km += r.km; min += r.min; gain += r.gain; if (r.km > longKm) longKm = r.km
                if ((r.hr ?: 0) > 0 && r.min > 0) { hw += r.hr!! * r.min; ht += r.min }
            } else if (r.date.isBefore(mon)) {
                if (r.km > prevMax) prevMax = r.km
                val m = monday(r.date); wk[m] = (wk[m] ?: 0.0) + r.km
            }
        }
        val pw = weeks.firstOrNull { it.start == mon }
        var planKm: Double? = null; var planN: Int? = null; var cons: Int? = null
        if (pw != null) {
            val pl = pw.days.filter { it.kind != Kinds.REST }
            planKm = pw.km; planN = pl.size
            cons = if (pl.isNotEmpty()) jsRound(pl.count { it.date in runDates } * 100.0 / pl.size) else null
        }
        var load = 0.0; var recLong = false; var recWeek = false; var prevKm = 0.0
        if (!lite) {
            for (i in 0..6) load += loadByDate[mon.plusDays(i.toLong())] ?: 0.0
            val prevWk = wk.values.maxOrNull() ?: 0.0
            recLong = prevMax > 0 && longKm >= 5 && longKm > prevMax + 0.05
            recWeek = prevWk > 0 && km >= 5 && km > prevWk + 0.05
            prevKm = wk[mon.minusWeeks(1)] ?: 0.0
        }
        return WeekReview(mon, end, n, km, min, gain, longKm, load, if (ht > 0) hw / ht else null, planKm, planN, cons,
            if (lite) emptyList() else prs, recLong, recWeek, prevKm)
    }

    /** Minggu beruntun: minggu dengan km >= 80% rencana (tanpa rencana: minimal satu lari). */
    fun weekStreak(runs: List<RecapRun>, weeks: List<RecapPlanWeek>, runDates: Set<LocalDate>, today: LocalDate): Int {
        val first = runs.filter { !it.bike && it.km > 0 }.minOfOrNull { it.date } ?: return 0
        val cur = monday(today); val firstMon = monday(first)
        var n = 0; var m = cur.minusWeeks(1); var i = 0
        while (i < 300 && !m.isBefore(firstMon)) {
            if (rvMet(weekReview(m, runs, weeks, runDates, lite = true))) n++ else break
            m = m.minusWeeks(1); i++
        }
        val cm = rvMet(weekReview(cur, runs, weeks, runDates, lite = true))
        return n + if (cm) 1 else 0
    }

    /** Hari berturut-turut dengan lari tercatat; hari libur rencana tidak memutus. */
    fun dayStreak(runs: List<RecapRun>, restDates: Set<LocalDate>, today: LocalDate): Int {
        val has = runs.filter { it.km > 0 }.map { it.date }.toSet()
        var d = today; var n = 0
        if (d !in has) d = d.minusDays(1)
        for (i in 0 until 400) {
            if (d in has) n++ else if (d !in restDates) break
            d = d.minusDays(1)
        }
        return n
    }

    fun achievements(runs: List<RecapRun>, prCount: Int, prTotal: Int, weekStreak: Int): List<Achievement> {
        val rs = runs.filter { !it.bike && it.km > 0 }
        val tot = rs.sumOf { it.km }; val mx = rs.maxOfOrNull { it.km } ?: 0.0
        val a = mutableListOf<Achievement>()
        listOf(100, 250, 500, 1000, 2000).forEach { a += Achievement(tot >= it, "${Js.idn(it)} km total") }
        listOf(10.0 to "10 km", 21.0975 to "Half marathon", 30.0 to "30 km", 42.195 to "Marathon").forEach { a += Achievement(mx >= it.first, "Lari terpanjang ≥ ${it.second}") }
        listOf(2, 4, 8, 12).forEach { a += Achievement(weekStreak >= it, "$it minggu beruntun") }
        a += Achievement(prCount >= 1, "PR pertama")
        a += Achievement(prCount >= prTotal, "Semua jarak PR terisi")
        return a
    }

    // ---------- Agregat harian / bulanan / tahunan (lari saja, sepeda dikecualikan) ----------
    fun dayAggregates(runs: List<RecapRun>): Map<LocalDate, DayAgg> {
        val m = mutableMapOf<LocalDate, DayAgg>()
        runs.forEach { r ->
            if (r.bike || !(r.km > 0 || r.min > 0)) return@forEach
            val o = m[r.date]
            m[r.date] = if (o == null) DayAgg(r.km, r.min, r.gain, 1) else DayAgg(o.km + r.km, o.min + r.min, o.gain + r.gain, o.n + 1)
        }
        return m
    }
    fun years(dm: Map<LocalDate, DayAgg>, today: LocalDate): List<Int> =
        (dm.keys.map { it.year } + today.year).distinct().sorted()

    fun monthAgg(dm: Map<LocalDate, DayAgg>, year: Int): List<MonthAgg> {
        val km = DoubleArray(12); val mn = DoubleArray(12); val gn = DoubleArray(12); val dy = IntArray(12)
        dm.forEach { (d, r) -> if (d.year == year) { val i = d.monthValue - 1; km[i] += r.km; mn[i] += r.min; gn[i] += r.gain; dy[i]++ } }
        return (0 until 12).map { MonthAgg(km[it], mn[it], gn[it], dy[it]) }
    }
    /** "" / "=" / "▲12%" / "▼5%" seperti stDelta web. */
    fun deltaText(cur: Double, prev: Double): String {
        if (!(prev > 0)) return ""
        val p = jsRound((cur - prev) / prev * 100)
        return if (p == 0) "=" else (if (p > 0) "▲" else "▼") + kotlin.math.abs(p) + "%"
    }

    /** Ambang 4 level heatmap dari kuartil nilai > 0. */
    fun levels(vals: Collection<Double>): DoubleArray {
        val v = vals.filter { it > 0 }.sorted()
        if (v.isEmpty()) return doubleArrayOf(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY)
        fun q(p: Double) = v[minOf(v.size - 1, floor(p * (v.size - 1) + .5).toInt())]
        return doubleArrayOf(q(.25), q(.5), q(.75))
    }
    fun levelOf(v: Double, cut: DoubleArray): Int = if (!(v > 0)) 0 else if (v <= cut[0]) 1 else if (v <= cut[1]) 2 else if (v <= cut[2]) 3 else 4

    fun yearGrid(year: Int): Pair<List<GridCell>, Int> {
        val jan1 = LocalDate.of(year, 1, 1)
        val start = jan1.minusDays((jan1.dayOfWeek.value - 1).toLong())
        val end = LocalDate.of(year, 12, 31)
        val n = java.time.temporal.ChronoUnit.DAYS.between(start, end).toInt() + 1
        val cells = (0 until n).map { i -> val d = start.plusDays(i.toLong()); GridCell(d, i / 7, i % 7, d.year == year) }
        return cells to ((n + 6) / 7)
    }
    /** Jarak dan hari aktif dari 1 Jan sampai tanggal yang sama (bulan-hari) di tahun yang diminta. */
    fun ytd(dm: Map<LocalDate, DayAgg>, year: Int, today: LocalDate): Pair<Double, Int> {
        var km = 0.0; var days = 0
        dm.forEach { (d, r) ->
            if (d.year != year || (d.monthValue * 100 + d.dayOfMonth) > (today.monthValue * 100 + today.dayOfMonth)) return@forEach
            km += r.km; if (r.km > 0 || r.min > 0) days++
        }
        return km to days
    }

    // ---------- Log bulanan ----------
    /** Bulan dari yang tertua (data/rencana) sampai bulan ini, maksimum 24 bulan terakhir. */
    fun monthRange(dates: Collection<LocalDate>, planStart: LocalDate?, today: LocalDate): List<YearMonth> {
        var lo = YearMonth.from(today)
        (dates + listOfNotNull(planStart)).forEach { val ym = YearMonth.from(it); if (ym.isBefore(lo)) lo = ym }
        val out = mutableListOf<YearMonth>(); var m = lo; val cm = YearMonth.from(today)
        while (!m.isAfter(cm)) { out += m; m = m.plusMonths(1) }
        return if (out.size > 24) out.takeLast(24) else out
    }
    /** Level warna sel hari lari: <6 km ringan, >=12 km berat, selain itu sedang. */
    fun monthDayLevel(km: Double, run: Boolean): Int = if (run && km > 0) (if (km < 6) 1 else if (km >= 12) 3 else 2) else 0
}
