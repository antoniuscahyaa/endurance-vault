package com.endurancevault.app.ui.screens

import android.graphics.Paint
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.lerp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.endurancevault.app.domain.ActBuilder
import com.endurancevault.app.domain.CourseStrategy
import com.endurancevault.app.domain.CourseStrategy.Pt
import com.endurancevault.app.domain.GpxRoute
import com.endurancevault.app.domain.Js
import com.endurancevault.app.ui.theme.Ember
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

private val UpC = Color(0xFFC4431B)
private val DownC = Color(0xFF2F6FD0)
private val FlatC = Color(0xFF8A8F98)
private fun segColor(type: String) = when (type) { "up" -> UpC; "down" -> DownC; else -> FlatC }
private fun segIcon(type: String) = when (type) { "up" -> "▲"; "down" -> "▼"; else -> "▬" }
private fun pct(g: Double) = Js.n(Js.round(abs(g) * 1000) / 10).replace('.', ',') + "%"
private fun stratLabel(k: String) = when (k) { "neg" -> "Negative split"; "cons" -> "Hati-hati"; else -> "Rata" }
private fun surfLabel(k: String) = when (k) { "dry" -> "Padat"; "slip" -> "Licin"; else -> "Biasa" }

private const val MAX_ZOOM = 8f

/**
 * Dialog kirim rute GPX ke jam, layar penuh. Atas (terpaku): peta yang bisa di-zoom cubit + profil elevasi/pace.
 * Tengah (bisa digulir): ringkasan rute, pengaturan strategi pacing (satu tombol), pace per ruas. Bawah (terpaku): tombol kirim.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun GpxPreviewDialog(p: GpxRoute.Preview, onSend: (CourseStrategy.Result?) -> Unit, onDismiss: () -> Unit) {
    var target by remember(p) { mutableStateOf("") }
    var strat by remember(p) { mutableStateOf("even") }
    var surf by remember(p) { mutableStateOf("dry") }
    var sendPace by remember(p) { mutableStateOf(true) }
    var showKm by remember(p) { mutableStateOf(true) }
    var settingsOpen by remember(p) { mutableStateOf(false) }
    val outcome = remember(p, target, strat, surf) {
        if (target.isEmpty()) null else CourseStrategy.pacing(p.pts, target, strat, surf)
    }
    val res = outcome?.result
    // ruas strategi yang sedang ditandai di peta (null = tidak ada); reset bila hasil strategi berubah
    var selSeg by remember(res) { mutableStateOf<Int?>(null) }
    val hi = remember(res, selSeg) {
        val sg = selSeg?.let { res?.segs?.getOrNull(it) }
        if (res == null || sg == null) null
        else SegHi(sg.from / res.km, sg.to / res.km, segColor(sg.type), "km ${Js.fmtKm(sg.from)}", "km ${Js.fmtKm(sg.to)}")
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            BoxWithConstraints(Modifier.fillMaxSize().systemBarsPadding()) {
            // peta 2x lebih besar (420 dp), dibatasi setengah tinggi layar agar area data tetap punya ruang di HP pendek
            val mapH = minOf(420.dp, maxHeight * 0.5f)
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, contentDescription = "Tutup") }
                    Column(Modifier.weight(1f)) {
                        Text("Kirim rute ke jam", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(p.name, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }

                // Terpaku: peta + profil elevasi/pace dalam satu panel, tidak ikut menggulir.
                EvPanel(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                    RouteMap(p, showKm, { showKm = it }, hi, Modifier.fillMaxWidth().height(mapH))
                    HorizontalDivider()
                    Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            DCaption(if (res != null) "Profil elevasi · warna sesuai ruas strategi" else "Profil elevasi")
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Legend("Naik", UpC); Legend("Turun", DownC); Legend("Datar", FlatC) }
                        }
                        when {
                            res != null -> SegElevChart(res, p.stats.prof, showKm, selSeg)
                            p.stats.hasEle -> { ElevChart(p.stats.prof); DCaption("Atur target waktu lewat tombol pengaturan untuk melihat pace per ruas.") }
                            else -> DCaption("Tanpa data elevasi, hanya jalur yang dikirim.")
                        }
                    }
                }

                // Bisa digulir: data di bawah panel peta.
                Column(
                    Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    val ele = if (p.stats.hasEle) "Elevasi ${Js.idn(Js.roundI(p.stats.min ?: 0.0))}–${Js.idn(Js.roundI(p.stats.max ?: 0.0))} m · " else ""
                    val thin = if (p.total > p.sent) "${p.sent} dari ${p.total} titik dikirim" else "${p.sent} titik dikirim"
                    DCaption(ele + thin + if (p.stats.hasEle) "" else ". Tanpa data elevasi, hanya jalur yang dikirim.")

                    EvPanel(Modifier.fillMaxWidth()) {
                        Row(
                            Modifier.fillMaxWidth().padding(start = 12.dp, top = 4.dp, bottom = 4.dp, end = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text("Strategi pacing", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                DCaption(if (target.isEmpty()) "Belum diatur · opsional" else "$target · ${stratLabel(strat)} · ${surfLabel(surf)}")
                            }
                            IconButton(onClick = { settingsOpen = true }) { Icon(Icons.Filled.Tune, contentDescription = "Atur strategi pacing") }
                        }
                    }
                    when {
                        target.isEmpty() -> DCaption(CourseStrategy.errText("waktu"))
                        res == null -> DCaption(CourseStrategy.errText(outcome?.err))
                        else -> PacingResult(res, selSeg) { selSeg = if (selSeg == it) null else it }
                    }
                }

                // Terpaku: tombol kirim.
                HorizontalDivider()
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Row(
                        Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).clickable(enabled = res != null) { sendPace = !sendPace },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(checked = sendPace && res != null, onCheckedChange = { sendPace = it }, enabled = res != null)
                        Column {
                            Text("Kirim juga pace", style = MaterialTheme.typography.bodyMedium)
                            DCaption(if (res == null) "Atur target waktu dulu" else "Sesi latihan, ±5%")
                        }
                    }
                    TextButton(onClick = onDismiss) { Text("Batal") }
                    Button(onClick = { onSend(if (sendPace) res else null) }) { Text("Kirim ke jam") }
                }
            }
            }
        }
    }

    if (settingsOpen) {
        ModalBottomSheet(onDismissRequest = { settingsOpen = false }, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 16.dp).navigationBarsPadding().imePadding(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text("Pengaturan strategi pacing", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = target, onValueChange = { target = GpxRoute.timeFmt(it) }, singleLine = true,
                    label = { Text("Target waktu") }, placeholder = { Text("mis. 5:30:00") },
                    supportingText = { Text("Ketik angka saja: 30000 → 3:00:00") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                )
                Choice("Strategi", listOf("even" to "Rata", "neg" to "Negative split", "cons" to "Hati-hati"), strat) { strat = it }
                Choice("Permukaan turunan", listOf("dry" to "Padat", "norm" to "Biasa", "slip" to "Licin"), surf) { surf = it }
                Button(onClick = { settingsOpen = false }, modifier = Modifier.fillMaxWidth()) { Text("Selesai") }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun Choice(label: String, items: List<Pair<String, String>>, sel: String, onSel: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items.forEach { (k, l) -> FilterChip(selected = sel == k, onClick = { onSel(k) }, label = { Text(l, style = MaterialTheme.typography.labelMedium) }) }
        }
    }
}

/** Proyeksi equirectangular titik rute + jarak kumulatif (km) per titik, dihitung sekali per rute. */
private class MapProj(pts: List<Pt>) {
    val xs: DoubleArray; val ys: DoubleArray; val cum: DoubleArray
    val x0: Double; val x1: Double; val y0: Double; val y1: Double
    init {
        val cosLat = cos(Math.toRadians(pts.sumOf { it.lat } / pts.size))
        xs = DoubleArray(pts.size) { pts[it].lon * cosLat }
        ys = DoubleArray(pts.size) { pts[it].lat }
        cum = DoubleArray(pts.size)
        for (i in 1 until pts.size) cum[i] = cum[i - 1] + ActBuilder.hav(pts[i - 1].lat, pts[i - 1].lon, pts[i].lat, pts[i].lon) / 1000
        x0 = xs.min(); x1 = xs.max(); y0 = ys.min(); y1 = ys.max()
    }

    /** Indeks titik terakhir dengan jarak kumulatif <= [k] km (dibatasi agar i+1 valid). */
    fun idx(k: Double): Int {
        var lo = 0; var hi = cum.size - 2
        while (lo < hi) { val m = (lo + hi + 1) / 2; if (cum[m] <= k) lo = m else hi = m - 1 }
        return lo
    }

    /** Koordinat terproyeksi (x, y) pada jarak [k] km sepanjang rute. */
    fun at(k: Double): DoubleArray {
        val i = idx(k); val seg = cum[i + 1] - cum[i]
        val t = if (seg > 0) ((k - cum[i]) / seg).coerceIn(0.0, 1.0) else 0.0
        return doubleArrayOf(xs[i] + (xs[i + 1] - xs[i]) * t, ys[i] + (ys[i + 1] - ys[i]) * t)
    }
}

/** Penempatan proyeksi ke kanvas [w]x[h] piksel dengan ruang kosong [padX]/[padY]. */
private class MapLayout(val proj: MapProj, val w: Float, val h: Float, padX: Float, padY: Float) {
    private val sc = min((w - 2 * padX) / max(1e-9, proj.x1 - proj.x0), (h - 2 * padY) / max(1e-9, proj.y1 - proj.y0))
    private val ox = (w - (proj.x1 - proj.x0) * sc) / 2
    private val oy = (h - (proj.y1 - proj.y0) * sc) / 2
    fun pt(x: Double, y: Double) = Offset((ox + (x - proj.x0) * sc).toFloat(), (h - oy - (y - proj.y0) * sc).toFloat())
    fun point(i: Int) = pt(proj.xs[i], proj.ys[i])
    fun at(k: Double): Offset { val c = proj.at(k); return pt(c[0], c[1]) }
}

/** Ruas strategi yang ditandai di peta: [from]/[to] = pecahan panjang rute (0..1). */
private class SegHi(val from: Double, val to: Double, val color: Color, val fromLabel: String, val toLabel: String)

/**
 * Peta jalur offline: cubit dua jari untuk zoom, geser untuk menggeser, ketuk dua kali untuk zoom/reset.
 * Penanda km (opsional) menyesuaikan kerapatannya dengan zoom. Ruas strategi yang diketuk ([hi]) ditandai di jalur dan peta di-zoom pas ke ruas itu.
 * Jarak/naik/turun ada di kotak kecil pojok kanan bawah.
 */
@Composable
private fun RouteMap(p: GpxRoute.Preview, showKm: Boolean, onShowKm: (Boolean) -> Unit, hi: SegHi?, modifier: Modifier = Modifier) {
    val line = Ember
    val halo = MaterialTheme.colorScheme.surface
    val inkArgb = MaterialTheme.colorScheme.onSurface.toArgb()
    val density = LocalDensity.current
    var zoom by remember(p) { mutableFloatStateOf(1f) }
    var offset by remember(p) { mutableStateOf(Offset.Zero) }
    var box by remember { mutableStateOf(IntSize.Zero) }
    val proj = remember(p) { MapProj(p.pts) }
    val paint = remember { Paint().apply { isAntiAlias = true; textAlign = Paint.Align.CENTER; isFakeBoldText = true } }
    val padX = with(density) { 16.dp.toPx() }
    val padY = with(density) { 48.dp.toPx() } // ruang untuk switch di atas dan kotak data di bawah

    // Ruas diketuk: zoom pas ke ruas itu. Pilihan dibatalkan: kembali ke tampilan utuh.
    LaunchedEffect(hi, box) {
        if (box.width == 0 || box.height == 0) return@LaunchedEffect
        if (hi == null) { zoom = 1f; offset = Offset.Zero; return@LaunchedEffect }
        val total = proj.cum.last()
        val lay = MapLayout(proj, box.width.toFloat(), box.height.toFloat(), padX, padY)
        val kA = hi.from * total; val kB = hi.to * total
        val a = lay.at(kA); val b = lay.at(kB)
        var bx0 = min(a.x, b.x); var bx1 = max(a.x, b.x); var by0 = min(a.y, b.y); var by1 = max(a.y, b.y)
        for (i in (proj.idx(kA) + 1)..proj.idx(kB)) {
            val o = lay.point(i)
            bx0 = min(bx0, o.x); bx1 = max(bx1, o.x); by0 = min(by0, o.y); by1 = max(by1, o.y)
        }
        val margin = with(density) { 56.dp.toPx() }; val minSpan = with(density) { 80.dp.toPx() }
        val bw = max(bx1 - bx0, minSpan); val bh = max(by1 - by0, minSpan)
        val z = min((box.width - 2 * margin) / bw, (box.height - 2 * margin) / bh).coerceIn(1f, MAX_ZOOM)
        val cx = (bx0 + bx1) / 2; val cy = (by0 + by1) / 2
        zoom = z
        offset = Offset((box.width / 2f - cx * z).coerceIn(box.width * (1 - z), 0f), (box.height / 2f - cy * z).coerceIn(box.height * (1 - z), 0f))
    }

    Box(modifier.clipToBounds().background(MaterialTheme.colorScheme.surfaceVariant).onSizeChanged { box = it }) {
        Canvas(
            Modifier.fillMaxSize()
                .pointerInput(p) {
                    detectTransformGestures { centroid, pan, z, _ ->
                        val ns = (zoom * z).coerceIn(1f, MAX_ZOOM)
                        val raw = centroid - (centroid - offset) * (ns / zoom) + pan
                        zoom = ns
                        offset = Offset(raw.x.coerceIn(size.width * (1 - ns), 0f), raw.y.coerceIn(size.height * (1 - ns), 0f))
                    }
                }
                .pointerInput(p) {
                    detectTapGestures(onDoubleTap = { pos ->
                        if (zoom > 1.01f) { zoom = 1f; offset = Offset.Zero } else {
                            val ns = 3f
                            val raw = pos - (pos - offset) * (ns / zoom)
                            zoom = ns
                            offset = Offset(raw.x.coerceIn(size.width * (1 - ns), 0f), raw.y.coerceIn(size.height * (1 - ns), 0f))
                        }
                    })
                },
        ) {
            val n = proj.xs.size
            val lay = MapLayout(proj, size.width, size.height, padX, padY)
            val base = List(n) { lay.point(it) }
            fun tr(o: Offset) = o * zoom + offset

            val path = Path()
            var pathPx = 0f
            for (i in 0 until n) {
                val o = tr(base[i]); if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y)
                if (i > 0) { val dx = base[i].x - base[i - 1].x; val dy = base[i].y - base[i - 1].y; pathPx += sqrt(dx * dx + dy * dy) }
            }
            drawPath(path, halo, style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            drawPath(path, line.copy(alpha = if (hi != null) 0.45f else 1f), style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))

            val total = proj.cum.last()
            if (showKm && total > 0 && pathPx > 0f) {
                val minStepKm = 44.dp.toPx() / (pathPx * zoom / total)
                val step = listOf(0.5, 1.0, 2.0, 5.0, 10.0, 20.0, 50.0, 100.0).firstOrNull { it >= minStepKm } ?: 100.0
                paint.textSize = 10.sp.toPx(); paint.color = inkArgb
                var k = step; var i = 0
                while (k < total - step * 0.3) {
                    while (i < n - 2 && proj.cum[i + 1] < k) i++
                    val seg = proj.cum[i + 1] - proj.cum[i]
                    val t = if (seg > 0) ((k - proj.cum[i]) / seg).coerceIn(0.0, 1.0).toFloat() else 0f
                    val o = tr(lerp(base[i], base[i + 1], t))
                    if (o.x in -20f..size.width + 20f && o.y in -20f..size.height + 20f) {
                        val label = if (k % 1.0 == 0.0) k.toInt().toString() else Js.fmtKm(k)
                        val r = if (label.length <= 2) 10.dp.toPx() else 13.dp.toPx()
                        drawCircle(halo, r, o)
                        drawCircle(line, r, o, style = Stroke(width = 1.5.dp.toPx()))
                        drawContext.canvas.nativeCanvas.drawText(label, o.x, o.y - (paint.fontMetrics.ascent + paint.fontMetrics.descent) / 2, paint)
                    }
                    k += step
                }
            }

            // Penanda ruas strategi yang diketuk: jalur ruas ditebalkan sewarna ruas, titik awal/akhir diberi label km.
            if (hi != null && total > 0) {
                val kA = hi.from * total; val kB = hi.to * total
                val a = tr(lay.at(kA)); val b = tr(lay.at(kB))
                val hp = Path(); hp.moveTo(a.x, a.y)
                for (i in (proj.idx(kA) + 1)..proj.idx(kB)) { val o = tr(base[i]); hp.lineTo(o.x, o.y) }
                hp.lineTo(b.x, b.y)
                drawPath(hp, halo, style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                drawPath(hp, hi.color, style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                paint.textSize = 10.sp.toPx(); paint.color = inkArgb; paint.isFakeBoldText = true
                fun pin(o: Offset, text: String, filled: Boolean) {
                    drawCircle(halo, 8.dp.toPx(), o)
                    if (filled) drawCircle(hi.color, 6.dp.toPx(), o) else drawCircle(hi.color, 6.dp.toPx(), o, style = Stroke(width = 2.5.dp.toPx()))
                    val pw = paint.measureText(text) + 14.dp.toPx(); val ph = 20.dp.toPx()
                    val cx = o.x.coerceIn(pw / 2, size.width - pw / 2); val cy = (o.y - 24.dp.toPx()).coerceIn(ph / 2, size.height - ph / 2)
                    val tl = Offset(cx - pw / 2, cy - ph / 2)
                    drawRoundRect(halo, tl, Size(pw, ph), CornerRadius(ph / 2))
                    drawRoundRect(hi.color, tl, Size(pw, ph), CornerRadius(ph / 2), style = Stroke(width = 1.5.dp.toPx()))
                    drawContext.canvas.nativeCanvas.drawText(text, cx, cy - (paint.fontMetrics.ascent + paint.fontMetrics.descent) / 2, paint)
                }
                pin(a, hi.fromLabel, true); pin(b, hi.toLabel, false)
            }

            val s0 = tr(base.first()); val s1 = tr(base.last())
            drawCircle(halo, 7.5.dp.toPx(), s0); drawCircle(Color(0xFF2E9E5B), 5.5.dp.toPx(), s0)
            drawCircle(halo, 7.5.dp.toPx(), s1); drawCircle(Color(0xFFD33F3F), 5.5.dp.toPx(), s1)
        }

        Surface(
            Modifier.align(Alignment.TopEnd).padding(8.dp), shape = RoundedCornerShape(18.dp),
            color = halo.copy(alpha = 0.9f), border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant),
        ) {
            Row(Modifier.padding(start = 12.dp, end = 2.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("Indikator km", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                Switch(checked = showKm, onCheckedChange = onShowKm, modifier = Modifier.scale(0.8f))
            }
        }
        Surface(
            Modifier.align(Alignment.BottomStart).padding(8.dp), shape = RoundedCornerShape(12.dp), color = halo.copy(alpha = 0.9f),
        ) {
            Row(Modifier.padding(horizontal = 10.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Legend("Mulai", Color(0xFF2E9E5B)); Legend("Finis", Color(0xFFD33F3F))
                if (zoom <= 1.01f) Text("Cubit untuk zoom", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                else Text(
                    "Reset · ${Js.n(Js.round(zoom * 10.0) / 10)}×", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary, modifier = Modifier.clickable { zoom = 1f; offset = Offset.Zero },
                )
            }
        }
        // Data rute: kotak kecil di ujung kanan bawah supaya jalur tetap terlihat.
        Surface(
            Modifier.align(Alignment.BottomEnd).padding(8.dp), shape = RoundedCornerShape(10.dp),
            color = halo.copy(alpha = 0.9f), border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant),
        ) {
            Column(Modifier.padding(horizontal = 8.dp, vertical = 5.dp), horizontalAlignment = Alignment.End) {
                Text("${Js.fmtKm(p.km)} km", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                Text(if (p.stats.hasEle) "▲ +${Js.idn(p.stats.up)} m" else "▲ –", style = MaterialTheme.typography.labelSmall, color = UpC)
                Text(if (p.stats.hasEle) "▼ −${Js.idn(p.stats.down)} m" else "▼ –", style = MaterialTheme.typography.labelSmall, color = DownC)
            }
        }
    }
}

/** Profil elevasi polos (dipakai selagi strategi pacing belum diisi). */
@Composable
private fun ElevChart(prof: List<DoubleArray>) {
    if (prof.size < 2) return
    Canvas(Modifier.fillMaxWidth().height(64.dp)) {
        val w = size.width; val h = size.height
        var lo = Double.MAX_VALUE; var hi = -Double.MAX_VALUE
        prof.forEach { lo = min(lo, it[1]); hi = max(hi, it[1]) }
        val rg = if (hi - lo > 0) hi - lo else 1.0
        val pk = prof.last()[0].let { if (it > 0) it else 1.0 }
        fun x(k: Double) = (k / pk * w).toFloat()
        fun y(e: Double) = (h - 4.dp.toPx() - (e - lo) / rg * (h - 8.dp.toPx())).toFloat()
        val fill = Path(); fill.moveTo(0f, h)
        prof.forEach { fill.lineTo(x(it[0]), y(it[1])) }
        fill.lineTo(w, h); fill.close()
        drawPath(fill, Ember.copy(alpha = 0.3f))
        val ln = Path(); prof.forEachIndexed { i, q -> if (i == 0) ln.moveTo(x(q[0]), y(q[1])) else ln.lineTo(x(q[0]), y(q[1])) }
        drawPath(ln, Ember, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** Bagian bawah (bisa digulir): ringkasan, catatan penting, dan kartu pace per ruas. Grafik dan peta ada di panel terpaku. */
@Composable
private fun PacingResult(r: CourseStrategy.Result, selected: Int?, onSelect: (Int) -> Unit) {
    var allNotes by remember(r) { mutableStateOf(false) }
    val notes = remember(r) { CourseStrategy.summary(r) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
            Column {
                Text(Js.durStr(r.tp), style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                DCaption("target waktu")
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("${Js.paceStr(r.tp / r.km)} /km", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                DCaption("pace rata-rata")
            }
        }
        val shown = if (allNotes) notes else notes.take(3)
        shown.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
        if (notes.size > 3) {
            Text(
                if (allNotes) "Tampilkan lebih sedikit" else "Semua catatan (${notes.size - 3} lagi)",
                style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.clickable { allNotes = !allNotes },
            )
        }
        HorizontalDivider()
        Text("Pace per ruas · ${r.segs.size} ruas", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        DCaption("Ketuk ruas untuk menandainya di peta dan melihat arahannya.")
        r.segs.forEachIndexed { i, sg -> SegRow(sg, r, selected == i) { onSelect(i) } }
        DCaption("Dihitung dari profil elevasi (usaha setara, GAP Minetti). Rute dikirim ke jam; pace ikut terkirim sebagai sesi latihan bila \"Kirim juga pace\" dicentang.")
    }
}

@Composable
private fun Legend(t: String, c: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        Box(Modifier.width(8.dp).height(8.dp).clip(RoundedCornerShape(2.dp)).background(c))
        Text(t, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Satu baris ruas: jarak + medan di kiri, pace + waktu kumulatif di kanan; ketuk untuk menandai di peta dan membuka arahan. */
@Composable
private fun SegRow(s: CourseStrategy.Seg, r: CourseStrategy.Result, selected: Boolean, onClick: () -> Unit) {
    val gain = if (s.type == "up") " · +${Js.roundI(s.gain)} m" else if (s.type == "down") " · −${Js.roundI(s.loss)} m" else ""
    val range = s.pr?.let { " · ≈ ${Js.paceStr(it[0])}–${Js.paceStr(it[1])}" } ?: ""
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surfaceVariant)
            .then(if (selected) Modifier.border(1.5.dp, segColor(s.type), RoundedCornerShape(10.dp)) else Modifier)
            .clickable(onClick = onClick),
    ) {
        Box(Modifier.width(4.dp).fillMaxHeight().background(segColor(s.type)))
        Column(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("km ${Js.fmtKm(s.from)}–${Js.fmtKm(s.to)}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "${segIcon(s.type)} ${pct(s.g)}$gain · ${CourseStrategy.segLabel(s)}$range",
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(Js.paceStr(s.pace), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("→ ${Js.durStr(s.eta)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (selected) Text(CourseStrategy.tip(s, r), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

/** Profil elevasi diwarnai per ruas strategi (ruas yang dipilih menonjol) dan sumbu km opsional. Batang pace dihapus: pace ada di daftar ruas. */
@Composable
private fun SegElevChart(r: CourseStrategy.Result, prof: List<DoubleArray>, showKm: Boolean, selected: Int?) {
    if (r.segs.isEmpty() || prof.size < 2) return
    val axis = MaterialTheme.colorScheme.outlineVariant
    val axisTxt = MaterialTheme.colorScheme.onSurfaceVariant.toArgb()
    val paint = remember { Paint().apply { isAntiAlias = true; textAlign = Paint.Align.CENTER } }
    Canvas(Modifier.fillMaxWidth().height(if (showKm) 92.dp else 78.dp)) {
        val w = size.width; val h = size.height
        val axH = if (showKm) 14.dp.toPx() else 0f
        val eT = 4.dp.toPx(); val eB = h - axH
        val km = r.km
        var lo = Double.MAX_VALUE; var hi = -Double.MAX_VALUE
        prof.forEach { lo = min(lo, it[1]); hi = max(hi, it[1]) }
        val rg = if (hi - lo > 0) hi - lo else 1.0
        val pk = prof.last()[0].let { if (it > 0) it else 1.0 }
        fun x(k: Double) = (k / km * w).toFloat()
        fun y(e: Double) = (eB - (e - lo) / rg * (eB - eT)).toFloat()
        r.segs.forEachIndexed { idx, s ->
            val col = segColor(s.type)
            var pts = prof.filter { it[0] / pk * km >= s.from - 1e-6 && it[0] / pk * km <= s.to + 1e-6 }
            if (pts.size < 2) {
                val mid = (s.from + s.to) / 2
                val m = prof.minByOrNull { abs(it[0] / pk * km - mid) }!!
                pts = listOf(doubleArrayOf(s.from / km * pk, m[1]), doubleArrayOf(s.to / km * pk, m[1]))
            }
            val path = Path()
            path.moveTo(x(s.from), eB)
            pts.forEach { path.lineTo(x(it[0] / pk * km), y(it[1])) }
            path.lineTo(x(s.to), eB); path.close()
            val a = if (selected == null) 0.6f else if (selected == idx) 1f else 0.25f
            drawPath(path, col.copy(alpha = a))
        }
        drawLine(axis, Offset(0f, eB), Offset(w, eB))
        if (showKm) {
            paint.textSize = 9.sp.toPx(); paint.color = axisTxt
            val step = listOf(1.0, 2.0, 5.0, 10.0, 20.0, 50.0, 100.0).first { km / it <= 5.0 }
            var k = 0.0
            while (k <= km + 1e-6) {
                val label = if (k % 1.0 == 0.0) k.toInt().toString() else Js.fmtKm(k)
                val tw = paint.measureText(label)
                drawContext.canvas.nativeCanvas.drawText(label, x(k).coerceIn(tw / 2, w - tw / 2), h - 2.dp.toPx(), paint)
                k += step
            }
        }
    }
}
