package com.endurancevault.app.ui.screens

import android.graphics.Paint
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.lerp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.endurancevault.app.domain.ActBuilder
import com.endurancevault.app.domain.CourseStrategy
import com.endurancevault.app.domain.CourseStrategy.Pt
import com.endurancevault.app.domain.GpxRoute
import com.endurancevault.app.domain.Js
import com.endurancevault.app.ui.theme.Ember
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

private val UpC = Color(0xFFC4431B)
private val DownC = Color(0xFF2F6FD0)
private val FlatC = Color(0xFF8A8F98)
private fun segColor(type: String) = when (type) { "up" -> UpC; "down" -> DownC; else -> FlatC }
private fun segIcon(type: String) = when (type) { "up" -> "▲"; "down" -> "▼"; else -> "▬" }
private fun pct(g: Double) = Js.n(Js.round(abs(g) * 1000) / 10).replace('.', ',') + "%"
private fun stratLabel(k: String) = when (k) { "neg" -> "Negative split"; "cons" -> "Hati-hati"; else -> "Rata" }
private fun surfLabel(k: String) = when (k) { "dry" -> "Padat"; "slip" -> "Licin"; else -> "Biasa" }

private const val MAX_ZOOM = 8f

/**
 * Dialog kirim rute GPX ke jam, layar penuh. Atas (terpaku): peta yang bisa di-zoom cubit + profil elevasi/pace.
 * Tengah (bisa digulir): ringkasan rute, pengaturan strategi pacing (satu tombol), pace per ruas. Bawah (terpaku): tombol kirim.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun GpxPreviewDialog(p: GpxRoute.Preview, onSend: (CourseStrategy.Result?) -> Unit, onDismiss: () -> Unit) {
    var target by remember(p) { mutableStateOf("") }
    var strat by remember(p) { mutableStateOf("even") }
    var surf by remember(p) { mutableStateOf("dry") }
    var sendPace by remember(p) { mutableStateOf(true) }
    var showKm by remember(p) { mutableStateOf(true) }
    var settingsOpen by remember(p) { mutableStateOf(false) }
    val outcome = remember(p, target, strat, surf) {
        if (target.isEmpty()) null else CourseStrategy.pacing(p.pts, target, strat, surf)
    }
    val res = outcome?.result

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize().systemBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, contentDescription = "Tutup") }
                    Column(Modifier.weight(1f)) {
                        Text("Kirim rute ke jam", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(p.name, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }

                // Terpaku: peta + profil elevasi/pace dalam satu panel, tidak ikut menggulir.
                EvPanel(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                    RouteMap(p, showKm, { showKm = it }, Modifier.fillMaxWidth().height(210.dp))
                    HorizontalDivider()
                    Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            DCaption(if (res != null) "Profil elevasi + pace (min/km)" else "Profil elevasi")
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Legend("Naik", UpC); Legend("Turun", DownC); Legend("Datar", FlatC) }
                        }
                        when {
                            res != null -> PaceChart(res, p.stats.prof, showKm)
                            p.stats.hasEle -> { ElevChart(p.stats.prof); DCaption("Atur target waktu lewat tombol pengaturan untuk melihat pace per ruas.") }
                            else -> DCaption("Tanpa data elevasi, hanya jalur yang dikirim.")
                        }
                    }
                }

                // Bisa digulir: data di bawah panel peta.
                Column(
                    Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    EvMetricRow(
                        listOf(
                            "Jarak" to "${Js.fmtKm(p.km)} km",
                            "Naik" to if (p.stats.hasEle) "+${Js.idn(p.stats.up)} m" else "–",
                            "Turun" to if (p.stats.hasEle) "−${Js.idn(p.stats.down)} m" else "–",
                        ),
                    )
                    val ele = if (p.stats.hasEle) "Elevasi ${Js.idn(Js.roundI(p.stats.min ?: 0.0))}–${Js.idn(Js.roundI(p.stats.max ?: 0.0))} m · " else ""
                    val thin = if (p.total > p.sent) "${p.sent} dari ${p.total} titik dikirim" else "${p.sent} titik dikirim"
                    DCaption(ele + thin + if (p.stats.hasEle) "" else ". Tanpa data elevasi, hanya jalur yang dikirim.")

                    EvPanel(Modifier.fillMaxWidth()) {
                        Row(
                            Modifier.fillMaxWidth().padding(start = 12.dp, top = 4.dp, bottom = 4.dp, end = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text("Strategi pacing", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                DCaption(if (target.isEmpty()) "Belum diatur · opsional" else "$target · ${stratLabel(strat)} · ${surfLabel(surf)}")
                            }
                            IconButton(onClick = { settingsOpen = true }) { Icon(Icons.Filled.Tune, contentDescription = "Atur strategi pacing") }
                        }
                    }
                    when {
                        target.isEmpty() -> DCaption(CourseStrategy.errText("waktu"))
                        res == null -> DCaption(CourseStrategy.errText(outcome?.err))
                        else -> PacingResult(res)
                    }
                }

                // Terpaku: tombol kirim.
                HorizontalDivider()
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Row(
                        Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).clickable(enabled = res != null) { sendPace = !sendPace },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(checked = sendPace && res != null, onCheckedChange = { sendPace = it }, enabled = res != null)
                        Column {
                            Text("Kirim juga pace", style = MaterialTheme.typography.bodyMedium)
                            DCaption(if (res == null) "Atur target waktu dulu" else "Sesi latihan, ±5%")
                        }
                    }
                    TextButton(onClick = onDismiss) { Text("Batal") }
                    Button(onClick = { onSend(if (sendPace) res else null) }) { Text("Kirim ke jam") }
                }
            }
        }
    }

    if (settingsOpen) {
        ModalBottomSheet(onDismissRequest = { settingsOpen = false }, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 16.dp).navigationBarsPadding().imePadding(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text("Pengaturan strategi pacing", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = target, onValueChange = { target = GpxRoute.timeFmt(it) }, singleLine = true,
                    label = { Text("Target waktu") }, placeholder = { Text("mis. 5:30:00") },
                    supportingText = { Text("Ketik angka saja: 30000 → 3:00:00") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                )
                Choice("Strategi", listOf("even" to "Rata", "neg" to "Negative split", "cons" to "Hati-hati"), strat) { strat = it }
                Choice("Permukaan turunan", listOf("dry" to "Padat", "norm" to "Biasa", "slip" to "Licin"), surf) { surf = it }
                Button(onClick = { settingsOpen = false }, modifier = Modifier.fillMaxWidth()) { Text("Selesai") }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun Choice(label: String, items: List<Pair<String, String>>, sel: String, onSel: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items.forEach { (k, l) -> FilterChip(selected = sel == k, onClick = { onSel(k) }, label = { Text(l, style = MaterialTheme.typography.labelMedium) }) }
        }
    }
}

/** Proyeksi equirectangular titik rute + jarak kumulatif (km) per titik, dihitung sekali per rute. */
private class MapProj(pts: List<Pt>) {
    val xs: DoubleArray; val ys: DoubleArray; val cum: DoubleArray
    val x0: Double; val x1: Double; val y0: Double; val y1: Double
    init {
        val cosLat = cos(Math.toRadians(pts.sumOf { it.lat } / pts.size))
        xs = DoubleArray(pts.size) { pts[it].lon * cosLat }
        ys = DoubleArray(pts.size) { pts[it].lat }
        cum = DoubleArray(pts.size)
        for (i in 1 until pts.size) cum[i] = cum[i - 1] + ActBuilder.hav(pts[i - 1].lat, pts[i - 1].lon, pts[i].lat, pts[i].lon) / 1000
        x0 = xs.min(); x1 = xs.max(); y0 = ys.min(); y1 = ys.max()
    }
}

/**
 * Peta jalur offline: cubit dua jari untuk zoom, geser untuk menggeser, ketuk dua kali untuk zoom/reset.
 * Penanda km (opsional) menyesuaikan kerapatannya dengan tingkat zoom.
 */
@Composable
private fun RouteMap(p: GpxRoute.Preview, showKm: Boolean, onShowKm: (Boolean) -> Unit, modifier: Modifier = Modifier) {
    val line = Ember
    val halo = MaterialTheme.colorScheme.surface
    val inkArgb = MaterialTheme.colorScheme.onSurface.toArgb()
    var zoom by remember(p) { mutableFloatStateOf(1f) }
    var offset by remember(p) { mutableStateOf(Offset.Zero) }
    val proj = remember(p) { MapProj(p.pts) }
    val paint = remember { Paint().apply { isAntiAlias = true; textAlign = Paint.Align.CENTER; isFakeBoldText = true } }

    Box(modifier.clipToBounds().background(MaterialTheme.colorScheme.surfaceVariant)) {
        Canvas(
            Modifier.fillMaxSize()
                .pointerInput(p) {
                    detectTransformGestures { centroid, pan, z, _ ->
                        val ns = (zoom * z).coerceIn(1f, MAX_ZOOM)
                        val raw = centroid - (centroid - offset) * (ns / zoom) + pan
                        zoom = ns
                        offset = Offset(raw.x.coerceIn(size.width * (1 - ns), 0f), raw.y.coerceIn(size.height * (1 - ns), 0f))
                    }
                }
                .pointerInput(p) {
                    detectTapGestures(onDoubleTap = { pos ->
                        if (zoom > 1.01f) { zoom = 1f; offset = Offset.Zero } else {
                            val ns = 3f
                            val raw = pos - (pos - offset) * (ns / zoom)
                            zoom = ns
                            offset = Offset(raw.x.coerceIn(size.width * (1 - ns), 0f), raw.y.coerceIn(size.height * (1 - ns), 0f))
                        }
                    })
                },
        ) {
            val n = proj.xs.size
            val pad = 16.dp.toPx()
            val sc = min((size.width - 2 * pad) / max(1e-9, proj.x1 - proj.x0), (size.height - 2 * pad) / max(1e-9, proj.y1 - proj.y0))
            val ox = (size.width - (proj.x1 - proj.x0) * sc) / 2; val oy = (size.height - (proj.y1 - proj.y0) * sc) / 2
            val base = List(n) { Offset((ox + (proj.xs[it] - proj.x0) * sc).toFloat(), (size.height - oy - (proj.ys[it] - proj.y0) * sc).toFloat()) }
            fun tr(o: Offset) = o * zoom + offset

            val path = Path()
            var pathPx = 0f
            for (i in 0 until n) {
                val o = tr(base[i]); if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y)
                if (i > 0) { val dx = base[i].x - base[i - 1].x; val dy = base[i].y - base[i - 1].y; pathPx += sqrt(dx * dx + dy * dy) }
            }
            drawPath(path, halo, style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            drawPath(path, line, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))

            val total = proj.cum.last()
            if (showKm && total > 0 && pathPx > 0f) {
                val minStepKm = 44.dp.toPx() / (pathPx * zoom / total)
                val step = listOf(0.5, 1.0, 2.0, 5.0, 10.0, 20.0, 50.0, 100.0).firstOrNull { it >= minStepKm } ?: 100.0
                paint.textSize = 10.sp.toPx(); paint.color = inkArgb
                var k = step; var i = 0
                while (k < total - step * 0.3) {
                    while (i < n - 2 && proj.cum[i + 1] < k) i++
                    val seg = proj.cum[i + 1] - proj.cum[i]
                    val t = if (seg > 0) ((k - proj.cum[i]) / seg).coerceIn(0.0, 1.0).toFloat() else 0f
                    val o = tr(lerp(base[i], base[i + 1], t))
                    if (o.x in -20f..size.width + 20f && o.y in -20f..size.height + 20f) {
                        val label = if (k % 1.0 == 0.0) k.toInt().toString() else Js.fmtKm(k)
                        val r = if (label.length <= 2) 10.dp.toPx() else 13.dp.toPx()
                        drawCircle(halo, r, o)
                        drawCircle(line, r, o, style = Stroke(width = 1.5.dp.toPx()))
                        drawContext.canvas.nativeCanvas.drawText(label, o.x, o.y - (paint.fontMetrics.ascent + paint.fontMetrics.descent) / 2, paint)
                    }
                    k += step
                }
            }
            val s0 = tr(base.first()); val s1 = tr(base.last())
            drawCircle(halo, 7.5.dp.toPx(), s0); drawCircle(Color(0xFF2E9E5B), 5.5.dp.toPx(), s0)
            drawCircle(halo, 7.5.dp.toPx(), s1); drawCircle(Color(0xFFD33F3F), 5.5.dp.toPx(), s1)
        }

        Surface(
            Modifier.align(Alignment.TopEnd).padding(8.dp), shape = RoundedCornerShape(18.dp),
            color = halo.copy(alpha = 0.9f), border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant),
        ) {
            Row(Modifier.padding(start = 12.dp, end = 2.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("Indikator km", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                Switch(checked = showKm, onCheckedChange = onShowKm, modifier = Modifier.scale(0.8f))
            }
        }
        Surface(
            Modifier.align(Alignment.BottomStart).padding(8.dp), shape = RoundedCornerShape(12.dp), color = halo.copy(alpha = 0.9f),
        ) {
            Row(Modifier.padding(horizontal = 10.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Legend("Mulai", Color(0xFF2E9E5B)); Legend("Finis", Color(0xFFD33F3F))
                if (zoom <= 1.01f) Text("Cubit untuk zoom", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (zoom > 1.01f) {
            Surface(
                Modifier.align(Alignment.BottomEnd).padding(8.dp).clickable { zoom = 1f; offset = Offset.Zero },
                shape = RoundedCornerShape(12.dp), color = halo.copy(alpha = 0.9f),
            ) {
                Text("Reset · ${Js.n(Js.round(zoom * 10.0) / 10)}×", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
            }
        }
    }
}

/** Profil elevasi polos (dipakai selagi strategi pacing belum diisi). */
@Composable
private fun ElevChart(prof: List<DoubleArray>) {
    if (prof.size < 2) return
    Canvas(Modifier.fillMaxWidth().height(64.dp)) {
        val w = size.width; val h = size.height
        var lo = Double.MAX_VALUE; var hi = -Double.MAX_VALUE
        prof.forEach { lo = min(lo, it[1]); hi = max(hi, it[1]) }
        val rg = if (hi - lo > 0) hi - lo else 1.0
        val pk = prof.last()[0].let { if (it > 0) it else 1.0 }
        fun x(k: Double) = (k / pk * w).toFloat()
        fun y(e: Double) = (h - 4.dp.toPx() - (e - lo) / rg * (h - 8.dp.toPx())).toFloat()
        val fill = Path(); fill.moveTo(0f, h)
        prof.forEach { fill.lineTo(x(it[0]), y(it[1])) }
        fill.lineTo(w, h); fill.close()
        drawPath(fill, Ember.copy(alpha = 0.3f))
        val ln = Path(); prof.forEachIndexed { i, q -> if (i == 0) ln.moveTo(x(q[0]), y(q[1])) else ln.lineTo(x(q[0]), y(q[1])) }
        drawPath(ln, Ember, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** Bagian bawah (bisa digulir): ringkasan, catatan penting, dan kartu pace per ruas. Grafiknya ada di panel terpaku. */
@Composable
private fun PacingResult(r: CourseStrategy.Result) {
    var allNotes by remember(r) { mutableStateOf(false) }
    val notes = remember(r) { CourseStrategy.summary(r) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
            Column {
                Text(Js.durStr(r.tp), style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                DCaption("target waktu")
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("${Js.paceStr(r.tp / r.km)} /km", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                DCaption("pace rata-rata")
            }
        }
        val shown = if (allNotes) notes else notes.take(3)
        shown.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
        if (notes.size > 3) {
            Text(
                if (allNotes) "Tampilkan lebih sedikit" else "Semua catatan (${notes.size - 3} lagi)",
                style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.clickable { allNotes = !allNotes },
            )
        }
        HorizontalDivider()
        Text("Pace per ruas · ${r.segs.size} ruas", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        DCaption("Ketuk ruas untuk melihat arahannya.")
        r.segs.forEach { SegRow(it, r) }
        DCaption("Dihitung dari profil elevasi (usaha setara, GAP Minetti). Rute dikirim ke jam; pace ikut terkirim sebagai sesi latihan bila \"Kirim juga pace\" dicentang.")
    }
}

@Composable
private fun Legend(t: String, c: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        Box(Modifier.width(8.dp).height(8.dp).clip(RoundedCornerShape(2.dp)).background(c))
        Text(t, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Satu baris ruas: jarak + medan di kiri, pace + waktu kumulatif di kanan; ketuk untuk arahan. */
@Composable
private fun SegRow(s: CourseStrategy.Seg, r: CourseStrategy.Result) {
    var open by remember(s) { mutableStateOf(false) }
    val gain = if (s.type == "up") " · +${Js.roundI(s.gain)} m" else if (s.type == "down") " · −${Js.roundI(s.loss)} m" else ""
    val range = s.pr?.let { " · ≈ ${Js.paceStr(it[0])}–${Js.paceStr(it[1])}" } ?: ""
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable { open = !open },
    ) {
        Box(Modifier.width(4.dp).fillMaxHeight().background(segColor(s.type)))
        Column(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("km ${Js.fmtKm(s.from)}–${Js.fmtKm(s.to)}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "${segIcon(s.type)} ${pct(s.g)}$gain · ${CourseStrategy.segLabel(s)}$range",
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(Js.paceStr(s.pace), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("→ ${Js.durStr(s.eta)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (open) Text(CourseStrategy.tip(s, r), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

/** Profil elevasi diwarnai per ruas, di bawahnya batang pace per ruas (makin tinggi = makin lambat) dan sumbu km opsional. */
@Composable
private fun PaceChart(r: CourseStrategy.Result, prof: List<DoubleArray>, showKm: Boolean) {
    if (r.segs.isEmpty() || prof.size < 2) return
    val axis = MaterialTheme.colorScheme.outlineVariant
    val axisTxt = MaterialTheme.colorScheme.onSurfaceVariant.toArgb()
    val paint = remember { Paint().apply { isAntiAlias = true; textAlign = Paint.Align.CENTER } }
    Canvas(Modifier.fillMaxWidth().height(if (showKm) 128.dp else 114.dp)) {
        val w = size.width; val h = size.height
        val axH = if (showKm) 14.dp.toPx() else 0f
        val eT = 4.dp.toPx(); val eB = (h - axH) * 0.5f; val pT = (h - axH) * 0.6f; val pB = h - axH
        val km = r.km
        var lo = Double.MAX_VALUE; var hi = -Double.MAX_VALUE
        prof.forEach { lo = min(lo, it[1]); hi = max(hi, it[1]) }
        val rg = if (hi - lo > 0) hi - lo else 1.0
        val pk = prof.last()[0].let { if (it > 0) it else 1.0 }
        fun x(k: Double) = (k / km * w).toFloat()
        fun y(e: Double) = (eB - (e - lo) / rg * (eB - eT)).toFloat()
        val paces = r.segs.map { it.pace }; val pmin = paces.min(); val pr2 = (paces.max() - pmin).let { if (it > 0) it else 1.0 }
        val minB = 16.dp.toPx()
        paint.isFakeBoldText = true; paint.textSize = 9.sp.toPx(); paint.color = 0xFF16130F.toInt()
        r.segs.forEach { s ->
            val col = segColor(s.type)
            var pts = prof.filter { it[0] / pk * km >= s.from - 1e-6 && it[0] / pk * km <= s.to + 1e-6 }
            if (pts.size < 2) {
                val mid = (s.from + s.to) / 2
                val m = prof.minByOrNull { abs(it[0] / pk * km - mid) }!!
                pts = listOf(doubleArrayOf(s.from / km * pk, m[1]), doubleArrayOf(s.to / km * pk, m[1]))
            }
            val path = Path()
            path.moveTo(x(s.from), eB)
            pts.forEach { path.lineTo(x(it[0] / pk * km), y(it[1])) }
            path.lineTo(x(s.to), eB); path.close()
            drawPath(path, col.copy(alpha = 0.55f))
            val bh = minB + ((s.pace - pmin) / pr2).toFloat() * (pB - pT - minB)
            val bw = max(1f, x(s.to) - x(s.from) - 2f)
            drawRect(col.copy(alpha = 0.85f), Offset(x(s.from) + 1f, pB - bh), Size(bw, bh))
            if (bw >= 30.dp.toPx()) {
                drawContext.canvas.nativeCanvas.drawText(Js.paceStr(s.pace), x(s.from) + 1f + bw / 2, pB - bh / 2 - (paint.fontMetrics.ascent + paint.fontMetrics.descent) / 2, paint)
            }
        }
        drawLine(axis, Offset(0f, eB), Offset(w, eB))
        if (showKm) {
            paint.isFakeBoldText = false; paint.color = axisTxt
            val step = listOf(1.0, 2.0, 5.0, 10.0, 20.0, 50.0, 100.0).first { km / it <= 5.0 }
            var k = 0.0
            while (k <= km + 1e-6) {
                val label = if (k % 1.0 == 0.0) k.toInt().toString() else Js.fmtKm(k)
                val tw = paint.measureText(label)
                drawContext.canvas.nativeCanvas.drawText(label, x(k).coerceIn(tw / 2, w - tw / 2), h - 2.dp.toPx(), paint)
                k += step
            }
        }
    }
}
