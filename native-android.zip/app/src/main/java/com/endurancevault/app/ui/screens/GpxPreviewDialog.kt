package com.endurancevault.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.endurancevault.app.domain.CourseStrategy
import com.endurancevault.app.domain.GpxRoute
import com.endurancevault.app.domain.Js
import com.endurancevault.app.ui.theme.Ember
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min

private val UpC = Color(0xFFC4431B)
private val DownC = Color(0xFF2F6FD0)
private val FlatC = Color(0xFF8A8F98)
private fun segColor(type: String) = when (type) { "up" -> UpC; "down" -> DownC; else -> FlatC }
private fun segIcon(type: String) = when (type) { "up" -> "▲"; "down" -> "▼"; else -> "▬" }
private fun pct(g: Double) = Js.n(Js.round(abs(g) * 1000) / 10).replace('.', ',') + "%"

/**
 * Dialog kirim rute GPX ke jam: ringkasan rute di atas, strategi pacing (opsional, tertutup) di bawah.
 * Padanan "Preview rute GPX" di versi web, disusun ulang agar ringkas di layar HP.
 */
@Composable
internal fun GpxPreviewDialog(p: GpxRoute.Preview, onSend: () -> Unit, onDismiss: () -> Unit) {
    var target by remember(p) { mutableStateOf("") }
    var strat by remember(p) { mutableStateOf("even") }
    var surf by remember(p) { mutableStateOf("dry") }
    var pacingOpen by remember(p) { mutableStateOf(false) }
    val outcome = remember(p, target, strat, surf) {
        if (target.isEmpty()) null else CourseStrategy.pacing(p.pts, target, strat, surf)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("Kirim rute ke jam")
                Text(p.name, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                EvPanel(Modifier.fillMaxWidth()) { RouteSketch(p) }
                EvMetricRow(
                    listOf(
                        "Jarak" to "${Js.fmtKm(p.km)} km",
                        "Naik" to if (p.stats.hasEle) "+${Js.idn(p.stats.up)} m" else "–",
                        "Turun" to if (p.stats.hasEle) "−${Js.idn(p.stats.down)} m" else "–",
                    ),
                )
                val ele = if (p.stats.hasEle) "Elevasi ${Js.idn(Js.roundI(p.stats.min ?: 0.0))}–${Js.idn(Js.roundI(p.stats.max ?: 0.0))} m · " else ""
                val thin = if (p.total > p.sent) "${p.sent} dari ${p.total} titik dikirim" else "${p.sent} titik dikirim"
                DCaption(ele + thin + if (p.stats.hasEle) "" else ". Tanpa data elevasi, hanya jalur yang dikirim.")

                EvPanel(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            Modifier.fillMaxWidth().clickable { pacingOpen = !pacingOpen },
                            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text("Strategi pacing", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                if (!pacingOpen) DCaption("Opsional · pace per ruas tanjakan, turunan, dan datar")
                            }
                            Text(if (pacingOpen) "▲" else "▼", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (pacingOpen) {
                            OutlinedTextField(
                                value = target, onValueChange = { target = GpxRoute.timeFmt(it) }, singleLine = true,
                                label = { Text("Target waktu") }, placeholder = { Text("mis. 5:30:00") },
                                supportingText = { Text("Ketik angka saja: 30000 → 3:00:00") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth(),
                            )
                            Choice("Strategi", listOf("even" to "Rata", "neg" to "Negative split", "cons" to "Hati-hati"), strat) { strat = it }
                            Choice("Permukaan turunan", listOf("dry" to "Padat", "norm" to "Biasa", "slip" to "Licin"), surf) { surf = it }
                            val res = outcome?.result
                            when {
                                target.isEmpty() -> DCaption(CourseStrategy.errText("waktu"))
                                res == null -> DCaption(CourseStrategy.errText(outcome?.err))
                                else -> PacingResult(res, p.stats.prof)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onSend) { Text("Kirim ke jam") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun Choice(label: String, items: List<Pair<String, String>>, sel: String, onSel: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items.forEach { (k, l) -> FilterChip(selected = sel == k, onClick = { onSel(k) }, label = { Text(l, style = MaterialTheme.typography.labelMedium) }) }
        }
    }
}

/** Sketsa jalur offline (proyeksi equirectangular): mulai hijau, finis merah. */
@Composable
private fun RouteSketch(p: GpxRoute.Preview) {
    val line = Ember
    val edge = MaterialTheme.colorScheme.surface
    Canvas(Modifier.fillMaxWidth().height(120.dp)) {
        val pts = p.pts
        val cosLat = cos(Math.toRadians(pts.sumOf { it.lat } / pts.size))
        val xs = pts.map { it.lon * cosLat }; val ys = pts.map { it.lat }
        val x0 = xs.min(); val x1 = xs.max(); val y0 = ys.min(); val y1 = ys.max()
        val pad = 12.dp.toPx()
        val sc = min((size.width - 2 * pad) / max(1e-9, x1 - x0), (size.height - 2 * pad) / max(1e-9, y1 - y0))
        val ox = (size.width - (x1 - x0) * sc) / 2; val oy = (size.height - (y1 - y0) * sc) / 2
        fun pt(i: Int) = Offset((ox + (xs[i] - x0) * sc).toFloat(), (size.height - oy - (ys[i] - y0) * sc).toFloat())
        val path = Path()
        for (i in pts.indices) { val o = pt(i); if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y) }
        drawPath(path, edge, style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawPath(path, line, style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawCircle(Color(0xFF2E9E5B), 4.5.dp.toPx(), pt(0))
        drawCircle(Color(0xFFD33F3F), 4.5.dp.toPx(), pt(pts.size - 1))
    }
}

@Composable
private fun PacingResult(r: CourseStrategy.Result, prof: List<DoubleArray>) {
    var allNotes by remember(r) { mutableStateOf(false) }
    val notes = remember(r) { CourseStrategy.summary(r) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        HorizontalDivider()
        // ringkasan satu baris
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
            Column {
                Text(Js.durStr(r.tp), style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                DCaption("target waktu")
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("${Js.paceStr(r.tp / r.km)} /km", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                DCaption("pace rata-rata")
            }
        }
        PaceChart(r, prof)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            DCaption("0 km")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Legend("Naik", UpC); Legend("Turun", DownC); Legend("Datar", FlatC) }
            DCaption("${Js.fmtKm(r.km)} km")
        }

        // catatan penting: 3 teratas, sisanya dilipat
        val shown = if (allNotes) notes else notes.take(3)
        shown.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
        if (notes.size > 3) {
            Text(
                if (allNotes) "Tampilkan lebih sedikit" else "Semua catatan (${notes.size - 3} lagi)",
                style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.clickable { allNotes = !allNotes },
            )
        }

        HorizontalDivider()
        Text("Pace per ruas · ${r.segs.size} ruas", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        DCaption("Ketuk ruas untuk melihat arahannya.")
        r.segs.forEach { SegRow(it, r) }
        DCaption("Panduan saja: dihitung dari profil elevasi (usaha setara, GAP Minetti). Yang dikirim ke jam tetap hanya jalur dan elevasi.")
    }
}

@Composable
private fun Legend(t: String, c: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        Box(Modifier.width(8.dp).height(8.dp).clip(RoundedCornerShape(2.dp)).background(c))
        Text(t, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Satu baris ruas: jarak + medan di kiri, pace + waktu kumulatif di kanan; ketuk untuk arahan. */
@Composable
private fun SegRow(s: CourseStrategy.Seg, r: CourseStrategy.Result) {
    var open by remember(s) { mutableStateOf(false) }
    val gain = if (s.type == "up") " · +${Js.roundI(s.gain)} m" else if (s.type == "down") " · −${Js.roundI(s.loss)} m" else ""
    val range = s.pr?.let { " · ≈ ${Js.paceStr(it[0])}–${Js.paceStr(it[1])}" } ?: ""
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable { open = !open },
    ) {
        Box(Modifier.width(4.dp).fillMaxHeight().background(segColor(s.type)))
        Column(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("km ${Js.fmtKm(s.from)}–${Js.fmtKm(s.to)}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "${segIcon(s.type)} ${pct(s.g)}$gain · ${CourseStrategy.segLabel(s)}$range",
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(Js.paceStr(s.pace), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("→ ${Js.durStr(s.eta)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (open) Text(CourseStrategy.tip(s, r), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

/** Profil elevasi diwarnai per ruas, di bawahnya batang pace per ruas (makin tinggi = makin lambat). */
@Composable
private fun PaceChart(r: CourseStrategy.Result, prof: List<DoubleArray>) {
    if (r.segs.isEmpty() || prof.size < 2) return
    val axis = MaterialTheme.colorScheme.outlineVariant
    Canvas(Modifier.fillMaxWidth().height(116.dp)) {
        val w = size.width; val h = size.height
        val eT = 4.dp.toPx(); val eB = h * 0.52f; val pT = h * 0.62f; val pB = h
        val km = r.km
        var lo = Double.MAX_VALUE; var hi = -Double.MAX_VALUE
        prof.forEach { lo = min(lo, it[1]); hi = max(hi, it[1]) }
        val rg = if (hi - lo > 0) hi - lo else 1.0
        val pk = prof.last()[0].let { if (it > 0) it else 1.0 }
        fun x(k: Double) = (k / km * w).toFloat()
        fun y(e: Double) = (eB - (e - lo) / rg * (eB - eT)).toFloat()
        val paces = r.segs.map { it.pace }; val pmin = paces.min(); val pr2 = (paces.max() - pmin).let { if (it > 0) it else 1.0 }
        r.segs.forEach { s ->
            val col = segColor(s.type)
            var pts = prof.filter { it[0] / pk * km >= s.from - 1e-6 && it[0] / pk * km <= s.to + 1e-6 }
            if (pts.size < 2) {
                val mid = (s.from + s.to) / 2
                val m = prof.minByOrNull { abs(it[0] / pk * km - mid) }!!
                pts = listOf(doubleArrayOf(s.from / km * pk, m[1]), doubleArrayOf(s.to / km * pk, m[1]))
            }
            val path = Path()
            path.moveTo(x(s.from), eB)
            pts.forEach { path.lineTo(x(it[0] / pk * km), y(it[1])) }
            path.lineTo(x(s.to), eB); path.close()
            drawPath(path, col.copy(alpha = 0.55f))
            val bh = 6.dp.toPx() + ((s.pace - pmin) / pr2).toFloat() * (pB - pT - 6.dp.toPx())
            drawRect(col.copy(alpha = 0.85f), Offset(x(s.from) + 1f, pB - bh), Size(max(1f, x(s.to) - x(s.from) - 2f), bh))
        }
        drawLine(axis, Offset(0f, eB), Offset(w, eB))
    }
}
