package com.endurancevault.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.domain.StructuredWorkout
import com.endurancevault.app.domain.ZoneLogCheck
import com.endurancevault.app.domain.Zones
import com.endurancevault.app.ui.i18n.Text
import com.rencanalari.huaweiwatch.ProtocolBridge

/** Tombol "Cek LTHR yang terkirim": membaca log protokol dan membandingkan zona terakhir yang dikirim dengan zona LTHR di app. */
@Composable
fun ZoneLogCheckPanel(settings: PlanSettings) {
    val context = LocalContext.current
    var report by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedButton(
            onClick = {
                report = runCatching {
                    val arr = ProtocolBridge.get(context).log(0).getJSONArray("lines")
                    val lines = List(arr.length()) { arr.getJSONObject(it).getString("text") }
                    // Selalu bandingkan dengan zona LTHR app, juga bila mode zona sedang HRR.
                    val cuts = Zones.cuts(settings.copy(zm = "lthr"))
                    ZoneLogCheck.report(
                        lines, cuts.lthr ?: 0,
                        StructuredWorkout.watchLowerBounds("lthr", cuts.lo, cuts.maxHr),
                        manual = (settings.lthr ?: 0.0) >= 100,
                    )
                }.getOrElse { "Log protokol tidak bisa dibaca: ${it.message ?: it.javaClass.simpleName}" }
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Cek LTHR yang terkirim ke jam (log)") }
        report?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}
