package com.endurancevault.app.ui.screens

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.data.TerrainBuilder
import com.endurancevault.app.data.TerrainScene
import com.endurancevault.app.domain.ActDetail
import com.endurancevault.app.domain.RouteVideoFormat
import com.endurancevault.app.domain.RouteVideoText
import com.endurancevault.app.domain.RouteVideoTrack
import com.endurancevault.app.domain.TrailData
import com.endurancevault.app.domain.TrailKeys
import com.endurancevault.app.domain.TrailPrefs
import com.endurancevault.app.domain.TrailTimeline
import com.endurancevault.app.domain.Zones
import com.endurancevault.app.ui.UiState
import com.endurancevault.app.ui.i18n.Text
import com.endurancevault.app.ui.sticker.StickerFontStore
import com.endurancevault.app.ui.sticker.StickerFonts
import com.endurancevault.app.ui.sticker.StickerPrefsStore
import com.endurancevault.app.ui.video.RouteVideoEncoder
import com.endurancevault.app.ui.video.RouteVideoIo
import com.endurancevault.app.ui.video.RouteVideoJobs
import com.endurancevault.app.ui.video.TrailEncoder
import com.endurancevault.app.ui.video.TrailPrefsStore
import com.endurancevault.app.ui.video.TrailPreviewHost
import com.endurancevault.app.ui.video.TrailRig
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

private val TV_ACCENTS = listOf("Oranye" to "#FF6A13", "Lime" to "#CBFD00", "Cyan" to "#27D3FF", "Merah" to "#FF3B4E", "Kuning" to "#FFD60A", "Putih" to "#FFFFFF")
private val TV_BG_COLORS = listOf("Arang" to "#14100E", "Hitam" to "#000000", "Biru malam" to "#0B1626", "Hijau tua" to "#0C1A12", "Putih" to "#F4F1EA")

/**
 * Video Trail 3D: kartu bergaya trail dengan slab medan 3D (lingkaran atau poligon) yang berputar, latar pegunungan senja atau
 * foto sendiri, profil elevasi yang terisi seiring lari (zona HR, tanjakan, puncak), tanda km, dan panel data dengan empat layout.
 * Render berjalan di latar belakang dengan notifikasi progres.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TrailVideoScreen(state: UiState, id: Long, load: suspend (ActivityEntity) -> ActDetail?, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val appCtx = ctx.applicationContext
    val scope = rememberCoroutineScope()
    val store = remember { TrailPrefsStore(appCtx) }
    var prefs by remember { mutableStateOf(store.load()) }
    fun update(p: TrailPrefs) { prefs = p.sanitized(); store.save(prefs) }

    val host = remember { TrailPreviewHost() }
    DisposableEffect(Unit) { onDispose { host.close() } }
    val stk = remember { StickerPrefsStore(appCtx).load() }
    val fontStore = remember { StickerFontStore(appCtx) }
    val fonts = remember(stk.fontNum, stk.fontBody) { StickerFonts(fontStore.typeface(stk.fontNum), fontStore.typeface(stk.fontBody)) }

    var pos by remember { mutableStateOf(0.55f) }
    var status by remember { mutableStateOf("Menyiapkan medan…") }
    var photo by remember { mutableStateOf<Bitmap?>(null) }
    var msg by remember { mutableStateOf("") }
    var stilling by remember { mutableStateOf(false) }
    var stillFile by remember { mutableStateOf<File?>(null) }
    // Pratinjau hidup: loop di bawah membuat bingkai terus-menerus saat playing; pos tetap posisi pratinjau diam.
    var playing by remember { mutableStateOf(false) }
    var livePos by remember { mutableStateOf(0f) }
    var liveFrame by remember { mutableStateOf<Bitmap?>(null) }
    var liveErr by remember { mutableStateOf<String?>(null) }

    val e = state.activities.firstOrNull { it.id == id }
    fun nameOf(a: ActivityEntity) = a.name.ifBlank { if (a.type == "bike") "Gowes" else "Lari" }

    val loaded by produceState<Pair<Boolean, ActDetail?>>(false to null, e?.id, e?.detailFile, e?.km, e?.durationSec, e?.type) {
        value = true to e?.let { load(it) }
    }
    val track = remember(loaded.second, e?.name) {
        val d = loaded.second
        if (e != null && d != null) RouteVideoTrack.from(d, nameOf(e), RouteVideoText.dateId(e.dateIso)) else null
    }
    val hrLo = remember(state.settings, state.daily) {
        runCatching { Zones.cuts(state.settings, restHrFrom(state.daily).first).lo }.getOrNull()
    }
    val data = remember(track, loaded.second, hrLo) { track?.let { TrailData(it, loaded.second?.weather, hrLo) } }

    val sceneRes by produceState<Pair<RouteVideoTrack?, TerrainScene?>>(null to null, track) {
        val t = track
        value = if (t == null) null to null else t to TerrainBuilder.buildTrail(appCtx, t) { status = it }
    }
    val scene = if (track != null && sceneRes.first === track) sceneRes.second else null
    val sceneLoading = track != null && sceneRes.first !== track

    val (pw, ph) = RouteVideoFormat.previewSize(prefs.aspect)
    val frameRes by produceState<Pair<Bitmap?, String?>>(null to null, scene, data, prefs, pos, photo, playing) {
        if (playing) return@produceState // bingkai dibuat loop pratinjau hidup
        val sc = scene; val d = data
        if (sc == null || d == null) value = null to null
        else {
            val pr = prefs; val ps = pos.toDouble(); val bg = photo
            val key = listOf<Any?>(pr.copy(bgRender = false, quality = "hd"), System.identityHashCode(sc), System.identityHashCode(bg), System.identityHashCode(d))
            value = withContext(host.dispatcher) {
                val r = runCatching {
                    host.frame(pw, ph, key, pr, ps) { TrailRig(pw, ph, pr, d, sc, fonts, bg, d.track.title, d.track.dateText) }
                }
                if (r.isSuccess) Pair<Bitmap?, String?>(r.getOrNull(), null)
                else Pair<Bitmap?, String?>(null, r.exceptionOrNull()?.message ?: "OpenGL gagal")
            }
        }
    }

    // Setelah jeda, bingkai hidup terakhir tetap tampil sampai bingkai diam baru (pada posisi jeda) selesai dibuat.
    var settleFrom by remember { mutableStateOf<Bitmap?>(null) }
    fun pause(at: Float) { settleFrom = frameRes.first; pos = at; playing = false }

    // Loop pratinjau hidup: membaca pengaturan terbaru tiap bingkai, jadi mengubah slider atau chip saat memutar langsung terlihat.
    val prefsRef = rememberUpdatedState(prefs)
    val photoRef = rememberUpdatedState(photo)
    val fontsRef = rememberUpdatedState(fonts)
    LaunchedEffect(playing, scene, data) {
        val sc = scene; val d = data
        if (!playing || sc == null || d == null) return@LaunchedEffect
        liveErr = null
        runPreviewLoop(livePos, { TrailTimeline.total(prefsRef.value) }) { f ->
            livePos = f.toFloat()
            val pr = prefsRef.value; val bg = photoRef.value; val fnt = fontsRef.value
            val (w, h) = RouteVideoFormat.previewSize(pr.aspect)
            val key = listOf<Any?>(pr.copy(bgRender = false, quality = "hd"), System.identityHashCode(sc), System.identityHashCode(bg), System.identityHashCode(d))
            val res = withContext(host.dispatcher) {
                runCatching { host.frame(w, h, key, pr, f) { TrailRig(w, h, pr, d, sc, fnt, bg, d.track.title, d.track.dateText) } }
            }
            res.getOrNull()?.let { liveFrame = it }
            if (res.isFailure) { liveErr = res.exceptionOrNull()?.message ?: "OpenGL gagal"; pause(livePos) }
            res.isSuccess
        }
    }
    PauseOnBackground { if (playing) pause(livePos) }

    val myKey = "trail-$id"
    val outSize = RouteVideoFormat.size(prefs.aspect, prefs.quality)
    val sizeLabel = outSize.first.toString() + "×" + outSize.second
    val bgRef = rememberUpdatedState(prefs.bgRender)
    DisposableEffect(Unit) { onDispose { if (!bgRef.value) RouteVideoJobs.cancelFor(myKey) } }
    val startRender = {
        val a = e; val d = data; val sc = scene
        if (a != null && d != null && sc != null) {
            RouteVideoJobs.clearResult()
            val out = File(RouteVideoIo.cacheDir(appCtx), "trail-${a.dateIso.take(10)}-${a.id}.mp4")
            val snap = prefs; val bg = photo
            val started = RouteVideoJobs.startTask(appCtx, myKey, nameOf(a), out, snap.bgRender) { active, prog ->
                TrailEncoder.encode(sc, d, snap, fonts, bg, d.track.title, d.track.dateText, out, active, prog)
            }
            msg = if (started) "" else "Masih ada render lain yang berjalan."
        }
    }

    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            val b = withContext(Dispatchers.IO) { decodePhoto(appCtx, uri) }
            if (b != null) { photo = b; update(prefs.copy(bgMode = "photo")); msg = "" } else msg = "Foto tidak bisa dibuka."
        }
    }

    Column(
        Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton(onClick = onBack) { Text("‹ Kembali") }
            Text("Video Trail 3D", style = MaterialTheme.typography.titleMedium)
        }
        if (e == null) { Text("Aktivitas tidak ditemukan."); return@Column }
        if (!loaded.first) { CircularProgressIndicator(Modifier.size(24.dp)); return@Column }
        if (track == null || data == null) {
            Text("Video Trail butuh rute GPS dan data per detik. Aktivitas ini tidak punya keduanya (mis. latihan indoor atau data lama).")
            return@Column
        }
        if (scene == null) {
            if (sceneLoading) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(22.dp)); Text(status)
                }
            } else Text("Medan 3D gagal disiapkan. Coba lagi saat tersambung internet.")
            return@Column
        }

        BoxWithConstraints(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            val ratio = RouteVideoFormat.ratio(prefs.aspect)
            val maxH = (LocalConfiguration.current.screenHeightDp * 0.38f).dp
            val w = minOf(maxWidth, maxH * ratio)
            Box(Modifier.width(w).aspectRatio(ratio).clip(RoundedCornerShape(12.dp)).background(Color.Black), contentAlignment = Alignment.Center) {
                val b = if (playing || frameRes.first === settleFrom) liveFrame ?: frameRes.first else frameRes.first
                if (b == null) { if (frameRes.second == null) CircularProgressIndicator(Modifier.size(28.dp)) }
                else Image(b.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
            }
        }
        val shownPos = if (playing) livePos else pos
        PreviewControls(
            "Posisi pratinjau (waktu video)", shownPos, 0f..1f, "${(shownPos * TrailTimeline.total(prefs)).roundToInt()} dtk", playing,
            onToggle = {
                if (playing) pause(livePos)
                else { livePos = if (pos >= 0.995f) 0f else pos; settleFrom = null; liveFrame = frameRes.first; playing = true }
            },
            onSeek = { if (playing) pause(it) else pos = it },
        )

        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            if (!scene.demOk) VuNote("Data elevasi belum terunduh (offline?), jadi medan tampil datar. Buka lagi saat online.")
            if (!track.hasEle) VuNote("Aktivitas ini tidak punya data elevasi, jadi grafik dan tanjakan tidak tampil.")
            (frameRes.second ?: liveErr)?.let { VuNote("Pratinjau 3D gagal: $it") }

            VideoRenderPanel(myKey, "Buat video ($sizeLabel)", true, prefs.bgRender) { startRender() }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(enabled = !stilling, onClick = {
                    val a = e; val d = data; val sc = scene
                    if (a != null && d != null && sc != null) scope.launch {
                        stilling = true; stillFile = null
                        try {
                            val posNow = pos.toDouble(); val snap = prefs; val bg = photo
                            val name = "foto-trail-${a.dateIso.take(10)}-${a.id}-${(posNow * 100).roundToInt()}.jpg"
                            val r = withContext(host.dispatcher) {
                                TrailEncoder.renderStill(sc, d, snap, fonts, bg, d.track.title, d.track.dateText, posNow)
                                    .map { bmp -> val f = RouteVideoIo.writePhoto(appCtx, bmp, name); bmp.recycle(); f }
                            }
                            r.onSuccess { stillFile = it; msg = "Foto siap." }.onFailure { msg = "Gagal membuat foto: ${it.message}" }
                        } finally { stilling = false }
                    }
                }) { Text(if (stilling) "Membuat foto…" else "Foto bingkai ini") }
                val sf = stillFile
                if (sf != null) {
                    OutlinedButton(onClick = {
                        RouteVideoIo.savePhotoToGallery(appCtx, sf, sf.name).onSuccess { msg = "Tersimpan di $it." }.onFailure { msg = "Gagal menyimpan: ${it.message}" }
                    }) { Text("Simpan foto") }
                    OutlinedButton(onClick = { RouteVideoIo.share(ctx, sf, "Bagikan foto", "image/jpeg").onFailure { msg = "Gagal membagikan: ${it.message}" } }) { Text("Bagikan foto") }
                }
            }
            if (msg.isNotEmpty()) VuInfo(msg)
            VuToggle("Lanjut di latar belakang (notifikasi)", prefs.bgRender) { update(prefs.copy(bgRender = it)) }
            if (!prefs.bgRender) VuInfo("Mati: render berhenti bila layar ini ditutup dan tidak ada notifikasi progres.")

            VuSection("Teks", "Judul memakai nama aktivitas. Lokasi dan akun tampil di header kartu.") {
                OutlinedTextField(
                    value = prefs.location, onValueChange = { update(prefs.copy(location = it.take(60))) },
                    label = { Text("Lokasi / nama event") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = prefs.handle, onValueChange = { update(prefs.copy(handle = it.take(30))) },
                    label = { Text("Akun (mis. @namamu)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                VuToggle("Tampilkan cuaca", prefs.showWeather) { update(prefs.copy(showWeather = it)) }
            }

            VuSection("Panel data", "Empat susunan siap pakai. Bar progres dan baris tambahan (VAM/GAP, cadence, naik) bisa dimatikan.") {
                VuChips(TrailKeys.LAYOUTS.map { it to TrailKeys.layoutName(it) }, prefs.layout) { update(prefs.copy(layout = it)) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    VuToggle("Bar progres", prefs.showBar) { update(prefs.copy(showBar = it)) }
                    VuToggle("Baris tambahan", prefs.extraRow) { update(prefs.copy(extraRow = it)) }
                }
                VuToggle("Data otomatis (pace, denyut, naik, waktu)", prefs.autoMetrics) { update(prefs.copy(autoMetrics = it)) }
                if (!prefs.autoMetrics) {
                    VuLabel("Pilih sampai 4 data (urutan sesuai pilihan)")
                    VuMetricChips(prefs.metrics) { update(prefs.copy(metrics = it)) }
                }
                VuLabel("Kartu di belakang data")
                VuChips(TrailKeys.CARDS.map { it to TrailKeys.cardName(it) }, prefs.card) { update(prefs.copy(card = it)) }
                VuToggle("Kartu otomatis bila latar terang", prefs.autoContrast) { update(prefs.copy(autoContrast = it)) }
                VuToggle("Aman dari kolom balas Story (9:16)", prefs.safeZone) { update(prefs.copy(safeZone = it)) }
            }

            VuSection("Penanda", "Yang tampil di slab dan grafik elevasi.") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    VuToggle("Penanda km", prefs.showKm) { update(prefs.copy(showKm = it)) }
                    VuToggle("Puncak", prefs.showPeak) { update(prefs.copy(showPeak = it)) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    VuToggle("Tanjakan", prefs.showClimbs) { update(prefs.copy(showClimbs = it)) }
                    VuToggle("Zona HR", prefs.showZones) { update(prefs.copy(showZones = it)) }
                    VuToggle("Gradien", prefs.showGrade) { update(prefs.copy(showGrade = it)) }
                }
            }

            VuSection("Bentuk dan kamera", "Bentuk slab, kemiringan, tinggi relief, dan putaran.") {
                VuChips(TrailKeys.SHAPES.map { it to TrailKeys.shapeName(it) }, prefs.shape) { update(prefs.copy(shape = it)) }
                VuSlider("Kemiringan dari atas", prefs.tilt.toFloat(), 20f..75f, "${prefs.tilt}°") { update(prefs.copy(tilt = it.roundToInt())) }
                VuSlider("Tinggi relief", prefs.relief.toFloat(), 5f..60f, "${prefs.relief}%") { update(prefs.copy(relief = it.roundToInt())) }
                VuSlider("Sudut awal", prefs.rotation.toFloat(), -180f..180f, "${prefs.rotation}°") { update(prefs.copy(rotation = it.roundToInt())) }
                VuSlider("Putaran selama lari", prefs.spin.toFloat(), -360f..360f, "${prefs.spin}°") { update(prefs.copy(spin = it.roundToInt())) }
            }

            VuSection("Warna", "Palet neon dan aksen sendiri.") {
                VuChips(TrailKeys.PALETTES.map { it to TrailKeys.paletteName(it) }, prefs.palette) { update(prefs.copy(palette = it)) }
                VuColorPick("Warna aksen", prefs.accent, TV_ACCENTS, "Ikut palet") { update(prefs.copy(accent = it)) }
            }

            VuSection("Latar", "Pegunungan senja, langit polos, warna polos, atau fotomu sendiri.") {
                VuChips(TrailKeys.BACKGROUNDS.map { it to TrailKeys.backgroundName(it) }, prefs.bgMode) {
                    if (it == "photo" && photo == null) pickPhoto.launch("image/*") else update(prefs.copy(bgMode = it))
                }
                if (prefs.bgMode == "solid") VuColorPick("Warna latar", prefs.bgColor, TV_BG_COLORS, null) { update(prefs.copy(bgColor = it)) }
                if (prefs.bgMode == "photo") {
                    OutlinedButton(onClick = { pickPhoto.launch("image/*") }) { Text(if (photo == null) "Pilih foto" else "Ganti foto") }
                    VuSlider("Peredam gelap foto", prefs.bgDim.toFloat(), 0f..85f, "${prefs.bgDim}%") { update(prefs.copy(bgDim = it.roundToInt())) }
                    VuInfo("Foto hanya dipakai di layar ini dan tidak disimpan. Pilih lagi bila layar ditutup.")
                }
            }

            VuSection("Linimasa dan format", "Lama rute berjalan, animasi masuk, dan ringkasan di akhir.") {
                VuSlider("Lama lari berjalan", prefs.durationSec.toFloat(), 6f..60f, "${prefs.durationSec} dtk") { update(prefs.copy(durationSec = it.roundToInt())) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    VuToggle("Animasi masuk", prefs.intro) { update(prefs.copy(intro = it)) }
                    VuToggle("Ringkasan akhir", prefs.summary) { update(prefs.copy(summary = it)) }
                }
                VuLabel("Rasio")
                VuChips(RouteVideoFormat.ASPECTS.map { it to it }, prefs.aspect) { update(prefs.copy(aspect = it)) }
                VuLabel("Kualitas")
                VuChips(listOf("hd" to "Penuh (1080)", "sd" to "Ringan (720)"), prefs.quality) { update(prefs.copy(quality = it)) }
            }
        }
    }
}

/** Pilih sampai 4 data panel; urutan mengikuti urutan dipilih. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun VuMetricChips(selected: List<String>, onChange: (List<String>) -> Unit) {
    androidx.compose.foundation.layout.FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        TrailKeys.METRICS.forEach { m ->
            val on = m in selected
            FilterChip(
                selected = on,
                onClick = {
                    if (on) { if (selected.size > 1) onChange(selected - m) }
                    else if (selected.size < 4) onChange(selected + m)
                },
                label = { Text(TrailKeys.metricName(m)) },
            )
        }
    }
}

/** Baca foto latar: perkecil agar sisi terpanjang <= 1920 px dan luruskan menurut EXIF. */
private fun decodePhoto(ctx: Context, uri: Uri): Bitmap? = runCatching {
    val cr = ctx.contentResolver
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@runCatching null
    var sample = 1
    while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1920) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    val bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return@runCatching null
    val orient = cr.openInputStream(uri)?.use {
        android.media.ExifInterface(it).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, android.media.ExifInterface.ORIENTATION_NORMAL)
    } ?: android.media.ExifInterface.ORIENTATION_NORMAL
    val deg = when (orient) {
        android.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90f
        android.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180f
        android.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270f
        else -> 0f
    }
    if (deg == 0f) bmp else Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
}.getOrNull()
