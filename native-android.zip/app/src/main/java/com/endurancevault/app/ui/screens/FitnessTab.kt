@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.i18n.Text
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.Favorite
import androidx.compose.material.icons.outlined.MonitorHeart
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.Timeline
import androidx.compose.material.icons.outlined.TrendingDown
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.endurancevault.app.domain.ActDetail
import com.endurancevault.app.domain.EasyRunAnalytics
import com.endurancevault.app.domain.FitnessAnalytics
import com.endurancevault.app.domain.Js
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.ProgressAnalytics
import com.endurancevault.app.domain.TrainingMetrics
import com.endurancevault.app.ui.UiState
import java.time.LocalDate
import java.time.format.TextStyle as JTextStyle
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Tab Kebugaran, disamakan dengan grup 'fit' di rencana lari (layout-compact.js):
 * Kebugaran lari (hero), Personal record, Zona pace dari RAI, Efisiensi aerobik, Cardiac drift, Tren easy run.
 * Susunan lebar mengikuti pack() di web: hero, PR, dan Zona pace selebar layar; Efisiensi aerobik berpasangan dengan
 * Cardiac drift; Tren easy run selebar layar dan terbuka sejak awal.
 */
@Composable
internal fun FitnessTab(state: UiState, onOpen: (Long) -> Unit) {
    val today = LocalDate.now()
    val metrics = remember(state.settings, state.activities, state.daily, state.plan, state.hrHistByActivity) {
        runCatching {
            TrainingMetrics.calculate(state.settings, state.activities, state.daily, state.plan, hrHistByActivity = state.hrHistByActivity)
        }.getOrNull()
    }
    val ability = remember(state.settings, state.activities, state.daily) {
        runCatching { ProgressAnalytics.runningAbility(state.settings, state.activities, state.daily) }.getOrNull()
    }
    val hero = remember(ability, metrics) { metrics?.let { FitnessAnalytics.hero(ability, it) } }
    val prs = remember(state.detailsByActivity) { runCatching { ProgressAnalytics.personalBests(state.detailsByActivity) }.getOrDefault(emptyList()) }
    val details = remember(state.detailsByActivity) { state.detailsByActivity.values.toList() }
    val planDays = remember(state.plan) {
        (state.plan as? PlanOutcome.Ok)?.weeks.orEmpty().flatMap { it.days }.associateBy { it.date }
    }
    val easyResults = remember(state.detailsByActivity, metrics, state.settings) {
        runCatching { EasyRunAnalytics.calculate(state.detailsByActivity, metrics?.lthr ?: 0, state.settings.easyRun) }.getOrDefault(emptyList())
    }

    var oPr by rememberSaveable { mutableStateOf(false) }
    var oPace by rememberSaveable { mutableStateOf(false) }
    var oAe by rememberSaveable { mutableStateOf(false) }
    var oDf by rememberSaveable { mutableStateOf(false) }
    var oEz by rememberSaveable { mutableStateOf(true) }   // di web kartu Tren easy run terbuka sejak awal

    FitnessHero(hero)
    FitnessPr(prs, today, onOpen, oPr, { oPr = !oPr }, Modifier.fillMaxWidth())
    FitnessPace(ability?.value, oPace, { oPace = !oPace }, Modifier.fillMaxWidth())
    RcPair(oAe, oDf,
        left = { m -> FitnessAero(details, today, oAe, { oAe = !oAe }, m) },
        right = { m -> FitnessDrift(details, planDays, oDf, { oDf = !oDf }, m) })
    FitnessEzTrend(easyResults, state, today, oEz, { oEz = !oEz }, Modifier.fillMaxWidth())
}

// ===================== helper kecil =====================

private val ID_LOC = com.endurancevault.app.ui.i18n.Lang.locale
private val EZ_GOOD = Color(0xFF3F9E86)
private val EZ_OK = Color(0xFFD8B04A)
private val EZ_HARD = Color(0xFFC84B3B)

private fun ftF1(x: Double): String = String.format(Locale.US, "%.1f", x).replace('.', ',')
private fun ftDate(d: LocalDate): String = "${d.dayOfMonth} ${d.month.getDisplayName(JTextStyle.SHORT, ID_LOC)}"
private fun ftDateY(d: LocalDate): String = "${ftDate(d)} ${d.year}"
private fun ftVerdictColor(v: String): Color = when (v) { "good" -> EZ_GOOD; "ok" -> EZ_OK; else -> EZ_HARD }

/** Garis mini ringkasan kartu tertutup (lvSpark di web); [dash] = garis acuan putus-putus. */
@Composable
private fun FtSpark(vals: List<Double>, color: Color, dash: Double? = null) {
    if (vals.size < 2) return
    val ref = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = .6f)
    Canvas(Modifier.fillMaxWidth().height(34.dp)) {
        val w = size.width; val h = size.height
        var mn = vals.minOrNull() ?: 0.0; var mx = vals.maxOrNull() ?: 1.0
        if (dash != null) { mn = min(mn, dash); mx = max(mx, dash) }
        val sp = if (mx - mn == 0.0) 1.0 else mx - mn
        val pad = 4.dp.toPx(); val ph = 10.dp.toPx()
        fun y(v: Double): Float = (h - pad - ((v - mn) / sp).toFloat() * (h - ph))
        fun x(i: Int): Float = i * w / (vals.size - 1)
        val line = Path().apply { vals.forEachIndexed { i, v -> if (i == 0) moveTo(x(i), y(v)) else lineTo(x(i), y(v)) } }
        val area = Path().apply { moveTo(0f, h); vals.forEachIndexed { i, v -> lineTo(x(i), y(v)) }; lineTo(w, h); close() }
        if (dash != null) {
            drawLine(ref, Offset(0f, y(dash)), Offset(w, y(dash)), strokeWidth = 1.dp.toPx(),
                pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(6f, 6f)))
        }
        drawPath(area, color.copy(alpha = .14f))
        drawPath(line, color, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** Satu baris meter bertajuk (tebr di web): label, angka, keterangan, dan batang. */
@Composable
private fun FtMeter(label: String, value: Int, tag: String, color: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
            Text(value.toString(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(8.dp))
            Text(tag, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        RcCompare(listOf(value.toFloat() to color), h = 6)
    }
}

@Composable
private fun FtLegendDot(color: Color, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Text(text.uppercase(Locale.ROOT), style = monoStyle(9f, .3f), color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ===================== 1. Kebugaran lari (hero, selalu terbuka) =====================

@Composable
private fun FitnessHero(hero: FitnessAnalytics.Hero?) {
    val cs = MaterialTheme.colorScheme
    Card(
        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = cs.surfaceVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        border = BorderStroke(.8.dp, cs.outlineVariant),
    ) {
        Column(
            Modifier.fillMaxWidth().background(SolidColor(Color.Transparent))
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(24.dp).clip(CircleShape).background(cs.primary.copy(alpha = .14f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Outlined.MonitorHeart, null, Modifier.size(14.dp), tint = cs.primary)
                }
                Spacer(Modifier.width(7.dp))
                Text("KEBUGARAN LARI", Modifier.weight(1f), style = monoStyle(9f, 0f), color = cs.onSurfaceVariant, maxLines = 1)
                if (hero?.raiRuns != null) {
                    Text("dari ${hero.raiRuns} lari terakhir", style = monoStyle(10f, 0f), color = cs.onSurfaceVariant, maxLines = 1)
                }
            }
            if (hero == null) {
                RcInner {
                    RcMuted("Belum ada data. Catat atau impor sesi lari (idealnya dengan HR) agar Running Ability Index, Fitness, Fatigue, dan waktu recovery bisa dihitung.")
                }
            } else {
                RcStatGrid(
                    listOf(
                        "Running Ability Index" to (hero.rai?.let { ftF1(Math.floor(it * 10 + .5) / 10.0) } ?: "–"),
                        "Fitness RAI" to hero.fitness.toString(),
                        "Fatigue RAI" to hero.fatigue.toString(),
                        "Recovery" to FitnessAnalytics.recoveryText(hero.recoveryHours),
                    ),
                    cols = 2,
                )
                RcInner(pad = 12) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        FtMeter("Fitness RAI", hero.fitness, FitnessAnalytics.fitLabel(hero.fitness), cs.primary)
                        FtMeter("Fatigue RAI", hero.fatigue, FitnessAnalytics.fatLabel(hero.fatigue), WARN)
                    }
                }
                if (hero.rai != null) {
                    val r = Math.floor(hero.rai * 10 + .5) / 10.0
                    RcMuted("RAI ${ftF1(r)} · ${FitnessAnalytics.raiLabel(r)}" + (hero.trend?.let { " · tren 5 minggu: $it" } ?: ""))
                }
                RcMuted(
                    "Perkiraan, bukan angka resmi Huawei. Running Ability Index memakai indeks kemampuan dari pace dan HR lari terakhir (setara VO2max). Fitness menggabungkan indeks itu dengan CTL. Fatigue dari rasio ATL:CTL ditambah kondisi pagi (HR istirahat, HRV, tidur). Waktu recovery dari beban tiap sesi 5 hari terakhir, disesuaikan dengan kebugaranmu. Mengisi kondisi pagi dan HR sesi membuat angka lebih akurat.",
                )
            }
        }
    }
}

// ===================== 2. Personal record =====================

@Composable
private fun FitnessPr(
    prs: List<com.endurancevault.app.domain.PersonalBest>, today: LocalDate, onOpen: (Long) -> Unit,
    open: Boolean, onToggle: () -> Unit, modifier: Modifier,
) {
    val defs = listOf("1 km" to "1 km", "5K" to "5K", "10K" to "10K", "Half marathon" to "21K")
    val found = defs.count { d -> prs.any { it.label == d.first } }
    RcCard(Icons.Outlined.EmojiEvents, "PERSONAL RECORD", open, onToggle, modifier,
        headText = if (found > 0) "$found dari 4 jarak" else null,
        summary = {
            if (found == 0) RcStats(listOf("1 km" to "–", "5K" to "–"))
            else {
                RcStatGrid(defs.map { (full, short) -> short to (prs.firstOrNull { it.label == full }?.let { Js.durStr(it.durationMinutes) } ?: "–") }, cols = 2)
                var recent: Pair<Long, String>? = null
                defs.forEach { (full, short) ->
                    val b = prs.firstOrNull { it.label == full } ?: return@forEach
                    val d = runCatching { LocalDate.parse(b.dateIso.take(10)) }.getOrNull() ?: return@forEach
                    val ago = java.time.temporal.ChronoUnit.DAYS.between(d, today)
                    if (ago in 0L..14L && (recent == null || ago < recent!!.first)) recent = ago to short
                }
                recent?.let { (ago, lb) -> RcTag("★ PR $lb · " + (if (ago > 0) "$ago hari lalu" else "hari ini"), 2) }
            }
        },
        body = {
            defs.chunked(2).forEach { pair ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    pair.forEach { (full, short) ->
                        val b = prs.firstOrNull { it.label == full }
                        PrTile(short, b, today, onOpen, Modifier.weight(1f))
                    }
                }
            }
            RcMuted("Dihitung dari data per kilometer yang tersimpan (lari GPX/TCX/FIT), jadi resolusinya 1 km dan bisa beda beberapa detik dari Strava atau Garmin. Ketuk kartu untuk membuka sesinya.")
        })
}

@Composable
private fun PrTile(label: String, b: com.endurancevault.app.domain.PersonalBest?, today: LocalDate, onOpen: (Long) -> Unit, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val date = b?.let { runCatching { LocalDate.parse(it.dateIso.take(10)) }.getOrNull() }
    val fresh = date != null && java.time.temporal.ChronoUnit.DAYS.between(date, today) <= 30
    Surface(
        modifier.then(if (b != null) Modifier.clickable { onOpen(b.activityId) } else Modifier),
        shape = RoundedCornerShape(14.dp), color = cs.surfaceVariant.copy(alpha = if (b != null) .7f else .35f),
        border = BorderStroke(.8.dp, cs.outlineVariant),
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(label.uppercase(Locale.ROOT), style = monoStyle(9f, .4f), color = cs.onSurfaceVariant)
                if (fresh) RcTag("baru", 2)
            }
            Text(b?.let { Js.durStr(it.durationMinutes) } ?: "–", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(
                if (b != null && date != null) "${Js.paceStr(b.durationMinutes / b.distanceKm)}/km · ${ftDateY(date)}" else "Belum ada data",
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
            )
        }
    }
}

// ===================== 3. Zona pace dari RAI =====================

@Composable
private fun FitnessPace(rai: Double?, open: Boolean, onToggle: () -> Unit, modifier: Modifier) {
    fun z(lo: Double, hi: Double): String =
        "${Js.paceStr(FitnessAnalytics.paceAtFrac(rai!!, lo))}–${Js.paceStr(FitnessAnalytics.paceAtFrac(rai, hi))}"
    RcCard(Icons.Outlined.Speed, "ZONA PACE DARI RAI", open, onToggle, modifier,
        headText = rai?.let { "RAI ${ftF1(Math.floor(it * 10 + .5) / 10.0)}" },
        summary = {
            if (rai == null) RcStats(listOf("Easy" to "–", "Threshold" to "–"))
            else RcStats(listOf("Easy" to z(.62, .74), "Threshold" to z(.88, .92)))
        },
        body = {
            if (rai == null) {
                RcMuted("Belum ada data. Impor sesi lari (idealnya dengan HR) agar Running Ability Index dan zona pace bisa dihitung.")
            } else {
                RcInner {
                    val w = listOf(1.2f, 1f)
                    RcTableRow(listOf("Zona", "Pace /km"), w, head = true)
                    FitnessAnalytics.PACE_ZONES.forEach { zn ->
                        RcTableRow(listOf("${zn.name}\n${zn.note}", z(zn.lo, zn.hi).replace("–", " – ")), w)
                    }
                }
                RcMuted("Untuk jalan datar. Di tanjakan atau cuaca panas, ikuti HR dan rasa usaha, bukan pace.")
            }
        })
}

// ===================== 4. Efisiensi aerobik =====================

@Composable
private fun FitnessAero(details: List<ActDetail>, today: LocalDate, open: Boolean, onToggle: () -> Unit, modifier: Modifier) {
    // HR target dan rentang waktu disimpan permanen (SharedPreferences), supaya tidak kembali ke 140 saat kartu dibuat ulang atau aplikasi dibuka lagi.
    val aePrefs = androidx.compose.ui.platform.LocalContext.current.getSharedPreferences("fitness_aero", android.content.Context.MODE_PRIVATE)
    val savedHr = remember { aePrefs.getInt("hr", FitnessAnalytics.AE_DEFAULT_HR).coerceIn(100, 190) }
    var hr by rememberSaveable { mutableIntStateOf(savedHr) }
    var hrText by rememberSaveable { mutableStateOf(savedHr.toString()) }
    var rangeIdx by rememberSaveable { mutableIntStateOf(aePrefs.getInt("range", 1).coerceIn(0, 3)) }   // 3 bln, 6 bln (bawaan), 1 th, Semua
    val months = listOf(3, 6, 12, 0)[rangeIdx]
    val pts = remember(details, hr, months, today) { FitnessAnalytics.aeSeries(details, hr, FitnessAnalytics.AE_TOL, months, today) }
    val sm = remember(pts) { FitnessAnalytics.aeSmooth(pts) }
    val sum = remember(pts) { FitnessAnalytics.aeSummary(pts) }
    val best = remember(details) { FitnessAnalytics.aeBest(details) }

    RcCard(Icons.Outlined.Favorite, "EFISIENSI AEROBIK", open, onToggle, modifier,
        headText = "pace pada $hr bpm (±${FitnessAnalytics.AE_TOL})",
        summary = {
            if (sum == null) RcStats(listOf("Pace" to "–", "Tren" to "–"))
            else {
                val pill = if (abs(sum.deltaPct) >= .5) (if (sum.deltaPct > 0) "▲ " else "▼ ") + ftF1(abs(sum.deltaPct)) + "%" else null
                RcBig(Js.paceStr(sum.lastPace), "/km pada $hr bpm", pill, sum.deltaPct < 0)
                FtSpark(sm.map { -it }, MaterialTheme.colorScheme.primary)
            }
        },
        body = {
            RcSeg(listOf("3 bln", "6 bln", "1 th", "Semua"), rangeIdx) { rangeIdx = it; aePrefs.edit().putInt("range", it).apply() }
            OutlinedTextField(
                value = hrText,
                onValueChange = { t ->
                    val clean = t.filter { it.isDigit() }.take(3)
                    hrText = clean
                    val v = clean.toIntOrNull()
                    if (v != null && v in 100..190) { hr = v; aePrefs.edit().putInt("hr", v).apply() }
                },
                label = { Text("HR (bpm)") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.width(140.dp),
            )
            if (pts.size < 2) {
                val tip = best?.takeIf { abs(it.hr - hr) > 2 }
                RcMuted(
                    "Belum cukup lari dengan HR sekitar $hr bpm (butuh minimal 2 lari dengan 1,5 km atau lebih di rentang itu, dari aktivitas yang punya data per km)." +
                        (tip?.let { " Data terbanyak ada di sekitar ${it.hr} bpm." } ?: ""),
                )
                if (tip != null) RcPill("Pakai ${tip.hr} bpm") { hr = tip.hr; hrText = tip.hr.toString(); aePrefs.edit().putInt("hr", tip.hr).apply() }
            } else {
                AeroChart(pts, sm)
                RcInner { Text(FitnessAnalytics.aeSummaryText(sum!!, hr), style = MaterialTheme.typography.bodyMedium) }
                RcMuted(
                    "Titik: satu lari (rata-rata kilometer dengan HR di rentang target). Garis: rata-rata 28 hari. Makin ke atas berarti makin cepat pada HR yang sama. Memakai GAP bila ada, atau hanya kilometer yang relatif datar. ${pts.size} lari.",
                )
            }
        })
}

@Composable
private fun AeroChart(pts: List<FitnessAnalytics.AePoint>, sm: List<Double>) {
    val cs = MaterialTheme.colorScheme
    val tm = rememberTextMeasurer()
    val ts = tickStyle()
    val dot = cs.primary.copy(alpha = .4f)
    Canvas(Modifier.fillMaxWidth().height(170.dp)) {
        val lp = 38.dp.toPx(); val rp = 8.dp.toPx(); val tp = 12.dp.toPx(); val bp = 22.dp.toPx()
        val all = pts.map { it.pace } + sm
        var mn = all.minOrNull() ?: 0.0; var mx = all.maxOrNull() ?: 1.0
        val pad = ((mx - mn) * .15).let { if (it == 0.0) .2 else it }
        mn -= pad; mx += pad
        val t0 = pts.first().date.toEpochDay(); val t1 = pts.last().date.toEpochDay(); val span = max(1L, t1 - t0)
        fun x(d: LocalDate): Float = lp + (size.width - lp - rp) * ((d.toEpochDay() - t0).toFloat() / span)
        fun y(v: Double): Float = tp + (size.height - tp - bp) * ((v - mn) / (mx - mn)).toFloat()
        for (i in 0..2) {
            val v = mn + (mx - mn) * i / 2; val yy = y(v)
            drawLine(cs.outlineVariant.copy(alpha = .6f), Offset(lp, yy), Offset(size.width - rp, yy), strokeWidth = .8.dp.toPx())
            val lbl = Js.paceStr(v); val w = tm.measure(lbl, ts).size.width
            drawText(tm, lbl, Offset(lp - 4.dp.toPx() - w, yy - 6.dp.toPx()), style = ts)
        }
        pts.forEach { drawCircle(dot, 3.dp.toPx(), Offset(x(it.date), y(it.pace))) }
        val line = Path().apply { pts.forEachIndexed { i, p -> if (i == 0) moveTo(x(p.date), y(sm[i])) else lineTo(x(p.date), y(sm[i])) } }
        drawPath(line, cs.primary, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawText(tm, ftDate(pts.first().date), Offset(lp, size.height - 16.dp.toPx()), style = ts)
        val last = ftDate(pts.last().date); val lw = tm.measure(last, ts).size.width
        drawText(tm, last, Offset(size.width - rp - lw, size.height - 16.dp.toPx()), style = ts)
    }
}

// ===================== 5. Cardiac drift =====================

@Composable
private fun FitnessDrift(
    details: List<ActDetail>, planDays: Map<LocalDate, com.endurancevault.app.domain.PDay>,
    open: Boolean, onToggle: () -> Unit, modifier: Modifier,
) {
    val rows = remember(details, planDays) {
        details.mapNotNull { d ->
            val date = runCatching { LocalDate.parse(d.date.take(10)) }.getOrNull() ?: return@mapNotNull null
            val pd = planDays[date]
            FitnessAnalytics.driftOf(d, pd?.kind, pd?.bench == true)
        }.sortedBy { it.date }
    }
    val cs = MaterialTheme.colorScheme
    RcCard(Icons.Outlined.TrendingDown, "CARDIAC DRIFT", open, onToggle, modifier,
        headText = if (rows.isNotEmpty()) "${rows.size} lari" else null,
        summary = {
            if (rows.isEmpty()) RcStats(listOf("Drift" to "–", "Lari" to "–"))
            else {
                val tail = rows.takeLast(5); val avg = tail.map { it.pct }.average()
                val r = Math.floor(avg * 10 + .5) / 10.0
                RcBig((if (r > 0) "+" else "") + ftF1(r) + "%", "rata-rata ${tail.size} lari terakhir", FitnessAnalytics.driftLabel(avg), avg >= 5)
                FtSpark(rows.takeLast(8).map { it.pct }, WARN, dash = 5.0)
            }
        },
        body = {
            if (rows.isEmpty()) {
                RcMuted("Belum ada data. Cardiac drift dihitung dari lari easy atau long run minimal 8 km yang punya data HR per km (impor GPX, TCX, atau FIT).")
            } else {
                FitnessAnalytics.driftMessage(rows.map { it.pct })?.let { msg -> RcInner { Text(msg, style = MaterialTheme.typography.bodyMedium) } }
                RcInner(pad = 6) {
                    rows.takeLast(8).asReversed().forEachIndexed { i, x ->
                        val bad = x.pct >= 5
                        RcTableRow(
                            listOf("${ftDate(x.date)} · ${com.endurancevault.app.ui.screens.fmtKmUi(x.km)} km",
                                (if (x.pct > 0) "+" else "") + ftF1(x.pct) + "% · " + FitnessAnalytics.driftLabel(x.pct)),
                            listOf(1f, 1f), tint = listOf(null, if (bad) WARN else cs.onSurface), line = i < min(8, rows.size) - 1,
                        )
                    }
                }
                RcMuted("Drift = penurunan efisiensi (kecepatan setara datar per detak) dari paruh pertama ke paruh kedua lari, setelah pemanasan. Di bawah 3% berarti stabil.")
            }
        })
}

// ===================== 6. Tren easy run =====================

@Composable
private fun FitnessEzTrend(
    results: List<com.endurancevault.app.domain.EasyRunResult>, state: UiState, today: LocalDate,
    open: Boolean, onToggle: () -> Unit, modifier: Modifier,
) {
    val cfg = state.settings.easyRun
    val all = remember(results) { FitnessAnalytics.ezRows(results) }
    val weeks = remember(all, today, cfg) { FitnessAnalytics.ezWeeks(all, FitnessAnalytics.EZT_WEEKS, today, cfg) }
    val win = remember(all, weeks) { all.filter { !it.week.isBefore(weeks.first().start) } }
    val cs = MaterialTheme.colorScheme

    RcCard(Icons.Outlined.Timeline, "TREN EASY RUN", open, onToggle, modifier,
        headText = "Waktu di zona · skor · berturut-turut",
        summary = {
            val last = weeks.lastOrNull { it.pct != null }
            if (last == null) RcStats(listOf("Zona" to "–", "Skor" to "–"))
            else {
                val st = FitnessAnalytics.ezStreaks(all)
                val cur = if (last.start == today.with(java.time.DayOfWeek.MONDAY)) "minggu ini" else "minggu terakhir"
                val lastPct = last.pct ?: 0.0
                RcBig("${lastPct.roundToInt()}%", "waktu di zona, $cur", if (st.cur > 0) "${st.cur}× terlalu keras" else null, st.cur > 0)
                RcCompare(listOf(lastPct.toFloat() to ftVerdictColor(FitnessAnalytics.ezWeekVerdict(last))))
            }
        },
        body = {
            if (win.isEmpty()) {
                RcMuted(
                    if (all.isNotEmpty()) "Tidak ada sesi yang dinilai dalam ${FitnessAnalytics.EZT_WEEKS} minggu terakhir."
                    else "Belum ada sesi yang ditandai. Buka Detail aktivitas, halaman Zona & beban, lalu tandai easy run atau long slow.",
                )
            } else {
                val st = FitnessAnalytics.ezStreaks(all)
                val stWin = FitnessAnalytics.ezStreaks(win)
                val adv = FitnessAnalytics.ezStreakAdvice(st, all.last().r.verdict)
                val advBg = when (adv.key) { "w" -> cs.errorContainer; "ok" -> cs.surfaceVariant; else -> cs.surfaceVariant }
                val advFg = if (adv.key == "w") cs.onErrorContainer else cs.onSurface
                Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), color = advBg) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Sesi Terlalu keras berturut-turut: ${st.cur}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = advFg)
                        Text(adv.text, style = MaterialTheme.typography.bodyMedium, color = advFg)
                        Text("Terpanjang dalam ${FitnessAnalytics.EZT_WEEKS} minggu terakhir: ${stWin.max}", style = MaterialTheme.typography.bodySmall, color = advFg.copy(alpha = .8f))
                    }
                }

                Text("WAKTU DI ZONA PER MINGGU", style = monoStyle(9.5f, .4f), color = cs.onSurfaceVariant)
                RcInner {
                    weeks.asReversed().forEach { w ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(ftDate(w.start), Modifier.width(54.dp), style = monoStyle(10f, 0f), color = cs.onSurfaceVariant, maxLines = 1)
                            Box(Modifier.weight(1f).height(8.dp).clip(RoundedCornerShape(99.dp)).background(cs.outlineVariant.copy(alpha = .6f))) {
                                if (w.pct != null) {
                                    Box(
                                        Modifier.fillMaxWidth((max(2.0, min(100.0, w.pct)) / 100.0).toFloat()).height(8.dp)
                                            .clip(RoundedCornerShape(99.dp)).background(ftVerdictColor(FitnessAnalytics.ezWeekVerdict(w))),
                                    )
                                }
                            }
                            Text(
                                if (w.pct == null) "–" else "${w.pct.roundToInt()}% · ${w.n}", Modifier.width(66.dp),
                                style = monoStyle(10f, 0f), textAlign = TextAlign.End, maxLines = 1,
                            )
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    FtLegendDot(EZ_GOOD, "Efisien"); FtLegendDot(EZ_OK, "Cukup"); FtLegendDot(EZ_HARD, "Terlalu keras")
                }

                val sc = FitnessAnalytics.ezScores(win, FitnessAnalytics.EZT_SESS)
                val sum = FitnessAnalytics.ezScoreSum(sc)
                Text("SKOR PER SESI", style = monoStyle(9.5f, .4f), color = cs.onSurfaceVariant)
                if (sc.isEmpty() || sum == null) {
                    RcMuted("Belum ada sesi dengan skor di rentang ini.")
                } else {
                    EzScoreChart(sc)
                    RcInner {
                        var txt = "Skor terakhir ${sum.last}/100."
                        if (sum.dir != null && sum.from != null && sum.to != null) {
                            txt += " Rata-rata ${sum.k} sesi awal ${sum.from} → ${sum.k} sesi akhir ${sum.to}: " +
                                when (sum.dir) { "up" -> "membaik."; "down" -> "menurun."; else -> "stabil." }
                        }
                        Text(txt, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                RcMuted(
                    "Hanya sesi yang ditandai (easy dan long slow), tiap sesi dinilai terhadap batas HR-nya sendiri. Persen = waktu di dalam batas + toleransi setelah pengali, dihitung per waktu dinilai; angka kecil di kanan = jumlah sesi. Warna batang mengikuti target Efisien/Cukup di Atur → Easy run. Titik skor berwarna menurut hasil sesi. Hanya saran: rencana latihan tidak diubah.",
                )
            }
        })
}

@Composable
private fun EzScoreChart(sc: List<FitnessAnalytics.EzScore>) {
    val cs = MaterialTheme.colorScheme
    val tm = rememberTextMeasurer()
    val ts = tickStyle()
    Canvas(Modifier.fillMaxWidth().height(150.dp)) {
        val lp = 30.dp.toPx(); val rp = 12.dp.toPx(); val tp = 12.dp.toPx(); val bp = 26.dp.toPx()
        fun x(i: Int): Float = if (sc.size > 1) lp + (size.width - lp - rp) * i / (sc.size - 1) else lp + (size.width - lp - rp) / 2
        fun y(v: Int): Float = tp + (size.height - tp - bp) * (1f - v / 100f)
        listOf(0, 50, 100).forEach { v ->
            drawLine(cs.outlineVariant.copy(alpha = .6f), Offset(lp, y(v)), Offset(size.width - rp, y(v)), strokeWidth = .8.dp.toPx())
            val lbl = v.toString(); val w = tm.measure(lbl, ts).size.width
            drawText(tm, lbl, Offset(lp - 4.dp.toPx() - w, y(v) - 6.dp.toPx()), style = ts)
        }
        if (sc.size > 1) {
            val line = Path().apply { sc.forEachIndexed { i, p -> if (i == 0) moveTo(x(i), y(p.score)) else lineTo(x(i), y(p.score)) } }
            drawPath(line, cs.primary.copy(alpha = .55f), style = Stroke(1.6.dp.toPx(), join = StrokeJoin.Round))
        }
        sc.forEachIndexed { i, p -> drawCircle(ftVerdictColor(p.verdict), 4.dp.toPx(), Offset(x(i), y(p.score))) }
        drawText(tm, ftDate(sc.first().date), Offset(lp, size.height - 18.dp.toPx()), style = ts)
        if (sc.size > 1) {
            val last = ftDate(sc.last().date); val lw = tm.measure(last, ts).size.width
            drawText(tm, last, Offset(size.width - rp - lw, size.height - 18.dp.toPx()), style = ts)
        }
    }
}
