package com.endurancevault.app.ui.screens

import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.endurancevault.app.data.ReadinessHistoryStore
import com.endurancevault.app.domain.*
import com.endurancevault.app.ui.UiState
import org.json.JSONArray
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

private val ID = Locale("id", "ID")

/**
 * Tab Minggu native. Logika tukar hari, libur dadakan (bagi km), geser/lewati sesi terlewat dan penanda selesai
 * disamakan dengan rencana-lari (web); perhitungannya ada di domain/SessionAdjust.kt, penyimpanannya di kv `mv` dan `done`
 * (format yang sama dengan cadangan web).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ScheduleScreen(
    state: UiState,
    onOpenActivity: (Long) -> Unit = {},
    onSetMv: (String, MvEntry?) -> Unit = { _, _ -> },
    onSetDone: (String, Boolean) -> Unit = { _, _ -> },
) {
    val today = LocalDate.now()
    var history by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf<Set<String>>(emptySet()) }
    var pendingSwap by remember { mutableStateOf<Pair<PDay, DayOption>?>(null) }
    var spreadFor by remember { mutableStateOf<LocalDate?>(null) }
    val inp = remember(state.mv, state.done, state.activities, state.settings.hr) {
        AdjInput(today, state.mv, state.done, SessionAdjust.loggedKm(state.activities), state.settings.hr)
    }

    when (val plan = state.plan) {
        is PlanOutcome.Err -> Text(plan.message, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.error)
        is PlanOutcome.Ok -> {
            val week = plan.weeks.firstOrNull { !today.isBefore(it.start) && !today.isAfter(it.end) }
                ?: plan.weeks.firstOrNull { !it.end.isBefore(today) } ?: plan.weeks.lastOrNull()
            LazyColumn(
                Modifier.fillMaxSize().padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(top = 18.dp, bottom = 24.dp),
            ) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("RENCANA PEKAN", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        Text("Minggu", style = MaterialTheme.typography.headlineMedium)
                        Text(
                            week?.let { "Minggu ${it.i + 1} · ${it.phase}" } ?: "Belum ada pekan latihan",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        FilterChip(selected = !history, onClick = { history = false }, label = { Text("Minggu ini") }, modifier = Modifier.weight(1f))
                        FilterChip(selected = history, onClick = { history = true }, label = { Text("Riwayat") }, modifier = Modifier.weight(1f))
                    }
                }
                if (!history) {
                    if (week != null) item {
                        EvPanel(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(if (plan.none) "No Race" else phaseLabel(week.phase, week.rec), style = MaterialTheme.typography.titleLarge)
                                Text(
                                    "Week ${week.i + 1} · ${week.start.dayOfMonth}–${week.end.dayOfMonth} ${week.end.month.getDisplayName(TextStyle.SHORT, ID)} · ${SessionAdjust.ds(week.km)} km",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                if (week.adj80) Text("Minggu ini dikurangi 20% karena minggu sebelumnya banyak terlewat.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.tertiary)
                            }
                        }
                    }
                    val days = week?.days.orEmpty()
                    if (days.isEmpty()) item { Text("Belum ada jadwal minggu ini.") }
                    items(days, key = { it.date.toString() }) { d ->
                        DayBlock(
                            d = d, state = state, today = today, open = d.date.toString() in expanded,
                            onToggle = { val k = d.date.toString(); expanded = if (k in expanded) expanded - k else expanded + k },
                            expandedKeys = expanded,
                            onToggleKey = { k -> expanded = if (k in expanded) expanded - k else expanded + k },
                            onOpenActivity = onOpenActivity, onSetMv = onSetMv, onSetDone = onSetDone,
                            askSwap = { opt ->
                                if (opt.warn) { pendingSwap = d to opt }
                                else { onSetMv("sw:${d.date}", MvEntry("sw", to = opt.date.toString())) }
                            },
                            openSpread = { spreadFor = d.date },
                        )
                    }
                } else {
                    item { ActivityHistoryContent(state, onOpenActivity) }
                    item { Text("RIWAYAT PENYESUAIAN", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary) }
                    val entries = state.mv.filterValues { it.raw == null }.toList().sortedByDescending { it.first.removePrefix("sw:") }
                    items(entries, key = { it.first }) { (key, e) -> AdjustmentRow(key, e) { onSetMv(key, null) } }
                    if (entries.isEmpty()) item { Text("Belum ada penyesuaian jadwal.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            }

            pendingSwap?.let { (src, opt) ->
                AlertDialog(
                    onDismissRequest = { pendingSwap = null },
                    title = { Text("Tukar ${SessionAdjust.dlabel(src)} dengan ${opt.label}?") },
                    text = { Text("Peringatan: pertukaran ini membuat dua sesi berat berurutan. Pastikan pemulihan mencukupi.", color = MaterialTheme.colorScheme.error) },
                    confirmButton = { TextButton(onClick = { onSetMv("sw:${src.date}", MvEntry("sw", to = opt.date.toString())); pendingSwap = null }) { Text("Tetap tukar") } },
                    dismissButton = { TextButton(onClick = { pendingSwap = null }) { Text("Batal") } },
                )
            }
            spreadFor?.let { date ->
                SpreadDialog(plan, inp, state.mv, date, onDismiss = { spreadFor = null }) { entry -> onSetMv(date.toString(), entry); spreadFor = null }
            }
        }
    }
}

// ---------- kartu hari ----------

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DayBlock(
    d: PDay, state: UiState, today: LocalDate, open: Boolean, onToggle: () -> Unit,
    expandedKeys: Set<String>, onToggleKey: (String) -> Unit,
    onOpenActivity: (Long) -> Unit, onSetMv: (String, MvEntry?) -> Unit, onSetDone: (String, Boolean) -> Unit,
    askSwap: (DayOption) -> Unit, openSpread: () -> Unit,
) {
    val key = d.date.toString()
    val rest = d.kind == Kinds.REST
    val logged = if (rest) null else SessionAdjust.primaryRun(state.activities, key)
    val manual = key in state.done
    val completed = !rest && (logged != null || manual)
    val adj = d.adj
    val cancelled = adj?.type == "skip" || adj?.type == "out" || adj?.type == "spread"
    val missed = !rest && !completed && adj?.type == "miss"
    val cs = MaterialTheme.colorScheme
    EvPanel(
        Modifier.fillMaxWidth().clickable(onClick = onToggle),
        containerColor = if (completed) cs.primaryContainer.copy(alpha = .35f) else cs.surface,
    ) {
        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Column(Modifier.width(52.dp)) {
                    Text(d.date.dayOfWeek.getDisplayName(TextStyle.SHORT, ID).uppercase(ID), style = MaterialTheme.typography.labelSmall)
                    Text(d.date.dayOfMonth.toString(), style = MaterialTheme.typography.headlineSmall)
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(if (rest) "Libur" else d.title, style = MaterialTheme.typography.titleMedium)
                    if (completed) {
                        val extra = logged?.let {
                            " · ${SessionAdjust.ds((it.km * 10).toLong() / 10.0)} km" + (it.avgHr?.let { hr -> " · HR $hr" } ?: "")
                        } ?: " · ditandai manual"
                        Text("Selesai$extra", color = cs.primary, style = MaterialTheme.typography.labelMedium)
                    } else if (missed) {
                        Text("Terlewat · belum ada aktivitas lari tercatat", color = cs.error, style = MaterialTheme.typography.labelMedium)
                    }
                    if (adj != null && !(missed && adj.type == "miss")) AdjText(adj)
                    if (open && !rest && d.detail.isNotBlank()) Text(d.detail, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    if (open && logged != null) {
                        val pace = if (logged.km > 0.0 && logged.durationSec > 0) " · ${"%.2f".format(logged.durationSec / 60.0 / logged.km)} min/km" else ""
                        Text("Logged · ${logged.name.ifBlank { "Run" }} · ${"%.1f".format(logged.km)} km$pace", style = MaterialTheme.typography.bodySmall, color = cs.primary)
                    }
                    if (!rest) {
                        val mvKm = d.mvKm
                        if (cancelled && mvKm != null) {
                            Text("${SessionAdjust.ds(mvKm)} km", style = MaterialTheme.typography.titleMedium, color = cs.onSurfaceVariant, textDecoration = TextDecoration.LineThrough)
                        } else if (d.km > 0) {
                            Text("${SessionAdjust.ds(d.km)} km", style = MaterialTheme.typography.titleMedium)
                        }
                    }
                    methodTag(d.tm)?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = cs.tertiary) }
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    if (!rest) DoneMark(
                        done = completed, locked = logged != null,
                        desc = if (completed) "Sesi selesai" else "Tandai sesi selesai",
                    ) { onSetDone(key, !manual) }
                    Text(if (open) "⌃" else "⌄", color = cs.onSurfaceVariant)
                }
            }
            if (open) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (d.mvUndo) TextButton(onClick = { onSetMv(d.mvSw ?: key, null) }) { Text("Batalkan") }
                    if (adj?.type == "miss" && !rest && !completed) {
                        d.mvOpt?.let { o -> OutlinedButton(onClick = { onSetMv(key, MvEntry("mv", to = o.date.toString())) }) { Text("Geser ke ${o.label}") } }
                        d.mvOptR?.let { o -> OutlinedButton(onClick = { onSetMv(key, MvEntry("mv", to = o.date.toString())) }) { Text("Tukar libur ${o.label}") } }
                        OutlinedButton(onClick = { onSetMv(key, MvEntry("skip")) }) { Text("Lewati") }
                        if (d.mvList.isNotEmpty()) PickButton("Pilih hari lain…", d.mvList) { o -> onSetMv(key, MvEntry("mv", to = o.date.toString())) }
                    }
                    if (!rest && d.spOpt) OutlinedButton(onClick = openSpread) { Text("Libur dadakan") }
                    if (!rest && d.swList.isNotEmpty()) PickButton("Tukar hari…", d.swList, askSwap)
                    if (!rest && logged == null && adj?.type != "skip") {
                        OutlinedButton(onClick = { onSetDone(key, !manual) }) { Text(if (manual) "Batal tandai" else "Tandai selesai") }
                    }
                    if (logged != null) TextButton(onClick = { onOpenActivity(logged.id) }) { Text("Detail") }
                }
            }
        }
    }
    // blok strength / ankle / upper: baris terpisah, masing-masing punya penanda selesai sendiri
    listOf(Triple(d.str, "s", "GYM"), Triple(d.ank, "a", "ANKLE"), Triple(d.up, "u", "UPPER")).forEach { (blk, suffix, tag) ->
        if (blk != null) StrengthRow(d, blk, "$key:$suffix", tag, state, today, expandedKeys, onToggleKey, onSetDone)
    }
}

@Composable
private fun StrengthRow(
    d: PDay, b: StrengthBlock, key: String, tag: String, state: UiState, today: LocalDate,
    expandedKeys: Set<String>, onToggleKey: (String) -> Unit, onSetDone: (String, Boolean) -> Unit,
) {
    val manual = key in state.done
    val fromWatch = state.strengthWorkouts.any { it.linkedKey == key }
    val completed = manual || fromWatch
    val open = key in expandedKeys
    val cs = MaterialTheme.colorScheme
    val adj = b.adj
    EvPanel(
        Modifier.fillMaxWidth().clickable { onToggleKey(key) },
        containerColor = if (completed) cs.primaryContainer.copy(alpha = .35f) else cs.surfaceVariant,
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
                Text(tag, Modifier.width(52.dp), style = MaterialTheme.typography.labelSmall, color = cs.primary)
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(b.title, style = MaterialTheme.typography.titleSmall)
                    if (completed) Text("Selesai${if (fromWatch && !manual) " · dari jam" else ""}", color = cs.primary, style = MaterialTheme.typography.labelMedium)
                    else if (adj != null) AdjText(adj)
                    else if (d.date.isBefore(today)) Text("Terlewat", color = cs.error, style = MaterialTheme.typography.labelMedium)
                    Text(
                        (if (open) "Sembunyikan set" else "Lihat set") + " · ${b.lines.size} gerakan",
                        style = MaterialTheme.typography.labelMedium, color = cs.primary,
                    )
                    if (open) {
                        Text(b.note, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                        b.lines.forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium) }
                    }
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("${b.mins} mnt", style = MaterialTheme.typography.titleSmall)
                    DoneMark(done = completed, locked = fromWatch && !manual, desc = if (completed) "Strength selesai" else "Tandai strength selesai") { onSetDone(key, !manual) }
                }
            }
        }
    }
}

@Composable
private fun DoneMark(done: Boolean, locked: Boolean, desc: String, onToggle: () -> Unit) {
    IconButton(onClick = onToggle, enabled = !locked, modifier = Modifier.size(40.dp)) {
        Icon(
            if (done) Icons.Filled.CheckCircle else Icons.Outlined.RadioButtonUnchecked,
            contentDescription = desc,
            tint = if (done) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
        )
    }
}

@Composable
private fun AdjText(a: DayAdj) {
    val cs = MaterialTheme.colorScheme
    val color = when (a.type) {
        "miss" -> cs.error
        "skip", "out" -> cs.onSurfaceVariant
        else -> cs.tertiary
    }
    Text(a.text, color = color, style = MaterialTheme.typography.bodySmall)
}

@Composable
private fun PickButton(text: String, options: List<DayOption>, onPick: (DayOption) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { open = true }) { Text(text) }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { o ->
                DropdownMenuItem(
                    text = { Text((if (o.warn) "⚠ " else "") + "${o.label} · ${o.what}") },
                    onClick = { open = false; onPick(o) },
                )
            }
        }
    }
}

// ---------- riwayat penyesuaian ----------

@Composable
private fun AdjustmentRow(key: String, e: MvEntry, onUndo: () -> Unit) {
    val (title, body) = when (e.t) {
        "sw" -> "${key.removePrefix("sw:")} · Tukar hari" to "Isi sesi ditukar dengan ${e.to}"
        "mv" -> "$key · Geser sesi terlewat" to "Dipindah ke ${e.to}"
        "skip" -> "$key · Dilewati" to "Keluar dari target"
        else -> "$key · Libur dadakan" to (
            (SessionAdjust.WHY_LABEL[e.why] ?: "-") + " · ${SessionAdjust.ds(e.km)} km" +
                (if (e.spread.isEmpty()) " · tidak dikejar" else "") +
                e.spread.joinToString("") { "\n${it.first} +${SessionAdjust.ds(it.second)} km" }
            )
    }
    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(body, style = MaterialTheme.typography.bodySmall)
            TextButton(onClick = onUndo) { Text("Batalkan") }
        }
    }
}

// ---------- libur dadakan ----------

private class Condition(val pain: Boolean, val score: Int, val swapTh: Int, val lightTh: Int)

/** Kondisi hari ini untuk pengaman pembagian km: nyeri aktif (kemarin/hari ini, berat ≥ 3) dan skor kesiapan terakhir. */
private fun readCondition(ctx: Context, today: LocalDate): Condition {
    val prefs = ctx.getSharedPreferences("readiness_settings", Context.MODE_PRIVATE)
    val recent = setOf(today.toString(), today.minusDays(1).toString())
    val pain = runCatching {
        val arr = JSONArray(prefs.getString("pain_entries", "[]"))
        (0 until arr.length()).any { i -> arr.optJSONObject(i)?.let { it.optString("date") in recent && it.optInt("severity", 1) >= 3 } == true }
    }.getOrDefault(false)
    val score = runCatching { ReadinessHistoryStore.load(ctx).lastOrNull { it.date == today }?.score }.getOrNull() ?: -1
    return Condition(pain, score, prefs.getInt("swap", 50), prefs.getInt("light", 65))
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SpreadDialog(
    plan: PlanOutcome.Ok, inp: AdjInput, mv: Map<String, MvEntry>, date: LocalDate,
    onDismiss: () -> Unit, onApply: (MvEntry) -> Unit,
) {
    val ctx = LocalContext.current
    val cond = remember { readCondition(ctx, inp.today) }
    var why by remember { mutableStateOf("sibuk") }
    var next by remember { mutableStateOf(false) }
    val pv = remember(plan, inp, date, why, next) { SessionAdjust.spPreview(plan, inp, date, why, next, cond.pain, cond.score, cond.swapTh, cond.lightTh) }
    if (pv == null) {
        AlertDialog(
            onDismissRequest = onDismiss, title = { Text("Libur dadakan") },
            text = { Text("Sesi ini tidak bisa diliburkan.") },
            confirmButton = { TextButton(onClick = onDismiss) { Text("OK") } },
        )
        return
    }
    var manual by remember(date, why, next) { mutableStateOf<Map<Int, String>>(emptyMap()) }
    // angka ubahan manual dijepit (kelipatan 0,5, batas per hari, jatah minggu depan, total sesi asal), sama seperti web
    val items = pv.items.mapIndexed { i, q ->
        SpItem(q.c, manual[i]?.let { it.replace(',', '.').toDoubleOrNull() ?: 0.0 } ?: q.x, q.cap, q.nx, q.done)
    }
    SessionAdjust.spClamp(items, pv.km, pv.allow)
    val total = items.sumOf { it.x }
    val left = Js.round((pv.km - total) * 10) / 10
    val cs = MaterialTheme.colorScheme
    val onlyRest = pv.lv >= 2 || items.isEmpty()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Libur dadakan · ${SessionAdjust.dlabel(pv.src)}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("${pv.src.title} · ${SessionAdjust.ds(pv.src.km)} km", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("sibuk", "capek", "sakit", "lain").forEach { k ->
                        FilterChip(selected = why == k, onClick = { why = k }, label = { Text(SessionAdjust.WHY_LABEL[k] ?: k) })
                    }
                }
                if (pv.lv >= 2) {
                    val reasons = listOfNotNull(
                        if (cond.pain) "ada nyeri aktif" else null,
                        if (cond.score >= 0 && cond.score < cond.swapTh) "skor kesiapan ${cond.score} rendah" else null,
                        if (why == "sakit") "alasan sakit/nyeri" else null,
                    ).joinToString(", ")
                    Text("Km tidak dibagi karena $reasons. Menambah beban ke hari lain berlawanan dengan alasan libur ini. Istirahat dulu; mulai lagi dengan easy.", color = cs.error, style = MaterialTheme.typography.bodySmall)
                } else {
                    if (pv.lv == 1) Text(
                        "Kondisi belum prima${if (cond.score >= 0) " (skor kesiapan ${cond.score})" else ""}${if (why == "capek") " dan alasan capek" else ""}, jadi batas tambahan tiap hari dipotong setengah.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    if (items.isEmpty()) Text("Tidak ada hari tujuan yang aman di minggu ini. Libur ini dicatat tanpa membagi km.", style = MaterialTheme.typography.bodySmall)
                    items.forEachIndexed { i, q ->
                        val typed = manual[i]?.replace(',', '.')?.toDoubleOrNull()
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(SessionAdjust.dlabel(q.c) + if (q.nx) " · minggu depan" else "")
                                Text(
                                    "${q.c.title} · ${SessionAdjust.ds(q.c.km)} km · " + if (q.done) "sudah dilari" else "maks +${SessionAdjust.ds(q.cap)} km",
                                    style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                                )
                                if (typed != null && typed != q.x) Text("dibatasi ke ${SessionAdjust.ds(q.x)} km", style = MaterialTheme.typography.bodySmall, color = cs.error)
                            }
                            OutlinedTextField(
                                value = manual[i] ?: SessionAdjust.ds(pv.items[i].x),
                                onValueChange = { v -> manual = manual.toMutableMap().apply { put(i, v) } },
                                modifier = Modifier.width(96.dp), singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                label = { Text("+ km") },
                            )
                        }
                    }
                    if (pv.hasNext) Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = next, onCheckedChange = { next = it })
                        Text("Sisa boleh ke easy minggu depan (maks. +10% dari total minggu itu)", style = MaterialTheme.typography.bodySmall)
                    }
                }
                Text(
                    if (pv.lv >= 2) "Km tidak dibagi: ${SessionAdjust.ds(pv.km)} km tidak dikejar."
                    else "Dibagi ${SessionAdjust.ds(total)} dari ${SessionAdjust.ds(pv.km)} km. " + if (left >= .5) "Sisa ${SessionAdjust.ds(left)} km tidak dikejar." else "Semua tertampung.",
                    style = MaterialTheme.typography.bodyMedium,
                )
                val hist = SessionAdjust.spHistory(mv, inp.today).filter { it.first != date.toString() }.take(5)
                if (hist.isNotEmpty()) {
                    Text("Libur dadakan terakhir", style = MaterialTheme.typography.labelMedium, color = cs.primary)
                    hist.forEach { (k, e) ->
                        Text("$k · ${SessionAdjust.WHY_LABEL[e.why]?.let { "$it · " } ?: ""}${SessionAdjust.ds(e.km)} km → " + if (e.spread.isEmpty()) "tidak dikejar" else "dibagi", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onApply(
                    MvEntry(
                        "spread", why = why, km = pv.km, f = if (pv.lv == 1) .5 else 1.0,
                        spread = if (pv.lv >= 2) emptyList() else items.filter { it.x > 0 }.map { it.c.date.toString() to it.x },
                    ),
                )
            }) { Text(if (onlyRest) "Libur saja" else "Terapkan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
    )
}

private fun phaseLabel(p: String, rec: Boolean) = when {
    rec -> "Pemulihan"; p == Phases.BASE -> "BASE"; p == Phases.BUILD -> "BUILD"; p == Phases.PEAK -> "PEAK"; else -> "TAPER"
}
