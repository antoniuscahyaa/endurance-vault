package com.endurancevault.app.ui.screens

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import android.widget.VideoView
import android.view.View
import android.graphics.Canvas as AndroidCanvas
import android.widget.FrameLayout
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.endurancevault.app.domain.HudVideoPrefs
import com.endurancevault.app.domain.RouteVideoTrack
import com.endurancevault.app.ui.video.HudVideoEncoder
import com.endurancevault.app.ui.video.HudVideoOverlay
import com.endurancevault.app.ui.video.RouteVideoIo
import java.io.File
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt
import kotlin.math.max
import kotlin.math.min

@Composable
fun HudVideoEditor(track: RouteVideoTrack, activityStartEpochMs: Long?, onBack: () -> Unit, modifier: Modifier = Modifier) {
    val context= LocalContext.current
    val scope= rememberCoroutineScope()
    val prefsStore= remember { context.getSharedPreferences("hud_video_native",Context.MODE_PRIVATE) }
    var prefs by remember { mutableStateOf(HudVideoPrefs(
        style=prefsStore.getString("style","two") ?: "two",
        format=prefsStore.getString("format","mp4") ?: "mp4",
        accent=prefsStore.getString("accent","#FF6A13") ?: "#FF6A13",
        showMap=prefsStore.getBoolean("map",true),showGauge=prefsStore.getBoolean("gauge",true),
        dim=prefsStore.getInt("dim",25),keepAudio=prefsStore.getBoolean("audio",true),
    ).sanitized()) }
    fun update(p:HudVideoPrefs){prefs=p.sanitized();prefsStore.edit().putString("style",prefs.style).putString("format",prefs.format).putString("accent",prefs.accent).putBoolean("map",prefs.showMap).putBoolean("gauge",prefs.showGauge).putInt("dim",prefs.dim).putBoolean("audio",prefs.keepAudio).apply()}
    var uri by remember { mutableStateOf<Uri?>(null) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var positionMs by remember { mutableLongStateOf(0L) }
    var offset by remember { mutableIntStateOf(0) }
    var videoView by remember { mutableStateOf<VideoView?>(null) }
    var overlayView by remember { mutableStateOf<HudOverlayPreviewView?>(null) }
    var scrubbing by remember { mutableStateOf(false) }
    var prepared by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(false) }
    var exporting by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var message by remember { mutableStateOf("") }
    var output by remember { mutableStateOf<File?>(null) }
    val cancelled=remember { AtomicBoolean(false) }

    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){ selected->
        if(selected!=null){
            runCatching { context.contentResolver.takePersistableUriPermission(selected,android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            uri=selected;durationMs=0;positionMs=0;prepared=false;playing=false;offset=0;message="Video dipilih. Menyiapkan preview…";output=null
        }
    }

    LaunchedEffect(uri){
        val u=uri ?: return@LaunchedEffect
        val retriever=MediaMetadataRetriever()
        try{
            retriever.setDataSource(context,u)
            durationMs=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?:0L
        }catch(e:Throwable){message="Metadata video tidak dapat dibaca: ${e.message}"}
        finally{runCatching{retriever.release()}}
    }
    LaunchedEffect(uri,videoView){
        while(uri!=null){
            val vv=videoView
            if(vv!=null&&prepared){
                if (!scrubbing) positionMs=vv.currentPosition.toLong()
                playing=vv.isPlaying
            }
            delay(200)
        }
    }

    val values=HudVideoOverlay.values(track,positionMs/1000.0,offset)
    SideEffect { overlayView?.update(track, positionMs / 1000.0, offset, prefs) }
    Column(modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=8.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        Row(verticalAlignment=Alignment.CenterVertically){
            TextButton(onClick=onBack){Text("‹ Kembali")}
            Text("HUD Video",style=MaterialTheme.typography.titleLarge)
        }
        Box(Modifier.fillMaxWidth().weight(.8f).clip(RoundedCornerShape(14.dp)).background(Color.Black),contentAlignment=Alignment.Center){
            val selectedUri = uri
            if(selectedUri!=null){
                AndroidView(
                    factory={ctx->
                        FrameLayout(ctx).also { container ->
                            val vv = VideoView(ctx).also { player ->
                                videoView=player
                                player.tag=selectedUri
                                player.setVideoURI(selectedUri)
                                player.setOnPreparedListener { mp -> durationMs=mp.duration.toLong();prepared=true;message="";mp.isLooping=true }
                                player.setOnCompletionListener { playing=false }
                            }
                            val overlay = HudOverlayPreviewView(ctx).also { it.update(track, positionMs/1000.0, offset, prefs); overlayView=it }
                            container.addView(vv, FrameLayout.LayoutParams(-1,-1))
                            container.addView(overlay, FrameLayout.LayoutParams(-1,-1))
                        }
                    },
                    update={container->
                        val vv=container.getChildAt(0) as? VideoView
                        if(vv?.tag!=selectedUri){vv?.tag=selectedUri;vv?.setVideoURI(selectedUri);vv?.setOnPreparedListener{mp->durationMs=mp.duration.toLong();prepared=true;mp.isLooping=true}}
                        (container.getChildAt(1) as? HudOverlayPreviewView)?.update(track,positionMs/1000.0,offset,prefs)
                    },
                    modifier=Modifier.fillMaxSize(),
                )
            }else Text("Pilih video POV untuk memulai",color=Color.White)
        }
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp),verticalAlignment=Alignment.CenterVertically){
            Button(onClick={picker.launch(arrayOf("video/*"))}){Text(if(uri==null)"Pilih video POV" else "Ganti video")}
            if(uri!=null){
                OutlinedButton(onClick={
                    val target=(positionMs-1000L).coerceAtLeast(0L);positionMs=target;videoView?.seekTo(target.toInt())
                },enabled=prepared){Text("−1s")}
                Button(onClick={if(playing)videoView?.pause() else videoView?.start()},enabled=prepared){Text(if(playing)"Pause" else "Putar")}
                OutlinedButton(onClick={
                    val target=(positionMs+1000L).coerceAtMost(durationMs);positionMs=target;videoView?.seekTo(target.toInt())
                },enabled=prepared){Text("+1s")}
            }
        }
        if(uri!=null&&durationMs>0){
            Column(verticalArrangement=Arrangement.spacedBy(2.dp)){
                Slider(
                    value=positionMs.toFloat().coerceIn(0f,durationMs.toFloat()),
                    onValueChange={scrubbing=true;positionMs=it.toLong();overlayView?.update(track,positionMs/1000.0,offset,prefs)},
                    onValueChangeFinished={videoView?.seekTo(positionMs.toInt());scrubbing=false},
                    valueRange=0f..durationMs.toFloat(),
                )
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
                    Text(formatTimeline(positionMs),style=MaterialTheme.typography.labelSmall)
                    Text(if(playing)"LIVE PREVIEW" else "PREVIEW PAUSED",style=MaterialTheme.typography.labelSmall,color=if(playing)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(formatTimeline(durationMs),style=MaterialTheme.typography.labelSmall)
                }
                Text("Sinkron saat ini: menit ${formatDuration(values.elapsedSec)} · km ${"%.2f".format(values.km)}",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(12.dp)){
            Text("Sinkronisasi video dengan aktivitas",style=MaterialTheme.typography.titleMedium)
            Text("Offset: ${if(offset>=0)"+" else ""}${offset} detik · aktivitas mulai di km ${"%.2f".format(HudVideoOverlay.values(track,0.0,offset).km)}",style=MaterialTheme.typography.bodySmall)
            Slider(value=offset.toFloat(),onValueChange={offset=it.roundToInt()},valueRange=-120f..track.totalSec.coerceAtLeast(60).toFloat())
            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
                listOf(-10,-1,1,10).forEach{delta->OutlinedButton(onClick={offset=(offset+delta).coerceIn(-120,track.totalSec)}){Text("${if(delta>0)"+" else ""}$delta dtk")}}
                OutlinedButton(onClick={
                    val guess=guessOffset(context,uri,durationMs,activityStartEpochMs,track.totalSec)
                    if(guess!=null){offset=guess;message="Sinkronisasi otomatis diterapkan."}else message="Jam file tidak cukup akurat untuk menebak sinkronisasi. Atur offset manual."
                },enabled=uri!=null){Text("Tebak dari waktu file")}
            }
            Divider()
            Text("Format ekspor",style=MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                FilterChip(selected=prefs.format=="mp4",onClick={update(prefs.copy(format="mp4"))},label={Text("MP4 H.264")})
                FilterChip(selected=prefs.format=="rec",onClick={update(prefs.copy(format="rec"))},label={Text("Live recorder")})
            }
            Text(if(prefs.format=="mp4")"Encoding H.264 langsung melalui MediaCodec." else "Mode recorder memakai encoder video perangkat; kompatibilitas mengikuti kemampuan HP.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Gaya HUD",style=MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                FilterChip(selected=prefs.style=="two",onClick={update(prefs.copy(style="two"))},label={Text("Dua kolom")})
                FilterChip(selected=prefs.style=="min",onClick={update(prefs.copy(style="min"))},label={Text("Minimal")})
            }
            Text("Warna aksen",style=MaterialTheme.typography.labelMedium)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                listOf("#FF6A13" to "Orange","#CBFD00" to "Lime","#27D3FF" to "Biru","#FFFFFF" to "Putih").forEach{(hex,label)->
                    FilterChip(selected=prefs.accent==hex,onClick={update(prefs.copy(accent=hex))},label={Text(label)})
                }
            }
            OutlinedTextField(value=prefs.accent,onValueChange={if(it.matches(Regex("#[0-9a-fA-F]{6}")))update(prefs.copy(accent=it))},label={Text("Warna kustom #RRGGBB · tempel kode lengkap")},singleLine=true,modifier=Modifier.fillMaxWidth())
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                FilterChip(selected=prefs.showMap,enabled=track.hasGpsRoute,onClick={update(prefs.copy(showMap=!prefs.showMap))},label={Text("Minimap rute")})
                FilterChip(selected=prefs.showGauge,onClick={update(prefs.copy(showGauge=!prefs.showGauge))},label={Text("Gauge kecepatan")})
                FilterChip(selected=prefs.keepAudio,onClick={update(prefs.copy(keepAudio=!prefs.keepAudio))},label={Text("Audio asli")})
            }
            Text("Peredam gelap: ${prefs.dim}%",style=MaterialTheme.typography.labelMedium)
            Slider(value=prefs.dim.toFloat(),onValueChange={update(prefs.copy(dim=it.roundToInt()))},valueRange=0f..60f)
            if(exporting){
                LinearProgressIndicator(progress={progress},modifier=Modifier.fillMaxWidth())
                Text("Mengekspor ${if(prefs.format=="mp4")"MP4 H.264" else "live recorder"}… ${(progress*100).roundToInt()}%",style=MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick={cancelled.set(true)}){Text("Batalkan ekspor")}
            }else{
                Button(onClick={
                    val u=uri ?: return@Button
                    cancelled.set(false);exporting=true;progress=0f;message="Menyiapkan ekspor…";output=null
                    scope.launch{
                        val file=File(context.cacheDir,"hud-${System.currentTimeMillis()}.mp4")
                        val result=withContext(Dispatchers.IO){HudVideoEncoder.encode(context,u,track,offset,prefs,file,{!cancelled.get()}){progress=it}}
                        exporting=false
                        result.onSuccess{
                            val saved=withContext(Dispatchers.IO){RouteVideoIo.saveToGallery(context,file,file.name).getOrNull()}
                            output=file
                            message=if(saved!=null)"Video HUD tersimpan di $saved" else "MP4 selesai dibuat, tetapi gagal menyalin ke galeri."
                        }.onFailure{message=if(it is java.util.concurrent.CancellationException)"Ekspor dibatalkan." else "Ekspor gagal: ${it.message}"}
                    }
                },enabled=uri!=null&&prepared,modifier=Modifier.fillMaxWidth()){Text(if(prefs.format=="mp4")"Ekspor video HUD · MP4 H.264" else "Ekspor video HUD · Live recorder")}
            }
            if (output != null) {
                OutlinedButton(onClick = { RouteVideoIo.share(context, output!!).onFailure { message = "Gagal membagikan: ${it.message}" } }) { Text("Bagikan video HUD") }
            }
            if(message.isNotBlank()) Text(message,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable private fun HudValue(label:String,value:String,unit:String){
    Row(verticalAlignment=Alignment.Bottom,horizontalArrangement=Arrangement.spacedBy(3.dp)){
        Text(value,color=Color.White,style=MaterialTheme.typography.titleLarge)
        Text(unit,color=Color.White.copy(alpha=.8f),style=MaterialTheme.typography.labelSmall)
    }
    Text(label,color=Color.White.copy(alpha=.8f),style=MaterialTheme.typography.labelSmall)
}
@Composable private fun HudMiniPreview(track:RouteVideoTrack,km:Double,accent:String){
    val ac=runCatching{Color(android.graphics.Color.parseColor(accent))}.getOrDefault(Color(0xFFFF6A13))
    androidx.compose.foundation.Canvas(Modifier.size(width=108.dp,height=76.dp).background(Color.Black.copy(alpha=.35f),RoundedCornerShape(8.dp)).padding(5.dp)){
        val xs=track.lon;val ys=track.lat;val minX=xs.minOrNull()?:0.0;val maxX=xs.maxOrNull()?:1.0;val minY=ys.minOrNull()?:0.0;val maxY=ys.maxOrNull()?:1.0
        val scale=min(size.width/max(1e-9,maxX-minX).toFloat(),size.height/max(1e-9,maxY-minY).toFloat())
        val x0=(size.width-(maxX-minX).toFloat()*scale)/2;val y0=(size.height-(maxY-minY).toFloat()*scale)/2
        fun xx(i:Int)=x0+(xs[i]-minX).toFloat()*scale
        fun yy(i:Int)=y0+(maxY-ys[i]).toFloat()*scale
        val idx=track.dist.indexOfLast{it<=km*1000}.coerceIn(0,track.n-1)
        val path=androidx.compose.ui.graphics.Path()
        for(i in 0 until track.n){if(i==0)path.moveTo(xx(i),yy(i))else path.lineTo(xx(i),yy(i))}
        drawPath(path,Color.White.copy(alpha=.65f),style=androidx.compose.ui.graphics.drawscope.Stroke(1.5.dp.toPx()))
        val done=androidx.compose.ui.graphics.Path()
        for(i in 0..idx){if(i==0)done.moveTo(xx(i),yy(i))else done.lineTo(xx(i),yy(i))}
        drawPath(done,ac,style=androidx.compose.ui.graphics.drawscope.Stroke(3.dp.toPx()))
        drawCircle(Color.White,3.dp.toPx(),androidx.compose.ui.geometry.Offset(xx(idx),yy(idx)))
    }
}
private fun formatDuration(sec:Int):String{val h=sec/3600;val m=sec%3600/60;val s=sec%60;return if(h>0)String.format("%02d:%02d",h,m)else String.format("%02d:%02d",m,s)}
private fun guessOffset(context:Context,uri:Uri?,durationMs:Long,startMs:Long?,maxSec:Int):Int?{
    val u=uri?:return null;val t0=startMs?:return null;if(durationMs<=0)return null
    val modified=runCatching{context.contentResolver.query(u,arrayOf(MediaStore.MediaColumns.DATE_MODIFIED),null,null,null)?.use{c->if(c.moveToFirst())c.getLong(0)*1000L else 0L}?:0L}.getOrDefault(0L)
    if(modified<=0)return null
    val off=((modified-durationMs-t0)/1000L).toInt()
    return off.takeIf{it in -120..maxSec}
}


/** Uses the same Canvas renderer as MP4 export, so the editor preview and exported HUD stay visually aligned. */
private class HudOverlayPreviewView(context: Context) : View(context) {
    private var track: RouteVideoTrack? = null
    private var videoSec: Double = 0.0
    private var offsetSec: Int = 0
    private var prefs: HudVideoPrefs = HudVideoPrefs()

    fun update(track: RouteVideoTrack, videoSec: Double, offsetSec: Int, prefs: HudVideoPrefs) {
        this.track = track
        this.videoSec = videoSec
        this.offsetSec = offsetSec
        this.prefs = prefs
        invalidate()
    }

    override fun onDraw(canvas: AndroidCanvas) {
        super.onDraw(canvas)
        val t = track ?: return
        if (width <= 0 || height <= 0) return
        HudVideoOverlay.drawOverlay(canvas, width, height, t, videoSec, offsetSec, prefs)
    }
}

private fun formatTimeline(ms: Long): String {
    val total = (ms.coerceAtLeast(0L) / 1000L).toInt()
    val hours = total / 3600
    val minutes = total % 3600 / 60
    val seconds = total % 60
    return if (hours > 0) String.format("%02d:%02d:%02d", hours, minutes, seconds)
    else String.format("%02d:%02d", minutes, seconds)
}
