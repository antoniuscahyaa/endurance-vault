package com.endurancevault.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.endurancevault.app.ui.AppRoot
import com.endurancevault.app.ui.theme.EnduranceVaultTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { EnduranceVaultTheme { AppRoot() } }
    }
}
