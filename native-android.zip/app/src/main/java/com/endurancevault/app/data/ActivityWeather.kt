package com.endurancevault.app.data

import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneOffset
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * Cuaca per sesi lari dari Open-Meteo: arsip (reanalisis) untuk sesi lama, prakiraan/analisis untuk sesi 85 hari terakhir.
 * Hasilnya berupa objek `wx` format web (t, fl, h, w, r, c) ditambah kunci baru: wd arah angin, g hembusan, cl awan, p tekanan,
 * dp titik embun, uo selisih UTC (detik), hh deret per jam (t epoch detik, c suhu, r hujan, k kode, w angin, ir 1 = jam di dalam sesi).
 */
object ActivityWeather {
    private const val UA = "EnduranceVault/0.5.88 (Android; personal fitness tracker)"
    private const val VARS = "temperature_2m,apparent_temperature,relative_humidity_2m,dew_point_2m,precipitation,weather_code," +
        "cloud_cover,surface_pressure,wind_speed_10m,wind_direction_10m,wind_gusts_10m"

    /** @param startSec detik epoch awal sesi; @param durSec lama sesi (detik). Null bila jaringan/respons gagal. */
    suspend fun fetch(lat: Double, lon: Double, startSec: Long, durSec: Int): Map<String, Any?>? = withContext(Dispatchers.IO) {
        if (!lat.isFinite() || !lon.isFinite() || startSec <= 0) return@withContext null
        val endSec = startSec + max(durSec, 600)
        val d0 = Instant.ofEpochSecond(startSec - 86400).atZone(ZoneOffset.UTC).toLocalDate()
        val d1 = Instant.ofEpochSecond(endSec + 86400).atZone(ZoneOffset.UTC).toLocalDate()
        val ageDays = (System.currentTimeMillis() / 1000 - startSec) / 86400
        val host = if (ageDays > 85) "https://archive-api.open-meteo.com/v1/archive" else "https://api.open-meteo.com/v1/forecast"
        val url = host + "?" + String.format(
            Locale.ROOT, "latitude=%.4f&longitude=%.4f&start_date=%s&end_date=%s&hourly=%s&timezone=auto&wind_speed_unit=kmh",
            lat, lon, d0, d1, VARS,
        )
        var conn: HttpURLConnection? = null
        try {
            conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 10_000; readTimeout = 20_000
                setRequestProperty("User-Agent", UA)
            }
            if (conn.responseCode != 200) return@withContext null
            parse(JSONObject(conn.inputStream.bufferedReader().use { it.readText() }), startSec, endSec)
        } catch (_: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    internal fun parse(root: JSONObject, startSec: Long, endSec: Long): Map<String, Any?>? {
        val off = root.optInt("utc_offset_seconds", 0)
        val h = root.optJSONObject("hourly") ?: return null
        val times = h.optJSONArray("time") ?: return null
        fun arr(k: String): JSONArray? = h.optJSONArray(k)
        fun v(a: JSONArray?, i: Int): Double? = if (a == null || a.isNull(i)) null else a.optDouble(i).takeIf { it.isFinite() }
        val aT = arr("temperature_2m"); val aF = arr("apparent_temperature"); val aH = arr("relative_humidity_2m"); val aD = arr("dew_point_2m")
        val aR = arr("precipitation"); val aC = arr("weather_code"); val aK = arr("cloud_cover"); val aP = arr("surface_pressure")
        val aW = arr("wind_speed_10m"); val aB = arr("wind_direction_10m"); val aG = arr("wind_gusts_10m")

        class H(val t: Long, val ov: Double, val i: Int)
        val hours = ArrayList<H>()
        for (i in 0 until times.length()) {
            val t = runCatching { LocalDateTime.parse(times.getString(i)).toEpochSecond(ZoneOffset.UTC) - off }.getOrNull() ?: continue
            hours.add(H(t, max(0L, min(t + 3600, endSec) - max(t, startSec)).toDouble(), i))
        }
        val inside = hours.filter { it.ov > 0 && v(aT, it.i) != null }
        if (inside.isEmpty()) return null
        val wsum = inside.sumOf { it.ov }

        fun avg(a: JSONArray?): Double? {
            var s = 0.0; var w = 0.0
            for (x in inside) { val y = v(a, x.i) ?: continue; s += y * x.ov; w += x.ov }
            return if (w > 0) s / w else null
        }
        fun r1(x: Double) = Math.round(x * 10) / 10.0

        val rain = inside.sumOf { (v(aR, it.i) ?: 0.0) * (it.ov / 3600.0) }
        // Arah angin: rata-rata vektor berbobot kecepatan, supaya 350° dan 10° tidak menjadi 180°.
        var sx = 0.0; var sy = 0.0
        for (x in inside) {
            val dir = v(aB, x.i) ?: continue; val sp = (v(aW, x.i) ?: 0.0).coerceAtLeast(0.1) * x.ov
            sx += sin(Math.toRadians(dir)) * sp; sy += cos(Math.toRadians(dir)) * sp
        }
        val wd = if (sx != 0.0 || sy != 0.0) ((Math.toDegrees(atan2(sx, sy)) + 360) % 360).toInt() else null
        val code = inside.maxByOrNull { it.ov }?.let { v(aC, it.i)?.toInt() }
        val gust = inside.mapNotNull { v(aG, it.i) }.maxOrNull()

        val out = LinkedHashMap<String, Any?>()
        out["t"] = r1(avg(aT) ?: return null)
        avg(aF)?.let { out["fl"] = r1(it) }
        avg(aH)?.let { out["h"] = Math.round(it).toInt() }
        avg(aW)?.let { out["w"] = r1(it) }
        out["r"] = r1(rain)
        code?.let { out["c"] = it }
        wd?.let { out["wd"] = it }
        gust?.let { out["g"] = r1(it) }
        avg(aK)?.let { out["cl"] = Math.round(it).toInt() }
        avg(aP)?.let { out["p"] = Math.round(it).toInt() }
        avg(aD)?.let { out["dp"] = r1(it) }
        out["uo"] = off
        out["src"] = "open-meteo"
        // Deret per jam: jam sesi ditambah satu jam konteks di kiri dan kanan.
        val first = hours.indexOfFirst { it.ov > 0 }; val last = hours.indexOfLast { it.ov > 0 }
        if (first >= 0) {
            val lo = max(0, first - 1); val hi = min(hours.lastIndex, last + 1)
            out["hh"] = (lo..hi).mapNotNull { k ->
                val x = hours[k]; val tmp = v(aT, x.i) ?: return@mapNotNull null
                mapOf(
                    "t" to x.t, "c" to r1(tmp), "r" to r1(v(aR, x.i) ?: 0.0), "k" to v(aC, x.i)?.toInt(),
                    "w" to r1(v(aW, x.i) ?: 0.0), "ir" to if (x.ov > 0) 1 else 0,
                )
            }
        }
        return out
    }
}
