package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.i18n.Text
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Watch
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntRect
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupPositionProvider
import androidx.compose.ui.window.PopupProperties
import kotlinx.coroutines.delay
import com.endurancevault.app.data.WatchDockUi
import com.endurancevault.app.domain.WatchDock

/**
 * Ringkasan status jam untuk tempat-tempat di luar tab Jam: kartu di Pengaturan dan pil di bawah nama pada header.
 * [state] null = belum diketahui (abu-abu). [conn] true = jam sedang terhubung, jadi ketukan titik langsung menyinkron.
 */
internal data class WatchBadge(
    val title: String,
    val summary: String,
    val battery: Int?,
    val state: WatchDock.SyncState?,
    val conn: Boolean,
    /** Epoch detik sinkron terakhir (null = belum pernah) dan zona jam untuk menampilkan jam. */
    val lastSyncSec: Long? = null,
    val tzMin: Int = 0,
)

internal fun watchBadgeOf(ui: WatchDockUi, syncing: Boolean, lastSyncJsSec: Long, alias: String): WatchBadge? = when (ui) {
    is WatchDockUi.Unsupported -> null
    is WatchDockUi.Loading -> WatchBadge(alias.ifBlank { "Jam" }, "Membaca data jam…", null, null, false)
    is WatchDockUi.Failed -> WatchBadge(alias.ifBlank { "Jam" }, "Gagal membaca data jam", null, WatchDock.SyncState.OFF, false)
    is WatchDockUi.Ready -> {
        val m = ui.model
        val st = WatchDock.syncState(m, syncing, lastSyncJsSec)
        val link = when {
            st == WatchDock.SyncState.SYNC -> "Menyinkron…"
            m.conn -> "Terhubung"
            else -> "Terputus"
        }
        val bat = m.battery?.let { " · Baterai $it%" } ?: ""
        val ts = maxOf(m.lastSyncAt ?: 0L, lastSyncJsSec)
        val sync = if (ts > 0 && st != WatchDock.SyncState.SYNC) " · Sinkron ${WatchDock.ago(m.now, ts)}" else ""
        WatchBadge(alias.ifBlank { m.devName.ifBlank { "Jam Huawei" } }, link + bat + sync, m.battery, st, m.conn, ts.takeIf { it > 0 }, m.tzMin)
    }
}

private fun dotColor(s: WatchDock.SyncState?): Color = when (s) {
    WatchDock.SyncState.OK -> Color(0xFF3FB67A)
    WatchDock.SyncState.WARN -> Color(0xFFE0A526)
    WatchDock.SyncState.SYNC -> Color(0xFF4F8CFF)
    WatchDock.SyncState.OFF -> Color(0xFFE5534B)
    null -> Color(0xFF9AA0A6)
}

private fun dotLabel(s: WatchDock.SyncState?): String = when (s) {
    WatchDock.SyncState.OK -> "Tersinkron"
    WatchDock.SyncState.WARN -> "Sinkron lama"
    WatchDock.SyncState.SYNC -> "Menyinkron"
    WatchDock.SyncState.OFF -> "Terputus"
    null -> "Status jam belum diketahui"
}

/** Lingkaran status; berkedip pelan selama sinkron berjalan. */
@Composable
internal fun WatchDot(state: WatchDock.SyncState?, size: Dp, modifier: Modifier = Modifier) {
    val a = if (state == WatchDock.SyncState.SYNC) {
        rememberInfiniteTransition(label = "watchDot").animateFloat(
            initialValue = 0.35f, targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "watchDotAlpha",
        ).value
    } else 1f
    Box(modifier.size(size).alpha(a).clip(CircleShape).background(dotColor(state)))
}

private class BelowAnchor(private val gapPx: Int) : PopupPositionProvider {
    override fun calculatePosition(anchorBounds: IntRect, windowSize: IntSize, layoutDirection: LayoutDirection, popupContentSize: IntSize): IntOffset {
        val x = anchorBounds.left.coerceIn(0, (windowSize.width - popupContentSize.width).coerceAtLeast(0))
        return IntOffset(x, anchorBounds.bottom + gapPx)
    }
}

/**
 * Pil kecil di samping pill Recovery: titik status sinkron + persen baterai. Hanya informasi: diketuk memunculkan balon
 * mengambang berisi jam dan waktu relatif sinkron terakhir (hilang sendiri setelah 4 detik atau saat layar disentuh).
 * Sinkron manual tetap lewat titik di kartu Jam di Pengaturan.
 */
@Composable
internal fun WatchHeaderPill(badge: WatchBadge) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(24.dp)
    var show by remember { mutableStateOf(false) }
    LaunchedEffect(show) { if (show) { delay(4000); show = false } }
    Box {
        Surface(
            shape = shape,
            color = cs.surfaceVariant,
            border = BorderStroke(0.8.dp, cs.outlineVariant),
            modifier = Modifier.clip(shape).clickable { show = !show }
                .semantics { contentDescription = "${dotLabel(badge.state)}, baterai jam ${badge.battery ?: "tidak diketahui"}. Ketuk untuk melihat sinkron terakhir" },
        ) {
            Row(
                Modifier.padding(horizontal = 11.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                WatchDot(badge.state, 8.dp)
                Text(
                    badge.battery?.let { "$it%" } ?: "–",
                    style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, maxLines = 1,
                )
            }
        }
        if (show) {
            val gap = with(LocalDensity.current) { 6.dp.roundToPx() }
            Popup(popupPositionProvider = BelowAnchor(gap), onDismissRequest = { show = false }, properties = PopupProperties(focusable = true)) {
                val nowSec = System.currentTimeMillis() / 1000
                val ts = badge.lastSyncSec
                Surface(
                    shape = RoundedCornerShape(12.dp), color = cs.surface, tonalElevation = 3.dp, shadowElevation = 6.dp,
                    border = BorderStroke(0.8.dp, cs.outlineVariant),
                ) {
                    Column(Modifier.padding(horizontal = 12.dp, vertical = 9.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("Sinkron terakhir", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                        Text(
                            when {
                                badge.state == WatchDock.SyncState.SYNC -> "Sedang menyinkron…"
                                ts != null -> WatchDock.clock(ts, badge.tzMin) + " · " + WatchDock.ago(nowSec, ts)
                                else -> "Belum pernah sinkron"
                            },
                            style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold,
                        )
                        if (!badge.conn && badge.state != WatchDock.SyncState.SYNC) {
                            Text("Jam sedang terputus", style = MaterialTheme.typography.labelSmall, color = cs.error)
                        }
                    }
                }
            }
        }
    }
}
