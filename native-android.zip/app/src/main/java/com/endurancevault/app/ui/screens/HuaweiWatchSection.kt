package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.i18n.Text
import android.Manifest
import android.bluetooth.BluetoothManager
import android.content.Context
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import com.endurancevault.app.domain.StepIntensity
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import com.rencanalari.huaweiwatch.ProtocolBridge
import com.rencanalari.huaweiwatch.KeepAliveConfig
import org.json.JSONObject
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.material3.Switch
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.IconButton
import androidx.compose.material.icons.outlined.Info
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.Icon
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import com.endurancevault.app.domain.PlanSettings

private data class BondedWatch(val name: String, val address: String)

@Composable
fun HuaweiWatchSection(
    message: String,
    onConnect: (String) -> Unit,
    onDisconnect: () -> Unit,
    onForgetAndReconnect: (String) -> Unit,
    onSync: (Boolean) -> Unit,
    isSyncing: Boolean,
    settings: PlanSettings,
    advancedMessage: String,
    onSyncHrZones: (PlanSettings) -> Unit,
    onPushWorkout: (String, Int, Int, Int, Int, Int, com.endurancevault.app.domain.WorkoutTargets) -> Unit,
    onSaveSettings: (PlanSettings) -> Unit = {},
    daily: List<com.endurancevault.app.data.DailyEntity> = emptyList(),
    showZoneEditor: Boolean = true,
    agpsContent: @Composable () -> Unit = {},
    notifyContent: @Composable () -> Unit = {},
) {
    val context = LocalContext.current
    var devices by remember { mutableStateOf<List<BondedWatch>>(emptyList()) }
    var warningAccepted by remember { mutableStateOf(false) }
    var accountId by remember { mutableStateOf("") }
    var accountHint by remember { mutableStateOf<String?>(null) }
    var accountSaved by remember { mutableStateOf(false) }
    var discoveryMessage by remember { mutableStateOf("Perangkat belum diperiksa.") }
    var protocolStatus by remember { mutableStateOf<JSONObject?>(null) }
    var keepInterval by remember { mutableStateOf(KeepAliveConfig.intervalMin(context).toString()) }
    var lowBattery by remember { mutableStateOf(KeepAliveConfig.lowBatteryPct(context).toString()) }
    var keepAliveWanted by remember { mutableStateOf(KeepAliveConfig.wanted(context)) }
    var keepAliveMessage by remember { mutableStateOf("Penjagaan latar ${if (KeepAliveConfig.wanted(context)) "diaktifkan" else "nonaktif"}.") }
    var forgetTarget by remember { mutableStateOf<BondedWatch?>(null) }
    var courseName by remember { mutableStateOf("EnduranceVault Interval") }
    var warmup by remember { mutableStateOf("10") }
    var repeats by remember { mutableStateOf("4") }
    var runMin by remember { mutableStateOf("4") }
    var recovery by remember { mutableStateOf("2") }
    var cooldown by remember { mutableStateOf("10") }
    // Target intensitas per langkah (opsional); default tanpa target seperti sebelumnya.
    var warmupTarget by remember { mutableStateOf(TargetUi()) }
    var runTarget by remember { mutableStateOf(TargetUi()) }
    var recoveryTarget by remember { mutableStateOf(TargetUi()) }
    var cooldownTarget by remember { mutableStateOf(TargetUi()) }
    // Batas zona HR yang berlaku (setelan zona di aplikasi: LTHR atau HRR), dalam bentuk yang sama dengan yang dikirim ke jam.
    val zoneCuts = remember(settings, daily) { com.endurancevault.app.domain.Zones.cuts(settings, restHrFrom(daily).first) }
    val zoneLower = remember(zoneCuts) { com.endurancevault.app.domain.StructuredWorkout.watchLowerBounds(zoneCuts.mode, zoneCuts.lo, zoneCuts.maxHr) }
    var openCard by remember { mutableStateOf("") }
    var notesOpen by remember { mutableStateOf(false) }

    fun refreshAccountStatus() {
        runCatching { ProtocolBridge.get(context).huaweiAccountInfo() }
            .onSuccess { info ->
                accountSaved = info.optBoolean("set")
                accountHint = if (accountSaved) "ID akun tersimpan di perangkat (…${info.optString("hint")})." else "Belum ada ID akun Huawei tersimpan."
            }
            .onFailure { accountHint = "Status ID akun tidak dapat dibaca: ${it.message ?: it.javaClass.simpleName}" }
    }

    fun refreshProtocolStatus() {
        protocolStatus = runCatching { ProtocolBridge.get(context).status() }.getOrNull()
    }

    LaunchedEffect(context) {
        refreshAccountStatus()
        refreshProtocolStatus()
    }
    LaunchedEffect(isSyncing, message) { refreshProtocolStatus() }
    LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(4000); refreshProtocolStatus() } }
    val isConnected = protocolStatus?.optString("state") == "connected"
    var infoOpen by remember { mutableStateOf(false) }

    fun refreshBonded() {
        try {
            val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
            val adapter = manager?.adapter
            if (adapter == null) {
                discoveryMessage = "Bluetooth tidak tersedia pada ponsel ini."
                devices = emptyList()
                return
            }
            if (!adapter.isEnabled) {
                discoveryMessage = "Bluetooth ponsel sedang mati. Aktifkan Bluetooth terlebih dahulu."
                devices = emptyList()
                return
            }
            val found = adapter.bondedDevices.orEmpty().mapNotNull { d ->
                val name = d.name ?: return@mapNotNull null
                val n = name.lowercase()
                if (n.contains("huawei") || n.contains("honor") || n.contains("watch fit") || n.contains("band")) {
                    BondedWatch(name, d.address)
                } else null
            }.sortedBy { it.name.lowercase() }
            devices = found
            discoveryMessage = if (found.isEmpty())
                "Belum ada jam Huawei/Honor yang dipasangkan di pengaturan Bluetooth Android."
            else "${found.size} perangkat terpasang ditemukan."
            refreshProtocolStatus()
        } catch (e: SecurityException) {
            discoveryMessage = "Izin Bluetooth belum diberikan. Izinkan akses perangkat terdekat lalu coba lagi."
        } catch (e: Exception) {
            discoveryMessage = "Gagal membaca perangkat: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    val permissions = buildList {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            add(Manifest.permission.BLUETOOTH_CONNECT)
            add(Manifest.permission.BLUETOOTH_SCAN)
        } else {
            add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }
    val bluetoothPermissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        listOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
    } else {
        listOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        val bluetoothGranted = bluetoothPermissions.all {
            result[it] == true || ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }
        if (bluetoothGranted) refreshBonded()
        else discoveryMessage = "Izin Bluetooth / perangkat terdekat belum diberikan. Izin notifikasi bersifat opsional."
    }

    forgetTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { forgetTarget = null },
            title = { Text("Lupakan jam & ikat ulang?") },
            text = { Text("Kunci autentikasi/pairing lama untuk ${target.name} akan dihapus, lalu aplikasi mencoba menghubungkan ulang. Huawei Health dapat terputus dari jam. Data latihan dan riwayat EnduranceVault tidak dihapus. Konfirmasi pairing pada layar jam bila diminta.") },
            confirmButton = {
                TextButton(onClick = {
                    forgetTarget = null
                    onForgetAndReconnect(target.address)
                }, enabled = !isSyncing) { Text("Lupakan & hubungkan ulang") }
            },
            dismissButton = { TextButton(onClick = { forgetTarget = null }) { Text("Batal") } },
        )
    }

    fun saveKeepAliveValues(): Boolean {
        val interval = keepInterval.toIntOrNull()
        val threshold = lowBattery.toIntOrNull()
        if (interval == null || interval !in 2..60 || threshold == null || threshold !in 0..50) {
            keepAliveMessage = "Nilai tidak valid. Interval 2–60 menit dan ambang baterai 0–50%."
            return false
        }
        KeepAliveConfig.setIntervalMin(context, interval)
        KeepAliveConfig.setLowBatteryPct(context, threshold)
        return true
    }
    fun startKeepAlive() {
        KeepAliveConfig.setWanted(context, true)
        val error = KeepAliveConfig.start(context)
        keepAliveWanted = true
        keepAliveMessage = if (error == null) "Penjagaan latar diaktifkan. Interval ${keepInterval} menit; peringatan baterai ${lowBattery}%."
            else "Pengaturan tersimpan, tetapi layanan belum dapat dimulai: $error"
    }
    fun stopKeepAlive() {
        KeepAliveConfig.setWanted(context, false)
        KeepAliveConfig.stop(context)
        keepAliveWanted = false
        keepAliveMessage = "Penjagaan latar dimatikan. Koneksi aktif tidak diputus; sinkron otomatis berhenti."
    }

    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    EvPanel(
        modifier = Modifier.fillMaxWidth(),
        containerColor = MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Huawei Watch · Bluetooth langsung", style = MaterialTheme.typography.titleLarge)
            Text(
                "Protokol langsung JoyoFit/Gadgetbridge, bukan Huawei Health.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            protocolStatus?.let { st ->
                val state = st.optString("state", "disconnected")
                val battery = st.optInt("battery", -1)
                Text(
                    "Status protokol: $state" + if (battery >= 0) " · baterai jam $battery%" else " · baterai belum dibaca",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            Text(message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { onSync(false) }, enabled = !isSyncing, modifier = Modifier.weight(1f)) { Text(if (isSyncing) "Sedang sinkron…" else "Sinkronkan") }
                OutlinedButton(onClick = onDisconnect, enabled = !isSyncing, modifier = Modifier.weight(1f)) { Text("Putuskan") }
            }
            OutlinedButton(onClick = { onSync(true) }, enabled = !isSyncing, modifier = Modifier.fillMaxWidth()) {
                Text("Sinkron riwayat penuh dari jam")
            }
            if (!isConnected) {
            androidx.compose.material3.HorizontalDivider()
            Text("Hubungkan jam baru", style = MaterialTheme.typography.titleSmall)
            WatchStep(1, "Pahami konsekuensi ikatan") {
                Text("Jam Huawei hanya dapat terikat ke satu aplikasi pendamping.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            Row {
                Checkbox(checked = warningAccepted, onCheckedChange = { warningAccepted = it })
                Text(
                    "Saya memahami konsekuensi ikatan Bluetooth langsung dan ingin melanjutkan.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 10.dp),
                )
            }
            }
            WatchStep(2, "ID akun Huawei (opsional)") {
            OutlinedTextField(
                value = accountId,
                onValueChange = { accountId = it.filter { c -> c.isDigit() }.take(19) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("ID akun Huawei (opsional)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                visualTransformation = PasswordVisualTransformation(),
            )
            OutlinedButton(
                onClick = {
                    try {
                        val clean = accountId.trim()
                        require(clean.matches(Regex("[0-9]{17,19}"))) { "Masukkan ID 17–19 angka." }
                        val bridge = ProtocolBridge.get(context)
                        bridge.setHuaweiAccount(clean)
                        accountId = ""
                        refreshAccountStatus()
                    } catch (e: Exception) {
                        accountHint = "ID tidak disimpan: ${e.message ?: e.javaClass.simpleName}"
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = accountId.trim().matches(Regex("[0-9]{17,19}")),
            ) { Text("Simpan ID akun di perangkat") }
            if (accountSaved) {
                OutlinedButton(
                    onClick = {
                        runCatching { ProtocolBridge.get(context).setHuaweiAccount("") }
                            .onSuccess { accountId = ""; refreshAccountStatus() }
                            .onFailure { accountHint = "Gagal menghapus ID: ${it.message ?: it.javaClass.simpleName}" }
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Hapus ID akun tersimpan") }
            }
            accountHint?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
            WatchStep(3, "Pilih perangkat terpasang") {
            Button(
                onClick = {
                    if (permissions.isEmpty() || permissions.all {
                            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
                        }) refreshBonded()
                    else permissionLauncher.launch(permissions.toTypedArray())
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Periksa perangkat Bluetooth terpasang") }

            Text(discoveryMessage, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            devices.forEach { watch ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(watch.name, style = MaterialTheme.typography.titleMedium)
                        Text("Perangkat sudah dipasangkan di Android", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Button(
                            onClick = { onConnect(watch.address) },
                            enabled = warningAccepted && !isSyncing,
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("Hubungkan ke EnduranceVault") }
                        OutlinedButton(
                            onClick = { forgetTarget = watch },
                            enabled = warningAccepted && !isSyncing,
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("Lupakan jam & ikat ulang") }
                    }
                }
            }
            OutlinedButton(onClick = { refreshProtocolStatus(); refreshBonded() }, modifier = Modifier.fillMaxWidth()) {
                Text("Perbarui status koneksi dan perangkat")
            }
            }
            }
            androidx.compose.material3.HorizontalDivider()
            Row(
                Modifier.fillMaxWidth().clickable { notesOpen = !notesOpen },
                horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Catatan dan batasan", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Medium)
                Icon(if (notesOpen) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (notesOpen) {
            if (!isConnected) {
            Text(
                "EnduranceVault menggunakan protokol Bluetooth langsung JoyoFit/Gadgetbridge dari proyek Rencana Lari. Bukan Huawei Health atau Health Kit. ID akun Huawei opsional hanya dipakai saat proses pairing bila jam memerlukannya; data disinkronkan langsung melalui Bluetooth.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                "Penting: jam Huawei hanya dapat terikat ke satu aplikasi pendamping. Saat ikatan langsung pertama dibuat, koneksi Huawei Health dapat terputus. Jangan lanjutkan jika kamu masih ingin Huawei Health menjadi aplikasi pendamping utama.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
            )
            Text(
                "ID akun Huawei opsional (17–19 angka). Pada sebagian jam, ID yang sama dengan akun Huawei Health dapat mencegah permintaan reset saat ikatan pertama. Simpan sebelum menghubungkan; ID disimpan lokal dan hanya petunjuk 4 digit terakhir yang ditampilkan.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            }
            Text(
                "Data workout dengan GPS diimpor sebagai aktivitas dengan rute; workout tanpa GPS sebagai ringkasan. Pengambilan workout ke jadwal dibatasi 100 sesi terbaru per sinkron penuh. HR istirahat, HRV, tidur, dan fase tidur mengisi catatan harian tanpa menimpa nilai manual.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            }
        }
    }

    EvPanel(
        modifier = Modifier.fillMaxWidth(),
        containerColor = MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Koneksi latar belakang", style = MaterialTheme.typography.titleLarge)
                        Box {
                            IconButton(onClick = { infoOpen = true }, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Outlined.Info, contentDescription = com.endurancevault.app.ui.i18n.Lang.tr("Keterangan koneksi latar belakang"), modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            DropdownMenu(expanded = infoOpen, onDismissRequest = { infoOpen = false }, modifier = Modifier.widthIn(max = 280.dp)) {
                                Text(
                                    "Saat aktif, EnduranceVault menjaga koneksi dan menyinkronkan data secara berkala melalui notifikasi layanan. Pengaturan ini tidak menjamin Android atau EMUI/HarmonyOS akan selalu mengizinkan proses berjalan; optimasi baterai ponsel mungkin tetap perlu diatur manual.",
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                                )
                            }
                        }
                    }
                }
                Switch(
                    checked = keepAliveWanted,
                    onCheckedChange = { on -> if (!on) stopKeepAlive() else if (saveKeepAliveValues()) startKeepAlive() },
                    enabled = !isSyncing,
                )
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = keepInterval,
                    onValueChange = { keepInterval = it.filter(Char::isDigit).take(2) },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    label = { Text("Interval (menit)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
                OutlinedTextField(
                    value = lowBattery,
                    onValueChange = { lowBattery = it.filter(Char::isDigit).take(2) },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    label = { Text("Baterai rendah (%)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
            }
            Text("Interval 2–60 menit, ambang baterai 0–50% (0 = mati).", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(keepAliveMessage, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(
                onClick = {
                    if (saveKeepAliveValues()) {
                        if (keepAliveWanted) startKeepAlive()
                        else keepAliveMessage = "Pengaturan tersimpan. Aktifkan saklar untuk menjaga koneksi di latar."
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = !isSyncing,
            ) { Text("Simpan pengaturan") }
        }
    }

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        FeatureTile("Zona HR", "Atur zona, kirim ke jam", openCard == "zona", Icons.Filled.Favorite, Modifier.weight(1f)) { openCard = if (openCard == "zona") "" else "zona" }
        FeatureTile("Structured workout", "Buat sesi interval", openCard == "workout", Icons.Filled.DirectionsRun, Modifier.weight(1f)) { openCard = if (openCard == "workout") "" else "workout" }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        FeatureTile("A-GPS", "Data orbit satelit", openCard == "agps", Icons.Filled.LocationOn, Modifier.weight(1f)) { openCard = if (openCard == "agps") "" else "agps" }
        FeatureTile("Notifikasi ke jam", "Teruskan dari ponsel", openCard == "notify", Icons.Filled.Notifications, Modifier.weight(1f)) { openCard = if (openCard == "notify") "" else "notify" }
    }
    if (openCard == "agps") FeaturePanel("A-GPS Huawei Watch", onClose = { openCard = "" }, content = agpsContent)
    if (openCard == "notify") FeaturePanel("Notifikasi ponsel ke jam", onClose = { openCard = "" }, content = notifyContent)

    if (openCard == "zona") {
        EvPanel(modifier = Modifier.fillMaxWidth(), containerColor = MaterialTheme.colorScheme.surfaceVariant) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Zona HR", style = MaterialTheme.typography.titleLarge)
                    TextButton(onClick = { openCard = "" }) { Text("Tutup") }
                }
                if (showZoneEditor) {
                    val (restDefault, restKnown) = restHrFrom(daily)
                    HrZoneSettings(
                        settings = settings, restDefault = restDefault, restKnown = restKnown,
                        onSave = onSaveSettings, onSendToWatch = onSyncHrZones,
                        watchStatus = advancedMessage, sending = isSyncing,
                    )
                } else {
                    OutlinedButton(onClick = { onSyncHrZones(settings) }, modifier = Modifier.fillMaxWidth(), enabled = !isSyncing) { Text("Kirim zona HR ke jam") }
                }
                Text(advancedMessage, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }

    if (openCard == "workout") {
        EvPanel(modifier = Modifier.fillMaxWidth(), containerColor = MaterialTheme.colorScheme.surfaceVariant) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Structured workout", style = MaterialTheme.typography.titleLarge)
                    TextButton(onClick = { openCard = "" }) { Text("Tutup") }
                }
                OutlinedTextField(value = courseName, onValueChange = { courseName = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Nama workout") })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(value = warmup, onValueChange = { warmup = it.filter(Char::isDigit).take(2) }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("Pemanasan (menit)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(value = repeats, onValueChange = { repeats = it.filter(Char::isDigit).take(2) }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("Repetisi") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(value = runMin, onValueChange = { runMin = it.filter(Char::isDigit).take(3) }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("Lari (menit)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(value = recovery, onValueChange = { recovery = it.filter(Char::isDigit).take(2) }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("Recovery (menit)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(value = cooldown, onValueChange = { cooldown = it.filter(Char::isDigit).take(2) }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("Pendinginan") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                }
                Text("Target intensitas (opsional)", style = MaterialTheme.typography.titleSmall)
                Text("Jam akan memberi tahu bila pace, zona detak jantung, atau cadence keluar dari rentang pada langkah itu.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                StepTargetEditor("Pemanasan", warmupTarget, zoneLower, zoneCuts.maxHr) { warmupTarget = it }
                StepTargetEditor("Lari", runTarget, zoneLower, zoneCuts.maxHr) { runTarget = it }
                StepTargetEditor("Recovery", recoveryTarget, zoneLower, zoneCuts.maxHr) { recoveryTarget = it }
                StepTargetEditor("Pendinginan", cooldownTarget, zoneLower, zoneCuts.maxHr) { cooldownTarget = it }
                OutlinedButton(onClick = { onPushWorkout(courseName, warmup.toIntOrNull() ?: 0, repeats.toIntOrNull() ?: 0, runMin.toIntOrNull() ?: 0, recovery.toIntOrNull() ?: 0, cooldown.toIntOrNull() ?: 0,
                    com.endurancevault.app.domain.WorkoutTargets(warmupTarget.toTarget(zoneLower, zoneCuts.maxHr), runTarget.toTarget(zoneLower, zoneCuts.maxHr), recoveryTarget.toTarget(zoneLower, zoneCuts.maxHr), cooldownTarget.toTarget(zoneLower, zoneCuts.maxHr))) }, modifier = Modifier.fillMaxWidth(), enabled = !isSyncing) { Text("Kirim structured workout") }
                Text(advancedMessage, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
    }
}


@Composable
private fun WatchStep(n: Int, title: String, content: @Composable () -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
        Box(Modifier.size(22.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
            Text(n.toString(), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Medium)
            content()
        }
    }
}

@Composable
private fun FeatureTile(title: String, hint: String, selected: Boolean, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(hint, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun FeaturePanel(title: String, onClose: () -> Unit, content: @Composable () -> Unit) {
    EvPanel(modifier = Modifier.fillMaxWidth(), containerColor = MaterialTheme.colorScheme.surfaceVariant) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(title, style = MaterialTheme.typography.titleLarge)
                TextButton(onClick = onClose) { Text("Tutup") }
            }
            content()
        }
    }
}


/** Isian form satu langkah: jenis target, dua batas sebagai teks (pace m:ss, cadence spm), atau zona HR 1..5. */
private data class TargetUi(val type: StepIntensity = StepIntensity.NONE, val a: String = "", val b: String = "", val zone: Int = 0) {
    fun toTarget(zoneLower: List<Int>, maxHr: Int): com.endurancevault.app.domain.StepTarget {
        val sw = com.endurancevault.app.domain.StructuredWorkout
        return when (type) {
            StepIntensity.HR_PERCENT -> sw.zoneTarget(zone, zoneLower, maxHr)
            StepIntensity.PACE -> sw.target(type, sw.parsePace(a), sw.parsePace(b))
            else -> sw.target(type, a.toIntOrNull(), b.toIntOrNull())
        }
    }
}

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
private fun StepTargetEditor(label: String, ui: TargetUi, zoneLower: List<Int>, maxHr: Int, onChange: (TargetUi) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label, style = MaterialTheme.typography.labelLarge)
        androidx.compose.foundation.layout.FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            StepIntensity.entries.forEach { t -> FilterChip(selected = ui.type == t, onClick = { onChange(TargetUi(t)) }, label = { Text(t.label) }) }
        }
        when (ui.type) {
            StepIntensity.NONE -> Unit
            StepIntensity.HR_PERCENT -> {
                // Zona sama dengan layar Zona HR (LTHR atau HRR) dan dengan yang dikirim ke jam.
                androidx.compose.foundation.layout.FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    (1..5).forEach { z ->
                        val r = com.endurancevault.app.domain.StructuredWorkout.zoneBpm(z, zoneLower, maxHr)
                        FilterChip(selected = ui.zone == z, onClick = { onChange(ui.copy(zone = z)) }, label = { Text("Z$z · ${r.first}–${r.last}") })
                    }
                }
                if (ui.zone in 1..5) {
                    val t = com.endurancevault.app.domain.StructuredWorkout.zoneTarget(ui.zone, zoneLower, maxHr)
                    Text("Dikirim ke jam sebagai ${t.low}–${t.high}% HR maks ($maxHr bpm). Kirim zona HR ke jam dulu agar HR maks jam sama.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            else -> {
                val pace = ui.type == StepIntensity.PACE
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = ui.a, onValueChange = { onChange(ui.copy(a = it.filter { c -> c.isDigit() || c == ':' }.take(5))) }, modifier = Modifier.weight(1f), singleLine = true,
                        label = { Text(if (pace) "Dari (m:ss/km)" else "Dari (spm)") },
                        placeholder = { Text(if (pace) "4:30" else "170") },
                        keyboardOptions = KeyboardOptions(keyboardType = if (pace) KeyboardType.Text else KeyboardType.Number),
                    )
                    OutlinedTextField(
                        value = ui.b, onValueChange = { onChange(ui.copy(b = it.filter { c -> c.isDigit() || c == ':' }.take(5))) }, modifier = Modifier.weight(1f), singleLine = true,
                        label = { Text("Sampai") },
                        placeholder = { Text(if (pace) "4:45" else "185") },
                        keyboardOptions = KeyboardOptions(keyboardType = if (pace) KeyboardType.Text else KeyboardType.Number),
                    )
                }
            }
        }
    }
}
