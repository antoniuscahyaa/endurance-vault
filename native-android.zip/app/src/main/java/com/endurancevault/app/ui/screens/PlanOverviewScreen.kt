package com.endurancevault.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.endurancevault.app.domain.*
import com.endurancevault.app.ui.UiState
import java.time.format.DateTimeFormatter
import java.util.Locale

private val planDateFmt = DateTimeFormatter.ofPattern("d MMM", Locale("id", "ID"))

/** Plan-wide overview. The Week dock remains the operational day-by-day tracker. */
@Composable
fun PlanOverviewScreen(state: UiState) {
    val plan = state.plan
    if (plan !is PlanOutcome.Ok) {
        Text((plan as? PlanOutcome.Err)?.message ?: "Rencana belum tersedia", Modifier.padding(20.dp))
        return
    }
    val weeks = plan.weeks
    val totalKm = weeks.sumOf { it.km }
    val current = weeks.firstOrNull { !java.time.LocalDate.now().isBefore(it.start) && !java.time.LocalDate.now().isAfter(it.end) }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(top = 18.dp, bottom = 22.dp)) {
        item {
            Text("JADWAL LATIHAN", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(6.dp))
            Text("Ringkasan rencana", style = MaterialTheme.typography.headlineMedium)
            Text(if (plan.none) "Belum ada training plan aktif" else "${plan.n} minggu · ${weeks.size} minggu tersusun", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            EvPanel(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column { Text("Panjang rencana", style = MaterialTheme.typography.labelMedium); Text("${weeks.size} minggu", style = MaterialTheme.typography.titleLarge) }
                    Column { Text("Total jarak", style = MaterialTheme.typography.labelMedium); Text("${"%.1f".format(totalKm)} km", style = MaterialTheme.typography.titleLarge) }
                    Column { Text("Rata-rata", style = MaterialTheme.typography.labelMedium); Text("${if (weeks.isEmpty()) 0 else "%.1f".format(totalKm / weeks.size)} km", style = MaterialTheme.typography.titleLarge) }
                }
            }
        }
        if (current != null) item {
            EvPanel(Modifier.fillMaxWidth(), containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("MINGGU BERJALAN", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    Text("Minggu ${current.i} · ${current.start.format(planDateFmt)}–${current.end.format(planDateFmt)}", style = MaterialTheme.typography.titleMedium)
                    Text("${"%.1f".format(current.km)} km · ${current.phase}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item { Text("Semua minggu", style = MaterialTheme.typography.titleLarge) }
        items(weeks, key = { it.i }) { w ->
            EvPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text("Minggu ${w.i}", style = MaterialTheme.typography.titleMedium)
                            Text("${w.start.format(planDateFmt)} – ${w.end.format(planDateFmt)} · ${w.phase}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text("${"%.1f".format(w.km)} km", style = MaterialTheme.typography.titleMedium)
                    }
                    LinearProgressIndicator(progress = { (w.km / (weeks.maxOfOrNull { it.km }?.coerceAtLeast(1.0) ?: 1.0)).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                    Text(w.days.joinToString("  ·  ") { d -> "${d.date.dayOfWeek.getDisplayName(java.time.format.TextStyle.SHORT, Locale("id", "ID"))} ${d.title}${if (d.km > 0) " ${"%.1f".format(d.km)}k" else ""}" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (w.cut || w.rec || w.race) Text(listOfNotNull(if (w.cut) "Minggu ringan" else null, if (w.rec) "Pemulihan" else null, if (w.race) "Minggu lomba" else null).joinToString(" · "), color = MaterialTheme.colorScheme.tertiary, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}
