package com.endurancevault.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.domain.Kinds
import com.endurancevault.app.domain.PDay
import com.endurancevault.app.domain.PWeek
import com.endurancevault.app.domain.Phases
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.SessionAdjust
import com.endurancevault.app.domain.StrengthBlock
import com.endurancevault.app.ui.UiState
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

// ---------- model tampilan ----------

private enum class Metric(val label: String, val title: String, val unit: String) {
    KM("Km", "KM PER WEEK", "km"),
    HOURS("Hours", "HOURS PER WEEK", "h"),
    CLIMB("Climb", "CLIMB PER WEEK", "m"),
    DESCENT("Descent", "DESCENT PER WEEK", "m"),
}

private class WeekStat(val idx: Int, val w: PWeek, val plan: Double, val done: Double, val spike: Int?)
private class Block(val phase: String, val n: Int, val of: Int, val stats: List<WeekStat>)

private sealed interface PRow { val key: String }
private class HeaderRow(val b: Block) : PRow { override val key = "h:${b.phase}:${b.n}" }
private class WeekRow(val s: WeekStat, val last: Boolean) : PRow { override val key = "w:${s.idx}" }

private val DATE_FMT = DateTimeFormatter.ofPattern("d MMM", Locale.ENGLISH)
private val MONO = FontFamily.Monospace

private val HeroTop = Color(0xFF7A4A24)
private val HeroMid = Color(0xFF1C1E23)
private val HeroBottom = Color(0xFF111317)
private val PhaseBase = Color(0xFF7B8190)
private val PhaseBuild = Color(0xFFFA7A0C)
private val PhasePeak = Color(0xFFF2500A)
private val PhaseTaper = Color(0xFFF2B48A)

private fun phaseColor(p: String) = when (p) {
    Phases.BASE -> PhaseBase
    Phases.BUILD -> PhaseBuild
    Phases.PEAK -> PhasePeak
    else -> PhaseTaper
}

/** Warna batang di kartu hero (di atas latar gelap): makin dekat puncak makin terang. */
private fun barColor(p: String) = when (p) {
    Phases.BASE -> Color(0xFF9A9DA4)
    Phases.BUILD -> Color(0xFFC9CCD2)
    Phases.PEAK -> Color(0xFFF4F5F7)
    else -> Color(0xFFF2B48A)
}

private fun phaseName(p: String) = when (p) {
    Phases.BASE -> "BASE"; Phases.BUILD -> "BUILD"; Phases.PEAK -> "PEAK"; else -> "TAPER"
}

private val PHASE_ORDER = listOf(Phases.BASE, Phases.BUILD, Phases.PEAK, Phases.TAPER)

private fun fmt(v: Double): String =
    if (abs(v - v.roundToInt()) < 0.05) v.roundToInt().toString() else String.format(Locale.US, "%.1f", v)

private fun paceMinPerKm(s: String): Double {
    val p = s.trim().split(":")
    val m = p.getOrNull(0)?.toDoubleOrNull() ?: return 6.5
    val sec = p.getOrNull(1)?.toDoubleOrNull() ?: 0.0
    return m + sec / 60.0
}

private fun planned(w: PWeek, m: Metric, pace: Double): Double = when (m) {
    Metric.KM -> w.km
    Metric.HOURS -> w.days.filter { it.kind != Kinds.REST }.sumOf { it.km } * pace / 60.0
    // Rencana hanya menyimpan D+; turunan dianggap sama (rute loop).
    Metric.CLIMB, Metric.DESCENT -> w.days.sumOf { (it.gain ?: 0).toDouble() }
}

private fun doneOf(w: PWeek, m: Metric, acts: List<ActivityEntity>): Double {
    val a = w.start.toString(); val b = w.end.toString()
    val runs = acts.filter { it.type.equals("run", ignoreCase = true) && it.dateIso >= a && it.dateIso <= b }
    return when (m) {
        Metric.KM -> runs.sumOf { it.km }
        Metric.HOURS -> runs.sumOf { it.durationSec.toDouble() } / 3600.0
        Metric.CLIMB, Metric.DESCENT -> runs.sumOf { (it.gain ?: 0).toDouble() }
    }
}

private fun buildStats(weeks: List<PWeek>, m: Metric, pace: Double, acts: List<ActivityEntity>): List<WeekStat> {
    var prev = 0.0
    return weeks.mapIndexed { i, w ->
        val p = planned(w, m, pace)
        val pct = if (i > 0 && prev > 0.0) ((p / prev - 1.0) * 100).roundToInt() else 0
        prev = p
        WeekStat(i, w, p, doneOf(w, m, acts), if (pct > 10) pct else null)
    }
}

private fun buildBlocks(stats: List<WeekStat>): List<Block> {
    val out = mutableListOf<Block>()
    var i = 0
    while (i < stats.size) {
        val ph = stats[i].w.phase
        var j = i
        while (j < stats.size && stats[j].w.phase == ph) j++
        val chunks = stats.subList(i, j).chunked(4)
        chunks.forEachIndexed { k, c -> out += Block(ph, k + 1, chunks.size, c) }
        i = j
    }
    return out
}

// ---------- layar ----------

/** Ringkasan seluruh rencana. Tab Minggu tetap menjadi pelacak operasional per hari. */
@Composable
fun PlanOverviewScreen(state: UiState, onOpenActivity: (Long) -> Unit = {}) {
    val plan = state.plan
    if (plan !is PlanOutcome.Ok) {
        Text((plan as? PlanOutcome.Err)?.message ?: "Rencana belum tersedia", Modifier.padding(20.dp))
        return
    }
    val weeks = plan.weeks
    val today = LocalDate.now()
    val pace = remember(state.settings.pace) { paceMinPerKm(state.settings.pace) }
    var metric by rememberSaveable { mutableStateOf(Metric.KM) }
    val curIdx = remember(weeks) {
        weeks.indexOfFirst { !today.isBefore(it.start) && !today.isAfter(it.end) }.takeIf { it >= 0 }
            ?: weeks.indexOfFirst { !it.end.isBefore(today) }.takeIf { it >= 0 } ?: (weeks.size - 1).coerceAtLeast(0)
    }
    var sel by rememberSaveable { mutableStateOf(curIdx) }
    var open by rememberSaveable { mutableStateOf(-1) }

    val stats = remember(weeks, metric, pace, state.activities) { buildStats(weeks, metric, pace, state.activities) }
    val blocks = remember(stats) { buildBlocks(stats) }
    val rows = remember(blocks) {
        buildList<PRow> { blocks.forEach { b -> add(HeaderRow(b)); b.stats.forEachIndexed { i, s -> add(WeekRow(s, i == b.stats.lastIndex)) } } }
    }
    val rowOffset = 2 // hero + label "ALL WEEKS"
    val phaseStart = remember(rows) {
        val m = linkedMapOf<String, Int>()
        rows.forEachIndexed { i, r -> if (r is HeaderRow && r.b.phase !in m) m[r.b.phase] = i + rowOffset }
        m
    }
    val curPhase = weeks.getOrNull(curIdx)?.phase ?: Phases.BASE
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val shownPhase by remember(phaseStart, curPhase) {
        derivedStateOf {
            val f = listState.firstVisibleItemIndex
            phaseStart.entries.filter { it.value <= f }.maxByOrNull { it.value }?.key ?: curPhase
        }
    }

    Column(Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 12.dp),
        ) {
            item(key = "hero") {
                Hero(
                    state = state, plan = plan, stats = stats, metric = metric, sel = sel,
                    onMetric = { metric = it }, onSelect = { sel = it },
                )
            }
            item(key = "label") {
                Row(Modifier.fillMaxWidth().padding(top = 20.dp, bottom = 10.dp, start = 4.dp, end = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("ALL WEEKS", fontFamily = MONO, fontSize = 12.sp, letterSpacing = 2.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${weeks.size} weeks", fontFamily = MONO, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            items(rows, key = { it.key }) { r ->
                when (r) {
                    is HeaderRow -> BlockHeader(r.b, metric, current = r.b.stats.any { it.idx == curIdx })
                    is WeekRow -> WeekItem(
                        r = r, metric = metric, expanded = open == r.s.idx, state = state, today = today,
                        onToggle = { open = if (open == r.s.idx) -1 else r.s.idx }, onOpenActivity = onOpenActivity,
                    )
                }
            }
        }
        PhaseDock(
            selected = shownPhase, current = curPhase, present = phaseStart.keys,
            onTap = { p -> phaseStart[p]?.let { idx -> scope.launch { listState.animateScrollToItem(idx) } } },
        )
    }
}

// ---------- kartu hero ----------

@Composable
private fun Hero(
    state: UiState, plan: PlanOutcome.Ok, stats: List<WeekStat>, metric: Metric, sel: Int,
    onMetric: (Metric) -> Unit, onSelect: (Int) -> Unit,
) {
    val white = Color.White
    val dim = Color.White.copy(alpha = .62f)
    val total = stats.sumOf { it.plan }
    val spikes = stats.filter { it.spike != null }
    val first = plan.weeks.firstOrNull()?.km ?: 0.0
    val peak = plan.weeks.maxOfOrNull { it.km } ?: 0.0
    val maxV = (stats.maxOfOrNull { maxOf(it.plan, it.done) } ?: 1.0).coerceAtLeast(0.1)
    val chosen = stats.getOrNull(sel) ?: stats.firstOrNull()

    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(30.dp)).background(
            Brush.linearGradient(
                colors = listOf(HeroTop, HeroMid, HeroBottom),
                start = Offset(Float.POSITIVE_INFINITY, 0f), end = Offset(0f, Float.POSITIVE_INFINITY),
            ),
        ),
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.clip(CircleShape).background(white.copy(alpha = .14f)).padding(horizontal = 14.dp, vertical = 9.dp)) {
                    Text(if (plan.build) "PERFORMANCE BUILD" else "TRAINING PLAN", fontFamily = MONO, fontSize = 11.sp, letterSpacing = 1.5.sp, color = white, maxLines = 1)
                }
                Box(Modifier.clip(CircleShape).border(1.dp, white.copy(alpha = .5f), CircleShape).padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Text("${state.settings.days} DAYS / MGG", fontFamily = MONO, fontSize = 11.sp, letterSpacing = 1.sp, color = white, maxLines = 1)
                }
                Spacer(Modifier.weight(1f))
                Text("${first.roundToInt()} → ${peak.roundToInt()} km/mgg", fontFamily = MONO, fontSize = 11.sp, color = dim, maxLines = 1)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                HeroStat("PLAN LENGTH", plan.weeks.size.toString(), "weeks")
                HeroStat("TOTAL VOLUME", fmt(total), metric.unit)
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(metric.title, Modifier.weight(1f), fontFamily = MONO, fontSize = 11.sp, letterSpacing = 1.5.sp, color = dim, maxLines = 2)
                Row(Modifier.clip(CircleShape).background(white.copy(alpha = .08f)).padding(4.dp)) {
                    Metric.values().forEach { m ->
                        val on = m == metric
                        Box(
                            Modifier.clip(CircleShape).background(if (on) white else Color.Transparent)
                                .clickable { onMetric(m) }.padding(horizontal = 9.dp, vertical = 9.dp),
                        ) {
                            Text(m.label, fontFamily = MONO, fontSize = 11.sp, maxLines = 1, color = if (on) Color(0xFFC44A07) else white.copy(alpha = .85f))
                        }
                    }
                }
            }
            if (chosen != null) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(white.copy(alpha = .08f)).padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        "W${chosen.idx + 1} · ${phaseName(chosen.w.phase).lowercase().replaceFirstChar { it.uppercase() }} · ${chosen.w.start.format(DATE_FMT)} – ${chosen.w.end.format(DATE_FMT)}",
                        Modifier.weight(1f), fontFamily = MONO, fontSize = 12.sp, color = white, maxLines = 1,
                    )
                    Text("${fmt(chosen.done)} ${metric.unit} / ${fmt(chosen.plan)} ${metric.unit}", fontFamily = MONO, fontSize = 12.sp, color = white, maxLines = 1)
                }
            }
            // batang per minggu
            Row(Modifier.fillMaxWidth().height(206.dp), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.Bottom) {
                stats.forEach { s ->
                    val frac = (s.plan / maxV).toFloat().coerceIn(0.04f, 1f)
                    val doneFrac = if (s.plan > 0) (s.done / s.plan).toFloat().coerceIn(0f, 1f) else 0f
                    val isSel = s.idx == sel
                    val c = barColor(s.w.phase)
                    Column(
                        Modifier.weight(1f).fillMaxHeight().clickable(
                            interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }, indication = null,
                        ) { onSelect(s.idx) },
                        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom,
                    ) {
                        if (s.spike != null) Text("▲", fontSize = 10.sp, color = white, modifier = Modifier.padding(bottom = 2.dp))
                        Box(
                            Modifier.fillMaxWidth().height(172.dp * frac).clip(RoundedCornerShape(5.dp))
                                .background(c.copy(alpha = .42f))
                                .then(if (isSel) Modifier.border(2.dp, white, RoundedCornerShape(5.dp)) else Modifier),
                        ) {
                            Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().fillMaxHeight(doneFrac).background(c))
                        }
                        Box(Modifier.padding(top = 5.dp).size(5.dp).clip(CircleShape).background(if (isSel) white else Color.Transparent))
                    }
                }
            }
            // peringatan lonjakan
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(white.copy(alpha = .08f)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.size(11.dp).border(1.6.dp, white, CircleShape))
                    Text(
                        if (spikes.isEmpty()) "No week up more than 10% (${metric.unit})"
                        else "${spikes.size} ${if (spikes.size == 1) "week" else "weeks"} up more than 10% (${metric.unit})",
                        fontFamily = MONO, fontSize = 13.sp, color = white,
                    )
                }
                if (spikes.isNotEmpty()) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    spikes.take(4).forEach { s ->
                        Box(Modifier.clip(CircleShape).border(1.5.dp, white, CircleShape).clickable { onSelect(s.idx) }.padding(horizontal = 14.dp, vertical = 9.dp)) {
                            Text("W${s.idx + 1} +${s.spike}%", fontFamily = MONO, fontSize = 12.sp, color = white)
                        }
                    }
                }
            }
            // legenda
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                listOf(Phases.BASE to "Base", Phases.BUILD to "Build", Phases.PEAK to "Peak", Phases.TAPER to "Taper").forEach { (p, l) -> Legend(barColor(p), l, dim) }
                Spacer(Modifier.weight(1f))
                Legend(white, "Done", dim)
                Legend(white.copy(alpha = .4f), "Not yet", dim)
            }
        }
    }
}

@Composable
private fun HeroStat(label: String, value: String, unit: String) {
    Column {
        Text(label, fontFamily = MONO, fontSize = 11.sp, letterSpacing = 1.5.sp, color = Color.White.copy(alpha = .62f))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(value, fontSize = 44.sp, fontWeight = FontWeight.Bold, color = Color.White, letterSpacing = (-1).sp)
            Text(unit, Modifier.padding(start = 4.dp, bottom = 8.dp), fontSize = 18.sp, color = Color.White)
        }
    }
}

@Composable
private fun Legend(c: Color, label: String, textColor: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(Modifier.size(11.dp).clip(RoundedCornerShape(3.dp)).background(c))
        Text(label, fontFamily = MONO, fontSize = 10.sp, color = textColor, maxLines = 1)
    }
}

// ---------- daftar minggu per fase ----------

@Composable
private fun BlockHeader(b: Block, metric: Metric, current: Boolean) {
    val cs = MaterialTheme.colorScheme
    val first = b.stats.first(); val last = b.stats.last()
    val range = if (first.idx == last.idx) "W${first.idx + 1}" else "W${first.idx + 1}–W${last.idx + 1}"
    val dates = "${first.w.start.format(DATE_FMT)} – ${last.w.end.format(DATE_FMT)}"
    val rec = b.stats.filter { it.w.rec }.joinToString(" ") { "W${it.idx + 1}" }
    val total = b.stats.sumOf { it.plan }
    val shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
    Row(Modifier.padding(top = if (b.n == 1 && b.phase == PHASE_ORDER.first()) 0.dp else 14.dp).fillMaxWidth().height(IntrinsicSize.Min).clip(shape)) {
        Box(Modifier.width(10.dp).fillMaxHeight().background(phaseColor(b.phase)))
        Row(
            Modifier.weight(1f).background(if (current) cs.primary.copy(alpha = .14f) else cs.surfaceVariant).padding(horizontal = 16.dp, vertical = 18.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(phaseName(b.phase), fontSize = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text(" ${b.n} / ${b.of}", fontFamily = MONO, fontSize = 12.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(bottom = 2.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(range, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text(dates + if (rec.isNotEmpty()) " · recovery $rec" else "", fontFamily = MONO, fontSize = 11.sp, color = cs.onSurfaceVariant, maxLines = 1)
            }
            Row(verticalAlignment = Alignment.Bottom) {
                Text(fmt(total), fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text(" ${metric.unit}", fontSize = 12.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(bottom = 3.dp))
            }
        }
    }
}

@Composable
private fun WeekItem(
    r: WeekRow, metric: Metric, expanded: Boolean, state: UiState, today: LocalDate,
    onToggle: () -> Unit, onOpenActivity: (Long) -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val s = r.s; val w = s.w
    val shape = if (r.last && !expanded) RoundedCornerShape(bottomStart = 22.dp, bottomEnd = 22.dp) else RoundedCornerShape(0.dp)
    val strengthN = w.days.sumOf { d -> listOf(d.str, d.ank, d.up).count { it != null } }
    val sub = buildAnnotatedString {
        if (strengthN > 0) append("${strengthN}× strength")
        if (s.spike != null) {
            if (length > 0) append(" · ")
            withStyle(SpanStyle(color = cs.primary, fontWeight = FontWeight.SemiBold)) { append("▲ spike +${s.spike}%") }
        }
        if (w.missed > 0) { if (length > 0) append(" · "); append("${w.missed} missed") }
        if (w.rec) { if (length > 0) append(" · "); append("recovery") }
    }
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min).clip(shape)) {
        Box(Modifier.width(10.dp).fillMaxHeight().background(phaseColor(w.phase).copy(alpha = .55f)))
        Column(Modifier.weight(1f).background(cs.surface)) {
            HorizontalDivider(color = cs.outlineVariant.copy(alpha = .6f))
            Row(
                Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(horizontal = 16.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Box(Modifier.clip(CircleShape).background(cs.surfaceVariant).padding(horizontal = 14.dp, vertical = 9.dp)) {
                    Text("W${s.idx + 1}", fontFamily = MONO, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("${w.start.format(DATE_FMT)} – ${w.end.format(DATE_FMT)}", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                        Box(Modifier.clip(CircleShape).background(phaseColor(w.phase)).padding(horizontal = 10.dp, vertical = 4.dp)) {
                            Text(phaseName(w.phase), fontFamily = MONO, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1)
                        }
                    }
                    if (sub.isNotEmpty()) Text(sub, fontFamily = MONO, fontSize = 12.sp, color = cs.onSurfaceVariant, maxLines = 1)
                }
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(fmt(s.plan), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(" ${metric.unit}", fontSize = 12.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(bottom = 3.dp))
                }
            }
            if (expanded) {
                Column(Modifier.fillMaxWidth().background(cs.surfaceVariant.copy(alpha = .6f)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    w.days.forEach { d ->
                        DayCard(d, state, today, onOpenActivity)
                        listOf(Triple(d.str, "s", "GYM"), Triple(d.ank, "a", "ANKLE"), Triple(d.up, "u", "UPPER")).forEach { (blk, suffix, tag) ->
                            if (blk != null) StrengthCard(d, blk, "${d.date}:$suffix", tag, state, today)
                        }
                    }
                }
            }
        }
    }
}

// ---------- kartu hari (hanya baca) ----------

@Composable
private fun DayCard(d: PDay, state: UiState, today: LocalDate, onOpenActivity: (Long) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val key = d.date.toString()
    val rest = d.kind == Kinds.REST
    val logged = if (rest) null else SessionAdjust.primaryRun(state.activities, key)
    val completed = !rest && (logged != null || key in state.done)
    val adj = d.adj
    val missed = !rest && !completed && (adj?.type == "miss" || (adj == null && d.date.isBefore(today)))
    val hard = d.kind == Kinds.QUALITY || d.kind == Kinds.LONG || d.kind == Kinds.RACE || d.kind == Kinds.EVENT
    val accent = if (hard) Brush.verticalGradient(listOf(PhaseBuild, PhasePeak)) else Brush.verticalGradient(listOf(PhaseBase, PhaseBase))
    val dow = d.date.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.ENGLISH).uppercase()

    val status: Pair<String, Boolean>? = when {
        completed && logged != null -> {
            val ok = d.km <= 0.0 || logged.km / d.km in 0.85..1.15
            (if (ok) "✓ On plan" else "! Needs attention") to ok
        }
        completed -> "✓ Marked done" to true
        missed -> "Missed" to false
        else -> null
    }

    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min).clip(RoundedCornerShape(16.dp)).background(cs.surface)) {
        Box(Modifier.width(5.dp).fillMaxHeight().background(accent))
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.width(40.dp)) {
                Text(dow, fontFamily = MONO, fontSize = 10.sp, color = cs.onSurfaceVariant)
                Text(d.date.dayOfMonth.toString(), fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(if (rest) "Rest" else d.title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                if (rest) Text("Complete rest.", fontSize = 12.sp, color = cs.onSurfaceVariant)
                else if (d.detail.isNotBlank()) Text(d.detail, fontSize = 12.sp, color = cs.onSurfaceVariant, maxLines = 2)
                if (logged != null) {
                    val pace = if (logged.km > 0 && logged.durationSec > 0) {
                        val sec = (logged.durationSec / logged.km).roundToInt()
                        " · ${sec / 60}:${"%02d".format(sec % 60)}/km"
                    } else ""
                    Box(Modifier.clip(RoundedCornerShape(18.dp)).background(cs.surfaceVariant).padding(horizontal = 14.dp, vertical = 8.dp)) {
                        Text("Logged · ${fmt(logged.km)} km$pace" + (logged.avgHr?.let { " · HR $it" } ?: ""), fontSize = 12.sp)
                    }
                    Box(Modifier.clip(CircleShape).background(cs.surfaceVariant).clickable { onOpenActivity(logged.id) }.padding(horizontal = 14.dp, vertical = 7.dp)) {
                        Text("Detail", fontSize = 12.sp)
                    }
                }
                if (adj != null && adj.type != "miss") Text(adj.text, fontSize = 11.sp, color = cs.tertiary)
                status?.let { (t, _) -> Text(t, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = cs.primary) }
            }
            if (!rest) Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (d.km > 0) Row(verticalAlignment = Alignment.Bottom) {
                    Text(fmt(d.km), fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text(" km", fontSize = 11.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(bottom = 2.dp))
                }
                DoneDot(completed)
            }
        }
    }
}

@Composable
private fun StrengthCard(d: PDay, b: StrengthBlock, key: String, tag: String, state: UiState, today: LocalDate) {
    val cs = MaterialTheme.colorScheme
    val completed = key in state.done || state.strengthWorkouts.any { it.linkedKey == key }
    val missed = !completed && d.date.isBefore(today)
    var open by rememberSaveable(key) { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min).clip(RoundedCornerShape(16.dp)).background(cs.surface).clickable { open = !open }) {
        Box(Modifier.width(5.dp).fillMaxHeight().background(Brush.verticalGradient(listOf(PhaseBuild, PhasePeak))))
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(tag, Modifier.width(40.dp), fontFamily = MONO, fontSize = 10.sp, color = cs.primary)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(b.title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                if (completed) Text("✓ Done", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = cs.primary)
                else if (missed) Text("Missed", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = cs.primary)
                Text((if (open) "Hide sets" else "See sets") + " · ${b.lines.size} exercises", fontSize = 12.sp, color = cs.primary)
                if (open) {
                    if (b.note.isNotBlank()) Text(b.note, fontSize = 12.sp, color = cs.onSurfaceVariant)
                    b.lines.forEach { Text("• $it", fontSize = 13.sp) }
                }
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("${b.mins}", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(" min", fontSize = 11.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(bottom = 2.dp))
                }
                DoneDot(completed)
            }
        }
    }
}

@Composable
private fun DoneDot(done: Boolean) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.size(24.dp).clip(CircleShape)
            .background(if (done) PhaseBuild else Color.Transparent)
            .border(2.dp, if (done) PhaseBuild else cs.outline, CircleShape),
    )
}

// ---------- dock fase ----------

@Composable
private fun PhaseDock(selected: String, current: String, present: Set<String>, onTap: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth().background(cs.surface)) {
        HorizontalDivider(color = cs.outlineVariant)
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PHASE_ORDER.forEach { p ->
                val exists = p in present
                val on = p == selected && exists
                Box(
                    Modifier.weight(1f).height(46.dp).clip(CircleShape)
                        .background(if (on) cs.primary else Color.Transparent)
                        .then(if (on) Modifier else Modifier.border(BorderStroke(1.dp, cs.outlineVariant.copy(alpha = if (exists) 1f else .5f)), CircleShape))
                        .then(if (exists) Modifier.clickable { onTap(p) } else Modifier),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        phaseName(p).lowercase().replaceFirstChar { it.uppercase() } + if (p == current) " •" else "",
                        fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
                        color = when {
                            on -> cs.onPrimary
                            exists -> cs.onSurface
                            else -> cs.onSurfaceVariant.copy(alpha = .45f)
                        },
                    )
                }
            }
        }
    }
}
