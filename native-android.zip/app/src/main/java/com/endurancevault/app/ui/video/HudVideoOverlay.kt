package com.endurancevault.app.ui.video

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import com.endurancevault.app.domain.HudVideoPrefs
import com.endurancevault.app.domain.RouteVideoTrack
import kotlin.math.*

/** Komposisi HUD per frame; nilai diturunkan dari timestamp video + offset ke waktu aktivitas. */
object HudVideoOverlay {
    data class Values(
        val km: Double, val elapsedSec: Int, val pace: Double?, val hr: Int?,
        val elevation: Double?, val grade: Double?, val speed: Double,
    )
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap=Paint.Cap.ROUND; strokeJoin=Paint.Join.ROUND }
    private fun txt(c:Canvas,s:String,x:Float,y:Float,size:Float,color:Int,bold:Boolean=false,align:Paint.Align=Paint.Align.LEFT){
        paint.shader=null;paint.style=Paint.Style.FILL;paint.color=color;paint.textSize=size;paint.textAlign=align
        paint.typeface=android.graphics.Typeface.create("sans-serif",if(bold)android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
        paint.clearShadowLayer();c.drawText(s,x,y,paint)
    }
    fun values(track:RouteVideoTrack, videoSec:Double, offsetSec:Int):Values {
        val elapsed=(offsetSec+videoSec).coerceIn(0.0,track.totalSec.toDouble())
        val upper=track.sec.binarySearch(elapsed.toInt()).let { if(it>=0) it else (-it-1).coerceIn(0,track.n-1) }
        val lower=(upper-1).coerceAtLeast(0)
        val span=(track.sec[upper]-track.sec[lower]).toDouble()
        val f=if(span>0)((elapsed-track.sec[lower])/span).coerceIn(0.0,1.0) else 0.0
        fun interp(a:DoubleArray):Double? {
            val x=a.getOrNull(lower);val y=a.getOrNull(upper)
            if(x==null||y==null||!x.isFinite()||!y.isFinite()) return null
            return x+(y-x)*f
        }
        val distance=track.dist[lower]+(track.dist[upper]-track.dist[lower])*f
        val frac=if(track.totalM>0)(distance/track.totalM).coerceIn(0.0,1.0) else 0.0
        val st=track.statsAt(frac,true)
        val pace=st.pace?.takeIf{it in 1.0..60.0}
        val h0=track.hr[lower];val h1=track.hr[upper]
        val hr=if(h0>=30&&h1>=30)(h0+(h1-h0)*f).roundToInt() else st.hr
        val elevation=interp(track.eleS)
        val grade=interp(track.gradeS)
        return Values(distance/1000.0,elapsed.roundToInt(),pace,hr,elevation,grade,if(pace!=null)60.0/pace else 0.0)
    }

    fun draw(canvas:Canvas,width:Int,height:Int,video:android.graphics.Bitmap,track:RouteVideoTrack,videoSec:Double,offsetSec:Int,prefs:HudVideoPrefs) {
        val v=prefs.sanitized()
        val src=RectF(0f,0f,video.width.toFloat(),video.height.toFloat())
        val factor=max(width/video.width.toFloat(),height/video.height.toFloat())
        val dw=video.width*factor;val dh=video.height*factor
        canvas.drawBitmap(video,null,RectF((width-dw)/2,(height-dh)/2,(width+dw)/2,(height+dh)/2),paint)
        drawOverlay(canvas,width,height,track,videoSec,offsetSec,v)
    }

    @Synchronized
    fun drawOverlay(c:Canvas,w:Int,h:Int,track:RouteVideoTrack,videoSec:Double,offsetSec:Int,prefs:HudVideoPrefs) {
        val v=prefs.sanitized();val k=min(w,h)/720f*(if(w>h).85f else 1f);val m=44f*k
        val ac=runCatching{Color.parseColor(v.accent)}.getOrDefault(0xFFFF6A13.toInt())
        val values=values(track,videoSec,offsetSec)
        val d=v.dim/100f
        if(d>0f){
            paint.shader=android.graphics.LinearGradient(0f,0f,0f,h*.30f,intArrayOf(Color.argb((d*255).toInt(),0,0,0),Color.TRANSPARENT),null,android.graphics.Shader.TileMode.CLAMP)
            c.drawRect(0f,0f,w.toFloat(),h*.30f,paint)
            paint.shader=android.graphics.LinearGradient(0f,h*.50f,0f,h.toFloat(),intArrayOf(Color.TRANSPARENT,Color.argb((d*255).toInt(),0,0,0)),null,android.graphics.Shader.TileMode.CLAMP)
            c.drawRect(0f,h*.5f,w.toFloat(),h.toFloat(),paint);paint.shader=null
        }
        c.save();paint.setShadowLayer(8*k,0f,2*k,0x99000000.toInt())
        if(v.style=="min"){
            val pace=values.pace?.let{String.format(java.util.Locale.US,"%d:%02d",it.toInt(),(it*60).roundToInt()%60)}?:"--:--"
            txt(c,pace,m,h-150*k,150*k,Color.WHITE,true)
            txt(c,"/km",m+210*k,h-150*k,40*k,0xDDFFFFFF.toInt())
            val row="${values.hr?.toString()?: "--"} bpm     ${"%.2f".format(values.km)} km     ${fmtTime(values.elapsedSec)}"
            txt(c,row,m,h-92*k,36*k,Color.WHITE,true)
            txt(c,"${values.elevation?.roundToInt()?.toString()?: "--"} m   ${values.grade?.roundToInt()?.let{(if(it>0)"+" else "")+it}?: "--"}%",w-m,m+42*k,34*k,Color.WHITE,true,Paint.Align.RIGHT)
        }else{
            if(v.showMap && track.hasGpsRoute) drawMini(c,w,h,track,values.km,k,ac)
            val pitch=122*k;val y0=h-96*k-3*pitch
            drawItem(c,w-m,m+68*k,values.elevation?.roundToInt()?.toString()?:"--","m","ELEVASI",k,true)
            drawItem(c,w-m,m+68*k+pitch,values.grade?.roundToInt()?.let{(if(it>0)"+" else "")+it}?: "--","%","KEMIRINGAN",k,true)
            drawItem(c,m,y0,values.hr?.toString()?:"--","bpm","DENYUT",k,false)
            drawItem(c,m,y0+pitch,String.format(java.util.Locale.US,"%.2f",values.km),"km","JARAK",k,false)
            drawItem(c,m,y0+2*pitch,values.pace?.let{String.format(java.util.Locale.US,"%d:%02d",it.toInt(),(it*60).roundToInt()%60)}?:"--:--","/km","PACE",k,false)
            drawItem(c,m,y0+3*pitch,fmtTime(values.elapsedSec),"","WAKTU",k,false)
            if(v.showGauge) drawGauge(c,w,h,values.speed,k,ac)
            if(v.showMap && track.hasGpsRoute) txt(c,"${"%.1f".format(values.km)} / ${"%.1f".format(track.totalM/1000.0)} km",m,44*k+214*k,25*k,Color.WHITE,true)
        }
        c.restore()
    }

    private fun drawItem(c:Canvas,x:Float,y:Float,value:String,unit:String,label:String,k:Float,right:Boolean){
        val align=if(right)Paint.Align.RIGHT else Paint.Align.LEFT
        paint.textSize=66*k;paint.typeface=android.graphics.Typeface.create("sans-serif",android.graphics.Typeface.BOLD)
        val valueWidth=paint.measureText(value)
        if(right){
            if(unit.isNotBlank()) txt(c,unit,x,y,26*k,0xDDFFFFFF.toInt(),false,Paint.Align.RIGHT)
            txt(c,value,if(unit.isNotBlank())x-34*k else x,y,66*k,Color.WHITE,true,Paint.Align.RIGHT)
        }else{
            txt(c,value,x,y,66*k,Color.WHITE,true,Paint.Align.LEFT)
            if(unit.isNotBlank()) txt(c,unit,x+valueWidth+8*k,y,26*k,0xDDFFFFFF.toInt(),false,Paint.Align.LEFT)
        }
        txt(c,label,x,y+32*k,24*k,0xDDFFFFFF.toInt(),false,align)
    }
    private fun drawMini(c:Canvas,w:Int,h:Int,t:RouteVideoTrack,km:Double,k:Float,accent:Int){
        val bx=44*k;val by=44*k;val bw=230*k;val bh=176*k
        paint.color=0x66000000;c.drawRoundRect(bx,by,bx+bw,by+bh,18*k,18*k,paint)
        val xs=t.lon;val ys=t.lat;val minX=xs.minOrNull()?:0.0;val maxX=xs.maxOrNull()?:1.0;val minY=ys.minOrNull()?:0.0;val maxY=ys.maxOrNull()?:1.0
        val s=min((bw-24*k)/max(1e-9,(maxX-minX)).toFloat(),(bh-24*k)/max(1e-9,(maxY-minY)).toFloat())
        val x0=bx+(bw-(maxX-minX).toFloat()*s)/2;val y0=by+(bh-(maxY-minY).toFloat()*s)/2
        fun xx(i:Int)=x0+(xs[i]-minX).toFloat()*s
        fun yy(i:Int)=y0+(maxY-ys[i]).toFloat()*s
        val idx=t.dist.indexOfLast{it<=km*1000}.coerceIn(0,t.n-1)
        val path=Path();for(i in 0 until t.n){if(i==0)path.moveTo(xx(i),yy(i))else path.lineTo(xx(i),yy(i))}
        paint.style=Paint.Style.STROKE;paint.strokeWidth=3*k;paint.color=0x99FFFFFF.toInt();c.drawPath(path,paint)
        val done=Path();for(i in 0..idx){if(i==0)done.moveTo(xx(i),yy(i))else done.lineTo(xx(i),yy(i))}
        paint.color=accent;paint.strokeWidth=6*k;c.drawPath(done,paint);paint.style=Paint.Style.FILL
        paint.color=Color.WHITE;c.drawCircle(xx(idx),yy(idx),8*k,paint);paint.color=accent;c.drawCircle(xx(idx),yy(idx),4*k,paint)
    }
    private fun drawGauge(c:Canvas,w:Int,h:Int,speed:Double,k:Float,accent:Int){
        val r=84*k;val cx=w-44*k-r-14*k;val cy=h-96*k-r-24*k;val a0=Math.PI*.75;val sweep=Math.PI*1.5
        paint.style=Paint.Style.STROKE;paint.strokeWidth=14*k;paint.color=0x99FFFFFF.toInt();c.drawArc(cx-r,cy-r,cx+r,cy+r,135f,270f,false,paint)
        paint.color=accent;c.drawArc(cx-r,cy-r,cx+r,cy+r,135f,(270*(speed/18.0).coerceIn(0.0,1.0)).toFloat(),false,paint);paint.style=Paint.Style.FILL
        txt(c,String.format(java.util.Locale.US,"%.1f",speed),cx,cy+18*k,58*k,Color.WHITE,true,Paint.Align.CENTER)
        txt(c,"km/jam",cx,cy+r*.7f+8*k,24*k,0xDDFFFFFF.toInt(),false,Paint.Align.CENTER)
    }
    private fun fmtTime(sec:Int):String{val h=sec/3600;val m=(sec%3600)/60;val s=sec%60;return if(h>0)String.format("%02d:%02d",h,m) else String.format("%02d:%02d",m,s)}
}
