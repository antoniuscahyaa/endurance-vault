package com.endurancevault.app.data

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import kotlin.math.floor
import kotlin.math.hypot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject

/**
 * Nama daerah (desa, kelurahan, kota kecil, puncak, dll.) di medan 3D. Posisi dalam meter relatif pusat medan seperti rute
 * (x ke timur, z ke selatan). [score] makin tinggi = makin pantas ditampilkan (jenis tempat yang lebih penting dan lebih
 * dekat ke rute). [frac] = bagian jarak rute (0..1) di titik rute terdekat, dipakai untuk memunculkan nama saat pelari mendekat.
 */
class ScenePlace(val name: String, val kind: String, val x: Float, val z: Float, val score: Float, val frac: Float)

/**
 * Sumber nama: OpenStreetMap lewat Overpass API (node `place` bernama dan puncak bernama). Hasil per kotak (dibulatkan 0,01°)
 * disimpan di cacheDir/osm-place selama 30 hari; bila jaringan gagal, cache basi tetap dipakai. Tanpa jaringan dan tanpa
 * cache, daftar kosong dan video tetap jadi tanpa nama daerah.
 */
object PlaceLabels {
    private const val USER_AGENT = "EnduranceVault/0.5.99 (Android; personal fitness route video)"
    private const val MAX_AGE_MS = 30L * 24 * 60 * 60 * 1000
    private const val TIMEOUT_MS = 9_000L
    private const val MAX_SPAN_DEG = 1.5
    const val MAX_CANDIDATES = 30

    private class Raw(val kind: String, val name: String, val lat: Double, val lon: Double)

    /** Bobot jenis tempat: kota > desa/kelurahan > dusun/lingkungan > lokasi umum. */
    private fun weight(kind: String): Float = when (kind) {
        "city" -> 6f; "town" -> 5f; "volcano" -> 4.5f; "village", "suburb" -> 4.2f; "island", "peak" -> 3.5f
        "quarter", "hamlet" -> 3.2f; "neighbourhood" -> 3f; else -> 2f
    }

    /**
     * Kandidat nama untuk satu medan: kotak geografis ([south],[west],[north],[east]) diubah ke meter lewat [xOf]/[zOf], dibuang
     * yang di luar medan ([side] meter per sisi), diberi skor menurut jarak ke rute ([rx],[rz],[rf]), nama kembar dibuang,
     * lalu diurutkan dari skor tertinggi (paling banyak [MAX_CANDIDATES]).
     */
    suspend fun candidates(
        ctx: Context, south: Double, west: Double, north: Double, east: Double,
        xOf: (Double) -> Float, zOf: (Double) -> Float, side: Float,
        rx: FloatArray, rz: FloatArray, rf: FloatArray,
    ): List<ScenePlace> {
        if (north - south > MAX_SPAN_DEG || east - west > MAX_SPAN_DEG || rx.isEmpty()) return emptyList()
        val raw = withTimeoutOrNull(TIMEOUT_MS) { fetch(ctx, south, west, north, east) } ?: return emptyList()
        val half = side * 0.5f
        val best = HashMap<String, ScenePlace>()
        for (r in raw) {
            val x = xOf(r.lon); val z = zOf(r.lat)
            if (x < -half || x > half || z < -half || z > half) continue
            var dMin = Float.MAX_VALUE; var iMin = 0
            for (i in rx.indices) {
                val d = hypot(rx[i] - x, rz[i] - z)
                if (d < dMin) { dMin = d; iMin = i }
            }
            val score = weight(r.kind) - 5f * (dMin / half).coerceIn(0f, 2f)
            val key = r.name.lowercase(Locale.ROOT)
            val old = best[key]
            if (old == null || old.score < score) best[key] = ScenePlace(r.name, r.kind, x, z, score, rf[iMin])
        }
        return best.values.sortedByDescending { it.score }.take(MAX_CANDIDATES)
    }

    /**
     * Pilih sampai [count] nama dari [all] (urut skor): hanya yang lolos [inside], dan tiap pasangan minimal [sepM] meter terpisah
     * supaya pin tidak bertumpuk dan sebarannya terasa wajar, bukan ditempel rapat di satu sudut.
     */
    fun select(all: List<ScenePlace>, count: Int, sepM: Float, inside: (ScenePlace) -> Boolean): List<ScenePlace> {
        val out = ArrayList<ScenePlace>()
        for (p in all) {
            if (out.size >= count) break
            if (!inside(p)) continue
            if (out.any { hypot(it.x - p.x, it.z - p.z) < sepM }) continue
            out.add(p)
        }
        return out
    }

    /**
     * Kemunculan pin (0..1). Pada angka berjalan ([live]) pin memudar masuk sesaat sebelum pelari tiba di dekatnya, jadi nama
     * mengikuti alur perjalanan, bukan semua muncul sekaligus. Nama dekat start sudah tampak sejak awal.
     */
    fun reveal(live: Boolean, progress: Double, placeFrac: Float): Float =
        if (!live) 1f else ((progress - (placeFrac - 0.10)) / 0.04).toFloat().coerceIn(0f, 1f)

    private suspend fun fetch(ctx: Context, south: Double, west: Double, north: Double, east: Double): List<Raw>? = withContext(Dispatchers.IO) {
        fun r(v: Double, up: Boolean) = (if (up) Math.ceil(v * 100) else floor(v * 100)) / 100.0
        val s = r(south, false); val w = r(west, false); val n = r(north, true); val e = r(east, true)
        val key = String.format(Locale.ROOT, "%.2f_%.2f_%.2f_%.2f", s, w, n, e)
        val file = File(ctx.applicationContext.cacheDir, "osm-place/$key.json")
        if (file.isFile && System.currentTimeMillis() - file.lastModified() < MAX_AGE_MS) {
            runCatching { parse(file.readText()) }.getOrNull()?.let { return@withContext it }
        }
        val box = String.format(Locale.ROOT, "%.2f,%.2f,%.2f,%.2f", s, w, n, e)
        val q = "[out:json][timeout:20];(" +
            "node[\"place\"~\"^(city|town|village|suburb|neighbourhood|hamlet|quarter|locality|island)\$\"][\"name\"]($box);" +
            "node[\"natural\"~\"^(peak|volcano)\$\"][\"name\"]($box);" +
            ");out body 500;"
        var conn: HttpURLConnection? = null
        try {
            conn = (URL("https://overpass-api.de/api/interpreter?data=" + URLEncoder.encode(q, "UTF-8")).openConnection() as HttpURLConnection).apply {
                connectTimeout = 6_000; readTimeout = 8_000
                setRequestProperty("User-Agent", USER_AGENT)
            }
            if (conn.responseCode != 200) return@withContext runCatching { parse(file.readText()) }.getOrNull()
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            val list = parse(text)
            runCatching { file.parentFile?.mkdirs(); file.writeText(text) }
            list
        } catch (_: Exception) {
            runCatching { parse(file.readText()) }.getOrNull()
        } finally {
            conn?.disconnect()
        }
    }

    private fun parse(text: String): List<Raw> {
        val arr = JSONObject(text).optJSONArray("elements") ?: return emptyList()
        val out = ArrayList<Raw>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val tags = o.optJSONObject("tags") ?: continue
            val kind = tags.optString("place").ifBlank { tags.optString("natural") }
            // Nama panjang berbahasa ganda ("A / B", "A (B)") dipersingkat ke bagian pertama supaya muat sebagai label kecil.
            val name = tags.optString("name").substringBefore(" / ").substringBefore(" (").trim()
            if (kind.isBlank() || name.isBlank() || name.length > 40) continue
            if (!o.has("lat") || !o.has("lon")) continue
            out.add(Raw(kind, name, o.optDouble("lat"), o.optDouble("lon")))
        }
        return out
    }
}
