package com.endurancevault.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.endurancevault.app.ui.i18n.Text
import com.endurancevault.app.ui.video.RenderState
import com.endurancevault.app.ui.video.RouteVideoIo
import com.endurancevault.app.ui.video.RouteVideoJobs
import kotlin.math.roundToInt

/** Komponen UI bersama layar Video Trail 3D dan Video HUD. */

@Composable
internal fun VuLabel(t: String) = Text(t, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

@Composable
internal fun VuNote(t: String) = Text(t, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)

@Composable
internal fun VuInfo(t: String) = Text(t, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun VuChips(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (k, n) -> FilterChip(selected = selected == k, onClick = { onSelect(k) }, label = { Text(n) }) }
    }
}

@Composable
internal fun VuToggle(label: String, on: Boolean, onChange: (Boolean) -> Unit) {
    FilterChip(selected = on, onClick = { onChange(!on) }, label = { Text(label) })
}

@Composable
internal fun VuSection(title: String, sub: String?, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        content()
    }
}

@Composable
internal fun VuSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, valueText: String, onChange: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { VuLabel(label); VuLabel(valueText) }
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range)
    }
}

private val VU_HEX = Regex("#[0-9a-fA-F]{6}")

/** Pilihan warna: [palette] siap pakai ditambah kolom kode hex. [allowEmpty] menambah pilihan "ikut bawaan" (nilai kosong). */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun VuColorPick(label: String, value: String, palette: List<Pair<String, String>>, emptyLabel: String?, onChange: (String) -> Unit) {
    VuLabel(label)
    val opts = (if (emptyLabel != null) listOf("" to emptyLabel) else emptyList()) + palette.map { it.second to it.first }
    VuChips(opts, opts.firstOrNull { it.first.equals(value, true) }?.first ?: "__custom") { onChange(it) }
    var text by remember(value) { mutableStateOf(value) }
    OutlinedTextField(
        value = text,
        onValueChange = { t ->
            val v = t.take(7).let { if (it.isNotEmpty() && !it.startsWith("#")) "#$it" else it }
            text = v
            if (VU_HEX.matches(v)) onChange(v.uppercase())
            else if (v.isEmpty() && emptyLabel != null) onChange("")
        },
        label = { Text("Kode warna (#RRGGBB)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
    )
}

/**
 * Tombol buat video + progres + hasil (simpan/bagikan) untuk render yang berbagi [RouteVideoJobs]. [myKey] mengenali render milik layar ini;
 * [onStart] dipanggil setelah izin notifikasi (Android 13+) diurus.
 */
@Composable
internal fun VideoRenderPanel(myKey: String, buttonLabel: String, enabled: Boolean, background: Boolean, onStart: () -> Unit) {
    val ctx = LocalContext.current
    val appCtx = ctx.applicationContext
    val job by RouteVideoJobs.state.collectAsState()
    var asked by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    val startRef = rememberUpdatedState(onStart)
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { startRef.value() }

    val running = job as? RenderState.Running
    val done = (job as? RenderState.Done)?.takeIf { it.key == myKey }
    val failed = (job as? RenderState.Failed)?.takeIf { it.key == myKey }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (running != null) {
            LinearProgressIndicator(progress = { running.progress }, modifier = Modifier.fillMaxWidth())
            Text(
                if (running.key == myKey) "Membuat video… ${(running.progress * 100).roundToInt()}%. " +
                    (if (background) "Boleh tutup layar ini; render lanjut di latar belakang." else "Biarkan layar ini tetap terbuka.")
                else "Masih membuat video “${running.label}” (${(running.progress * 100).roundToInt()}%).",
                style = MaterialTheme.typography.bodyMedium,
            )
            if (running.key == myKey) OutlinedButton(onClick = { RouteVideoJobs.cancel() }) { Text("Batal") }
        } else {
            Button(
                modifier = Modifier.fillMaxWidth(), enabled = enabled,
                onClick = {
                    if (background && Build.VERSION.SDK_INT >= 33 && !asked &&
                        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                    ) { asked = true; permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
                    else onStart()
                },
            ) { Text(buttonLabel) }
            if (failed != null) Text("Gagal membuat video: ${failed.message}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            if (done != null) {
                Text("Video siap.", style = MaterialTheme.typography.bodyMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        RouteVideoIo.saveToGallery(appCtx, done.file, done.file.name)
                            .onSuccess { msg = "Tersimpan di $it." }.onFailure { msg = "Gagal menyimpan: ${it.message}" }
                    }) { Text("Simpan ke galeri") }
                    OutlinedButton(onClick = { RouteVideoIo.share(ctx, done.file).onFailure { msg = "Gagal membagikan: ${it.message}" } }) { Text("Bagikan") }
                }
            }
        }
        if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
