package com.endurancevault.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Tab
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.endurancevault.app.ui.i18n.Text
import com.endurancevault.app.ui.video.RenderState
import com.endurancevault.app.ui.video.RouteVideoIo
import com.endurancevault.app.ui.video.RouteVideoJobs
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/** Komponen UI bersama layar Video rute 3D, Video Trail 3D, dan Video HUD. */

/**
 * Kontrol pratinjau langsung: tombol putar/jeda di kiri slider posisi. Menggeser slider saat memutar adalah urusan pemanggil
 * ([onSeek]); [value] dan [valueText] sudah posisi yang sedang tampil (hidup saat memutar, tetap saat dijeda).
 */
@Composable
internal fun PreviewControls(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>, valueText: String, playing: Boolean,
    enabled: Boolean = true, onToggle: () -> Unit, onSeek: (Float) -> Unit,
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        FilledTonalIconButton(onClick = onToggle, enabled = enabled) {
            Icon(
                if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                contentDescription = if (playing) "Jeda pratinjau" else "Putar pratinjau",
            )
        }
        Box(Modifier.weight(1f)) { VuSlider(label, value, range, valueText, onSeek) }
    }
}

/** Menjalankan [onPause] saat layar masuk latar belakang, supaya pratinjau hidup tidak terus memakai GPU dan baterai. */
@Composable
internal fun PauseOnBackground(onPause: () -> Unit) {
    val cb = rememberUpdatedState(onPause)
    LifecycleEventEffect(Lifecycle.Event.ON_PAUSE) { cb.value() }
}

/**
 * Putar linimasa pratinjau berdasarkan jam dinding: posisi (0..1) maju sesuai waktu nyata dan berulang dari awal setelah selesai.
 * [render] dipanggil terus selama coroutine aktif; bila bingkai butuh waktu lebih lama dari satu tik, bingkai dilewati (waktu tidak
 * melambat). [render] mengembalikan false untuk menghentikan putaran (mis. saat gagal). [totalSec] dibaca ulang tiap bingkai
 * supaya perubahan durasi langsung berlaku.
 */
internal suspend fun runPreviewLoop(startFrac: Float, totalSec: () -> Double, render: suspend (Double) -> Boolean) {
    var base = if (startFrac >= 0.995f) 0.0 else startFrac.toDouble().coerceAtLeast(0.0)
    var t0 = System.nanoTime()
    while (currentCoroutineContext().isActive) {
        val total = totalSec().coerceAtLeast(1.0)
        var f = base + (System.nanoTime() - t0) / 1e9 / total
        if (f >= 1.0) { base = 0.0; t0 = System.nanoTime(); f = 0.0 }
        if (!render(f)) return
    }
}

@Composable
internal fun VuLabel(t: String) = Text(t, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

@Composable
internal fun VuNote(t: String) = Text(t, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)

@Composable
internal fun VuInfo(t: String) = Text(t, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun VuChips(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (k, n) -> FilterChip(selected = selected == k, onClick = { onSelect(k) }, label = { Text(n) }) }
    }
}

@Composable
internal fun VuToggle(label: String, on: Boolean, onChange: (Boolean) -> Unit) {
    FilterChip(selected = on, onClick = { onChange(!on) }, label = { Text(label) })
}

@Composable
internal fun VuSection(title: String, sub: String?, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        content()
    }
}

@Composable
internal fun VuSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, valueText: String, onChange: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { VuLabel(label); VuLabel(valueText) }
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range)
    }
}

private val VU_HEX = Regex("#[0-9a-fA-F]{6}")

/** Pilihan warna: [palette] siap pakai ditambah kolom kode hex. [allowEmpty] menambah pilihan "ikut bawaan" (nilai kosong). */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun VuColorPick(label: String, value: String, palette: List<Pair<String, String>>, emptyLabel: String?, onChange: (String) -> Unit) {
    VuLabel(label)
    val opts = (if (emptyLabel != null) listOf("" to emptyLabel) else emptyList()) + palette.map { it.second to it.first }
    VuChips(opts, opts.firstOrNull { it.first.equals(value, true) }?.first ?: "__custom") { onChange(it) }
    var text by remember(value) { mutableStateOf(value) }
    OutlinedTextField(
        value = text,
        onValueChange = { t ->
            val v = t.take(7).let { if (it.isNotEmpty() && !it.startsWith("#")) "#$it" else it }
            text = v
            if (VU_HEX.matches(v)) onChange(v.uppercase())
            else if (v.isEmpty() && emptyLabel != null) onChange("")
        },
        label = { Text("Kode warna (#RRGGBB)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
    )
}

/**
 * Tombol buat video + progres + hasil (simpan/bagikan) untuk render yang berbagi [RouteVideoJobs]. [myKey] mengenali render milik layar ini;
 * [onStart] dipanggil setelah izin notifikasi (Android 13+) diurus.
 */
@Composable
internal fun VideoRenderPanel(myKey: String, buttonLabel: String, enabled: Boolean, background: Boolean, onStart: () -> Unit) {
    val ctx = LocalContext.current
    val appCtx = ctx.applicationContext
    val job by RouteVideoJobs.state.collectAsState()
    var asked by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    val startRef = rememberUpdatedState(onStart)
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { startRef.value() }

    val running = job as? RenderState.Running
    val done = (job as? RenderState.Done)?.takeIf { it.key == myKey }
    val failed = (job as? RenderState.Failed)?.takeIf { it.key == myKey }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (running != null) {
            LinearProgressIndicator(progress = { running.progress }, modifier = Modifier.fillMaxWidth())
            Text(
                if (running.key == myKey) "Membuat video… ${(running.progress * 100).roundToInt()}%. " +
                    (if (background) "Boleh tutup layar ini; render lanjut di latar belakang." else "Biarkan layar ini tetap terbuka.")
                else "Masih membuat video “${running.label}” (${(running.progress * 100).roundToInt()}%).",
                style = MaterialTheme.typography.bodyMedium,
            )
            if (running.key == myKey) OutlinedButton(onClick = { RouteVideoJobs.cancel() }) { Text("Batal") }
        } else {
            Button(
                modifier = Modifier.fillMaxWidth(), enabled = enabled,
                onClick = {
                    if (background && Build.VERSION.SDK_INT >= 33 && !asked &&
                        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                    ) { asked = true; permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
                    else onStart()
                },
            ) { Text(buttonLabel) }
            if (failed != null) Text("Gagal membuat video: ${failed.message}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            if (done != null) {
                Text("Video siap.", style = MaterialTheme.typography.bodyMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        RouteVideoIo.saveToGallery(appCtx, done.file, done.file.name)
                            .onSuccess { msg = "Tersimpan di $it." }.onFailure { msg = "Gagal menyimpan: ${it.message}" }
                    }) { Text("Simpan ke galeri") }
                    OutlinedButton(onClick = { RouteVideoIo.share(ctx, done.file).onFailure { msg = "Gagal membagikan: ${it.message}" } }) { Text("Bagikan") }
                }
            }
        }
        if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ---------------------------------------------------------------------------------------------------------------------
// Editor berkategori: tab di atas, halaman digeser horizontal, isi tiap halaman digulir vertikal sendiri.
// ---------------------------------------------------------------------------------------------------------------------

/** Satu kategori pengaturan: [title] tampil di baris tab, [content] di halaman yang bisa digulir ke bawah. */
internal class EditorTab(val title: String, val content: @Composable ColumnScope.() -> Unit)

/**
 * Baris tab (bisa digulir bila banyak) + halaman yang digeser ke kiri/kanan. Tiap halaman punya gulir vertikal sendiri,
 * jadi pengaturan tidak lagi memanjang ke bawah dalam satu daftar. Memakai sisa tinggi kolom pemanggil.
 */
@Composable
internal fun ColumnScope.EditorPager(tabs: List<EditorTab>, startPage: Int = 0) {
    if (tabs.isEmpty()) return
    val pager = rememberPagerState(initialPage = startPage.coerceIn(0, tabs.lastIndex)) { tabs.size }
    val scope = rememberCoroutineScope()
    ScrollableTabRow(selectedTabIndex = pager.currentPage.coerceIn(0, tabs.lastIndex), edgePadding = 0.dp, divider = {}) {
        tabs.forEachIndexed { i, t ->
            Tab(
                selected = pager.currentPage == i,
                onClick = { scope.launch { pager.animateScrollToPage(i) } },
                text = { Text(t.title, maxLines = 1, style = MaterialTheme.typography.labelLarge) },
            )
        }
    }
    HorizontalPager(
        state = pager, modifier = Modifier.weight(1f).fillMaxWidth(),
        beyondViewportPageCount = 1, verticalAlignment = Alignment.Top, key = { it },
    ) { page ->
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(top = 12.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) { tabs[page.coerceIn(0, tabs.lastIndex)].content(this) }
    }
}

// ---------------------------------------------------------------------------------------------------------------------
// Zoom pratinjau (hanya tampilan; tidak mengubah hasil render): cubit, seret, ketuk dua kali, atau tombol − / +.
// ---------------------------------------------------------------------------------------------------------------------

/** Keadaan zoom pratinjau. [scale] 1..[MAX]; [tx]/[ty] adalah geseran piksel dari tengah. */
internal class PreviewZoom {
    var scale by mutableFloatStateOf(1f)
    var tx by mutableFloatStateOf(0f)
    var ty by mutableFloatStateOf(0f)

    val zoomed: Boolean get() = scale > 1.01f

    fun reset() { scale = 1f; tx = 0f; ty = 0f }

    /** Ubah skala ke [target] dengan titik [fx],[fy] (relatif tengah kotak) tetap di tempatnya, lalu jaga isi tetap menutupi kotak. */
    fun zoomTo(target: Float, fx: Float, fy: Float, w: Float, h: Float) {
        val s0 = scale
        val s1 = target.coerceIn(1f, MAX)
        if (s1 <= 1.001f) { reset(); return }
        tx = fx * (1f - s1 / s0) + tx * s1 / s0
        ty = fy * (1f - s1 / s0) + ty * s1 / s0
        scale = s1
        clamp(w, h)
    }

    fun pan(dx: Float, dy: Float, w: Float, h: Float) { tx += dx; ty += dy; clamp(w, h) }

    fun clamp(w: Float, h: Float) {
        val mx = (scale - 1f) * w / 2f; val my = (scale - 1f) * h / 2f
        tx = tx.coerceIn(-mx, mx); ty = ty.coerceIn(-my, my)
    }

    companion object { const val MAX = 6f }
}

/** Terapkan zoom/geser ke isi pratinjau (Image, dll.). Untuk View bawaan (VideoView) gunakan [applyTo]. */
internal fun Modifier.previewZoomLayer(z: PreviewZoom): Modifier = graphicsLayer {
    scaleX = z.scale; scaleY = z.scale; translationX = z.tx; translationY = z.ty
}

/** Samakan transformasi sebuah View bawaan (mis. VideoView berbasis SurfaceView, yang tidak ikut graphicsLayer Compose). */
internal fun PreviewZoom.applyTo(v: android.view.View) {
    v.scaleX = scale; v.scaleY = scale; v.translationX = tx; v.translationY = ty
}

/**
 * Kotak pratinjau yang bisa di-zoom. [content] digambar penuh di dalam kotak dan memakai [previewZoomLayer]. Isi di luar kotak
 * terpotong (sudut membulat). Di pojok kanan bawah ada kontrol kecil − / angka / + (ketuk angka = kembali 1×).
 */
@Composable
internal fun ZoomablePreview(zoom: PreviewZoom, modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    var w by remember { mutableFloatStateOf(1f) }
    var h by remember { mutableFloatStateOf(1f) }
    Box(
        modifier
            .clip(RoundedCornerShape(12.dp)).background(Color.Black)
            .onSizeChanged { sz -> w = sz.width.toFloat(); h = sz.height.toFloat(); zoom.clamp(w, h) }
            .pointerInput(Unit) {
                detectTransformGestures { centroid, pan, gestureZoom, _ ->
                    val fx = centroid.x - w / 2f; val fy = centroid.y - h / 2f
                    if (gestureZoom != 1f) zoom.zoomTo(zoom.scale * gestureZoom, fx, fy, w, h)
                    if (zoom.zoomed) zoom.pan(pan.x, pan.y, w, h)
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = { o ->
                    if (zoom.zoomed) zoom.reset() else zoom.zoomTo(2.5f, o.x - w / 2f, o.y - h / 2f, w, h)
                })
            },
        contentAlignment = Alignment.Center,
    ) {
        content()
        Row(
            Modifier.align(Alignment.BottomEnd).padding(6.dp).clip(RoundedCornerShape(50)).background(Color(0x99000000)),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ZoomBtn("−", zoom.scale > 1.01f) { zoom.zoomTo(if (zoom.scale <= 1.5f) 1f else zoom.scale / 1.5f, 0f, 0f, w, h) }
            Text(
                String.format(java.util.Locale.US, "%.1f×", zoom.scale),
                Modifier.clickable(enabled = zoom.zoomed) { zoom.reset() }.padding(horizontal = 4.dp),
                color = Color.White, style = MaterialTheme.typography.labelSmall,
            )
            ZoomBtn("+", zoom.scale < PreviewZoom.MAX - 0.01f) { zoom.zoomTo(zoom.scale * 1.5f, 0f, 0f, w, h) }
        }
    }
}

@Composable
private fun ZoomBtn(label: String, enabled: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(30.dp).clickable(enabled = enabled, onClick = onClick), contentAlignment = Alignment.Center) {
        Text(label, color = if (enabled) Color.White else Color(0x66FFFFFF), style = MaterialTheme.typography.titleMedium)
    }
}
