package com.endurancevault.app.ui.screens

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.domain.ActDetail
import com.endurancevault.app.domain.IntervalAnalysis
import com.endurancevault.app.domain.PeriodStats
import com.endurancevault.app.domain.SharePeriod
import com.endurancevault.app.domain.ShareSegments
import com.endurancevault.app.ui.UiState
import com.endurancevault.app.ui.i18n.Text
import com.endurancevault.app.ui.sticker.ShareBg
import com.endurancevault.app.ui.sticker.ShareCardRenderer
import com.endurancevault.app.ui.sticker.ShareDayExtra
import com.endurancevault.app.ui.sticker.ShareSize
import com.endurancevault.app.ui.sticker.StickerIo
import java.time.LocalDate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Bagikan statistik lari sebagai gambar: pilih periode (harian = aktivitas yang dibuka, mingguan Senin sampai Minggu,
 * bulanan tanggal 1 sampai akhir bulan) dan latar (gelap, foto, transparan). Dibuka dari menu ⋮ detail aktivitas.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ShareStatsScreen(state: UiState, id: Long, load: suspend (ActivityEntity) -> ActDetail?, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val e = state.activities.firstOrNull { it.id == id }
    var period by rememberSaveable { mutableStateOf(SharePeriod.WEEK) }
    var bg by rememberSaveable { mutableStateOf(ShareBg.DARK) }
    var size by rememberSaveable { mutableStateOf(ShareSize.FEED) }
    var photo by remember { mutableStateOf<Bitmap?>(null) }
    var msg by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) { if (photo == null) bg = ShareBg.DARK; return@rememberLauncherForActivityResult }
        scope.launch {
            val b = withContext(Dispatchers.IO) { StickerIo.decodePhoto(ctx, uri) }
            if (b == null) { msg = "Foto tidak bisa dibuka."; if (photo == null) bg = ShareBg.DARK } else { photo = b; bg = ShareBg.PHOTO; msg = "" }
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        TextButton(onClick = onBack) { Text("‹ Kembali") }
        Text("Bagikan statistik", style = MaterialTheme.typography.titleLarge)
        if (e == null || e.type == "bike" || e.km <= 0.0) {
            Text("Kartu statistik hanya tersedia untuk aktivitas lari yang punya jarak.")
            return@Column
        }
        val anchor = remember(e.dateIso) { LocalDate.parse(e.dateIso.take(10)) }
        val detail by produceState<ActDetail?>(null, e.id, e.detailFile, e.km, e.durationSec) { value = load(e) }
        val summary = remember(e, state.activities, period) {
            if (period == SharePeriod.DAY) PeriodStats.summarize(listOf(e), SharePeriod.DAY, anchor)
            else PeriodStats.summarize(state.activities, period, anchor)
        }
        val dayExtra = remember(detail) {
            detail?.takeIf { it.hasRoute }?.let { d ->
                val sp = d.splits.filter { it.pace > 0 }
                val laps = IntervalAnalysis.detect(d)?.takeIf { it.first == "lap" }?.second
                ShareDayExtra(d.route, sp.map { it.pace }, sp.lastOrNull()?.partial == true, ShareSegments.build(d.segments, laps))
            }
        }
        val card by produceState<Bitmap?>(null, summary, bg, photo, dayExtra, size) {
            value = withContext(Dispatchers.Default) { ShareCardRenderer.render(summary, bg, photo, if (period == SharePeriod.DAY) dayExtra else null, size) }
        }

        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = period == SharePeriod.DAY, onClick = { period = SharePeriod.DAY }, label = { Text("Harian") })
            FilterChip(selected = period == SharePeriod.WEEK, onClick = { period = SharePeriod.WEEK }, label = { Text("Mingguan") })
            FilterChip(selected = period == SharePeriod.MONTH, onClick = { period = SharePeriod.MONTH }, label = { Text("Bulanan") })
        }
        Text(
            when (period) {
                SharePeriod.DAY -> "Aktivitas yang sedang dibuka. Bila ada segmen (repetisi, istirahat, dst.), grafik pace memakai segmen."
                SharePeriod.WEEK -> "Senin sampai Minggu pada minggu aktivitas ini."
                SharePeriod.MONTH -> "Tanggal 1 sampai akhir bulan aktivitas ini."
            },
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Box(Modifier.fillMaxWidth().aspectRatio(size.w.toFloat() / size.h).clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp))) {
            if (bg == ShareBg.CLEAR) Checker(Modifier.fillMaxSize())
            card?.let { Image(it.asImageBitmap(), contentDescription = "Pratinjau kartu statistik", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
        }

        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = bg == ShareBg.DARK, onClick = { bg = ShareBg.DARK }, label = { Text("Gelap") })
            FilterChip(selected = bg == ShareBg.PHOTO, onClick = { if (photo == null) picker.launch("image/*") else bg = ShareBg.PHOTO }, label = { Text("Foto") })
            FilterChip(selected = bg == ShareBg.CLEAR, onClick = { bg = ShareBg.CLEAR }, label = { Text("Transparan") })
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = size == ShareSize.FEED, onClick = { size = ShareSize.FEED }, label = { Text("Feed 4:5") })
            FilterChip(selected = size == ShareSize.STORY, onClick = { size = ShareSize.STORY }, label = { Text("Story Instagram 9:16") })
        }
        if (bg == ShareBg.PHOTO) OutlinedButton(onClick = { picker.launch("image/*") }) { Text("Ganti foto") }
        if (bg == ShareBg.CLEAR) Text("Disimpan sebagai PNG transparan, cocok untuk ditempel di foto atau video.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

        val fileName = "statistik-${when (period) { SharePeriod.DAY -> "harian"; SharePeriod.WEEK -> "mingguan"; SharePeriod.MONTH -> "bulanan" }}-${summary.start}${if (size == ShareSize.STORY) "-story" else ""}.png"
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(modifier = Modifier.weight(1f), onClick = {
                val b = card ?: return@Button
                scope.launch {
                    val r = withContext(Dispatchers.IO) { StickerIo.saveToGallery(ctx, fileName, b) }
                    msg = r.fold({ "Tersimpan di $it." }, { "Gagal menyimpan: ${it.message}" })
                }
            }) { Text("Simpan") }
            OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                val b = card ?: return@OutlinedButton
                scope.launch {
                    val r = withContext(Dispatchers.IO) { StickerIo.share(ctx, fileName, b, "Bagikan statistik") }
                    msg = r.fold({ "" }, { "Berbagi gagal (${it.message}). Coba tombol Simpan." })
                }
            }) { Text("Bagikan") }
        }
        if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodySmall)
    }
}

/** Kotak-kotak abu-abu sebagai penanda area transparan pada pratinjau. */
@Composable
private fun Checker(modifier: Modifier) {
    Canvas(modifier) {
        val s = 16.dp.toPx()
        val cols = (size.width / s).toInt() + 1; val rows = (size.height / s).toInt() + 1
        for (r in 0 until rows) for (c in 0 until cols) {
            drawRect(if ((r + c) % 2 == 0) Color(0xFF8A8A8F) else Color(0xFFA9A9AE), Offset(c * s, r * s), Size(s, s))
        }
    }
}
