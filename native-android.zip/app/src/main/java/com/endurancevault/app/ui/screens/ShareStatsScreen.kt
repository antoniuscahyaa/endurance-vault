package com.endurancevault.app.ui.screens

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.domain.ActDetail
import com.endurancevault.app.domain.IntervalAnalysis
import com.endurancevault.app.domain.PeriodStats
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.SharePeriod
import com.endurancevault.app.domain.ShareSegments
import com.endurancevault.app.domain.SwDay
import com.endurancevault.app.domain.SwWeek
import com.endurancevault.app.ui.UiState
import com.endurancevault.app.ui.i18n.Text
import com.endurancevault.app.ui.sticker.ShareBg
import com.endurancevault.app.ui.sticker.ShareBrand
import com.endurancevault.app.ui.sticker.ShareBrandIo
import com.endurancevault.app.ui.sticker.ShareCardRenderer
import com.endurancevault.app.ui.sticker.ShareDayExtra
import com.endurancevault.app.ui.sticker.ShareExtras
import com.endurancevault.app.ui.sticker.ShareSize
import com.endurancevault.app.ui.sticker.ShareStatsPrefs
import com.endurancevault.app.ui.sticker.ShareTemplate
import com.endurancevault.app.ui.sticker.availableTemplates
import com.endurancevault.app.ui.sticker.StickerIo
import java.time.LocalDate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Bagikan statistik lari sebagai gambar: pilih periode (harian = aktivitas yang dibuka, mingguan Senin sampai Minggu,
 * bulanan tanggal 1 sampai akhir bulan) dan latar (solid, foto, transparan), template, dan judul kartu. Dibuka dari menu ⋮ detail aktivitas.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ShareStatsScreen(state: UiState, id: Long, load: suspend (ActivityEntity) -> ActDetail?, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val e = state.activities.firstOrNull { it.id == id }
    var period by rememberSaveable { mutableStateOf(SharePeriod.WEEK) }
    var bg by rememberSaveable { mutableStateOf(ShareBg.SOLID) }
    var size by rememberSaveable { mutableStateOf(ShareSize.FEED) }
    val prefs = remember { ShareStatsPrefs(ctx) }
    var titleRaw by remember { mutableStateOf(prefs.title) }
    var tplSel by remember { mutableStateOf(prefs.template) }
    val icon = remember { ShareBrandIo.appIcon(ctx) }
    var photo by remember { mutableStateOf<Bitmap?>(null) }
    var msg by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) { if (photo == null) bg = ShareBg.SOLID; return@rememberLauncherForActivityResult }
        scope.launch {
            val b = withContext(Dispatchers.IO) { StickerIo.decodePhoto(ctx, uri) }
            if (b == null) { msg = "Foto tidak bisa dibuka."; if (photo == null) bg = ShareBg.SOLID } else { photo = b; bg = ShareBg.PHOTO; msg = "" }
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        TextButton(onClick = onBack) { Text("‹ Kembali") }
        Text("Bagikan statistik", style = MaterialTheme.typography.titleLarge)
        if (e == null || e.type == "bike" || e.km <= 0.0) {
            Text("Kartu statistik hanya tersedia untuk aktivitas lari yang punya jarak.")
            return@Column
        }
        val anchor = remember(e.dateIso) { LocalDate.parse(e.dateIso.take(10)) }
        val detail by produceState<ActDetail?>(null, e.id, e.detailFile, e.km, e.durationSec) { value = load(e) }
        val summary = remember(e, state.activities, period) {
            if (period == SharePeriod.DAY) PeriodStats.summarize(listOf(e), SharePeriod.DAY, anchor)
            else PeriodStats.summarize(state.activities, period, anchor)
        }
        val dayExtra = remember(detail) {
            detail?.let { d ->
                val sp = d.splits.filter { it.pace > 0 }
                val laps = IntervalAnalysis.detect(d)?.takeIf { it.first == "lap" }?.second
                ShareDayExtra(if (d.hasRoute) d.route else emptyList(), sp.map { it.pace }, sp.lastOrNull()?.partial == true, ShareSegments.build(d.segments, laps))
            }
        }
        // Target (Cincin) dan pembanding (Banding) untuk periode ini.
        val target = remember(state.plan, summary) {
            val weeks = (state.plan as? PlanOutcome.Ok)?.weeks.orEmpty().map { w -> SwWeek(w.i, w.days.map { SwDay(it.date, it.kind, it.km) }, w.km) }
            PeriodStats.planTarget(weeks, summary.start, summary.end)
        }
        val prev = remember(state.activities, period) { PeriodStats.previous(state.activities, period, anchor) }
        val extras = remember(target, prev, period) { ShareExtras(target, prev, PeriodStats.previousLabel(period)) }
        val avail = availableTemplates(period, target != null, prev != null, (dayExtra?.splitPace?.size ?: 0) >= 2)
        val tpl = if (tplSel in avail) tplSel else ShareTemplate.CLASSIC
        val eSize = if (tpl == ShareTemplate.STRIP) ShareSize.STRIP else size
        val brand = remember(titleRaw, icon) { ShareBrand(ShareStatsPrefs.effectiveTitle(titleRaw), icon) }
        val card by produceState<Bitmap?>(null, summary, tpl, bg, photo, dayExtra, eSize, brand, extras) {
            delay(120)  // redam render ulang saat mengetik judul
            value = withContext(Dispatchers.Default) {
                ShareCardRenderer.render(summary, tpl, bg, photo, if (period == SharePeriod.DAY) dayExtra else null, eSize, brand, extras)
            }
        }

        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = period == SharePeriod.DAY, onClick = { period = SharePeriod.DAY }, label = { Text("Harian") })
            FilterChip(selected = period == SharePeriod.WEEK, onClick = { period = SharePeriod.WEEK }, label = { Text("Mingguan") })
            FilterChip(selected = period == SharePeriod.MONTH, onClick = { period = SharePeriod.MONTH }, label = { Text("Bulanan") })
        }
        Text(
            when (period) {
                SharePeriod.DAY -> "Aktivitas yang sedang dibuka. Bila ada segmen (repetisi, istirahat, dst.), grafik pace memakai segmen."
                SharePeriod.WEEK -> "Senin sampai Minggu pada minggu aktivitas ini."
                SharePeriod.MONTH -> "Tanggal 1 sampai akhir bulan aktivitas ini."
            },
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Box(Modifier.fillMaxWidth().aspectRatio(eSize.w.toFloat() / eSize.h).clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp))) {
            if (bg == ShareBg.CLEAR) Checker(Modifier.fillMaxSize())
            card?.let { Image(it.asImageBitmap(), contentDescription = "Pratinjau kartu statistik", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
        }

        Text("Template", style = MaterialTheme.typography.labelLarge)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            avail.forEach { t ->
                FilterChip(selected = tpl == t, onClick = { tplSel = t; prefs.template = t }, label = { Text(t.label) })
            }
        }
        Text("Latar", style = MaterialTheme.typography.labelLarge)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = bg == ShareBg.SOLID, onClick = { bg = ShareBg.SOLID }, label = { Text("Solid") })
            FilterChip(selected = bg == ShareBg.PHOTO, onClick = { if (photo == null) picker.launch("image/*") else bg = ShareBg.PHOTO }, label = { Text("Foto") })
            FilterChip(selected = bg == ShareBg.CLEAR, onClick = { bg = ShareBg.CLEAR }, label = { Text("Transparan") })
        }
        if (tpl != ShareTemplate.STRIP) FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = size == ShareSize.FEED, onClick = { size = ShareSize.FEED }, label = { Text("Feed 4:5") })
            FilterChip(selected = size == ShareSize.STORY, onClick = { size = ShareSize.STORY }, label = { Text("Story Instagram 9:16") })
        }
        OutlinedTextField(
            value = titleRaw, singleLine = true, modifier = Modifier.fillMaxWidth(),
            onValueChange = { v -> titleRaw = v.take(ShareBrand.MAX_LEN); prefs.title = titleRaw },
            label = { Text("Judul kartu") },
            trailingIcon = {
                if (titleRaw != ShareBrand.DEFAULT_TITLE) TextButton(onClick = { titleRaw = ShareBrand.DEFAULT_TITLE; prefs.title = titleRaw }) { Text("Reset") }
            },
        )
        Text("Kosong = ${ShareBrand.DEFAULT_TITLE}. Ikon aplikasi tampil di sebelah kiri judul.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (bg == ShareBg.PHOTO) OutlinedButton(onClick = { picker.launch("image/*") }) { Text("Ganti foto") }
        if (tpl == ShareTemplate.STRIP) Text("Strip selalu 1080 x 420. Solid = pil gelap, Foto = pil berisi foto, Transparan = teks saja.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (bg == ShareBg.CLEAR) Text("Disimpan sebagai PNG transparan, cocok untuk ditempel di foto atau video.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

        val fileName = "statistik-${when (period) { SharePeriod.DAY -> "harian"; SharePeriod.WEEK -> "mingguan"; SharePeriod.MONTH -> "bulanan" }}-${tpl.name.lowercase()}-${summary.start}${if (eSize == ShareSize.STORY) "-story" else ""}.png"
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(modifier = Modifier.weight(1f), onClick = {
                val b = card ?: return@Button
                scope.launch {
                    val r = withContext(Dispatchers.IO) { StickerIo.saveToGallery(ctx, fileName, b) }
                    msg = r.fold({ "Tersimpan di $it." }, { "Gagal menyimpan: ${it.message}" })
                }
            }) { Text("Simpan") }
            OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                val b = card ?: return@OutlinedButton
                scope.launch {
                    val r = withContext(Dispatchers.IO) { StickerIo.share(ctx, fileName, b, "Bagikan statistik") }
                    msg = r.fold({ "" }, { "Berbagi gagal (${it.message}). Coba tombol Simpan." })
                }
            }) { Text("Bagikan") }
        }
        if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodySmall)
    }
}

/** Kotak-kotak abu-abu sebagai penanda area transparan pada pratinjau. */
@Composable
private fun Checker(modifier: Modifier) {
    Canvas(modifier) {
        val s = 16.dp.toPx()
        val cols = (size.width / s).toInt() + 1; val rows = (size.height / s).toInt() + 1
        for (r in 0 until rows) for (c in 0 until cols) {
            drawRect(if ((r + c) % 2 == 0) Color(0xFF8A8A8F) else Color(0xFFA9A9AE), Offset(c * s, r * s), Size(s, s))
        }
    }
}
