package com.endurancevault.app.ui.screens

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import com.endurancevault.app.ui.floating.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.endurancevault.app.domain.GpxRoute
import com.endurancevault.app.domain.Js
import com.endurancevault.app.domain.TrailTarget
import com.endurancevault.app.ui.i18n.Text
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Hasil cek GPX untuk satu sesi trail: [review] terisi bila berhasil, selain itu [error] berisi pesan. */
internal class TrailReviewUi(
    val dayLabel: String, val targetKm: Double, val targetGain: Int?,
    val review: TrailTarget.Review?, val error: String?,
)

/** Baca berkas GPX dari [uri] lalu bandingkan dengan target sesi ([TrailTarget.reviewGpx]). Tidak melempar. */
internal suspend fun loadTrailReview(ctx: Context, uri: Uri, dayLabel: String, target: TrailTarget.Target): TrailReviewUi =
    withContext(Dispatchers.IO) {
        try {
            val xml = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                ?: throw GpxRoute.Err("GPX tidak dapat dibuka")
            val fileName = ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            } ?: uri.lastPathSegment ?: "Rute"
            TrailReviewUi(dayLabel, target.km, target.gain, TrailTarget.reviewGpx(xml, fileName, target.km, target.gain), null)
        } catch (e: GpxRoute.Err) {
            TrailReviewUi(dayLabel, target.km, target.gain, null, e.message ?: "GPX gagal diproses")
        } catch (e: Exception) {
            TrailReviewUi(dayLabel, target.km, target.gain, null, "GPX gagal diproses: ${e.message ?: e.javaClass.simpleName}")
        }
    }

@Composable
internal fun TrailReviewDialog(r: TrailReviewUi, onPickAgain: () -> Unit, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Cek GPX · ${r.dayLabel}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val rv = r.review
                if (rv == null) {
                    Text(r.error ?: "GPX gagal diproses", color = cs.error)
                } else {
                    Text(rv.routeName, fontWeight = FontWeight.SemiBold)
                    Text(
                        TrailTarget.verdict(rv.overall), fontSize = 16.sp, fontWeight = FontWeight.Bold,
                        color = when (rv.overall) {
                            TrailTarget.Level.OK -> cs.primary
                            TrailTarget.Level.NEAR -> cs.tertiary
                            TrailTarget.Level.OFF -> cs.error
                        },
                    )
                    MetricRow("Jarak", "${Js.fmtKm(rv.km.actual)} km", "target ${Js.fmtKm(rv.km.target)} km · ±${Js.fmtKm(rv.km.tol)}", rv.km.level)
                    rv.gain?.let {
                        MetricRow("D+", "+${Js.idn(Js.roundI(it.actual))} m", "target +${Js.idn(Js.roundI(it.target))} m · ±${Js.idn(Js.roundI(it.tol))}", it.level)
                    }
                    rv.lines.forEach { Text(it, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant) }
                    Text(
                        "Toleransi: jarak ±10% (min 1 km), D+ ±15% (min 50 m). Elevasi lebih longgar karena beda perangkat dan sumber data bisa selisih 10–15%.",
                        style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tutup") } },
        dismissButton = { TextButton(onClick = onPickAgain) { Text("Pilih GPX lain") } },
    )
}

@Composable
private fun MetricRow(label: String, actual: String, detail: String, level: TrailTarget.Level) {
    val cs = MaterialTheme.colorScheme
    val mark = when (level) { TrailTarget.Level.OK -> "✓"; TrailTarget.Level.NEAR -> "~"; TrailTarget.Level.OFF -> "!" }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(label, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(0.28f))
        Column(Modifier.weight(0.72f)) {
            Text("$mark $actual", fontWeight = FontWeight.SemiBold)
            Text(detail, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
        }
    }
}
