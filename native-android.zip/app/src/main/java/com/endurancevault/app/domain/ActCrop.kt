package com.endurancevault.app.domain

import java.time.ZoneId
import kotlin.math.hypot
import kotlin.math.max

/**
 * Crop aktivitas seperti di Strava: buang bagian awal dan/atau akhir, lalu hitung ulang semua angka turunan.
 *
 * Dasarnya deret 1 Hz (`tl`) yang tersimpan di berkas detail; sumbunya detik bergerak. Bagian terpilih dibangun ulang
 * lewat [ActBuilder.build] sehingga jarak, waktu, pace, GAP, HR, kadens, D+/D−, split, profil, histogram HR, dan
 * deret grafik konsisten dengan impor biasa. Rute (`rt`/`ge`) tidak punya waktu per titik, jadi dipotong menurut
 * proporsi jarak sepanjang garis rute.
 */
object ActCrop {
    const val MIN_SECONDS = 60
    const val MIN_METERS = 200.0

    /** Rentang indeks deret yang terpilih beserta jarak dan lamanya. */
    class Window(val i0: Int, val i1: Int, val meters: Double, val seconds: Int) {
        val valid: Boolean get() = seconds >= MIN_SECONDS && meters >= MIN_METERS
    }

    class Cropped(
        val act: Map<String, Any?>,
        val km: Double, val durationSec: Int,
        val avgHr: Int?, val maxHr: Int?, val gain: Int?,
    )

    /** Deret 1 Hz dari objek aktivitas (kunci `tl`); null bila tidak ada, tidak berurutan, atau terlalu pendek. */
    fun seriesOf(act: Map<String, Any?>): ActivityTimeSeries? {
        val tl = act["tl"] as? Map<*, *> ?: return null
        if ((tl["r"] as? Number)?.toInt() != 1) return null
        fun list(key: String): List<Any?> = (tl[key] as? List<*>).orEmpty()
        val sec = list("s").mapNotNull { (it as? Number)?.toInt() }
        val dist = list("d").map { (it as? Number)?.toDouble() ?: 0.0 }
        val hr = list("h").map { (it as? Number)?.toInt() ?: 0 }
        val cad = list("c").map { (it as? Number)?.toInt() ?: 0 }
        val elev = list("e").map { (it as? Number)?.toDouble() }
        val n = listOf(sec.size, dist.size, hr.size, cad.size, elev.size).min()
        if (n < 2) return null
        return ActivityTimeSeries(
            sec.take(n), dist.take(n), hr.take(n), cad.take(n), elev.take(n),
            List(n) { 0 }, List(n) { null },
        )
    }

    /** Rentang [startSec]..[endSec] (detik bergerak) pada deret; null bila kosong. Dipakai pratinjau UI dan [crop] agar sama. */
    fun window(ts: ActivityTimeSeries, startSec: Int, endSec: Int): Window? {
        val i0 = ts.seconds.indexOfFirst { it >= startSec }
        val i1 = ts.seconds.indexOfLast { it <= endSec }
        if (i0 < 0 || i1 <= i0) return null
        return Window(i0, i1, ts.distanceMeters[i1] - ts.distanceMeters[i0], ts.seconds[i1] - ts.seconds[i0])
    }

    fun crop(act: Map<String, Any?>, startSec: Int, endSec: Int, zone: ZoneId = ZoneId.systemDefault()): Cropped {
        val ts = seriesOf(act) ?: throw ActImportException("Aktivitas ini tidak punya data per detik, jadi belum bisa dipotong")
        val w = window(ts, startSec, endSec) ?: throw ActImportException("Rentang crop kosong")
        if (!w.valid) throw ActImportException("Hasil crop minimal 1 menit dan 200 m")

        val secBase = ts.seconds[w.i0]
        val distBase = ts.distanceMeters[w.i0]
        val pts = (w.i0..w.i1).map { i ->
            Pt(
                t = (ts.seconds[i] - secBase) * 1000.0,
                d = ts.distanceMeters[i] - distBase,
                e = ts.elevationMeters[i] ?: Double.NaN,
                h = ts.heartRateBpm[i].let { if (it > 0) it.toDouble() else Double.NaN },
                c = ts.cadenceSpm[i].let { if (it > 0) it.toDouble() else Double.NaN },
            )
        }
        val xk = act["xk"] as? String
        val bike = act["bike"] == true
        val sport = when {
            xk == "hike" -> "hiking"
            xk == "swim" -> "swimming"
            bike -> "biking"
            else -> "running"
        }
        val built = ActBuilder.build(pts, sport, (act["nm"] as? String).orEmpty(), zone, cadScale = 1)

        val out = LinkedHashMap<String, Any?>(act)
        for ((k, v) in built) out[k] = v
        // Identitas sesi (kapan dan apa) tetap; yang berubah hanya isi lintasannya.
        for (k in listOf("t0", "date", "st", "nm", "bike", "xk")) if (act.containsKey(k)) out[k] = act[k] else out.remove(k)
        // Angka yang hanya bermakna untuk sesi utuh (lap, VAM terbaik, baterai jam) tidak bisa dihitung ulang dari deret ini.
        for (k in listOf("sg", "vam", "bat")) out.remove(k)

        val newLen = w.seconds
        val shift = secBase
        (act["ez"] as? Map<*, *>)?.let { ez ->
            val m = LinkedHashMap<String, Any?>()
            ez.forEach { (k, v) -> m[k.toString()] = v }
            val st = m["st"]
            if (st is Number) shiftStride(st.toInt(), shift, newLen)?.let { m["st"] = it } ?: m.remove("st")
            out["ez"] = m
        }
        (act["zs"] as? Number)?.let { z -> shiftStride(z.toInt(), shift, newLen)?.let { out["zs"] = it } ?: out.remove("zs") }

        val d0km = distBase / 1000.0
        val d1km = ts.distanceMeters[w.i1] / 1000.0
        val vs = (act["vs"] as? List<*>).orEmpty().mapNotNull { e ->
            val l = e as? List<*> ?: return@mapNotNull null
            val k = (l.getOrNull(0) as? Number)?.toDouble() ?: return@mapNotNull null
            val v = (l.getOrNull(1) as? Number)?.toDouble() ?: return@mapNotNull null
            if (k < d0km || k > d1km) null else listOf(Js.round((k - d0km) * 1000) / 1000, v)
        }
        if (vs.isEmpty()) out.remove("vs") else out["vs"] = vs

        val totalM = ts.distanceMeters.last() - ts.distanceMeters.first()
        val route = if (totalM > 0) cropRoute(act, (distBase - ts.distanceMeters.first()) / totalM, (ts.distanceMeters[w.i1] - ts.distanceMeters.first()) / totalM) else null
        if (route != null) {
            out["rt"] = route.rt; out["rw"] = route.rw; out["rh"] = route.rh; out["ge"] = route.ge
            if (act.containsKey("sla") && route.startLat != null && route.startLon != null) {
                out["sla"] = Js.round(route.startLat * 1000) / 1000; out["slo"] = Js.round(route.startLon * 1000) / 1000
            }
        } else {
            out["rt"] = emptyList<Any?>(); out["rw"] = 0; out["rh"] = 0; out["ge"] = null
        }

        val km = (built["km"] as Number).toDouble()
        val min = (built["min"] as Number).toDouble()
        return Cropped(
            out, km, Js.roundI(min * 60),
            (built["hr"] as? Number)?.toInt(), (built["hrMax"] as? Number)?.toInt(), (built["gain"] as? Number)?.toInt(),
        )
    }

    /** Awal fase "setelah pemanasan" bergeser mengikuti potongan: sebelum awal jadi 0, setelah akhir dibuang. */
    private fun shiftStride(st: Int, shift: Int, len: Int): Int? {
        val n = max(0, st - shift)
        return if (n > len) null else n
    }

    class Route(
        val rt: List<List<Int>>, val rw: Int, val rh: Int, val ge: List<Double>?,
        val startLat: Double?, val startLon: Double?,
    )

    /** Potong rute ternormalisasi menurut proporsi panjang garis [f0]..[f1] (0..1); null bila rute tidak ada atau hasilnya terlalu pendek. */
    internal fun cropRoute(act: Map<String, Any?>, f0: Double, f1: Double): Route? {
        val raw = (act["rt"] as? List<*>).orEmpty().mapNotNull { e ->
            val l = e as? List<*> ?: return@mapNotNull null
            val x = (l.getOrNull(0) as? Number)?.toDouble() ?: return@mapNotNull null
            val y = (l.getOrNull(1) as? Number)?.toDouble() ?: return@mapNotNull null
            x to y
        }
        if (raw.size < 2) return null
        val frame = RouteGeo.frameOf(act["ge"] as? List<*>)
        val sc0 = frame?.scale ?: 1.0
        val mnx0 = frame?.let { it.lonMin * it.cosLat } ?: 0.0
        val mxy0 = frame?.latMax ?: 0.0
        // Koordinat isotropik (lon·cos, lat) dalam derajat; panjang Euclid di sini sebanding dengan jarak sebenarnya.
        val xs = raw.map { it.first / sc0 + mnx0 }
        val ys = raw.map { mxy0 - it.second / sc0 }
        val cum = DoubleArray(xs.size)
        for (i in 1 until xs.size) cum[i] = cum[i - 1] + hypot(xs[i] - xs[i - 1], ys[i] - ys[i - 1])
        val total = cum.last()
        if (!(total > 0.0)) return null
        val l0 = total * f0.coerceIn(0.0, 1.0)
        val l1 = total * f1.coerceIn(0.0, 1.0)
        if (!(l1 > l0)) return null

        fun at(l: Double): Pair<Double, Double> {
            var i = 1
            while (i < cum.size - 1 && cum[i] < l) i++
            val seg = cum[i] - cum[i - 1]
            val f = if (seg > 0) ((l - cum[i - 1]) / seg).coerceIn(0.0, 1.0) else 0.0
            return (xs[i - 1] + (xs[i] - xs[i - 1]) * f) to (ys[i - 1] + (ys[i] - ys[i - 1]) * f)
        }
        val pts = ArrayList<Pair<Double, Double>>()
        pts += at(l0)
        for (i in xs.indices) if (cum[i] > l0 && cum[i] < l1) pts += xs[i] to ys[i]
        pts += at(l1)
        val dedup = ArrayList<Pair<Double, Double>>()
        for (p in pts) if (dedup.isEmpty() || dedup.last() != p) dedup += p
        if (dedup.size < 2) return null

        val mnx = dedup.minOf { it.first }; val mxx = dedup.maxOf { it.first }
        val mny = dedup.minOf { it.second }; val mxy = dedup.maxOf { it.second }
        val sc = 1000 / max(max(mxx - mnx, mxy - mny), 1e-9)
        val rt = dedup.map { listOf(Js.roundI((it.first - mnx) * sc), Js.roundI((mxy - it.second) * sc)) }
        fun f6(x: Double) = Js.round(x * 1e6) / 1e6
        val ge = frame?.let { listOf(f6(mnx / it.cosLat), f6(mxy), Js.round(sc * 1e4) / 1e4, f6(it.cosLat)) }
        return Route(
            rt, Js.roundI((mxx - mnx) * sc), Js.roundI((mxy - mny) * sc), ge,
            frame?.let { dedup.first().second }, frame?.let { dedup.first().first / it.cosLat },
        )
    }

    /** Pace rata-rata (menit/km) untuk pratinjau; null bila jarak nol. */
    fun previewPace(w: Window): Double? = if (w.meters > 0) (w.seconds / 60.0) / (w.meters / 1000.0) else null
}
