package com.endurancevault.app.ui


import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import com.endurancevault.app.domain.TrainingMetrics

import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.Icon
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.Surface
import androidx.compose.foundation.layout.size
import androidx.compose.ui.Alignment
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.navArgument
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.endurancevault.app.ui.screens.ActivityDetailScreen
import com.endurancevault.app.ui.screens.ProfileScreen
import com.endurancevault.app.ui.screens.ProgressScreen
import com.endurancevault.app.ui.screens.ScheduleScreen
import com.endurancevault.app.ui.screens.PlanOverviewScreen
import com.endurancevault.app.ui.screens.TodayScreen
import com.endurancevault.app.ui.screens.HuaweiWatchSection
import com.endurancevault.app.ui.screens.WatchDockScreen

private enum class Tab(val route: String, val label: String, val icon: ImageVector) {
    Today("today", "Hari ini", Icons.Filled.Home),
    Profile("profile", "Profil", Icons.Filled.Person),
    Watch("watch", "Jam", Icons.Filled.Favorite),
    Week("week", "Minggu", Icons.Filled.CalendarMonth),
    Schedule("schedule", "Jadwal", Icons.Filled.CalendarMonth),
}

@Composable
private fun EnduranceProfileHeader(
    name: String,
    photoUri: String?,
    recoveryHours: Int,
    onEditName: () -> Unit,
    onOpenSettings: () -> Unit,
    onPickPhoto: () -> Unit,
) {
    val context = LocalContext.current
    val avatar by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, photoUri) {
        value = if (photoUri.isNullOrBlank()) null else withContext(Dispatchers.IO) {
            runCatching {
                context.contentResolver.openInputStream(Uri.parse(photoUri))?.use {
                    BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = 4 })?.asImageBitmap()
                }
            }.getOrNull()
        }
    }
    val readyAt = LocalTime.now().plusHours(recoveryHours.coerceAtLeast(0).toLong())
    val readyLabel = readyAt.format(DateTimeFormatter.ofPattern("HH:mm"))
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        androidx.compose.foundation.layout.Box(
            modifier = Modifier.size(62.dp).clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape)
                .clickable(onClick = onPickPhoto),
            contentAlignment = Alignment.Center,
        ) {
            if (avatar != null) {
                Image(bitmap = avatar!!, contentDescription = "Foto profil", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize().clip(CircleShape))
            } else {
                Icon(Icons.Filled.Person, contentDescription = "Pilih foto profil", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(32.dp))
            }
            androidx.compose.foundation.layout.Box(
                Modifier.align(Alignment.BottomEnd).size(20.dp).clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surface).border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Filled.Edit, contentDescription = null, modifier = Modifier.size(12.dp), tint = MaterialTheme.colorScheme.primary) }
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth().clickable(onClick = onEditName),
            ) {
                Text(
                    name.ifBlank { "Tambahkan nama profil" },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                )
                Icon(Icons.Filled.Edit, contentDescription = "Edit nama", modifier = Modifier.padding(start = 6.dp).size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp,
                shadowElevation = 1.dp,
            ) {
                Row(
                    Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(7.dp),
                ) {
                    androidx.compose.foundation.layout.Box(Modifier.size(7.dp).clip(CircleShape).background(Color(0xFF3D8A69)))
                    Text("Recovery ${recoveryHours} h", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                    Text("ready $readyLabel", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Surface(
            shape = CircleShape, color = MaterialTheme.colorScheme.surface,
            tonalElevation = 3.dp, shadowElevation = 2.dp,
            modifier = Modifier.size(48.dp).clickable(onClick = onOpenSettings),
        ) {
            androidx.compose.foundation.layout.Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Settings, contentDescription = "Pengaturan", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
            }
        }
    }
}

/** Isi ProfileScreen dengan semua state dari ViewModel; dipakai oleh tab Profil dan halaman Pengaturan terpisah. */
@Composable
private fun ProfileHost(vm: MainViewModel, state: UiState, onOpenActivity: (Long) -> Unit, settingsMode: Boolean, onBack: () -> Unit) {
        val imp by vm.importState.collectAsState()
        val backupUi by vm.backupState.collectAsState()
        val watchMsg by vm.watchMessage.collectAsState()
        val watchSyncing by vm.watchSyncing.collectAsState()
        val watchAdvancedMessage by vm.watchAdvancedMessage.collectAsState()
        val liveHr by vm.liveHrJson.collectAsState()
        val weather by vm.weatherMessage.collectAsState()
        val weatherBusy by vm.weatherBusy.collectAsState()
        val weatherLat by vm.weatherLat.collectAsState()
        val weatherLon by vm.weatherLon.collectAsState()
        val weatherWatchStatus by vm.weatherWatchStatus.collectAsState()
        val agpsStatus by vm.agpsStatus.collectAsState()
        val notifyStatus by vm.notifyStatus.collectAsState()
        val aiStatus by vm.aiStatus.collectAsState()
        val aiMessages by vm.aiMessages.collectAsState()
        val aiBusy by vm.aiBusy.collectAsState()
        val duplicateStatus by vm.duplicateStatus.collectAsState()
        val profileTrackMsg by vm.trackMsg.collectAsState()
        ProfileScreen(
            state, vm::saveSettings, imp, vm::startImport, vm::confirmImport, vm::dismissImport, vm::mergeDuplicateActivities, vm::scanDuplicateActivities, duplicateStatus,
            vm::saveDaily, vm::saveGear, vm::deleteGear,
            watchMsg, vm::connectWatch, vm::disconnectWatch, vm::forgetAndReconnectWatch, vm::syncWatch, watchSyncing,
            watchAdvancedMessage, liveHr, vm::refreshLiveHr, vm::setLiveHr, vm::syncWatchHrZones,
            vm::pushStructuredWorkout, vm::pushGpxRoute,
            weather, weatherBusy, weatherLat, weatherLon, { lat, lon -> vm.fetchWeather(lat, lon) }, { q -> vm.searchWeatherCity(q) }, vm::useCurrentLocation, { lat, lon, name -> vm.sendWeatherToWatch(lat, lon, name) },
            weatherWatchStatus, agpsStatus, { enabled, mirror -> vm.setAgps(enabled, mirror) }, { vm.testAgps() },
            notifyStatus, { enabled, quiet, start, end, screenOff, apps -> vm.setWatchNotifications(enabled, quiet, start, end, screenOff, apps) }, { vm.testWatchNotification() },
            aiStatus, aiMessages, vm::saveAiKey, vm::sendAiQuestion, aiBusy,
            vm::deleteActivity, onOpenActivity, vm::importTracks, profileTrackMsg,
            settingsMode = settingsMode, onBack = onBack,
            backupUi = backupUi, backupFileName = vm::backupFileName, onExportBackup = vm::exportBackup,
            onStartRestore = vm::startRestore, onConfirmRestore = vm::confirmRestore, onDismissBackup = vm::dismissBackup,
        )
}

@Composable
fun AppRoot(vm: MainViewModel = viewModel()) {
    val nav = rememberNavController()
    val state by vm.state.collectAsState()
    val context = LocalContext.current
    val profilePrefs = remember { context.getSharedPreferences("profile_identity", android.content.Context.MODE_PRIVATE) }
    var profileName by remember { mutableStateOf(profilePrefs.getString("name", "") ?: "") }
    var profilePhotoUri by remember { mutableStateOf(profilePrefs.getString("photo_uri", null)) }
    var showProfileNameDialog by remember { mutableStateOf(false) }
    var showSettings by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf(false) }
    androidx.activity.compose.BackHandler(enabled = showSettings) { showSettings = false }
    var editedProfileName by remember { mutableStateOf(profileName) }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            profilePhotoUri = uri.toString()
            profilePrefs.edit().putString("photo_uri", uri.toString()).apply()
        }
    }
    val trainingMetrics = remember(state.settings, state.activities, state.daily, state.plan, state.hrHistByActivity) {
        runCatching { TrainingMetrics.calculate(state.settings, state.activities, state.daily, state.plan, hrHistByActivity = state.hrHistByActivity) }.getOrNull()
    }
    val recoveryHours = trainingMetrics?.recoveryRemainingHours ?: 0
    val current = nav.currentBackStackEntryAsState().value?.destination?.route
    // Jadwal is a contextual destination: it exists only while a training plan is selected.
    val hasTrainingPlan = state.settings.rtype != "none"
    LaunchedEffect(hasTrainingPlan, current) {
        if (!hasTrainingPlan && current == Tab.Schedule.route) {
            nav.navigate(Tab.Week.route) { popUpTo(Tab.Today.route); launchSingleTop = true }
        }
    }
    val tabs = buildList {
        add(Tab.Today); add(Tab.Profile); add(Tab.Watch); add(Tab.Week)
        if (hasTrainingPlan) add(Tab.Schedule)
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentColor = MaterialTheme.colorScheme.onBackground,
        bottomBar = {
            // Dock mengikuti pola aplikasi lama: transparan, empat tujuan utama,
            // Today menjadi tombol utama; Jadwal hanya muncul ketika plan aktif.
            if (!showSettings) Surface(color = MaterialTheme.colorScheme.background, tonalElevation = 0.dp) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth().navigationBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .shadow(10.dp, RoundedCornerShape(32.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(32.dp))
                            .padding(horizontal = 6.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                    tabs.forEach { t ->
                        val selected = current == t.route || (t == Tab.Profile && current == "progress")
                        val isHome = t == Tab.Today
                        Column(
                            modifier = Modifier
                                .weight(if (isHome) 1.18f else 1f)
                                .height(54.dp)
                                .then(
                                    if (isHome && selected) Modifier
                                        .shadow(1.dp, RoundedCornerShape(14.dp))
                                        .then(Modifier)
                                    else Modifier
                                )
                                .background(
                                    if (isHome && selected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    RoundedCornerShape(14.dp),
                                )
                                .clickable {
                                    nav.navigate(t.route) {
                                        popUpTo(Tab.Today.route) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                                .padding(vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                        ) {
                            Icon(
                                t.icon,
                                contentDescription = t.label,
                                modifier = Modifier.size(20.dp),
                                tint = when {
                                    isHome && selected -> MaterialTheme.colorScheme.onPrimary
                                    selected -> MaterialTheme.colorScheme.primary
                                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                                },
                            )
                            Text(
                                t.label,
                                maxLines = 1,
                                style = MaterialTheme.typography.labelSmall,
                                color = when {
                                    isHome && selected -> MaterialTheme.colorScheme.onPrimary
                                    selected -> MaterialTheme.colorScheme.primary
                                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                                },
                            )
                        }
                    }
                    }
                }
            }
        },
    ) { pad ->
        if (showSettings) {
            // Halaman penuh di luar kartu utama: tanpa header profil dan tanpa dock.
            androidx.compose.foundation.layout.Box(Modifier.fillMaxSize().padding(pad).background(MaterialTheme.colorScheme.background)) {
                ProfileHost(vm, state, onOpenActivity = { id -> showSettings = false; nav.navigate("activity/$id") }, settingsMode = true, onBack = { showSettings = false })
            }
        } else Column(
            modifier = Modifier.fillMaxSize().padding(pad).background(MaterialTheme.colorScheme.background),
        ) {
            EnduranceProfileHeader(
                name = profileName,
                photoUri = profilePhotoUri,
                recoveryHours = recoveryHours,
                onEditName = { editedProfileName = profileName; showProfileNameDialog = true },
                onOpenSettings = { showSettings = true },
                onPickPhoto = { photoPicker.launch(arrayOf("image/*")) },
            )
            Surface(
                modifier = Modifier.fillMaxWidth().weight(1f).padding(horizontal = 14.dp).padding(bottom = 8.dp),
                shape = RoundedCornerShape(30.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
                shadowElevation = 2.dp,
            ) {
                NavHost(nav, startDestination = Tab.Today.route, modifier = Modifier.fillMaxSize()) {
            composable(Tab.Today.route) {
                val weatherSnap by vm.weatherSnapshot.collectAsState()
                val weatherBusy by vm.weatherBusy.collectAsState()
                val weatherLabel by vm.weatherPlaceLabel.collectAsState()
                val weatherError by vm.weatherError.collectAsState()
                TodayScreen(
                    state = state, onAdd = vm::addActivity, weather = weatherSnap, weatherPlaceLabel = weatherLabel,
                    weatherBusy = weatherBusy, weatherError = weatherError,
                    onRefreshWeather = vm::refreshWeatherFromCard,
                    onAutoRefreshWeather = { maxAge -> vm.refreshWeatherIfStale(maxAge) },
                    onOpenActivity = { id -> nav.navigate("activity/$id") },
                    onGoWeek = { nav.navigate(Tab.Week.route) { launchSingleTop = true } },
                )
            }
            composable("progress") {
                val trackMsg by vm.trackMsg.collectAsState()
                ProgressScreen(
                    state = state,
                    onDelete = vm::deleteActivity,
                    onOpen = { id -> nav.navigate("activity/$id") },
                    onImportTracks = vm::importTracks,
                    trackMsg = trackMsg,
                )
            }
            composable(Tab.Week.route) {
                ScheduleScreen(
                    state,
                    onOpenActivity = { id -> nav.navigate("activity/$id") },
                    onSetMv = vm::setMv,
                    onSetDone = vm::setDone,
                )
            }
            composable(Tab.Schedule.route) {
                if (hasTrainingPlan) PlanOverviewScreen(state) else TodayScreen(state, vm::addActivity)
            }
            composable(Tab.Watch.route) {
                val watchMsg by vm.watchMessage.collectAsState()
                val watchSyncing by vm.watchSyncing.collectAsState()
                val watchAdvancedMessage by vm.watchAdvancedMessage.collectAsState()
                val dock by vm.watchDock.collectAsState()
                val dockWx by vm.weatherSnapshot.collectAsState()
                val dockLastSyncJs by vm.watchLastSyncJs.collectAsState()
                val dockAlias by vm.watchAlias.collectAsState()
                androidx.compose.foundation.lazy.LazyColumn(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 18.dp, bottom = 24.dp),
                ) {
                    item {
                        // Dock Jam: kartu jam, ubin data harian, latihan dari jam. Roda gigi membuka halaman pengaturan jam (route watchsettings).
                        WatchDockScreen(
                            ui = dock, activities = state.activities, wx = dockWx, syncing = watchSyncing,
                            lastSyncJsSec = dockLastSyncJs, message = watchMsg, alias = dockAlias,
                            onRefresh = vm::refreshWatchDock, onSync = { vm.syncWatch(false) }, onSaveAlias = vm::setWatchAlias,
                            onPickGpx = vm::pushGpxRoute, onOpenActivity = { id -> nav.navigate("activity/$id") },
                            onOpenSettings = { nav.navigate("watchsettings") },
                        )
                    }
                }
            }
            composable("watchsettings") {
                val watchMsg by vm.watchMessage.collectAsState()
                val watchSyncing by vm.watchSyncing.collectAsState()
                val watchAdvancedMessage by vm.watchAdvancedMessage.collectAsState()
                androidx.compose.foundation.layout.Box(Modifier.fillMaxSize()) {
                    androidx.compose.foundation.lazy.LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                        verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 18.dp, bottom = 96.dp),
                    ) {
                        item {
                            HuaweiWatchSection(
                                message = watchMsg, onConnect = vm::connectWatch, onDisconnect = vm::disconnectWatch,
                                onForgetAndReconnect = vm::forgetAndReconnectWatch, onSync = vm::syncWatch,
                                isSyncing = watchSyncing, settings = state.settings, advancedMessage = watchAdvancedMessage,
                                onSyncHrZones = vm::syncWatchHrZones, onPushWorkout = vm::pushStructuredWorkout,
                                onSaveSettings = vm::saveSettings, daily = state.daily,
                            )
                        }
                    }
                    androidx.compose.foundation.layout.Box(
                        Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(72.dp).background(
                            androidx.compose.ui.graphics.Brush.verticalGradient(
                                listOf(androidx.compose.ui.graphics.Color.Transparent, MaterialTheme.colorScheme.surface),
                            ),
                        ),
                    )
                    Surface(
                        modifier = Modifier.align(Alignment.BottomEnd).padding(end = 18.dp, bottom = 18.dp).size(44.dp)
                            .clip(CircleShape).clickable { nav.popBackStack() },
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shadowElevation = 4.dp,
                    ) {
                        androidx.compose.foundation.layout.Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali", modifier = Modifier.size(22.dp))
                        }
                    }
                }
            }
            composable("activity/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
                ActivityDetailScreen(state, e.arguments?.getLong("id") ?: -1L, vm::detailOf, trainingMetrics, vm::setActivityGear, vm::setActivityFeel) { nav.popBackStack() }
            }
            composable(Tab.Profile.route) {
                ProfileHost(vm, state, onOpenActivity = { id -> nav.navigate("activity/$id") }, settingsMode = false, onBack = {})
            }
                }
            }
        }
        if (showProfileNameDialog) {
            AlertDialog(
                onDismissRequest = { showProfileNameDialog = false },
                title = { Text("Nama profil") },
                text = {
                    OutlinedTextField(
                        value = editedProfileName,
                        onValueChange = { editedProfileName = it },
                        singleLine = true,
                        label = { Text("Nama") },
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        profileName = editedProfileName.trim()
                        profilePrefs.edit().putString("name", profileName).apply()
                        showProfileNameDialog = false
                    }) { Text("Simpan") }
                },
                dismissButton = { TextButton(onClick = { showProfileNameDialog = false }) { Text("Batal") } },
            )
        }
    }
}
