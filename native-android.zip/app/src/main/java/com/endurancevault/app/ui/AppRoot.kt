package com.endurancevault.app.ui


import com.endurancevault.app.ui.i18n.Text
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import com.endurancevault.app.domain.TrainingMetrics

import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.Icon
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.foundation.layout.size
import androidx.compose.ui.Alignment
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.navArgument
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.endurancevault.app.ui.screens.ActivityDetailScreen
import com.endurancevault.app.ui.screens.RouteVideoScreen
import com.endurancevault.app.ui.screens.StickerScreen
import com.endurancevault.app.ui.screens.ProfileScreen
import com.endurancevault.app.ui.screens.rememberProfileAvatar
import com.endurancevault.app.ui.screens.ProgressScreen
import com.endurancevault.app.ui.screens.ScheduleScreen
import com.endurancevault.app.ui.screens.PlanOverviewScreen
import com.endurancevault.app.ui.screens.TodayScreen
import com.endurancevault.app.ui.screens.HuaweiWatchSection
import com.endurancevault.app.domain.ProgressAnalytics
import com.endurancevault.app.domain.CourseStrategy
import com.endurancevault.app.domain.ExSession
import com.endurancevault.app.domain.Kinds
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.RouteGeo
import com.endurancevault.app.ui.screens.ExploreCollectionScreen
import com.endurancevault.app.ui.screens.ExploreRouteDetailScreen
import com.endurancevault.app.ui.screens.ExploreScreen
import com.endurancevault.app.ui.screens.exViewAt
import com.endurancevault.app.ui.screens.GpxPreviewDialog
import com.endurancevault.app.ui.screens.WatchBadge
import com.endurancevault.app.ui.screens.restHrFrom
import com.endurancevault.app.ui.screens.WatchDockScreen
import com.endurancevault.app.ui.screens.WatchHeaderPill
import com.endurancevault.app.ui.screens.WatchDot
import com.endurancevault.app.ui.screens.planSummaryOf
import com.endurancevault.app.ui.screens.settingsIcon
import com.endurancevault.app.ui.theme.cardTint
import com.endurancevault.app.ui.theme.onCardTint
import com.endurancevault.app.ui.screens.watchBadgeOf
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.rotate
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.outlined.Watch
import kotlinx.coroutines.launch

private enum class Tab(val route: String, val label: String, val icon: ImageVector) {
    Today("today", "Hari ini", Icons.Filled.Home),
    Profile("profile", "Profil", Icons.Filled.Person),
    Progress("progress", "Progres", Icons.Filled.ShowChart),
    Watch("watch", "Jam", Icons.Filled.Favorite),
    Week("week", "Minggu", Icons.Filled.CalendarMonth),
    Schedule("schedule", "Jadwal", Icons.Filled.CalendarMonth),
    Explore("explore", "Explore", Icons.Filled.Explore),
}

@Composable
private fun EnduranceProfileHeader(
    name: String,
    photoUri: String?,
    recoveryHours: Int,
    onOpenDrawer: () -> Unit,
    onOpenSettings: () -> Unit,
    watchBadge: WatchBadge? = null,
) {
    val avatar = rememberProfileAvatar(photoUri)
    val readyAt = LocalTime.now().plusHours(recoveryHours.coerceAtLeast(0).toLong())
    val readyLabel = readyAt.format(DateTimeFormatter.ofPattern("HH:mm"))
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        androidx.compose.foundation.layout.Box(
            modifier = Modifier.size(62.dp).clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape)
                .clickable(onClick = onOpenDrawer),
            contentAlignment = Alignment.Center,
        ) {
            if (avatar != null) {
                Image(bitmap = avatar, contentDescription = com.endurancevault.app.ui.i18n.Lang.tr("Buka menu"), contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize().clip(CircleShape))
            } else {
                Icon(Icons.Filled.Person, contentDescription = com.endurancevault.app.ui.i18n.Lang.tr("Buka menu"), tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(32.dp))
            }
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = if (name.isBlank()) Modifier.fillMaxWidth().clickable(onClick = onOpenSettings) else Modifier.fillMaxWidth(),
            ) {
                Text(
                    name.ifBlank { "Tambahkan nama di Pengaturan" },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.weight(1f, fill = false),
                ) {
                    Row(
                        Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(7.dp),
                    ) {
                        androidx.compose.foundation.layout.Box(Modifier.size(7.dp).clip(CircleShape).background(MaterialTheme.colorScheme.tertiary))
                        Text("Recovery ${recoveryHours} h", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, maxLines = 1)
                        Text(
                            "ready $readyLabel", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false),
                        )
                    }
                }
                if (watchBadge != null) WatchHeaderPill(watchBadge)
            }
        }
    }
}

/** [subs] = sub-tab halaman itu (label persis sama dengan yang dipakai layarnya); kosong = tanpa panah dropdown. */
private data class DrawerEntry(val route: String, val label: String, val icon: ImageVector, val subs: List<String> = emptyList())

/** Kartu Rencana di sidebar (dulu kartu di menu Pengaturan): ikon, nama, ringkasan rencana aktif. */
@Composable
private fun DrawerPlanCard(summary: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(16.dp)
    Row(
        modifier.fillMaxWidth().clip(shape).background(cs.surfaceVariant).border(androidx.compose.foundation.BorderStroke(0.8.dp, cs.outlineVariant), shape)
            .clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(cs.surface), contentAlignment = Alignment.Center) {
            Icon(settingsIcon("Rencana"), contentDescription = null, tint = cs.onCardTint, modifier = Modifier.size(22.dp))
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Text("Rencana", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(
                summary, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant,
                maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
            )
        }
    }
}

/** Drawer kiri: menggantikan dock bawah. Profil, tab utama, lalu Pengaturan di dasar. Dibuka hanya lewat foto profil di header. */
@Composable
private fun AppDrawerSheet(
    name: String,
    photoUri: String?,
    entries: List<DrawerEntry>,
    current: String?,
    onSelect: (String) -> Unit,
    onSelectSub: (String, String) -> Unit,
    onSettings: () -> Unit,
    watchBadge: WatchBadge? = null,
    onOpenWatch: () -> Unit = {},
    planSummary: String = "",
    onPlan: () -> Unit = {},
) {
    val avatar = rememberProfileAvatar(photoUri)
    val primary = MaterialTheme.colorScheme.primary
    val itemColors = NavigationDrawerItemDefaults.colors(
        selectedContainerColor = primary.copy(alpha = 0.16f),
        unselectedContainerColor = Color.Transparent,
        selectedIconColor = primary,
        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
        selectedTextColor = primary,
        unselectedTextColor = MaterialTheme.colorScheme.onSurface,
    )
    // Hanya satu dropdown sub-tab terbuka sekaligus; tertutup sampai panahnya diketuk.
    var expandedRoute by remember { mutableStateOf<String?>(null) }
    ModalDrawerSheet(
        modifier = Modifier.width(284.dp),
        drawerContainerColor = MaterialTheme.colorScheme.surface,
    ) {
        Column(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 16.dp)) {
          // Bagian atas bisa di-scroll (dropdown membuat daftar lebih tinggi); Rencana dan Pengaturan tetap di dasar.
          Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Box(
                    Modifier.size(48.dp).clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    if (avatar != null) {
                        Image(bitmap = avatar, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize().clip(CircleShape))
                    } else {
                        Icon(Icons.Filled.Person, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(28.dp))
                    }
                }
                Column {
                    Text(name.ifBlank { "Pelari" }, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    Text("EnduranceVault", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            HorizontalDivider(Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.outlineVariant)
            entries.forEach { e ->
                val selected = current == e.route || (e.route == Tab.Explore.route && current?.startsWith("explore") == true)
                val open = expandedRoute == e.route
                NavigationDrawerItem(
                    label = { Text(e.label) },
                    icon = { Icon(e.icon, contentDescription = null) },
                    selected = selected,
                    onClick = { onSelect(e.route) },
                    colors = itemColors,
                    modifier = Modifier.padding(vertical = 2.dp),
                    badge = if (e.subs.isNotEmpty()) ({
                        val rot by animateFloatAsState(if (open) 180f else 0f, label = "drawerChevron")
                        // Panah saja tanpa latar; ketukannya hanya membuka/menutup daftar sub-tab.
                        Icon(
                            Icons.Filled.KeyboardArrowDown,
                            contentDescription = "Sub-tab ${e.label}",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(40.dp).clip(CircleShape)
                                .clickable { expandedRoute = if (open) null else e.route }
                                .padding(8.dp).rotate(rot),
                        )
                    }) else null,
                )
                if (e.subs.isNotEmpty()) {
                    AnimatedVisibility(visible = open) {
                        Column(Modifier.padding(start = 28.dp, bottom = 4.dp)) {
                            e.subs.forEach { sub ->
                                Text(
                                    sub,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                                        .clickable { onSelectSub(e.route, sub) }
                                        .padding(horizontal = 16.dp, vertical = 11.dp),
                                )
                            }
                        }
                    }
                }
            }
            if (watchBadge != null) {
                // Seperti menu lain: hanya label; dot di ujung kanan = status sinkron (warna mengikuti status).
                NavigationDrawerItem(
                    label = { Text(watchBadge.title, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis) },
                    icon = { Icon(Icons.Outlined.Watch, contentDescription = null) },
                    selected = current == Tab.Watch.route,
                    onClick = onOpenWatch,
                    colors = itemColors,
                    modifier = Modifier.padding(vertical = 2.dp),
                    badge = { WatchDot(watchBadge.state, 10.dp) },
                )
            }
          }
            HorizontalDivider(Modifier.padding(bottom = 8.dp), color = MaterialTheme.colorScheme.outlineVariant)
            DrawerPlanCard(planSummary, onClick = onPlan, modifier = Modifier.padding(bottom = 6.dp))
            NavigationDrawerItem(
                label = { Text("Pengaturan") },
                icon = { Icon(Icons.Filled.Settings, contentDescription = null) },
                selected = false,
                onClick = onSettings,
                colors = itemColors,
            )
        }
    }
}

/** Isi ProfileScreen dengan semua state dari ViewModel; dipakai oleh tab Profil dan halaman Pengaturan terpisah. */
@Composable
private fun ProfileHost(vm: MainViewModel, state: UiState, onOpenActivity: (Long) -> Unit, settingsMode: Boolean, onBack: () -> Unit, onOpenStickers: () -> Unit = {}, onOpenProgressDock: (String) -> Unit = {},
    profileName: String = "", profilePhotoUri: String? = null, onEditProfileName: () -> Unit = {}, onPickProfilePhoto: () -> Unit = {},
    initialSection: String? = null,
    initialHomeTab: String = "Profile", initialHomeTabNonce: Int = 0,
) {
        val imp by vm.importState.collectAsState()
        val backupUi by vm.backupState.collectAsState()
        val watchMsg by vm.watchMessage.collectAsState()
        val watchSyncing by vm.watchSyncing.collectAsState()
        val watchAdvancedMessage by vm.watchAdvancedMessage.collectAsState()
        val liveHr by vm.liveHrJson.collectAsState()
        val weather by vm.weatherMessage.collectAsState()
        val weatherBusy by vm.weatherBusy.collectAsState()
        val weatherLat by vm.weatherLat.collectAsState()
        val weatherLon by vm.weatherLon.collectAsState()
        val weatherWatchStatus by vm.weatherWatchStatus.collectAsState()
        val wxSnapshot by vm.weatherSnapshot.collectAsState()
        val wxPlaceLabel by vm.weatherPlaceLabel.collectAsState()
        val wxError by vm.weatherError.collectAsState()
        val wxNotice by vm.weatherNotice.collectAsState()
        val wxWatchBusy by vm.weatherWatchBusy.collectAsState()
        val wxWatchNote by vm.weatherWatchNote.collectAsState()
        val agpsStatus by vm.agpsStatus.collectAsState()
        val notifyStatus by vm.notifyStatus.collectAsState()
        val aiStatus by vm.aiStatus.collectAsState()
        val aiModelSel by vm.aiModel.collectAsState()
        val aiKeySetSel by vm.aiKeySet.collectAsState()
        val duplicateStatus by vm.duplicateStatus.collectAsState()
        val profileTrackMsg by vm.trackMsg.collectAsState()
        ProfileScreen(
            state, vm::saveSettings, imp, vm::startImport, vm::confirmImport, vm::dismissImport, vm::mergeDuplicateActivities, vm::scanDuplicateActivities, duplicateStatus,
            vm::saveDaily, vm::saveGear, vm::deleteGear,
            watchMsg, vm::connectWatch, vm::disconnectWatch, vm::forgetAndReconnectWatch, vm::syncWatch, watchSyncing,
            watchAdvancedMessage, liveHr, vm::refreshLiveHr, vm::setLiveHr, vm::syncWatchHrZones,
            vm::pushStructuredWorkout, vm::pushGpxRoute,
            weather, weatherBusy, weatherLat, weatherLon, { lat, lon, name -> vm.fetchWeather(lat, lon, name.ifBlank { "Lokasi latihan" }) }, { q -> vm.searchWeatherCity(q) }, vm::useCurrentLocation, { lat, lon, name -> vm.sendWeatherToWatch(lat, lon, name) },
            weatherWatchStatus, agpsStatus, { enabled, mirror -> vm.setAgps(enabled, mirror) }, { vm.testAgps() },
            notifyStatus, { enabled, quiet, start, end, screenOff, apps -> vm.setWatchNotifications(enabled, quiet, start, end, screenOff, apps) }, { vm.testWatchNotification() },
            aiStatus, vm::saveAiKey,
            vm::deleteActivity, onOpenActivity, vm::importTracks, profileTrackMsg,
            settingsMode = settingsMode, onBack = onBack,
            backupUi = backupUi, backupFileName = vm::backupFileName, onExportBackup = vm::exportBackup,
            onStartRestore = vm::startRestore, onConfirmRestore = vm::confirmRestore, onDismissBackup = vm::dismissBackup,
            onOpenStickers = onOpenStickers, onOpenProgressDock = onOpenProgressDock,
            profileName = profileName, profilePhotoUri = profilePhotoUri,
            onEditProfileName = onEditProfileName, onPickProfilePhoto = onPickProfilePhoto,
            initialSection = initialSection,
            initialHomeTab = initialHomeTab, initialHomeTabNonce = initialHomeTabNonce,
            weatherSnapshot = wxSnapshot, weatherPlaceLabel = wxPlaceLabel, weatherError = wxError, weatherNotice = wxNotice,
            weatherWatchBusy = wxWatchBusy, weatherWatchNote = wxWatchNote, onRefreshWeather = vm::refreshWeatherFromCard,
            aiKeySet = aiKeySetSel, aiModel = aiModelSel, aiModels = vm.aiModels, onAiModel = vm::setAiModel,
        )
}

@Composable
fun AppRoot(vm: MainViewModel = viewModel()) {
    val nav = rememberNavController()
    val state by vm.state.collectAsState()
    val gpxPreview by vm.gpxPreview.collectAsState()
    gpxPreview?.let { gp ->
        // indeks kemampuan dari lari terakhir, dasar tiga opsi prediksi waktu (Ringan/Sedang/Berat)
        val ability = remember(gp, state.settings, state.activities, state.daily) {
            runCatching { ProgressAnalytics.runningAbility(state.settings, state.activities, state.daily) }.getOrNull()
        }
        GpxPreviewDialog(gp, ability, onSend = { pace -> vm.confirmGpxRoute(pace) }, onDismiss = vm::dismissGpxPreview)
    }
    val context = LocalContext.current
    val profilePrefs = remember { context.getSharedPreferences("profile_identity", android.content.Context.MODE_PRIVATE) }
    var profileName by remember { mutableStateOf(profilePrefs.getString("name", "") ?: "") }
    var profilePhotoUri by remember { mutableStateOf(profilePrefs.getString("photo_uri", null)) }
    var showProfileNameDialog by remember { mutableStateOf(false) }
    var showSettings by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf(false) }
    androidx.activity.compose.BackHandler(enabled = showSettings) { showSettings = false }
    // Bagian Pengaturan yang dibuka langsung dari sidebar (mis. "Rencana"); direset saat Pengaturan ditutup.
    var settingsSection by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf<String?>(null) }
    LaunchedEffect(showSettings) { if (!showSettings) settingsSection = null }
    var editedProfileName by remember { mutableStateOf(profileName) }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            profilePhotoUri = uri.toString()
            profilePrefs.edit().putString("photo_uri", uri.toString()).apply()
        }
    }
    val trainingMetrics = remember(state.settings, state.activities, state.daily, state.plan, state.hrHistByActivity) {
        runCatching { TrainingMetrics.calculate(state.settings, state.activities, state.daily, state.plan, hrHistByActivity = state.hrHistByActivity) }.getOrNull()
    }
    val recoveryHours = trainingMetrics?.recoveryRemainingHours ?: 0
    // Status jam untuk header dan kartu Pengaturan (tab Jam sudah tidak ada di dock). Dibaca ulang tiap menit dan setiap sinkron mulai/selesai.
    val wbDock by vm.watchDock.collectAsState()
    val wbSyncing by vm.watchSyncing.collectAsState()
    val wbLastSync by vm.watchLastSyncJs.collectAsState()
    val wbAlias by vm.watchAlias.collectAsState()
    val watchBadge = watchBadgeOf(wbDock, wbSyncing, wbLastSync, wbAlias)
    LaunchedEffect(Unit) { while (true) { vm.refreshWatchDock(); kotlinx.coroutines.delay(60_000L) } }
    LaunchedEffect(wbSyncing) { vm.refreshWatchDock() }
    // Acuan latihan (batas HR easy, rentang HR threshold, pace easy) mengikuti zona dan data lari secara otomatis; mesin rencana membaca nilai yang tersimpan.
    LaunchedEffect(state.activities, state.daily, state.settings) {
        val cur = state.settings
        val refs = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
            runCatching { com.endurancevault.app.domain.TrainingRefs.compute(cur, state.activities, state.daily, restHrFrom(state.daily).first) }.getOrNull()
        } ?: return@LaunchedEffect
        com.endurancevault.app.domain.TrainingRefs.update(cur, refs)?.let { vm.saveSettings(it) }
    }
    var progressInitialTab by remember { mutableStateOf("Rekap") }
    // Sub-tab yang dipilih dari dropdown sidebar. Nonce naik tiap pilihan agar memilih sub-tab yang sama pun tetap berpindah.
    var progressTabNonce by remember { mutableStateOf(0) }
    var weekShowHistory by remember { mutableStateOf(false) }
    var weekTabNonce by remember { mutableStateOf(0) }
    var profileHomeTabInit by remember { mutableStateOf("Profile") }
    var profileTabNonce by remember { mutableStateOf(0) }
    val current = nav.currentBackStackEntryAsState().value?.destination?.route
    // Halaman Jam dibuka dari Pengaturan: Back kembali ke Pengaturan, bukan ke Hari ini.
    var settingsReturnRoute by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf<String?>(null) }
    androidx.activity.compose.BackHandler(enabled = settingsReturnRoute != null && current == settingsReturnRoute) {
        settingsReturnRoute = null
        nav.popBackStack()
        showSettings = true
    }
    LaunchedEffect(current) {
        if (current != Tab.Watch.route && current != "watchsettings") settingsReturnRoute = null
    }
    // Jadwal is a contextual destination: it exists only while a training plan is selected.
    val hasTrainingPlan = state.settings.rtype != "none"
    LaunchedEffect(hasTrainingPlan, current) {
        if (!hasTrainingPlan && current == Tab.Schedule.route) {
            nav.navigate(Tab.Week.route) { popUpTo(Tab.Today.route); launchSingleTop = true }
        }
    }
    // Jam ada di Pengaturan (kartu Jam) dan pil status di header; rute "watch" tetap ada tanpa tab dock.
    val onWatchDot: () -> Unit = {
        if (watchBadge?.conn == true) { if (!wbSyncing) vm.syncWatch(false) }
        else { settingsReturnRoute = "watchsettings"; showSettings = false; nav.navigate("watchsettings") { launchSingleTop = true } }
    }
    val onOpenWatch: () -> Unit = { settingsReturnRoute = Tab.Watch.route; showSettings = false; nav.navigate(Tab.Watch.route) { launchSingleTop = true } }
    // Estimasi waktu rute di Explore: tempo "sedang" dari indeks kemampuan lari terakhir (sama dengan dialog Kirim ke jam).
    val exploreAbility = remember(state.settings, state.activities, state.daily) {
        runCatching { ProgressAnalytics.runningAbility(state.settings, state.activities, state.daily) }.getOrNull()
    }
    val exploreEstimate: (List<CourseStrategy.Pt>) -> Double? = { pts ->
        exploreAbility?.let { ab -> runCatching { CourseStrategy.forecast(pts, ab.value, "dry")?.minutesOf(CourseStrategy.Effort.MODERATE) }.getOrNull() }
    }
    // Sesi terjadwal ke depan (maks. 14 hari, bukan libur) untuk memasang rute Explore ke sesi.
    val exploreSessions = remember(state.plan) {
        val ok = state.plan as? PlanOutcome.Ok
        val today = java.time.LocalDate.now()
        ok?.weeks.orEmpty().flatMap { it.days }
            .filter { !it.date.isBefore(today) && it.kind != Kinds.REST }
            .sortedBy { it.date }
            .take(14)
            .map { ExSession(it.date.toString(), it.title, it.km) }
    }
    // Dock bawah diganti drawer kiri: dibuka hanya lewat foto profil, tertutup otomatis setelah memilih menu.
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val drawerScope = rememberCoroutineScope()
    val drawerEntries = buildList {
        add(DrawerEntry(Tab.Profile.route, "Profil", Tab.Profile.icon, subs = listOf("Profile", "Timeline")))
        add(DrawerEntry(Tab.Today.route, Tab.Today.label, Tab.Today.icon))
        add(DrawerEntry(Tab.Progress.route, Tab.Progress.label, Tab.Progress.icon, subs = listOf("Rekap", "Fitness", "Load", "Routes & conditions", "Body")))
        add(DrawerEntry(Tab.Week.route, Tab.Week.label, Tab.Week.icon, subs = listOf("This week", "History")))
        if (hasTrainingPlan) add(DrawerEntry(Tab.Schedule.route, Tab.Schedule.label, Tab.Schedule.icon))
        add(DrawerEntry(Tab.Explore.route, Tab.Explore.label, Tab.Explore.icon))
    }
    // Back saat drawer terbuka hanya menutup drawer (kembali ke halaman yang tadi dibuka). Halaman utama tetap Hari ini.
    androidx.activity.compose.BackHandler(enabled = drawerState.isOpen) { drawerScope.launch { drawerState.close() } }
    // Konten di belakang drawer dikaburkan: Android 12+ via Modifier.blur (RenderEffect),
    // Android 10/11 via snapshot bitmap yang dikaburkan manual (LegacyBlurBehind).
    val drawerOpen = drawerState.targetValue == DrawerValue.Open
    val useRenderEffectBlur = android.os.Build.VERSION.SDK_INT >= 31
    val drawerBlur by animateDpAsState(if (drawerOpen && useRenderEffectBlur) 10.dp else 0.dp, label = "drawerBlur")
    val scrimAlpha = if (useRenderEffectBlur) 0.34f else 0.4f

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = drawerState.isOpen,
        scrimColor = Color.Black.copy(alpha = scrimAlpha),
        drawerContent = {
            AppDrawerSheet(
                name = profileName,
                photoUri = profilePhotoUri,
                entries = drawerEntries,
                current = current,
                onSelect = { route ->
                    drawerScope.launch { drawerState.close() }
                    // Ketuk menu utama = halaman default (sub-tab pertama).
                    when (route) {
                        Tab.Progress.route -> progressInitialTab = "Rekap"
                        Tab.Week.route -> weekShowHistory = false
                        Tab.Profile.route -> profileHomeTabInit = "Profile"
                    }
                    nav.navigate(route) {
                        popUpTo(Tab.Today.route) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                onSelectSub = { route, sub ->
                    drawerScope.launch { drawerState.close() }
                    when (route) {
                        Tab.Progress.route -> { progressInitialTab = sub; progressTabNonce++ }
                        Tab.Week.route -> { weekShowHistory = sub == "History"; weekTabNonce++ }
                        Tab.Profile.route -> { profileHomeTabInit = sub; profileTabNonce++ }
                    }
                    nav.navigate(route) {
                        popUpTo(Tab.Today.route) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                onSettings = {
                    drawerScope.launch { drawerState.close() }
                    settingsSection = null
                    showSettings = true
                },
                watchBadge = watchBadge,
                onOpenWatch = { drawerScope.launch { drawerState.close() }; onOpenWatch() },
                planSummary = planSummaryOf(state.settings.name, state.settings.rtype),
                onPlan = {
                    drawerScope.launch { drawerState.close() }
                    settingsSection = "Rencana"
                    showSettings = true
                },
            )
        },
    ) {
    LegacyBlurBehind(active = drawerOpen && !useRenderEffectBlur, modifier = Modifier.fillMaxSize()) {
    Scaffold(
        modifier = if (drawerBlur > 0.dp) Modifier.blur(drawerBlur) else Modifier,
        containerColor = MaterialTheme.colorScheme.background,
        contentColor = MaterialTheme.colorScheme.onBackground,
    ) { pad ->
        if (showSettings) {
            // Halaman penuh di luar kartu utama: tanpa header profil dan tanpa dock.
            androidx.compose.foundation.layout.Box(Modifier.fillMaxSize().padding(pad).background(MaterialTheme.colorScheme.background)) {
                ProfileHost(vm, state, onOpenActivity = { id -> showSettings = false; nav.navigate("activity/$id") }, settingsMode = true, onBack = { showSettings = false }, onOpenStickers = { showSettings = false; nav.navigate("sticker") },
                    initialSection = settingsSection,
                    onOpenProgressDock = { tab -> showSettings = false; progressInitialTab = tab; nav.navigate(Tab.Progress.route) { popUpTo(Tab.Today.route) { saveState = true }; launchSingleTop = true } },
                    profileName = profileName, profilePhotoUri = profilePhotoUri,
                    onEditProfileName = { editedProfileName = profileName; showProfileNameDialog = true },
                    onPickProfilePhoto = { photoPicker.launch(arrayOf("image/*")) })
            }
        } else Column(
            modifier = Modifier.fillMaxSize().padding(pad).background(MaterialTheme.colorScheme.background),
        ) {
            EnduranceProfileHeader(
                name = profileName,
                photoUri = profilePhotoUri,
                recoveryHours = recoveryHours,
                onOpenDrawer = { drawerScope.launch { drawerState.open() } },
                onOpenSettings = { showSettings = true },
                watchBadge = watchBadge,
            )
            Surface(
                modifier = Modifier.fillMaxWidth().weight(1f).padding(horizontal = 14.dp).padding(bottom = 8.dp),
                shape = RoundedCornerShape(30.dp),
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant),
            ) {
                NavHost(nav, startDestination = Tab.Today.route, modifier = Modifier.fillMaxSize()) {
            composable(Tab.Today.route) {
                val weatherSnap by vm.weatherSnapshot.collectAsState()
                val weatherBusy by vm.weatherBusy.collectAsState()
                val weatherLabel by vm.weatherPlaceLabel.collectAsState()
                val weatherError by vm.weatherError.collectAsState()
                val weatherWatchBusy by vm.weatherWatchBusy.collectAsState()
                val weatherWatchNote by vm.weatherWatchNote.collectAsState()
                val aiMessages by vm.aiMessages.collectAsState()
                val aiPending by vm.aiPending.collectAsState()
                val aiBusy by vm.aiBusy.collectAsState()
                val aiKeySet by vm.aiKeySet.collectAsState()
                val aiError by vm.aiError.collectAsState()
                val aiRateLimited by vm.aiRateLimited.collectAsState()
                val agpsBusyNow by vm.agpsBusy.collectAsState()
                val agpsNoteNow by vm.agpsNote.collectAsState()
                val todayDock by vm.watchDock.collectAsState()
                val fabHider = com.endurancevault.app.ui.screens.rememberFabScrollHider()
                // Pertanyaan awal AI Coach menyesuaikan data yang ada.
                val aiStarters = remember(state.activities.size, state.daily.size) {
                    buildList {
                        add("Ringkas minggu ini")
                        if (state.activities.isNotEmpty()) add("Bagaimana lari terakhirku?")
                        add("Sesi hari ini sebaiknya bagaimana?")
                        if (state.daily.isNotEmpty()) add("Apakah aku perlu istirahat?")
                        add("Boleh naikkan jarak?")
                    }.take(4)
                }
                Box(Modifier.fillMaxSize().nestedScroll(fabHider.connection)) {
                TodayScreen(
                    state = state, onAdd = vm::addActivity, weather = weatherSnap, weatherPlaceLabel = weatherLabel,
                    weatherBusy = weatherBusy || weatherWatchBusy || agpsBusyNow, weatherError = weatherError, weatherWatchNote = listOf(weatherWatchNote, agpsNoteNow).filter { it.isNotBlank() }.joinToString(" · "),
                    onRefreshWeather = vm::refreshWeatherAndAgps,
                    onAutoRefreshWeather = { maxAge -> vm.refreshWeatherIfStale(maxAge) },
                    onOpenActivity = { id -> nav.navigate("activity/$id") },
                    onGoWeek = { nav.navigate(Tab.Week.route) { launchSingleTop = true } },
                    explore = vm.explore,
                    onOpenRoute = { id -> nav.navigate("explore/route/$id") { launchSingleTop = true } },
                    onOpenExplore = { nav.navigate(Tab.Explore.route) { launchSingleTop = true } },
                    sleep = (todayDock as? com.endurancevault.app.data.WatchDockUi.Ready)?.model?.sleep,
                )
                // Chat AI Coach: tombol melayang yang hanya ada di Beranda. API key tetap diatur di Pengaturan.
                com.endurancevault.app.ui.screens.AiChatFab(
                    messages = aiMessages, busy = aiBusy, keySet = aiKeySet,
                    keyHint = "Masukkan Groq API key untuk mengaktifkan AI Coach online.",
                    error = aiError, onSend = { q, web -> vm.sendAiQuestion(q, "", web) },
                    pending = aiPending, onApplyPending = vm::applyAiActions, onDismissPending = vm::dismissAiActions,
                    rateLimited = aiRateLimited, onSwitchModel = vm::switchAiModelAndRetry,
                    starters = aiStarters, hiddenByScroll = fabHider.hidden,
                    modifier = Modifier.fillMaxSize(),
                )
                }
            }
            composable(Tab.Progress.route) {
                val trackMsg by vm.trackMsg.collectAsState()
                ProgressScreen(
                    state = state,
                    onDelete = vm::deleteActivity,
                    onOpen = { id -> nav.navigate("activity/$id") },
                    onImportTracks = vm::importTracks,
                    trackMsg = trackMsg,
                    initialTab = progressInitialTab,
                    initialTabNonce = progressTabNonce,
                    onSaveSettings = vm::saveSettings,
                )
            }
            composable(Tab.Week.route) {
                val weekTrackMsg by vm.trackMsg.collectAsState()
                val weekWatchMsg by vm.watchAdvancedMessage.collectAsState()
                ScheduleScreen(
                    state,
                    onOpenActivity = { id -> nav.navigate("activity/$id") },
                    onSetMv = vm::setMv,
                    onSetDone = vm::setDone,
                    onImportTracks = vm::importTracks,
                    trackMsg = weekTrackMsg,
                    onPushWorkout = vm::pushStructuredWorkout,
                    watchMsg = weekWatchMsg,
                    initialHistory = weekShowHistory,
                    initialTabNonce = weekTabNonce,
                )
            }
            composable(Tab.Schedule.route) {
                if (hasTrainingPlan) PlanOverviewScreen(state, onOpenActivity = { id -> nav.navigate("activity/$id") }) else TodayScreen(state, vm::addActivity)
            }
            composable(Tab.Watch.route) {
                val watchMsg by vm.watchMessage.collectAsState()
                val watchSyncing by vm.watchSyncing.collectAsState()
                val watchAdvancedMessage by vm.watchAdvancedMessage.collectAsState()
                val dock by vm.watchDock.collectAsState()
                val dockWx by vm.weatherSnapshot.collectAsState()
                val dockLastSyncJs by vm.watchLastSyncJs.collectAsState()
                val dockAlias by vm.watchAlias.collectAsState()
                androidx.compose.foundation.lazy.LazyColumn(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp),
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 18.dp, bottom = 24.dp),
                ) {
                    item {
                        // Dock Jam: kartu jam, ubin data harian, latihan dari jam. Roda gigi membuka halaman pengaturan jam (route watchsettings).
                        WatchDockScreen(
                            ui = dock, activities = state.activities, wx = dockWx, syncing = watchSyncing,
                            lastSyncJsSec = dockLastSyncJs, message = watchMsg, alias = dockAlias,
                            onRefresh = vm::refreshWatchDock, onSync = { vm.syncWatch(false) }, onSaveAlias = vm::setWatchAlias,
                            onPickGpx = vm::pushGpxRoute, onOpenActivity = { id -> nav.navigate("activity/$id") },
                            onOpenSettings = { nav.navigate("watchsettings") },
                        )
                    }
                }
            }
            composable("watchsettings") {
                val watchMsg by vm.watchMessage.collectAsState()
                val watchSyncing by vm.watchSyncing.collectAsState()
                val watchAdvancedMessage by vm.watchAdvancedMessage.collectAsState()
                val agpsStatus by vm.agpsStatus.collectAsState()
                val notifyStatus by vm.notifyStatus.collectAsState()
                androidx.compose.foundation.layout.Box(Modifier.fillMaxSize()) {
                    androidx.compose.foundation.lazy.LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                        verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 18.dp, bottom = 96.dp),
                    ) {
                        item {
                            HuaweiWatchSection(
                                message = watchMsg, onConnect = vm::connectWatch, onDisconnect = vm::disconnectWatch,
                                onForgetAndReconnect = vm::forgetAndReconnectWatch, onSync = vm::syncWatch,
                                isSyncing = watchSyncing, settings = state.settings, advancedMessage = watchAdvancedMessage,
                                onSyncHrZones = vm::syncWatchHrZones, onPushWorkout = vm::pushStructuredWorkout,
                                onSaveSettings = vm::saveSettings, daily = state.daily,
                                agpsContent = { com.endurancevault.app.ui.screens.WatchAgpsSection(agpsStatus, { enabled, mirror -> vm.setAgps(enabled, mirror) }, { vm.testAgps() }) },
                                notifyContent = {
                                    com.endurancevault.app.ui.screens.WatchNotifySection(
                                        notifyStatus,
                                        { enabled, quiet, start, end, screenOff, apps -> vm.setWatchNotifications(enabled, quiet, start, end, screenOff, apps) },
                                        { vm.testWatchNotification() },
                                    )
                                },
                            )
                        }
                    }
                    Surface(
                        modifier = Modifier.align(Alignment.BottomEnd).padding(end = 18.dp, bottom = 18.dp).size(44.dp)
                            .clip(CircleShape).clickable { nav.popBackStack() },
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant),
                    ) {
                        androidx.compose.foundation.layout.Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = com.endurancevault.app.ui.i18n.Lang.tr("Kembali"), modifier = Modifier.size(22.dp))
                        }
                    }
                }
            }
            composable("activity/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
                ActivityDetailScreen(
                    state, e.arguments?.getLong("id") ?: -1L, vm::detailOf, trainingMetrics, vm::setActivityGear, vm::setActivityFeel,
                    onDelete = vm::deleteActivity, onCrop = vm::cropActivity, onEdit = vm::editActivity,
                    onSaveSegments = vm::saveSegments,
                    onOpenSticker = { sid -> nav.navigate("sticker/$sid") },
                    onOpenRouteVideo = { sid -> nav.navigate("routevideo/$sid") },
                    onSaveAsRoute = { d -> vm.explore.saveActivityAsRoute(d) },
                    onFetchWeather = vm::fetchActivityWeather,
                    onBattery = vm::activityBattery,
                ) { nav.popBackStack() }
            }
            composable("sticker") {
                StickerScreen(state, -1L, vm::detailOf) { nav.popBackStack() }
            }
            composable("sticker/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
                StickerScreen(state, e.arguments?.getLong("id") ?: -1L, vm::detailOf) { nav.popBackStack() }
            }
            composable(Tab.Explore.route) {
                ExploreScreen(
                    ctl = vm.explore,
                    initialCenter = RouteGeo.LatLon(vm.weatherLat.value.toDoubleOrNull() ?: -6.99, vm.weatherLon.value.toDoubleOrNull() ?: 110.42),
                    estimateMin = exploreEstimate,
                    onOpenCollection = { nav.navigate("explore/collection") { launchSingleTop = true } },
                )
            }
            composable("explore/collection") {
                ExploreCollectionScreen(
                    ctl = vm.explore,
                    mapCenter = vm.explore.lastView?.let { v -> RouteGeo.LatLon(RouteGeo.latOfWorldY(v.cy0, 0), RouteGeo.lonOfWorldX(v.cx0, 0)) },
                    onBack = { nav.popBackStack() },
                    onOpenRoute = { id -> nav.navigate("explore/route/$id") { launchSingleTop = true } },
                    onShowPlace = { p -> vm.explore.lastView = exViewAt(RouteGeo.LatLon(p.lat, p.lon), 16.0); nav.navigate(Tab.Explore.route) { popUpTo(Tab.Today.route) { saveState = false }; launchSingleTop = true } },
                )
            }
            composable("explore/route/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { e ->
                ExploreRouteDetailScreen(
                    ctl = vm.explore,
                    routeId = e.arguments?.getString("id") ?: "",
                    estimateMin = exploreEstimate,
                    activities = state.activities,
                    detailOf = vm::detailOf,
                    sessions = exploreSessions,
                    onOpenActivity = { aid -> nav.navigate("activity/$aid") },
                    onBack = { nav.popBackStack() },
                    onEdit = { nav.navigate(Tab.Explore.route) { popUpTo(Tab.Today.route) { saveState = false }; launchSingleTop = true } },
                    onSendToWatch = { r ->
                        val prev = r.toWatchPreview()
                        if (prev != null) vm.gpxPreview.value = prev else vm.explore.message.value = "Rute terlalu pendek untuk dikirim ke jam."
                    },
                )
            }
            composable("routevideo/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
                RouteVideoScreen(state, e.arguments?.getLong("id") ?: -1L, vm::detailOf) { nav.popBackStack() }
            }
            composable(Tab.Profile.route) {
                ProfileHost(vm, state, onOpenActivity = { id -> nav.navigate("activity/$id") }, settingsMode = false, onBack = {}, onOpenStickers = { nav.navigate("sticker") },
                    initialHomeTab = profileHomeTabInit, initialHomeTabNonce = profileTabNonce,
                    onOpenProgressDock = { tab -> progressInitialTab = tab; nav.navigate(Tab.Progress.route) { popUpTo(Tab.Today.route) { saveState = true }; launchSingleTop = true } })
            }
                }
            }
        }
        if (showProfileNameDialog) {
            AlertDialog(
                onDismissRequest = { showProfileNameDialog = false },
                title = { Text("Nama profil") },
                text = {
                    OutlinedTextField(
                        value = editedProfileName,
                        onValueChange = { editedProfileName = it },
                        singleLine = true,
                        label = { Text("Nama") },
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        profileName = editedProfileName.trim()
                        profilePrefs.edit().putString("name", profileName).apply()
                        showProfileNameDialog = false
                    }) { Text("Simpan") }
                },
                dismissButton = { TextButton(onClick = { showProfileNameDialog = false }) { Text("Batal") } },
            )
        }
    }
    }
    }
}
