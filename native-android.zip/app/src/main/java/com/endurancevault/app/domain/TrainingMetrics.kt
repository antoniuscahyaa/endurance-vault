package com.endurancevault.app.domain

import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.data.DailyEntity
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.temporal.ChronoUnit
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

data class LoadDay(val date: LocalDate, val load: Double, val fitness: Double, val fatigue: Double, val form: Double, val sessionCount: Int)
data class TrainingSessionMetric(
    val activityId: Long, val date: LocalDate, val load: Double, val aerobicEffect: Double,
    val anaerobicEffect: Double?, val recoveryHours: Double, val recoveryRemainingHours: Double,
    val source: String, val watchLoad: Int? = null, val fromWatch: Boolean = false,
)
data class ReadinessPart(val key: String, val label: String, val score: Int?, val detail: String, val weight: Double)
data class ReadinessMetric(val score: Int, val tier: String, val advice: String, val parts: List<ReadinessPart>, val dataDays: Int, val sleepDebtHours: Double? = null)
data class PainReadinessEntry(val date: LocalDate, val area: String, val severity: Int, val side: String = "b", val whenTag: String = "sl")
data class ReadinessConfig(
    val swapThreshold: Int = 50, val lightThreshold: Int = 65, val easyThreshold: Int = 35,
    val weights: Map<String, Double> = emptyMap(),
    val sleepNeedHours: Double = 7.5,
    val painEntries: List<PainReadinessEntry> = emptyList(),
    val bikeHrOffset: Int = 8,
    val bikeModeFactor: Double = 1.25,
    val normalizeBikeLoad: Boolean = true,
) {
    fun safe(): ReadinessConfig {
        val swap = swapThreshold.coerceIn(20, 80)
        val light = lightThreshold.coerceIn(swap + 1, 90)
        val easy = easyThreshold.coerceIn(5, swap)
        return copy(swapThreshold = swap, lightThreshold = light, easyThreshold = easy,
            weights = weights.filterValues { it.isFinite() && it in 1.0..100.0 },
            sleepNeedHours = sleepNeedHours.coerceIn(5.0, 10.0),
            bikeHrOffset = bikeHrOffset.coerceIn(0, 20),
            bikeModeFactor = bikeModeFactor.coerceIn(1.0, 1.6))
    }
}
data class PlanAdjustment(
    val plannedTitle: String,
    val plannedKind: String,
    val plannedKm: Double,
    val action: String,
    val suggestedKm: Double,
    val reason: String,
    val readinessScore: Int,
)
data class TrainingMetricsResult(
    val days: List<LoadDay>, val sessions: List<TrainingSessionMetric>, val weeklyLoad: Int,
    val fitness: Int, val fatigue: Int, val form: Int, val ratio: Double, val optimalRange: IntRange,
    val status: String, val statusDetail: String, val readiness: ReadinessMetric?,
    val recoveryRemainingHours: Int, val scale: Double, val lthr: Int, val hrMax: Int,
    val planAdjustment: PlanAdjustment? = null,
    /** Poin penyesuaian kondisi pagi (HR istirahat, HRV, tidur) untuk Fatigue dan recovery, setara morningAdj() di web. */
    val morningPts: Int = 0,
) { val latest: LoadDay? get() = days.lastOrNull() }

/** Native port dari 15-training-load-te-kebugaran.js. Jika histogram HR belum tersedia,
 * load memakai HR rata-rata; anaerobic TE sengaja tidak ditebak tanpa distribusi HR. */
object TrainingMetrics {
    private const val DEFAULT_SCALE = 2.7
    private val kindFactors = mapOf("easy" to 45.0, "short" to 40.0, "medium" to 58.0, "long" to 55.0, "quality" to 75.0, "sub" to 85.0, "race" to 95.0, "event" to 55.0)

    fun calculate(settings: PlanSettings, activities: List<ActivityEntity>, daily: List<DailyEntity>, plan: PlanOutcome,
                  today: LocalDate = LocalDate.now(), loadScale: Double = settings.loadScale ?: DEFAULT_SCALE,
                  hrHistByActivity: Map<Long, Map<Int, Double>> = emptyMap(), readinessConfig: ReadinessConfig = ReadinessConfig()): TrainingMetricsResult {
        val scale = loadScale.takeIf { it in .5..6.0 } ?: DEFAULT_SCALE
        val valid = activities.filter { it.km > 0 || it.durationSec > 0 }
        val restValues = daily.filter { it.dateIso < today.toString() && it.rhr != null }.sortedBy { it.dateIso }.takeLast(14).mapNotNull { it.rhr }
        val rest: Double = settings.rhr?.takeIf { it >= 30 } ?: restValues.sorted().let { if (it.isEmpty()) 55.0 else it[it.size / 2].toDouble() }
        val lthr = settings.lthr?.takeIf { it >= 100 }?.roundToInt() ?: (thrBand(settings)?.let { (it[0] + it[1]) / 2 } ?: 168)
        // Max HR profil hanya manual. Tanpanya, load memakai jalur durasi, bukan HR yang dinormalisasi dengan tebakan.
        val hrMax = hrMaxEst(settings)
        val safeRest: Double = if (rest > lthr - 25) max(30.0, (lthr - 60).toDouble()) else rest
        val hasHrMax = hrMax in 140..240 && hrMax > safeRest
        val reserve = if (hasHrMax) (lthr - safeRest).toDouble() / (hrMax - safeRest) else 0.0
        val reference = if (hasHrMax) reserve * exp(1.92 * reserve) else 0.0
        val planKinds = mutableMapOf<LocalDate, String>()
        (plan as? PlanOutcome.Ok)?.weeks?.forEach { w -> w.days.forEach { planKinds[it.date] = it.kind } }
        val grouped = valid.mapNotNull { a -> runCatching { LocalDate.parse(a.dateIso.take(10)) to a }.getOrNull() }.groupBy({ it.first }, { it.second })
        val rawLoads = mutableMapOf<LocalDate, Double>()
        val sessionRaw = mutableListOf<Triple<ActivityEntity, Double, Map<Int, Double>?>>()
        grouped.forEach { (date, list) ->
            var sum = 0.0
            list.forEach { a ->
                val minutes = if (a.durationSec > 0) a.durationSec / 60.0 else a.km * Js.parsePaceStr(settings.pace)
                val hist = hrHistByActivity[a.id]?.takeIf { it.values.sum() > 60.0 }
                val raw = if (hist != null && hasHrMax && reference > 0) {
                    hist.entries.sumOf { (bpm, seconds) ->
                        val r = ((bpm - safeRest).toDouble() / (hrMax - safeRest).coerceAtLeast(1.0)).let { if (it <= 0) 0.0 else it.coerceAtMost(1.05) }
                        seconds * (r * exp(1.92 * r))
                    } / 3600.0 / reference.coerceAtLeast(.0001) * 100.0
                } else if (a.avgHr != null && a.avgHr > 0 && hasHrMax && reference > 0) {
                    val r = ((a.avgHr - safeRest).toDouble() / (hrMax - safeRest).coerceAtLeast(1.0)).coerceIn(0.0, 1.05)
                    minutes / 60.0 * (r * exp(1.92 * r)) / reference.coerceAtLeast(.0001) * 100.0
                } else minutes / 60.0 * (kindFactors[planKinds[date]] ?: 50.0) * if (a.type == "bike") .85 else 1.0
                val bikeDiv = if (readinessConfig.normalizeBikeLoad) readinessConfig.bikeModeFactor.coerceIn(1.0, 1.6) else 1.0
                val adjusted = if (a.type == "bike" && (hist != null || a.avgHr != null)) raw / bikeDiv else raw
                sum += adjusted; sessionRaw += Triple(a, adjusted, hist)
            }
            rawLoads[date] = sum
        }
        if (rawLoads.isEmpty()) {
            val readiness = readiness(null, daily, today, config = readinessConfig.safe())
            val adjustment = readiness?.let { recommendTodayPlan(plan, today, it.score, readinessConfig.safe()) }
            return TrainingMetricsResult(emptyList(), emptyList(), 0, 0, 0, 0, 0.0, 0..0,
                "Belum ada data", "Catat atau impor aktivitas untuk mulai menghitung training load.",
                readiness, 0, scale, lthr, hrMax, adjustment)
        }
        val first = rawLoads.keys.minOrNull()!!; val end = maxOf(today, rawLoads.keys.maxOrNull()!!)
        val af = 1.0 - exp(-1.0 / 42.0); val at = 1.0 - exp(-1.0 / 7.0)
        var ctl = 0.0; var atl = 0.0; val days = mutableListOf<LoadDay>(); var date = first
        while (!date.isAfter(end) && days.size < 3000) {
            val load = (rawLoads[date] ?: 0.0) * scale
            ctl += (load - ctl) * af; atl += (load - atl) * at
            days += LoadDay(date, load, ctl, atl, ctl - atl, grouped[date]?.size ?: 0); date = date.plusDays(1)
        }
        val cur = days.firstOrNull { it.date == today } ?: days.last()
        val weekly = days.filter { !it.date.isBefore(today.minusDays(6)) && !it.date.isAfter(today) }.sumOf { it.load }.roundToInt()
        val ratio = if (cur.fitness > 0) cur.fatigue / cur.fitness else 0.0
        val status = when {
            ChronoUnit.DAYS.between(first, today) + 1 < 28 || cur.fitness / scale < 8 -> "Data belum cukup" to "Dibutuhkan sekitar 4 minggu aktivitas tercatat agar status beban lebih stabil."
            ratio < .8 -> "Beban turun" to "Beban 7 hari berada di bawah kebiasaan 6 minggu. Ini dapat mendukung pemulihan."
            ratio <= 1.3 -> "Beban optimal" to "Beban jangka pendek relatif seimbang dengan kebiasaan latihan."
            ratio <= 1.5 -> "Beban tinggi" to "Beban meningkat cepat. Pertahankan sesi easy tetap ringan dan sisipkan pemulihan."
            else -> "Beban sangat tinggi" to "Lonjakan beban cukup besar. Pertimbangkan mengurangi volume dan prioritaskan pemulihan."
        }
        val sessionMetrics = sessionRaw.map { (a, raw, hist) ->
            val d = LocalDate.parse(a.dateIso.take(10)); val dayIndex = days.indexOfFirst { it.date == d }
            val ctlBefore = if (dayIndex > 0) days[dayIndex - 1].fitness / scale else 0.0
            val ff = (1.3 - ctlBefore / 150.0).coerceIn(.7, 1.3)
            val watch = runCatching { org.json.JSONObject(a.note) }.getOrNull()
            val watchRecovery = watch?.optDouble("recoveryHours", 0.0)?.takeIf { it > 0.0 }
            val watchAerobic = watch?.optDouble("aerobicEffect", 0.0)?.takeIf { it in 0.1..5.0 }
            val watchAnaerobic = watch?.optDouble("anaerobicEffect", 0.0)?.takeIf { it in 0.1..5.0 }
            val watchLoad = watch?.optInt("workoutLoad", 0)?.takeIf { it > 0 }
            val watchData = watch?.optString("source") == "huawei-watch"
            val recovery = watchRecovery ?: (24.0 * raw.coerceAtLeast(0.0).div(100.0).pow(.9) * ff)
            val endTime = runCatching { LocalDateTime.of(d, a.startTime?.let { LocalTime.parse(it) } ?: LocalTime.NOON).plusSeconds(a.durationSec.toLong()) }.getOrNull()
            val elapsed = endTime?.let { ChronoUnit.SECONDS.between(it, LocalDateTime.now()).coerceAtLeast(0) / 3600.0 } ?: 0.0
            val ctlP = ctlBefore
            val factor = (1.0 + ctlP / 50.0).coerceIn(1.0, 1.6)
            val te = watchAerobic ?: (5.0 * (1.0 - exp(-raw / (58.0 * factor)))).coerceIn(0.0, 5.0)
            var anaerobic: Double? = null
            if (hist != null && hasHrMax) {
                val high = lthr + .35 * (hrMax - lthr)
                val minutesHigh = hist.entries.sumOf { (bpm, seconds) ->
                    when { bpm >= high -> seconds / 60.0; bpm >= lthr -> seconds / 60.0 * .15; else -> 0.0 }
                }
                anaerobic = (5.0 * (1.0 - exp(-minutesHigh / 14.0))).let { (it * 10).roundToInt() / 10.0 }
            }
            val teBonus = te >= 4.0
            val adjustedRecovery = if (watchRecovery != null) recovery else recovery * if (teBonus) 1.25 else 1.0
            val rem = (adjustedRecovery - elapsed).coerceAtLeast(0.0)
            TrainingSessionMetric(
                a.id, d, raw * scale, (te * 10).roundToInt() / 10.0,
                watchAnaerobic ?: anaerobic, adjustedRecovery, rem,
                if (watchData) "Huawei Watch" else if (hist != null) "Histogram HR" else if (a.avgHr != null) "HR rata-rata" else "Estimasi durasi",
                watchLoad, watchData,
            )
        }.sortedByDescending { it.date }
        val morningPts = morningPoints(daily, today)
        val recoveryBase = sessionMetrics.filter { !it.date.isAfter(today) && ChronoUnit.DAYS.between(it.date, today) <= 5 }
            .map { it.recoveryRemainingHours }.sortedDescending().foldIndexed(0.0) { i, acc, h -> acc + h * if (i == 0) 1.0 else .5 }
        val recoveryRemaining = when {
            recoveryBase > 0 -> recoveryBase + morningPts * .3
            morningPts >= 14 -> morningPts * .3
            else -> recoveryBase
        }.roundToInt().coerceIn(0, 96)
        // Readiness already scores sleep, HRV and resting HR as their own factors, so its Recovery factor must not
        // include the morning points again (legacy readinessCalc calls recoveryCalc with pts = 0).
        val readinessRecovery = recoveryBase.roundToInt().coerceIn(0, 96)
        val readiness = readiness(cur, daily, today, readinessRecovery, ratio, readinessConfig.safe(), scale)
        val adjustment = readiness?.let { recommendTodayPlan(plan, today, it.score, readinessConfig.safe()) }
        return TrainingMetricsResult(days, sessionMetrics, weekly, cur.fitness.roundToInt(), cur.fatigue.roundToInt(), cur.form.roundToInt(), ratio,
            (cur.fitness * 7 * .8).roundToInt()..(cur.fitness * 7 * 1.3).roundToInt(), status.first, status.second,
            readiness, recoveryRemaining, scale, lthr, hrMax, adjustment, morningPts)
    }

    /** Perkiraan beban satu pekan rencana (tanpa HR): menit lari × faktor jenis sesi × skala internal, sama dengan jalur "estimasi durasi" di calculate(). */
    fun plannedWeekLoad(week: PWeek, settings: PlanSettings, scale: Double = DEFAULT_SCALE): Int {
        val pace = Js.parsePaceStr(settings.pace)
        return week.days.filter { it.kind != Kinds.REST && it.km > 0 }
            .sumOf { d -> d.km * pace / 60.0 * (kindFactors[d.kind] ?: 50.0) * scale }.roundToInt()
    }

    private fun recommendTodayPlan(plan: PlanOutcome, today: LocalDate, score: Int, config: ReadinessConfig): PlanAdjustment? {
        val day = (plan as? PlanOutcome.Ok)?.weeks?.asSequence()?.flatMap { it.days.asSequence() }
            ?.firstOrNull { it.date == today } ?: return null
        if (day.kind == Kinds.REST || day.kind == Kinds.RACE || day.kind == Kinds.EVENT) return null
        val action = when {
            day.kind in setOf(Kinds.QUALITY, Kinds.LONG, Kinds.MEDIUM) && score < config.swapThreshold -> "swap"
            day.kind in setOf(Kinds.QUALITY, Kinds.LONG, Kinds.MEDIUM) && score < config.lightThreshold -> "light"
            day.kind in setOf(Kinds.EASY, "short") && score < config.easyThreshold -> "light"
            else -> return null
        }
        val km = if (action == "swap") min(6.0, max(3.0, day.km * .5)) else day.km * .8
        val reason = when (action) {
            "swap" -> "Readiness di bawah ${config.swapThreshold}. Pertimbangkan mengganti sesi utama dengan lari easy pendek 3–6 km, sepeda ringan, atau istirahat."
            else -> "Readiness belum mencapai ambang ${if (day.kind in setOf(Kinds.EASY, "short")) config.easyThreshold else config.lightThreshold}. Pertimbangkan mengurangi jarak sekitar 20% dan menjaga intensitas tetap ringan."
        }
        return PlanAdjustment(day.title, day.kind, day.km, action, km, reason, score)
    }

    /** Jam tidur efektif satu hari (malam + tidur siang maks. 180 menit); null bila malam belum tercatat. Dasar utang tidur 7 hari. */
    fun effectiveSleepHours(day: DailyEntity): Double? = sleepFactors(day)?.effectiveHours

    /** Utang tidur: selisih (kebutuhan - tidur) per malam, kelebihan dihitung maks. 1 jam per malam, hasil >= 0 dibulatkan 0,1 jam. */
    fun sleepDebtOf(effective: List<Double>, need: Double): Double =
        (max(0.0, effective.sumOf { max(need - it, -1.0) }) * 10).roundToInt() / 10.0

    private data class SleepFactors(
        val effectiveHours: Double,
        val score: Int,
        val awakeCount: Int,
        val awakeMinutes: Int,
        val stageAdjustment: Int,
    )

    /** Port morningAdj() dari web: nilai harian terbaru (maks. 1 hari lalu) dibanding rata-rata 14 hari sebelumnya. */
    fun morningPoints(daily: List<DailyEntity>, today: LocalDate): Int {
        val ordered = daily.sortedBy { it.dateIso }
        val last = ordered.lastOrNull() ?: return 0
        val lastDate = runCatching { LocalDate.parse(last.dateIso.take(10)) }.getOrNull() ?: return 0
        if (ChronoUnit.DAYS.between(lastDate, today) > 1) return 0
        val base = ordered.dropLast(1).takeLast(14)
        var pts = 0
        val rb = base.mapNotNull { it.rhr }.filter { it > 0 }
        val rhr = last.rhr
        if (rhr != null && rhr > 0 && rb.size >= 3) {
            val d = rhr - rb.average()
            if (d >= 8) pts += 14 else if (d >= 5) pts += 8
        }
        val hb = base.mapNotNull { it.hrv }.filter { it > 0 }
        val hrv = last.hrv
        if (hrv != null && hrv > 0 && hb.size >= 3) {
            val n = hb.average()
            if (hrv <= n * .7) pts += 14 else if (hrv <= n * .85) pts += 8
        }
        val se = sleepFactors(last)?.effectiveHours ?: 0.0
        if (se > 0) { if (se < 5) pts += 10 else if (se < 6) pts += 6 }
        return pts
    }

    private fun rawNumber(raw: String, key: String): Double? = runCatching {
        val obj = com.google.gson.JsonParser.parseString(raw).asJsonObject
        obj.get(key)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asDouble
    }.getOrNull()

    private fun truthy(e: com.google.gson.JsonElement?): Boolean {
        if (e == null || !e.isJsonPrimitive) return false
        val p = e.asJsonPrimitive
        return if (p.isBoolean) p.asBoolean else if (p.isNumber) p.asDouble != 0.0 else p.asString.let { it == "true" || it == "1" }
    }

    /** Port of sleepScore() / awakeMin() / awakeN() from the web app. */
    private fun sleepFactors(day: DailyEntity): SleepFactors? {
        val night = day.sleepH?.takeIf { it > 0 } ?: rawNumber(day.raw, "sleep")?.takeIf { it > 0 } ?: return null
        val nap = (rawNumber(day.raw, "nap") ?: 0.0).coerceIn(0.0, 180.0)
        val effective = (night + nap / 60.0).let { (it * 10).roundToInt() / 10.0 }
        var awakeCount = (rawNumber(day.raw, "wkN") ?: 0.0).roundToInt().coerceIn(0, 20)
        var awakeMinutes = 0
        runCatching {
            val root = com.google.gson.JsonParser.parseString(day.raw).asJsonObject
            val ranges = root.getAsJsonArray("wks")
            if (ranges != null && ranges.size() > 0) {
                // From the watch: sum of awake ranges; no-data gaps (g) are not awake time.
                ranges.forEach { e ->
                    val o = e.asJsonObject
                    if (!truthy(o.get("g"))) awakeMinutes += o.get("m")?.takeIf { it.isJsonPrimitive }?.asInt ?: 0
                }
            } else {
                // Manual: a single awake span (wkAt -> reAt) that must lie between bed time and wake time.
                val bed = parseClock(root.get("bed")?.takeIf { it.isJsonPrimitive }?.asString)
                val wake = parseClock(root.get("wake")?.takeIf { it.isJsonPrimitive }?.asString)
                val x = parseClock(root.get("wkAt")?.takeIf { it.isJsonPrimitive }?.asString)
                val y = parseClock(root.get("reAt")?.takeIf { it.isJsonPrimitive }?.asString)
                if (bed != null && wake != null && x != null && y != null) {
                    var span = (wake - bed + 1440) % 1440; if (span == 0) span = 1440
                    val o1 = (x - bed + 1440) % 1440; val o2 = (y - bed + 1440) % 1440
                    if (o2 > o1 && o2 <= span) awakeMinutes = o2 - o1
                }
            }
        }
        if (awakeCount == 0 && awakeMinutes > 0) awakeCount = 1
        val deep = rawNumber(day.raw, "deep") ?: 0.0
        val rem = rawNumber(day.raw, "rem") ?: 0.0
        val light = rawNumber(day.raw, "light") ?: 0.0
        val totalStages = deep + rem + light
        val stageAdj = if (totalStages > 0 && deep + rem > 0)
            jsRound(((deep + rem) / totalStages - .35) * 50).coerceIn(-8, 8) else 0
        val penalty = min(awakeCount * 6, 30) + min(awakeMinutes / 10, 10)
        val base = jsRound((effective - 4.0) / 3.5 * 100).coerceIn(0, 100)
        val score = (base - penalty + stageAdj).coerceIn(0, 100)
        return SleepFactors(effective, score, awakeCount, awakeMinutes, stageAdj)
    }

    /** JS Math.round (halves round up, also for negatives) so scores match the web app exactly. */
    private fun jsRound(v: Double): Int = Math.floor(v + 0.5).toInt()

    private fun parseClock(value: String?): Int? {
        if (value == null) return null
        val parts = value.split(":")
        if (parts.size != 2) return null
        val h = parts[0].toIntOrNull() ?: return null
        val m = parts[1].toIntOrNull() ?: return null
        return if (h in 0..23 && m in 0..59) h * 60 + m else null
    }

    private fun readiness(current: LoadDay?, daily: List<DailyEntity>, today: LocalDate, recovery: Int = 0, ratio: Double = 0.0, config: ReadinessConfig = ReadinessConfig(), scale: Double = 1.0): ReadinessMetric? {
        val ordered = daily.sortedBy { it.dateIso }
        // Select the newest fresh record independently for each sensor family. A manual leg/mood
        // entry for today must not hide last night's sleep or the latest watch HR/HRV samples.
        fun isFresh(day: DailyEntity): Boolean = runCatching {
            val date = LocalDate.parse(day.dateIso.take(10))
            !date.isBefore(today.minusDays(1)) && !date.isAfter(today)
        }.getOrDefault(false)
        val freshRows = ordered.filter(::isFresh)
        val latestSleep = freshRows.lastOrNull { sleepFactors(it) != null }
        val latestHrv = freshRows.lastOrNull { it.hrv != null && it.hrv > 0 }
        val latestRhr = freshRows.lastOrNull { it.rhr != null && it.rhr > 0 }
        val latestSleepHr = freshRows.lastOrNull { rawNumber(it.raw, "shr")?.let { v -> v > 0 } == true }
        val latestLeg = freshRows.lastOrNull { it.leg != null && it.leg in 1..5 }
        val latestMood = freshRows.lastOrNull { it.mood != null && it.mood in 1..5 }
        val baselineDate = listOfNotNull(latestSleep?.dateIso, latestHrv?.dateIso, latestRhr?.dateIso, latestSleepHr?.dateIso)
            .maxOrNull() ?: today.toString()
        val baseline = ordered.filter { it.dateIso < baselineDate }.takeLast(14)
        val parts = mutableListOf<ReadinessPart>()
        if (current != null) {
            parts += ReadinessPart("rec", "Recovery", (100 - recovery * 100.0 / 72).roundToInt().coerceIn(0, 100),
                if (recovery < 2) "Pulih" else "Sisa sekitar $recovery jam", 30.0)
            if (current.fitness > 8 * scale) parts += ReadinessPart("load", "Beban latihan",
                (100 - max(0.0, ratio - 1) * 140).roundToInt().coerceIn(10, 100), "ATL:CTL %.2f".format(ratio), 20.0)
        }
        val sleep = latestSleep?.let { sleepFactors(it) }
        if (sleep != null) {
            parts += ReadinessPart("sl", "Tidur", sleep.score,
                "%.1f jam efektif".format(sleep.effectiveHours) +
                    (if (sleep.awakeCount > 0) " · ${sleep.awakeCount}× terbangun" else "") +
                    (if (sleep.awakeMinutes > 0) " · ${sleep.awakeMinutes} menit terjaga" else "") +
                    (if (sleep.stageAdjustment != 0) " · fase ${if (sleep.stageAdjustment > 0) "+" else ""}${sleep.stageAdjustment}" else ""),
                20.0)
        }
        val sleepDays = (0..6).mapNotNull { offset ->
            val d = today.minusDays(offset.toLong()).toString()
            ordered.lastOrNull { it.dateIso.take(10) == d }?.let { sleepFactors(it)?.effectiveHours }
        }
        var sleepDebtHours: Double? = null
        if (sleepDays.size >= 3) {
            val need = config.sleepNeedHours.coerceIn(5.0, 10.0)
            // Legacy sleepDebt(): debt rounded to 0.1 h first, the score is derived from the rounded value.
            val debt = sleepDebtOf(sleepDays, need)
            sleepDebtHours = debt
            val score = (100 - debt * 14).roundToInt().coerceIn(0, 100)
            parts += ReadinessPart("debt", "Utang tidur 7 hari", score,
                "%.1f jam · %d/7 malam".format(debt, sleepDays.size), 15.0)
        }
        latestHrv?.hrv?.takeIf { it > 0 }?.let { v ->
            val b = ordered.filter { it.dateIso < latestHrv.dateIso }.takeLast(14).mapNotNull { it.hrv }.filter { it > 0 }
            val score = if (b.size >= 3) (100 - max(0.0, 1 - v / b.average()) * 200).roundToInt().coerceIn(0, 100) else null
            parts += ReadinessPart("hrv", "HRV", score,
                "$v ms" + if (score == null) " · butuh ≥3 hari data" else " · baseline %.0f ms".format(b.average()),
                if (score == null) 0.0 else 20.0)
        }
        latestRhr?.rhr?.takeIf { it > 0 }?.let { v ->
            val b = ordered.filter { it.dateIso < latestRhr.dateIso }.takeLast(14).mapNotNull { it.rhr }.filter { it > 0 }
            val delta = if (b.isNotEmpty()) v - b.average() else 0.0
            val score = if (b.size >= 3) (100 - max(0.0, delta) * 7).roundToInt().coerceIn(0, 100) else null
            parts += ReadinessPart("rhr", "HR istirahat", score,
                "$v bpm" + if (score == null) " · butuh ≥3 hari data" else " · ${if (delta >= 0) "+" else ""}${delta.roundToInt()} bpm",
                if (score == null) 0.0 else 10.0)
        }
        latestSleepHr?.let { day ->
            val sleepHr = rawNumber(day.raw, "shr")?.takeIf { it in 25.0..220.0 }
            if (sleepHr != null) {
                val base = ordered.filter { it.dateIso < day.dateIso }.takeLast(14)
                    .mapNotNull { rawNumber(it.raw, "shr") }.filter { it in 25.0..220.0 }
                if (base.size >= 3) {
                    val delta = sleepHr - base.average()
                    val score = (100 - max(0.0, delta) * 8).roundToInt().coerceIn(0, 100)
                    parts += ReadinessPart("shr", "HR saat tidur", score,
                        "${sleepHr.roundToInt()} bpm · ${if (delta >= 0) "+" else ""}${delta.roundToInt()} bpm", 5.0)
                }
            }
        }
        // Legacy pain readiness: highest pain today/yesterday; recurring area subtracts 10 points (max 20).
        val painDays = setOf(today, today.minusDays(1))
        val recentPain = config.painEntries.filter { it.date in painDays && it.severity in 1..5 }
        val topPain = recentPain.maxByOrNull { it.severity }
        if (topPain != null) {
            val fourDays = (0..3).map { today.minusDays(it.toLong()) }.toSet()
            val alerts = InjuryPrevention.alerts(config.painEntries, today).size
            val basePain = listOf(90, 75, 55, 30, 10)[topPain.severity - 1]
            val painScore = (basePain - min(alerts * 10, 20)).coerceIn(0, 100)
            parts += ReadinessPart("pain", "Nyeri", painScore,
                "${InjuryPrevention.areaName(topPain.area)} ${topPain.severity}/5" + if (alerts > 0) " · berulang" else "", 15.0)
        }
        latestLeg?.leg?.let {
            val score = listOf(100, 80, 55, 30, 10)[it - 1]
            parts += ReadinessPart("leg", "Rasa kaki", score, "$it/5", 15.0)
        }
        latestMood?.mood?.let {
            val score = listOf(100, 80, 55, 30, 10)[it - 1]
            parts += ReadinessPart("mood", "Stres / mood", score, "$it/5", 10.0)
        }
        val adjustedParts = parts.map { part -> part.copy(weight = config.weights[part.key] ?: part.weight) }
        val usable = adjustedParts.filter { it.score != null && it.weight > 0 }
        val totalWeight = usable.sumOf { it.weight }
        if (totalWeight <= 0) return null
        val score = (usable.sumOf { it.score!! * it.weight } / totalWeight).roundToInt().coerceIn(0, 100)
        val tier = when {
            score >= 80 -> "Siap penuh"
            score >= 60 -> "Baik"
            score >= 40 -> "Sedang"
            score >= 20 -> "Rendah"
            else -> "Perlu istirahat"
        }
        val weakest = usable.minByOrNull { it.score!! }
        val advice = when {
            score >= 80 -> "Siap untuk sesi kualitas atau long run."
            score >= 60 -> "Sesi kualitas masih memungkinkan; tetap dengarkan tubuh."
            score >= 40 -> "Pilih lari easy atau sesi yang lebih pendek."
            score >= 20 -> "Sebaiknya easy, sepeda ringan, atau istirahat."
            else -> "Prioritaskan istirahat hari ini."
        } + (if (weakest != null && weakest.score!! < 70 && score < 80) " Faktor terendah: ${weakest.label} (${weakest.detail})." else "")
        return ReadinessMetric(score, tier, advice, adjustedParts, baseline.size + if (freshRows.isNotEmpty()) 1 else 0, sleepDebtHours)
    }


}
