package com.endurancevault.app.ui.video

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.endurancevault.app.data.TerrainScene
import com.endurancevault.app.domain.GhostInfo
import com.endurancevault.app.domain.RouteVideoCamera
import com.endurancevault.app.domain.RouteVideoColors
import com.endurancevault.app.domain.RouteVideoFormat
import com.endurancevault.app.domain.RouteVideoPrefs
import com.endurancevault.app.domain.RouteVideoRace
import com.endurancevault.app.domain.RouteVideoTimeline
import com.endurancevault.app.domain.RouteVideoTrack
import com.endurancevault.app.ui.sticker.StickerFonts
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.CancellationException

/**
 * Render video rute 3D ke MP4 (H.264, 30 fps, ukuran menurut rasio dan kualitas): tiap frame digambar lewat OpenGL ES
 * ke Surface milik MediaCodec, lalu bendera dan panel data digambar di atasnya. Berjalan blocking di thread
 * pemanggil, yang juga harus thread GL-nya.
 */
object RouteVideoEncoder {
    const val FPS = 30

    /**
     * [ghost] (opsional) membuat balapan menurut waktu. [isActive] dicek tiap frame; bila false, render berhenti dan
     * berkas sementara dihapus. [onProgress] 0..1.
     */
    fun encode(
        scene: TerrainScene, track: RouteVideoTrack, ghost: RouteVideoTrack?, prefs: RouteVideoPrefs, fonts: StickerFonts, out: File,
        isActive: () -> Boolean, onProgress: (Float) -> Unit,
    ): Result<Unit> {
        out.parentFile?.mkdirs(); out.delete()
        val (W, H) = RouteVideoFormat.size(prefs.aspect, prefs.quality)
        var codec: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var egl: EglCore? = null
        var gl: TerrainGl? = null
        var inputSurface: android.view.Surface? = null
        var muxerStarted = false
        var trackIndex = -1
        var ok = false
        try {
            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, W, H).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, (W.toLong() * H * 7).coerceAtMost(40_000_000L).toInt())
                setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }
            val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            codec = enc
            enc.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = enc.createInputSurface()
            enc.start()
            val mux = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = mux

            val eg = EglCore(inputSurface, W, H)
            egl = eg
            eg.makeCurrent()
            val g = TerrainGl(W, H).also { it.init() }
            gl = g
            val accent = RouteVideoOverlay.accentOf(prefs)
            g.accent = accent; g.hillshade = prefs.hillshade; g.fog = prefs.fog
            g.setLineScale(prefs.lineWidth / 100f)
            g.setScene(scene, prefs.exaggeration.toFloat(), reuseTexture = false)
            g.setColors(RouteVideoColors.colors(track, prefs.lineMode, accent, scene.routeFrac))
            val race = ghost?.takeIf { scene.ghostX != null }?.let { RouteVideoRace(track, it) }

            val info = MediaCodec.BufferInfo()
            fun drain(endOfStream: Boolean) {
                while (true) {
                    val i = enc.dequeueOutputBuffer(info, if (endOfStream) 10_000 else 0)
                    when {
                        i == MediaCodec.INFO_TRY_AGAIN_LATER -> { if (!endOfStream) return }
                        i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            check(!muxerStarted) { "Format keluaran berubah dua kali." }
                            trackIndex = mux.addTrack(enc.outputFormat); mux.start(); muxerStarted = true
                        }
                        i >= 0 -> {
                            val buf = enc.getOutputBuffer(i)
                            if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                            if (info.size > 0 && buf != null && muxerStarted) {
                                buf.position(info.offset); buf.limit(info.offset + info.size)
                                mux.writeSampleData(trackIndex, buf, info)
                            }
                            enc.releaseOutputBuffer(i, false)
                            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                        }
                    }
                }
            }

            val overlay = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(overlay)
            val frames = RouteVideoTimeline.frames(prefs, FPS)
            for (f in 0 until frames) {
                if (!isActive()) throw CancellationException("Render dibatalkan.")
                val pt = RouteVideoTimeline.at(f.toDouble() / (frames - 1).coerceAtLeast(1), prefs)
                val cam = RouteVideoCamera.at(pt.p, prefs, race, track)
                val st = track.statsAt(cam.routeFrac, prefs.live)
                val marks = RouteVideoOverlay.marksFor(scene, g.project(cam), track, prefs, cam.routeFrac)
                val gi = if (race != null && ghost != null) GhostInfo(ghost.title, race.gapSeconds(cam.routeFrac)) else null
                overlay.eraseColor(0)
                RouteVideoOverlay.draw(canvas, W, H, prefs, track, st, cam.routeFrac, fonts, null, marks, gi, pt.summaryAlpha)
                g.render(cam, overlay)
                eg.setPresentationTime(f * 1_000_000_000L / FPS)
                check(eg.swap()) { "Gagal menukar buffer EGL." }
                drain(false)
                onProgress((f + 1f) / frames)
            }
            overlay.recycle()
            enc.signalEndOfInputStream()
            drain(true)
            check(muxerStarted) { "Encoder tidak menghasilkan data." }
            ok = true
        } catch (e: Throwable) {
            if (e is OutOfMemoryError) return Result.failure(IllegalStateException("Memori tidak cukup untuk membuat video. Coba kualitas 720p."))
            return Result.failure(e)
        } finally {
            runCatching { gl?.release() }
            runCatching { egl?.release() }
            runCatching { inputSurface?.release() }
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { if (muxerStarted) muxer?.stop() }
            runCatching { muxer?.release() }
            if (!ok) out.delete()
        }
        return Result.success(Unit)
    }

    /**
     * Satu bingkai penuh (ukuran dan tampilan sama dengan video) pada posisi [pos] (0..1) di seluruh linimasa, sebagai bitmap.
     * Harus dipanggil dari thread yang boleh memakai OpenGL (membuat konteks pbuffer sendiri lalu melepasnya).
     */
    fun renderStill(
        scene: TerrainScene, track: RouteVideoTrack, ghost: RouteVideoTrack?, prefs: RouteVideoPrefs, fonts: StickerFonts, pos: Double,
    ): Result<Bitmap> {
        val (W, H) = RouteVideoFormat.size(prefs.aspect, prefs.quality)
        var egl: EglCore? = null
        var gl: TerrainGl? = null
        return try {
            val eg = EglCore(null, W, H)
            egl = eg
            eg.makeCurrent()
            val g = TerrainGl(W, H).also { it.init() }
            gl = g
            val accent = RouteVideoOverlay.accentOf(prefs)
            g.accent = accent; g.hillshade = prefs.hillshade; g.fog = prefs.fog
            g.setLineScale(prefs.lineWidth / 100f)
            g.setScene(scene, prefs.exaggeration.toFloat(), reuseTexture = false)
            g.setColors(RouteVideoColors.colors(track, prefs.lineMode, accent, scene.routeFrac))
            val race = ghost?.takeIf { scene.ghostX != null }?.let { RouteVideoRace(track, it) }
            val pt = RouteVideoTimeline.at(pos, prefs)
            val cam = RouteVideoCamera.at(pt.p, prefs, race, track)
            val st = track.statsAt(cam.routeFrac, prefs.live)
            val marks = RouteVideoOverlay.marksFor(scene, g.project(cam), track, prefs, cam.routeFrac)
            val gi = if (race != null && ghost != null) GhostInfo(ghost.title, race.gapSeconds(cam.routeFrac)) else null
            val overlay = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
            RouteVideoOverlay.draw(Canvas(overlay), W, H, prefs, track, st, cam.routeFrac, fonts, null, marks, gi, pt.summaryAlpha)
            g.render(cam, overlay)
            val bmp = g.readFrame()
            overlay.recycle()
            Result.success(bmp)
        } catch (e: Throwable) {
            Result.failure(if (e is OutOfMemoryError) IllegalStateException("Memori tidak cukup untuk foto penuh. Coba kualitas 720p.") else e)
        } finally {
            runCatching { gl?.release() }
            runCatching { egl?.release() }
        }
    }
}

/** Menyimpan dan membagikan video hasil render. */
object RouteVideoIo {
    fun cacheDir(ctx: Context): File = File(ctx.cacheDir, "videos").apply {
        mkdirs()
        listFiles()?.filter { it.lastModified() < System.currentTimeMillis() - 24 * 3600_000L }?.forEach { it.delete() }
    }

    /** Simpan ke galeri, album TrainingPlan (Android 10+ tanpa izin); Android 9 ke bawah ke folder video milik aplikasi. */
    fun saveToGallery(ctx: Context, file: File, name: String): Result<String> = runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val cv = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/TrainingPlan")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val cr = ctx.contentResolver
            val uri = cr.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv) ?: error("galeri menolak berkas")
            try {
                cr.openOutputStream(uri)!!.use { o -> file.inputStream().use { it.copyTo(o) } }
                cr.update(uri, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
            } catch (e: Exception) { cr.delete(uri, null, null); throw e }
            "galeri, album TrainingPlan"
        } else {
            val dir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "TrainingPlan").apply { mkdirs() }
            FileOutputStream(File(dir, name)).use { o -> file.inputStream().use { it.copyTo(o) } }
            "folder aplikasi (${dir.absolutePath})"
        }
    }

    /** Simpan foto (JPEG) ke galeri, album TrainingPlan; Android 9 ke bawah ke folder gambar milik aplikasi. */
    fun savePhotoToGallery(ctx: Context, file: File, name: String): Result<String> = runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/TrainingPlan")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val cr = ctx.contentResolver
            val uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: error("galeri menolak berkas")
            try {
                cr.openOutputStream(uri)!!.use { o -> file.inputStream().use { it.copyTo(o) } }
                cr.update(uri, ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }, null, null)
            } catch (e: Exception) { cr.delete(uri, null, null); throw e }
            "galeri, album TrainingPlan"
        } else {
            val dir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_PICTURES), "TrainingPlan").apply { mkdirs() }
            FileOutputStream(File(dir, name)).use { o -> file.inputStream().use { it.copyTo(o) } }
            "folder aplikasi (${dir.absolutePath})"
        }
    }

    /** Tulis [bmp] sebagai JPEG kualitas 95 ke cache dan kembalikan berkasnya. */
    fun writePhoto(ctx: Context, bmp: Bitmap, name: String): File {
        val f = File(cacheDir(ctx), name)
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        return f
    }

    fun share(ctx: Context, file: File, title: String = "Bagikan video", mime: String = "video/mp4"): Result<Unit> = runCatching {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mime; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
