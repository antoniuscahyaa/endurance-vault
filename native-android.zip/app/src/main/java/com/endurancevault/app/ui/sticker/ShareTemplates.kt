package com.endurancevault.app.ui.sticker

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import com.endurancevault.app.domain.PeriodSummary
import com.endurancevault.app.domain.SharePeriod
import com.endurancevault.app.ui.i18n.Lang
import com.endurancevault.app.ui.sticker.ShareCardRenderer.DAYS
import com.endurancevault.app.ui.sticker.ShareCardRenderer.EM
import com.endurancevault.app.ui.sticker.ShareCardRenderer.EM2
import com.endurancevault.app.ui.sticker.ShareCardRenderer.PAD
import com.endurancevault.app.ui.sticker.ShareCardRenderer.W
import com.endurancevault.app.ui.sticker.ShareCardRenderer.brandRow
import com.endurancevault.app.ui.sticker.ShareCardRenderer.duration
import com.endurancevault.app.ui.sticker.ShareCardRenderer.inkFor
import com.endurancevault.app.ui.sticker.ShareCardRenderer.km1
import com.endurancevault.app.ui.sticker.ShareCardRenderer.km2
import com.endurancevault.app.ui.sticker.ShareCardRenderer.newCanvas
import com.endurancevault.app.ui.sticker.ShareCardRenderer.pace
import com.endurancevault.app.ui.sticker.ShareCardRenderer.periodLabel
import com.endurancevault.app.ui.sticker.ShareCardRenderer.tag
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Template kartu. [CLASSIC] adalah kartu awal; sisanya ditambahkan kemudian. */
enum class ShareTemplate(val label: String) {
    CLASSIC("Klasik"), POSTER("Poster"), RING("Cincin target"), RECEIPT("Struk"), BIB("Nomor dada"),
    CALENDAR("Kalender"), GLASS("Kaca"), CURVE("Kurva"), COMPARE("Banding"), TILES("Ubin"), STRIP("Strip");
}

/** Template yang tersedia untuk data yang ada; Cincin butuh target rencana, Banding butuh pembanding, dst. */
fun availableTemplates(period: SharePeriod, hasTarget: Boolean, hasPrev: Boolean, dayHasSeries: Boolean): List<ShareTemplate> =
    ShareTemplate.values().filter {
        when (it) {
            ShareTemplate.RING -> hasTarget
            ShareTemplate.COMPARE -> hasPrev
            ShareTemplate.CALENDAR -> period != SharePeriod.DAY
            ShareTemplate.CURVE -> period != SharePeriod.DAY || dayHasSeries
            else -> true
        }
    }

/** Alat gambar: kanvas + cat, dengan bayangan teks otomatis bila [ink] meminta (latar foto/transparan). */
internal class Pen(val c: Canvas, var ink: Ink) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private fun face(bold: Boolean, mono: Boolean): Typeface =
        if (mono) Typeface.create(Typeface.MONOSPACE, if (bold) Typeface.BOLD else Typeface.NORMAL)
        else Typeface.create(if (bold) "sans-serif-medium" else "sans-serif", Typeface.NORMAL)

    fun width(s: String, size: Float, bold: Boolean = false, spacing: Float = 0f, mono: Boolean = false): Float {
        p.reset(); p.isAntiAlias = true; p.textSize = size; p.letterSpacing = spacing; p.typeface = face(bold, mono)
        return p.measureText(s)
    }

    fun text(s: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean = false, align: Paint.Align = Paint.Align.LEFT, spacing: Float = 0f, mono: Boolean = false) {
        p.reset(); p.isAntiAlias = true; p.textSize = size; p.color = color; p.textAlign = align; p.letterSpacing = spacing; p.typeface = face(bold, mono)
        if (ink.shadow) p.setShadowLayer(14f, 0f, 3f, Color.argb(130, 0, 0, 0))
        c.drawText(s, x, y, p)
    }

    /** Ukuran terbesar (<= [start], >= [min]) yang membuat [s] muat dalam [maxW]. */
    fun fit(s: String, start: Float, min: Float, maxW: Float, bold: Boolean = true): Float {
        var z = start
        while (z > min && width(s, z, bold) > maxW) z -= 6f
        return z
    }

    fun rect(r: RectF, color: Int, radius: Float = 0f) {
        p.reset(); p.isAntiAlias = true; p.color = color
        if (radius > 0f) c.drawRoundRect(r, radius, radius, p) else c.drawRect(r, p)
    }

    fun circle(cx: Float, cy: Float, r: Float, color: Int) { p.reset(); p.isAntiAlias = true; p.color = color; c.drawCircle(cx, cy, r, p) }

    fun line(x1: Float, y1: Float, x2: Float, y2: Float, color: Int, w: Float = 3f, dash: Boolean = false) {
        p.reset(); p.isAntiAlias = true; p.color = color; p.strokeWidth = w; p.style = Paint.Style.STROKE
        if (dash) p.pathEffect = DashPathEffect(floatArrayOf(14f, 12f), 0f)
        c.drawLine(x1, y1, x2, y2, p)
    }
}

internal fun withAlpha(color: Int, a: Int): Int = Color.argb(a, Color.red(color), Color.green(color), Color.blue(color))

/** Satu statistik: label, nilai, satuan. */
internal class Stat(val label: String, val value: String, val unit: String)

internal fun coreStats(sm: PeriodSummary): List<Stat> = listOf(
    Stat(Lang.tr("Durasi"), duration(sm.durationSec), ""),
    Stat(Lang.tr("Pace rata-rata"), pace(sm.avgPace), "/km"),
    Stat(Lang.tr("Elevasi"), "+${sm.gain}", "m"),
)

/** Dua statistik tambahan: harian = detak jantung dan km tercepat; mingguan/bulanan = sesi lari dan detak jantung (atau hari aktif). */
internal fun extraStats(sm: PeriodSummary, day: ShareDayExtra?): List<Stat> {
    val hr = sm.avgHr?.let { Stat(Lang.tr("Detak jantung"), "$it", "bpm") }
    return if (sm.period == SharePeriod.DAY) {
        val best = day?.splitPace?.minOrNull()
        listOf(
            hr ?: Stat(Lang.tr("Terpanjang"), km2(sm.longestKm), "km"),
            if (best != null) Stat(Lang.tr("Km tercepat"), pace(best), "/km") else Stat(Lang.tr("Sesi lari"), "${sm.sessions}", "kali"),
        )
    } else {
        listOf(Stat(Lang.tr("Sesi lari"), "${sm.sessions}", "kali"), hr ?: Stat(Lang.tr("Hari aktif"), "${sm.activeDays}", "hari"))
    }
}

internal object ShareTemplates {
    private val DK = Color.parseColor("#111112")
    private val GREEN = Color.parseColor("#4CC38A")
    private val DOWN = Color.parseColor("#E8844F")
    private val CREAM = Color.parseColor("#F4F1EA")
    private val PAPER = Color.parseColor("#FAFAF7")
    private val INK_DARK = Color.parseColor("#1C1C1E")
    private val INK_SOFT = Color.parseColor("#6E6E73")

    fun render(t: ShareTemplate, sm: PeriodSummary, bg: ShareBg, photo: Bitmap?, day: ShareDayExtra?, size: ShareSize, brand: ShareBrand, ex: ShareExtras): Bitmap {
        if (t == ShareTemplate.STRIP) return strip(sm, bg, photo, brand)
        val solid = when (t) { ShareTemplate.POSTER -> EM; ShareTemplate.RECEIPT -> CREAM; ShareTemplate.BIB -> PAPER; else -> DK }
        val (out, c) = newCanvas(bg, photo, size, solid)
        val lay = Lay.of(size)
        val ink = inkFor(bg)
        when (t) {
            ShareTemplate.POSTER -> poster(Pen(c, ink), sm, bg, brand, lay)
            ShareTemplate.RING -> ring(Pen(c, ink), sm, ink, brand, ex, lay)
            ShareTemplate.RECEIPT -> receipt(c, sm, bg, day, brand, lay)
            ShareTemplate.BIB -> bib(c, sm, bg, day, brand, lay, size.h.toFloat())
            ShareTemplate.CALENDAR -> calendar(Pen(c, ink), sm, ink, brand, lay)
            ShareTemplate.GLASS -> glass(Pen(c, ink), sm, bg, ink, day, brand, lay)
            ShareTemplate.CURVE -> curve(Pen(c, ink), sm, ink, day, brand, lay)
            ShareTemplate.COMPARE -> compare(Pen(c, ink), sm, ink, brand, ex, lay)
            ShareTemplate.TILES -> tiles(Pen(c, ink), sm, bg, ink, day, brand, lay)
            else -> Unit
        }
        return out
    }

    /** Kepala umum: merek (ikon + judul) di kiri, tag periode di kanan, tanggal periode di bawahnya. */
    private fun header(pen: Pen, sm: PeriodSummary, brand: ShareBrand, brandColor: Int, tagColor: Int, labelColor: Int, lay: Lay) {
        brandRow(pen, brand, PAD, 117f + lay.hs, 32f, brandColor)
        pen.text(tag(sm.period), W - PAD, 117f + lay.hs, 32f, tagColor, true, Paint.Align.RIGHT, 0.12f)
        pen.text(periodLabel(sm), PAD, 196f + lay.hs, 42f, labelColor)
    }

    private fun heroText(sm: PeriodSummary) = if (sm.period == SharePeriod.DAY) km2(sm.km) else km1(sm.km)

    /** Angka km + "km" kecil di sebelahnya, rata kiri pada [x]/[base]. */
    private fun hero(pen: Pen, sm: PeriodSummary, x: Float, base: Float, maxSize: Float, color: Int, unitColor: Int) {
        val t = heroText(sm)
        val hs = pen.fit(t, maxSize, 110f, W - 2 * PAD - 160f)
        pen.text(t, x, base, hs, color, true)
        pen.text("km", x + pen.width(t, hs, true) + 22f, base, 64f, unitColor)
    }

    /** Kolom statistik: label kecil di atas, nilai besar + satuan. */
    private fun statCol(pen: Pen, x: Float, y: Float, s: Stat, vSize: Float, valueColor: Int, muteColor: Int, maxW: Float = 300f) {
        pen.text(s.label, x, y, 32f, muteColor)
        val vs = pen.fit(s.value, vSize, 36f, maxW - (if (s.unit.isEmpty()) 0f else 70f))
        pen.text(s.value, x, y + 74f, vs, valueColor, true)
        if (s.unit.isNotEmpty()) pen.text(s.unit, x + pen.width(s.value, vs, true) + 10f, y + 74f, 34f, muteColor)
    }

    private fun threeCols(pen: Pen, y: Float, stats: List<Stat>, vSize: Float, valueColor: Int, muteColor: Int) {
        val cw = (W - 2 * PAD) / 3f
        stats.take(3).forEachIndexed { i, s -> statCol(pen, PAD + i * cw, y, s, vSize, valueColor, muteColor, cw - 20f) }
    }

    // 1. Poster: angka km raksasa. Solid = latar oranye, teks gelap.
    private fun poster(pen: Pen, sm: PeriodSummary, bg: ShareBg, brand: ShareBrand, lay: Lay) {
        val onSolid = bg == ShareBg.SOLID
        val fg = if (onSolid) DK else pen.ink.ink
        val sub = if (onSolid) withAlpha(DK, 205) else pen.ink.mute
        header(pen, sm, brand, sub, fg, sub, lay)
        val t = heroText(sm)
        val hs = pen.fit(t, 480f, 140f, W - 2 * PAD + 10f)
        val my = lay.hs + lay.mid / 2f
        pen.text(t, PAD - 10f, 740f + my, hs, fg, true)
        val unit = when (sm.period) { SharePeriod.DAY -> "kilometer"; SharePeriod.WEEK -> "km dalam seminggu"; SharePeriod.MONTH -> "km dalam sebulan" }
        pen.text(Lang.tr(unit), PAD, 850f + my, 84f, fg)
        pen.line(PAD, 1010f + lay.fs, W - PAD, 1010f + lay.fs, withAlpha(fg, 90), 3f)
        threeCols(pen, 1070f + lay.fs, coreStats(sm), 62f, fg, sub)
    }

    // 2. Cincin target: jarak terhadap target rencana pada periode itu.
    private fun ring(pen: Pen, sm: PeriodSummary, ink: Ink, brand: ShareBrand, ex: ShareExtras, lay: Lay) {
        header(pen, sm, brand, ink.mute, EM2, ink.mute, lay)
        val target = ex.target ?: 0.0
        val frac = if (target > 0) (sm.km / target).coerceAtLeast(0.0) else 0.0
        val cx = W / 2f; val cy = 560f + lay.hs + lay.mid / 2f; val r = 290f + lay.mid * 0.16f
        val box = RectF(cx - r, cy - r, cx + r, cy + r)
        val arc = Paint(Paint.ANTI_ALIAS_FLAG); arc.style = Paint.Style.STROKE; arc.strokeWidth = 56f; arc.strokeCap = Paint.Cap.ROUND
        arc.color = ink.empty; pen.c.drawArc(box, 0f, 360f, false, arc)
        arc.color = EM; if (frac > 0) pen.c.drawArc(box, -90f, (min(1.0, frac) * 360.0).toFloat().coerceAtLeast(2f), false, arc)
        val t = heroText(sm)
        pen.text(t, cx, cy + 20f, pen.fit(t, 170f + lay.mid * 0.1f, 90f, 2 * r - 150f), ink.ink, true, Paint.Align.CENTER)
        pen.text(Lang.tr("dari ${km1(target)} km rencana"), cx, cy + 90f, 40f, ink.mute, false, Paint.Align.CENTER)
        pen.text("${(frac * 100).roundToInt()}%", cx, cy + 170f, 64f, EM2, true, Paint.Align.CENTER)
        pen.line(PAD, 950f + lay.fs, W - PAD, 950f + lay.fs, ink.line, 2f)
        threeCols(pen, 1010f + lay.fs, coreStats(sm), 58f, ink.ink, ink.mute)
    }

    // 3. Struk: kertas krem berhuruf monospace dengan barcode.
    private fun receipt(c: Canvas, sm: PeriodSummary, bg: ShareBg, day: ShareDayExtra?, brand: ShareBrand, lay: Lay) {
        val top = if (lay.story) 200f else 60f
        val bot = if (lay.story) 1720f else 1290f
        val paper = RectF(60f, top, 1020f, bot)
        val pen = Pen(c, Ink(INK_DARK, INK_SOFT, INK_DARK, INK_DARK, false))
        if (bg != ShareBg.SOLID) {
            val sh = Paint(Paint.ANTI_ALIAS_FLAG); sh.color = CREAM; sh.setShadowLayer(40f, 0f, 12f, Color.argb(110, 0, 0, 0))
            c.drawRoundRect(paper, 28f, 28f, sh)
        }
        val cx = W / 2f
        brandRow(pen, brand, cx, top + 130f, 54f, INK_DARK, center = true, upper = true)
        val kind = when (sm.period) { SharePeriod.DAY -> "harian"; SharePeriod.WEEK -> "mingguan"; SharePeriod.MONTH -> "bulanan" }
        pen.text(Lang.tr("Struk lari $kind"), cx, top + 196f, 38f, INK_SOFT, false, Paint.Align.CENTER, 0f, true)
        pen.line(120f, top + 236f, 960f, top + 236f, INK_DARK, 3f, true)
        val extra = extraStats(sm, day)
        val per = when (sm.period) { SharePeriod.DAY -> periodLabel(sm).substringAfter(", "); SharePeriod.WEEK -> weekShort(sm); SharePeriod.MONTH -> periodLabel(sm) }
        val rows = listOf(
            "Periode" to per,
            "Jarak" to "${heroText(sm)} km",
            "Durasi" to hms(sm.durationSec),
            "Pace" to "${pace(sm.avgPace)} /km",
            "Elevasi" to "${sm.gain} m",
            extra[0].label to "${extra[0].value} ${extra[0].unit}".trim(),
            extra[1].label to "${extra[1].value} ${extra[1].unit}".trim(),
        )
        rows.forEachIndexed { i, (l, v) ->
            val y = top + 312f + i * ((bot - 364f - (top + 312f)) / 6f)
            pen.text(Lang.tr(l), 120f, y, 46f, INK_DARK, false, Paint.Align.LEFT, 0f, true)
            pen.text(v, 960f, y, 46f, INK_DARK, false, Paint.Align.RIGHT, 0f, true)
        }
        pen.line(120f, bot - 304f, 960f, bot - 304f, INK_DARK, 3f, true)
        pen.text("TOTAL", 120f, bot - 220f, 58f, INK_DARK, true, Paint.Align.LEFT, 0f, true)
        pen.text("${heroText(sm)} KM", 960f, bot - 220f, 58f, INK_DARK, true, Paint.Align.RIGHT, 0f, true)
        val widths = intArrayOf(5, 3, 8, 3, 5, 3, 3, 8, 5, 3, 5, 8, 3, 3, 5, 3, 8, 5, 3, 5, 3, 8, 3, 5, 5, 3, 8, 3, 5, 3, 3, 8, 5, 3, 5, 5, 3, 8, 3, 5, 3, 5, 8, 3, 5, 3, 3, 5, 8, 3, 5, 3)
        var x = 120f; var i = 0
        while (i < widths.size && x < 955f) { pen.rect(RectF(x, bot - 160f, min(955f, x + widths[i]), bot - 54f), INK_DARK); x += widths[i] + 6f; i++ }
    }

    private fun weekShort(sm: PeriodSummary): String {
        val a = sm.start; val b = sm.end
        val ms = arrayOf("Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des")
        return if (a.monthValue == b.monthValue) "${a.dayOfMonth}–${b.dayOfMonth} ${ms[b.monthValue - 1]} ${b.year}"
        else "${a.dayOfMonth} ${ms[a.monthValue - 1]}–${b.dayOfMonth} ${ms[b.monthValue - 1]}"
    }

    private fun hms(sec: Int): String = "${sec / 3600}:${((sec % 3600) / 60).toString().padStart(2, '0')}:${(sec % 60).toString().padStart(2, '0')}"

    // 4. Nomor dada: pita oranye di atas, angka besar, bilah gelap di bawah.
    private fun bib(c: Canvas, sm: PeriodSummary, bg: ShareBg, day: ShareDayExtra?, brand: ShareBrand, lay: Lay, canvasH: Float) {
        val solid = bg == ShareBg.SOLID
        val paper = if (solid) RectF(0f, 0f, W.toFloat(), canvasH) else RectF(60f, if (lay.story) 200f else 60f, 1020f, if (lay.story) 1720f else 1290f)
        val ct = if (lay.story) 200f else paper.top
        val cb = if (lay.story) 1720f else paper.bottom
        val ex = ((cb - ct) - 1230f) / 2f
        val rad = if (solid) 0f else 32f
        val pen = Pen(c, Ink(DK, INK_SOFT, INK_DARK, INK_DARK, false))
        if (!solid) {
            val sh = Paint(Paint.ANTI_ALIAS_FLAG); sh.color = PAPER; sh.setShadowLayer(40f, 0f, 12f, Color.argb(110, 0, 0, 0))
            c.drawRoundRect(paper, rad, rad, sh)
        }
        val clip = Path(); clip.addRoundRect(paper, rad, rad, Path.Direction.CW)
        c.save(); c.clipPath(clip)
        pen.rect(paper, PAPER)
        pen.rect(RectF(paper.left, paper.top, paper.right, ct + 300f), EM)
        pen.rect(RectF(paper.left, cb - 250f, paper.right, paper.bottom), DK)
        c.restore()
        pen.circle(paper.left + 48f, paper.top + 48f, 20f, PAPER); pen.circle(paper.right - 48f, paper.top + 48f, 20f, PAPER)
        val ix = paper.left + 72f
        brandRow(pen, brand, ix, ct + 150f, 34f, Color.WHITE)
        pen.text(tag(sm.period), paper.right - 72f, ct + 150f, 34f, Color.WHITE, true, Paint.Align.RIGHT, 0.12f)
        pen.text(periodLabel(sm), ix, ct + 238f, 40f, Color.WHITE)
        val t = heroText(sm)
        val cx = (paper.left + paper.right) / 2f
        pen.text(t, cx, ct + 740f + ex, pen.fit(t, 400f, 140f, paper.width() - 144f), DK, true, Paint.Align.CENTER)
        pen.text("KILOMETER", cx, ct + 830f + ex, 60f, INK_SOFT, false, Paint.Align.CENTER, 0.3f)
        val core = coreStats(sm); val e0 = extraStats(sm, day)[0]
        pen.text("${core[0].value}  ·  ${core[1].value} /km  ·  +${sm.gain} m", cx, cb - 126f, 50f, Color.WHITE, false, Paint.Align.CENTER)
        pen.text("${e0.label}  ${e0.value} ${e0.unit}".trim(), cx, cb - 52f, 40f, Color.parseColor("#9A9AA0"), false, Paint.Align.CENTER)
    }

    // 5. Kalender: mingguan = tujuh sel besar bernilai; bulanan = kalender panas mulai tanggal 1.
    private fun calendar(pen: Pen, sm: PeriodSummary, ink: Ink, brand: ShareBrand, lay: Lay) {
        header(pen, sm, brand, ink.mute, EM2, ink.mute, lay)
        hero(pen, sm, PAD - 6f, lay.hs + 196f + 40f + 150f * 0.82f, 150f, ink.ink, ink.mute)
        val offset = sm.start.dayOfWeek.value - 1
        val rows = (offset + sm.dailyKm.size + 6) / 7
        val gap = 12f
        val cw = (W - 2 * PAD - gap * 6) / 7f
        val top = 520f + lay.hs
        for (i in 0 until 7) pen.text(DAYS[i].take(1), PAD + i * (cw + gap) + cw / 2f, top, 30f, ink.mute, false, Paint.Align.CENTER)
        val ratio = if (rows == 1) (if (lay.story) 3.0f else 1.5f) else (if (lay.story) 1.15f else 0.8f)
        val ch = min(cw * ratio, (520f + lay.mid - gap * (rows - 1)) / rows)
        sm.dailyKm.forEachIndexed { i, v ->
            val pos = offset + i
            val x = PAD + (pos % 7) * (cw + gap); val y = top + 24f + (pos / 7) * (ch + gap)
            val col = when { v <= 0 -> ink.empty; v < 6.5 -> Color.parseColor("#5A2A0B"); v < 10 -> Color.parseColor("#A8470A"); v < 15 -> EM; else -> EM2 }
            pen.rect(RectF(x, y, x + cw, y + ch), col, 14f)
            if (rows == 1) { if (v > 0) pen.text(km1(v), x + cw / 2f, y + ch / 2f + 14f, 40f, Color.WHITE, true, Paint.Align.CENTER) }
            else pen.text("${sm.start.dayOfMonth + i}", x + 12f, y + 34f, 26f, withAlpha(Color.WHITE, if (v > 0) 200 else 110))
        }
        threeCols(pen, 1110f + lay.fs, coreStats(sm), 58f, ink.ink, ink.mute)
    }

    // 6. Kaca: panel kaca di bagian bawah; pada latar solid, visual periode digambar samar di atasnya.
    private fun glass(pen: Pen, sm: PeriodSummary, bg: ShareBg, ink: Ink, day: ShareDayExtra?, brand: ShareBrand, lay: Lay) {
        header(pen, sm, brand, ink.mute, EM2, ink.mute, lay)
        val panelTop = 800f + lay.fs
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        if (bg == ShareBg.SOLID) {
            val box = RectF(PAD, 260f + lay.hs, W - PAD, panelTop - 40f)
            when (sm.period) {
                SharePeriod.DAY -> ShareCardRenderer.drawDay(pen.c, p, box, ink, day)
                SharePeriod.WEEK -> ShareCardRenderer.drawWeek(pen.c, p, box, ink, sm)
                SharePeriod.MONTH -> ShareCardRenderer.drawMonth(pen.c, p, box, ink, sm)
            }
        }
        val panel = RectF(56f, panelTop, 1024f, panelTop + 496f)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG); fill.color = Color.argb(if (bg == ShareBg.SOLID) 26 else 52, 255, 255, 255)
        pen.c.drawRoundRect(panel, 64f, 64f, fill)
        val edge = Paint(Paint.ANTI_ALIAS_FLAG); edge.style = Paint.Style.STROKE; edge.strokeWidth = 3f; edge.color = Color.argb(100, 255, 255, 255)
        pen.c.drawRoundRect(panel, 64f, 64f, edge)
        val t = heroText(sm)
        val hs = pen.fit(t, 200f, 100f, 430f)
        pen.text(t, 104f, panelTop + 230f, hs, ink.ink, true)
        pen.text("km", 104f + pen.width(t, hs, true) + 18f, panelTop + 230f, 56f, ink.mute)
        val core = coreStats(sm)
        pen.text(core[0].value, 976f, panelTop + 130f, 54f, ink.ink, true, Paint.Align.RIGHT)
        pen.text("${core[1].value} /km", 976f, panelTop + 208f, 54f, ink.ink, true, Paint.Align.RIGHT)
        pen.text("+${sm.gain} m", 976f, panelTop + 286f, 54f, ink.ink, true, Paint.Align.RIGHT)
        val e = extraStats(sm, day)
        pen.text("${e[0].value} ${e[0].unit}  ·  ${e[1].value} ${e[1].unit}".trim(), 104f, panelTop + 410f, 40f, ink.mute)
    }

    // 7. Kurva: garis dengan area; mingguan/bulanan = jarak per hari, harian = pace per km (lebih cepat = lebih tinggi).
    private fun curve(pen: Pen, sm: PeriodSummary, ink: Ink, day: ShareDayExtra?, brand: ShareBrand, lay: Lay) {
        header(pen, sm, brand, ink.mute, EM2, ink.mute, lay)
        hero(pen, sm, PAD - 6f, lay.hs + 196f + 40f + 150f * 0.82f, 150f, ink.ink, ink.mute)
        val isDay = sm.period == SharePeriod.DAY
        val vals: List<Double> = if (isDay) day?.splitPace.orEmpty() else sm.dailyKm
        if (vals.size >= 2) {
            val area = RectF(PAD + 20f, 520f + lay.hs, W - PAD - 20f, 1000f + lay.fs)
            val base = area.bottom
            val top = area.top + 50f
            val hi = vals.maxOrNull() ?: 1.0; val lo = vals.minOrNull() ?: 0.0
            val span = max(0.25, hi - lo)
            fun px(i: Int) = area.left + i * (area.width() / (vals.size - 1))
            fun py(v: Double): Float = if (isDay) top + ((v - lo) / span).toFloat() * (base - top - 40f)
            else base - (v / max(1.0, hi)).toFloat() * (base - top)
            val line = Path(); val fill = Path()
            vals.forEachIndexed { i, v -> if (i == 0) { line.moveTo(px(i), py(v)); fill.moveTo(px(i), base); fill.lineTo(px(i), py(v)) } else { line.lineTo(px(i), py(v)); fill.lineTo(px(i), py(v)) } }
            fill.lineTo(px(vals.size - 1), base); fill.close()
            val pf = Paint(Paint.ANTI_ALIAS_FLAG); pf.color = withAlpha(EM, 60); pen.c.drawPath(fill, pf)
            val pl = Paint(Paint.ANTI_ALIAS_FLAG); pl.style = Paint.Style.STROKE; pl.strokeWidth = 9f; pl.color = EM2; pl.strokeJoin = Paint.Join.ROUND; pl.strokeCap = Paint.Cap.ROUND
            if (ink.shadow) pl.setShadowLayer(12f, 0f, 3f, Color.argb(130, 0, 0, 0))
            pen.c.drawPath(line, pl)
            pen.line(area.left - 20f, base, area.right + 20f, base, ink.line, 2f)
            val dotR = if (vals.size > 12) 7f else 13f
            var bestI = 0
            vals.forEachIndexed { i, v ->
                if (if (isDay) v < vals[bestI] else v > vals[bestI]) bestI = i
                pen.circle(px(i), py(v), dotR, if (v > 0) EM2 else ink.empty)
            }
            pen.text(if (isDay) pace(vals[bestI]) else km1(vals[bestI]), px(bestI).coerceIn(area.left + 40f, area.right - 40f), py(vals[bestI]) - 28f, 38f, ink.ink, true, Paint.Align.CENTER)
            val step = if (vals.size > 12) 7 else if (isDay && vals.size > 8) 2 else 1
            vals.indices.forEach { i ->
                val show = if (vals.size > 12) (i % step == 0) else (i % step == 0)
                if (show) pen.text(if (isDay) "${i + 1}" else if (sm.period == SharePeriod.WEEK) DAYS[i] else "${sm.start.dayOfMonth + i}", px(i), base + 44f, 30f, ink.mute, false, Paint.Align.CENTER)
            }
            if (isDay) pen.text(Lang.tr("Pace per km"), area.left - 20f, area.top + 6f, 32f, ink.mute)
        }
        threeCols(pen, 1120f + lay.fs, coreStats(sm), 58f, ink.ink, ink.mute)
    }

    // 8. Banding: selisih terhadap periode sebelumnya (atau rata-rata 28 hari untuk harian).
    private fun compare(pen: Pen, sm: PeriodSummary, ink: Ink, brand: ShareBrand, ex: ShareExtras, lay: Lay) {
        header(pen, sm, brand, ink.mute, EM2, ink.mute, lay)
        hero(pen, sm, PAD - 6f, lay.hs + 196f + 40f + 150f * 0.82f, 150f, ink.ink, ink.mute)
        val prev = ex.prev ?: return
        val pct = if (prev.km > 0) ((sm.km - prev.km) / prev.km * 100).roundToInt() else 0
        val up = pct >= 0
        val chipCol = if (up) GREEN else DOWN
        val chip = "${abs(pct)}% dari ${ex.prevLabel}"
        val cw = pen.width(chip, 40f) + 100f
        val h0 = lay.hs; val barY = lay.hs + lay.mid * 0.4f
        val chipBox = RectF(PAD, 400f + h0, PAD + cw, 484f + h0)
        pen.rect(chipBox, withAlpha(chipCol, 55), 42f)
        val tri = Path()
        if (up) { tri.moveTo(PAD + 36f, 456f + h0); tri.lineTo(PAD + 64f, 456f + h0); tri.lineTo(PAD + 50f, 428f + h0) } else { tri.moveTo(PAD + 36f, 428f + h0); tri.lineTo(PAD + 64f, 428f + h0); tri.lineTo(PAD + 50f, 456f + h0) }
        tri.close()
        val pt = Paint(Paint.ANTI_ALIAS_FLAG); pt.color = chipCol; pen.c.drawPath(tri, pt)
        pen.text(chip, PAD + 84f, 456f + h0, 40f, chipCol)
        val now = when (sm.period) { SharePeriod.DAY -> "Lari ini"; SharePeriod.WEEK -> "Minggu ini"; SharePeriod.MONTH -> "Bulan ini" }
        val mx = max(sm.km, prev.km).coerceAtLeast(0.1)
        val full = W - 2 * PAD
        val barPrev = if (ink.shadow) withAlpha(Color.WHITE, 90) else Color.parseColor("#3A3A3E")
        pen.text(Lang.tr(now), PAD, 590f + barY, 36f, ink.mute); pen.text("${km1(sm.km)} km", W - PAD, 590f + barY, 36f, ink.ink, false, Paint.Align.RIGHT)
        pen.rect(RectF(PAD, 612f + barY, PAD + full * (sm.km / mx).toFloat(), 668f + barY), EM, 28f)
        pen.text(ex.prevLabel.replaceFirstChar { it.uppercase() }, PAD, 740f + barY, 36f, ink.mute); pen.text("${km1(prev.km)} km", W - PAD, 740f + barY, 36f, ink.ink, false, Paint.Align.RIGHT)
        pen.rect(RectF(PAD, 762f + barY, PAD + full * (prev.km / mx).toFloat(), 818f + barY), barPrev, 28f)
        pen.line(PAD, 880f + lay.fs, W - PAD, 880f + lay.fs, ink.line, 2f)
        val dDur = sm.durationSec - prev.durationSec
        val pc = sm.avgPace; val pp = prev.avgPace
        val dPace = if (pc != null && pp != null) ((pc - pp) * 60).roundToInt() else null
        val dGain = sm.gain - prev.gain
        fun sgn(n: Int) = if (n >= 0) "+" else "−"
        val rows = listOf(
            Triple("Durasi", "${sgn(dDur)}${duration(abs(dDur))}", ink.ink),
            Triple("Pace", if (dPace == null) "-" else "${sgn(dPace)}${abs(dPace)} dtk/km", if (dPace == null) ink.ink else if (dPace <= 0) GREEN else DOWN),
            Triple("Elevasi", "${sgn(dGain)}${abs(dGain)} m", ink.ink),
        )
        rows.forEachIndexed { i, (l, v, col) ->
            val y = 960f + lay.fs + i * 96f
            pen.text(Lang.tr(l), PAD, y, 44f, ink.mute); pen.text(v, W - PAD, y, 52f, col, true, Paint.Align.RIGHT)
        }
    }

    // 9. Ubin: enam ubin statistik; ubin jarak disorot.
    private fun tiles(pen: Pen, sm: PeriodSummary, bg: ShareBg, ink: Ink, day: ShareDayExtra?, brand: ShareBrand, lay: Lay) {
        header(pen, sm, brand, ink.mute, EM2, ink.mute, lay)
        val core = coreStats(sm); val ex = extraStats(sm, day)
        val all = listOf(Stat(Lang.tr("Jarak"), heroText(sm), "km"), core[0], core[1], core[2], ex[0], ex[1])
        val gap = 24f
        val tw = (W - 2 * PAD - gap) / 2f
        val th = 300f + lay.mid / 3f
        val tileFill = if (bg == ShareBg.SOLID) INK_DARK else withAlpha(Color.WHITE, 46)
        all.forEachIndexed { i, s ->
            val x = PAD + (i % 2) * (tw + gap); val y = 270f + lay.hs + (i / 2) * (th + gap)
            val hi = i == 0
            pen.rect(RectF(x, y, x + tw, y + th), if (hi) EM else tileFill, 48f)
            val lc = if (hi) DK else ink.mute; val vc = if (hi) DK else ink.ink
            pen.text(s.label, x + 44f, y + 70f, 38f, lc)
            val vs = pen.fit(s.value, 120f, 48f, tw - 88f - (if (s.unit.isEmpty()) 0f else 90f))
            val vy = y + 200f + (th - 300f) * 0.5f
            pen.text(s.value, x + 44f, vy, vs, vc, true)
            if (s.unit.isNotEmpty()) pen.text(s.unit, x + 44f + pen.width(s.value, vs, true) + 12f, vy, 44f, lc)
        }
    }

    // 10. Strip: pil lebar 1080 x 420. Solid = pil gelap, Foto = pil berisi foto, Transparan = teks saja.
    private fun strip(sm: PeriodSummary, bg: ShareBg, photo: Bitmap?, brand: ShareBrand): Bitmap {
        val out = Bitmap.createBitmap(ShareSize.STRIP.w, ShareSize.STRIP.h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val ink = inkFor(bg)
        val pen = Pen(c, ink)
        val pill = RectF(30f, 30f, 1050f, 390f)
        when (bg) {
            ShareBg.SOLID -> pen.rect(pill, DK, 180f)
            ShareBg.PHOTO -> {
                val clip = Path(); clip.addRoundRect(pill, 180f, 180f, Path.Direction.CW)
                c.save(); c.clipPath(clip); c.translate(pill.left, pill.top)
                if (photo != null) ShareCardRenderer.drawCover(c, photo, 1020, 360) else c.drawColor(Color.parseColor("#2A3A33"))
                c.drawColor(Color.argb(115, 0, 0, 0))
                c.restore()
            }
            ShareBg.CLEAR -> Unit
        }
        val icon = brand.icon
        val ib = RectF(96f, 135f, 246f, 285f)
        if (icon != null) {
            val path = Path(); path.addRoundRect(ib, 36f, 36f, Path.Direction.CW)
            c.save(); c.clipPath(path); c.drawBitmap(icon, null, ib, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)); c.restore()
        } else pen.circle(ib.centerX(), ib.centerY(), 46f, EM)
        val x = 286f
        pen.text("${brand.title.take(ShareBrand.MAX_LEN)}  ·  ${tag(sm.period).lowercase().replaceFirstChar { it.uppercase() }}", x, 118f, 38f, ink.mute)
        val t = heroText(sm)
        val hs = pen.fit(t, 150f, 80f, 520f)
        pen.text(t, x, 250f, hs, ink.ink, true)
        pen.text("km", x + pen.width(t, hs, true) + 18f, 250f, 56f, ink.mute)
        val core = coreStats(sm)
        pen.text("${core[0].value}  ·  ${core[1].value} /km  ·  +${sm.gain} m", x, 330f, 46f, ink.ink)
        return out
    }
}
