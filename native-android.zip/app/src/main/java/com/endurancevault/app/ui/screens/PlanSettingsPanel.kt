package com.endurancevault.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.endurancevault.app.domain.Phases
import com.endurancevault.app.domain.PbConversion
import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.domain.PlanOutcome
import java.time.LocalDate

/** Layout pengaturan rencana (padanan tampilan web): kartu ringkasan gelap + grafik bar, tab Race/Volume/Week/Target/Strength. */

internal val PLAN_SUB_TABS = listOf("Race", "Volume", "Week", "Target", "Strength")

internal val PB_CYCLE_OPTIONS = listOf(
    "2" to "2:1 · 2 weeks up, 1 recovery week",
    "3" to "3:1 · 3 weeks up, 1 recovery week",
    "4" to "4:1 · 4 weeks up, 1 recovery week",
)

internal val PB_FOCUS_OPTIONS = listOf(
    "mix" to "Mixed focus",
    "thr" to "Threshold focus",
    "vo2" to "VO₂max focus",
    "vol" to "Volume focus",
)

private val HeroTop = Color(0xFF1B1D22)
private val HeroBottom = Color(0xFF101114)
private val HeroGlow = Color(0xAAB8601E)
private val BarBuild = Color(0xFFE2E4E8)
private val BarRecovery = Color(0xFF8A8D93)
private val BarTaper = Color(0xFFFFB27A)
private val Mono = FontFamily.Monospace

/** Panel induk collapsible: header "Plan settings" + isi. */
@Composable
internal fun PlanSettingsPanel(
    open: Boolean,
    onToggle: () -> Unit,
    content: @Composable ColumnScope.() -> Unit,
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(Modifier.padding(10.dp)) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant),
            ) {
                Column {
                    Row(
                        Modifier.fillMaxWidth().clickable { onToggle() }.padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        PlanTargetIcon()
                        Text("Plan settings", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Icon(
                            if (open) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                            contentDescription = if (open) "Tutup" else "Buka",
                        )
                    }
                    if (open) {
                        Box(Modifier.fillMaxWidth().height(0.8.dp).background(MaterialTheme.colorScheme.outlineVariant))
                        Column(Modifier.padding(horizontal = 12.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
                    }
                }
            }
        }
    }
}

@Composable
private fun PlanTargetIcon() {
    val primary = MaterialTheme.colorScheme.primary
    Box(
        Modifier.size(36.dp).clip(CircleShape)
            .background(Brush.linearGradient(listOf(Color(0xFFFF9B2E), Color(0xFFE8500A)))),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(20.dp)) {
            val c = Offset(size.width / 2, size.height / 2)
            val sw = 1.8.dp.toPx()
            drawCircle(Color.White, radius = size.width / 2 - sw / 2, center = c, style = androidx.compose.ui.graphics.drawscope.Stroke(sw))
            drawCircle(Color.White, radius = size.width / 4, center = c, style = androidx.compose.ui.graphics.drawscope.Stroke(sw))
            drawCircle(Color.White, radius = size.width / 12, center = c)
        }
    }
}

/** Kartu ringkasan gelap: chip jenis, panjang rencana, total volume, grafik bar mingguan. */
@Composable
internal fun PlanHeroCard(
    outcome: PlanOutcome?,
    typeLabel: String,
    days: Int,
    base: String,
    peak: String,
) {
    val ok = outcome as? PlanOutcome.Ok
    val weeks = ok?.weeks.orEmpty()
    val totalKm = weeks.sumOf { it.km }
    val shape = RoundedCornerShape(26.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape)
            .background(Brush.verticalGradient(listOf(HeroTop, HeroBottom)))
            .drawBehind {
                drawRect(Brush.radialGradient(listOf(HeroGlow, Color.Transparent), center = Offset(size.width, 0f), radius = size.width * 0.8f))
            }
            .padding(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Surface(shape = RoundedCornerShape(50), color = Color(0xFF3A3D44)) {
                Text(typeLabel.uppercase(), color = Color(0xFFE6E8EC), fontFamily = Mono, fontSize = 11.sp, letterSpacing = 1.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp))
            }
            Surface(shape = RoundedCornerShape(50), color = Color.Transparent, border = BorderStroke(1.dp, Color(0xFF6A6D74))) {
                Text("$days DAYS / WK", color = Color(0xFFE6E8EC), fontFamily = Mono, fontSize = 11.sp, letterSpacing = 1.5.sp, maxLines = 1, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp))
            }
            Text(
                "$base → $peak km/wk", color = Color(0xFFD7D9DE), fontFamily = Mono, fontSize = 12.sp, maxLines = 1,
                modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.End,
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(26.dp)) {
            HeroStat("PLAN LENGTH", if (ok != null) weeks.size.toString() else "–", "weeks")
            HeroStat("TOTAL VOLUME", if (ok != null) Math.round(totalKm).toString() else "–", "km")
        }
        if (weeks.isNotEmpty()) {
            val maxKm = weeks.maxOf { it.km }.coerceAtLeast(1.0)
            Canvas(Modifier.fillMaxWidth().height(86.dp)) {
                val n = weeks.size
                val gap = (if (n > 24) 2.dp else 5.dp).toPx()
                val bw = ((size.width - gap * (n - 1)) / n).coerceAtLeast(1f)
                val corner = CornerRadius(3.dp.toPx())
                weeks.forEachIndexed { idx, w ->
                    val h = (size.height * (w.km / maxKm)).toFloat().coerceAtLeast(6.dp.toPx())
                    val color = when {
                        w.phase == Phases.TAPER || w.race -> BarTaper
                        w.cut || w.rec -> BarRecovery
                        else -> BarBuild
                    }
                    drawRoundRect(color, topLeft = Offset(idx * (bw + gap), size.height - h), size = Size(bw, h), cornerRadius = corner)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
                LegendDot(BarBuild, "Build"); LegendDot(BarRecovery, "Recovery week"); LegendDot(BarTaper, "Taper")
            }
        } else {
            Text(
                (outcome as? PlanOutcome.Err)?.message ?: "Rencana belum tersedia",
                color = Color(0xFFB8BBC2), fontSize = 12.sp,
            )
        }
    }
}

@Composable
private fun HeroStat(label: String, value: String, unit: String) {
    Column {
        Text(label, color = Color(0xFFB8BBC2), fontFamily = Mono, fontSize = 11.sp, letterSpacing = 2.sp)
        Text(
            buildAnnotatedString {
                withStyle(SpanStyle(fontSize = 36.sp, fontWeight = FontWeight.Bold, color = Color.White)) { append(value) }
                withStyle(SpanStyle(fontSize = 17.sp, fontWeight = FontWeight.Medium, color = Color(0xFFE6E8EC))) { append(" $unit") }
            },
        )
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(Modifier.size(11.dp).clip(RoundedCornerShape(3.dp)).background(color))
        Text(label, color = Color(0xFFD7D9DE), fontFamily = Mono, fontSize = 12.sp)
    }
}

/** Pil pilihan bergaya oranye saat aktif, garis tipis saat tidak. */
@Composable
internal fun PlanPill(label: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.height(38.dp).clip(RoundedCornerShape(50)).clickable { onClick() },
        shape = RoundedCornerShape(50),
        color = if (selected) MaterialTheme.colorScheme.primary else Color.Transparent,
        border = if (selected) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        shadowElevation = if (selected) 3.dp else 0.dp,
    ) {
        Box(Modifier.padding(horizontal = 18.dp), contentAlignment = Alignment.Center) {
            Text(
                label,
                color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                fontSize = 15.sp, maxLines = 1,
            )
        }
    }
}

/** Baris tab "PLAN  Race  Volume  Week  Target  Strength" yang bisa digeser. */
@Composable
internal fun PlanSubTabs(selected: String, onSelect: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text("PLAN", color = MaterialTheme.colorScheme.onSurfaceVariant, fontFamily = Mono, fontSize = 11.sp, letterSpacing = 2.sp, modifier = Modifier.padding(end = 2.dp))
        PLAN_SUB_TABS.forEach { PlanPill(it, selected == it, { onSelect(it) }) }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun PlanPillFlow(content: @Composable () -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { content() }
}

/** Dropdown berlabel ala web: label kapital kecil di atas, kolom nilai bergaya mono. */
@Composable
internal fun PlanDropdown(label: String, valueLabel: String, options: List<Pair<String, String>>, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label.uppercase(), color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, letterSpacing = 1.2.sp)
        Box {
            Surface(
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { expanded = true },
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            ) {
                Row(Modifier.padding(horizontal = 16.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(valueLabel, fontFamily = Mono, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    Icon(Icons.Filled.KeyboardArrowDown, contentDescription = null)
                }
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                options.forEach { (k, v) ->
                    DropdownMenuItem(text = { Text(v, fontFamily = Mono, fontSize = 14.sp) }, onClick = { expanded = false; onSelect(k) })
                }
            }
        }
    }
}

/** Baris aksi bawah: "Got a race?" dan "Recalculate plan  N weeks • X km". */
@Composable
internal fun PlanActionRow(weeks: Int?, km: Double?, onRace: () -> Unit, onRecalc: () -> Unit, showRace: Boolean) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        if (showRace) {
            Surface(
                modifier = Modifier.height(46.dp).clip(RoundedCornerShape(50)).clickable { onRace() },
                shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.primary, shadowElevation = 3.dp,
            ) {
                Box(Modifier.padding(horizontal = 18.dp), contentAlignment = Alignment.Center) {
                    Text("Got a race?", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
                }
            }
        }
        Box(
            Modifier.weight(1f).height(46.dp).clip(RoundedCornerShape(50))
                .background(Brush.horizontalGradient(listOf(Color(0xFFFF9B2E), Color(0xFFE8500A))))
                .clickable { onRecalc() }.padding(horizontal = 14.dp),
            contentAlignment = Alignment.Center,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Recalculate plan", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
                if (weeks != null && km != null) {
                    Text("$weeks weeks • ${Math.round(km)} km", color = Color(0xFFFFE6D0), fontFamily = Mono, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

/** Info rencana hasil konversi PB + tombol kembali (pbConvSync/pbConvUndo di web). */
@Composable
internal fun PlanConvInfo(wk: Int, onUndo: () -> Unit) {
    Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant, border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                "Rencana lomba dari Performance Build: $wk minggu pertama dihitung sebagai base. Build berlanjut dari minggu ke-${wk + 1}.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            TextButton(onClick = onUndo) { Text("Kembali ke Performance Build") }
        }
    }
}

/** Dialog "Got a race?" (pbRaceForm di web): ubah Performance Build menjadi rencana lomba. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun PlanPbRaceDialog(settings: PlanSettings, onDismiss: () -> Unit, onApply: (PlanSettings) -> Unit) {
    val st = remember(settings) { PbConversion.state(settings) }
    var rt by remember { mutableStateOf("hm") }
    var date by remember { mutableStateOf("") }
    var goal by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var km by remember { mutableStateOf(fmtKmUi(PbConversion.defaultKm("ultra"))) }
    var gain by remember { mutableStateOf("") }
    var peak by remember { mutableStateOf(maxOf(PbConversion.defaultPeak("hm"), st.base).toString()) }
    var err by remember { mutableStateOf<String?>(null) }
    val trail = rt == "ultra" || rt == "ultrar"
    val labels = mapOf("5k" to "5K", "10k" to "10K", "hm" to "Half marathon", "fm" to "Marathon", "ultra" to "Trail", "ultrar" to "Ultra road")
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Got a race?") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    if (st.wk > 0) "${st.wk} minggu Performance Build sudah berjalan (sejak ${settings.start}). Semuanya dihitung sebagai base, build lanjut dari minggu ini dengan volume sekarang (±${st.base} km/minggu)."
                    else "Rencana baru mulai minggu ini, jadi belum ada minggu yang dihitung sebagai base.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    PbConversion.RACE_TYPES.forEach { k ->
                        PlanPill(labels.getValue(k), rt == k, {
                            rt = k
                            peak = maxOf(PbConversion.defaultPeak(k), st.base).toString()
                            if (k == "ultra" || k == "ultrar") { if (km.isBlank() || (km.replace(',', '.').toDoubleOrNull() ?: 0.0) <= 0.0) km = fmtKmUi(PbConversion.defaultKm(k)) }
                        })
                    }
                }
                OutlinedTextField(name, { name = it }, label = { Text("Nama lomba") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(date, { date = it }, label = { Text("Tanggal lomba (yyyy-MM-dd)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(goal, { goal = it }, label = { Text("Target waktu (h:mm:ss, opsional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                if (trail) {
                    OutlinedTextField(km, { km = it }, label = { Text("Jarak lomba (km)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(gain, { gain = it }, label = { Text("Elevation gain lomba (m)") }, supportingText = { Text("Kosong = otomatis 2.400 m") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
                OutlinedTextField(peak, { peak = it }, label = { Text("Km mingguan puncak") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                err?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val r = PbConversion.build(settings, rt, date, goal, name, km, gain, peak, st.wk, st.base)
                if (r.error != null) err = r.error else r.settings?.let(onApply)
            }) { Text("Buat rencana lomba") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
    )
}
