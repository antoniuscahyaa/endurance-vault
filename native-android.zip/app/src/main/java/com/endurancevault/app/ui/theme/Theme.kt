package com.endurancevault.app.ui.theme

import android.app.Activity
import android.content.Context
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat

// Tema flat: latar putih, semua kartu abu muda, aksen orange. Hanya kartu greeting memakai orange transparan (cardTint).
// Tanpa gradien dan tanpa shadow; pemisah visual hanya lewat garis tipis (outlineVariant).

// Aksen. Ember dan Fire sengaja satu warna (flat) agar kode lama yang memakainya tidak perlu diubah.
val Ember = Color(0xFFEA5F0A)
val Fire = Color(0xFFEA5F0A)
val EmberDark = Color(0xFFFF8A26)

// Palet netral
private val LightBg = Color(0xFFFFFFFF)
private val LightCard = Color(0xFFF4F4F5)
private val LightInk = Color(0xFF1C1C1E)
private val LightMute = Color(0xFF6E6E73)
private val LightLine = Color(0xFFE8E8EA)
private val LightLineStrong = Color(0xFFD4D4D8)
private val LightOrangeText = Color(0xFFC2410C)

private val DarkBg = Color(0xFF111112)
private val DarkCard = Color(0xFF1C1C1E)
private val DarkInk = Color(0xFFF5F5F7)
private val DarkMute = Color(0xFF9A9AA0)
private val DarkLine = Color(0xFF2C2C2F)
private val DarkLineStrong = Color(0xFF3A3A3E)

private val Dark = darkColorScheme(
    primary = EmberDark, onPrimary = Color(0xFF1A1005),
    primaryContainer = Color(0xFF321F11), onPrimaryContainer = Color(0xFFFFA45C),
    secondary = DarkMute, onSecondary = DarkBg,
    secondaryContainer = Color(0xFF321F11), onSecondaryContainer = Color(0xFFFFA45C),
    tertiary = Color(0xFF4CC38A), onTertiary = Color(0xFF062016),
    background = DarkBg, onBackground = DarkInk,
    surface = DarkBg, onSurface = DarkInk,
    surfaceVariant = DarkCard, onSurfaceVariant = DarkMute,
    surfaceTint = Color.Transparent,
    surfaceContainerLowest = DarkBg, surfaceContainerLow = DarkBg,
    surfaceContainer = DarkCard, surfaceContainerHigh = DarkCard, surfaceContainerHighest = DarkCard,
    outline = DarkLineStrong, outlineVariant = DarkLine,
    error = Color(0xFFF07070),
)

private val Light = lightColorScheme(
    primary = Ember, onPrimary = Color.White,
    primaryContainer = Color(0xFFFEF2E7), onPrimaryContainer = LightOrangeText,
    secondary = LightMute, onSecondary = Color.White,
    secondaryContainer = Color(0xFFFEF2E7), onSecondaryContainer = LightOrangeText,
    tertiary = Color(0xFF2E9E5B), onTertiary = Color.White,
    background = LightBg, onBackground = LightInk,
    surface = LightBg, onSurface = LightInk,
    surfaceVariant = LightCard, onSurfaceVariant = LightMute,
    surfaceTint = Color.Transparent,
    surfaceContainerLowest = LightBg, surfaceContainerLow = LightBg,
    surfaceContainer = LightCard, surfaceContainerHigh = LightBg, surfaceContainerHighest = LightCard,
    outline = LightLineStrong, outlineVariant = LightLine,
    error = Color(0xFFD64545),
)

/** Kartu orange transparan: aksen 10% (light) atau 14% (dark) di atas latar, hasilnya warna solid. */
val ColorScheme.cardTint: Color
    get() {
        val dark = background.luminance() < 0.5f
        return primary.copy(alpha = if (dark) 0.14f else 0.10f).compositeOver(background)
    }

/** Teks orange di atas cardTint; lebih gelap di light agar kontras cukup. */
val ColorScheme.onCardTint: Color
    get() = if (background.luminance() < 0.5f) Color(0xFFFFA45C) else LightOrangeText

enum class ThemeMode(val key: String, val label: String) {
    SYSTEM("system", "Ikuti sistem"), LIGHT("light", "Light"), DARK("dark", "Dark");
    companion object { fun from(k: String?) = values().firstOrNull { it.key == k } ?: SYSTEM }
}

/** Pilihan tema yang disimpan di SharedPreferences dan dibaca langsung oleh Compose. */
object ThemePrefs {
    private const val FILE = "ev_theme"
    private const val KEY = "mode"
    var mode by mutableStateOf(ThemeMode.SYSTEM)
        private set

    fun load(ctx: Context) {
        mode = ThemeMode.from(ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY, null))
    }

    fun set(ctx: Context, m: ThemeMode) {
        mode = m
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString(KEY, m.key).apply()
    }
}

private val EvShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(26.dp),
    extraLarge = RoundedCornerShape(30.dp),
)

private val EvTypography = Typography(
    headlineLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.ExtraBold, fontSize = 30.sp, lineHeight = 36.sp, letterSpacing = (-0.8).sp),
    headlineMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.ExtraBold, fontSize = 25.sp, lineHeight = 31.sp, letterSpacing = (-0.5).sp),
    headlineSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 21.sp, lineHeight = 27.sp, letterSpacing = (-0.3).sp),
    titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 19.sp, lineHeight = 25.sp, letterSpacing = (-0.2).sp),
    titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp),
    titleSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 15.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 17.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, letterSpacing = 0.2.sp),
    labelMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 11.sp, letterSpacing = 0.35.sp),
    labelSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 10.sp, letterSpacing = 0.8.sp),
)

@Composable
fun EnduranceVaultTheme(content: @Composable () -> Unit) {
    val dark = when (ThemePrefs.mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !dark
                isAppearanceLightNavigationBars = !dark
            }
        }
    }
    MaterialTheme(
        colorScheme = if (dark) Dark else Light,
        typography = EvTypography,
        shapes = EvShapes,
        content = content,
    )
}
