package com.endurancevault.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Typography
import androidx.compose.foundation.shape.RoundedCornerShape

// Native translation of the original EnduranceVault default skin (ev-skin.css).
// Soft Clay remains a separate legacy/custom skin and is not the default.
val Ember = Color(0xFFFA7A0C)
val Fire = Color(0xFFF2500A)
val Ink = Color(0xFF0B0C0F)
val Panel = Color(0xFF1A1C21)
val PanelHi = Color(0xFF23262C)
val EvLightBg = Color(0xFFE3E5E9)
val EvLightSurface = Color(0xFFF5F6F7)
val EvLightPanel = Color(0xFFE9EBEE)
val EvLightInk = Color(0xFF16181C)

private val Dark = darkColorScheme(
    primary = Color(0xFFFA8A1E), onPrimary = Color.White,
    secondary = Color(0xFF9AA1AD), onSecondary = Color(0xFF111318),
    tertiary = Color(0xFF5CCB93), onTertiary = Color(0xFF062016),
    background = Ink, onBackground = Color(0xFFF4F5F7),
    surface = Panel, onSurface = Color(0xFFF4F5F7),
    surfaceVariant = PanelHi, onSurfaceVariant = Color(0xFF9EA2AB),
    outline = Color(0xFF3A3E46), outlineVariant = Color(0xFF2E3239),
    error = Color(0xFFF07070),
)

private val Light = lightColorScheme(
    primary = Color(0xFFC44A07), onPrimary = Color.White,
    secondary = Color(0xFF6C7480), onSecondary = Color.White,
    tertiary = Color(0xFF3C8A64), onTertiary = Color.White,
    background = EvLightBg, onBackground = EvLightInk,
    surface = EvLightSurface, onSurface = EvLightInk,
    surfaceVariant = EvLightPanel, onSurfaceVariant = Color(0xFF5E636C),
    outline = Color(0xFFB9BDC5), outlineVariant = Color(0xFFC6C9D0),
    error = Color(0xFFD64545),
)

private val EvShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(26.dp),
)

private val EvTypography = Typography(
    headlineLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 30.sp, lineHeight = 36.sp, letterSpacing = (-0.6).sp),
    headlineMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 25.sp, lineHeight = 31.sp, letterSpacing = (-0.4).sp),
    headlineSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 21.sp, lineHeight = 27.sp),
    titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 19.sp, lineHeight = 25.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp),
    titleSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 15.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 17.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, letterSpacing = 0.2.sp),
    labelMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 11.sp, letterSpacing = 0.35.sp),
    labelSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 10.sp, letterSpacing = 0.6.sp),
)

@Composable
fun EnduranceVaultTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    MaterialTheme(
        colorScheme = if (dark) Dark else Light,
        typography = EvTypography,
        shapes = EvShapes,
        content = content,
    )
}
