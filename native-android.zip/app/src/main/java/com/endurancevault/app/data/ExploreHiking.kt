package com.endurancevault.app.data

import android.content.Context
import com.endurancevault.app.domain.ExPoi
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.LocalDate
import java.util.Locale
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * Puncak, sumber air, dan pondok dari OpenStreetMap lewat Overpass API (overpass-api.de). Hasil per kotak (dibulatkan 0,01°)
 * disimpan di cacheDir/osm-poi selama 30 hari; bila jaringan gagal, cache basi tetap dipakai.
 */
object ExploreOsm {
    private const val USER_AGENT = "EnduranceVault/0.5.82 (Android; personal fitness route planner)"
    private const val MAX_AGE_MS = 30L * 24 * 60 * 60 * 1000

    suspend fun fetch(context: Context, south: Double, west: Double, north: Double, east: Double): List<ExPoi>? = withContext(Dispatchers.IO) {
        fun r(v: Double, up: Boolean) = (if (up) Math.ceil(v * 100) else floor(v * 100)) / 100.0
        val s = r(south, false); val w = r(west, false); val n = r(north, true); val e = r(east, true)
        val key = String.format(Locale.ROOT, "%.2f_%.2f_%.2f_%.2f", s, w, n, e)
        val file = File(context.applicationContext.cacheDir, "osm-poi/$key.json")
        if (file.isFile && System.currentTimeMillis() - file.lastModified() < MAX_AGE_MS) {
            runCatching { parse(file.readText()) }.getOrNull()?.let { return@withContext it }
        }
        val box = String.format(Locale.ROOT, "%.2f,%.2f,%.2f,%.2f", s, w, n, e)
        val q = "[out:json][timeout:25];(" +
            "node[\"natural\"=\"peak\"][\"name\"]($box);" +
            "node[\"natural\"=\"spring\"]($box);" +
            "node[\"amenity\"=\"drinking_water\"]($box);" +
            "node[\"tourism\"=\"alpine_hut\"]($box);" +
            "node[\"tourism\"=\"wilderness_hut\"]($box);" +
            ");out body 700;"
        var conn: HttpURLConnection? = null
        try {
            conn = (URL("https://overpass-api.de/api/interpreter?data=" + URLEncoder.encode(q, "UTF-8")).openConnection() as HttpURLConnection).apply {
                connectTimeout = 10_000; readTimeout = 30_000
                setRequestProperty("User-Agent", USER_AGENT)
            }
            if (conn.responseCode != 200) return@withContext runCatching { parse(file.readText()) }.getOrNull()
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            val list = parse(text)
            runCatching { file.parentFile?.mkdirs(); file.writeText(text) }
            list
        } catch (_: Exception) {
            runCatching { parse(file.readText()) }.getOrNull()
        } finally {
            conn?.disconnect()
        }
    }

    private fun parse(text: String): List<ExPoi> {
        val arr: JSONArray = JSONObject(text).optJSONArray("elements") ?: return emptyList()
        val out = ArrayList<ExPoi>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val tags = o.optJSONObject("tags") ?: continue
            val kind = when {
                tags.optString("natural") == "peak" -> "peak"
                tags.optString("natural") == "spring" || tags.optString("amenity") == "drinking_water" -> "water"
                tags.optString("tourism") == "alpine_hut" || tags.optString("tourism") == "wilderness_hut" -> "hut"
                else -> continue
            }
            val ele = Regex("-?\\d+([.,]\\d+)?").find(tags.optString("ele"))?.value?.replace(',', '.')?.toDoubleOrNull()
            val rawName = tags.optString("name")
            if (rawName.isBlank() && kind == "peak") continue
            val name = rawName.ifBlank { if (kind == "water") "Sumber air" else "Pondok" }
            out.add(ExPoi(kind, name, ele, o.optDouble("lat"), o.optDouble("lon")))
        }
        return out
    }
}

/** Terbit dan terbenam matahari (persamaan terbit-terbenam NOAA, akurat ±1–2 menit). */
object ExploreSun {
    /** Epoch milidetik (terbit, terbenam) pada [date] di lokasi; null di wilayah kutub saat matahari tak terbit/terbenam. */
    fun riseSet(lat: Double, lon: Double, date: LocalDate): Pair<Long, Long>? {
        val n = (date.toEpochDay() + 2440588L - 2451545L).toDouble() // hari sejak J2000 (siang UTC pada tanggal itu)
        val jStar = n - lon / 360.0
        val m = Math.toRadians((357.5291 + 0.98560028 * jStar) % 360.0)
        val c = 1.9148 * sin(m) + 0.02 * sin(2 * m) + 0.0003 * sin(3 * m)
        val lambda = Math.toRadians(((Math.toDegrees(m) + c + 180.0 + 102.9372) % 360.0))
        val transit = 2451545.0 + jStar + 0.0053 * sin(m) - 0.0069 * sin(2 * lambda)
        val sinDec = sin(lambda) * sin(Math.toRadians(23.4397))
        val dec = asin(sinDec)
        val phi = Math.toRadians(lat)
        val cosH = (sin(Math.toRadians(-0.833)) - sin(phi) * sinDec) / (cos(phi) * cos(dec))
        if (cosH < -1.0 || cosH > 1.0) return null
        val h = Math.toDegrees(acos(cosH))
        fun ms(j: Double) = ((j - 2440587.5) * 86_400_000.0).toLong()
        return ms(transit - h / 360.0) to ms(transit + h / 360.0)
    }
}

/** Prakiraan per jam Open-Meteo pada ketinggian tertentu (parameter `elevation` menyesuaikan suhu dengan ketinggian puncak). */
object ExploreWeather {
    class Hour(val time: String, val tempC: Double, val popPct: Int, val windKmh: Double, val gustKmh: Double)

    /** Jam-jam hari ini dan besok di lokasi (waktu setempat, format `yyyy-MM-ddTHH:00`); null bila gagal. */
    suspend fun fetch(lat: Double, lon: Double, ele: Double): List<Hour>? = withContext(Dispatchers.IO) {
        val url = "https://api.open-meteo.com/v1/forecast?" + String.format(
            Locale.ROOT,
            "latitude=%.4f&longitude=%.4f&elevation=%.0f&hourly=temperature_2m,precipitation_probability,wind_speed_10m,wind_gusts_10m&forecast_days=2&timezone=auto&wind_speed_unit=kmh",
            lat, lon, ele,
        )
        var conn: HttpURLConnection? = null
        try {
            conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8_000; readTimeout = 12_000
                setRequestProperty("User-Agent", "EnduranceVault/0.5.82 (Android; personal fitness route planner)")
            }
            if (conn.responseCode != 200) return@withContext null
            val h = JSONObject(conn.inputStream.bufferedReader().use { it.readText() }).getJSONObject("hourly")
            val t = h.getJSONArray("time"); val temp = h.getJSONArray("temperature_2m")
            val pop = h.getJSONArray("precipitation_probability"); val wind = h.getJSONArray("wind_speed_10m"); val gust = h.getJSONArray("wind_gusts_10m")
            (0 until t.length()).map { i ->
                Hour(t.getString(i), temp.optDouble(i, 0.0), pop.optInt(i, 0), wind.optDouble(i, 0.0), gust.optDouble(i, 0.0))
            }
        } catch (_: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }
}
