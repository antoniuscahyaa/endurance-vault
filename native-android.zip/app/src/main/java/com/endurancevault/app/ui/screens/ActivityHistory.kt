package com.endurancevault.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.ui.UiState
import java.time.LocalDate
import java.time.DayOfWeek
import java.time.temporal.WeekFields
import java.util.Locale

private data class HistoryRun(val activity: ActivityEntity, val kind: String, val group: String)
private fun historyKind(a: ActivityEntity): String = when {
    a.type.equals("bike", true) -> "Sepeda"
    a.srcKey.matches(Regex(""".+~f\d+$""")) -> "Lari bebas"
    else -> "Lari"
}
private fun historyWeek(date: LocalDate): LocalDate = date.with(DayOfWeek.MONDAY)
private fun historyDistance(km: Double) = when { km < 7.0 -> "Pendek (<7 km)"; km <= 12.0 -> "Sedang (7–12 km)"; else -> "Panjang (>12 km)" }
private fun historyDuration(sec: Int): String {
    val h=sec/3600; val m=(sec%3600)/60
    return if(h>0) "${h}j ${m}m" else "${m}m"
}
private fun historyPace(a: ActivityEntity): String =
    if(a.km>0 && a.durationSec>0) "%.2f".format(a.durationSec/60.0/a.km) else "–"

@Composable
fun ActivityHistoryContent(state: UiState, onOpen: (Long) -> Unit) {
    var range by remember { mutableIntStateOf(30) }
    var grouping by remember { mutableStateOf("week") }
    var collapsed by remember { mutableStateOf(setOf<String>()) }
    val today= remember { LocalDate.now() }
    val from=if(range==7) historyWeek(today) else today.minusDays(29)
    val runs=state.activities.mapNotNull { a ->
        val d=runCatching { LocalDate.parse(a.dateIso) }.getOrNull() ?: return@mapNotNull null
        if(d.isBefore(from)||d.isAfter(today)||a.km<=0) return@mapNotNull null
        val kind=historyKind(a)
        val key=when(grouping) {
            "type" -> kind
            "dist" -> historyDistance(a.km)
            else -> historyWeek(d).toString()
        }
        HistoryRun(a,kind,key)
    }.sortedWith(compareByDescending<HistoryRun>{it.activity.dateIso}.thenByDescending{it.activity.id})
    val km=runs.sumOf{it.activity.km}
    val duration=runs.sumOf{it.activity.durationSec}
    val climb=runs.sumOf{it.activity.gain ?: 0}
    val prevFrom=if(range==7) from.minusDays(7) else from.minusDays(30)
    val prevTo=if(range==7) today.minusDays(7) else today.minusDays(30)
    val prevKm=state.activities.sumOf { a ->
        val d=runCatching { LocalDate.parse(a.dateIso) }.getOrNull()
        if(d!=null && !d.isBefore(prevFrom) && !d.isAfter(prevTo) && a.km>0) a.km else 0.0
    }
    val delta=if(prevKm>0) ((km-prevKm)/prevKm*100).toInt() else null
    val grouped=runs.groupBy{it.group}.map { (key,items) ->
        Triple(key,items,items.sumOf{it.activity.km})
    }.sortedBy { if(grouping=="week") -runCatching{LocalDate.parse(it.first)}.getOrDefault(LocalDate.MIN).toEpochDay() else when(it.first){ "Lari bebas"->4; "Lari"->0; "Sepeda"->5; "Pendek (<7 km)"->0; "Sedang (7–12 km)"->1; "Panjang (>12 km)"->2; else->3 } }

    Column(Modifier.fillMaxWidth(), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        EvPanel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    HistoryMetric("JARAK","%.1f km".format(km),delta?.let { "%+d%% vs periode sebelumnya".format(it) } ?: "")
                    HistoryMetric("LARI",runs.count{it.activity.type!="bike"}.toString()+" sesi","")
                }
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    HistoryMetric("WAKTU",historyDuration(duration),"")
                    HistoryMetric("CLIMB","+${climb} m","")
                }
                HistoryBars(state.activities,from,today,range)
                Row(horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                    FilterChip(selected=range==7,onClick={range=7;collapsed=emptySet()},label={Text("Minggu ini")})
                    FilterChip(selected=range==30,onClick={range=30;collapsed=emptySet()},label={Text("30 hari")})
                }
                Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically) {
                    Text("Kelompokkan",style=MaterialTheme.typography.labelSmall)
                    Spacer(Modifier.width(6.dp))
                    listOf("week" to "Minggu","type" to "Jenis","dist" to "Jarak").forEach { (v,l) ->
                        FilterChip(selected=grouping==v,onClick={grouping=v;collapsed=emptySet()},label={Text(l)},modifier=Modifier.weight(1f))
                    }
                }
                TextButton(onClick={collapsed=if(collapsed.size==grouped.size) emptySet() else grouped.map{it.first}.toSet()}, modifier=Modifier.align(androidx.compose.ui.Alignment.End)) {
                    Text(if(collapsed.size==grouped.size) "Buka semua" else "Lipat semua")
                }
            }
        }
        if(runs.isEmpty()) {
            Text("Belum ada aktivitas dalam rentang ini.",color=MaterialTheme.colorScheme.onSurfaceVariant)
        } else grouped.forEach { (key,items,total) ->
            val closed=key in collapsed
            EvPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth().clickable { collapsed=if(closed) collapsed-key else collapsed+key },horizontalArrangement=Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(if(grouping=="week") historyWeekLabel(key) else key,style=MaterialTheme.typography.titleSmall)
                            Text("%.1f km · %d sesi%s".format(total,items.size,if(items.any{it.activity.durationSec>0}) " · %.2f/km".format(items.sumOf{it.activity.durationSec}/60.0/total) else ""),style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(if(closed) "›" else "⌄",color=MaterialTheme.colorScheme.primary)
                    }
                    if(!closed) items.forEach { r ->
                        val a=r.activity
                        HorizontalDivider(color=MaterialTheme.colorScheme.outlineVariant)
                        Column(Modifier.fillMaxWidth().clickable { onOpen(a.id) }.padding(vertical=8.dp),verticalArrangement=Arrangement.spacedBy(5.dp)) {
                            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                Text(a.dateIso,style=MaterialTheme.typography.titleSmall)
                                AssistChip(onClick={onOpen(a.id)},label={Text(r.kind)})
                            }
                            if(a.name.isNotBlank()) Text(a.name,style=MaterialTheme.typography.bodySmall)
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                                HistoryValue("DIST","%.1f km".format(a.km))
                                HistoryValue("PACE",historyPace(a))
                                HistoryValue("TIME",historyDuration(a.durationSec))
                                HistoryValue("HR",a.avgHr?.toString() ?: "–")
                                HistoryValue("ELEV. GAIN","+${a.gain ?: 0} m")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun RowScope.HistoryMetric(label:String,value:String,sub:String) {
    Column(Modifier.weight(1f).padding(2.dp)) {
        Text(label,style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value,style=MaterialTheme.typography.titleLarge)
        if(sub.isNotBlank()) Text(sub,style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
@Composable private fun HistoryValue(label:String,value:String) {
    Column {
        Text(label,style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value,style=MaterialTheme.typography.labelMedium)
    }
}
@Composable private fun HistoryBars(activities:List<ActivityEntity>,from:LocalDate,to:LocalDate,range:Int) {
    val days=(0 until range).map { from.plusDays(it.toLong()) }
    val values=days.map { d -> activities.filter { it.type!="bike" && it.dateIso==d.toString() }.sumOf{it.km} }
    val max=(values.maxOrNull()?:0.0).coerceAtLeast(1.0)
    val accent=MaterialTheme.colorScheme.primary
    val muted=MaterialTheme.colorScheme.outlineVariant
    Canvas(Modifier.fillMaxWidth().height(92.dp)) {
        val slot=size.width/values.size
        values.forEachIndexed { i,v ->
            val h=((v/max).toFloat()*size.height*.92f)
            drawRoundRect(if(v>0) accent else muted.copy(alpha=.3f),Offset(i*slot+slot*.2f,size.height-h),androidx.compose.ui.geometry.Size(slot*.6f,h.coerceAtLeast(2.dp.toPx())),androidx.compose.ui.geometry.CornerRadius(3.dp.toPx()))
        }
    }
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
        Text(from.dayOfMonth.toString()+" "+from.month.name.lowercase().take(3),style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
        Text(to.dayOfMonth.toString()+" "+to.month.name.lowercase().take(3),style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
    }
    Text("Batang menunjukkan jarak lari per hari",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
}
private fun historyWeekLabel(key:String):String {
    val d=runCatching{LocalDate.parse(key)}.getOrNull() ?: return key
    return when(d) {
        LocalDate.now().with(DayOfWeek.MONDAY) -> "Minggu ini"
        LocalDate.now().with(DayOfWeek.MONDAY).minusDays(7) -> "Minggu lalu"
        else -> "${d.dayOfMonth} ${d.month.name.lowercase().take(3)} – ${d.plusDays(6).dayOfMonth} ${d.plusDays(6).month.name.lowercase().take(3)}"
    }
}
