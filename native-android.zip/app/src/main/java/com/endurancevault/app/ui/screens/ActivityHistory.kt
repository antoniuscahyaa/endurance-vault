package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.i18n.Text
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.ui.UiState
import com.endurancevault.app.ui.theme.Ember
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.roundToInt

// Sub tab History di dock Minggu: kartu ringkasan padat + baris sesi ala DayBlock (Opsi A).

private data class HistoryRun(val activity: ActivityEntity, val kind: String, val group: String, val date: LocalDate)

private fun historyKind(a: ActivityEntity): String = when {
    a.type.equals("bike", true) -> "Sepeda"
    a.srcKey.matches(Regex(""".+~f\d+$""")) -> "Lari bebas"
    else -> "Lari"
}
private fun historyWeek(date: LocalDate): LocalDate = date.with(DayOfWeek.MONDAY)
private fun historyDistance(km: Double) = when { km < 7.0 -> "Pendek (<7 km)"; km <= 12.0 -> "Sedang (7–12 km)"; else -> "Panjang (>12 km)" }
private fun historyDuration(sec: Int): String {
    val h = sec / 3600; val m = (sec % 3600) / 60
    return if (h > 0) "${h}j ${m}m" else "${m}m"
}
private fun historyPace(sec: Int, km: Double): String {
    if (km <= 0 || sec <= 0) return "–"
    val s = (sec / km).roundToInt()
    return "${s / 60}:${"%02d".format(s % 60)}"
}
private fun historySub(a: ActivityEntity): String {
    val bike = a.type.equals("bike", true)
    val speed = when {
        a.km <= 0 || a.durationSec <= 0 -> null
        bike -> "${(a.km / (a.durationSec / 3600.0)).roundToInt()} km/h"
        else -> historyPace(a.durationSec, a.km) + "/km"
    }
    return listOfNotNull(
        speed,
        historyDuration(a.durationSec).takeIf { a.durationSec > 0 },
        a.avgHr?.let { "HR $it" },
        a.gain?.takeIf { it > 0 }?.let { "+$it m" },
    ).joinToString(" · ")
}

@Composable
fun ActivityHistoryContent(state: UiState, onOpen: (Long) -> Unit) {
    val cs = MaterialTheme.colorScheme
    var range by remember { mutableIntStateOf(30) }
    var grouping by remember { mutableStateOf("week") }
    var collapsed by remember { mutableStateOf(setOf<String>()) }
    val today = remember { LocalDate.now() }
    val from = if (range == 7) historyWeek(today) else today.minusDays(29)
    val runs = state.activities.mapNotNull { a ->
        val d = runCatching { LocalDate.parse(a.dateIso) }.getOrNull() ?: return@mapNotNull null
        if (d.isBefore(from) || d.isAfter(today) || a.km <= 0) return@mapNotNull null
        val kind = historyKind(a)
        val key = when (grouping) {
            "type" -> kind
            "dist" -> historyDistance(a.km)
            else -> historyWeek(d).toString()
        }
        HistoryRun(a, kind, key, d)
    }.sortedWith(compareByDescending<HistoryRun> { it.activity.dateIso }.thenByDescending { it.activity.id })
    val km = runs.sumOf { it.activity.km }
    val duration = runs.sumOf { it.activity.durationSec }
    val climb = runs.sumOf { it.activity.gain ?: 0 }
    val prevFrom = if (range == 7) from.minusDays(7) else from.minusDays(30)
    val prevTo = if (range == 7) today.minusDays(7) else today.minusDays(30)
    val prevKm = state.activities.sumOf { a ->
        val d = runCatching { LocalDate.parse(a.dateIso) }.getOrNull()
        if (d != null && !d.isBefore(prevFrom) && !d.isAfter(prevTo) && a.km > 0) a.km else 0.0
    }
    val delta = if (prevKm > 0) ((km - prevKm) / prevKm * 100).toInt() else null
    val grouped = runs.groupBy { it.group }.map { (key, items) -> Triple(key, items, items.sumOf { it.activity.km }) }
        .sortedBy {
            if (grouping == "week") -runCatching { LocalDate.parse(it.first) }.getOrDefault(LocalDate.MIN).toEpochDay()
            else when (it.first) { "Lari bebas" -> 4; "Lari" -> 0; "Sepeda" -> 5; "Pendek (<7 km)" -> 0; "Sedang (7–12 km)" -> 1; "Panjang (>12 km)" -> 2; else -> 3 }
        }
    val allClosed = grouped.isNotEmpty() && collapsed.size == grouped.size

    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        // ringkasan: rentang, 4 metrik, batang harian dalam satu kartu
        WkCard {
            Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        HistoryPill("30 hari", range == 30) { range = 30; collapsed = emptySet() }
                        HistoryPill("Minggu ini", range == 7) { range = 7; collapsed = emptySet() }
                    }
                    delta?.let { Text("%+d%% vs sebelumnya".format(it), fontSize = 10.sp, color = cs.onSurfaceVariant, maxLines = 1) }
                }
                Row(Modifier.fillMaxWidth()) {
                    HistoryStat("JARAK", "%.1f km".format(km))
                    HistoryStat("LARI", runs.count { it.activity.type != "bike" }.toString())
                    HistoryStat("WAKTU", historyDuration(duration))
                    HistoryStat("CLIMB", "+$climb m")
                }
                HistoryBars(state.activities, from, today, range)
            }
        }
        // kontrol pengelompokan: satu baris
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("week" to "Minggu", "type" to "Jenis", "dist" to "Jarak").forEach { (v, l) ->
                    HistoryPill(l, grouping == v) { grouping = v; collapsed = emptySet() }
                }
            }
            if (grouped.isNotEmpty()) Text(
                if (allClosed) "Buka semua" else "Lipat semua",
                Modifier.clickable { collapsed = if (allClosed) emptySet() else grouped.map { it.first }.toSet() }.padding(vertical = 6.dp),
                fontSize = 12.sp, fontWeight = FontWeight.Medium, color = cs.primary,
            )
        }
        if (runs.isEmpty()) {
            Text("Belum ada aktivitas dalam rentang ini.", fontSize = 13.sp, color = cs.onSurfaceVariant)
        } else grouped.forEach { (key, items, total) ->
            val closed = key in collapsed
            // satu grup = kartu header + kartu sesi, jarak 2dp, sudut hanya di ujung (seperti DayBlock)
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                WkCard(shape = wkGroupShape(first = true, last = closed), onClick = { collapsed = if (closed) collapsed - key else collapsed + key }) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(if (grouping == "week") historyWeekLabel(key) else key, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            val pace = if (items.any { it.activity.durationSec > 0 }) " · ${historyPace(items.sumOf { it.activity.durationSec }, total)}/km" else ""
                            Text("%.1f km · %d sesi%s".format(total, items.size, pace), fontSize = 11.sp, color = cs.onSurfaceVariant)
                        }
                        Icon(if (closed) Icons.Filled.KeyboardArrowDown else Icons.Filled.KeyboardArrowUp, null, Modifier.size(20.dp), tint = cs.primary)
                    }
                }
                if (!closed) items.forEachIndexed { i, r ->
                    HistoryRow(r, showMonth = grouping != "week", last = i == items.lastIndex, onOpen = onOpen)
                }
            }
        }
    }
}

@Composable
private fun HistoryRow(r: HistoryRun, showMonth: Boolean, last: Boolean, onOpen: (Long) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val a = r.activity
    val bike = r.kind == "Sepeda"
    val dow = r.date.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.ENGLISH).uppercase() +
        if (showMonth) " " + r.date.month.getDisplayName(TextStyle.SHORT, Locale.ENGLISH).uppercase() else ""
    WkCard(shape = wkGroupShape(first = false, last = last), onClick = { onOpen(a.id) }) {
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
            Box(Modifier.width(4.dp).fillMaxHeight().background(if (bike) WkGray else Ember))
            Row(Modifier.weight(1f).padding(horizontal = 10.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.width(38.dp)) {
                    Text(dow, fontFamily = WkMono, fontSize = if (showMonth) 8.sp else 9.sp, color = cs.onSurfaceVariant, maxLines = 1)
                    Text(r.date.dayOfMonth.toString(), fontSize = 18.sp, fontWeight = FontWeight.Bold, lineHeight = 20.sp)
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(a.name.ifBlank { r.kind }, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(historySub(a), fontSize = 11.sp, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(wkNum(a.km), fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text(" km", fontSize = 10.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(bottom = 2.dp))
                }
            }
        }
    }
}

@Composable
private fun HistoryPill(label: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        shape = CircleShape,
        color = if (selected) cs.primaryContainer else cs.surface,
        border = BorderStroke(0.6.dp, if (selected) cs.primary else cs.outlineVariant),
    ) {
        Text(
            label, Modifier.clickable(onClick = onClick).padding(horizontal = 11.dp, vertical = 5.dp),
            fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1,
            color = if (selected) cs.onPrimaryContainer else cs.onSurface,
        )
    }
}

@Composable
private fun RowScope.HistoryStat(label: String, value: String) {
    Column(Modifier.weight(1f)) {
        Text(label, fontFamily = WkMono, fontSize = 10.sp, letterSpacing = .8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        Text(value, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun HistoryBars(activities: List<ActivityEntity>, from: LocalDate, to: LocalDate, range: Int) {
    val cs = MaterialTheme.colorScheme
    val days = (0 until range).map { from.plusDays(it.toLong()) }
    val values = days.map { d -> activities.filter { it.type != "bike" && it.dateIso == d.toString() }.sumOf { it.km } }
    val max = (values.maxOrNull() ?: 0.0).coerceAtLeast(1.0)
    val accent = cs.primary
    val muted = cs.outlineVariant
    Canvas(Modifier.fillMaxWidth().height(40.dp)) {
        val slot = size.width / values.size
        values.forEachIndexed { i, v ->
            val h = ((v / max).toFloat() * size.height * .92f)
            drawRoundRect(
                if (v > 0) accent else muted.copy(alpha = .3f),
                Offset(i * slot + slot * .2f, size.height - h.coerceAtLeast(2.dp.toPx())),
                Size(slot * .6f, h.coerceAtLeast(2.dp.toPx())), CornerRadius(2.dp.toPx()),
            )
        }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text("${from.dayOfMonth} ${from.month.getDisplayName(TextStyle.SHORT, Locale.ENGLISH)}", fontFamily = WkMono, fontSize = 10.sp, color = cs.onSurfaceVariant)
        Text("${to.dayOfMonth} ${to.month.getDisplayName(TextStyle.SHORT, Locale.ENGLISH)}", fontFamily = WkMono, fontSize = 10.sp, color = cs.onSurfaceVariant)
    }
}

private fun historyWeekLabel(key: String): String {
    val d = runCatching { LocalDate.parse(key) }.getOrNull() ?: return key
    val thisMon = LocalDate.now().with(DayOfWeek.MONDAY)
    fun m(x: LocalDate) = x.month.getDisplayName(TextStyle.SHORT, Locale.ENGLISH)
    return when (d) {
        thisMon -> "Minggu ini"
        thisMon.minusDays(7) -> "Minggu lalu"
        else -> "${d.dayOfMonth} ${m(d)} – ${d.plusDays(6).dayOfMonth} ${m(d.plusDays(6))}"
    }
}
