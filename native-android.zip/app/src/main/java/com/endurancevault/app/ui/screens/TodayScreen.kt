package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.i18n.Text
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.delay
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.data.ReadinessHistoryStore
import com.endurancevault.app.domain.*
import com.endurancevault.app.ui.UiState
import java.time.LocalDate
import java.time.DayOfWeek
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.time.temporal.ChronoUnit
import java.util.Locale

/** Today follows the legacy glance-dock structure: greeting/weather, compact session card, sleep + readiness cards,
 *  selectable week strip, compact glance tiles and last-run summary. */
@Composable
fun TodayScreen(
    state: UiState,
    onAdd: (ActivityEntity) -> Unit,
    weather: WxSnapshot? = null,
    weatherPlaceLabel: String = "",
    weatherBusy: Boolean = false,
    weatherError: String? = null,
    weatherWatchNote: String = "",
    onRefreshWeather: (() -> Unit)? = null,
    onAutoRefreshWeather: ((Long) -> Unit)? = null,
    onOpenActivity: ((Long) -> Unit)? = null,
    onGoWeek: (() -> Unit)? = null,
    explore: com.endurancevault.app.ui.ExploreController? = null,
    onOpenRoute: (String) -> Unit = {},
    onOpenExplore: () -> Unit = {},
    sleep: SleepSummary? = null,
) {
    var dialog by remember { mutableStateOf(false) }
    var routePicker by remember { mutableStateOf(false) }
    var readinessOpen by remember { mutableStateOf(false) }
    var readinessInfoOpen by remember { mutableStateOf(false) }
    var sleepOpen by remember { mutableStateOf(false) }
    var zoneOpen by remember { mutableStateOf(false) }
    val appContext = LocalContext.current
    val readinessPrefs = remember { appContext.getSharedPreferences("readiness_settings", android.content.Context.MODE_PRIVATE) }
    var readinessConfig by remember {
        mutableStateOf(com.endurancevault.app.data.ReadinessPrefs.load(readinessPrefs))
    }
    var sessionExpanded by remember { mutableStateOf(false) }
    var selectedDate by remember { mutableStateOf<String?>(null) }
    val today = LocalDate.now()
    val plan = state.plan
    val planOk = plan as? PlanOutcome.Ok
    val week = planOk?.weeks?.firstOrNull { !today.isBefore(it.start) && !today.isAfter(it.end) }
    val day = week?.days?.firstOrNull { it.date == today }
    val metrics = remember(state.settings, state.activities, state.daily, state.plan, state.hrHistByActivity, readinessConfig) {
        TrainingMetrics.calculate(state.settings, state.activities, state.daily, state.plan, today, hrHistByActivity = state.hrHistByActivity, readinessConfig = readinessConfig)
    }
    val readiness = metrics.readiness
    // Kartu Tidur: ringkasan jam (punya fase); bila belum ada, jatuh ke jam tidur di catatan harian hari ini/kemarin.
    val sleepFallbackH = state.daily.filter { it.sleepH != null && it.dateIso >= today.minusDays(1).toString() && it.dateIso <= today.toString() }
        .maxByOrNull { it.dateIso }?.sleepH
    val sleepUi = remember(sleep, sleepFallbackH) { todaySleepUi(sleep, sleepFallbackH) }
    val sleepExtra = remember(sleep, sleepUi, state.daily, today) { todaySleepExtra(state.daily, sleepUi, sleep, today) }
    // Zona HR pekan berjalan (Senin..Minggu): sumber sama dengan HR ZONES di tab Load (histogram HR per aktivitas + batas zona di pengaturan).
    val zoneCuts = remember(state.settings) { Zones.cuts(state.settings) }
    val zoneHists = remember(state.activities, state.hrHistByActivity) { ldHists(state) }
    val zoneWeek = remember(zoneHists, zoneCuts, today) { LoadView.zonePeriods(zoneHists, zoneCuts, today, false, 1).first() }
    val zoneDays = remember(zoneHists, zoneCuts, today) { LoadView.zoneDays(zoneHists, zoneCuts, today.with(DayOfWeek.MONDAY)) }
    LaunchedEffect(today, readiness, state.daily) {
        readiness?.let { ReadinessHistoryStore.record(appContext, today, it, state.daily.any { d -> d.dateIso == today.toString() }) }
    }
    val freeMode = state.settings.rtype == "none"
    val weekStart = today.with(DayOfWeek.MONDAY)
    val stripStart = if (freeMode) today.minusDays(6) else weekStart
    val weekActivities = state.activities.filter { it.type != "bike" && it.km > 0 && it.dateIso >= weekStart.toString() && it.dateIso <= today.toString() }
    val completedKm = weekActivities.sumOf { it.km }
    val plannedKm = week?.km ?: 0.0
    val progress = if (plannedKm > 0) (completedKm / plannedKm).coerceIn(0.0, 1.0) else 0.0
    val lastRun = state.activities.filter { it.km > 0 && it.type != "bike" }.maxByOrNull { it.dateIso + (it.startTime ?: "") }
    val streak = calculateRunStreak(state.activities, today)
    val km28 = state.activities.filter { it.type != "bike" && it.km > 0 && runCatching { ChronoUnit.DAYS.between(LocalDate.parse(it.dateIso), today) in 0L..27L }.getOrDefault(false) }.sumOf { it.km }
    val selectedActivities = selectedDate?.let { date -> state.activities.filter { it.dateIso == date }.sortedBy { it.startTime ?: "" } }.orEmpty()
    val ranToday = state.activities.any { it.dateIso == today.toString() && it.km > 0 }
    val todayState = when { day == null -> "none"; day.kind == Kinds.REST -> "rest"; ranToday -> "done"; else -> "todo" }
    val nowHour = java.time.LocalTime.now().hour
    val greetPeriod = GreetingEngine.period(nowHour)
    val greetInput = buildGreetInput(
        todayState = todayState, readiness = readiness, acwr = metrics.ratio, daily = state.daily, activities = state.activities,
        raceDate = if (freeMode) null else state.settings.race, streak = streak, today = today, weather = weather,
    )
    // Kalimat dipilih sekali per peluncuran (seed tetap) dan hanya berganti bila kategori/datanya berubah.
    val quote = remember(greetInput, greetPeriod) { GreetingEngine.pick(greetInput, GreetingEngine.sessionSeed, greetPeriod) }

    // Muat ulang cuaca saat layar dibuka/kembali (jeda minimal 1 menit) dan tiap 10 menit selama terlihat.
    val lifecycleOwner = LocalLifecycleOwner.current
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { onAutoRefreshWeather?.invoke(60_000L) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(10 * 60_000L)
            if (lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) onAutoRefreshWeather?.invoke(9 * 60_000L + 30_000L)
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        // Judul halaman + tanggal; sapaan waktu kini ada di dalam kartu sapaan + cuaca di bawahnya.
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
            Text("Hari ini", style = MaterialTheme.typography.headlineMedium)
            Text(today.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", com.endurancevault.app.ui.i18n.Lang.locale)), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        GreetingWeatherCard(
            greeting = GreetingEngine.word(greetPeriod),
            quote = quote,
            time = GreetingEngine.timeOfDay(nowHour),
            atmosphere = GreetingEngine.atmosphere(greetInput),
            weather = weather,
            placeLabel = weatherPlaceLabel,
            busy = weatherBusy,
            error = weatherError,
            onRefresh = { onRefreshWeather?.invoke() },
            watchNote = weatherWatchNote,
        )

        // Kartu sesi hari ini: satu kartu horizontal compact. Gauge readiness kini jadi kartu sendiri di bawahnya.
        EvPanel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val sessionTitle = when {
                    day == null && freeMode -> "Latihan fleksibel"
                    day == null -> "Tidak ada sesi terjadwal"
                    day.kind == Kinds.REST -> "Libur"
                    else -> day.title
                }
                val detailText = day?.detail.orEmpty()
                val hrLimit = Regex("""HR\s*≤\s*\d+""", RegexOption.IGNORE_CASE)
                    .find(detailText)?.value?.replace(Regex("\\s+"), " ")
                val extraKm = Regex("""Tambahan\s+([\d.,]+)\s*km""", RegexOption.IGNORE_CASE)
                    .find(detailText)?.groupValues?.getOrNull(1)?.let { "+ $it km" }
                val hasSession = day != null && day.kind != Kinds.REST

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (day == null) if (freeMode) "SARAN HARI INI" else "HARI INI" else "SESI HARI INI",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    if (day != null && day.detail.isNotBlank()) {
                        Text(
                            if (sessionExpanded) "Detail sesi ▴" else "Detail sesi ▾",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { sessionExpanded = !sessionExpanded }
                                .padding(horizontal = 6.dp, vertical = 4.dp)
                        )
                    }
                }
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        sessionTitle,
                        style = MaterialTheme.typography.titleLarge,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (day != null && day.km > 0) {
                        Text(
                            "${fmtKmUi(day.km)} km",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (hrLimit != null || extraKm != null || ranToday) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (hrLimit != null) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Icon(
                                    androidx.compose.material.icons.Icons.Filled.Favorite,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(17.dp)
                                )
                                Text(hrLimit, style = MaterialTheme.typography.labelLarge, maxLines = 1)
                            }
                        }
                        if (extraKm != null) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Icon(
                                    androidx.compose.material.icons.Icons.Filled.Route,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(17.dp)
                                )
                                Text(extraKm, style = MaterialTheme.typography.labelLarge, maxLines = 1)
                            }
                        }
                        if (ranToday) {
                            Surface(
                                color = MaterialTheme.colorScheme.tertiaryContainer,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                                ) {
                                    Icon(
                                        androidx.compose.material.icons.Icons.Filled.Check,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.tertiary,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Text(
                                        "Tercatat",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.tertiary
                                    )
                                }
                            }
                        }
                    }
                }

                if (sessionExpanded && day != null && day.detail.isNotBlank()) {
                    Text(
                        detailText,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Rute dari Explore yang dipasang ke sesi hari ini (atau tombol untuk memasang satu).
                if (explore != null && day != null && day.kind != Kinds.REST) {
                    val links by explore.links.collectAsState()
                    val savedRoutes by explore.routes.collectAsState()
                    val linked = savedRoutes.firstOrNull { it.id == links[today.toString()] }
                    if (linked != null) {
                        val diff = if (day.km > 0) linked.stats.km - day.km else null
                        val far = diff != null && day.km > 0 && kotlin.math.abs(diff) / day.km > 0.15
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.72f),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().clickable(role = androidx.compose.ui.semantics.Role.Button, onClickLabel = "Buka rute ${linked.name}") { onOpenRoute(linked.id) },
                        ) {
                            Row(Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                ExRouteThumb(linked.pts, Modifier.size(52.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("RUTE SESI", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                    Text(linked.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(
                                        "${fmtKmUi(linked.stats.km)} km" + (if (linked.stats.hasEle) " · naik ${Js.idn(linked.stats.up)} m" else "") +
                                            (if (diff != null) " · target ${fmtKmUi(day.km)} km (${if (diff >= 0) "+" else "−"}${fmtKmUi(kotlin.math.abs(diff))})" else ""),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (far) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                TextButton(onClick = { explore.linkRoute(today.toString(), null) }) { Text("Lepas") }
                            }
                        }
                    } else {
                        OutlinedButton(onClick = { routePicker = true }, modifier = Modifier.fillMaxWidth()) { Text("Pasang rute dari Explore") }
                    }
                    if (routePicker) {
                        AlertDialog(
                            onDismissRequest = { routePicker = false },
                            title = { Text("Pasang rute ke sesi hari ini") },
                            text = {
                                if (savedRoutes.isEmpty()) Text("Koleksimu belum punya rute. Buat atau impor rute di Explore dulu.")
                                else Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    savedRoutes.forEach { r ->
                                        Row(
                                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                                .clickable(role = androidx.compose.ui.semantics.Role.Button) { explore.linkRoute(today.toString(), r.id); routePicker = false }
                                                .padding(8.dp),
                                            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically,
                                        ) {
                                            ExRouteThumb(r.pts, Modifier.size(44.dp))
                                            Column(Modifier.weight(1f)) {
                                                Text(r.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                Text("${fmtKmUi(r.stats.km)} km", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        }
                                    }
                                }
                            },
                            confirmButton = { if (savedRoutes.isEmpty()) TextButton(onClick = { routePicker = false; onOpenExplore() }) { Text("Buka Explore") } },
                            dismissButton = { TextButton(onClick = { routePicker = false }) { Text("Tutup") } },
                        )
                    }
                }

                if (day == null && !freeMode) {
                    OutlinedButton(onClick = { dialog = true }, modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)) { Text("Catat aktivitas") }
                } else if (day?.kind == Kinds.REST) {
                    Text("Pulihkan diri dan beri waktu tubuh beradaptasi.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else if (day == null && freeMode) {
                    Text("Tidak ada rencana lomba aktif. Gunakan saran latihan dan riwayat untuk mengatur sesi.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        // Tidur semalam + Kesiapan + Zona HR pekan ini: tiga kartu cincin berdampingan; ketuk untuk info melayang.
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            TodaySleepCard(sleepUi, Modifier.weight(1f).fillMaxHeight()) { sleepOpen = true }
            TodayReadinessCard(readiness, Modifier.weight(1f).fillMaxHeight()) { readinessInfoOpen = true }
            TodayHrZoneCard(zoneWeek, Modifier.weight(1f).fillMaxHeight()) { zoneOpen = true }
        }

        // Selectable week strip. Tapping a day with recorded activity opens its activity summary inline.
        EvPanel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(if (freeMode) "7 HARI TERAKHIR" else "MINGGU INI", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        Text(if (freeMode) "${fmtKmUi(km28)} km · 28 hari" else "${fmtKmUi(completedKm)} / ${fmtKmUi(plannedKm)} km", style = MaterialTheme.typography.titleMedium)
                    }
                    if (!freeMode && plannedKm > 0) Text("${(progress * 100).toInt()}%", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    (0..6).forEach { index ->
                        val date = stripStart.plusDays(index.toLong())
                        val dateIso = date.toString()
                        val dayPlan = week?.days?.firstOrNull { it.date == date }
                        val acts = state.activities.filter { it.dateIso == dateIso && it.km > 0 }
                        val done = acts.isNotEmpty()
                        val missed = date.isBefore(today) && dayPlan != null && dayPlan.kind != Kinds.REST && !done
                        val selected = selectedDate == dateIso
                        val tint = when { done -> MaterialTheme.colorScheme.tertiary; missed -> MaterialTheme.colorScheme.error; else -> MaterialTheme.colorScheme.onSurfaceVariant }
                        Column(
                            Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                                .background(if (selected) MaterialTheme.colorScheme.primary.copy(alpha = .14f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = if (date == today) .72f else .35f))
                                .then(if (date == today || selected) Modifier.border(1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp)) else Modifier)
                                .clickable { selectedDate = if (selected) null else dateIso }
                                .padding(vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp),
                        ) {
                            Text(date.dayOfWeek.getDisplayName(TextStyle.SHORT, com.endurancevault.app.ui.i18n.Lang.locale), style = MaterialTheme.typography.labelSmall, color = tint)
                            Box(Modifier.size(12.dp).clip(CircleShape).background(if (done) tint else MaterialTheme.colorScheme.surface).then(if (done) Modifier else Modifier.border(1.dp, tint, CircleShape)))
                            Box(
                                Modifier.fillMaxWidth().height(16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                if (acts.isNotEmpty()) {
                                    Text(
                                        fmtKmUi(acts.sumOf { it.km }),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = tint,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }
                if (selectedDate != null) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(LocalDate.parse(selectedDate).format(DateTimeFormatter.ofPattern("EEEE, d MMM", com.endurancevault.app.ui.i18n.Lang.locale)), style = MaterialTheme.typography.titleSmall)
                        TextButton(onClick = { selectedDate = null }) { Text("Tutup") }
                    }
                    if (selectedActivities.isEmpty()) Text("Belum ada aktivitas tercatat pada tanggal ini.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    selectedActivities.forEach { activity ->
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onOpenActivity?.invoke(activity.id) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Box(Modifier.size(8.dp).clip(CircleShape).background(MaterialTheme.colorScheme.tertiary))
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(activity.name.ifBlank { if (activity.type == "bike") "Sepeda" else "Lari" }, style = MaterialTheme.typography.titleSmall)
                                Text("${fmtKmUi(activity.km)} km · ${runPace(activity)} /km${activity.avgHr?.let { " · HR $it" } ?: ""}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (onOpenActivity != null) Text("Detail →", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
                Text(if (freeMode) "Volume berjalan · 28 hari terakhir" else "Minggu ${week?.i?.plus(1) ?: "—"} dari ${planOk?.n ?: "—"}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        // Compact glance tiles from legacy: ACWR + streak (or recent volume in no-race mode).
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HomeMetric("ACWR", if (metrics.ratio > 0) "%.2f".format(metrics.ratio) else "—", metrics.status)
            if (freeMode) HomeMetric("Volume 28 hari", "${fmtKmUi(km28)} km", "lari")
            else HomeMetric("Streak", streak.toString(), "hari berturut-turut")
        }
        EvPanel(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(if (state.activities.any { it.dateIso == today.toString() && it.km > 0 }) "LARI SEBELUMNYA" else "LARI TERAKHIR", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    Text(lastRun?.let { "${relativeRunDate(it.dateIso, today)} · ${fmtKmUi(it.km)} km · ${runPace(it)} /km" } ?: "Belum ada aktivitas", style = MaterialTheme.typography.titleSmall)
                }
                if (lastRun != null && onOpenActivity != null) TextButton(onClick = { onOpenActivity(lastRun.id) }) { Text("Detail") }
            }
        }
    }

    if (readinessOpen && readiness != null) {
        ReadinessDetailDialog(
            score = readiness, settings = state.settings, activities = state.activities, daily = state.daily, plan = state.plan,
            config = readinessConfig,
            onConfigChange = { updated ->
                readinessConfig = updated
                val e = readinessPrefs.edit().putInt("swap", updated.swapThreshold).putInt("light", updated.lightThreshold).putInt("easy", updated.easyThreshold)
                listOf("rec", "load", "sl", "debt", "hrv", "rhr", "shr", "pain", "leg", "mood").forEach { e.remove("weight_$it") }
                updated.weights.forEach { (key, value) -> e.putFloat("weight_$key", value.toFloat()) }
                e.apply()
            },
            onDismiss = { readinessOpen = false },
        )
    }
    if (sleepOpen && sleepUi != null) {
        // Offset zona waktu saat bangun, supaya jam di grafik fase sama dengan tab Jam.
        val sleepTzMin = sleep?.takeIf { it.end > 0 }
            ?.let { java.time.ZoneId.systemDefault().rules.getOffset(java.time.Instant.ofEpochSecond(it.end)).totalSeconds / 60 } ?: 0
        SleepInfoDialog(sleepUi, readiness?.sleepDebtHours, sleepExtra, sleep, sleepTzMin) { sleepOpen = false }
    }
    if (zoneOpen) HrZoneWeekDialog(zoneWeek, zoneDays, zoneCuts, today) { zoneOpen = false }
    if (readinessInfoOpen && readiness != null) ReadinessInfoDialog(
        readiness,
        onOpenFull = { readinessInfoOpen = false; readinessOpen = true },
        onDismiss = { readinessInfoOpen = false },
    )
    if (dialog) LogRunDialog(onDismiss = { dialog = false }) { km, min, hr ->
        onAdd(ActivityEntity(dateIso = today.toString(), km = km, durationSec = min * 60, avgHr = hr)); dialog = false
    }
}

@Composable
private fun CompactReadinessArc(score: Int, tier: String, onClick: () -> Unit) {
    val trackColor = MaterialTheme.colorScheme.surfaceVariant
    val progressColor = MaterialTheme.colorScheme.primary
    Column(
        Modifier.width(112.dp).clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick)
            .padding(2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(1.dp)
    ) {
        Box(Modifier.size(106.dp), contentAlignment = Alignment.Center) {
            androidx.compose.foundation.Canvas(Modifier.fillMaxSize().padding(7.dp)) {
                val stroke = 8.dp.toPx()
                drawArc(
                    color = trackColor,
                    startAngle = 135f, sweepAngle = 270f, useCenter = false,
                    style = androidx.compose.ui.graphics.drawscope.Stroke(
                        width = stroke, cap = androidx.compose.ui.graphics.StrokeCap.Round
                    )
                )
                drawArc(
                    color = progressColor,
                    startAngle = 135f, sweepAngle = 270f * (score.coerceIn(0, 100) / 100f),
                    useCenter = false,
                    style = androidx.compose.ui.graphics.drawscope.Stroke(
                        width = stroke, cap = androidx.compose.ui.graphics.StrokeCap.Round
                    )
                )
            }
            Text(score.toString(), style = MaterialTheme.typography.headlineLarge)
        }
        Text(tier, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.tertiary)
    }
}

@Composable private fun ReadinessRing(score: Int, tier: String, onClick: () -> Unit) {
    Column(Modifier.width(82.dp).clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(3.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Box(Modifier.size(72.dp).clip(CircleShape).background(MaterialTheme.colorScheme.tertiaryContainer), contentAlignment = Alignment.Center) {
            Text(score.toString(), style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onTertiaryContainer)
        }
        Text(tier, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.tertiary)
        Text("Kesiapan · detail", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable private fun RowScope.HomeMetric(label: String, value: String, sub: String) {
    EvPanel(Modifier.weight(1f)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.headlineSmall)
            if (sub.isNotBlank()) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
        }
    }
}

private fun calculateRunStreak(activities: List<ActivityEntity>, today: LocalDate): Int {
    val dates = activities.filter { it.type != "bike" && it.km > 0 }.mapNotNull { runCatching { LocalDate.parse(it.dateIso) }.getOrNull() }.toSet()
    var date = if (today in dates) today else today.minusDays(1)
    var count = 0
    while (date in dates && count < 365) { count++; date = date.minusDays(1) }
    return count
}
private fun relativeRunDate(iso: String, today: LocalDate): String {
    val d = runCatching { LocalDate.parse(iso) }.getOrNull() ?: return iso
    return when (ChronoUnit.DAYS.between(d, today).toInt()) { 0 -> "hari ini"; 1 -> "kemarin"; else -> d.format(DateTimeFormatter.ofPattern("d MMM", com.endurancevault.app.ui.i18n.Lang.locale)) }
}
private fun runPace(a: ActivityEntity): String = if (a.km > 0 && a.durationSec > 0) "%d:%02d".format((a.durationSec / a.km / 60).toInt(), ((a.durationSec / a.km).toInt() % 60)) else "—"

@Composable private fun LogRunDialog(onDismiss: () -> Unit, onSave: (Double, Int, Int?) -> Unit) {
    var km by remember { mutableStateOf("") }; var min by remember { mutableStateOf("") }; var hr by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Catat lari") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(km, { km = it }, label = { Text("Jarak (km)") }, singleLine = true)
            OutlinedTextField(min, { min = it }, label = { Text("Durasi (menit)") }, singleLine = true)
            OutlinedTextField(hr, { hr = it }, label = { Text("HR rata-rata (opsional)") }, singleLine = true)
        }
    }, confirmButton = { TextButton(onClick = { val k = km.replace(',', '.').toDoubleOrNull(); val m = min.toIntOrNull(); if (k != null && k > 0 && m != null && m > 0) onSave(k, m, hr.toIntOrNull()) }) { Text("Simpan") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } })
}

internal fun fmtKmUi(x: Double): String = if (x == kotlin.math.floor(x)) x.toLong().toString() else "%.1f".format(x).replace('.', ',')
