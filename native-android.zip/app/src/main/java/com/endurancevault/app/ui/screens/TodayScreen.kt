package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.floating.AlertDialog
import com.endurancevault.app.ui.i18n.Text
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import kotlin.math.roundToInt
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.delay
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.data.ReadinessHistoryStore
import com.endurancevault.app.domain.*
import com.endurancevault.app.ui.UiState
import java.time.LocalDate
import java.time.DayOfWeek
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.time.temporal.ChronoUnit
import java.util.Locale

/** Today follows the legacy glance-dock structure: greeting/weather, compact session card, sleep + readiness cards,
 *  selectable week strip, compact glance tiles and last-run summary. */
@Composable
fun TodayScreen(
    state: UiState,
    onAdd: (ActivityEntity) -> Unit,
    weather: WxSnapshot? = null,
    weatherPlaceLabel: String = "",
    weatherBusy: Boolean = false,
    weatherError: String? = null,
    weatherWatchNote: String = "",
    onRefreshWeather: (() -> Unit)? = null,
    onAutoRefreshWeather: ((Long) -> Unit)? = null,
    onOpenActivity: ((Long) -> Unit)? = null,
    onGoWeek: (() -> Unit)? = null,
    explore: com.endurancevault.app.ui.ExploreController? = null,
    onOpenRoute: (String) -> Unit = {},
    onOpenExplore: () -> Unit = {},
    onPushWorkout: (String, Int, Int, Int, Int, Int, WorkoutTargets) -> Unit = { _, _, _, _, _, _, _ -> },
    duplicateCount: Int = 0,
    duplicateNotice: String = "",
    onMergeDuplicates: () -> Unit = {},
    onDismissDuplicateNotice: () -> Unit = {},
    sleep: SleepSummary? = null,
) {
    var dialog by remember { mutableStateOf(false) }
    var sendOpen by remember { mutableStateOf(false) }
    // Mode data kartu 7 hari/minggu: "run" atau "bike". Jarak total dan isi kapsul mengikuti mode ini.
    var stripMode by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf("run") }
    var readinessOpen by remember { mutableStateOf(false) }
    var readinessInfoOpen by remember { mutableStateOf(false) }
    var sleepOpen by remember { mutableStateOf(false) }
    var zoneOpen by remember { mutableStateOf(false) }
    val appContext = LocalContext.current
    val readinessPrefs = remember { appContext.getSharedPreferences("readiness_settings", android.content.Context.MODE_PRIVATE) }
    var readinessConfig by remember {
        mutableStateOf(com.endurancevault.app.data.ReadinessPrefs.load(readinessPrefs))
    }
    var sessionExpanded by remember { mutableStateOf(false) }
    val today = LocalDate.now()
    val plan = state.plan
    val planOk = plan as? PlanOutcome.Ok
    val week = planOk?.weeks?.firstOrNull { !today.isBefore(it.start) && !today.isAfter(it.end) }
    val day = week?.days?.firstOrNull { it.date == today }
    val metrics = remember(state.settings, state.activities, state.daily, state.plan, state.hrHistByActivity, readinessConfig) {
        TrainingMetrics.calculate(state.settings, state.activities, state.daily, state.plan, today, hrHistByActivity = state.hrHistByActivity, readinessConfig = readinessConfig)
    }
    val readiness = metrics.readiness
    // Kartu Tidur: ringkasan jam (punya fase); bila belum ada, jatuh ke jam tidur di catatan harian hari ini/kemarin.
    val sleepFallbackH = state.daily.filter { it.sleepH != null && it.dateIso >= today.minusDays(1).toString() && it.dateIso <= today.toString() }
        .maxByOrNull { it.dateIso }?.sleepH
    val sleepUi = remember(sleep, sleepFallbackH) { todaySleepUi(sleep, sleepFallbackH) }
    val sleepExtra = remember(sleep, sleepUi, state.daily, today) { todaySleepExtra(state.daily, sleepUi, sleep, today) }
    // Zona HR pekan berjalan (Senin..Minggu): sumber sama dengan HR ZONES di tab Load (histogram HR per aktivitas + batas zona di pengaturan).
    val zoneCuts = remember(state.settings) { Zones.cuts(state.settings) }
    val zoneHists = remember(state.activities, state.hrHistByActivity) { ldHists(state) }
    val zoneWeek = remember(zoneHists, zoneCuts, today) { LoadView.zonePeriods(zoneHists, zoneCuts, today, false, 1).first() }
    val zoneDays = remember(zoneHists, zoneCuts, today) { LoadView.zoneDays(zoneHists, zoneCuts, today.with(DayOfWeek.MONDAY)) }
    LaunchedEffect(today, readiness, state.daily) {
        readiness?.let { ReadinessHistoryStore.record(appContext, today, it, state.daily.any { d -> d.dateIso == today.toString() }) }
    }
    val freeMode = state.settings.rtype == "none"
    val weekStart = today.with(DayOfWeek.MONDAY)
    val stripStart = if (freeMode) today.minusDays(6) else weekStart
    val weekActivities = state.activities.filter { it.type != "bike" && it.km > 0 && it.dateIso >= weekStart.toString() && it.dateIso <= today.toString() }
    val completedKm = weekActivities.sumOf { it.km }
    val plannedKm = week?.km ?: 0.0
    val progress = if (plannedKm > 0) (completedKm / plannedKm).coerceIn(0.0, 1.0) else 0.0
    val lastRun = state.activities.filter { it.km > 0 && it.type != "bike" }.maxByOrNull { it.dateIso + (it.startTime ?: "") }
    val streak = calculateRunStreak(state.activities, today)
    val km28 = state.activities.filter { it.type != "bike" && it.km > 0 && runCatching { ChronoUnit.DAYS.between(LocalDate.parse(it.dateIso), today) in 0L..27L }.getOrDefault(false) }.sumOf { it.km }
    val km7 = state.activities.filter { it.type != "bike" && it.km > 0 && runCatching { ChronoUnit.DAYS.between(LocalDate.parse(it.dateIso), today) in 0L..6L }.getOrDefault(false) }.sumOf { it.km }
    val ranToday = state.activities.any { it.dateIso == today.toString() && it.km > 0 }
    // Mode No Race: PlanEngine mengisi semua hari dengan Libur, jadi sesi disarankan dari pola lari 28 hari terakhir.
    val rec = if (!freeMode) null else remember(state.activities, state.settings, readiness, readinessConfig, metrics.ratio, today) {
        val cfg = readinessConfig.safe()
        val runPts = state.activities.filter { it.type != "bike" && it.km > 0 }.mapNotNull { a ->
            runCatching { FreeRunRecommender.Run(LocalDate.parse(a.dateIso.take(10)), a.km, a.durationSec / 60.0, a.avgHr, a.gain) }.getOrNull()
        }
        val hrCap = runCatching { EasyPace.sessHr(state.settings) }.getOrNull()?.takeIf { it in 100..220 }
        val easyPace = hrCap?.let { cap ->
            EasyPace.recentAverage(
                state.activities.map { EasyPace.Run(it.dateIso, it.km, it.durationSec / 60.0, it.avgHr, it.type, it.gain) }, cap, 5,
            )?.pace
        }
        FreeRunRecommender.recommend(
            FreeRunRecommender.Input(
                runs = runPts, today = today, easyHrCap = hrCap, easyPaceMin = easyPace,
                fallbackPaceMin = Js.parsePaceStr(state.settings.pace),
                readinessScore = readiness?.score, readinessEasyThreshold = cfg.easyThreshold, readinessSwapThreshold = cfg.swapThreshold,
                acwr = metrics.ratio.takeIf { it > 0 },
                recentPain = cfg.painEntries.filter { !it.date.isBefore(today.minusDays(2)) && !it.date.isAfter(today) }.maxOfOrNull { it.severity } ?: 0,
            ),
        )
    }
    val todayState = when {
        rec != null -> when (rec.kind) { FreeRunRecommender.Kind.REST -> "rest"; FreeRunRecommender.Kind.DONE -> "done"; else -> "todo" }
        day == null -> "none"; day.kind == Kinds.REST -> "rest"; ranToday -> "done"; else -> "todo"
    }
    val nowHour = java.time.LocalTime.now().hour
    val greetPeriod = GreetingEngine.period(nowHour)
    val greetInput = buildGreetInput(
        todayState = todayState, readiness = readiness, acwr = metrics.ratio, daily = state.daily, activities = state.activities,
        raceDate = if (freeMode) null else state.settings.race, streak = streak, today = today, weather = weather,
    )
    // Kalimat dipilih sekali per peluncuran (seed tetap) dan hanya berganti bila kategori/datanya berubah.
    val quote = remember(greetInput, greetPeriod) { GreetingEngine.pick(greetInput, GreetingEngine.sessionSeed, greetPeriod) }

    // Muat ulang cuaca saat layar dibuka/kembali (jeda minimal 1 menit) dan tiap 10 menit selama terlihat.
    val lifecycleOwner = LocalLifecycleOwner.current
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { onAutoRefreshWeather?.invoke(60_000L) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(10 * 60_000L)
            if (lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) onAutoRefreshWeather?.invoke(9 * 60_000L + 30_000L)
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        // Hari dan tanggal saja (judul "Hari ini" dihapus), rata kiri; sapaan waktu ada di dalam kartu sapaan + cuaca di bawahnya.
        Text(
            today.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", com.endurancevault.app.ui.i18n.Lang.locale)),
            style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 4.dp, top = 4.dp),
        )

        GreetingWeatherCard(
            greeting = GreetingEngine.word(greetPeriod),
            quote = quote,
            time = GreetingEngine.timeOfDay(nowHour),
            atmosphere = GreetingEngine.atmosphere(greetInput),
            weather = weather,
            placeLabel = weatherPlaceLabel,
            busy = weatherBusy,
            error = weatherError,
            onRefresh = { onRefreshWeather?.invoke() },
            watchNote = weatherWatchNote,
        )

        // Aktivitas ganda: hasil gabung otomatis (info) dan pasangan yang butuh konfirmasi. Duplikat membuat volume dan saran latihan keliru.
        if (duplicateNotice.isNotBlank()) {
            EvPanel(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(start = 14.dp, top = 6.dp, bottom = 6.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(duplicateNotice, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                    TextButton(onClick = onDismissDuplicateNotice) { Text("Tutup") }
                }
            }
        }
        if (duplicateCount > 0) {
            EvPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("AKTIVITAS GANDA", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    Text(
                        "Ada $duplicateCount pasangan aktivitas yang tampak ganda. Ini membuat volume mingguan dan saran latihan jadi keliru.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    OutlinedButton(onClick = onMergeDuplicates, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("Gabungkan") }
                }
            }
        }

        // Kartu sesi hari ini: satu kartu horizontal compact. Gauge readiness kini jadi kartu sendiri di bawahnya.
        EvPanel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val sessionTitle = when {
                    rec != null -> rec.title
                    day == null && freeMode -> "Latihan fleksibel"
                    day == null -> "Tidak ada sesi terjadwal"
                    day.kind == Kinds.REST -> "Libur"
                    else -> day.title
                }
                val detailText = if (rec != null) (rec.reasons + listOfNotNull(rec.paceText?.let { "Pace easy sekitar $it." }, rec.basis.takeIf { it.isNotBlank() })).joinToString("\n") else day?.detail.orEmpty()
                val hrLimit = if (rec != null) rec.hrLimit?.let { "HR ≤ $it" } else Regex("""HR\s*≤\s*\d+""", RegexOption.IGNORE_CASE)
                    .find(detailText)?.value?.replace(Regex("\\s+"), " ")
                val shownKm = rec?.km ?: day?.km ?: 0.0
                val recMinutes = rec?.minutes?.let { "≈ $it mnt" }
                val extraKm = Regex("""Tambahan\s+([\d.,]+)\s*km""", RegexOption.IGNORE_CASE)
                    .find(detailText)?.groupValues?.getOrNull(1)?.let { "+ $it km" }
                val hasSession = if (rec != null) rec.kind != FreeRunRecommender.Kind.REST && rec.kind != FreeRunRecommender.Kind.DONE else day != null && day.kind != Kinds.REST

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (rec != null) "SARAN HARI INI" else if (day == null) if (freeMode) "SARAN HARI INI" else "HARI INI" else "SESI HARI INI",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    if (detailText.isNotBlank()) {
                        Text(
                            if (sessionExpanded) "Detail sesi ▴" else "Detail sesi ▾",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { sessionExpanded = !sessionExpanded }
                                .padding(horizontal = 6.dp, vertical = 4.dp)
                        )
                    }
                }
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        sessionTitle,
                        style = MaterialTheme.typography.titleLarge,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (shownKm > 0) {
                        Text(
                            "${fmtKmUi(shownKm)} km",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (hrLimit != null || extraKm != null || recMinutes != null || ranToday) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (hrLimit != null) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Icon(
                                    androidx.compose.material.icons.Icons.Filled.Favorite,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(17.dp)
                                )
                                Text(hrLimit, style = MaterialTheme.typography.labelLarge, maxLines = 1)
                            }
                        }
                        if (recMinutes != null) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Icon(
                                    androidx.compose.material.icons.Icons.Filled.Schedule,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(17.dp)
                                )
                                Text(recMinutes, style = MaterialTheme.typography.labelLarge, maxLines = 1)
                            }
                        }
                        if (extraKm != null) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Icon(
                                    androidx.compose.material.icons.Icons.Filled.Route,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(17.dp)
                                )
                                Text(extraKm, style = MaterialTheme.typography.labelLarge, maxLines = 1)
                            }
                        }
                        if (ranToday) {
                            Surface(
                                color = MaterialTheme.colorScheme.tertiaryContainer,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                                ) {
                                    Icon(
                                        androidx.compose.material.icons.Icons.Filled.Check,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.tertiary,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Text(
                                        "Tercatat",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.tertiary
                                    )
                                }
                            }
                        }
                    }
                }

                if (sessionExpanded && detailText.isNotBlank()) {
                    Text(
                        detailText,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Rute Explore yang sudah dipasang ke sesi hari ini tetap tampil (dengan tombol Lepas). Tombol untuk memasang rute baru
                // sengaja dihapus dari kartu rekomendasi.
                if (explore != null && hasSession) {
                    val links by explore.links.collectAsState()
                    val savedRoutes by explore.routes.collectAsState()
                    val linked = savedRoutes.firstOrNull { it.id == links[today.toString()] }
                    if (linked != null) {
                        val diff = if (shownKm > 0) linked.stats.km - shownKm else null
                        val far = diff != null && shownKm > 0 && kotlin.math.abs(diff) / shownKm > 0.15
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.72f),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().clickable(role = androidx.compose.ui.semantics.Role.Button, onClickLabel = "Buka rute ${linked.name}") { onOpenRoute(linked.id) },
                        ) {
                            Row(Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                ExRouteThumb(linked.pts, Modifier.size(52.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("RUTE SESI", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                    Text(linked.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(
                                        "${fmtKmUi(linked.stats.km)} km" + (if (linked.stats.hasEle) " · naik ${Js.idn(linked.stats.up)} m" else "") +
                                            (if (diff != null) " · target ${fmtKmUi(shownKm)} km (${if (diff >= 0) "+" else "−"}${fmtKmUi(kotlin.math.abs(diff))})" else ""),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (far) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                TextButton(onClick = { explore.linkRoute(today.toString(), null) }) { Text("Lepas") }
                            }
                        }
                    }
                }

                // Sesi quality berbasis repetisi/progresif (QualityWorkout bisa menyusun langkahnya): tombol kirim ke jam.
                if (rec == null && day != null && !ranToday && QualityWorkout.fromDay(day) != null) {
                    OutlinedButton(onClick = { sendOpen = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("Kirim ke jam") }
                    if (sendOpen) {
                        val maxHr = remember(state.settings, state.daily) { Zones.cuts(state.settings, restHrFrom(state.daily).first).maxHr }
                        SendWorkoutDialog(day, state.settings.hr, maxHr, onDismiss = { sendOpen = false }) { name, spec, targets ->
                            onPushWorkout(name, spec.warmupMin, spec.repeats, spec.runMin, spec.recoveryMin, spec.cooldownMin, targets)
                            sendOpen = false
                        }
                    }
                }

                if (rec != null) {
                    Text(rec.summary, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (!sessionExpanded) rec.reasons.firstOrNull()?.let {
                        Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else if (day == null && !freeMode) {
                    OutlinedButton(onClick = { dialog = true }, modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)) { Text("Catat aktivitas") }
                } else if (day?.kind == Kinds.REST) {
                    Text("Pulihkan diri dan beri waktu tubuh beradaptasi.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else if (day == null && freeMode) {
                    Text("Tidak ada rencana lomba aktif. Gunakan saran latihan dan riwayat untuk mengatur sesi.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        // Tidur semalam + Kesiapan + Zona HR pekan ini: tiga kartu cincin berdampingan; ketuk untuk info melayang.
        // Tinggi tiap kartu mengikuti lebarnya (kartu dalam persegi), jadi tidak perlu IntrinsicSize/fillMaxHeight.
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            TodaySleepCard(sleepUi, Modifier.weight(1f)) { sleepOpen = true }
            TodayReadinessCard(readiness, Modifier.weight(1f)) { readinessInfoOpen = true }
            TodayHrZoneCard(zoneWeek, Modifier.weight(1f)) { zoneOpen = true }
        }

        // Selectable week strip. Tapping a day with recorded activity opens its activity summary inline.
        EvPanel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                val bikeMode = stripMode == "bike"
                val stripEnd = if (freeMode) today else weekStart.plusDays(6)
                val stripActs = state.activities.filter { (it.type == "bike") == bikeMode && it.km > 0 && it.dateIso >= stripStart.toString() && it.dateIso <= stripEnd.toString() }
                val bikeKm = if (bikeMode) stripActs.sumOf { it.km } else 0.0
                // Total durasi data yang sedang ditampilkan (lari atau sepeda), ikut mode saklar.
                val stripDur = WatchDock.hm((stripActs.sumOf { it.durationSec } / 60.0).roundToInt())
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(if (freeMode) "7 HARI TERAKHIR" else "MINGGU INI", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        Text(
                            when {
                                bikeMode -> if (freeMode) "${fmtKmUi(bikeKm)} km · 7 hari" else "${fmtKmUi(bikeKm)} km"
                                freeMode -> "${fmtKmUi(km7)} km · 7 hari"
                                else -> "${fmtKmUi(completedKm)} / ${fmtKmUi(plannedKm)} km"
                            },
                            style = MaterialTheme.typography.titleMedium,
                        )
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            Icon(androidx.compose.material.icons.Icons.Filled.Schedule, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(15.dp))
                            Text(stripDur, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (!bikeMode && !freeMode && plannedKm > 0) Text("${(progress * 100).toInt()}%", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                        StripModeSwitch(bikeMode) { stripMode = if (it) "bike" else "run" }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    (0..6).forEach { index ->
                        val date = stripStart.plusDays(index.toLong())
                        val dateIso = date.toString()
                        val dayPlan = week?.days?.firstOrNull { it.date == date }
                        val acts = state.activities.filter { it.dateIso == dateIso && it.km > 0 && (it.type == "bike") == bikeMode }
                        val done = acts.isNotEmpty()
                        val missed = !bikeMode && date.isBefore(today) && dayPlan != null && dayPlan.kind != Kinds.REST && !done
                        val tint = when { done -> MaterialTheme.colorScheme.tertiary; missed -> MaterialTheme.colorScheme.error; else -> MaterialTheme.colorScheme.onSurfaceVariant }
                        val capsule = RoundedCornerShape(50)
                        val cs = MaterialTheme.colorScheme
                        val dayBg = when {
                            done -> cs.tertiary.copy(alpha = .14f)
                            missed -> cs.error.copy(alpha = .10f)
                            else -> cs.surface
                        }
                        // Ketuk kapsul membuka halaman aktivitas (yang terjauh bila ada beberapa pada hari itu).
                        val openTarget = acts.maxByOrNull { it.km }?.takeIf { onOpenActivity != null }
                        Column(
                            Modifier.weight(1f).defaultMinSize(minHeight = 76.dp).clip(capsule)
                                .background(dayBg)
                                .then(if (date == today) Modifier.border(1.dp, cs.outline, capsule) else Modifier)
                                .then(if (openTarget != null) Modifier.clickable(role = androidx.compose.ui.semantics.Role.Button, onClickLabel = "Buka aktivitas") { onOpenActivity?.invoke(openTarget.id) } else Modifier)
                                .padding(vertical = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Text(date.dayOfWeek.getDisplayName(TextStyle.SHORT, com.endurancevault.app.ui.i18n.Lang.locale), style = MaterialTheme.typography.labelSmall, color = tint)
                            Box(Modifier.size(12.dp).clip(CircleShape).background(if (done) tint else MaterialTheme.colorScheme.surface).then(if (done) Modifier else Modifier.border(1.dp, tint, CircleShape)))
                            Box(Modifier.fillMaxWidth().height(16.dp), contentAlignment = Alignment.Center) {
                                if (acts.isNotEmpty()) Text(fmtKmUi(acts.sumOf { it.km }), style = MaterialTheme.typography.labelSmall, color = tint, maxLines = 1)
                            }
                        }
                    }
                }
                Text(if (freeMode) "Volume berjalan · 28 hari terakhir" else "Minggu ${week?.i?.plus(1) ?: "—"} dari ${planOk?.n ?: "—"}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        // Compact glance tiles from legacy: ACWR + streak (or recent volume in no-race mode).
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HomeMetric("ACWR", if (metrics.ratio > 0) "%.2f".format(metrics.ratio) else "—", metrics.status)
            if (freeMode) HomeMetric("Volume 28 hari", "${fmtKmUi(km28)} km", "lari")
            else HomeMetric("Streak", streak.toString(), "hari berturut-turut")
        }
        EvPanel(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(if (state.activities.any { it.dateIso == today.toString() && it.km > 0 }) "LARI SEBELUMNYA" else "LARI TERAKHIR", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    Text(lastRun?.let { "${relativeRunDate(it.dateIso, today)} · ${fmtKmUi(it.km)} km · ${runPace(it)} /km" } ?: "Belum ada aktivitas", style = MaterialTheme.typography.titleSmall)
                }
                if (lastRun != null && onOpenActivity != null) TextButton(onClick = { onOpenActivity(lastRun.id) }) { Text("Detail") }
            }
        }
    }

    if (readinessOpen && readiness != null) {
        ReadinessDetailDialog(
            score = readiness, settings = state.settings, activities = state.activities, daily = state.daily, plan = state.plan,
            config = readinessConfig,
            onConfigChange = { updated ->
                readinessConfig = updated
                val e = readinessPrefs.edit().putInt("swap", updated.swapThreshold).putInt("light", updated.lightThreshold).putInt("easy", updated.easyThreshold)
                listOf("rec", "load", "sl", "debt", "hrv", "rhr", "shr", "pain", "leg", "mood").forEach { e.remove("weight_$it") }
                updated.weights.forEach { (key, value) -> e.putFloat("weight_$key", value.toFloat()) }
                e.apply()
            },
            onDismiss = { readinessOpen = false },
        )
    }
    if (sleepOpen && sleepUi != null) {
        // Offset zona waktu saat bangun, supaya jam di grafik fase sama dengan tab Jam.
        val sleepTzMin = sleep?.takeIf { it.end > 0 }
            ?.let { java.time.ZoneId.systemDefault().rules.getOffset(java.time.Instant.ofEpochSecond(it.end)).totalSeconds / 60 } ?: 0
        SleepInfoDialog(sleepUi, readiness?.sleepDebtHours, sleepExtra, sleep, sleepTzMin) { sleepOpen = false }
    }
    if (zoneOpen) HrZoneWeekDialog(zoneWeek, zoneDays, zoneCuts, today) { zoneOpen = false }
    if (readinessInfoOpen && readiness != null) ReadinessInfoDialog(
        readiness,
        onOpenFull = { readinessInfoOpen = false; readinessOpen = true },
        onDismiss = { readinessInfoOpen = false },
    )
    if (dialog) LogRunDialog(onDismiss = { dialog = false }) { km, min, hr ->
        onAdd(ActivityEntity(dateIso = today.toString(), km = km, durationSec = min * 60, avgHr = hr)); dialog = false
    }
}

@Composable
private fun CompactReadinessArc(score: Int, tier: String, onClick: () -> Unit) {
    val trackColor = MaterialTheme.colorScheme.surfaceVariant
    val progressColor = MaterialTheme.colorScheme.primary
    Column(
        Modifier.width(112.dp).clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick)
            .padding(2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(1.dp)
    ) {
        Box(Modifier.size(106.dp), contentAlignment = Alignment.Center) {
            androidx.compose.foundation.Canvas(Modifier.fillMaxSize().padding(7.dp)) {
                val stroke = 8.dp.toPx()
                drawArc(
                    color = trackColor,
                    startAngle = 135f, sweepAngle = 270f, useCenter = false,
                    style = androidx.compose.ui.graphics.drawscope.Stroke(
                        width = stroke, cap = androidx.compose.ui.graphics.StrokeCap.Round
                    )
                )
                drawArc(
                    color = progressColor,
                    startAngle = 135f, sweepAngle = 270f * (score.coerceIn(0, 100) / 100f),
                    useCenter = false,
                    style = androidx.compose.ui.graphics.drawscope.Stroke(
                        width = stroke, cap = androidx.compose.ui.graphics.StrokeCap.Round
                    )
                )
            }
            Text(score.toString(), style = MaterialTheme.typography.headlineLarge)
        }
        Text(tier, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.tertiary)
    }
}

@Composable private fun ReadinessRing(score: Int, tier: String, onClick: () -> Unit) {
    Column(Modifier.width(82.dp).clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(3.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Box(Modifier.size(72.dp).clip(CircleShape).background(MaterialTheme.colorScheme.tertiaryContainer), contentAlignment = Alignment.Center) {
            Text(score.toString(), style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onTertiaryContainer)
        }
        Text(tier, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.tertiary)
        Text("Kesiapan · detail", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable private fun RowScope.HomeMetric(label: String, value: String, sub: String) {
    EvPanel(Modifier.weight(1f)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.headlineSmall)
            if (sub.isNotBlank()) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
        }
    }
}

private fun calculateRunStreak(activities: List<ActivityEntity>, today: LocalDate): Int {
    val dates = activities.filter { it.type != "bike" && it.km > 0 }.mapNotNull { runCatching { LocalDate.parse(it.dateIso) }.getOrNull() }.toSet()
    var date = if (today in dates) today else today.minusDays(1)
    var count = 0
    while (date in dates && count < 365) { count++; date = date.minusDays(1) }
    return count
}
private fun relativeRunDate(iso: String, today: LocalDate): String {
    val d = runCatching { LocalDate.parse(iso) }.getOrNull() ?: return iso
    return when (ChronoUnit.DAYS.between(d, today).toInt()) { 0 -> "hari ini"; 1 -> "kemarin"; else -> d.format(DateTimeFormatter.ofPattern("d MMM", com.endurancevault.app.ui.i18n.Lang.locale)) }
}
private fun runPace(a: ActivityEntity): String = if (a.km > 0 && a.durationSec > 0) "%d:%02d".format((a.durationSec / a.km / 60).toInt(), ((a.durationSec / a.km).toInt() % 60)) else "—"

@Composable private fun LogRunDialog(onDismiss: () -> Unit, onSave: (Double, Int, Int?) -> Unit) {
    var km by remember { mutableStateOf("") }; var min by remember { mutableStateOf("") }; var hr by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Catat lari") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(km, { km = it }, label = { Text("Jarak (km)") }, singleLine = true)
            OutlinedTextField(min, { min = it }, label = { Text("Durasi (menit)") }, singleLine = true)
            OutlinedTextField(hr, { hr = it }, label = { Text("HR rata-rata (opsional)") }, singleLine = true)
        }
    }, confirmButton = { TextButton(onClick = { val k = km.replace(',', '.').toDoubleOrNull(); val m = min.toIntOrNull(); if (k != null && k > 0 && m != null && m > 0) onSave(k, m, hr.toIntOrNull()) }) { Text("Simpan") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } })
}

internal fun fmtKmUi(x: Double): String = if (x == kotlin.math.floor(x)) x.toLong().toString() else "%.1f".format(x).replace('.', ',')

/** Saklar kecil Lari | Sepeda untuk kartu 7 hari/minggu. [onChange] menerima true bila Sepeda dipilih. */
@Composable
private fun StripModeSwitch(bike: Boolean, onChange: (Boolean) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(cs.surface).border(0.8.dp, cs.outlineVariant, RoundedCornerShape(50)).padding(2.dp),
    ) {
        listOf(false to "Lari", true to "Sepeda").forEach { (isBike, label) ->
            val on = bike == isBike
            Box(
                Modifier.clip(RoundedCornerShape(50))
                    .background(if (on) cs.primary else androidx.compose.ui.graphics.Color.Transparent)
                    .clickable(role = androidx.compose.ui.semantics.Role.RadioButton, onClickLabel = label) { onChange(isBike) }
                    .padding(horizontal = 12.dp, vertical = 5.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(label, style = MaterialTheme.typography.labelMedium, color = if (on) cs.onPrimary else cs.onSurfaceVariant, maxLines = 1)
            }
        }
    }
}
