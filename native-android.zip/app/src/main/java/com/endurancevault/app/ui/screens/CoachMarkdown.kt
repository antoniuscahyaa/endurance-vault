package com.endurancevault.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp

/**
 * Merapikan jawaban AI Coach agar enak dibaca di layar kecil: markdown ringan (judul, **tebal**, *miring*, `kode`,
 * daftar berpoin/bernomor) dirender sebagai teks bergaya, tabel diubah jadi daftar ringkas, dan penanda sitasi
 * pencarian web (【…】) dibuang. Teks bukan UI, jadi memakai Text material3 (tidak lewat penerjemah kamus).
 */
internal sealed interface CoachBlock {
    data class Heading(val text: String) : CoachBlock
    data class Para(val text: String) : CoachBlock
    data class Bullet(val text: String, val level: Int) : CoachBlock
    data class Numbered(val n: String, val text: String) : CoachBlock
}

private val CitationRegex = Regex("【[^】]*】")
private val BrRegex = Regex("<br\\s*/?>", RegexOption.IGNORE_CASE)
private val HeadingRegex = Regex("^\\s{0,3}#{1,6}\\s+(.*?)\\s*#*\\s*$")
private val BulletRegex = Regex("^(\\s*)[-*•]\\s+(.*)$")
private val NumberRegex = Regex("^\\s*(\\d{1,2})[.)]\\s+(.*)$")
private val RuleRegex = Regex("^\\s*([-*_])(\\s*\\1){2,}\\s*$")

private fun isTableSeparator(line: String): Boolean =
    line.contains('-') && line.all { it == '|' || it == ':' || it == '-' || it == ' ' || it == '\t' }

private fun tableCells(line: String): List<String> =
    line.trim().trim('|').split('|').map { it.trim() }

/** Tabel markdown terlalu lebar untuk layar ponsel: tiap baris jadi satu butir "**Kolom 1** · Judul: nilai · …". */
private fun tableToBullets(rows: List<List<String>>, out: MutableList<CoachBlock>) {
    if (rows.isEmpty()) return
    val header = rows.first()
    val body = rows.drop(1)
    if (body.isEmpty()) {
        out.add(CoachBlock.Para(header.joinToString(" · ")))
        return
    }
    body.forEach { r ->
        val parts = r.mapIndexed { idx, cell ->
            val h = header.getOrNull(idx).orEmpty()
            when {
                cell.isBlank() -> ""
                idx == 0 -> "**$cell**"
                h.isBlank() -> cell
                else -> "$h: $cell"
            }
        }
        out.add(CoachBlock.Bullet(parts.filter { it.isNotBlank() }.joinToString(" · "), 0))
    }
}

internal fun parseCoachBlocks(raw: String): List<CoachBlock> {
    val text = raw.replace("\r\n", "\n").replace(BrRegex, "\n").replace(CitationRegex, "")
    val lines = text.split('\n')
    val out = ArrayList<CoachBlock>()
    val para = StringBuilder()
    fun flush() {
        if (para.isNotBlank()) out.add(CoachBlock.Para(para.toString().trim()))
        para.setLength(0)
    }
    var i = 0
    while (i < lines.size) {
        val line = lines[i]
        val t = line.trim()
        if (t.isEmpty() || RuleRegex.matches(line)) {
            flush()
        } else if (t.startsWith("|")) {
            flush()
            val rows = ArrayList<List<String>>()
            while (i < lines.size && lines[i].trim().startsWith("|")) {
                if (!isTableSeparator(lines[i])) rows.add(tableCells(lines[i]))
                i++
            }
            i--
            tableToBullets(rows, out)
        } else {
            val heading = HeadingRegex.find(line)
            val bullet = BulletRegex.find(line)
            val number = NumberRegex.find(line)
            if (heading != null) {
                flush()
                out.add(CoachBlock.Heading(heading.groupValues[1]))
            } else if (bullet != null) {
                flush()
                out.add(CoachBlock.Bullet(bullet.groupValues[2], if (bullet.groupValues[1].length >= 2) 1 else 0))
            } else if (number != null) {
                flush()
                out.add(CoachBlock.Numbered(number.groupValues[1], number.groupValues[2]))
            } else if (t.startsWith(">")) {
                flush()
                out.add(CoachBlock.Para(t.trimStart('>').trim()))
            } else {
                if (para.isNotEmpty()) para.append('\n')
                para.append(t)
            }
        }
        i++
    }
    flush()
    return out
}

/** Gaya sebaris: **tebal**, *miring*, `kode`. Penanda yang tidak berpasangan dibiarkan apa adanya. */
internal fun coachInline(src: String, codeBg: Color): AnnotatedString = buildAnnotatedString {
    var i = 0
    val n = src.length
    while (i < n) {
        val c = src[i]
        if (c == '*' && src.startsWith("**", i)) {
            val end = src.indexOf("**", i + 2)
            if (end > i + 2) {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(coachInline(src.substring(i + 2, end), codeBg)) }
                i = end + 2
                continue
            }
        }
        if (c == '*' && i + 1 < n && !src[i + 1].isWhitespace() && src[i + 1] != '*') {
            var j = src.indexOf('*', i + 1)
            while (j != -1 && (src[j - 1].isWhitespace() || (j + 1 < n && src[j + 1] == '*'))) j = src.indexOf('*', j + 1)
            if (j > i + 1) {
                withStyle(SpanStyle(fontStyle = FontStyle.Italic)) { append(coachInline(src.substring(i + 1, j), codeBg)) }
                i = j + 1
                continue
            }
        }
        if (c == '`') {
            val end = src.indexOf('`', i + 1)
            if (end > i + 1) {
                withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = codeBg)) { append(src.substring(i + 1, end)) }
                i = end + 1
                continue
            }
        }
        append(c)
        i++
    }
}

@Composable
internal fun CoachMarkdown(text: String, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val blocks = remember(text) { parseCoachBlocks(text) }
    val codeBg = cs.onSurface.copy(alpha = 0.08f)
    val body = MaterialTheme.typography.bodyMedium
    Column(modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        blocks.forEach { b ->
            when (b) {
                is CoachBlock.Heading ->
                    androidx.compose.material3.Text(coachInline(b.text, codeBg), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                is CoachBlock.Para ->
                    androidx.compose.material3.Text(coachInline(b.text, codeBg), style = body)
                is CoachBlock.Bullet ->
                    Row(Modifier.padding(start = (b.level * 14).dp)) {
                        androidx.compose.material3.Text("•", style = body, modifier = Modifier.width(14.dp))
                        androidx.compose.material3.Text(coachInline(b.text, codeBg), style = body, modifier = Modifier.weight(1f))
                    }
                is CoachBlock.Numbered ->
                    Row {
                        androidx.compose.material3.Text("${b.n}.", style = body, modifier = Modifier.width(22.dp))
                        androidx.compose.material3.Text(coachInline(b.text, codeBg), style = body, modifier = Modifier.weight(1f))
                    }
            }
        }
    }
}
