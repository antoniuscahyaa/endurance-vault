package com.endurancevault.app.ui.video

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import com.endurancevault.app.data.TerrainScene
import com.endurancevault.app.domain.FrameStats
import com.endurancevault.app.domain.GhostInfo
import com.endurancevault.app.domain.RouteVideoColors
import com.endurancevault.app.domain.RouteVideoGrid
import com.endurancevault.app.domain.RouteVideoPrefs
import com.endurancevault.app.domain.RouteVideoText
import com.endurancevault.app.domain.RouteVideoTrack
import com.endurancevault.app.domain.VideoPanel
import com.endurancevault.app.domain.seriesSamples
import com.endurancevault.app.ui.sticker.StickerFonts
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Bendera di peta (posisi layar dalam piksel bingkai). [kind]: start, finish, km, peak, steep, fast, hrmax. */
class ScreenMark(val kind: String, val title: String, val sub: String, val x: Float, val y: Float, val alpha: Float, val priority: Int)

/**
 * Menggambar bendera, panel data, dan kartu ringkasan di atas bingkai. Panel menempati kotak grid dan isinya diskalakan
 * agar pas; tanpa latar (transparan penuh). Satuan skala: sisi pendek bingkai 1080 px = 1 unit [u0], jadi pratinjau
 * (setengah ukuran) dan video tampak sama di semua rasio. Fungsi [draw] mengembalikan kotak tiap panel (piksel bingkai)
 * untuk pemilihan di pratinjau.
 */
object RouteVideoOverlay {
    // Pratinjau (thread UI) dan render video (thread GL) bisa berjalan bersamaan, jadi tiap thread punya Paint sendiri.
    private val paintTL = ThreadLocal.withInitial { Paint(Paint.ANTI_ALIAS_FLAG) }
    private val paint: Paint get() = paintTL.get()!!

    fun accentOf(prefs: RouteVideoPrefs): Int = runCatching { Color.parseColor(prefs.lineColor) }.getOrDefault(0xFFC6F432.toInt())

    private fun inkOf(k: String): Int = when (k) { "k" -> 0xFF111111.toInt(); "l" -> 0xFFC6F432.toInt(); else -> Color.WHITE }

    private fun withAlpha(c: Int, a: Float): Int = Color.argb((a * 255).roundToInt().coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    /**
     * Ubah titik layar hasil proyeksi menjadi bendera yang terlihat pada [frac] (bagian jarak aktivitas utama).
     * Urutan hasil menurut prioritas: finish, start, puncak, tanjakan, km tercepat, HR tertinggi, lalu km.
     */
    fun marksFor(scene: TerrainScene, pts: List<ProjectedPoint>, track: RouteVideoTrack, prefs: RouteVideoPrefs, frac: Double): List<ScreenMark> {
        val out = ArrayList<ScreenMark>()
        for (p in pts) {
            val a = scene.anchors.getOrNull(p.anchorIndex)?.anchor ?: continue
            if (!prefs.showsAnchor(a.kind)) continue
            val alpha = when (a.kind) {
                "start" -> 1f
                "finish" -> if (!prefs.live) 1f else ((frac - 0.97) / 0.03).toFloat().coerceIn(0f, 1f)
                else -> if (!prefs.live) 1f else ((frac - a.frac) / 0.012).toFloat().coerceIn(0f, 1f)
            }
            if (alpha <= 0.01f) continue
            val (title, sub) = RouteVideoText.anchorLabel(a, track)
            val pr = when (a.kind) { "finish" -> 0; "start" -> 1; "peak" -> 2; "steep" -> 3; "fast" -> 4; "hrmax" -> 5; else -> 6 }
            out.add(ScreenMark(a.kind, title, sub, p.x, p.y, alpha, pr))
        }
        return out.sortedBy { it.priority }
    }

    /**
     * Gambar semua lapisan 2D. [selected] (kunci panel) menampilkan garis grid bantu dan bingkai putus-putus di panel itu;
     * kirim null saat render video. [summaryAlpha] (0..1) memudarkan panel dan memunculkan kartu ringkasan.
     */
    fun draw(
        c: Canvas, w: Int, h: Int, prefs: RouteVideoPrefs, track: RouteVideoTrack, st: FrameStats,
        progress: Double, fonts: StickerFonts, selected: String?,
        marks: List<ScreenMark> = emptyList(), ghost: GhostInfo? = null, summaryAlpha: Double = 0.0,
    ): Map<String, RectF> {
        val ink = inkOf(prefs.ink)
        val ink2 = withAlpha(ink, .78f)
        val accent = accentOf(prefs)
        val darkInk = prefs.ink == "k"
        val numFace = fonts.num ?: Typeface.create("sans-serif-condensed", Typeface.BOLD)
        val bodyFace = fonts.body ?: Typeface.create("sans-serif-medium", Typeface.NORMAL)
        val u0 = min(w, h) / 1080f
        val out = LinkedHashMap<String, RectF>()
        drawMarks(c, marks, w, h, u0, numFace, bodyFace)

        val sa = summaryAlpha.toFloat().coerceIn(0f, 1f)
        val layer = if (sa > 0.001f) c.saveLayerAlpha(0f, 0f, w.toFloat(), h.toFloat(), ((1f - sa) * 255).roundToInt()) else -1
        if (selected != null) drawGrid(c, w, h, prefs, accent, u0)
        for (p in prefs.panels) {
            val r = RouteVideoGrid.rect(p, w, h, prefs.gridCols, prefs.gridRows, prefs.gridGapX, prefs.gridGapY)
            val cell = RectF(r[0].toFloat(), r[1].toFloat(), r[2].toFloat(), r[3].toFloat())
            if (!drawPanel(c, p, cell, u0, prefs, track, st, progress, ghost, numFace, bodyFace, ink, ink2, accent, !darkInk)) continue
            if (selected == p.key) {
                paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.STROKE
                paint.color = accent; paint.strokeWidth = max(2f, 3f * u0); paint.pathEffect = DashPathEffect(floatArrayOf(14f * u0, 10f * u0), 0f)
                c.drawRoundRect(cell, 10f * u0, 10f * u0, paint)
            }
            out[p.key] = cell
        }
        if (layer >= 0) c.restoreToCount(layer)
        if (sa > 0.001f) drawSummary(c, w, h, prefs, track, numFace, bodyFace, ink, darkInk, sa, u0)
        return out
    }

    private fun txt(
        c: Canvas, s: String, x: Float, y: Float, px: Float, face: Typeface, col: Int, align: Paint.Align, shadow: Boolean, u: Float,
    ) {
        paint.reset(); paint.isAntiAlias = true; paint.typeface = face; paint.textSize = px; paint.color = col; paint.textAlign = align
        if (shadow) paint.setShadowLayer(10f * u, 0f, 3f * u, Color.argb(130, 0, 0, 0))
        c.drawText(s, x, y, paint)
    }

    private fun width(s: String, px: Float, face: Typeface): Float {
        paint.reset(); paint.isAntiAlias = true; paint.typeface = face; paint.textSize = px
        return paint.measureText(s)
    }

    private fun ellipsize(s: String, px: Float, face: Typeface, maxW: Float): String {
        if (width(s, px, face) <= maxW) return s
        var t = s
        while (t.length > 1 && width("$t…", px, face) > maxW) t = t.dropLast(1)
        return "$t…"
    }

    // ---- Panel ----

    /** Gambar satu panel di [cell]; false bila tidak ada yang bisa digambar (mis. tanpa data HR). */
    private fun drawPanel(
        c: Canvas, p: VideoPanel, cell: RectF, u0: Float, prefs: RouteVideoPrefs, track: RouteVideoTrack, st: FrameStats,
        progress: Double, ghost: GhostInfo?, num: Typeface, body: Typeface, ink: Int, ink2: Int, accent: Int, shadow: Boolean,
    ): Boolean = when (p.key) {
        "judul" -> { drawTitle(c, cell, u0, prefs, track, num, body, ink, ink2, shadow); true }
        "profil", "grafikhr", "grafikpace" -> drawChart(c, p.key, cell, u0, prefs, track, progress, body, ink2, ink, accent, shadow)
        "legenda" -> drawLegend(c, cell, u0, prefs, track, body, ink2, shadow)
        "ghost" -> ghost?.let { drawStat(c, RouteVideoText.ghostCell(it), cell, u0, num, body, ink, ink2, shadow); true } ?: false
        else -> RouteVideoText.cell(p.key, st, prefs.live, track.bike)?.let { drawStat(c, it, cell, u0, num, body, ink, ink2, shadow); true } ?: false
    }

    /** Label kecil di atas, nilai besar, satuan di kanan nilai; diskalakan agar pas di [cell] dan rata kiri. */
    private fun drawStat(
        c: Canvas, cell: RouteVideoText.Cell, rect: RectF, u0: Float, num: Typeface, body: Typeface, ink: Int, ink2: Int, sh: Boolean,
    ) {
        val lw = width(cell.label, 26f * u0, body) + cell.label.length * 1.5f * u0
        val vw = width(cell.value, 92f * u0, num)
        val uw = if (cell.unit.isEmpty()) 0f else 10f * u0 + width(cell.unit, 34f * u0, body)
        val natW = max(lw, vw + uw); val natH = 110f * u0
        val k = min(rect.width() / natW, rect.height() / natH).coerceIn(0.3f, 1.2f)
        val u = u0 * k
        val top = rect.top + (rect.height() - natH * k) / 2
        txt(c, cell.label, rect.left, top + 22f * u, 26f * u, body, ink2, Paint.Align.LEFT, sh, u)
        val base = top + (26f + 8f + 72f) * u
        txt(c, cell.value, rect.left, base, 92f * u, num, ink, Paint.Align.LEFT, sh, u)
        if (cell.unit.isNotEmpty()) {
            val vwk = width(cell.value, 92f * u, num)
            txt(c, cell.unit, rect.left + vwk + 10f * u, base, 34f * u, body, ink2, Paint.Align.LEFT, sh, u)
        }
    }

    // ---- Judul: baris 1 judul sendiri atau nama aktivitas, baris 2 teks bebas, baris 3 tanggal ----

    private fun drawTitle(
        c: Canvas, rect: RectF, u0: Float, prefs: RouteVideoPrefs, track: RouteVideoTrack,
        num: Typeface, body: Typeface, ink: Int, ink2: Int, sh: Boolean,
    ) {
        val l1 = prefs.titleText.trim().ifBlank { track.title }
        val l2 = prefs.subtitle.trim()
        val l3 = if (prefs.showDate) track.dateText else ""
        var natH = 56f * u0
        if (l2.isNotEmpty()) natH += 36f * u0
        if (l3.isNotEmpty()) natH += 32f * u0
        var natW = max(width(l1, 48f * u0, num), max(if (l2.isEmpty()) 0f else width(l2, 30f * u0, body), if (l3.isEmpty()) 0f else width(l3, 26f * u0, body)))
        natW = min(natW, rect.width() / 0.75f)    // judul panjang: diperkecil paling banyak ke 75%, sisanya dipotong
        val k = min(rect.width() / natW.coerceAtLeast(1f), rect.height() / natH).coerceIn(0.3f, 1.2f)
        val u = u0 * k
        var y = rect.top + 44f * u
        txt(c, ellipsize(l1, 48f * u, num, rect.width()), rect.left, y, 48f * u, num, ink, Paint.Align.LEFT, sh, u)
        if (l2.isNotEmpty()) { y += 36f * u; txt(c, ellipsize(l2, 30f * u, body, rect.width()), rect.left, y, 30f * u, body, ink2, Paint.Align.LEFT, sh, u) }
        if (l3.isNotEmpty()) { y += 32f * u; txt(c, l3, rect.left, y, 26f * u, body, ink2, Paint.Align.LEFT, sh, u) }
    }

    // ---- Grafik (elevasi, pace/kecepatan, detak jantung) ----

    private class Chart(val title: String, val range: String, val samples: DoubleArray, val lo: Double, val hi: Double)

    private fun chartOf(key: String, track: RouteVideoTrack): Chart? = when (key) {
        "profil" -> {
            val s = track.profileSamples(180)
            val fin = s.filter { it.isFinite() }
            if (fin.isEmpty()) null else {
                val lo = fin.min(); val hi = max(fin.max(), lo + 10.0)
                Chart("ELEVASI", "${lo.roundToInt()}–${hi.roundToInt()} m", s, lo, hi)
            }
        }
        "grafikhr" -> RouteVideoColors.info(track, "hr")?.let { info ->
            val s = track.seriesSamples("hr", info.values)
            if (s.none { it.isFinite() }) null
            else Chart("DETAK JANTUNG", "${info.lo.roundToInt()}–${info.hi.roundToInt()} bpm", s, info.lo, info.hi)
        }
        else -> RouteVideoColors.info(track, "pace")?.let { info ->
            val s = track.seriesSamples("pace", info.values)
            if (s.none { it.isFinite() }) null
            // Sumbu y = kecepatan (naik = lebih cepat); label menampilkan pace tercepat dan terlambat.
            else Chart(if (track.bike) "KECEPATAN" else "PACE", "${info.hiText} – ${info.loText}", s, info.lo, info.hi)
        }
    }

    private fun drawChart(
        c: Canvas, key: String, rect: RectF, u0: Float, prefs: RouteVideoPrefs, track: RouteVideoTrack, progress: Double,
        body: Typeface, ink2: Int, ink: Int, accent: Int, sh: Boolean,
    ): Boolean {
        val ch = chartOf(key, track) ?: return false
        val u = u0 * min(rect.width() / (880f * u0), rect.height() / (210f * u0)).coerceIn(0.4f, 1.3f)
        val pad = 4f * u
        val x0 = rect.left + pad; val x1 = rect.right - pad
        val y0 = rect.top + pad + 30f * u; val y1 = rect.bottom - pad
        if (y1 - y0 < 8f) return true
        val span = max(ch.hi - ch.lo, 1e-6)
        val n = ch.samples.size
        val pts = ch.samples.mapIndexed { i, v ->
            val x = x0 + (x1 - x0) * i / (n - 1)
            val t = (((if (v.isFinite()) v else ch.lo).coerceIn(ch.lo, ch.hi) - ch.lo) / span).toFloat() * 0.92f + 0.04f
            x to (y1 - t * (y1 - y0))
        }
        val doneIdx = if (prefs.live) (progress.coerceIn(0.0, 1.0) * (n - 1)).roundToInt() else n - 1

        fun area(upTo: Int): Path = Path().also { p ->
            p.moveTo(pts[0].first, y1)
            for (i in 0..upTo) p.lineTo(pts[i].first, pts[i].second)
            p.lineTo(pts[upTo].first, y1); p.close()
        }
        paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.FILL
        paint.color = withAlpha(ink, if (prefs.ink == "k") .14f else .16f); c.drawPath(area(n - 1), paint)
        if (doneIdx > 0) { paint.color = withAlpha(accent, .45f); c.drawPath(area(doneIdx), paint) }

        val line = Path().also { p -> pts.forEachIndexed { i, q -> if (i == 0) p.moveTo(q.first, q.second) else p.lineTo(q.first, q.second) } }
        paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.STROKE; paint.strokeWidth = 4f * u
        paint.strokeJoin = Paint.Join.ROUND; paint.strokeCap = Paint.Cap.ROUND
        paint.color = ink2; c.drawPath(line, paint)
        if (doneIdx > 0) {
            val done = Path().also { p -> for (i in 0..doneIdx) if (i == 0) p.moveTo(pts[i].first, pts[i].second) else p.lineTo(pts[i].first, pts[i].second) }
            paint.color = accent; paint.strokeWidth = 5f * u; c.drawPath(done, paint)
        }
        if (prefs.live) {
            val q = pts[min(doneIdx, pts.size - 1)]
            paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.FILL; paint.color = Color.WHITE
            c.drawCircle(q.first, q.second, 9f * u, paint)
            paint.color = accent; c.drawCircle(q.first, q.second, 5.5f * u, paint)
        }
        txt(c, ch.title, x0, rect.top + pad + 22f * u, 22f * u, body, ink2, Paint.Align.LEFT, sh, u)
        txt(c, ch.range, x1, rect.top + pad + 22f * u, 22f * u, body, ink2, Paint.Align.RIGHT, sh, u)
        return true
    }

    // ---- Legenda warna garis ----

    private fun drawLegend(c: Canvas, rect: RectF, u0: Float, prefs: RouteVideoPrefs, track: RouteVideoTrack, body: Typeface, ink2: Int, sh: Boolean): Boolean {
        val info = RouteVideoColors.info(track, prefs.lineMode) ?: return false
        val u = u0 * min(rect.height() / (80f * u0), 1.2f).coerceAtLeast(0.3f)
        val top = rect.top + (rect.height() - 80f * u) / 2
        val x0 = rect.left; val x1 = rect.right
        val y0 = top + 34f * u; val y1 = y0 + 16f * u
        txt(c, info.title, x0, top + 22f * u, 26f * u, body, ink2, Paint.Align.LEFT, sh, u)
        val cols = RouteVideoColors.legendColors(prefs.lineMode, 24)
        val seg = (x1 - x0) / cols.size
        paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.FILL
        for (i in cols.indices) { paint.color = cols[i]; c.drawRect(x0 + seg * i, y0, x0 + seg * (i + 1) + 1f, y1, paint) }
        txt(c, info.loText, x0, y1 + 28f * u, 22f * u, body, ink2, Paint.Align.LEFT, sh, u)
        txt(c, info.hiText, x1, y1 + 28f * u, 22f * u, body, ink2, Paint.Align.RIGHT, sh, u)
        return true
    }

    // ---- Garis grid bantu (hanya di pratinjau saat panel dipilih) ----

    private fun drawGrid(c: Canvas, w: Int, h: Int, prefs: RouteVideoPrefs, accent: Int, u0: Float) {
        val a = RouteVideoGrid.area(w, h)
        paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.STROKE
        paint.color = withAlpha(accent, .5f); paint.strokeWidth = max(1f, 1.5f * u0)
        paint.pathEffect = DashPathEffect(floatArrayOf(8f * u0, 8f * u0), 0f)
        val l = a.left.toFloat(); val t = a.top.toFloat(); val r = (a.left + a.width).toFloat(); val b = (a.top + a.height).toFloat()
        for (i in 0..prefs.gridCols) { val x = (a.left + a.width * i / prefs.gridCols).toFloat(); c.drawLine(x, t, x, b, paint) }
        for (j in 0..prefs.gridRows) { val y = (a.top + a.height * j / prefs.gridRows).toFloat(); c.drawLine(l, y, r, y, paint) }
    }

    // ---- Kartu ringkasan di akhir video ----

    private fun drawSummary(
        c: Canvas, w: Int, h: Int, prefs: RouteVideoPrefs, track: RouteVideoTrack,
        num: Typeface, body: Typeface, inkColor: Int, darkInk: Boolean, alpha: Float, u0: Float,
    ) {
        // Peredup layar penuh (bukan kartu) supaya angka terbaca di atas peta.
        c.drawColor(if (darkInk) Color.argb((alpha * 165).roundToInt(), 255, 255, 255) else Color.argb((alpha * 165).roundToInt(), 0, 0, 0))
        val st = track.statsAt(1.0, false)
        val keys = arrayListOf("jarak", "waktu", "pace", "gain")
        if (st.hr != null) keys += "hr"
        if ((st.cad ?: 0) > 0) keys += "cad"
        val cells = keys.mapNotNull { RouteVideoText.cell(it, st, false, track.bike) }
        val rows = (cells.size + 1) / 2
        val l1 = prefs.titleText.trim().ifBlank { track.title }
        val l2 = prefs.subtitle.trim()
        val l3 = if (prefs.showDate) track.dateText else ""
        var titleH = 72f * u0
        if (l2.isNotEmpty()) titleH += 40f * u0
        if (l3.isNotEmpty()) titleH += 36f * u0
        val rowH = 190f * u0; val gap = 64f * u0
        var y = (h - (titleH + gap + rows * rowH)) / 2
        val sh = !darkInk
        val ink = withAlpha(inkColor, alpha); val ink2 = withAlpha(inkColor, .78f * alpha)
        val cx0 = w / 2f
        y += 58f * u0
        txt(c, ellipsize(l1, 64f * u0, num, w * 0.88f), cx0, y, 64f * u0, num, ink, Paint.Align.CENTER, sh, u0)
        if (l2.isNotEmpty()) { y += 42f * u0; txt(c, ellipsize(l2, 34f * u0, body, w * 0.88f), cx0, y, 34f * u0, body, ink2, Paint.Align.CENTER, sh, u0) }
        if (l3.isNotEmpty()) { y += 38f * u0; txt(c, l3, cx0, y, 30f * u0, body, ink2, Paint.Align.CENTER, sh, u0) }
        y += 14f * u0 + gap
        cells.forEachIndexed { i, cell ->
            val row = i / 2; val single = (i == cells.size - 1) && (cells.size % 2 == 1)
            val cx = if (single) cx0 else w * (0.27f + 0.46f * (i % 2))
            val top = y + row * rowH
            val vw = width(cell.value, 104f * u0, num)
            val uw = if (cell.unit.isEmpty()) 0f else 12f * u0 + width(cell.unit, 38f * u0, body)
            txt(c, cell.label, cx, top + 30f * u0, 28f * u0, body, ink2, Paint.Align.CENTER, sh, u0)
            val left = cx - (vw + uw) / 2
            txt(c, cell.value, left, top + 138f * u0, 104f * u0, num, ink, Paint.Align.LEFT, sh, u0)
            if (cell.unit.isNotEmpty()) txt(c, cell.unit, left + vw + 12f * u0, top + 138f * u0, 38f * u0, body, ink2, Paint.Align.LEFT, sh, u0)
        }
    }

    // ---- Bendera di peta ----

    private fun drawMarks(c: Canvas, marks: List<ScreenMark>, w: Int, h: Int, u: Float, num: Typeface, body: Typeface) {
        val drawn = ArrayList<RectF>()
        for (m in marks) {
            val tw = width(m.title, 24f * u, num)
            val sw = if (m.sub.isEmpty()) 0f else width(m.sub, 21f * u, body)
            val bw = max(tw, sw) + 26f * u
            val bh = if (m.sub.isEmpty()) 42f * u else 66f * u
            val pole = 56f * u
            val box = RectF(m.x - bw / 2, m.y - pole - bh, m.x + bw / 2, m.y - pole)
            if (box.right < 0 || box.left > w || box.bottom < 0 || box.top > h) continue
            if (drawn.any { RectF.intersects(it, box) }) continue
            drawn.add(box)
            val (bg, fg) = when (m.kind) {
                "start" -> 0xFF2ECC71.toInt() to 0xFF0B1F12.toInt()
                "finish" -> Color.WHITE to 0xFF111111.toInt()
                "peak" -> 0xFFFF9F1C.toInt() to 0xFF1A1100.toInt()
                "steep" -> 0xFFEB4D4B.toInt() to Color.WHITE
                "fast" -> 0xFFB388FF.toInt() to 0xFF14002E.toInt()
                "hrmax" -> 0xFFFF5C8A.toInt() to Color.WHITE
                else -> 0xFF111111.toInt() to Color.WHITE
            }
            paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.STROKE
            paint.strokeWidth = max(2f, 3f * u); paint.color = withAlpha(Color.WHITE, m.alpha * .9f)
            c.drawLine(m.x, m.y, m.x, box.bottom, paint)
            paint.style = Paint.Style.FILL; c.drawCircle(m.x, m.y, 6f * u, paint)
            paint.color = withAlpha(bg, m.alpha * .94f); c.drawRoundRect(box, 14f * u, 14f * u, paint)
            val cx = (box.left + box.right) / 2
            if (m.sub.isEmpty()) {
                txt(c, m.title, cx, box.top + 29f * u, 24f * u, num, withAlpha(fg, m.alpha), Paint.Align.CENTER, false, u)
            } else {
                txt(c, m.title, cx, box.top + 28f * u, 24f * u, num, withAlpha(fg, m.alpha), Paint.Align.CENTER, false, u)
                txt(c, m.sub, cx, box.top + 54f * u, 21f * u, body, withAlpha(fg, m.alpha * .85f), Paint.Align.CENTER, false, u)
            }
        }
    }
}
