package com.endurancevault.app.ui.video

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import com.endurancevault.app.data.TerrainScene
import com.endurancevault.app.domain.FrameStats
import com.endurancevault.app.domain.GhostInfo
import com.endurancevault.app.domain.RouteVideoColors
import com.endurancevault.app.domain.RouteVideoPrefs
import com.endurancevault.app.domain.RouteVideoText
import com.endurancevault.app.domain.RouteVideoTrack
import com.endurancevault.app.ui.sticker.StickerFonts
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Bendera di peta (posisi layar dalam piksel bingkai). [kind]: start, finish, km, peak, steep. */
class ScreenMark(val kind: String, val title: String, val sub: String, val x: Float, val y: Float, val alpha: Float, val priority: Int)

/**
 * Menggambar panel data di atas bingkai. Satuan skala: sisi pendek bingkai 1080 px = 1 unit [u] pada ukuran panel 100%,
 * jadi pratinjau (setengah ukuran) dan video tampak sama di semua rasio. Mengembalikan kotak tiap panel (piksel bingkai) untuk
 * pemilihan dan penyeretan di pratinjau.
 */
object RouteVideoOverlay {
    // Pratinjau (thread UI) dan render video (thread GL) bisa berjalan bersamaan, jadi tiap thread punya Paint sendiri.
    private val paintTL = ThreadLocal.withInitial { Paint(Paint.ANTI_ALIAS_FLAG) }
    private val paint: Paint get() = paintTL.get()!!

    fun accentOf(prefs: RouteVideoPrefs): Int = runCatching { Color.parseColor(prefs.lineColor) }.getOrDefault(0xFFC6F432.toInt())

    private fun inkOf(k: String): Int = when (k) { "k" -> 0xFF111111.toInt(); "l" -> 0xFFC6F432.toInt(); else -> Color.WHITE }

    private fun withAlpha(c: Int, a: Float): Int = Color.argb((a * 255).roundToInt().coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    /**
     * Ubah titik layar hasil proyeksi menjadi bendera yang terlihat pada [frac] (bagian jarak aktivitas utama).
     * Urutan hasil menurut prioritas: finish, start, puncak, tanjakan, lalu km.
     */
    fun marksFor(scene: TerrainScene, pts: List<ProjectedPoint>, track: RouteVideoTrack, prefs: RouteVideoPrefs, frac: Double): List<ScreenMark> {
        val out = ArrayList<ScreenMark>()
        for (p in pts) {
            val a = scene.anchors.getOrNull(p.anchorIndex)?.anchor ?: continue
            if (!prefs.showsAnchor(a.kind)) continue
            val alpha = when (a.kind) {
                "start" -> 1f
                "finish" -> if (!prefs.live) 1f else ((frac - 0.97) / 0.03).toFloat().coerceIn(0f, 1f)
                else -> if (!prefs.live) 1f else ((frac - a.frac) / 0.012).toFloat().coerceIn(0f, 1f)
            }
            if (alpha <= 0.01f) continue
            val (title, sub) = RouteVideoText.anchorLabel(a, track)
            val pr = when (a.kind) { "finish" -> 0; "start" -> 1; "peak" -> 2; "steep" -> 3; else -> 4 }
            out.add(ScreenMark(a.kind, title, sub, p.x, p.y, alpha, pr))
        }
        return out.sortedBy { it.priority }
    }

    fun draw(
        c: Canvas, w: Int, h: Int, prefs: RouteVideoPrefs, track: RouteVideoTrack, st: FrameStats,
        progress: Double, fonts: StickerFonts, selected: String?,
        marks: List<ScreenMark> = emptyList(), ghost: GhostInfo? = null,
    ): Map<String, RectF> {
        val ink = inkOf(prefs.ink)
        val ink2 = withAlpha(ink, .78f)
        val accent = accentOf(prefs)
        val darkInk = prefs.ink == "k"
        val numFace = fonts.num ?: Typeface.create("sans-serif-condensed", Typeface.BOLD)
        val bodyFace = fonts.body ?: Typeface.create("sans-serif-medium", Typeface.NORMAL)
        val out = LinkedHashMap<String, RectF>()
        drawMarks(c, marks, w, h, min(w, h) / 1080f, numFace, bodyFace)

        for (p in prefs.panels) {
            val u = min(w, h) / 1080f * p.size / 100f
            val pad = 16f * u
            val ox = (p.x / 100.0 * w).toFloat(); val oy = (p.y / 100.0 * h).toFloat()

            // Isi panel digambar dua kali bila perlu latar: ukur dulu, gambar latar, lalu isinya.
            val box: RectF = when (p.key) {
                "judul" -> measureTitle(track, u, numFace, bodyFace, w, pad, ox, oy)
                "profil" -> RectF(ox, oy, ox + 880f * u + 2 * pad, oy + 210f * u + 2 * pad)
                "legenda" -> {
                    if (RouteVideoColors.info(track, prefs.lineMode) == null) continue
                    RectF(ox, oy, ox + 560f * u + 2 * pad, oy + 80f * u + 2 * pad)
                }
                "ghost" -> {
                    val g = ghost ?: continue
                    measureStat(RouteVideoText.ghostCell(g), u, numFace, bodyFace, pad, ox, oy)
                }
                else -> {
                    val cell = RouteVideoText.cell(p.key, st, prefs.live, track.bike) ?: continue
                    measureStat(cell, u, numFace, bodyFace, pad, ox, oy)
                }
            }
            if (prefs.panelBg != "off") {
                val a = if (prefs.panelBg == "strong") .62f else .38f
                paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.FILL
                paint.color = if (darkInk) Color.argb(((a + .14f) * 255).roundToInt(), 255, 255, 255) else Color.argb((a * 255).roundToInt(), 0, 0, 0)
                c.drawRoundRect(box, 22f * u, 22f * u, paint)
            }
            when (p.key) {
                "judul" -> drawTitle(c, track, u, numFace, bodyFace, ink, ink2, darkInk, box, pad)
                "profil" -> drawProfile(c, track, prefs, progress, u, ink, ink2, accent, bodyFace, darkInk, box, pad)
                "legenda" -> drawLegend(c, track, prefs, u, bodyFace, ink2, darkInk, box, pad)
                "ghost" -> {
                    val g = ghost ?: continue
                    drawStat(c, RouteVideoText.ghostCell(g), u, numFace, bodyFace, ink, ink2, darkInk, box, pad)
                }
                else -> {
                    val cell = RouteVideoText.cell(p.key, st, prefs.live, track.bike) ?: continue
                    drawStat(c, cell, u, numFace, bodyFace, ink, ink2, darkInk, box, pad)
                }
            }
            if (selected == p.key) {
                paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.STROKE
                paint.color = accent; paint.strokeWidth = max(2f, 3f * u); paint.pathEffect = DashPathEffect(floatArrayOf(14f * u, 10f * u), 0f)
                c.drawRoundRect(box, 22f * u, 22f * u, paint)
            }
            out[p.key] = box
        }
        return out
    }

    private fun txt(
        c: Canvas, s: String, x: Float, y: Float, px: Float, face: Typeface, col: Int, align: Paint.Align, shadow: Boolean, u: Float,
    ) {
        paint.reset(); paint.isAntiAlias = true; paint.typeface = face; paint.textSize = px; paint.color = col; paint.textAlign = align
        if (shadow) paint.setShadowLayer(10f * u, 0f, 3f * u, Color.argb(115, 0, 0, 0))
        c.drawText(s, x, y, paint)
    }

    private fun width(s: String, px: Float, face: Typeface): Float {
        paint.reset(); paint.isAntiAlias = true; paint.typeface = face; paint.textSize = px
        return paint.measureText(s)
    }

    // ---- Panel angka: label kecil di atas, nilai besar, satuan di kanan nilai ----

    private fun measureStat(cell: RouteVideoText.Cell, u: Float, num: Typeface, body: Typeface, pad: Float, ox: Float, oy: Float): RectF {
        val lw = width(cell.label, 26f * u, body) + cell.label.length * 1.5f * u
        val vw = width(cell.value, 92f * u, num)
        val uw = if (cell.unit.isEmpty()) 0f else 10f * u + width(cell.unit, 34f * u, body)
        return RectF(ox, oy, ox + max(lw, vw + uw) + 2 * pad, oy + (26f + 8f + 76f) * u + 2 * pad)
    }

    private fun drawStat(
        c: Canvas, cell: RouteVideoText.Cell, u: Float, num: Typeface, body: Typeface,
        ink: Int, ink2: Int, darkInk: Boolean, box: RectF, pad: Float,
    ) {
        val sh = !darkInk
        txt(c, cell.label, box.left + pad, box.top + pad + 22f * u, 26f * u, body, ink2, Paint.Align.LEFT, sh, u)
        val base = box.top + pad + (26f + 8f + 72f) * u
        txt(c, cell.value, box.left + pad, base, 92f * u, num, ink, Paint.Align.LEFT, sh, u)
        if (cell.unit.isNotEmpty()) {
            val vw = width(cell.value, 92f * u, num)
            txt(c, cell.unit, box.left + pad + vw + 10f * u, base, 34f * u, body, ink2, Paint.Align.LEFT, sh, u)
        }
    }

    // ---- Judul ----

    private fun ellipsize(s: String, px: Float, face: Typeface, maxW: Float): String {
        if (width(s, px, face) <= maxW) return s
        var t = s
        while (t.length > 1 && width("$t…", px, face) > maxW) t = t.dropLast(1)
        return "$t…"
    }

    private fun measureTitle(track: RouteVideoTrack, u: Float, num: Typeface, body: Typeface, w: Int, pad: Float, ox: Float, oy: Float): RectF {
        val maxW = max(120f * u, w * 0.88f - ox - 2 * pad)
        val t = ellipsize(track.title, 48f * u, num, maxW)
        val tw = max(width(t, 48f * u, num), width(track.dateText, 28f * u, body))
        return RectF(ox, oy, ox + tw + 2 * pad, oy + (48f + 10f + 28f) * u + 2 * pad)
    }

    private fun drawTitle(
        c: Canvas, track: RouteVideoTrack, u: Float, num: Typeface, body: Typeface,
        ink: Int, ink2: Int, darkInk: Boolean, box: RectF, pad: Float,
    ) {
        val sh = !darkInk
        val maxW = box.width() - 2 * pad
        txt(c, ellipsize(track.title, 48f * u, num, maxW), box.left + pad, box.top + pad + 42f * u, 48f * u, num, ink, Paint.Align.LEFT, sh, u)
        txt(c, track.dateText, box.left + pad, box.top + pad + (48f + 10f + 24f) * u, 28f * u, body, ink2, Paint.Align.LEFT, sh, u)
    }

    // ---- Legenda warna garis ----

    private fun drawLegend(
        c: Canvas, track: RouteVideoTrack, prefs: RouteVideoPrefs, u: Float, body: Typeface,
        ink2: Int, darkInk: Boolean, box: RectF, pad: Float,
    ) {
        val info = RouteVideoColors.info(track, prefs.lineMode) ?: return
        val sh = !darkInk
        val x0 = box.left + pad; val x1 = box.right - pad
        val y0 = box.top + pad + 34f * u; val y1 = y0 + 16f * u
        txt(c, info.title, x0, box.top + pad + 22f * u, 26f * u, body, ink2, Paint.Align.LEFT, sh, u)
        val cols = RouteVideoColors.legendColors(prefs.lineMode, 24)
        val seg = (x1 - x0) / cols.size
        paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.FILL
        for (i in cols.indices) { paint.color = cols[i]; c.drawRect(x0 + seg * i, y0, x0 + seg * (i + 1) + 1f, y1, paint) }
        txt(c, info.loText, x0, y1 + 28f * u, 22f * u, body, ink2, Paint.Align.LEFT, sh, u)
        txt(c, info.hiText, x1, y1 + 28f * u, 22f * u, body, ink2, Paint.Align.RIGHT, sh, u)
    }

    // ---- Bendera di peta ----

    private fun drawMarks(c: Canvas, marks: List<ScreenMark>, w: Int, h: Int, u: Float, num: Typeface, body: Typeface) {
        val drawn = ArrayList<RectF>()
        for (m in marks) {
            val tw = width(m.title, 24f * u, num)
            val sw = if (m.sub.isEmpty()) 0f else width(m.sub, 21f * u, body)
            val bw = max(tw, sw) + 26f * u
            val bh = if (m.sub.isEmpty()) 42f * u else 66f * u
            val pole = 56f * u
            val box = RectF(m.x - bw / 2, m.y - pole - bh, m.x + bw / 2, m.y - pole)
            if (box.right < 0 || box.left > w || box.bottom < 0 || box.top > h) continue
            if (drawn.any { RectF.intersects(it, box) }) continue
            drawn.add(box)
            val (bg, fg) = when (m.kind) {
                "start" -> 0xFF2ECC71.toInt() to 0xFF0B1F12.toInt()
                "finish" -> Color.WHITE to 0xFF111111.toInt()
                "peak" -> 0xFFFF9F1C.toInt() to 0xFF1A1100.toInt()
                "steep" -> 0xFFEB4D4B.toInt() to Color.WHITE
                else -> 0xFF111111.toInt() to Color.WHITE
            }
            paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.STROKE
            paint.strokeWidth = max(2f, 3f * u); paint.color = withAlpha(Color.WHITE, m.alpha * .9f)
            c.drawLine(m.x, m.y, m.x, box.bottom, paint)
            paint.style = Paint.Style.FILL; c.drawCircle(m.x, m.y, 6f * u, paint)
            paint.color = withAlpha(bg, m.alpha * .94f); c.drawRoundRect(box, 14f * u, 14f * u, paint)
            val cx = (box.left + box.right) / 2
            if (m.sub.isEmpty()) {
                txt(c, m.title, cx, box.top + 29f * u, 24f * u, num, withAlpha(fg, m.alpha), Paint.Align.CENTER, false, u)
            } else {
                txt(c, m.title, cx, box.top + 28f * u, 24f * u, num, withAlpha(fg, m.alpha), Paint.Align.CENTER, false, u)
                txt(c, m.sub, cx, box.top + 54f * u, 21f * u, body, withAlpha(fg, m.alpha * .85f), Paint.Align.CENTER, false, u)
            }
        }
    }

    // ---- Grafik elevasi ----

    private fun drawProfile(
        c: Canvas, track: RouteVideoTrack, prefs: RouteVideoPrefs, progress: Double, u: Float,
        ink: Int, ink2: Int, accent: Int, body: Typeface, darkInk: Boolean, box: RectF, pad: Float,
    ) {
        val samples = track.profileSamples(180)
        val fin = samples.filter { it.isFinite() }
        if (fin.isEmpty()) return
        val lo = fin.min(); val hi = fin.max()
        val span = max(hi - lo, 10.0)
        val x0 = box.left + pad; val x1 = box.right - pad
        val y0 = box.top + pad + 26f * u; val y1 = box.bottom - pad
        val pts = samples.mapIndexed { i, v ->
            val x = x0 + (x1 - x0) * i / (samples.size - 1)
            val y = y1 - ((if (v.isFinite()) v else lo) - lo + span * 0.04).toFloat() / (span * 1.08).toFloat() * (y1 - y0)
            x to y
        }
        val doneIdx = if (prefs.live) (progress.coerceIn(0.0, 1.0) * (samples.size - 1)).roundToInt() else samples.size - 1

        fun area(upTo: Int): Path = Path().also { p ->
            p.moveTo(pts[0].first, y1)
            for (i in 0..upTo) p.lineTo(pts[i].first, pts[i].second)
            p.lineTo(pts[upTo].first, y1); p.close()
        }
        paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.FILL
        paint.color = withAlpha(ink, if (darkInk) .14f else .16f); c.drawPath(area(samples.size - 1), paint)
        if (doneIdx > 0) { paint.color = withAlpha(accent, .45f); c.drawPath(area(doneIdx), paint) }

        val line = Path().also { p -> pts.forEachIndexed { i, q -> if (i == 0) p.moveTo(q.first, q.second) else p.lineTo(q.first, q.second) } }
        paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.STROKE; paint.strokeWidth = 4f * u
        paint.strokeJoin = Paint.Join.ROUND; paint.strokeCap = Paint.Cap.ROUND
        paint.color = ink2; c.drawPath(line, paint)
        if (doneIdx > 0) {
            val done = Path().also { p -> for (i in 0..doneIdx) if (i == 0) p.moveTo(pts[i].first, pts[i].second) else p.lineTo(pts[i].first, pts[i].second) }
            paint.color = accent; paint.strokeWidth = 5f * u; c.drawPath(done, paint)
        }
        if (prefs.live) {
            val q = pts[min(doneIdx, pts.size - 1)]
            paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.FILL; paint.color = Color.WHITE
            c.drawCircle(q.first, q.second, 9f * u, paint)
            paint.color = accent; c.drawCircle(q.first, q.second, 5.5f * u, paint)
        }
        val sh = !darkInk
        txt(c, "${hi.roundToInt()} m", x0, box.top + pad + 20f * u, 22f * u, body, ink2, Paint.Align.LEFT, sh, u)
        txt(c, "${lo.roundToInt()} m", x1, box.top + pad + 20f * u, 22f * u, body, ink2, Paint.Align.RIGHT, sh, u)
    }
}
