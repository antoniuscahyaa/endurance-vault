package com.endurancevault.app.ui.video

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.LinearGradient
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import com.endurancevault.app.data.TerrainScene
import com.endurancevault.app.domain.FrameStats
import com.endurancevault.app.domain.GhostInfo
import com.endurancevault.app.domain.RouteVideoColors
import com.endurancevault.app.domain.RouteVideoLayout
import com.endurancevault.app.domain.RouteVideoPrefs
import com.endurancevault.app.domain.RouteVideoText
import com.endurancevault.app.domain.RouteVideoTrack
import com.endurancevault.app.domain.seriesSamples
import com.endurancevault.app.ui.sticker.StickerFonts
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Bendera di peta (posisi layar dalam piksel bingkai). [kind]: start, finish, km, peak, steep, fast, hrmax. */
class ScreenMark(val kind: String, val title: String, val sub: String, val x: Float, val y: Float, val alpha: Float, val priority: Int)

/**
 * Menggambar bendera, panel data, dan kartu ringkasan di atas bingkai. Panel menempati kotak grid dan isinya diskalakan
 * agar pas; tanpa latar (transparan penuh). Satuan skala: sisi pendek bingkai 1080 px = 1 unit [u0], jadi pratinjau
 * (setengah ukuran) dan video tampak sama di semua rasio. Fungsi [draw] mengembalikan kotak tiap panel (piksel bingkai)
 * untuk pemilihan di pratinjau.
 */
object RouteVideoOverlay {
    // Pratinjau (thread UI) dan render video (thread GL) bisa berjalan bersamaan, jadi tiap thread punya Paint sendiri.
    private val paintTL = ThreadLocal.withInitial { Paint(Paint.ANTI_ALIAS_FLAG) }
    private val paint: Paint get() = paintTL.get()!!

    fun accentOf(prefs: RouteVideoPrefs): Int = runCatching { Color.parseColor(prefs.lineColor) }.getOrDefault(0xFFC6F432.toInt())

    private fun withAlpha(c: Int, a: Float): Int = Color.argb((a * 255).roundToInt().coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    /**
     * Ubah titik layar hasil proyeksi menjadi bendera yang terlihat pada [frac] (bagian jarak aktivitas utama).
     * Urutan hasil menurut prioritas: finish, start, puncak, tanjakan, km tercepat, HR tertinggi, lalu km.
     */
    fun marksFor(scene: TerrainScene, pts: List<ProjectedPoint>, track: RouteVideoTrack, prefs: RouteVideoPrefs, frac: Double): List<ScreenMark> {
        val out = ArrayList<ScreenMark>()
        for (p in pts) {
            val a = scene.anchors.getOrNull(p.anchorIndex)?.anchor ?: continue
            if (!prefs.showsAnchor(a.kind)) continue
            val alpha = when (a.kind) {
                "start" -> 1f
                "finish" -> if (!prefs.live) 1f else ((frac - 0.97) / 0.03).toFloat().coerceIn(0f, 1f)
                else -> if (!prefs.live) 1f else ((frac - a.frac) / 0.012).toFloat().coerceIn(0f, 1f)
            }
            if (alpha <= 0.01f) continue
            val (title, sub) = RouteVideoText.anchorLabel(a, track)
            val pr = when (a.kind) { "finish" -> 0; "start" -> 1; "peak" -> 2; "steep" -> 3; "fast" -> 4; "hrmax" -> 5; else -> 6 }
            out.add(ScreenMark(a.kind, title, sub, p.x, p.y, alpha, pr))
        }
        return out.sortedBy { it.priority }
    }

    private fun parseColor(hex: String): Int = runCatching { Color.parseColor(hex) }.getOrDefault(Color.WHITE)

    /** Warna gelap tidak diberi bayangan teks (bayangan hitam hanya membantu teks terang di atas peta). */
    private fun isDark(c: Int): Boolean = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0 < 0.35

    /** Data yang tampil di bawah video, urut: pilihan pengguna, lalu selisih ghost bila ada. */
    private fun statCells(prefs: RouteVideoPrefs, track: RouteVideoTrack, st: FrameStats, ghost: GhostInfo?): List<RouteVideoText.Cell> =
        prefs.layout.stats.mapNotNull { RouteVideoText.cell(it, st, prefs.live, track.bike) } + listOfNotNull(ghost?.let { RouteVideoText.ghostCell(it) })

    /**
     * Gambar semua lapisan 2D: bendera, judul (kiri atas, tetap), grafik, legenda, dan data di bawah. Tanpa latar (transparan
     * penuh). [summaryAlpha] (0..1) memudarkan semuanya dan memunculkan kartu ringkasan.
     */
    fun draw(
        c: Canvas, w: Int, h: Int, prefs: RouteVideoPrefs, track: RouteVideoTrack, st: FrameStats,
        progress: Double, fonts: StickerFonts,
        marks: List<ScreenMark> = emptyList(), ghost: GhostInfo? = null, summaryAlpha: Double = 0.0,
    ) {
        val lay = prefs.layout
        val statInk = parseColor(lay.statColor); val titleInk = parseColor(lay.titleColor)
        val accent = accentOf(prefs)
        val numFace = fonts.num ?: Typeface.create("sans-serif-condensed", Typeface.BOLD)
        val bodyFace = fonts.body ?: Typeface.create("sans-serif-medium", Typeface.NORMAL)
        val u0 = min(w, h) / 1080f
        drawMarks(c, marks, w, h, u0, numFace, bodyFace)

        val sa = summaryAlpha.toFloat().coerceIn(0f, 1f)
        val layer = if (sa > 0.001f) c.saveLayerAlpha(0f, 0f, w.toFloat(), h.toFloat(), ((1f - sa) * 255).roundToInt()) else -1

        drawTitle(c, w, h, u0 * lay.titleSize / 100f, prefs, track, numFace, bodyFace, titleInk, withAlpha(titleInk, .78f), !isDark(titleInk))

        val cells = statCells(prefs, track, st, ghost)
        val chartOk = lay.showChart && chartOf(lay.chartKind, track) != null
        val legendOk = lay.legend && RouteVideoColors.info(track, prefs.lineMode) != null
        val plan = lay.plan(w, h, cells.size, chartOk, legendOk)
        val ink2 = withAlpha(statInk, .78f); val sh = !isDark(statInk)
        if (lay.scrim && lay.scrimOpacity > 0) plan.top?.let { drawScrim(c, w, h, it.toFloat(), u0, lay.scrimOpacity / 100f, isDark(statInk)) }
        plan.chart?.let { drawChart(c, lay.chartKind, rf(it), u0, prefs, track, progress, bodyFace, ink2, statInk, accent, sh) }
        plan.legend?.let { drawLegend(c, rf(it), u0, prefs, track, bodyFace, ink2, sh) }
        cells.forEachIndexed { i, cell ->
            plan.stats.getOrNull(i)?.let { drawStat(c, cell, rf(it), u0 * lay.statSize / 100f, numFace, bodyFace, statInk, ink2, sh) }
        }

        if (layer >= 0) c.restoreToCount(layer)
        if (sa > 0.001f) drawSummary(c, w, h, prefs, track, numFace, bodyFace, titleInk, statInk, sa, u0)
    }

    private fun rf(r: DoubleArray) = RectF(r[0].toFloat(), r[1].toFloat(), r[2].toFloat(), r[3].toFloat())

    private fun txt(
        c: Canvas, s: String, x: Float, y: Float, px: Float, face: Typeface, col: Int, align: Paint.Align, shadow: Boolean, u: Float,
    ) {
        paint.reset(); paint.isAntiAlias = true; paint.typeface = face; paint.textSize = px; paint.color = col; paint.textAlign = align
        if (shadow) paint.setShadowLayer(10f * u, 0f, 3f * u, Color.argb(130, 0, 0, 0))
        c.drawText(s, x, y, paint)
    }

    private fun width(s: String, px: Float, face: Typeface): Float {
        paint.reset(); paint.isAntiAlias = true; paint.typeface = face; paint.textSize = px
        return paint.measureText(s)
    }

    private fun ellipsize(s: String, px: Float, face: Typeface, maxW: Float): String {
        if (width(s, px, face) <= maxW) return s
        var t = s
        while (t.length > 1 && width("$t…", px, face) > maxW) t = t.dropLast(1)
        return "$t…"
    }

    // ---- Latar gradasi blok bawah ----

    /** Gradasi dari transparan (sedikit di atas blok) ke paling pekat di tepi bawah bingkai; hitam untuk teks terang, putih untuk teks gelap. */
    private fun drawScrim(c: Canvas, w: Int, h: Int, blockTop: Float, u0: Float, opacity: Float, darkText: Boolean) {
        val y0 = max(0f, blockTop - 90f * u0)
        if (h - y0 < 2f) return
        val base = if (darkText) Color.WHITE else Color.BLACK
        paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(0f, y0, 0f, h.toFloat(), withAlpha(base, 0f), withAlpha(base, opacity), Shader.TileMode.CLAMP)
        c.drawRect(0f, y0, w.toFloat(), h.toFloat(), paint)
        paint.shader = null
    }

    // ---- Data di bawah video ----

    /**
     * Label kecil di atas, nilai besar, satuan di kanan nilai; rata kiri di [rect]. [b] = satuan skala (sudah termasuk ukuran huruf
     * pilihan pengguna). Bila lebih lebar dari kotaknya, isi mengecil agar tidak menimpa data di sebelahnya.
     */
    private fun drawStat(
        c: Canvas, cell: RouteVideoText.Cell, rect: RectF, b: Float, num: Typeface, body: Typeface, ink: Int, ink2: Int, sh: Boolean,
    ) {
        val lw = width(cell.label, 22f * b, body) + cell.label.length * 1.2f * b
        val vw = width(cell.value, 72f * b, num)
        val uw = if (cell.unit.isEmpty()) 0f else 8f * b + width(cell.unit, 28f * b, body)
        val natW = max(lw, vw + uw)
        val k = min(1f, rect.width() / natW.coerceAtLeast(1f)).coerceAtLeast(0.3f)
        val u = b * k
        txt(c, cell.label, rect.left, rect.top + 18f * u, 22f * u, body, ink2, Paint.Align.LEFT, sh, u)
        val base = rect.top + 84f * u
        txt(c, cell.value, rect.left, base, 72f * u, num, ink, Paint.Align.LEFT, sh, u)
        if (cell.unit.isNotEmpty()) {
            val vwk = width(cell.value, 72f * u, num)
            txt(c, cell.unit, rect.left + vwk + 8f * u, base, 28f * u, body, ink2, Paint.Align.LEFT, sh, u)
        }
    }

    // ---- Judul (kiri atas, posisi tetap): baris 1 judul sendiri atau nama aktivitas, baris 2 ringkasan bebas, baris 3 tanggal ----

    private fun drawTitle(
        c: Canvas, w: Int, h: Int, u: Float, prefs: RouteVideoPrefs, track: RouteVideoTrack,
        num: Typeface, body: Typeface, ink: Int, ink2: Int, sh: Boolean,
    ) {
        val l1 = prefs.titleText.trim().ifBlank { track.title }
        val l2 = prefs.subtitle.trim()
        val l3 = if (prefs.showDate) track.dateText else ""
        val x = RouteVideoLayout.titleLeft(w).toFloat(); val maxW = RouteVideoLayout.titleMaxWidth(w).toFloat()
        var y = RouteVideoLayout.titleTop(h).toFloat() + 44f * u
        txt(c, ellipsize(l1, 48f * u, num, maxW), x, y, 48f * u, num, ink, Paint.Align.LEFT, sh, u)
        if (l2.isNotEmpty()) { y += 36f * u; txt(c, ellipsize(l2, 30f * u, body, maxW), x, y, 30f * u, body, ink2, Paint.Align.LEFT, sh, u) }
        if (l3.isNotEmpty()) { y += 32f * u; txt(c, l3, x, y, 26f * u, body, ink2, Paint.Align.LEFT, sh, u) }
    }

    // ---- Grafik (elevasi, pace/kecepatan, detak jantung) ----

    private class Chart(val title: String, val range: String, val samples: DoubleArray, val lo: Double, val hi: Double)

    private fun chartOf(key: String, track: RouteVideoTrack): Chart? = when (key) {
        "profil" -> {
            val s = track.profileSamples(180)
            val fin = s.filter { it.isFinite() }
            if (fin.isEmpty()) null else {
                val lo = fin.min(); val hi = max(fin.max(), lo + 10.0)
                Chart("ELEVASI", "${lo.roundToInt()}–${hi.roundToInt()} m", s, lo, hi)
            }
        }
        "grafikhr" -> RouteVideoColors.info(track, "hr")?.let { info ->
            val s = track.seriesSamples("hr", info.values)
            if (s.none { it.isFinite() }) null
            else Chart("DETAK JANTUNG", "${info.lo.roundToInt()}–${info.hi.roundToInt()} bpm", s, info.lo, info.hi)
        }
        else -> RouteVideoColors.info(track, "pace")?.let { info ->
            val s = track.seriesSamples("pace", info.values)
            if (s.none { it.isFinite() }) null
            // Sumbu y = kecepatan (naik = lebih cepat); label menampilkan pace tercepat dan terlambat.
            else Chart(if (track.bike) "KECEPATAN" else "PACE", "${info.hiText} – ${info.loText}", s, info.lo, info.hi)
        }
    }

    private fun drawChart(
        c: Canvas, key: String, rect: RectF, u0: Float, prefs: RouteVideoPrefs, track: RouteVideoTrack, progress: Double,
        body: Typeface, ink2: Int, ink: Int, accent: Int, sh: Boolean,
    ): Boolean {
        val ch = chartOf(key, track) ?: return false
        val u = u0 * min(rect.width() / (880f * u0), rect.height() / (210f * u0)).coerceIn(0.4f, 1.3f)
        val pad = 4f * u
        val x0 = rect.left + pad; val x1 = rect.right - pad
        val y0 = rect.top + pad + 30f * u; val y1 = rect.bottom - pad
        if (y1 - y0 < 8f) return true
        val span = max(ch.hi - ch.lo, 1e-6)
        val n = ch.samples.size
        val pts = ch.samples.mapIndexed { i, v ->
            val x = x0 + (x1 - x0) * i / (n - 1)
            val t = (((if (v.isFinite()) v else ch.lo).coerceIn(ch.lo, ch.hi) - ch.lo) / span).toFloat() * 0.92f + 0.04f
            x to (y1 - t * (y1 - y0))
        }
        val doneIdx = if (prefs.live) (progress.coerceIn(0.0, 1.0) * (n - 1)).roundToInt() else n - 1

        fun area(upTo: Int): Path = Path().also { p ->
            p.moveTo(pts[0].first, y1)
            for (i in 0..upTo) p.lineTo(pts[i].first, pts[i].second)
            p.lineTo(pts[upTo].first, y1); p.close()
        }
        paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.FILL
        paint.color = withAlpha(ink, if (isDark(ink)) .14f else .16f); c.drawPath(area(n - 1), paint)
        if (doneIdx > 0) { paint.color = withAlpha(accent, .45f); c.drawPath(area(doneIdx), paint) }

        val line = Path().also { p -> pts.forEachIndexed { i, q -> if (i == 0) p.moveTo(q.first, q.second) else p.lineTo(q.first, q.second) } }
        paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.STROKE; paint.strokeWidth = 4f * u
        paint.strokeJoin = Paint.Join.ROUND; paint.strokeCap = Paint.Cap.ROUND
        paint.color = ink2; c.drawPath(line, paint)
        if (doneIdx > 0) {
            val done = Path().also { p -> for (i in 0..doneIdx) if (i == 0) p.moveTo(pts[i].first, pts[i].second) else p.lineTo(pts[i].first, pts[i].second) }
            paint.color = accent; paint.strokeWidth = 5f * u; c.drawPath(done, paint)
        }
        if (prefs.live) {
            val q = pts[min(doneIdx, pts.size - 1)]
            paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.FILL; paint.color = Color.WHITE
            c.drawCircle(q.first, q.second, 9f * u, paint)
            paint.color = accent; c.drawCircle(q.first, q.second, 5.5f * u, paint)
        }
        txt(c, ch.title, x0, rect.top + pad + 22f * u, 22f * u, body, ink2, Paint.Align.LEFT, sh, u)
        txt(c, ch.range, x1, rect.top + pad + 22f * u, 22f * u, body, ink2, Paint.Align.RIGHT, sh, u)
        return true
    }

    // ---- Legenda warna garis ----

    private fun drawLegend(c: Canvas, rect: RectF, u0: Float, prefs: RouteVideoPrefs, track: RouteVideoTrack, body: Typeface, ink2: Int, sh: Boolean): Boolean {
        val info = RouteVideoColors.info(track, prefs.lineMode) ?: return false
        val u = u0 * min(rect.height() / (80f * u0), 1.2f).coerceAtLeast(0.3f)
        val top = rect.top + (rect.height() - 80f * u) / 2
        val x0 = rect.left; val x1 = rect.right
        val y0 = top + 34f * u; val y1 = y0 + 16f * u
        txt(c, info.title, x0, top + 22f * u, 26f * u, body, ink2, Paint.Align.LEFT, sh, u)
        val cols = RouteVideoColors.legendColors(prefs.lineMode, 24)
        val seg = (x1 - x0) / cols.size
        paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.FILL
        for (i in cols.indices) { paint.color = cols[i]; c.drawRect(x0 + seg * i, y0, x0 + seg * (i + 1) + 1f, y1, paint) }
        txt(c, info.loText, x0, y1 + 28f * u, 22f * u, body, ink2, Paint.Align.LEFT, sh, u)
        txt(c, info.hiText, x1, y1 + 28f * u, 22f * u, body, ink2, Paint.Align.RIGHT, sh, u)
        return true
    }

    // ---- Kartu ringkasan di akhir video ----

    private fun drawSummary(
        c: Canvas, w: Int, h: Int, prefs: RouteVideoPrefs, track: RouteVideoTrack,
        num: Typeface, body: Typeface, titleInk: Int, statInk: Int, alpha: Float, u0: Float,
    ) {
        // Peredup layar penuh (bukan kartu) supaya angka terbaca di atas peta.
        val darkInk = isDark(statInk)
        c.drawColor(if (darkInk) Color.argb((alpha * 165).roundToInt(), 255, 255, 255) else Color.argb((alpha * 165).roundToInt(), 0, 0, 0))
        val st = track.statsAt(1.0, false)
        val keys = arrayListOf("jarak", "waktu", "pace", "gain")
        if (st.hr != null) keys += "hr"
        if ((st.cad ?: 0) > 0) keys += "cad"
        val cells = keys.mapNotNull { RouteVideoText.cell(it, st, false, track.bike) }
        val rows = (cells.size + 1) / 2
        val l1 = prefs.titleText.trim().ifBlank { track.title }
        val l2 = prefs.subtitle.trim()
        val l3 = if (prefs.showDate) track.dateText else ""
        var titleH = 72f * u0
        if (l2.isNotEmpty()) titleH += 40f * u0
        if (l3.isNotEmpty()) titleH += 36f * u0
        val rowH = 190f * u0; val gap = 64f * u0
        var y = (h - (titleH + gap + rows * rowH)) / 2
        val sh = !darkInk
        val ink = withAlpha(statInk, alpha); val ink2 = withAlpha(statInk, .78f * alpha)
        val tInk = withAlpha(titleInk, alpha); val tInk2 = withAlpha(titleInk, .78f * alpha)
        val cx0 = w / 2f
        y += 58f * u0
        txt(c, ellipsize(l1, 64f * u0, num, w * 0.88f), cx0, y, 64f * u0, num, tInk, Paint.Align.CENTER, sh, u0)
        if (l2.isNotEmpty()) { y += 42f * u0; txt(c, ellipsize(l2, 34f * u0, body, w * 0.88f), cx0, y, 34f * u0, body, tInk2, Paint.Align.CENTER, sh, u0) }
        if (l3.isNotEmpty()) { y += 38f * u0; txt(c, l3, cx0, y, 30f * u0, body, tInk2, Paint.Align.CENTER, sh, u0) }
        y += 14f * u0 + gap
        cells.forEachIndexed { i, cell ->
            val row = i / 2; val single = (i == cells.size - 1) && (cells.size % 2 == 1)
            val cx = if (single) cx0 else w * (0.27f + 0.46f * (i % 2))
            val top = y + row * rowH
            val vw = width(cell.value, 104f * u0, num)
            val uw = if (cell.unit.isEmpty()) 0f else 12f * u0 + width(cell.unit, 38f * u0, body)
            txt(c, cell.label, cx, top + 30f * u0, 28f * u0, body, ink2, Paint.Align.CENTER, sh, u0)
            val left = cx - (vw + uw) / 2
            txt(c, cell.value, left, top + 138f * u0, 104f * u0, num, ink, Paint.Align.LEFT, sh, u0)
            if (cell.unit.isNotEmpty()) txt(c, cell.unit, left + vw + 12f * u0, top + 138f * u0, 38f * u0, body, ink2, Paint.Align.LEFT, sh, u0)
        }
    }

    // ---- Bendera di peta ----

    private fun drawMarks(c: Canvas, marks: List<ScreenMark>, w: Int, h: Int, u: Float, num: Typeface, body: Typeface) {
        val drawn = ArrayList<RectF>()
        for (m in marks) {
            val tw = width(m.title, 24f * u, num)
            val sw = if (m.sub.isEmpty()) 0f else width(m.sub, 21f * u, body)
            val bw = max(tw, sw) + 26f * u
            val bh = if (m.sub.isEmpty()) 42f * u else 66f * u
            val pole = 56f * u
            val box = RectF(m.x - bw / 2, m.y - pole - bh, m.x + bw / 2, m.y - pole)
            if (box.right < 0 || box.left > w || box.bottom < 0 || box.top > h) continue
            if (drawn.any { RectF.intersects(it, box) }) continue
            drawn.add(box)
            val (bg, fg) = when (m.kind) {
                "start" -> 0xFF2ECC71.toInt() to 0xFF0B1F12.toInt()
                "finish" -> Color.WHITE to 0xFF111111.toInt()
                "peak" -> 0xFFFF9F1C.toInt() to 0xFF1A1100.toInt()
                "steep" -> 0xFFEB4D4B.toInt() to Color.WHITE
                "fast" -> 0xFFB388FF.toInt() to 0xFF14002E.toInt()
                "hrmax" -> 0xFFFF5C8A.toInt() to Color.WHITE
                else -> 0xFF111111.toInt() to Color.WHITE
            }
            paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.STROKE
            paint.strokeWidth = max(2f, 3f * u); paint.color = withAlpha(Color.WHITE, m.alpha * .9f)
            c.drawLine(m.x, m.y, m.x, box.bottom, paint)
            paint.style = Paint.Style.FILL; c.drawCircle(m.x, m.y, 6f * u, paint)
            paint.color = withAlpha(bg, m.alpha * .94f); c.drawRoundRect(box, 14f * u, 14f * u, paint)
            val cx = (box.left + box.right) / 2
            if (m.sub.isEmpty()) {
                txt(c, m.title, cx, box.top + 29f * u, 24f * u, num, withAlpha(fg, m.alpha), Paint.Align.CENTER, false, u)
            } else {
                txt(c, m.title, cx, box.top + 28f * u, 24f * u, num, withAlpha(fg, m.alpha), Paint.Align.CENTER, false, u)
                txt(c, m.sub, cx, box.top + 54f * u, 21f * u, body, withAlpha(fg, m.alpha * .85f), Paint.Align.CENTER, false, u)
            }
        }
    }
}
