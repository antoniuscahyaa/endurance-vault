package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.i18n.Text
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.endurancevault.app.data.HuaweiSleepParity
import com.endurancevault.app.domain.NightBar
import com.endurancevault.app.domain.SleepStage
import com.endurancevault.app.domain.SleepSummary
import com.endurancevault.app.domain.WatchDay
import com.endurancevault.app.domain.WatchDock
import com.endurancevault.app.domain.WatchModel
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.abs
import kotlin.math.max

private data class DsRow(val t: String, val v: String, val s: String = "")

private fun r(x: Double) = Math.floor(x + 0.5)

/** Daftar nilai 2 kolom (label kecil, angka tebal, keterangan) — setara <dl class="jm-ds">. */
@Composable
private fun Ds(rows: List<DsRow>) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        rows.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                pair.forEach { c ->
                    Column(Modifier.weight(1f)) {
                        Text(c.t, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(c.v, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        if (c.s.isNotEmpty()) Text(c.s, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun Dt(title: String, sub: String? = null) {
    Column(Modifier.padding(top = 6.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        if (!sub.isNullOrBlank()) Text(sub, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun Nod(text: String, top: Int = 0) {
    Text(text, Modifier.padding(top = top.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun NoData() = Nod("Belum cukup data untuk grafik ini.")

@Composable
private fun Dot(k: String) {
    Box(Modifier.size(9.dp).clip(CircleShape).background(stageColor(k)))
}

private fun hourItems(arr: DoubleArray, curH: Int, div: Double = 1.0) =
    arr.mapIndexed { i, v -> BarItem(if (i % 6 == 0) (if (i < 10) "0$i" else "$i") else "", v / div, i == curH) }

private fun weekItems(wk: List<WatchDay>, div: Double, goal: Double = 0.0, sel: (WatchDay) -> Double) =
    wk.map { d -> val v = sel(d) / div; BarItem(d.l, v, d.now, goal > 0 && v >= goal) }

/** Isi panel rinci untuk satu ubin (k = steps | hr | rhr | kcal | dist | spo2 | sleep | bat). */
@Composable
fun WatchDetail(m: WatchModel, k: String, hypV: Int?, onHyp: (Int) -> Unit) {
    val wk = m.wk; val c = m.cur; val hi = m.hourly
    val curH = if (m.t0 > 0) ((m.now - m.t0) / 3600).toInt() else -1
    val t7 = "7 hari terakhir"
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        when (k) {
            "steps" -> {
                val sv = wk.filter { it.steps > 0 }; val pv = wk.take(6).filter { it.steps > 0 }
                val avg = WatchDock.avgOf(pv) { it.steps }; val best = WatchDock.maxOf(sv) { it.steps }
                Ds(listOf(
                    DsRow("Hari ini", WatchDock.num(c.steps), "${r(c.steps / WatchDock.GOAL * 100).toInt()}% target"),
                    DsRow("Rata-rata harian", if (pv.isNotEmpty()) WatchDock.num(avg) else "–", "tanpa hari ini"),
                    DsRow("Terbaik", if (best != null) WatchDock.num(best.steps) else "–", best?.l ?: ""),
                    DsRow("Capai target", "${wk.count { it.steps >= WatchDock.GOAL }}/7", WatchDock.num(WatchDock.GOAL.toDouble())),
                ))
                Dt("Per jam hari ini")
                if (hi.steps.sum() > 0) WatchBarsChart(hourItems(hi.steps, curH), "Langkah per jam", fmt = { WatchDock.kShort(it) }, bw = 9f) else NoData()
                Dt(t7, "garis hijau = target")
                if (sv.isNotEmpty()) WatchBarsChart(weekItems(wk, 1.0, WatchDock.GOAL.toDouble()) { it.steps }, "Langkah 7 hari", goal = WatchDock.GOAL.toDouble(), avg = if (pv.isNotEmpty()) avg else 0.0, vals = true, fmt = { WatchDock.kShort(it) }) else NoData()
            }
            "hr" -> {
                val h = m.hr
                Ds(listOf(
                    DsRow("Terendah", if (h != null) "${h.min} bpm" else "–", "hari ini"),
                    DsRow("Rata-rata", if (h != null) "${h.avg} bpm" else "–", "hari ini"),
                    DsRow("Tertinggi", if (h != null) "${h.max} bpm" else "–", "hari ini"),
                    DsRow("HR istirahat", if (c.rhr > 0) "${c.rhr} bpm" else "–"),
                ))
                Dt("Hari ini", "pita = rentang tiap 10 menit")
                if (h != null && h.series.size > 1) WatchHrChart(h) else NoData()
                Dt(t7, "batang = min–maks, titik = rata-rata")
                if (wk.any { it.hrMax > 0 }) WatchRangeChart(wk.map { RangeItem(it.l, it.hrMin.toDouble(), it.hrMax.toDouble(), it.hrAvg.toDouble(), it.now) }, "HR 7 hari", step = 10.0, pad = 4.0, span = 40.0, color = ColHr) else NoData()
            }
            "rhr" -> {
                val sv = wk.filter { it.rhr > 0 }; val avg = WatchDock.avgOf(sv) { it.rhr.toDouble() }
                val best = WatchDock.minOf(sv) { it.rhr.toDouble() }; val low = WatchDock.maxOf(sv) { it.rhr.toDouble() }
                Ds(listOf(
                    DsRow("Terbaru", if (c.rhr > 0) "${c.rhr} bpm" else "–"),
                    DsRow("Rata-rata 7 hari", if (sv.isNotEmpty()) "${r(avg).toInt()} bpm" else "–"),
                    DsRow("Terendah", if (best != null) "${best.rhr} bpm" else "–", best?.l ?: ""),
                    DsRow("Tertinggi", if (low != null) "${low.rhr} bpm" else "–", low?.l ?: ""),
                ))
                Dt(t7)
                if (sv.isNotEmpty()) WatchLineChart(wk.map { LineItem(it.l, it.rhr.toDouble(), it.now) }, "HR istirahat 7 hari", step = 2.0, span = 6.0, color = ColHr) else NoData()
                if (c.rhr > 0 && sv.size > 2) {
                    val dlt = c.rhr - avg
                    Nod("Dibanding rata-rata 7 hari: " + (if (dlt >= 0) "+" else "") + WatchDock.dec(dlt, 1) + " bpm. Naik beberapa bpm beruntun bisa tanda kurang pulih.")
                }
            }
            "kcal" -> {
                val sv = wk.filter { it.kcal > 0 }; val pv = wk.take(6).filter { it.kcal > 0 }
                val avg = WatchDock.avgOf(pv) { it.kcal }; val best = WatchDock.maxOf(sv) { it.kcal }
                Ds(listOf(
                    DsRow("Hari ini", WatchDock.kcalTxt(c.kcal)),
                    DsRow("Rata-rata harian", if (pv.isNotEmpty()) WatchDock.num(avg) + " kkal" else "–", "tanpa hari ini"),
                    DsRow("Tertinggi", if (best != null) WatchDock.num(best.kcal) + " kkal" else "–", best?.l ?: ""),
                    DsRow("Total 7 hari", WatchDock.num(wk.sumOf { it.kcal }) + " kkal"),
                ))
                Dt("Per jam hari ini")
                if (hi.hasCal) WatchBarsChart(hourItems(hi.kcal, curH), "Kalori per jam", fmt = { WatchDock.num(it) }, bw = 9f, color = ColKcal) else NoData()
                Dt(t7)
                if (sv.isNotEmpty()) WatchBarsChart(weekItems(wk, 1.0) { it.kcal }, "Kalori 7 hari", avg = if (pv.isNotEmpty()) avg else 0.0, vals = true, fmt = { WatchDock.num(it) }, color = ColKcal) else NoData()
            }
            "dist" -> {
                val sv = wk.filter { it.dist > 0 }; val pv = wk.take(6).filter { it.dist > 0 }
                val avg = WatchDock.avgOf(pv) { it.dist } / 1000; val best = WatchDock.maxOf(sv) { it.dist }
                Ds(listOf(
                    DsRow("Hari ini", WatchDock.dec(c.dist / 1000, 2) + " km"),
                    DsRow("Rata-rata harian", if (pv.isNotEmpty()) WatchDock.dec(avg, 2) + " km" else "–", "tanpa hari ini"),
                    DsRow("Terjauh", if (best != null) WatchDock.dec(best.dist / 1000, 2) + " km" else "–", best?.l ?: ""),
                    DsRow("Total 7 hari", WatchDock.dec(wk.sumOf { it.dist } / 1000, 1) + " km"),
                ))
                Dt("Per jam hari ini")
                if (hi.hasDist) WatchBarsChart(hourItems(hi.dist, curH, 1000.0), "Jarak per jam", fmt = { WatchDock.kmShort(it) }, bw = 9f, color = ColDist) else NoData()
                Dt(t7)
                if (sv.isNotEmpty()) WatchBarsChart(weekItems(wk, 1000.0) { it.dist }, "Jarak 7 hari", avg = if (pv.isNotEmpty()) avg else 0.0, vals = true, fmt = { WatchDock.kmShort(it) }, color = ColDist) else NoData()
            }
            "spo2" -> {
                val sv = wk.filter { it.spo2Avg > 0 }; val avg = WatchDock.avgOf(sv) { it.spo2Avg.toDouble() }
                val low = WatchDock.minOf(sv.filter { it.spo2Min > 0 }) { it.spo2Min.toDouble() }
                Ds(listOf(
                    DsRow("Terbaru", if (c.spo2 > 0) "${c.spo2}%" else "–"),
                    DsRow("Rata-rata hari ini", if (c.spo2Avg > 0) "${r(c.spo2Avg).toInt()}%" else "–", if (c.spo2N > 1) "${c.spo2N} sampel" else ""),
                    DsRow("Terendah 7 hari", if (low != null) "${low.spo2Min}%" else "–", low?.l ?: ""),
                    DsRow("Rata-rata 7 hari", if (sv.isNotEmpty()) "${r(avg).toInt()}%" else "–"),
                ))
                Dt("Hari ini", "pita = rentang tiap 10 menit")
                if (m.spo2s.size > 1) WatchTimeChart(m.spo2s, m.t0, m.now, 80.0, 100.0, "SpO₂ hari ini") else NoData()
                Dt(t7, "batang = min–maks, titik = rata-rata")
                if (wk.any { it.spo2Max > 0 }) WatchRangeChart(wk.map { RangeItem(it.l, it.spo2Min.toDouble(), it.spo2Max.toDouble(), it.spo2Avg.toDouble(), it.now) }, "SpO₂ 7 hari", step = 5.0, pad = 1.0, span = 10.0, cap = 100.0, fmt = { "${r(it).toInt()}%" }, color = ColSpo2) else NoData()
            }
            "sleep" -> SleepDetail(m, hypV, onHyp)
            "bat" -> BatteryDetail(m)
        }
    }
}

@Composable
private fun SleepDetail(m: WatchModel, hypV: Int?, onHyp: (Int) -> Unit) {
    val nw = m.nights7; val ns = nw.filter { it.asleep > 0 }; val s = m.sleep
    val avg = if (ns.isEmpty()) 0.0 else ns.sumOf { it.asleep } / ns.size.toDouble()
    val best = ns.fold(null as NightBar?) { b, n -> if (b == null || n.asleep > b.asleep) n else b }
    Ds(listOf(
        DsRow("Semalam", if (s != null) WatchDock.hm(s.asleep) else "–", if (s != null) s.bed + "–" + s.wake else ""),
        DsRow("Efisiensi", if (s?.eff != null) "${s.eff}%" else "–"),
        DsRow("Rata-rata 7 malam", if (ns.isNotEmpty()) WatchDock.hm(avg) else "–", if (ns.isNotEmpty()) "${ns.size} malam" else ""),
        DsRow("Terpanjang", if (best != null) WatchDock.hm(best.asleep) else "–", best?.l ?: ""),
    ))
    SleepLast(m, hypV, onHyp)
    Dt("Fase tidur 7 malam", "angka = jam tidur · abu = tidur lagi")
    if (nw.any { it.asleep > 0 }) WatchStackChart(nw, "Tidur 7 malam") else NoData()
    Dt("Terbangun & tidur lagi", "per malam, 7 hari")
    var any = false
    nw.reversed().forEach { n ->
        if (!(n.asleep > 0)) return@forEach
        any = true
        val np = m.naps.filter { it.date == n.date }.flatMap { it.list }
        NightRow(n.l, n.bed + "–" + n.wake + " · " + WatchDock.hm(n.asleep) + (if (n.wakeN > 0) " · ${n.wakeN}×" else ""), n.wakes, n.extras, np, n.bed, n.wake, "Tidak ada terbangun terbaca")
    }
    if (!any) NoData()
    val napOnly = m.naps.filter { d -> !nw.any { it.date == d.date && it.asleep > 0 } }
    if (napOnly.isNotEmpty()) {
        Dt("Tidur siang")
        napOnly.forEach { d -> NightRow(d.date.drop(5), WatchDock.hm(d.minutes), emptyList(), emptyList(), d.list, "", "", null) }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
        listOf("deep" to "Dalam", "rem" to "REM", "light" to "Ringan").forEach { (k, l) ->
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) { Dot(k); Text(l, style = MaterialTheme.typography.labelSmall) }
        }
    }
}

@Composable
private fun NightRow(
    label: String, summary: String, wakes: List<HuaweiSleepParity.Wake>, extras: List<HuaweiSleepParity.Extra>,
    naps: List<HuaweiSleepParity.NapItem>, bed: String, wake: String, emptyText: String?,
) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
            Text(summary, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        val has = wakes.isNotEmpty() || extras.isNotEmpty() || naps.isNotEmpty()
        if (has) WakeList(wakes, extras, naps, bed, wake) else if (emptyText != null) Nod(emptyText, 2)
    }
}

/** Daftar terbangun -> tidur lagi, sesi tidur tambahan, dan tidur siang untuk satu malam (jamWakeList). */
@Composable
internal fun WakeList(
    wakes: List<HuaweiSleepParity.Wake>, extras: List<HuaweiSleepParity.Extra>, naps: List<HuaweiSleepParity.NapItem>, bed: String, wake: String,
) {
    Column(Modifier.fillMaxWidth().padding(top = 4.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        fun item(t: String, v: String) = t to v
        val rows = ArrayList<Pair<String, String>>()
        wakes.forEach { w -> rows += item(w.a + " → tidur lagi " + w.b + (if (w.gap) " (jeda tanpa data)" else ""), WatchDock.hm(w.min)) }
        extras.forEach { x ->
            rows += item(
                if (x.pos == "b") "${x.a}–${x.b} tidur · terbangun ${x.b} → tidur lagi $bed" else "Terbangun $wake → tidur lagi ${x.a} · ${x.a}–${x.b}",
                WatchDock.hm(x.min),
            )
        }
        naps.forEach { x -> rows += item("Tidur siang ${x.a}–${x.b}", WatchDock.hm(x.min)) }
        rows.forEach { (t, v) ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(t, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(v, Modifier.padding(start = 8.dp), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
            }
        }
        // Jeda tanpa data yang panjang biasanya berarti jam longgar atau terlepas, bukan terbangun sungguhan.
        val gm = wakes.filter { it.gap }.sumOf { it.min }
        if (gm >= 20) Nod("Jam tidak merekam apa pun selama " + WatchDock.hm(gm) + " malam ini. Bila sering terjadi, kencangkan tali jam atau cek apakah jam sempat terlepas.", 4)
    }
}

/** Bar fase tidur (lebar sebanding durasi) — setara <div class="jm-stg">. */
@Composable
internal fun SleepStageBar(stages: List<SleepStage>) {
    Row(Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(6.dp))) {
        stages.filter { it.min > 0 }.forEach { x -> Box(Modifier.weight(x.min.toFloat()).height(12.dp).background(stageColor(x.k))) }
    }
}

/** Legenda fase: titik, nama, durasi, persen. */
@Composable
internal fun SleepLegend(stages: List<SleepStage>, tot: Int) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        stages.forEach { x ->
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Dot(x.k)
                Text(x.label, style = MaterialTheme.typography.bodySmall)
                Text(WatchDock.hm(x.min), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                Text("${r(x.min.toDouble() / tot * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

/** Slider waktu di grafik fase: geser untuk melihat rentang jam, fase, dan durasi blok di posisi itu (seperti Huawei Health). */
@Composable
internal fun HypSlider(m: WatchModel, s: SleepSummary, hypV: Int?, onHyp: (Int) -> Unit) {
    if (s.blocks.isEmpty() || s.end <= s.start) return
    val v = (hypV ?: WatchDock.hypDefault(s)).coerceIn(0, 1000)
    val info = WatchDock.hypInfo(s.blocks, s.start + (v / 1000.0 * (s.end - s.start)).toLong(), WatchDock.hypLabels(s), m.tzMin) ?: return
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(info.from + " – " + info.to, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Dot(info.k); Text(info.label, style = MaterialTheme.typography.bodyMedium)
                Text(info.dur, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        WatchHypnogram(s.blocks, s.start, s.end, m.tzMin, "Fase tidur sepanjang malam", cursor = v, hit = info.i)
        Slider(value = v.toFloat(), onValueChange = { onHyp(it.toInt()) }, valueRange = 0f..1000f)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Tidur " + s.bed, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Bangun " + s.wake, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/** Isi kartu "Tidur semalam" (bar fase, legenda, skor, terbangun); ditampilkan di dalam expand kartu Tidur (jamSleepLast). */
@Composable
private fun SleepLast(m: WatchModel, hypV: Int?, onHyp: (Int) -> Unit) {
    val s = m.sleep ?: return
    val todayNaps = m.naps.filter { it.date == s.date }.flatMap { it.list }
    Dt("Tidur semalam", s.bed + "–" + s.wake + " · " + WatchDock.hm(s.asleep) + (if (s.eff != null) " · efisiensi ${s.eff}%" else ""))
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (s.stages.isNotEmpty()) { SleepStageBar(s.stages); SleepLegend(s.stages, s.tot) }
        else Nod("Jam tidak mengirim fase tidur untuk malam ini.")
        if (s.blocks.isNotEmpty()) {
            Dt("Fase sepanjang malam", "atas ke bawah: terjaga · REM · ringan · dalam")
            HypSlider(m, s, hypV, onHyp)
        }
        Dt("Pernapasan saat tidur")
        Ds(listOf(
            DsRow("Rata-rata SpO₂", if (s.spo2 > 0) "${s.spo2}%" else "–", if (s.spo2 > 0) "" else "jam butuh ±7 malam pemakaian"),
            DsRow("Rata-rata laju napas", if (s.resp > 0) "${s.resp} napas/mnt" else "–", if (s.resp > 0) "" else "belum dikirim jam"),
        ))
        val meta = ArrayList<String>()
        if (s.score > 0) meta += "Skor tidur ${s.score}"
        if (s.lat > 0) meta += "tertidur setelah " + WatchDock.hm(s.lat)
        meta += if (s.wakeN > 0) "terbangun ${s.wakeN}× · " + WatchDock.hm(s.wakeMin) else "tidak ada terbangun terbaca"
        if (s.extraMin > 0) meta += "+ tidur lagi " + WatchDock.hm(s.extraMin)
        Nod(meta.joinToString(" · "), 2)
        if (s.wakes.isNotEmpty() || s.extras.isNotEmpty() || todayNaps.isNotEmpty()) WakeList(s.wakes, s.extras, todayNaps, s.bed, s.wake)
    }
}

/** Isi tambahan ubin Tidur saat collapse: grafik fase sepanjang malam lalu bar durasi bertumpuk + legenda (jamSleepTileExtra). */
@Composable
fun SleepTileExtra(m: WatchModel, hypV: Int?, onHyp: (Int) -> Unit) {
    val s = m.sleep ?: return
    if (s.stages.isEmpty()) return
    Column(Modifier.fillMaxWidth().padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (s.blocks.isNotEmpty()) {
            Column { Text("Fase sepanjang malam", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold); Nod("atas ke bawah: terjaga · REM · ringan · dalam") }
            HypSlider(m, s, hypV, onHyp)
        }
        SleepStageBar(s.stages); SleepLegend(s.stages, s.tot)
    }
}

@Composable
private fun BatteryDetail(m: WatchModel) {
    val zone = ZoneId.systemDefault()
    Ds(listOf(
        DsRow("Baterai", if (m.battery != null) "${m.battery}%" else "–"),
        DsRow("Status", if (m.state == "syncing") "Menyinkronkan" else if (m.conn) "Terhubung" else "Tidak terhubung"),
        DsRow("Data terakhir", if (m.lastTs != null) WatchDock.ago(m.now, m.lastTs) else "–"),
        DsRow("Sinkron terakhir", if (m.lastSyncAt != null) WatchDock.ago(m.now, m.lastSyncAt) else "–"),
        DsRow("Dijaga di latar", if (m.keepAlive) "Ya" else "Tidak"),
        DsRow("Perangkat", m.device.ifEmpty { "–" }),
    ))
    val be = m.batEst; val er = ArrayList<DsRow>()
    if (be.charging) er += DsRow("Estimasi habis", "Sedang mengisi")
    else {
        er += DsRow("Estimasi habis (laju terkini)",
            if (be.liveH != null) "±" + WatchDock.clock(be.endTs ?: 0, m.tzMin) + " · " + WatchDock.dec(be.liveH, if (be.liveH < 10) 1 else 0) + " j lagi" else "Belum cukup data")
        if ((be.runH ?: 0.0) > 0) er += DsRow("Bila dipakai lari", "±" + WatchDock.dec(be.runH!!, if (be.runH < 10) 1 else 0) + " jam")
    }
    Dt("Estimasi baterai"); Ds(er)
    if (m.batSessions.isNotEmpty()) {
        val fmt = DateTimeFormatter.ofPattern("dd/MM HH:mm")
        Dt("Baterai terpakai per sesi")
        Ds(m.batSessions.sortedByDescending { it.first }.take(8).map { (start, b) ->
            DsRow(Instant.ofEpochSecond(start).atZone(zone).format(fmt), (if (b.ap) "~" else "") + "−" + b.used + "%")
        })
    }
    Nod("Jam tidak menyimpan riwayat baterai; aplikasi mencatatnya sendiri dari level yang terbaca, jadi sesi tanpa catatan di sekitar waktunya tidak punya data (tanda ~ = perkiraan). Bila rendah (≤20%), jam bisa berhenti mengirim data.")
}
