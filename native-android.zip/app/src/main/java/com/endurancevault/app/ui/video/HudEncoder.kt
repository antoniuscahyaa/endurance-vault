package com.endurancevault.app.ui.video

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.SurfaceTexture
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLUtils
import android.os.Handler
import android.os.HandlerThread
import android.provider.OpenableColumns
import android.view.Surface
import com.endurancevault.app.domain.HudPrefs
import com.endurancevault.app.domain.RouteVideoTrack
import com.endurancevault.app.domain.VideoHud
import com.endurancevault.app.ui.sticker.StickerFonts
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.CancellationException
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Keterangan video sumber (ukuran tampilan sudah memperhitungkan rotasi). */
class HudSourceInfo(
    val width: Int, val height: Int, val rotation: Int, val durationSec: Double, val fps: Float,
    val hasAudio: Boolean, val audioAac: Boolean,
) {
    val dispW: Int get() = if (rotation == 90 || rotation == 270) height else width
    val dispH: Int get() = if (rotation == 90 || rotation == 270) width else height
}

/** Membaca video dari galeri: keterangan, jam rekam, dan bingkai pratinjau. */
object HudVideoIo {
    fun probe(ctx: Context, uri: Uri): Result<HudSourceInfo> = runCatching {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(ctx, uri, null)
            var v: MediaFormat? = null; var hasAudio = false; var aac = false
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (v == null && mime.startsWith("video/")) v = f
                if (mime.startsWith("audio/")) { hasAudio = true; if (mime == MediaFormat.MIMETYPE_AUDIO_AAC) aac = true }
            }
            val vf = v ?: error("Berkas ini tidak berisi video.")
            val rot = if (vf.containsKey(MediaFormat.KEY_ROTATION)) vf.getInteger(MediaFormat.KEY_ROTATION) else metaRotation(ctx, uri)
            val dur = if (vf.containsKey(MediaFormat.KEY_DURATION)) vf.getLong(MediaFormat.KEY_DURATION) / 1e6 else 0.0
            val fps = if (vf.containsKey(MediaFormat.KEY_FRAME_RATE)) vf.getInteger(MediaFormat.KEY_FRAME_RATE).toFloat() else 30f
            HudSourceInfo(vf.getInteger(MediaFormat.KEY_WIDTH), vf.getInteger(MediaFormat.KEY_HEIGHT), ((rot % 360) + 360) % 360, dur, fps, hasAudio, aac)
        } finally { ex.release() }
    }

    private fun metaRotation(ctx: Context, uri: Uri): Int {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
        } catch (e: Exception) { 0 } finally { runCatching { r.release() } }
    }

    /** Nama berkas untuk tampilan. */
    fun displayName(ctx: Context, uri: Uri): String = runCatching {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
    }.getOrNull() ?: (uri.lastPathSegment ?: "video")

    /** Waktu rekaman (epoch ms) dari metadata video (UTC), atau null. Dianggap saat rekaman dimulai. */
    fun createdMs(ctx: Context, uri: Uri): Long? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            val s = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DATE) ?: return null
            val fmt = SimpleDateFormat("yyyyMMdd'T'HHmmss", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
            fmt.parse(s.take(15))?.time?.takeIf { it > 946_684_800_000L }
        } catch (e: Exception) { null } finally { runCatching { r.release() } }
    }

    /** Waktu ubah berkas (epoch ms) bila penyedia berkas mengatakannya; aplikasi kamera mengisinya saat rekaman selesai. */
    fun modifiedMs(ctx: Context, uri: Uri): Long? {
        for ((col, mul) in listOf("last_modified" to 1L, "date_modified" to 1000L, "datetaken" to 1L)) {
            val v = runCatching {
                ctx.contentResolver.query(uri, arrayOf(col), null, null, null)?.use { if (it.moveToFirst() && !it.isNull(0)) it.getLong(0) * mul else null }
            }.getOrNull()
            if (v != null && v > 946_684_800_000L) return v
        }
        return null
    }

    /** Bingkai pada detik [sec] (sudah dirotasi sesuai metadata), diperkecil agar sisi terpanjang <= [maxSide]. */
    fun frameAt(ctx: Context, uri: Uri, sec: Double, maxSide: Int): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            val b = r.getFrameAtTime((sec * 1e6).toLong(), MediaMetadataRetriever.OPTION_CLOSEST) ?: return null
            val m = max(b.width, b.height)
            if (m <= maxSide) b else {
                val f = maxSide.toFloat() / m
                Bitmap.createScaledBitmap(b, (b.width * f).roundToInt().coerceAtLeast(2), (b.height * f).roundToInt().coerceAtLeast(2), true).also { if (it !== b) b.recycle() }
            }
        } catch (e: Exception) { null } finally { runCatching { r.release() } }
    }
}

private fun hudBuf(a: FloatArray): FloatBuffer = ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().also { it.put(a); it.position(0) }

private fun hudCompile(type: Int, src: String): Int {
    val s = GLES20.glCreateShader(type)
    GLES20.glShaderSource(s, src); GLES20.glCompileShader(s)
    val ok = IntArray(1); GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
    check(ok[0] != 0) { "Shader HUD gagal dikompilasi: ${GLES20.glGetShaderInfoLog(s)}" }
    return s
}

private fun hudProgram(vs: String, fs: String): Int {
    val p = GLES20.glCreateProgram()
    GLES20.glAttachShader(p, hudCompile(GLES20.GL_VERTEX_SHADER, vs)); GLES20.glAttachShader(p, hudCompile(GLES20.GL_FRAGMENT_SHADER, fs))
    GLES20.glLinkProgram(p)
    val ok = IntArray(1); GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
    check(ok[0] != 0) { "Program HUD gagal ditautkan: ${GLES20.glGetProgramInfoLog(p)}" }
    return p
}

/**
 * Menempel HUD pada video sumber: video didecode ke SurfaceTexture, digambar lewat OpenGL (dengan rotasi tampilan), HUD ditumpuk
 * sebagai tekstur transparan, lalu hasilnya di-encode H.264. Suara asli (AAC) disalin tanpa di-encode ulang. Blocking di thread
 * pemanggil (thread render). Maksimal [VideoHud.MAX_SEC] detik pertama.
 */
object HudEncoder {
    fun encode(
        ctx: Context, uri: Uri, info: HudSourceInfo, track: RouteVideoTrack, prefs: HudPrefs, offsetSec: Int, fonts: StickerFonts,
        out: File, isActive: () -> Boolean, onProgress: (Float) -> Unit,
    ): Result<Unit> {
        out.parentFile?.mkdirs(); out.delete()
        // Ukuran keluaran: ukuran tampilan, sisi terpanjang <= 1920, genap.
        val scale = min(1f, 1920f / max(info.dispW, info.dispH))
        val W = ((info.dispW * scale).roundToInt() / 2 * 2).coerceAtLeast(2)
        val H = ((info.dispH * scale).roundToInt() / 2 * 2).coerceAtLeast(2)

        var extractor: MediaExtractor? = null
        var decoder: MediaCodec? = null
        var encoder: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var egl: EglCore? = null
        var encSurface: Surface? = null
        var decSurface: Surface? = null
        var st: SurfaceTexture? = null
        var thread: HandlerThread? = null
        var overlay: Bitmap? = null
        var muxerStarted = false
        var videoTrack = -1; var audioTrack = -1
        var progs = IntArray(0)
        var texIds = IntArray(0)
        var ok = false
        try {
            val ex = MediaExtractor(); extractor = ex
            ex.setDataSource(ctx, uri, null)
            var vIdx = -1; var vFmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true) { vIdx = i; vFmt = f; break }
            }
            val vf = vFmt ?: error("Berkas ini tidak berisi video.")
            ex.selectTrack(vIdx)
            val capSec = min(if (info.durationSec > 0) info.durationSec else VideoHud.MAX_SEC.toDouble(), VideoHud.MAX_SEC.toDouble())
            val capUs = (capSec * 1e6).toLong()

            // ---- Encoder ----
            val fps = info.fps.coerceIn(24f, 60f)
            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, W, H).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, (W.toLong() * H * 7).coerceAtMost(30_000_000L).toInt())
                setInteger(MediaFormat.KEY_FRAME_RATE, fps.roundToInt())
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }
            val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC); encoder = enc
            enc.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            encSurface = enc.createInputSurface()
            enc.start()
            val mux = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4); muxer = mux

            // ---- Audio (disalin apa adanya) ----
            var aEx: MediaExtractor? = null
            var aFmt: MediaFormat? = null
            if (prefs.audio && info.hasAudio && info.audioAac) {
                val ae = MediaExtractor(); aEx = ae
                ae.setDataSource(ctx, uri, null)
                for (i in 0 until ae.trackCount) {
                    val f = ae.getTrackFormat(i)
                    if (f.getString(MediaFormat.KEY_MIME) == MediaFormat.MIMETYPE_AUDIO_AAC) { ae.selectTrack(i); aFmt = f; break }
                }
            }

            // ---- GL ----
            val eg = EglCore(encSurface, W, H); egl = eg
            eg.makeCurrent()
            val pVideo = hudProgram(
                """
                uniform mat4 uSt; uniform float uC; uniform float uS; attribute vec2 aPos; attribute vec2 aUv; varying vec2 vUv;
                void main() {
                  vec2 c = aUv - 0.5;
                  vec2 r = vec2(uC * c.x - uS * c.y, uS * c.x + uC * c.y) + 0.5;
                  vUv = (uSt * vec4(r, 0.0, 1.0)).xy;
                  gl_Position = vec4(aPos, 0.0, 1.0);
                }
                """.trimIndent(),
                """
                #extension GL_OES_EGL_image_external : require
                precision mediump float;
                varying vec2 vUv; uniform samplerExternalOES sTex;
                void main() { gl_FragColor = texture2D(sTex, vUv); }
                """.trimIndent(),
            )
            val pOver = hudProgram(
                "attribute vec2 aPos; attribute vec2 aUv; varying vec2 vUv; void main() { vUv = aUv; gl_Position = vec4(aPos, 0.0, 1.0); }",
                "precision mediump float; uniform sampler2D uTex; varying vec2 vUv; void main() { gl_FragColor = texture2D(uTex, vUv); }",
            )
            progs = intArrayOf(pVideo, pOver)
            val tids = IntArray(2); GLES20.glGenTextures(2, tids, 0); texIds = tids
            val oes = tids[0]; val ovTex = tids[1]
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oes)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

            val th = HandlerThread("hud-frames").also { it.start() }; thread = th
            val lock = Object()
            var frameReady = false
            val tex = SurfaceTexture(oes); st = tex
            tex.setOnFrameAvailableListener({ synchronized(lock) { frameReady = true; lock.notifyAll() } }, Handler(th.looper))
            val ds = Surface(tex); decSurface = ds

            // ---- Decoder ----
            val mime = vf.getString(MediaFormat.KEY_MIME)!!
            val dec = MediaCodec.createDecoderByType(mime); decoder = dec
            dec.configure(vf, ds, null, 0)
            dec.start()

            // Quad layar penuh: posisi NDC dan uv (v=0 di bawah, konvensi tekstur video).
            val quad = hudBuf(floatArrayOf(-1f, -1f, 0f, 0f, 1f, -1f, 1f, 0f, -1f, 1f, 0f, 1f, 1f, 1f, 1f, 1f))
            // Quad overlay: bitmap Android berbaris atas lebih dulu, jadi v=0 di atas.
            val quadO = hudBuf(floatArrayOf(-1f, 1f, 0f, 0f, 1f, 1f, 1f, 0f, -1f, -1f, 0f, 1f, 1f, -1f, 1f, 1f))
            val stMat = FloatArray(16)
            val rad = Math.toRadians(info.rotation.toDouble())
            val rc = Math.cos(rad).toFloat(); val rs = Math.sin(rad).toFloat()

            val mini = VideoHud.miniMap(track)
            val vmax = VideoHud.vmax(track)
            val painter = HudPainter(W, H, prefs, mini, fonts)
            val ov = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888); overlay = ov
            val oc = Canvas(ov)
            var overlayReady = false

            val bi = MediaCodec.BufferInfo()
            fun drain(endOfStream: Boolean) {
                while (true) {
                    val i = enc.dequeueOutputBuffer(bi, if (endOfStream) 10_000 else 0)
                    when {
                        i == MediaCodec.INFO_TRY_AGAIN_LATER -> { if (!endOfStream) return }
                        i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            check(!muxerStarted) { "Format keluaran berubah dua kali." }
                            videoTrack = mux.addTrack(enc.outputFormat)
                            val af = aFmt
                            if (af != null) audioTrack = mux.addTrack(af)
                            mux.start(); muxerStarted = true
                        }
                        i >= 0 -> {
                            val buf = enc.getOutputBuffer(i)
                            if (bi.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) bi.size = 0
                            if (bi.size > 0 && buf != null && muxerStarted) {
                                buf.position(bi.offset); buf.limit(bi.offset + bi.size)
                                mux.writeSampleData(videoTrack, buf, bi)
                            }
                            enc.releaseOutputBuffer(i, false)
                            if (bi.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                        }
                    }
                }
            }

            var firstPts = -1L
            val di = MediaCodec.BufferInfo()
            var inputDone = false; var outputDone = false
            var startUs = -1L
            var lastProgress = 0f
            while (!outputDone) {
                if (!isActive()) throw CancellationException("Render dibatalkan.")
                if (!inputDone) {
                    val ii = dec.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val ib = dec.getInputBuffer(ii)!!
                        val sz = ex.readSampleData(ib, 0)
                        val t = ex.sampleTime
                        if (startUs < 0 && t >= 0) startUs = t
                        if (sz < 0 || t < 0 || (startUs >= 0 && t - startUs > capUs)) {
                            dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inputDone = true
                        } else { dec.queueInputBuffer(ii, 0, sz, t, 0); ex.advance() }
                    }
                }
                val oi = dec.dequeueOutputBuffer(di, 10_000)
                if (oi >= 0) {
                    val render = di.size != 0
                    dec.releaseOutputBuffer(oi, render)
                    if (render) {
                        synchronized(lock) {
                            val until = System.currentTimeMillis() + 3000
                            while (!frameReady) {
                                val left = until - System.currentTimeMillis()
                                check(left > 0) { "Bingkai video tidak kunjung tiba dari decoder." }
                                lock.wait(left)
                            }
                            frameReady = false
                        }
                        tex.updateTexImage(); tex.getTransformMatrix(stMat)
                        if (firstPts < 0) firstPts = di.presentationTimeUs
                        val rel = di.presentationTimeUs - firstPts
                        if (rel <= capUs) {
                            // Video
                            GLES20.glViewport(0, 0, W, H)
                            GLES20.glDisable(GLES20.GL_BLEND); GLES20.glDisable(GLES20.GL_DEPTH_TEST)
                            GLES20.glClearColor(0f, 0f, 0f, 1f); GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
                            GLES20.glUseProgram(pVideo)
                            GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(pVideo, "uSt"), 1, false, stMat, 0)
                            GLES20.glUniform1f(GLES20.glGetUniformLocation(pVideo, "uC"), rc)
                            GLES20.glUniform1f(GLES20.glGetUniformLocation(pVideo, "uS"), rs)
                            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
                            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oes)
                            GLES20.glUniform1i(GLES20.glGetUniformLocation(pVideo, "sTex"), 0)
                            val vp = GLES20.glGetAttribLocation(pVideo, "aPos"); val vu = GLES20.glGetAttribLocation(pVideo, "aUv")
                            quad.position(0); GLES20.glEnableVertexAttribArray(vp); GLES20.glVertexAttribPointer(vp, 2, GLES20.GL_FLOAT, false, 16, quad)
                            quad.position(2); GLES20.glEnableVertexAttribArray(vu); GLES20.glVertexAttribPointer(vu, 2, GLES20.GL_FLOAT, false, 16, quad)
                            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
                            GLES20.glDisableVertexAttribArray(vp); GLES20.glDisableVertexAttribArray(vu)

                            // HUD
                            ov.eraseColor(0)
                            val state = VideoHud.stateAt(track, rel / 1e6, offsetSec)
                            painter.draw(oc, VideoHud.values(track, state, vmax))
                            GLES20.glUseProgram(pOver)
                            GLES20.glEnable(GLES20.GL_BLEND); GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA)
                            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
                            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ovTex)
                            if (!overlayReady) {
                                GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, ov, 0)
                                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
                                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
                                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
                                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
                                overlayReady = true
                            } else GLUtils.texSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0, 0, ov)
                            GLES20.glUniform1i(GLES20.glGetUniformLocation(pOver, "uTex"), 0)
                            val op = GLES20.glGetAttribLocation(pOver, "aPos"); val ou = GLES20.glGetAttribLocation(pOver, "aUv")
                            quadO.position(0); GLES20.glEnableVertexAttribArray(op); GLES20.glVertexAttribPointer(op, 2, GLES20.GL_FLOAT, false, 16, quadO)
                            quadO.position(2); GLES20.glEnableVertexAttribArray(ou); GLES20.glVertexAttribPointer(ou, 2, GLES20.GL_FLOAT, false, 16, quadO)
                            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
                            GLES20.glDisableVertexAttribArray(op); GLES20.glDisableVertexAttribArray(ou)

                            eg.setPresentationTime(rel * 1000L)
                            check(eg.swap()) { "Gagal menukar buffer EGL." }
                            drain(false)
                            val p = (rel.toFloat() / capUs.toFloat()).coerceIn(0f, 1f)
                            if (p - lastProgress >= 0.005f) { lastProgress = p; onProgress(p * 0.95f) }
                        }
                    }
                    if (di.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                }
            }
            enc.signalEndOfInputStream()
            drain(true)
            check(muxerStarted) { "Encoder tidak menghasilkan data." }

            // Suara asli: salin sampel AAC apa adanya, dipotong sepanjang video.
            val ae = aEx
            if (ae != null && audioTrack >= 0) {
                val abuf = ByteBuffer.allocate(256 * 1024)
                val ai = MediaCodec.BufferInfo()
                val aStart = ae.sampleTime.coerceAtLeast(0L)
                while (true) {
                    if (!isActive()) throw CancellationException("Render dibatalkan.")
                    abuf.clear()
                    val sz = ae.readSampleData(abuf, 0)
                    if (sz < 0) break
                    val t = ae.sampleTime
                    if (t - aStart > capUs) break
                    ai.set(0, sz, max(0L, t - aStart), if (ae.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                    mux.writeSampleData(audioTrack, abuf, ai)
                    ae.advance()
                }
            }
            runCatching { aEx?.release() }
            ok = true
            onProgress(1f)
        } catch (e: Throwable) {
            if (e is OutOfMemoryError) return Result.failure(IllegalStateException("Memori tidak cukup untuk memproses video ini."))
            return Result.failure(e)
        } finally {
            runCatching { decoder?.stop() }; runCatching { decoder?.release() }
            runCatching { st?.release() }; runCatching { decSurface?.release() }
            runCatching { thread?.quitSafely() }
            runCatching { extractor?.release() }
            runCatching { if (texIds.isNotEmpty()) GLES20.glDeleteTextures(texIds.size, texIds, 0) }
            runCatching { for (p in progs) if (p != 0) GLES20.glDeleteProgram(p) }
            runCatching { egl?.release() }
            runCatching { encSurface?.release() }
            runCatching { encoder?.stop() }; runCatching { encoder?.release() }
            runCatching { if (muxerStarted) muxer?.stop() }
            runCatching { muxer?.release() }
            runCatching { overlay?.recycle() }
            if (!ok) out.delete()
        }
        return Result.success(Unit)
    }
}
