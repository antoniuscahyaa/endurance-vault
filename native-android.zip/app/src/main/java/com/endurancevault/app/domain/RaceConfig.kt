package com.endurancevault.app.domain

/** Bobot km per peran dalam seminggu. */
internal val W: Map<String, Double> = mapOf("long" to .34, "quality" to .15, "medium" to .15, "easy" to .13, "short" to .10)

internal class RC(
    val km: Double, val nm: String, val trail: Boolean, val road: Boolean = false,
    val taper: Int, val tf: List<Double>, val w: Map<String, Double>,
)

/** Padanan RCFG di web. */
internal val RCFG: Map<String, RC> = mapOf(
    "5k" to RC(5.0, "5K", false, false, 1, listOf(.5), mapOf("long" to .24, "quality" to .18, "medium" to .16, "easy" to .13, "short" to .10)),
    "10k" to RC(10.0, "10K", false, false, 1, listOf(.5), mapOf("long" to .26, "quality" to .18, "medium" to .15, "easy" to .13, "short" to .10)),
    "hm" to RC(21.1, "Half marathon", false, false, 2, listOf(.7, .45), mapOf("long" to .30, "quality" to .17, "medium" to .14, "easy" to .13, "short" to .10)),
    "fm" to RC(42.2, "Marathon", false, false, 3, listOf(.75, .55, .4), mapOf("long" to .33, "quality" to .16, "medium" to .15, "easy" to .12, "short" to .10)),
    "none" to RC(0.0, "No Race", false, false, 0, emptyList(), W),
    "pb" to RC(0.0, "Performance Build", false, false, 0, emptyList(), mapOf("long" to .28, "quality" to .18, "medium" to .15, "easy" to .13, "short" to .10)),
    "ultra" to RC(40.0, "Trail", true, false, 2, listOf(.7, .4), W),
    "ultrar" to RC(50.0, "Ultra road", true, true, 2, listOf(.7, .4), W),
)

/** Rentang HR (fraksi HRmax) sesi pace lomba per jenis. */
internal val RBAND: Map<String, DoubleArray> = mapOf(
    "none" to doubleArrayOf(.87, .93), "5k" to doubleArrayOf(.93, .99), "10k" to doubleArrayOf(.90, .96),
    "hm" to doubleArrayOf(.87, .93), "fm" to doubleArrayOf(.82, .88), "ultra" to doubleArrayOf(.74, .82),
    "ultrar" to doubleArrayOf(.76, .84), "pb" to doubleArrayOf(.80, .88),
)

internal fun rcOf(s: PlanSettings): RC = RCFG[s.rtype] ?: RCFG.getValue("ultra")
internal fun raceKmOf(s: PlanSettings): Double {
    val r = rcOf(s)
    return if (r.trail) (s.raceKm?.takeIf { it != 0.0 } ?: 40.0) else r.km
}

internal fun thrBand(s: PlanSettings): List<Int>? {
    val m = Regex("(\\d{2,3})\\D+(\\d{2,3})").find(s.thr) ?: return null
    val a = m.groupValues[1].toInt(); val b = m.groupValues[2].toInt()
    return if (a < b) listOf(a, b) else listOf(b, a)
}

/** Max HR profil hanya boleh berasal dari input manual yang valid. Tidak ada estimasi/fallback. */
internal fun hrMaxEst(s: PlanSettings, logMax: Int = 0): Int =
    s.hrMax?.takeIf { it in 140..240 } ?: 0

internal class RacePaces(val p5: Double, val p10: Double, val phm: Double, val pfm: Double, val thr: Double)

internal fun racePaces(s: PlanSettings): RacePaces? {
    val rc = rcOf(s)
    if (rc.trail) return null
    val g = Js.parseDur(s.goalT); val d = raceKmOf(s)
    if (!(g > 0) || !(d > 0)) return null
    fun t(x: Double) = g * Math.pow(x / d, 1.06)
    val d60 = d * Math.pow(60 / g, 1 / 1.06)
    return RacePaces(t(5.0) / 5, t(10.0) / 10, t(21.0975) / 21.0975, t(42.195) / 42.195, 60 / d60)
}

internal fun raceDetail(s: PlanSettings): String {
    val rc = rcOf(s); val g = Js.parseDur(s.goalT)
    if (rc.trail) {
        var t = "Hari lomba. Mulai pelan, makan dan minum sesuai rencana."
        if (g > 0) t += " Target ${Js.durStr(g)}, rata-rata sekitar ${Js.paceStr(g / raceKmOf(s))}" +
            (if (rc.road) "/km termasuk jalan di pos bantuan." else "/km termasuk tanjakan dan jalan.")
        return t
    }
    var t2 = "Hari lomba ${rc.nm}. Pemanasan sesuai jarak, mulai di pace target dan jangan terlalu cepat di kilometer awal."
    if (g > 0) t2 += " Target ${Js.durStr(g)}, pace ${Js.paceStr(g / raceKmOf(s))}/km."
    return t2
}

internal fun pbLen(s: PlanSettings): Int {
    val n = s.pbCycle.toIntOrNull()
    return if (n == 2 || n == 3 || n == 4) n + 1 else 4
}
internal fun pbFocusOf(s: PlanSettings): String = if (s.pbFocus in setOf("thr", "vo2", "vol")) s.pbFocus else "mix"
internal fun pbWeights(w: Map<String, Double>, f: String): Map<String, Double> {
    val o = w.toMutableMap()
    when (f) {
        "vol" -> { o["long"] = .32; o["quality"] = .12; o["medium"] = .17; o["easy"] = .14 }
        "thr" -> { o["quality"] = .20; o["long"] = .27 }
        "vo2" -> { o["quality"] = .21; o["long"] = .26; o["medium"] = .14 }
    }
    return o
}
