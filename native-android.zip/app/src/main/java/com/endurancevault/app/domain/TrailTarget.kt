package com.endurancevault.app.domain

import kotlin.math.abs
import kotlin.math.max

/**
 * Target sesi trail (jarak + elevation gain) dan peninjauan berkas GPX terhadap target itu.
 * Pengganti logika loop Ungaran: sesi trail kini hanya punya target `km` dan `gain`, rutenya bebas.
 *
 * Murni (tanpa Android), diuji di TrailTargetTest.
 *
 * Toleransi (dipilih agar masuk akal untuk data GPS/GPX, bukan untuk menyulitkan):
 *  - Jarak: ±10% dari target, minimal ±1 km. Jarak GPX stabil antar perangkat, selisih kecil sudah berarti rutenya beda.
 *  - D+: ±15% dari target, minimal ±50 m. Elevasi lebih berisik: jam barometrik, GPX rencana (model elevasi DEM), dan
 *    ambang 3 m di [GpxRoute.stats] bisa beda 10–15% untuk rute yang sama, jadi toleransinya lebih longgar.
 *  - "Hampir sesuai": di luar toleransi tetapi masih dalam 1,5× toleransi. Lebih jauh dari itu = "Belum sesuai".
 */
object TrailTarget {
    const val KM_TOL_PCT = 0.10
    const val KM_TOL_MIN = 1.0
    const val GAIN_TOL_PCT = 0.15
    const val GAIN_TOL_MIN = 50.0
    const val NEAR_FACTOR = 1.5

    /** Urutan = tingkat keparahan: OK < NEAR < OFF. */
    enum class Level { OK, NEAR, OFF }

    /** Hasil satu ukuran (jarak atau D+). [diff] = aktual − target. */
    class Check(val target: Double, val actual: Double, val tol: Double, val level: Level) {
        val diff: Double get() = actual - target
    }

    /**
     * [gain] null bila sesi tidak punya target D+ atau GPX tanpa elevasi ([noElevation]).
     * [lines] = penjelasan siap tampil (Indonesia), satu kalimat per baris.
     */
    class Review(
        val routeName: String, val km: Check, val gain: Check?, val noElevation: Boolean,
        val overall: Level, val lines: List<String>,
    )

    /** Target jarak dan D+ sebuah hari rencana. [gain] null bila sesi tidak punya target D+ (hanya jarak yang dicek). */
    class Target(val km: Double, val gain: Int?)

    /** Awal teks detail sesi trail bertarget; penanda bahwa sesi ini punya target jarak + D+ yang bisa dicek dengan GPX. */
    const val TARGET_PREFIX = "Target trail: ±"
    private const val TARGET_END = "unggah GPX untuk dicek. "

    /** Kalimat target di awal detail sesi trail (diakhiri spasi). Dibuat PlanEngine dan diperbarui oleh [sync]. */
    fun targetText(km: Double, gain: Int?): String =
        if (gain != null && gain > 0) "$TARGET_PREFIX${Js.n(km)} km dan +${Js.idn(gain)} m. Pilih rute yang mendekati keduanya, lalu $TARGET_END"
        else "$TARGET_PREFIX${Js.n(km)} km. Pilih rute yang mendekati target, lalu $TARGET_END"

    fun isTarget(d: PDay): Boolean = d.detail.startsWith(TARGET_PREFIX)

    /** Target sesi, atau null bila bukan sesi trail bertarget (libur, lomba, sudah dibatalkan, atau diganti sepeda). */
    fun targetOf(d: PDay): Target? {
        if (d.kind == Kinds.REST || d.kind == Kinds.RACE || !isTarget(d) || !(d.km > 0)) return null
        return Target(d.km, d.gain?.takeIf { it > 0 })
    }

    /**
     * Selaraskan kalimat target di detail dengan km dan D+ hari ini. Perlu karena km/D+ bisa berubah sesudah plan() dibuat:
     * libur dadakan (bagi km), beban pekan dari Profil, dan sebagainya.
     */
    fun sync(d: PDay) {
        val det = d.detail
        if (!det.startsWith(TARGET_PREFIX) || d.kind == Kinds.REST || d.kind == Kinds.RACE || !(d.km > 0)) return
        val end = det.indexOf(TARGET_END)
        if (end < 0) return
        d.detail = targetText(d.km, d.gain) + det.substring(end + TARGET_END.length)
    }

    fun sync(plan: PlanOutcome) {
        val ok = plan as? PlanOutcome.Ok ?: return
        ok.weeks.forEach { w -> w.days.forEach { sync(it) } }
    }

    /** Saat km sesi diperingan oleh [factor] (<1), D+ target ikut turun sebanding agar kerapatan tanjakan (m/km) tetap. */
    fun scaleGain(d: PDay, factor: Double) {
        if (!isTarget(d)) return
        val g = d.gain ?: return
        d.gain = max(10, (Math.round(g * factor / 10.0) * 10).toInt())
    }

    fun kmTol(targetKm: Double): Double = max(KM_TOL_MIN, targetKm * KM_TOL_PCT)
    fun gainTol(targetGain: Double): Double = max(GAIN_TOL_MIN, targetGain * GAIN_TOL_PCT)

    fun level(diff: Double, tol: Double): Level {
        val a = abs(diff)
        return when {
            a <= tol + 1e-9 -> Level.OK
            a <= tol * NEAR_FACTOR + 1e-9 -> Level.NEAR
            else -> Level.OFF
        }
    }

    /** Bandingkan statistik rute dengan target. [targetGain] null/≤0 = hanya jarak yang dinilai. */
    fun review(routeName: String, targetKm: Double, targetGain: Int?, st: GpxRoute.Stats): Review {
        val kt = kmTol(targetKm)
        val km = Check(targetKm, st.km, kt, level(st.km - targetKm, kt))
        val wantGain = targetGain != null && targetGain > 0
        val noEle = wantGain && !st.hasEle
        val gain = if (wantGain && st.hasEle) {
            val gt = gainTol(targetGain!!.toDouble())
            Check(targetGain.toDouble(), st.up.toDouble(), gt, level(st.up - targetGain.toDouble(), gt))
        } else null

        val lines = ArrayList<String>()
        lines.add(
            when {
                km.level == Level.OK -> "Jarak masuk toleransi (±${Js.fmtKm(kt)} km)."
                km.diff > 0 -> "Jarak lebih ${Js.fmtKm(abs(km.diff))} km dari target. Pendekkan rute atau putar balik lebih awal."
                else -> "Jarak kurang ${Js.fmtKm(abs(km.diff))} km dari target. Perpanjang rute atau tambah satu putaran kecil."
            },
        )
        if (gain != null) {
            val d = Js.roundI(abs(gain.diff))
            lines.add(
                when {
                    gain.level == Level.OK -> "D+ masuk toleransi (±${Js.idn(Js.roundI(gain.tol))} m)."
                    gain.diff > 0 -> "D+ lebih ${Js.idn(d)} m dari target. Pilih rute yang lebih landai."
                    else -> "D+ kurang ${Js.idn(d)} m dari target. Cari rute dengan lebih banyak tanjakan atau ulangi satu tanjakan."
                },
            )
        }
        if (noEle) lines.add("GPX tidak punya data elevasi, jadi D+ tidak bisa dinilai. Hanya jarak yang dicek.")

        val overall = listOfNotNull(km.level, gain?.level).maxByOrNull { it.ordinal } ?: Level.OK
        return Review(routeName, km, gain, noEle, overall, lines)
    }

    /** Teks GPX → hasil review. Melempar [GpxRoute.Err] bila berkas tidak bisa dibaca atau tidak berisi jalur. */
    fun reviewGpx(xml: String, fileName: String, targetKm: Double, targetGain: Int?): Review {
        val (pts, gname) = try { GpxRoute.parsePoints(xml) } catch (e: Exception) { throw GpxRoute.Err("Berkas tidak bisa dibaca sebagai GPX.") }
        if (pts.size < 2) throw GpxRoute.Err("Berkas GPX tidak berisi jalur yang bisa dibaca (minimal 2 titik).")
        val name = gname.ifEmpty { fileName.replace(Regex("\\.[^.]+$"), "").ifEmpty { "Rute" } }
        return review(name, targetKm, targetGain, GpxRoute.stats(pts))
    }

    fun verdict(l: Level): String = when (l) {
        Level.OK -> "Sesuai target"
        Level.NEAR -> "Hampir sesuai target"
        Level.OFF -> "Belum sesuai target"
    }
}
