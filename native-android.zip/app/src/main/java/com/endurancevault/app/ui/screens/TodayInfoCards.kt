package com.endurancevault.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.endurancevault.app.data.DailyEntity
import com.endurancevault.app.domain.ReadinessMetric
import com.endurancevault.app.domain.SleepStage
import com.endurancevault.app.domain.SleepSummary
import com.endurancevault.app.domain.WatchDock
import com.endurancevault.app.ui.i18n.Lang
import com.endurancevault.app.ui.i18n.Text
import org.json.JSONObject
import java.time.LocalDate
import kotlin.math.roundToInt

/*
 * Kartu kecil di tab Hari ini: Tidur semalam (cincin fase) dan Kesiapan (gauge),
 * plus info melayang saat kartu diketuk. Semua gaya mengikuti EvPanel / EvMetricTile yang sudah ada.
 */

// ---------------------------------------------------------------- data

/** Data kartu Tidur. [stages] kosong bila hanya total jam yang diketahui (mis. input manual di Kondisi pagi). */
internal data class TodaySleepUi(
    val totalMin: Int,
    val stages: List<SleepStage>,
    val range: String?,
    val eff: Int?,
    val wakeN: Int?,
    val date: String?,
)

/** Data tambahan malam itu: HR istirahat, HRV, HR saat tidur, laju napas saat tidur. Null bila semuanya kosong. */
internal data class TodaySleepExtra(val rhr: Int?, val hrv: Int?, val sleepHr: Int?, val resp: Double?)

/** [s] dari WatchDock.model.sleep (punya fase); [fallbackHours] dari catatan harian bila jam belum menyediakan malam itu. */
internal fun todaySleepUi(s: SleepSummary?, fallbackHours: Double?): TodaySleepUi? {
    if (s != null && s.asleep > 0) return TodaySleepUi(s.asleep, s.stages, "${s.bed} – ${s.wake}", s.eff, s.wakeN, s.date)
    val min = fallbackHours?.takeIf { it > 0 }?.let { (it * 60).roundToInt() } ?: return null
    return TodaySleepUi(min, emptyList(), null, null, null, null)
}

/**
 * RHR, HRV, HR tidur (raw "shr") dan laju napas tidur (raw "srr") diambil dari baris harian tanggal bangun malam itu
 * (diisi sinkron jam), sehingga tetap terbaca walau jam sedang tidak terhubung. Laju napas jatuh ke ringkasan jam bila kosong.
 */
internal fun todaySleepExtra(daily: List<DailyEntity>, sleep: TodaySleepUi?, summary: SleepSummary?, today: LocalDate): TodaySleepExtra? {
    val from = today.minusDays(1).toString()
    val row = sleep?.date?.let { d -> daily.firstOrNull { it.dateIso == d } }
        ?: daily.filter { it.dateIso >= from && it.dateIso <= today.toString() }.maxByOrNull { it.dateIso }
    val raw = row?.let { runCatching { JSONObject(it.raw) }.getOrNull() }
    fun num(key: String): Double? =
        raw?.takeIf { it.has(key) && !it.isNull(key) }?.optDouble(key, 0.0)?.takeIf { it > 0 }
    val out = TodaySleepExtra(
        rhr = row?.rhr?.takeIf { it > 0 },
        hrv = row?.hrv?.takeIf { it > 0 },
        sleepHr = num("shr")?.roundToInt(),
        resp = num("srr") ?: summary?.resp?.takeIf { it > 0 }?.toDouble(),
    )
    return if (out.rhr == null && out.hrv == null && out.sleepHr == null && out.resp == null) null else out
}

@Composable
private fun sleepStageColor(k: String): Color {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    return when (k) {
        "deep" -> if (dark) Color(0xFF6C63D9) else Color(0xFF534AB7)
        "rem" -> if (dark) Color(0xFF8E87E8) else Color(0xFF7F77DD)
        "light" -> if (dark) Color(0xFFC0BBF2) else Color(0xFFAFA9EC)
        else -> MaterialTheme.colorScheme.primary // awake
    }
}

// ---------------------------------------------------------------- kartu kecil

@Composable
internal fun TodaySleepCard(ui: TodaySleepUi?, modifier: Modifier = Modifier, onClick: () -> Unit) {
    EvPanel(
        modifier.clip(RoundedCornerShape(16.dp)).clickable(
            enabled = ui != null, onClickLabel = Lang.tr("Buka detail tidur"), role = Role.Button, onClick = onClick,
        ),
    ) {
        Column(
            Modifier.fillMaxWidth().padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text("TIDUR SEMALAM", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.align(Alignment.Start))
            SleepRing(ui)
            Row(Modifier.height(20.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                if (ui == null) Text("Belum ada data", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                else ui.stages.filter { it.min > 0 }.forEach {
                    Box(Modifier.size(8.dp).clip(RoundedCornerShape(2.dp)).background(sleepStageColor(it.k)))
                }
            }
        }
    }
}

@Composable
private fun SleepRing(ui: TodaySleepUi?) {
    val track = MaterialTheme.colorScheme.outlineVariant
    val cDeep = sleepStageColor("deep"); val cRem = sleepStageColor("rem")
    val cLight = sleepStageColor("light"); val cAwake = sleepStageColor("awake")
    Box(Modifier.size(88.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = 9.dp.toPx()
            val d = size.minDimension - sw
            val tl = Offset(sw / 2f, sw / 2f)
            val sz = Size(d, d)
            drawArc(track, 0f, 360f, false, tl, sz, style = Stroke(sw))
            if (ui != null) {
                val segs = ui.stages.filter { it.min > 0 }
                if (segs.isEmpty()) {
                    drawArc(cLight, -90f, 360f, false, tl, sz, style = Stroke(sw))
                } else {
                    val tot = segs.sumOf { it.min }.toFloat()
                    val gap = if (segs.size > 1) 3f else 0f
                    var a = -90f
                    segs.forEach { s ->
                        val sweep = s.min / tot * 360f
                        val c = when (s.k) { "deep" -> cDeep; "rem" -> cRem; "light" -> cLight; else -> cAwake }
                        drawArc(c, a + gap / 2f, (sweep - gap).coerceAtLeast(1f), false, tl, sz, style = Stroke(sw))
                        a += sweep
                    }
                }
            }
        }
        Text(ui?.let { WatchDock.hm(it.totalMin) } ?: "–", style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
internal fun TodayReadinessCard(readiness: ReadinessMetric?, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val track = MaterialTheme.colorScheme.outlineVariant
    val progress = MaterialTheme.colorScheme.primary
    EvPanel(
        modifier.clip(RoundedCornerShape(16.dp)).clickable(
            enabled = readiness != null, onClickLabel = Lang.tr("Buka detail kesiapan"), role = Role.Button, onClick = onClick,
        ),
    ) {
        Column(
            Modifier.fillMaxWidth().padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text("KESIAPAN", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.align(Alignment.Start))
            Box(Modifier.size(88.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val sw = 8.dp.toPx()
                    val d = size.minDimension - sw
                    val tl = Offset(sw / 2f, sw / 2f)
                    val sz = Size(d, d)
                    drawArc(track, 135f, 270f, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
                    if (readiness != null) {
                        drawArc(progress, 135f, 270f * (readiness.score.coerceIn(0, 100) / 100f), false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
                    }
                }
                Text(readiness?.score?.toString() ?: "–", style = MaterialTheme.typography.headlineMedium)
            }
            Box(Modifier.height(20.dp), contentAlignment = Alignment.Center) {
                if (readiness != null) Text(readiness.tier, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.tertiary)
                else Text("Belum ada data", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

// ---------------------------------------------------------------- info melayang

@Composable
private fun InfoDialogShell(title: String, subtitle: String?, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth().widthIn(max = 440.dp).heightIn(max = 600.dp),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant),
        ) {
            Column(
                Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(title, style = MaterialTheme.typography.titleMedium)
                        if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Filled.Close, contentDescription = Lang.tr("Tutup"), modifier = Modifier.size(18.dp))
                    }
                }
                content()
            }
        }
    }
}

/** Satu baris bar: label kiri, bar tengah, nilai kanan. */
@Composable
private fun BarRow(label: String, fraction: Float, color: Color, value: String, labelWidth: androidx.compose.ui.unit.Dp, valueWidth: androidx.compose.ui.unit.Dp) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.width(labelWidth), maxLines = 1)
        Box(Modifier.weight(1f).height(8.dp).clip(RoundedCornerShape(4.dp)).background(MaterialTheme.colorScheme.outlineVariant)) {
            Box(Modifier.fillMaxWidth(fraction.coerceIn(0f, 1f)).fillMaxHeight().background(color))
        }
        Text(value, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.End, modifier = Modifier.width(valueWidth), maxLines = 1)
    }
}

private fun oneDecimal(v: Double): String = "%.1f".format(Lang.locale, v)

@Composable
internal fun SleepInfoDialog(ui: TodaySleepUi, debtHours: Double?, extra: TodaySleepExtra?, onDismiss: () -> Unit) {
    val subtitle = ui.range?.let { "$it · ${WatchDock.hm(ui.totalMin)}" } ?: WatchDock.hm(ui.totalMin)
    InfoDialogShell("Tidur semalam", subtitle, onDismiss) {
        val stages = ui.stages.filter { it.min > 0 }
        val tot = stages.sumOf { it.min }.coerceAtLeast(1)
        if (stages.isNotEmpty()) {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                stages.forEach { s ->
                    val pct = (s.min * 100.0 / tot).roundToInt()
                    BarRow(s.label, s.min / tot.toFloat(), sleepStageColor(s.k), "${WatchDock.hm(s.min)} · $pct%", 64.dp, 84.dp)
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            EvMetricTile("Efisiensi", ui.eff?.let { "$it%" } ?: "–", Modifier.weight(1f))
            EvMetricTile("Terbangun", ui.wakeN?.let { "$it×" } ?: "–", Modifier.weight(1f))
            EvMetricTile("Utang 7 hari", debtHours?.let { oneDecimal(it) + " j" } ?: "–", Modifier.weight(1f))
        }
        if (extra != null) {
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Text("DATA MALAM ITU", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                EvMetricTile("HR istirahat (bpm)", extra.rhr?.toString() ?: "–", Modifier.weight(1f))
                EvMetricTile("HRV (ms)", extra.hrv?.toString() ?: "–", Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                EvMetricTile("HR tidur (bpm)", extra.sleepHr?.toString() ?: "–", Modifier.weight(1f))
                EvMetricTile("Napas tidur (/mnt)", extra.resp?.let { oneDecimal(it) } ?: "–", Modifier.weight(1f))
            }
        }
    }
}

@Composable
internal fun ReadinessInfoDialog(readiness: ReadinessMetric, onOpenFull: () -> Unit, onDismiss: () -> Unit) {
    InfoDialogShell("Kesiapan", "${Lang.tr("Skor")} ${readiness.score} · ${Lang.tr(readiness.tier)}", onDismiss) {
        if (readiness.advice.isNotBlank()) {
            Surface(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.72f), shape = RoundedCornerShape(14.dp)) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.Top,
                ) {
                    Icon(Icons.Filled.Info, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    Text(readiness.advice, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                }
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            readiness.parts.forEach { p ->
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    BarRow(p.label, (p.score ?: 0) / 100f, MaterialTheme.colorScheme.primary, p.score?.toString() ?: "–", 120.dp, 28.dp)
                    if (p.detail.isNotBlank()) Text(p.detail, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        OutlinedButton(onClick = onOpenFull, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
            Text("Detail lengkap dan pengaturan")
        }
    }
}
