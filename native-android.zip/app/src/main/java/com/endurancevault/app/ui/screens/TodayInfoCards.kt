package com.endurancevault.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.endurancevault.app.domain.Js
import com.endurancevault.app.domain.ZoneCuts
import com.endurancevault.app.domain.ZoneDay
import com.endurancevault.app.domain.ZonePeriod
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.endurancevault.app.data.DailyEntity
import com.endurancevault.app.domain.ReadinessMetric
import com.endurancevault.app.domain.SleepStage
import com.endurancevault.app.domain.SleepSummary
import com.endurancevault.app.domain.WatchDock
import com.endurancevault.app.ui.i18n.Lang
import com.endurancevault.app.ui.i18n.Text
import org.json.JSONObject
import java.time.LocalDate
import kotlin.math.roundToInt

/*
 * Kartu kecil di tab Hari ini: Tidur semalam (cincin fase) dan Kesiapan (gauge),
 * plus info melayang saat kartu diketuk. Semua gaya mengikuti EvPanel / EvMetricTile yang sudah ada.
 */

// ---------------------------------------------------------------- data

/** Data kartu Tidur. [stages] kosong bila hanya total jam yang diketahui (mis. input manual di Kondisi pagi). */
internal data class TodaySleepUi(
    val totalMin: Int,
    val stages: List<SleepStage>,
    val range: String?,
    val eff: Int?,
    val wakeN: Int?,
    val date: String?,
    /** Skor tidur dari jam (0..100); null bila jam belum mengirim skor untuk malam itu. */
    val score: Int? = null,
)

/** Data tambahan malam itu: HR istirahat, HRV, HR saat tidur, laju napas saat tidur. Null bila semuanya kosong. */
/** Angka utama di tengah cincin kartu Tidur, Kesiapan, dan Zona HR (sedikit lebih kecil dari headlineMedium 25sp). */
@Composable
private fun RingValueStyle() = MaterialTheme.typography.headlineMedium.copy(fontSize = 21.sp, lineHeight = 26.sp)

internal data class TodaySleepExtra(val rhr: Int?, val hrv: Int?, val sleepHr: Int?, val resp: Double?)

/** [s] dari WatchDock.model.sleep (punya fase); [fallbackHours] dari catatan harian bila jam belum menyediakan malam itu. */
internal fun todaySleepUi(s: SleepSummary?, fallbackHours: Double?): TodaySleepUi? {
    if (s != null && s.asleep > 0) return TodaySleepUi(s.asleep, s.stages, "${s.bed} – ${s.wake}", s.eff, s.wakeN, s.date, s.score.takeIf { it > 0 })
    val min = fallbackHours?.takeIf { it > 0 }?.let { (it * 60).roundToInt() } ?: return null
    return TodaySleepUi(min, emptyList(), null, null, null, null)
}

/**
 * RHR, HRV, HR tidur (raw "shr") dan laju napas tidur (raw "srr") diambil dari baris harian tanggal bangun malam itu
 * (diisi sinkron jam), sehingga tetap terbaca walau jam sedang tidak terhubung. Laju napas jatuh ke ringkasan jam bila kosong.
 */
internal fun todaySleepExtra(daily: List<DailyEntity>, sleep: TodaySleepUi?, summary: SleepSummary?, today: LocalDate): TodaySleepExtra? {
    val from = today.minusDays(1).toString()
    val row = sleep?.date?.let { d -> daily.firstOrNull { it.dateIso == d } }
        ?: daily.filter { it.dateIso >= from && it.dateIso <= today.toString() }.maxByOrNull { it.dateIso }
    val raw = row?.let { runCatching { JSONObject(it.raw) }.getOrNull() }
    fun num(key: String): Double? =
        raw?.takeIf { it.has(key) && !it.isNull(key) }?.optDouble(key, 0.0)?.takeIf { it > 0 }
    val out = TodaySleepExtra(
        rhr = row?.rhr?.takeIf { it > 0 },
        hrv = row?.hrv?.takeIf { it > 0 },
        sleepHr = num("shr")?.roundToInt(),
        resp = num("srr") ?: summary?.resp?.takeIf { it > 0 }?.toDouble(),
    )
    return if (out.rhr == null && out.hrv == null && out.sleepHr == null && out.resp == null) null else out
}

@Composable
private fun sleepStageColor(k: String): Color {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    return when (k) {
        "deep" -> if (dark) Color(0xFF6C63D9) else Color(0xFF534AB7)
        "rem" -> if (dark) Color(0xFF8E87E8) else Color(0xFF7F77DD)
        "light" -> if (dark) Color(0xFFC0BBF2) else Color(0xFFAFA9EC)
        else -> MaterialTheme.colorScheme.primary // awake
    }
}

// ---------------------------------------------------------------- kartu kecil

@Composable
internal fun TodaySleepCard(ui: TodaySleepUi?, modifier: Modifier = Modifier, onClick: () -> Unit) {
    TodayRingCard("TIDUR", modifier, enabled = ui != null, onClickLabel = Lang.tr("Buka detail tidur"), onClick = onClick) { SleepRing(ui) }
}

@Composable
private fun SleepRing(ui: TodaySleepUi?) {
    val track = MaterialTheme.colorScheme.outlineVariant
    val cDeep = sleepStageColor("deep"); val cRem = sleepStageColor("rem")
    val cLight = sleepStageColor("light"); val cAwake = sleepStageColor("awake")
    Box(Modifier.fillMaxSize(TODAY_RING_FRACTION), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = 9.dp.toPx()
            val d = size.minDimension - sw
            val tl = Offset(sw / 2f, sw / 2f)
            val sz = Size(d, d)
            drawArc(track, 0f, 360f, false, tl, sz, style = Stroke(sw))
            if (ui != null) {
                val segs = ui.stages.filter { it.min > 0 }
                if (segs.isEmpty()) {
                    drawArc(cLight, -90f, 360f, false, tl, sz, style = Stroke(sw))
                } else {
                    val tot = segs.sumOf { it.min }.toFloat()
                    val gap = if (segs.size > 1) 3f else 0f
                    var a = -90f
                    segs.forEach { s ->
                        val sweep = s.min / tot * 360f
                        val c = when (s.k) { "deep" -> cDeep; "rem" -> cRem; "light" -> cLight; else -> cAwake }
                        drawArc(c, a + gap / 2f, (sweep - gap).coerceAtLeast(1f), false, tl, sz, style = Stroke(sw))
                        a += sweep
                    }
                }
            }
        }
        when {
            ui == null -> Text("–", style = MaterialTheme.typography.titleMedium)
            // Skor jam jadi data utama (besar), durasi tidur kecil tepat di bawahnya.
            ui.score != null -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(ui.score.toString(), style = RingValueStyle(), maxLines = 1)
                Text(WatchDock.hm(ui.totalMin), style = RingDetailStyle(), color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            }
            // Jam belum mengirim skor: tampilkan durasi seperti sebelumnya.
            else -> Text(WatchDock.hm(ui.totalMin), style = MaterialTheme.typography.titleMedium, maxLines = 1)
        }
    }
}

/** Cincin mengisi 75% sisi kartu persegi, jadi ikut menyesuaikan lebar layar (sekitar 80dp pada kartu 107dp). */
private const val TODAY_RING_FRACTION = 0.75f

private val TodayRingOuterShape = RoundedCornerShape(18.dp)
private val TodayRingInnerShape = RoundedCornerShape(14.dp)

/** Teks detail di bawah angka utama cincin: 8sp, sengaja kecil supaya angka utama menonjol. */
@Composable
private fun RingDetailStyle() = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp, lineHeight = 10.sp)

/**
 * Bentuk bersama kartu cincin Hari ini: kartu utama vertikal dengan judul rata tengah, memuat kartu persegi
 * (tinggi = lebar) yang berisi cincin. Tinggi kartu utama mengikuti lebarnya, jadi ketiga kartu selalu sama tinggi.
 */
@Composable
private fun TodayRingCard(
    title: String,
    modifier: Modifier,
    enabled: Boolean = true,
    onClickLabel: String,
    onClick: () -> Unit,
    ring: @Composable BoxScope.() -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    EvPanel(
        modifier.clip(TodayRingOuterShape).clickable(enabled = enabled, onClickLabel = onClickLabel, role = Role.Button, onClick = onClick),
        shape = TodayRingOuterShape,
    ) {
        Column(
            Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 10.dp, bottom = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text(title, style = MaterialTheme.typography.labelMedium, color = cs.primary, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), maxLines = 1)
            Box(
                Modifier.fillMaxWidth().aspectRatio(1f).clip(TodayRingInnerShape).background(cs.surface)
                    .border(0.8.dp, cs.outlineVariant, TodayRingInnerShape),
                contentAlignment = Alignment.Center,
                content = ring,
            )
        }
    }
}

@Composable
internal fun TodayReadinessCard(readiness: ReadinessMetric?, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val track = MaterialTheme.colorScheme.outlineVariant
    val progress = MaterialTheme.colorScheme.primary
    TodayRingCard("KESIAPAN", modifier, enabled = readiness != null, onClickLabel = Lang.tr("Buka detail kesiapan"), onClick = onClick) {
        Box(Modifier.fillMaxSize(TODAY_RING_FRACTION), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val sw = 8.dp.toPx()
                val d = size.minDimension - sw
                val tl = Offset(sw / 2f, sw / 2f)
                val sz = Size(d, d)
                drawArc(track, 135f, 270f, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
                if (readiness != null) {
                    drawArc(progress, 135f, 270f * (readiness.score.coerceIn(0, 100) / 100f), false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
                }
            }
            // Skor besar di tengah, tingkat kesiapan kecil di bawahnya (sama seperti kartu Tidur); tanpa baris tambahan di bawah kartu.
            // Digeser sedikit ke atas dan fontnya 8sp supaya teks tier tidak menyentuh ujung busur di celah bawah.
            Column(Modifier.offset(y = (-4).dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(readiness?.score?.toString() ?: "–", style = RingValueStyle(), maxLines = 1)
                Text(
                    readiness?.tier ?: "Belum ada data",
                    style = RingDetailStyle(),
                    color = if (readiness != null) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                    modifier = Modifier.widthIn(max = 52.dp), textAlign = TextAlign.Center,
                )
            }
        }
    }
}

// ---------------------------------------------------------------- info melayang

@Composable
private fun InfoDialogShell(title: String, subtitle: String?, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth().widthIn(max = 440.dp).heightIn(max = 600.dp),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant),
        ) {
            Column(
                Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(title, style = MaterialTheme.typography.titleMedium)
                        if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Filled.Close, contentDescription = Lang.tr("Tutup"), modifier = Modifier.size(18.dp))
                    }
                }
                content()
            }
        }
    }
}

/** Satu baris bar: label kiri, bar tengah, nilai kanan. */
@Composable
private fun BarRow(label: String, fraction: Float, color: Color, value: String, labelWidth: androidx.compose.ui.unit.Dp, valueWidth: androidx.compose.ui.unit.Dp) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.width(labelWidth), maxLines = 1)
        Box(Modifier.weight(1f).height(8.dp).clip(RoundedCornerShape(4.dp)).background(MaterialTheme.colorScheme.outlineVariant)) {
            Box(Modifier.fillMaxWidth(fraction.coerceIn(0f, 1f)).fillMaxHeight().background(color))
        }
        Text(value, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.End, modifier = Modifier.width(valueWidth), maxLines = 1)
    }
}

private fun oneDecimal(v: Double): String = "%.1f".format(Lang.locale, v)

@Composable
internal fun SleepInfoDialog(
    ui: TodaySleepUi, debtHours: Double?, extra: TodaySleepExtra?,
    summary: SleepSummary? = null, tzMin: Int = 0, onDismiss: () -> Unit,
) {
    val base = ui.range?.let { "$it · ${WatchDock.hm(ui.totalMin)}" } ?: WatchDock.hm(ui.totalMin)
    val subtitle = if (ui.score != null) "${Lang.tr("Skor")} ${ui.score} · $base" else base
    var hypV by remember { mutableStateOf<Int?>(null) }
    InfoDialogShell("Tidur semalam", subtitle, onDismiss) {
        // Grafik fase sepanjang malam: duplikat dari tab Jam (tab Jam tetap punya sendiri).
        if (summary != null && summary.blocks.isNotEmpty()) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("Fase sepanjang malam", style = MaterialTheme.typography.labelLarge)
                Text("atas ke bawah: terjaga · REM · ringan · dalam", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            HypSlider(summary, tzMin, hypV) { hypV = it }
        }
        val stages = ui.stages.filter { it.min > 0 }
        val tot = stages.sumOf { it.min }.coerceAtLeast(1)
        if (stages.isNotEmpty()) {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                stages.forEach { s ->
                    val pct = (s.min * 100.0 / tot).roundToInt()
                    BarRow(s.label, s.min / tot.toFloat(), sleepStageColor(s.k), "${WatchDock.hm(s.min)} · $pct%", 64.dp, 84.dp)
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            EvMetricTile("Efisiensi", ui.eff?.let { "$it%" } ?: "–", Modifier.weight(1f))
            EvMetricTile("Terbangun", ui.wakeN?.let { "$it×" } ?: "–", Modifier.weight(1f))
            EvMetricTile("Utang 7 hari", debtHours?.let { oneDecimal(it) + " j" } ?: "–", Modifier.weight(1f))
        }
        if (extra != null) {
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Text("DATA MALAM ITU", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                EvMetricTile("HR istirahat (bpm)", extra.rhr?.toString() ?: "–", Modifier.weight(1f))
                EvMetricTile("HRV (ms)", extra.hrv?.toString() ?: "–", Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                EvMetricTile("HR tidur (bpm)", extra.sleepHr?.toString() ?: "–", Modifier.weight(1f))
                EvMetricTile("Napas tidur (/mnt)", extra.resp?.let { oneDecimal(it) } ?: "–", Modifier.weight(1f))
            }
        }
    }
}

@Composable
internal fun ReadinessInfoDialog(readiness: ReadinessMetric, onOpenFull: () -> Unit, onDismiss: () -> Unit) {
    InfoDialogShell("Kesiapan", "${Lang.tr("Skor")} ${readiness.score} · ${Lang.tr(readiness.tier)}", onDismiss) {
        if (readiness.advice.isNotBlank()) {
            Surface(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.72f), shape = RoundedCornerShape(14.dp)) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.Top,
                ) {
                    Icon(Icons.Filled.Info, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    Text(readiness.advice, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                }
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            readiness.parts.forEach { p ->
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    BarRow(p.label, (p.score ?: 0) / 100f, MaterialTheme.colorScheme.primary, p.score?.toString() ?: "–", 120.dp, 28.dp)
                    if (p.detail.isNotBlank()) Text(p.detail, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        OutlinedButton(onClick = onOpenFull, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
            Text("Detail lengkap dan pengaturan")
        }
    }
}

// ---------------------------------------------------------------- kartu Zona HR pekan ini

/**
 * Kartu ketiga: distribusi zona HR pekan berjalan (Senin..Minggu), sumber data sama dengan HR ZONES di tab Load.
 * Cincin = lima zona (warna zona HR); angka besar = persen waktu di Z1–2; di bawahnya total durasi semua zona.
 */
@Composable
internal fun TodayHrZoneCard(week: ZonePeriod?, modifier: Modifier = Modifier, onClick: () -> Unit) {
    TodayRingCard("ZONA HR", modifier, onClickLabel = Lang.tr("Buka detail zona HR"), onClick = onClick) { HrZoneRing(week) }
}

@Composable
private fun HrZoneRing(week: ZonePeriod?) {
    val track = MaterialTheme.colorScheme.outlineVariant
    Box(Modifier.fillMaxSize(TODAY_RING_FRACTION), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = 9.dp.toPx()
            val d = size.minDimension - sw
            val tl = Offset(sw / 2f, sw / 2f)
            val sz = Size(d, d)
            drawArc(track, 0f, 360f, false, tl, sz, style = Stroke(sw))
            if (week != null && week.hasData) {
                val tot = week.total.toFloat()
                val gap = if (week.secs.count { it > 0.0 } > 1) 3f else 0f
                var a = -90f
                week.secs.forEachIndexed { i, s ->
                    if (s > 0.0) {
                        val sweep = s.toFloat() / tot * 360f
                        drawArc(DetailZoneColors[i], a + gap / 2f, (sweep - gap).coerceAtLeast(1f), false, tl, sz, style = Stroke(sw))
                        a += sweep
                    }
                }
            }
        }
        val dist = week?.distribution()
        if (week == null || dist == null) {
            Text("–", style = MaterialTheme.typography.titleMedium)
        } else {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(Js.roundI(dist.z1z2).toString(), style = RingValueStyle(), maxLines = 1)
                    Text("%", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 4.dp), maxLines = 1)
                }
                Text(WatchDock.hm((week.total / 60).roundToInt()), style = RingDetailStyle(), color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            }
        }
    }
}

/** Info melayang zona HR pekan ini: ringkasan Z1–2 / Z3 / Z4–5, rincian lima zona, lalu riwayat per hari (ketuk hari untuk rincian zonanya). */
@Composable
internal fun HrZoneWeekDialog(week: ZonePeriod, days: List<ZoneDay>, zc: ZoneCuts, today: LocalDate, onDismiss: () -> Unit) {
    val fmt = remember { java.time.format.DateTimeFormatter.ofPattern("d MMM", Lang.locale) }
    val range = "${week.start.format(fmt)} – ${week.end.format(fmt)}"
    val subtitle = if (week.hasData) "$range · ${week.sessions} ${Lang.tr("sesi")} · ${WatchDock.hm((week.total / 60).roundToInt())}" else range
    var selDay by remember { mutableStateOf<LocalDate?>(null) }
    val bands = remember(zc) { zc.bands() }
    val maxDay = days.maxOfOrNull { it.total }?.coerceAtLeast(1.0) ?: 1.0
    val cs = MaterialTheme.colorScheme
    InfoDialogShell("Distribusi HR minggu ini", subtitle, onDismiss) {
        val dist = week.distribution()
        if (dist == null) {
            Text("Belum ada histogram HR minggu ini.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                EvMetricTile("Z1–2", "${Js.roundI(dist.z1z2)}%", Modifier.weight(1f))
                EvMetricTile("Z3", "${Js.roundI(dist.z3)}%", Modifier.weight(1f))
                EvMetricTile("Z4–5", "${Js.roundI(dist.z4z5)}%", Modifier.weight(1f))
            }
            Text("TOTAL MINGGU INI", style = MaterialTheme.typography.labelMedium, color = cs.primary)
            HrZoneRows(week.secs, week.total, bands)
        }
        HorizontalDivider(color = cs.outlineVariant)
        Text("PER HARI", style = MaterialTheme.typography.labelMedium, color = cs.primary)
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            days.forEach { d ->
                val on = selDay == d.date
                val label = d.date.dayOfWeek.getDisplayName(java.time.format.TextStyle.SHORT, Lang.locale) + " " + d.date.dayOfMonth
                Column {
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                            .then(if (on) Modifier.background(cs.onSurface.copy(alpha = .08f)) else Modifier)
                            .clickable(enabled = d.hasData) { selDay = if (on) null else d.date }
                            .padding(horizontal = 6.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text(
                            label, Modifier.width(58.dp), style = MaterialTheme.typography.bodySmall, maxLines = 1,
                            color = if (d.hasData || d.date == today) cs.onSurface else cs.onSurfaceVariant.copy(alpha = .6f),
                            fontWeight = if (d.date == today) androidx.compose.ui.text.font.FontWeight.Bold else null,
                        )
                        Box(Modifier.weight(1f).height(10.dp).clip(RoundedCornerShape(5.dp)).background(cs.outlineVariant.copy(alpha = .5f))) {
                            if (d.hasData) {
                                Row(Modifier.fillMaxWidth((d.total / maxDay).toFloat().coerceIn(.04f, 1f)).fillMaxHeight()) {
                                    d.secs.forEachIndexed { i, s ->
                                        if (s > 0.0) Box(Modifier.weight(s.toFloat()).fillMaxHeight().background(DetailZoneColors[i]))
                                    }
                                }
                            }
                        }
                        Text(
                            if (d.hasData) WatchDock.hm((d.total / 60).roundToInt()) else "–", Modifier.width(56.dp),
                            style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.End, maxLines = 1,
                        )
                    }
                    if (on) Column(Modifier.padding(start = 6.dp, end = 6.dp, top = 4.dp, bottom = 8.dp)) { HrZoneRows(d.secs, d.total, bands) }
                }
            }
        }
        Text("Ketuk satu hari untuk rincian zonanya.", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
    }
}

/** Lima baris zona: kotak warna, Z#, rentang bpm, durasi, persen dari [total]. */
@Composable
private fun HrZoneRows(secs: DoubleArray, total: Double, bands: List<String>) {
    val cs = MaterialTheme.colorScheme
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        (0 until 5).forEach { i ->
            val s = secs[i]
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.size(12.dp).clip(RoundedCornerShape(3.dp)).background(DetailZoneColors[i]))
                Text("Z${i + 1}", Modifier.width(24.dp), style = MaterialTheme.typography.bodyMedium, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, maxLines = 1)
                Text("${bands[i]} bpm", Modifier.weight(1f), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant, maxLines = 1)
                Text(if (s > 0.0) WatchDock.hm((s / 60).roundToInt()) else "–", Modifier.width(56.dp), style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.End, maxLines = 1)
                Text("${Js.roundI(s / total.coerceAtLeast(1.0) * 100)}%", Modifier.width(38.dp), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, textAlign = TextAlign.End, maxLines = 1)
            }
        }
    }
}
