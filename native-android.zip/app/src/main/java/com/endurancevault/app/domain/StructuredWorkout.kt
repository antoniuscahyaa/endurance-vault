package com.endurancevault.app.domain

import org.json.JSONArray
import org.json.JSONObject

/** Jenis target intensitas satu langkah structured workout; [wire] = nilai `intensity` pada JSON kursus jam (CoursePush). */
enum class StepIntensity(val wire: String, val label: String) {
    NONE("none", "Tanpa target"),
    PACE("pace", "Pace"),
    HR_PERCENT("hrPercent", "Zona HR"),
    CADENCE("cadence", "Cadence"),
}

/**
 * Target intensitas satu langkah. Satuan [low]/[high]: PACE = detik per km (batas tercepat di [low]), HR_PERCENT = % HR maks
 * (20..100), CADENCE = langkah per menit (100..300). Batas disamakan dengan validasi protokol jam (CourseProtobuf.validate)
 * supaya kesalahan input tertangkap di aplikasi, bukan ditolak jam.
 */
data class StepTarget(val type: StepIntensity = StepIntensity.NONE, val low: Int = 0, val high: Int = 0) {
    /** Pesan galat untuk [stepName], atau null bila valid. */
    fun validate(stepName: String): String? = when (type) {
        StepIntensity.NONE -> null
        StepIntensity.PACE -> when {
            low !in 60..900 || high !in 60..900 -> "$stepName: pace harus 1:00 sampai 15:00 per km"
            low > high -> "$stepName: pace tercepat harus lebih kecil dari yang terlambat"
            else -> null
        }
        StepIntensity.HR_PERCENT -> when {
            low == 0 && high == 0 -> "$stepName: pilih zona HR"
            low !in 20..100 || high !in 20..100 -> "$stepName: HR harus 20 sampai 100 % dari HR maks"
            low > high -> "$stepName: batas HR bawah harus lebih kecil dari batas atas"
            else -> null
        }
        StepIntensity.CADENCE -> when {
            low !in 100..300 || high !in 100..300 -> "$stepName: cadence harus 100 sampai 300 langkah/menit"
            low > high -> "$stepName: batas cadence bawah harus lebih kecil dari batas atas"
            else -> null
        }
    }
}

/** Target per jenis langkah. */
data class WorkoutTargets(
    val warmup: StepTarget = StepTarget(),
    val run: StepTarget = StepTarget(),
    val recovery: StepTarget = StepTarget(),
    val cooldown: StepTarget = StepTarget(),
)

/** Membangun payload `{"courses":[...]}` untuk ProtocolGateway.pushCourses dari bentuk interval sederhana. Murni, tanpa Android. */
object StructuredWorkout {
    /** "5:30" -> 330 detik/km; null bila bukan m:ss. */
    fun parsePace(text: String): Int? {
        val m = Regex("(\\d{1,2}):([0-5]\\d)").matchEntire(text.trim()) ?: return null
        return m.groupValues[1].toInt() * 60 + m.groupValues[2].toInt()
    }

    fun formatPace(sec: Int): String = "%d:%02d".format(sec / 60, sec % 60)

    /** Urutkan batas supaya yang kecil di [StepTarget.low]; pengguna boleh mengisi dalam urutan apa pun. */
    fun target(type: StepIntensity, a: Int?, b: Int?): StepTarget = when {
        type == StepIntensity.NONE -> StepTarget()
        a == null || b == null -> StepTarget(type, 0, 0) // input kosong/rusak: dibiarkan 0 agar validate() menolaknya
        else -> StepTarget(type, minOf(a, b), maxOf(a, b))
    }

    /**
     * Batas bawah lima zona HR persis seperti yang dikirim ke jam (VM.syncWatchHrZones): mode HRR memakai kelima batas Karvonen apa
     * adanya; mode LTHR memakai batas Z2..Z5 dan Z1 = min(50% HR maks, awal Z2 - 1). [lo] = ZoneCuts.lo.
     */
    fun watchLowerBounds(mode: String, lo: List<Int>, maxHr: Int): List<Int> =
        if (mode == "hrr") lo else listOf(minOf(Math.round(maxHr * 0.5).toInt(), lo[1] - 1)) + lo.drop(1)

    /** Rentang bpm zona [zone] (1..5): dari batas bawahnya sampai satu bpm sebelum zona berikutnya; Z5 sampai [maxHr]. */
    fun zoneBpm(zone: Int, lower: List<Int>, maxHr: Int): IntRange =
        lower[zone - 1]..(if (zone < 5) lower[zone] - 1 else maxHr)

    /** Target HR untuk zona [zone]: jam hanya menerima % HR maks (20..100), jadi rentang bpm zona dikonversi dan dibulatkan. */
    fun zoneTarget(zone: Int, lower: List<Int>, maxHr: Int): StepTarget {
        if (zone !in 1..5 || lower.size != 5 || maxHr <= 0) return StepTarget(StepIntensity.HR_PERCENT, 0, 0)
        val r = zoneBpm(zone, lower, maxHr)
        fun pct(bpm: Int) = Math.round(bpm * 100.0 / maxHr).toInt().coerceIn(20, 100)
        return StepTarget(StepIntensity.HR_PERCENT, pct(r.first), maxOf(pct(r.first), pct(r.last)))
    }

    /** Galat pertama atau null. */
    fun validate(warmupMin: Int, repeats: Int, runMin: Int, recoveryMin: Int, cooldownMin: Int, t: WorkoutTargets): String? {
        if (!(repeats in 1..20 && runMin in 1..180 && warmupMin in 0..60 && recoveryMin in 0..60 && cooldownMin in 0..60)) return "Durasi/repetisi di luar batas."
        return t.warmup.takeIf { warmupMin > 0 }?.validate("Pemanasan")
            ?: t.run.validate("Lari")
            ?: t.recovery.takeIf { recoveryMin > 0 }?.validate("Recovery")
            ?: t.cooldown.takeIf { cooldownMin > 0 }?.validate("Pendinginan")
    }

    private fun step(kind: String, seconds: Int, t: StepTarget): JSONObject =
        JSONObject().put("kind", kind).put("target", "time").put("value", seconds).put("intensity", t.type.wire).also {
            if (t.type != StepIntensity.NONE) it.put("low", t.low).put("high", t.high)
        }

    /** Pemanasan (1x) -> [repeats] x (lari + recovery) -> pendinginan (1x). Langkah berdurasi 0 dilewati. Panggil [validate] lebih dulu. */
    fun buildPayload(id: String, name: String, warmupMin: Int, repeats: Int, runMin: Int, recoveryMin: Int, cooldownMin: Int, t: WorkoutTargets): JSONObject {
        val blocks = JSONArray()
        if (warmupMin > 0) blocks.put(JSONObject().put("repeat", 1).put("steps", JSONArray().put(step("warmup", warmupMin * 60, t.warmup))))
        val loop = JSONArray().put(step("run", runMin * 60, t.run))
        if (recoveryMin > 0) loop.put(step("rest", recoveryMin * 60, t.recovery))
        blocks.put(JSONObject().put("repeat", repeats).put("steps", loop))
        if (cooldownMin > 0) blocks.put(JSONObject().put("repeat", 1).put("steps", JSONArray().put(step("cooldown", cooldownMin * 60, t.cooldown))))
        return JSONObject().put("courses", JSONArray().put(JSONObject().put("id", id).put("name", name.ifBlank { "EnduranceVault Workout" }).put("blocks", blocks)))
    }
}
