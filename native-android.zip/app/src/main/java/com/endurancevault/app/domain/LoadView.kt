package com.endurancevault.app.domain

import java.time.DayOfWeek
import java.time.LocalDate
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.max

/** Ringkasan strain satu pekan kalender (Senin–Minggu) dari load harian. */
data class WeekStrain(val start: LocalDate, val end: LocalDate, val load: Double, val strain: Double, val monotony: Double?)

/** Histogram HR {bpm: detik} satu aktivitas beserta tanggalnya. */
class DatedHist(val date: LocalDate, val hist: Map<Int, Double>)

/** Detik per zona (Z1..Z5) dalam satu periode (pekan atau bulan) dan jumlah sesi yang punya histogram HR. */
class ZonePeriod(val start: LocalDate, val end: LocalDate, val secs: DoubleArray, val sessions: Int) {
    val total: Double get() = secs.sum()
    val hasData: Boolean get() = total > 0.0

    /** Persentase Z1–2 / Z3 / Z4–5 dari periode ini; null bila kosong. */
    fun distribution(): IntensityDistribution? {
        val t = total
        if (t <= 0.0) return null
        return IntensityDistribution((secs[0] + secs[1]) / t * 100, secs[2] / t * 100, (secs[3] + secs[4]) / t * 100, t)
    }
}

/** Rentetan pekan berurutan dengan fase rencana yang sama. */
data class PhaseRun(val phase: String, val start: LocalDate, val end: LocalDate)

/**
 * Logika murni (tanpa Android) untuk layout tab Load: strain mingguan, periode zona HR, distribusi per rentang tanggal,
 * tick sumbu grafik, teks penjelasan, dan format durasi. Tidak mengubah rumus beban/ACWR/readiness yang sudah ada.
 */
object LoadView {
    private fun f1(x: Double) = String.format(Locale.US, "%.1f", x).replace('.', ',')
    private fun f2(x: Double) = String.format(Locale.US, "%.2f", x).replace('.', ',')

    /** [weeks] pekan penuh (Senin–Minggu) sebelum pekan berjalan, terbaru lebih dulu. */
    fun weeklyStrain(days: List<LoadDay>, today: LocalDate, weeks: Int = 7): List<WeekStrain> {
        val thisMonday = today.with(DayOfWeek.MONDAY)
        return (1..weeks).map { k ->
            val start = thisMonday.minusWeeks(k.toLong())
            val end = start.plusDays(6)
            val ms = ProgressAnalytics.monotonyStrain(days, end)
            WeekStrain(start, end, ms?.load ?: 0.0, ms?.strain ?: 0.0, ms?.monotony)
        }
    }

    /** [count] periode berakhir pada periode berjalan (pekan Senin atau bulan kalender), terbaru lebih dulu. */
    fun zonePeriods(items: List<DatedHist>, zc: ZoneCuts, today: LocalDate, monthly: Boolean, count: Int): List<ZonePeriod> =
        (0 until count).map { k ->
            val start = if (monthly) today.withDayOfMonth(1).minusMonths(k.toLong()) else today.with(DayOfWeek.MONDAY).minusWeeks(k.toLong())
            val end = if (monthly) start.plusMonths(1).minusDays(1) else start.plusDays(6)
            val secs = DoubleArray(5)
            var n = 0
            items.filter { !it.date.isBefore(start) && !it.date.isAfter(end) }.forEach { h ->
                val s = Zones.secs(h.hist, zc)
                if (s.sum() > 0.0) { n++; for (i in 0 until 5) secs[i] += s[i] }
            }
            ZonePeriod(start, end, secs, n)
        }

    /** Distribusi 80/20 (rumus ProgressAnalytics.intensity) untuk aktivitas pada [from]..[to] inklusif. */
    fun distribution(items: List<DatedHist>, from: LocalDate, to: LocalDate, lthr: Int, hrMax: Int): IntensityDistribution? =
        ProgressAnalytics.intensity(items.filter { !it.date.isBefore(from) && !it.date.isAfter(to) }.map { it.hist }, lthr, hrMax)

    /** Gabungkan pekan rencana (mulai, akhir, fase) yang berurutan dan berfase sama menjadi satu blok. */
    fun phaseRuns(weeks: List<Triple<LocalDate, LocalDate, String>>): List<PhaseRun> {
        val out = mutableListOf<PhaseRun>()
        weeks.sortedBy { it.first }.forEach { (s, e, p) ->
            val last = out.lastOrNull()
            if (last != null && last.phase == p) out[out.lastIndex] = last.copy(end = e) else out += PhaseRun(p, s, e)
        }
        return out
    }

    /** Tick sumbu Y: 0 sampai kelipatan "bulat" di atas [maxValue], paling banyak [maxTicks] tick. */
    fun axisTicks(maxValue: Double, maxTicks: Int = 6): List<Int> {
        val steps = listOf(5, 10, 20, 25, 50, 100, 200, 250, 500, 1000, 2000, 5000)
        val mx = max(maxValue, 1.0)
        val st = steps.firstOrNull { ceil(mx / it) <= maxTicks - 1 } ?: steps.last()
        val top = (ceil(mx / st) * st).toInt()
        return (0..top step st).toList()
    }

    /** "1h 45m" (menit dibulatkan ke bawah) atau "45m". */
    fun duration(sec: Double): String {
        val t = sec.toLong().coerceAtLeast(0)
        val h = t / 3600; val m = (t % 3600) / 60
        return if (h > 0) "${h}h ${m}m" else "${m}m"
    }

    /** "1:12:29" atau "27:48". */
    fun clock(sec: Double): String {
        val t = Math.round(sec).coerceAtLeast(0)
        val h = t / 3600; val m = (t % 3600) / 60; val s = t % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%d:%02d", m, s)
    }

    /** 0 = OK, 1 = waspada, 2 = tinggi (acuan Foster: monotony di atas 2,0 dianggap tinggi). */
    fun monotonyLevel(monotony: Double): Int = if (monotony < 1.5) 0 else if (monotony < 2.0) 1 else 2

    fun monotonyLabel(monotony: Double): String = when (monotonyLevel(monotony)) { 0 -> "OK"; 1 -> "WASPADA"; else -> "TINGGI" }

    fun acwrMessage(ratio: Double?): String = when {
        ratio == null -> "Belum cukup hari ber-load (minimal 8 hari dalam 28 hari terakhir) untuk menghitung ACWR."
        ratio < 0.8 -> "ACWR ${f2(ratio)}: pekan ini lebih ringan dari kebiasaan 4 pekanmu. Aman, tetapi kebugaran bisa turun bila berlanjut."
        ratio <= 1.3 -> "ACWR ${f2(ratio)}: beban pekan ini sejalan dengan kebiasaan 4 pekanmu. Zona optimal."
        ratio <= 1.5 -> "ACWR ${f2(ratio)}: beban pekan ini naik cukup cepat dari kebiasaan 4 pekanmu. Waspada; jaga sesi easy tetap ringan."
        else -> "ACWR ${f2(ratio)}: lonjakan beban dibanding kebiasaan 4 pekanmu. Risiko cedera meningkat; pertimbangkan mengurangi volume."
    }

    fun monotonyMessage(monotony: Double?): String = when {
        monotony == null -> "Belum ada load dalam 7 hari terakhir."
        monotony < 1.5 -> "Variasi beban sehat (monotony ${f1(monotony)}). Tidak ada tanda pekan yang terlalu seragam atau terlalu berat."
        monotony < 2.0 -> "Beban mulai seragam (monotony ${f1(monotony)}). Selipkan hari ringan atau libur di antara sesi."
        else -> "Beban terlalu seragam (monotony ${f1(monotony)}). Tambah variasi: hari libur atau sesi yang jauh lebih ringan."
    }

    /**
     * Saran distribusi intensitas terhadap target metode latihan. Metode bawaan memakai [ProgressTabs.intensityAdvice].
     * Kembalian: (nada, teks); nada 0 = sesuai, 1 = perlu perhatian. Hanya rekomendasi.
     */
    fun intensityAdvice(method: String, z1z2: Double, z3: Double, z4z5: Double): Pair<Int, String> {
        val t = TrainingMethod.TARGET[method] ?: return ProgressTabs.intensityAdvice(z1z2, z3)
        val a = Js.roundI(z1z2); val b = Js.roundI(z3); val c = Js.roundI(z4z5)
        val head = "(Z1–2 $a%, Z3 $b%, Z4–5 $c%; target ${TrainingMethod.name(method)}: Z1–2 ${t.lo[0]}–${t.lo[1]}%, Z3 ${t.mid[0]}–${t.mid[1]}%, Z4–5 ${t.hi[0]}–${t.hi[1]}%)"
        return when {
            z3 < t.mid[0] -> 1 to "Z3 hanya $b% $head. Kerjakan blok steady di easy sedang dan long run sesuai rencana."
            z3 > t.mid[1] -> 1 to "Z3 $b% di atas target $head. Jaga easy lebih santai supaya sesi keras tetap berkualitas."
            z1z2 < t.lo[0] -> 1 to "Z1–2 hanya $a% $head. Tambah waktu di easy bila kondisi pulih memungkinkan."
            z4z5 > t.hi[1] -> 1 to "Z4–5 $c% di atas target $head. Kurangi sesi keras atau beri pemulihan lebih panjang."
            z4z5 < t.hi[0] -> 1 to "Z4–5 hanya $c% $head. Kerjakan sesi interval atau tempo sesuai rencana."
            else -> 0 to "Distribusi sesuai target ${TrainingMethod.name(method)} $head."
        }
    }
}
