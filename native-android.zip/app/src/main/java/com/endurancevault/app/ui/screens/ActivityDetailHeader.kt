package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.i18n.Text
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.domain.FeelCheck
import com.endurancevault.app.ui.UiState
import java.util.Locale

/** Teks layar detail ringkasan. Satu tempat agar mudah diterjemahkan. */
internal object DL {
    const val MOVING = "Moving time"; const val TOTAL = "Total time"; const val PACE = "Pace"; const val PACE_TOTAL = "Total pace"
    const val SPEED = "Speed"; const val HEART = "Heart"; const val ELEVATION = "Elevation"; const val FORM = "Form"
    const val BATTERY = "WATCH BATTERY USED"; const val ACTIVE = "TOTAL TIME"; const val GEAR = "Gear (shoes)"; const val NO_GEAR = "No gear"
    const val FEEL = "HOW IT FELT"
    val TABS = listOf("1 · Map overview", "2 · Summary", "3 · Zones & load", "4 · Per km")
    val MONTHS = arrayOf("JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC")
    val MONTHS_FULL = arrayOf("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")
    const val EFFORT_INFO =
        "Effort pace = GAP pace corrected for heat: the pace this same effort would give on flat ground at 15 °C. The heat correction uses your own sensitivity, fitted from your past runs (pace per heart rate vs temperature). Until there are at least 8 runs with a 4 °C spread, a default of 0.13% per °C above 15 °C is used."
    const val FEEL_INFO =
        "Feel 1–10 is matched to your own HR zones: 1–2 = Z1, 3–4 = Z2, 5–6 = Z3, 7–8 = Z4, 9–10 = Z5. The percentage is your average HR against the top of the zone that matches the feel."
}

internal fun trimNum(x: Double, digits: Int): String =
    String.format(Locale.ROOT, "%.${digits}f", x).let { if (it.contains('.')) it.trimEnd('0').trimEnd('.') else it }

internal fun weatherEn(code: Int?): String? = when (code) {
    null -> null
    0 -> "Clear"; 1 -> "Mostly clear"; 2 -> "Partly cloudy"; 3 -> "Overcast"; 45, 48 -> "Fog"
    in 51..57 -> "Drizzle"; in 61..67 -> "Rain"; in 71..77 -> "Snow"; in 80..82 -> "Showers"; 85, 86 -> "Snow showers"
    in 95..99 -> "Thunderstorm"; else -> null
}

/** "Easy · 4 November 2026" */
internal fun headerTitle(kind: String?, dateIso: String, bike: Boolean): String {
    val k = (kind?.takeIf { it.isNotBlank() } ?: if (bike) "bike" else "run").lowercase().replaceFirstChar { it.uppercase() }
    val day = dateIso.substring(8, 10).trimStart('0').ifEmpty { "0" }
    val mon = DL.MONTHS_FULL.getOrNull(dateIso.substring(5, 7).toInt() - 1) ?: ""
    val year = dateIso.substring(0, 4)
    return "$k · $day $mon $year"
}

@Composable
internal fun DetailTopBar(title: String, subtitle: String, onBack: () -> Unit, menu: List<Pair<String, () -> Unit>> = emptyList()) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("‹", fontSize = 26.sp, modifier = Modifier.clickable(onClick = onBack).padding(horizontal = 8.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.5.sp)
            Text(subtitle, fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (menu.isNotEmpty()) {
            var open by remember { mutableStateOf(false) }
            Box {
                Text("⋮", fontSize = 22.sp, modifier = Modifier.clickable { open = true }.padding(horizontal = 12.dp, vertical = 4.dp))
                DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                    menu.forEach { (label, action) ->
                        DropdownMenuItem(text = { Text(label) }, onClick = { open = false; action() })
                    }
                }
            }
        }
    }
}

@Composable
internal fun DetailTabs(page: Int, onPage: (Int) -> Unit) {
    val listState = rememberLazyListState()
    LaunchedEffect(page) { listState.animateScrollToItem(page) }
    LazyRow(Modifier.fillMaxWidth(), state = listState, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        itemsIndexed(DL.TABS) { i, label ->
            val sel = page == i
            val ink = MaterialTheme.colorScheme.onSurface
            Box(
                Modifier.height(34.dp).clip(RoundedCornerShape(17.dp))
                    .background(if (sel) ink else Color.Transparent)
                    .then(if (sel) Modifier else Modifier.border(BorderStroke(1.dp, MaterialTheme.colorScheme.outline), RoundedCornerShape(17.dp)))
                    .clickable { onPage(i) }
                    .padding(horizontal = 14.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label, fontSize = 11.sp, fontWeight = FontWeight.Medium, maxLines = 1, softWrap = false, textAlign = TextAlign.Center,
                    color = if (sel) MaterialTheme.colorScheme.surface else ink,
                )
            }
        }
    }
}

@Composable
internal fun DetailHero(
    kmText: String, plan: String?, timeLabel: String, timeValue: String, paceLabel: String, paceValue: String, paceUnit: String,
    pauseNote: String?, onToggleTime: (() -> Unit)?,
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(kmText, fontSize = 30.sp, fontWeight = FontWeight.Bold, letterSpacing = (-1).sp, lineHeight = 34.sp, maxLines = 1, softWrap = false)
                Text("km", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, softWrap = false, modifier = Modifier.padding(bottom = 4.dp))
            }
            if (plan != null) {
                Box(Modifier.background(MaterialTheme.colorScheme.primary.copy(alpha = .16f), RoundedCornerShape(50)).padding(horizontal = 12.dp, vertical = 5.dp)) {
                    Text(plan, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                }
            }
        }
        Row(Modifier.weight(1f).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.End), verticalAlignment = Alignment.Top) {
            Column(horizontalAlignment = Alignment.End, modifier = if (onToggleTime != null) Modifier.clickable(onClick = onToggleTime) else Modifier) {
                Text(timeLabel, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(timeValue, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
                if (pauseNote != null) Text(pauseNote, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(paceLabel, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(paceValue, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
                    if (paceUnit.isNotEmpty()) Text(paceUnit, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 4.dp))
                }
            }
        }
    }
}

/** Satu baris kartu: label kiri, nilai + satuan kanan. [note] kecil setelah satuan (mis. "km 3"). */
internal class DRow(val label: String, val value: String?, val unit: String? = null, val note: String? = null)

@Composable
internal fun DetailCard(title: String, rows: List<DRow>, modifier: Modifier = Modifier) {
    val shown = rows.filter { it.value != null }
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(horizontal = 12.dp, vertical = 9.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Text(title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        shown.forEachIndexed { i, r ->
            if (i > 0) Box(Modifier.fillMaxWidth().height(0.8.dp).background(MaterialTheme.colorScheme.outline.copy(alpha = .5f)))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.SpaceBetween) {
                Text(r.label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, modifier = Modifier.weight(1f, fill = false).padding(end = 8.dp))
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(r.value ?: "", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
                    r.unit?.let { Text(it, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 2.dp)) }
                    r.note?.let { Text(it, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 2.dp)) }
                }
            }
        }
    }
}

/** Dua kartu sejajar dengan tinggi sama. Kartu tanpa baris tidak ditampilkan. */
@Composable
internal fun DetailCardPair(a: Pair<String, List<DRow>>, b: Pair<String, List<DRow>>) {
    val ea = a.second.any { it.value != null }; val eb = b.second.any { it.value != null }
    if (!ea && !eb) return
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        if (ea) DetailCard(a.first, a.second, Modifier.weight(1f).fillMaxHeight()) else Spacer(Modifier.weight(1f))
        if (eb) DetailCard(b.first, b.second, Modifier.weight(1f).fillMaxHeight()) else Spacer(Modifier.weight(1f))
    }
}

/** Kartu panjang: baterai jam terpakai di kiri, total waktu aktivitas termasuk jeda ([totalTime]) di kanan. */
@Composable
internal fun DetailBatteryCard(usedPct: Int, approx: Boolean, startPct: Int, endPct: Int, perHour: Double?, totalTime: String, totalNote: String?) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(DL.BATTERY, fontSize = 10.sp, fontFamily = FontFamily.Monospace, letterSpacing = 1.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text((if (approx) "~" else "") + "−$usedPct%", fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
            Text(
                "$startPct% → $endPct%" + (perHour?.takeIf { it > 0 }?.let { " · ${trimNum(it, 1)}%/h" } ?: ""),
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(DL.ACTIVE, fontSize = 10.sp, fontFamily = FontFamily.Monospace, letterSpacing = 1.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(totalTime, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
            if (totalNote != null) Text(totalNote, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/** Kartu panjang (gaya sama dengan kartu baterai) berisi baris label kiri / nilai kanan, dipisah garis tipis. Baris tanpa nilai dibuang. */
@Composable
internal fun DetailStatRows(rows: List<DRow>) {
    val shown = rows.filter { it.value != null }
    if (shown.isEmpty()) return
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        shown.forEachIndexed { i, r ->
            if (i > 0) Box(Modifier.fillMaxWidth().height(0.8.dp).background(MaterialTheme.colorScheme.outline.copy(alpha = .5f)))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.SpaceBetween) {
                Text(r.label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(r.value ?: "", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    r.unit?.let { Text(it, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 2.dp)) }
                    r.note?.let { Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 2.dp)) }
                }
            }
        }
    }
}

@Composable
internal fun DetailGear(state: UiState, e: ActivityEntity, onSetGear: (Long, String?) -> Unit) {
    if (state.gear.isEmpty()) {
        DCaption("No gear yet. Add shoes in the Profile tab to pick them here.")
        return
    }
    var open by remember { mutableStateOf(false) }
    val current = state.gear.firstOrNull { it.id == e.gearId }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(DL.GEAR, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Box(Modifier.weight(1.1f)) {
            Row(
                Modifier.fillMaxWidth().height(42.dp).clip(RoundedCornerShape(21.dp)).background(MaterialTheme.colorScheme.surfaceVariant)
                    .clickable { open = true }.padding(horizontal = 20.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text((current?.name ?: DL.NO_GEAR) + if (current?.retired == true) " (retired)" else "", fontSize = 14.sp, maxLines = 1, modifier = Modifier.weight(1f))
                Text("⌄", fontSize = 18.sp)
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                DropdownMenuItem(text = { Text(DL.NO_GEAR) }, onClick = { open = false; onSetGear(e.id, null) })
                state.gear.filter { !it.retired || it.id == e.gearId }.forEach { g ->
                    DropdownMenuItem(text = { Text(g.name + if (g.retired) " (retired)" else "") }, onClick = { open = false; onSetGear(e.id, g.id) })
                }
            }
        }
    }
}

@Composable
internal fun DetailFeel(feel: Int?, check: FeelCheck.Result?, onPick: (Int?) -> Unit) {
    var info by remember { mutableStateOf(false) }
    val primary = MaterialTheme.colorScheme.primary
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(DL.FEEL, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            (1..10).forEach { n ->
                val sel = feel == n
                Box(
                    Modifier.weight(1f).height(30.dp).clip(RoundedCornerShape(15.dp))
                        .background(if (sel) primary else Color.Transparent)
                        .then(if (sel) Modifier else Modifier.border(BorderStroke(1.dp, MaterialTheme.colorScheme.outline), RoundedCornerShape(15.dp)))
                        .clickable { onPick(if (sel) null else n) },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(n.toString(), fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1, softWrap = false, color = if (sel) Color.White else MaterialTheme.colorScheme.onSurface)
                }
            }
        }
        if (check != null) {
            val c = when (check.level) { "ok" -> primary; "warn" -> DetailAmber; else -> DetailBlue }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Top) {
                Text(if (check.level == "ok") "✓" else "!", fontSize = 14.sp, color = c, fontWeight = FontWeight.Bold)
                Text(check.text, fontSize = 13.sp, modifier = Modifier.weight(1f))
            }
        }
        Box(Modifier.fillMaxWidth().height(0.8.dp).background(MaterialTheme.colorScheme.outline.copy(alpha = .5f)))
        Box(
            Modifier.size(30.dp).clip(CircleShape).clickable { info = !info }
                .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape),
            contentAlignment = Alignment.Center,
        ) { Text("i", fontSize = 14.sp, fontFamily = FontFamily.Monospace) }
        if (info) { DCaption(DL.EFFORT_INFO); DCaption(DL.FEEL_INFO) }
    }
}
