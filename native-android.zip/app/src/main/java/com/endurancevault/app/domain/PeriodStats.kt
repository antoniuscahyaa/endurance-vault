package com.endurancevault.app.domain

import com.endurancevault.app.data.ActivityEntity
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters
import kotlin.math.roundToInt

/** Periode kartu statistik yang dibagikan. */
enum class SharePeriod { DAY, WEEK, MONTH }

/**
 * Ringkasan satu periode. [dailyKm] berisi satu angka per hari dari [start] sampai [end] (hari tanpa lari = 0).
 * [avgHr] dirata-rata berbobot durasi.
 */
class PeriodSummary(
    val period: SharePeriod, val start: LocalDate, val end: LocalDate,
    val km: Double, val durationSec: Int, val gain: Int, val sessions: Int,
    val avgHr: Int?, val longestKm: Double, val dailyKm: List<Double>,
) {
    /** Pace rata-rata (menit/km) dari total durasi dan total jarak; null bila belum ada lari. */
    val avgPace: Double? get() = if (km > 0 && durationSec > 0) durationSec / 60.0 / km else null
    val activeDays: Int get() = dailyKm.count { it > 0 }
}

object PeriodStats {
    /** Rentang periode yang memuat [anchor]: minggu Senin sampai Minggu, bulan tanggal 1 sampai hari terakhir. */
    fun range(period: SharePeriod, anchor: LocalDate): Pair<LocalDate, LocalDate> = when (period) {
        SharePeriod.DAY -> anchor to anchor
        SharePeriod.WEEK -> {
            val mon = anchor.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            mon to mon.plusDays(6)
        }
        SharePeriod.MONTH -> anchor.withDayOfMonth(1) to anchor.with(TemporalAdjusters.lastDayOfMonth())
    }

    private fun dateOf(e: ActivityEntity): LocalDate? = runCatching { LocalDate.parse(e.dateIso.take(10)) }.getOrNull()

    /** Hanya lari (bukan sepeda) dengan jarak > 0 yang dihitung. */
    fun summarize(acts: List<ActivityEntity>, period: SharePeriod, anchor: LocalDate): PeriodSummary {
        val (start, end) = range(period, anchor)
        val nDays = (end.toEpochDay() - start.toEpochDay()).toInt() + 1
        val inRange = acts.mapNotNull { a ->
            val d = dateOf(a) ?: return@mapNotNull null
            if (a.type == "bike" || a.km <= 0.0 || d.isBefore(start) || d.isAfter(end)) null else d to a
        }
        val daily = DoubleArray(nDays)
        var km = 0.0; var sec = 0; var gain = 0; var longest = 0.0
        var hrSum = 0.0; var hrSec = 0
        inRange.forEach { (d, a) ->
            daily[(d.toEpochDay() - start.toEpochDay()).toInt()] += a.km
            km += a.km; sec += a.durationSec; gain += a.gain ?: 0
            if (a.km > longest) longest = a.km
            val hr = a.avgHr
            if (hr != null && hr > 0 && a.durationSec > 0) { hrSum += hr.toDouble() * a.durationSec; hrSec += a.durationSec }
        }
        val avgHr = if (hrSec > 0) (hrSum / hrSec).roundToInt() else null
        return PeriodSummary(period, start, end, km, sec, gain, inRange.size, avgHr, longest, daily.toList())
    }
}
