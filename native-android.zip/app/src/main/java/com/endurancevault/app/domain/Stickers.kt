package com.endurancevault.app.domain

import com.endurancevault.app.data.ActivityEntity
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import java.util.Locale

/**
 * Stiker data (port `10c-stiker-data.js`): PNG transparan, satu data per gambar, untuk ditempel di foto.
 * File ini hanya berisi model dan pengaturan (tanpa Android), supaya bisa dites JUnit biasa.
 * Penggambaran ada di `ui/sticker/StickerRenderer.kt`.
 */

/** Satu angka: label, nilai, satuan (padanan `[label, nilai, satuan]` di web). */
data class StickerNum(val label: String, val value: String, val unit: String)

/** Pengaturan tampilan stiker (padanan `STK` / `rl:stk` di web). Nilai tak valid dibersihkan oleh [sanitized]. */
data class StickerPrefs(
    /** w = putih, k = hitam, l = lime. */
    val ink: String = "w",
    val cols: Int = 3,
    /** gabung = satu kartu, pisah = satu PNG per angka. */
    val mode: String = "gabung",
    /** bawah = data di bawah rute, kiri = data di samping. */
    val lay: String = "bawah",
    val order: List<String> = listOf("jarak", "pace", "waktu"),
    val mapFields: Set<String> = Stickers.MAP_KEYS.toSet(),
    /** both = durasi dan persen, dur, pct. */
    val hz: String = "both",
    /** Warna aksen `#rrggbb`; kosong = bawaan palet. */
    val accent: String = "",
    /** off, soft, strong. */
    val panel: String = "off",
    val highlight: Boolean = true,
    val hrLine: Boolean = false,
    /** Isi paket sesi; null = belum pernah dipilih (pakai bawaan). */
    val pack: List<String>? = null,
    val snap: Boolean = true,
) {
    fun sanitized(): StickerPrefs = copy(
        ink = if (ink in setOf("w", "k", "l")) ink else "w",
        cols = if (cols in 2..4) cols else 3,
        mode = if (mode == "pisah") "pisah" else "gabung",
        lay = if (lay == "kiri") "kiri" else "bawah",
        order = order.filter { it in Stickers.NUM_KEYS }.distinct(),
        mapFields = mapFields.filter { it in Stickers.MAP_KEYS }.toSet(),
        hz = if (hz == "dur" || hz == "pct") hz else "both",
        accent = Stickers.hex(accent),
        panel = if (panel == "soft" || panel == "strong") panel else "off",
        pack = pack?.filter { it.length <= 40 }?.take(40),
    )

    fun toJson(): String {
        val o = JsonObject()
        o.addProperty("ink", ink); o.addProperty("cols", cols); o.addProperty("mode", mode); o.addProperty("lay", lay)
        o.add("order", JsonArray().also { a -> order.forEach { a.add(it) } })
        o.add("mf", JsonArray().also { a -> mapFields.forEach { a.add(it) } })
        o.addProperty("hz", hz); o.addProperty("ac", accent); o.addProperty("pn", panel)
        o.addProperty("hl", highlight); o.addProperty("hrl", hrLine); o.addProperty("snap", snap)
        pack?.let { p -> o.add("pkg", JsonArray().also { a -> p.forEach { a.add(it) } }) }
        return o.toString()
    }

    companion object {
        /** Membaca JSON hasil [toJson]; JSON rusak atau kosong menghasilkan pengaturan bawaan. */
        fun fromJson(json: String?): StickerPrefs {
            val d = StickerPrefs()
            val o = runCatching { JsonParser.parseString(json ?: "").asJsonObject }.getOrNull() ?: return d
            fun str(k: String, def: String) = o.get(k)?.takeIf { it.isJsonPrimitive }?.asString ?: def
            fun bool(k: String, def: Boolean) = o.get(k)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isBoolean }?.asBoolean ?: def
            fun list(k: String): List<String>? = o.get(k)?.takeIf { it.isJsonArray }?.asJsonArray
                ?.mapNotNull { e -> e.takeIf { it.isJsonPrimitive }?.asString }
            return StickerPrefs(
                ink = str("ink", d.ink),
                cols = o.get("cols")?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asInt ?: d.cols,
                mode = str("mode", d.mode), lay = str("lay", d.lay),
                order = list("order") ?: d.order,
                mapFields = list("mf")?.toSet() ?: d.mapFields,
                hz = str("hz", d.hz), accent = str("ac", d.accent), panel = str("pn", d.panel),
                highlight = bool("hl", d.highlight), hrLine = bool("hrl", d.hrLine),
                pack = list("pkg"), snap = bool("snap", d.snap),
            ).sanitized()
        }
    }
}

/** Baris tabel segmen: [kind] jenis bawaan (atau null), [custom] true bila label buatan sendiri. */
class StickerSegRow(val name: String, val kind: String?, val custom: Boolean, val d: Double, val min: Double, val pace: Double, val hr: Int?)

/** Satu split km yang layak digambar. */
class StickerSplitRow(val k: Double, val pace: Double, val partial: Boolean)

/**
 * Data satu sesi untuk stiker (padanan `stkModel`). Dibuat lewat [Stickers.forActivity].
 * [hist] histogram HR {bpm: detik}; [zc] batas zona HR dari pengaturan.
 */
class StickerModel(
    val key: String,
    val date: String,
    val name: String,
    val km: Double,
    val min: Double,
    val bike: Boolean,
    val gain: Int?,
    val hr: Int?,
    val cad: Int?,
    val gapPace: Double?,
    val detail: ActDetail?,
    val hist: Map<Int, Double>,
    val zc: ZoneCuts,
) {
    val pace: Double? = if (min > 0 && km > 0) min / km else null

    /** Angka bernilai untuk [key], atau null bila datanya tidak ada pada sesi ini. */
    fun num(key: String): StickerNum? = when (key) {
        "jarak" -> StickerNum("Jarak", Stickers.km2(km), "km")
        "pace" -> pace?.let { StickerNum("Pace", Js.paceStr(it), "/km") }
        "waktu" -> if (min > 0) StickerNum("Waktu", Js.durStr(min), "") else null
        "elev" -> gain?.let { StickerNum("Elevasi naik", it.toString(), "m") }
        "hr" -> hr?.takeIf { it > 0 }?.let { StickerNum("HR rata-rata", it.toString(), "bpm") }
        "kad" -> cad?.takeIf { it > 0 }?.let { StickerNum("Kadens", it.toString(), "spm") }
        "gap" -> gapPace?.takeIf { it > 0 }?.let { StickerNum("GAP", Js.paceStr(it), "/km") }
        else -> null
    }

    /** Kunci yang dipakai menurut urutan ketukan, hanya yang datanya ada. */
    fun keys(order: List<String>): List<String> = order.filter { num(it) != null }

    val hasRoute: Boolean get() = (detail?.route?.size ?: 0) >= 2

    /** Baris tabel segmen; null bila kurang dari dua segmen. */
    val segRows: List<StickerSegRow> by lazy {
        val sg = detail?.segments.orEmpty()
        if (sg.size < 2) emptyList() else sg.map { s ->
            val kind = SegKind.normalize(s.type)
            val text = SegKind.displayLabel(s.label, s.type)
            StickerSegRow(text ?: "Tanpa label", kind, kind == null && text != null, s.d, s.min, s.pace, s.hr)
        }
    }

    /** Segmen yang punya jarak dan pace (untuk bar pace per segmen). */
    val paceSegments: List<Segment> by lazy { detail?.segments.orEmpty().filter { it.d > 0 && it.pace > 0 } }

    val splitRows: List<StickerSplitRow> by lazy {
        detail?.splits.orEmpty().filter { it.pace > 0 && it.pace < 30 }.map { StickerSplitRow(it.k, it.pace, it.partial) }
    }

    val hrTotalSec: Double get() = hist.values.sum()
    val zoneSecs: DoubleArray by lazy { Zones.secs(hist, zc) }

    /** Alasan sebuah grafik tidak tersedia (teks untuk pengguna), atau null bila tersedia. */
    fun graphWhy(id: String): String? = when (id) {
        "tabel-segmen" -> if (segRows.size >= 2) null else NO_SEG
        "bar-segmen" -> if (detail?.segments.orEmpty().count { it.min > 0 } >= 2) null else NO_SEG
        "pace-segmen" -> if (paceSegments.size >= 2) null else NO_SEG
        "split-km" -> if (splitRows.size >= 2) null else "Sesi ini tidak punya data split per km."
        "elevasi" -> if ((detail?.profile?.size ?: 0) >= 2) null else "Sesi ini tidak punya data elevasi."
        "zona-hr-sesi", "zona-hr-tumpuk" -> if (hrTotalSec > 60) null else "Sesi ini tidak punya data HR."
        else -> "Stiker ini belum tersedia di versi native."
    }

    private companion object { const val NO_SEG = "Sesi ini belum punya segmen. Atur lewat Ubah pembagian segmen." }
}

object Stickers {
    val NUM_KEYS = listOf("jarak", "pace", "waktu", "elev", "hr", "kad", "gap")
    val MAP_KEYS = listOf("pace", "jarak", "elev", "hr", "waktu")
    val ACCENTS = listOf("#c6f432", "#4caf7d", "#e8873a", "#3fa9f5", "#e5484d", "#b57bee", "#ffd23f")

    /** Grafik satu file per item, dengan judul. Urutan sama dengan daftar web (yang sudah diport). */
    val GRAPHS: List<Pair<String, String>> = listOf(
        "tabel-segmen" to "Tabel segmen",
        "bar-segmen" to "Bar segmen",
        "pace-segmen" to "Bar pace per segmen",
        "split-km" to "Split per km",
        "elevasi" to "Grafik elevasi",
        "zona-hr-sesi" to "Zona HR sesi",
        "zona-hr-tumpuk" to "Zona HR bar tumpuk",
    )

    const val MAX_PHOTO_STICKERS = 5

    /** Warna zona HR (sama dengan `DetailZoneColors`) dalam RGB. */
    val ZONE_RGB = intArrayOf(0x7F9CD6, 0x3F9E86, 0xD8B04A, 0xE8844F, 0xC84B3B)

    /** Warna label segmen (sama dengan `segKindColor` / `CustomLabelColor`) dalam RGB; null = netral mengikuti palet. */
    fun segRgb(kind: String?, custom: Boolean): Int? = when {
        kind == SegKind.REPETITION -> 0xEA5F0A
        kind == SegKind.STRIDE -> 0x7F9CD6
        kind == SegKind.PROGRESSIVE -> 0x3F9E86
        custom -> 0x9B7FD1
        else -> null
    }

    fun hex(v: String?): String = if (v != null && Regex("^#[0-9a-fA-F]{6}$").matches(v)) v.lowercase(Locale.ROOT) else ""

    /** Dua desimal dengan koma, seperti `stkKm2`. */
    fun km2(km: Double): String = String.format(Locale.ROOT, "%.2f", Js.round(km * 100) / 100).replace('.', ',')

    /** Model stiker untuk satu aktivitas; null bila jaraknya nol. Detail dan histogram HR boleh kosong. */
    fun forActivity(e: ActivityEntity, d: ActDetail?, hist: Map<Int, Double>, zc: ZoneCuts): StickerModel? {
        val km = d?.km?.takeIf { it > 0 } ?: e.km
        if (!(km > 0)) return null
        val bike = e.type == "bike"
        val min = d?.movingMin?.takeIf { it > 0 } ?: (e.durationSec / 60.0)
        val gain = d?.gain ?: e.gain
        val gap = ActInsights.gapOfActivity(d?.gapPace, d?.splits.orEmpty(), gain != null, bike)
        return StickerModel(
            key = e.dateIso, date = e.dateIso.take(10), name = e.name.ifBlank { d?.name.orEmpty() },
            km = km, min = min, bike = bike, gain = gain, hr = d?.hr ?: e.avgHr, cad = d?.cad, gapPace = gap,
            detail = d, hist = d?.hrHist?.takeIf { it.isNotEmpty() } ?: hist, zc = zc,
        )
    }

    /** Id semua stiker yang tersedia untuk sesi ini, urutan sama dengan web (angka, peta, grafik). */
    fun allIds(m: StickerModel, p: StickerPrefs): List<String> {
        val ids = ArrayList<String>()
        val ks = m.keys(p.order)
        if (ks.isNotEmpty()) { if (p.mode == "pisah") ks.forEach { ids.add("n-$it") } else ids.add("n-all") }
        if (m.hasRoute) ids.add("map")
        GRAPHS.forEach { (id, _) -> if (m.graphWhy(id) == null) ids.add(id) }
        return ids
    }

    fun idLabel(id: String, m: StickerModel): String = when {
        id == "n-all" -> "Kartu angka"
        id.startsWith("n-") -> "Angka: " + (m.num(id.removePrefix("n-"))?.label ?: id.removePrefix("n-"))
        id == "map" -> "Template peta"
        else -> GRAPHS.firstOrNull { it.first == id }?.second ?: id
    }

    /** Paket sesi: pilihan pengguna bila ada, kalau tidak kartu angka, peta, dan bar pace per segmen (atau dua stiker pertama). */
    fun packSel(ids: List<String>, p: StickerPrefs): List<String> {
        p.pack?.let { saved -> return ids.filter { it in saved } }
        val d = ids.filter { it.startsWith("n-") || it == "map" || it == "pace-segmen" }
        return d.ifEmpty { ids.take(2) }
    }

    /** Nama berkas: `trainingplan-<item>-<tanggal>.png`; [seq] > 0 menambah nomor urut `01-`. */
    fun fileName(id: String, m: StickerModel, seq: Int = 0): String {
        var nm = if (id.startsWith("n-")) (if (id == "n-all") "angka" else id.removePrefix("n-")) else id
        if (seq > 0) nm = String.format(Locale.ROOT, "%02d-%s", seq, nm)
        return "trainingplan-$nm-${m.date}.png"
    }
}
