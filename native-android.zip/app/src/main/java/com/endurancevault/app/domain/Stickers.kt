package com.endurancevault.app.domain

import com.endurancevault.app.data.ActivityEntity
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import java.util.Locale
import kotlin.math.abs

/**
 * Stiker data (port `10c-stiker-data.js`): PNG transparan, satu data per gambar, untuk ditempel di foto.
 * File ini hanya berisi model dan pengaturan (tanpa Android), supaya bisa dites JUnit biasa.
 * Penggambaran ada di `ui/sticker/StickerRenderer.kt`.
 */

/** Satu angka: label, nilai, satuan (padanan `[label, nilai, satuan]` di web). */
data class StickerNum(val label: String, val value: String, val unit: String)

/** Pengaturan tampilan stiker (padanan `STK` / `rl:stk` di web). Nilai tak valid dibersihkan oleh [sanitized]. */
data class StickerPrefs(
    /** w = putih, k = hitam, l = lime. */
    val ink: String = "w",
    val cols: Int = 3,
    /** gabung = satu kartu, pisah = satu PNG per angka. */
    val mode: String = "gabung",
    /** bawah = data di bawah rute, kiri = data di samping. */
    val lay: String = "bawah",
    val order: List<String> = listOf("jarak", "pace", "waktu"),
    val mapFields: Set<String> = Stickers.MAP_KEYS.toSet(),
    /** both = durasi dan persen, dur, pct. */
    val hz: String = "both",
    /** Warna aksen `#rrggbb`; kosong = bawaan palet. */
    val accent: String = "",
    /** off, soft, strong. */
    val panel: String = "off",
    val highlight: Boolean = true,
    val hrLine: Boolean = false,
    /** Isi paket sesi; null = belum pernah dipilih (pakai bawaan). */
    val pack: List<String>? = null,
    val snap: Boolean = true,
    /** Data angka minggu, urutan sesuai ketukan. */
    val wk: List<String> = listOf("jarak", "waktu", "elev", "sesi"),
    /** Jumlah minggu pada tren pace: 4, 6, atau 8. */
    val trendWeeks: Int = 8,
    /** Warna bar mingguan (zona HR minggu dan target minggu) `#rrggbb`; kosong = bawaan. */
    val weekColor: String = "",
    /** Nama berkas huruf kustom (di `files/sticker_fonts/`) untuk angka dan judul; kosong = bawaan. */
    val fontNum: String = "",
    /** Nama berkas huruf kustom untuk teks isi; kosong = bawaan. */
    val fontBody: String = "",
    /** Warna teks kustom `#rrggbb`; bila diisi, menggantikan pilihan [ink]. */
    val inkCustom: String = "",
    /** Skala ukuran PNG dalam persen (50..300); 100 = ukuran standar. */
    val scale: Int = 100,
    /** Periode stiker statistik: day, week, atau month. */
    val per: String = "week",
    /** Data angka periode, urutan sesuai ketukan. */
    val pf: List<String> = listOf("jarak", "waktu", "pace", "elev"),
) {
    fun sanitized(): StickerPrefs = copy(
        ink = if (ink in setOf("w", "k", "l")) ink else "w",
        cols = if (cols in 2..Stickers.MAX_COLS) cols else 3,
        mode = if (mode == "pisah") "pisah" else "gabung",
        lay = if (lay == "kiri") "kiri" else "bawah",
        order = order.filter { it in Stickers.ALL_NUM_KEYS }.distinct(),
        mapFields = mapFields.filter { it in Stickers.MAP_KEYS }.toSet(),
        hz = if (hz == "dur" || hz == "pct") hz else "both",
        accent = Stickers.hex(accent),
        panel = if (panel == "soft" || panel == "strong") panel else "off",
        pack = pack?.filter { it.length <= 40 }?.take(40),
        wk = wk.filter { it in Stickers.WK_KEYS }.distinct(),
        trendWeeks = if (trendWeeks == 4 || trendWeeks == 6) trendWeeks else 8,
        weekColor = Stickers.hex(weekColor),
        fontNum = Stickers.fontName(fontNum),
        fontBody = Stickers.fontName(fontBody),
        inkCustom = Stickers.hex(inkCustom),
        scale = scale.coerceIn(Stickers.MIN_SCALE, Stickers.MAX_SCALE),
        per = if (per == "day" || per == "month") per else "week",
        pf = pf.filter { it in Stickers.PERIOD_KEYS }.distinct(),
    )

    fun toJson(): String {
        val o = JsonObject()
        o.addProperty("ink", ink); o.addProperty("cols", cols); o.addProperty("mode", mode); o.addProperty("lay", lay)
        o.add("order", JsonArray().also { a -> order.forEach { a.add(it) } })
        o.add("mf", JsonArray().also { a -> mapFields.forEach { a.add(it) } })
        o.addProperty("hz", hz); o.addProperty("ac", accent); o.addProperty("pn", panel)
        o.addProperty("hl", highlight); o.addProperty("hrl", hrLine); o.addProperty("snap", snap)
        o.add("wk", JsonArray().also { a -> wk.forEach { a.add(it) } })
        o.addProperty("tw", trendWeeks); o.addProperty("wc", weekColor)
        o.addProperty("fn", fontNum); o.addProperty("fb", fontBody)
        o.addProperty("ic", inkCustom); o.addProperty("sc", scale)
        o.addProperty("per", per)
        o.add("pf", JsonArray().also { a -> pf.forEach { a.add(it) } })
        pack?.let { p -> o.add("pkg", JsonArray().also { a -> p.forEach { a.add(it) } }) }
        return o.toString()
    }

    companion object {
        /** Membaca JSON hasil [toJson]; JSON rusak atau kosong menghasilkan pengaturan bawaan. */
        fun fromJson(json: String?): StickerPrefs {
            val d = StickerPrefs()
            val o = runCatching { JsonParser.parseString(json ?: "").asJsonObject }.getOrNull() ?: return d
            fun str(k: String, def: String) = o.get(k)?.takeIf { it.isJsonPrimitive }?.asString ?: def
            fun bool(k: String, def: Boolean) = o.get(k)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isBoolean }?.asBoolean ?: def
            fun list(k: String): List<String>? = o.get(k)?.takeIf { it.isJsonArray }?.asJsonArray
                ?.mapNotNull { e -> e.takeIf { it.isJsonPrimitive }?.asString }
            return StickerPrefs(
                ink = str("ink", d.ink),
                cols = o.get("cols")?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asInt ?: d.cols,
                mode = str("mode", d.mode), lay = str("lay", d.lay),
                order = list("order") ?: d.order,
                mapFields = list("mf")?.toSet() ?: d.mapFields,
                hz = str("hz", d.hz), accent = str("ac", d.accent), panel = str("pn", d.panel),
                highlight = bool("hl", d.highlight), hrLine = bool("hrl", d.hrLine),
                pack = list("pkg"), snap = bool("snap", d.snap),
                wk = list("wk") ?: d.wk,
                trendWeeks = o.get("tw")?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asInt ?: d.trendWeeks,
                weekColor = str("wc", d.weekColor),
                fontNum = str("fn", d.fontNum), fontBody = str("fb", d.fontBody),
                inkCustom = str("ic", d.inkCustom),
                scale = o.get("sc")?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asInt ?: d.scale,
                per = str("per", d.per), pf = list("pf") ?: d.pf,
            ).sanitized()
        }
    }
}

/** Baris tabel segmen: [kind] jenis bawaan (atau null), [custom] true bila label buatan sendiri. */
class StickerSegRow(val name: String, val kind: String?, val custom: Boolean, val d: Double, val min: Double, val pace: Double, val hr: Int?)

/** Satu split km yang layak digambar. */
class StickerSplitRow(val k: Double, val pace: Double, val partial: Boolean)

/**
 * Data satu sesi untuk stiker (padanan `stkModel`). Dibuat lewat [Stickers.forActivity].
 * [hist] histogram HR {bpm: detik}; [zc] batas zona HR dari pengaturan.
 */
class StickerModel(
    val key: String,
    val date: String,
    val name: String,
    val km: Double,
    val min: Double,
    val bike: Boolean,
    val gain: Int?,
    val hr: Int?,
    val cad: Int?,
    val gapPace: Double?,
    val detail: ActDetail?,
    val hist: Map<Int, Double>,
    val zc: ZoneCuts,
    /** Pola interval yang terdeteksi (minimal dua repetisi), atau null. */
    val iv: IvResult? = null,
    /** Data minggu rencana dan aktivitas; null = stiker mingguan tidak tersedia. */
    val weekInput: SwInput? = null,
    /** Ringkasan harian/mingguan/bulanan, pembanding, dan target; null = stiker periode tidak tersedia. */
    val periods: PeriodData? = null,
) {
    val pace: Double? = if (min > 0 && km > 0) min / km else null

    /** Angka bernilai untuk [key], atau null bila datanya tidak ada pada sesi ini. */
    fun num(key: String): StickerNum? = when (key) {
        "jarak" -> StickerNum("Jarak", Stickers.km2(km), "km")
        "pace" -> pace?.let { StickerNum("Pace", Js.paceStr(it), "/km") }
        "waktu" -> if (min > 0) StickerNum("Waktu", Js.durStr(min), "") else null
        "elev" -> gain?.let { StickerNum("Elevasi naik", it.toString(), "m") }
        "hr" -> hr?.takeIf { it > 0 }?.let { StickerNum("HR rata-rata", it.toString(), "bpm") }
        "kad" -> cad?.takeIf { it > 0 }?.let { StickerNum("Kadens", it.toString(), "spm") }
        "gap" -> gapPace?.takeIf { it > 0 }?.let { StickerNum("GAP", Js.paceStr(it), "/km") }
        "rep", "piv", "best", "fade", "hrr" -> ivNum(key)
        else -> null
    }

    private fun ivNum(key: String): StickerNum? {
        val v = iv ?: return null
        val st = v.stats; val n = st.n
        return when (key) {
            "rep" -> {
                val dm = v.reps.sumOf { it.d } / n
                StickerNum("Repetisi", "$n×" + (if (dm < 1) (Js.round(dm * 100) * 10).toLong().toString() else Js.fmtKm(dm)), if (dm < 1) "m" else "km")
            }
            "piv" -> StickerNum("Pace interval", Js.paceStr(st.avg), "/km")
            "best" -> StickerNum("Tercepat", Js.paceStr(st.best), "/km")
            "fade" -> {
                val r = Js.round(st.fade).toInt()
                StickerNum("Fade", (if (r > 0) "+" else if (r < 0) "\u2212" else "") + abs(r), "dtk/km")
            }
            "hrr" -> {
                val a = st.hrFirst; val b = st.hrLast
                if (a != null && b != null && a > 0 && b > 0) StickerNum("HR awal→akhir", "$a→$b", "") else null
            }
            else -> null
        }
    }

    /** Konteks minggu sesi ini (minggu rencana yang memuatnya); null untuk sepeda atau sesi di luar rencana. */
    val wkCtx: SwCtx? by lazy {
        val wi = weekInput
        val d = runCatching { java.time.LocalDate.parse(date) }.getOrNull()
        if (bike || wi == null || d == null) null else runCatching { StickerWeeks.contextOf(d, wi, zc) }.getOrNull()
    }

    /** Angka satu minggu dari ringkasan minggu sesi ini, atau null bila datanya tidak ada. */
    fun numWk(key: String): StickerNum? {
        val ws = wkCtx?.summary ?: return null
        return when (key) {
            "jarak" -> StickerNum("Jarak minggu", String.format(Locale.ROOT, "%.1f", Js.round(ws.km * 10) / 10).replace('.', ','), "km")
            "waktu" -> if (ws.min > 0) StickerNum("Waktu minggu", Js.durStr(ws.min), "") else null
            "elev" -> if (ws.gain > 0) StickerNum("Elevasi naik", Js.round(ws.gain).toLong().toString(), "m") else null
            "sesi" -> {
                val n = ws.nDone + ws.nFree
                if (n > 0 || ws.nPlan > 0) StickerNum("Sesi", n.toString(), if (ws.nPlan > 0) "/ ${ws.nPlan}" else "") else null
            }
            "pace" -> ws.pace?.takeIf { it > 0 }?.let { StickerNum("Pace rata-rata", Js.paceStr(it), "/km") }
            "hr" -> ws.hr?.takeIf { it > 0 }?.let { StickerNum("HR rata-rata", Js.round(it).toLong().toString(), "bpm") }
            else -> null
        }
    }

    fun keysWk(order: List<String>): List<String> = order.filter { numWk(it) != null }

    /** Ringkasan periode terpilih ([per] = day, week, month), atau null bila tidak ada datanya. */
    fun periodSummary(per: String): PeriodSummary? = periods?.cur?.get(Stickers.perOf(per))?.takeIf { it.km > 0.0 }

    /** Angka satu periode, atau null bila datanya tidak ada. Label mingguan dan bulanan diberi akhiran "minggu" atau "bulan". */
    fun numPer(key: String, per: String): StickerNum? {
        val s = periodSummary(per) ?: return null
        val suf = when (per) { "week" -> " minggu"; "month" -> " bulan"; else -> "" }
        return when (key) {
            "jarak" -> StickerNum("Jarak$suf", if (per == "day") Stickers.km2(s.km) else Stickers.km1(s.km), "km")
            "waktu" -> if (s.durationSec > 0) StickerNum("Waktu$suf", Js.durStr(s.durationSec / 60.0), "") else null
            "pace" -> s.avgPace?.let { StickerNum("Pace rata-rata", Js.paceStr(it), "/km") }
            "elev" -> if (s.gain > 0) StickerNum("Elevasi naik", s.gain.toString(), "m") else null
            "sesi" -> StickerNum("Sesi lari", s.sessions.toString(), "kali")
            "hari" -> if (per != "day") StickerNum("Hari aktif", s.activeDays.toString(), "hari") else null
            "hr" -> s.avgHr?.takeIf { it > 0 }?.let { StickerNum("HR rata-rata", it.toString(), "bpm") }
            "terpanjang" -> if (s.longestKm > 0.0) StickerNum("Terpanjang", Stickers.km2(s.longestKm), "km") else null
            else -> null
        }
    }

    fun keysPer(order: List<String>, per: String): List<String> = order.filter { numPer(it, per) != null }

    /** Alasan stiker periode tidak tersedia, atau null bila tersedia. */
    private fun periodWhy(id: String, per: String): String? {
        val s = periodSummary(per) ?: return NO_PER
        return when (id) {
            "p-kalender", "p-kurva" -> if (s.period == SharePeriod.DAY) ONLY_RANGE else null
            "p-cincin" -> if ((periods?.target?.get(s.period) ?: 0.0) > 0.0) null else "Tidak ada target rencana pada periode ini."
            "p-banding" -> if (periods?.prev?.get(s.period) != null) null else "Belum ada pembanding untuk periode ini."
            else -> null
        }
    }

    private val trendCache = HashMap<Int, List<SwTrendPt>?>()

    /** Pace mingguan sampai minggu ini (maks. [n] minggu); null bila kurang dari dua minggu punya pace. */
    fun trend(n: Int): List<SwTrendPt>? = trendCache.getOrPut(n) {
        val c = wkCtx; val wi = weekInput
        if (c == null || wi == null) null else runCatching { StickerWeeks.trend(c, wi, zc, n) }.getOrNull()
    }

    /** Kunci yang dipakai menurut urutan ketukan, hanya yang datanya ada. */
    fun keys(order: List<String>): List<String> = order.filter { num(it) != null }

    val hasRoute: Boolean get() = (detail?.route?.size ?: 0) >= 2

    /** Baris tabel segmen; null bila kurang dari dua segmen. */
    val segRows: List<StickerSegRow> by lazy {
        val sg = detail?.segments.orEmpty()
        if (sg.size < 2) emptyList() else sg.map { s ->
            val kind = SegKind.normalize(s.type)
            val text = SegKind.displayLabel(s.label, s.type)
            StickerSegRow(text ?: "Tanpa label", kind, kind == null && text != null, s.d, s.min, s.pace, s.hr)
        }
    }

    /** Segmen yang punya jarak dan pace (untuk bar pace per segmen). */
    val paceSegments: List<Segment> by lazy { detail?.segments.orEmpty().filter { it.d > 0 && it.pace > 0 } }

    val splitRows: List<StickerSplitRow> by lazy {
        detail?.splits.orEmpty().filter { it.pace > 0 && it.pace < 30 }.map { StickerSplitRow(it.k, it.pace, it.partial) }
    }

    val hrTotalSec: Double get() = hist.values.sum()
    val zoneSecs: DoubleArray by lazy { Zones.secs(hist, zc) }

    /** Alasan sebuah grafik tidak tersedia (teks untuk pengguna), atau null bila tersedia. */
    fun graphWhy(id: String, trendWeeks: Int = 8, per: String = "week"): String? = when (id) {
        "p-hero", "p-kalender", "p-kurva", "p-cincin", "p-banding" -> periodWhy(id, per)
        "tabel-segmen" -> if (segRows.size >= 2) null else NO_SEG
        "bar-segmen" -> if (detail?.segments.orEmpty().count { it.min > 0 } >= 2) null else NO_SEG
        "pace-segmen" -> if (paceSegments.size >= 2) null else NO_SEG
        "split-km" -> if (splitRows.size >= 2) null else "Sesi ini tidak punya data split per km."
        "elevasi" -> if ((detail?.profile?.size ?: 0) >= 2) null else "Sesi ini tidak punya data elevasi."
        "pace-repetisi" -> if (iv != null) null else "Belum ada pola interval yang terdeteksi."
        "tren-pace" -> if (trend(trendWeeks) != null) null else "Belum cukup minggu dengan data pace (minimal 2 minggu rencana sampai minggu ini)."
        "zona-hr-minggu" -> if (wkCtx?.summary?.zones != null) null else "Minggu ini belum punya data zona HR."
        "target-minggu" -> {
            val ws = wkCtx?.summary
            if (ws != null && ws.days.isNotEmpty() && ws.planKm > 0) null else "Sesi ini tidak ada di rencana minggu."
        }
        "zona-hr-sesi", "zona-hr-tumpuk" -> if (hrTotalSec > 60) null else "Sesi ini tidak punya data HR."
        else -> "Stiker ini belum tersedia di versi native."
    }

    private companion object {
        const val NO_SEG = "Sesi ini belum punya segmen. Atur lewat Ubah pembagian segmen."
        const val NO_PER = "Belum ada lari di periode ini."
        const val ONLY_RANGE = "Hanya untuk periode mingguan atau bulanan."
    }
}

object Stickers {
    val NUM_KEYS = listOf("jarak", "pace", "waktu", "elev", "hr", "kad", "gap")
    /** Angka dari analisis interval: repetisi, pace interval, tercepat, fade, HR awal ke akhir. */
    val IV_KEYS = listOf("rep", "piv", "best", "fade", "hrr")
    val ALL_NUM_KEYS = NUM_KEYS + IV_KEYS
    /** Angka satu minggu. */
    val WK_KEYS = listOf("jarak", "waktu", "elev", "sesi", "pace", "hr")
    val MAP_KEYS = listOf("pace", "jarak", "elev", "hr", "waktu")
    /** Angka satu periode (harian, mingguan, atau bulanan). */
    val PERIOD_KEYS = listOf("jarak", "waktu", "pace", "elev", "sesi", "hari", "hr", "terpanjang")
    val PERIODS = listOf("day" to "Harian", "week" to "Mingguan", "month" to "Bulanan")
    /** Stiker statistik periode satu file per item (angka periode `p-angka` ditangani terpisah, seperti `n-all`). */
    val PERIOD_GRAPHS: List<Pair<String, String>> = listOf(
        "p-hero" to "Angka besar periode",
        "p-kalender" to "Kalender periode",
        "p-kurva" to "Kurva jarak harian",
        "p-cincin" to "Cincin target",
        "p-banding" to "Banding periode",
    )

    fun perOf(s: String): SharePeriod = when (s) { "day" -> SharePeriod.DAY; "month" -> SharePeriod.MONTH; else -> SharePeriod.WEEK }

    /** Satu desimal dengan koma. */
    fun km1(km: Double): String = String.format(Locale.ROOT, "%.1f", Js.round(km * 10) / 10).replace('.', ',')
    val ACCENTS = listOf("#c6f432", "#4caf7d", "#e8873a", "#3fa9f5", "#e5484d", "#b57bee", "#ffd23f")

    /** Grafik satu file per item, dengan judul. Urutan sama dengan daftar web (yang sudah diport). */
    val GRAPHS: List<Pair<String, String>> = listOf(
        "tabel-segmen" to "Tabel segmen",
        "bar-segmen" to "Bar segmen",
        "pace-segmen" to "Bar pace per segmen",
        "pace-repetisi" to "Pace per repetisi",
        "split-km" to "Split per km",
        "elevasi" to "Grafik elevasi",
        "zona-hr-sesi" to "Zona HR sesi",
        "tren-pace" to "Tren pace mingguan",
        "zona-hr-tumpuk" to "Zona HR bar tumpuk",
        "zona-hr-minggu" to "Zona HR minggu",
        "target-minggu" to "Target minggu",
    )

    const val MAX_PHOTO_STICKERS = 5

    /** Angka per baris: 2 sampai [MAX_COLS]. */
    const val MAX_COLS = 6
    const val MIN_SCALE = 50
    const val MAX_SCALE = 300

    /** Warna zona HR (sama dengan `DetailZoneColors`) dalam RGB. */
    val ZONE_RGB = intArrayOf(0x7F9CD6, 0x3F9E86, 0xD8B04A, 0xE8844F, 0xC84B3B)

    /** Warna label segmen (sama dengan `segKindColor` / `CustomLabelColor`) dalam RGB; null = netral mengikuti palet. */
    fun segRgb(kind: String?, custom: Boolean): Int? = when {
        kind == SegKind.REPETITION -> 0xEA5F0A
        kind == SegKind.STRIDE -> 0x7F9CD6
        kind == SegKind.PROGRESSIVE -> 0x3F9E86
        custom -> 0x9B7FD1
        else -> null
    }

    /** Selisih pace bertanda, mis. +0:12 atau −0:05 (padanan `stkDPace`); d dalam menit/km. */
    fun dPace(d: Double): String {
        val sc = Js.round(abs(d) * 60).toInt()
        val sg = if (d > 0 && sc > 0) "+" else if (d < 0 && sc > 0) "\u2212" else "±"
        return "$sg${sc / 60}:${if (sc % 60 < 10) "0" else ""}${sc % 60}"
    }

    private val FONT_NAME = Regex("[A-Za-z0-9_-]{1,60}\\.(ttf|otf)")

    /** Nama berkas huruf yang aman (tanpa folder), atau kosong. */
    fun fontName(v: String?): String = if (v != null && FONT_NAME.matches(v)) v else ""

    fun hex(v: String?): String = if (v != null && Regex("^#[0-9a-fA-F]{6}$").matches(v)) v.lowercase(Locale.ROOT) else ""

    /** Dua desimal dengan koma, seperti `stkKm2`. */
    fun km2(km: Double): String = String.format(Locale.ROOT, "%.2f", Js.round(km * 100) / 100).replace('.', ',')

    /** Model stiker untuk satu aktivitas; null bila jaraknya nol. Detail dan histogram HR boleh kosong. */
    fun forActivity(
        e: ActivityEntity, d: ActDetail?, hist: Map<Int, Double>, zc: ZoneCuts, weekInput: SwInput? = null, periods: PeriodData? = null,
    ): StickerModel? {
        val km = d?.km?.takeIf { it > 0 } ?: e.km
        if (!(km > 0)) return null
        val bike = e.type == "bike"
        val min = d?.movingMin?.takeIf { it > 0 } ?: (e.durationSec / 60.0)
        val gain = d?.gain ?: e.gain
        val gap = ActInsights.gapOfActivity(d?.gapPace, d?.splits.orEmpty(), gain != null, bike)
        return StickerModel(
            key = e.dateIso, date = e.dateIso.take(10), name = e.name.ifBlank { d?.name.orEmpty() },
            km = km, min = min, bike = bike, gain = gain, hr = d?.hr ?: e.avgHr, cad = d?.cad, gapPace = gap,
            detail = d, hist = d?.hrHist?.takeIf { it.isNotEmpty() } ?: hist, zc = zc,
            iv = runCatching { IntervalAnalysis.analyze(d) }.getOrNull(), weekInput = weekInput, periods = periods,
        )
    }

    /** Id semua stiker yang tersedia untuk sesi ini, urutan sama dengan web (angka, peta, grafik). */
    fun allIds(m: StickerModel, p: StickerPrefs): List<String> {
        val ids = ArrayList<String>()
        val ks = m.keys(p.order)
        if (ks.isNotEmpty()) { if (p.mode == "pisah") ks.forEach { ids.add("n-$it") } else ids.add("n-all") }
        if (m.hasRoute) ids.add("map")
        if (m.keysWk(p.wk).isNotEmpty()) ids.add("wk-all")
        if (m.keysPer(p.pf, p.per).isNotEmpty()) ids.add("p-angka")
        PERIOD_GRAPHS.forEach { (id, _) -> if (m.graphWhy(id, p.trendWeeks, p.per) == null) ids.add(id) }
        GRAPHS.forEach { (id, _) -> if (m.graphWhy(id, p.trendWeeks) == null) ids.add(id) }
        return ids
    }

    fun idLabel(id: String, m: StickerModel): String = when {
        id == "n-all" -> "Kartu angka"
        id.startsWith("n-") -> "Angka: " + (m.num(id.removePrefix("n-"))?.label ?: id.removePrefix("n-"))
        id == "map" -> "Template peta"
        id == "wk-all" -> "Angka minggu"
        id == "p-angka" -> "Angka periode"
        else -> (GRAPHS + PERIOD_GRAPHS).firstOrNull { it.first == id }?.second ?: id
    }

    /** Paket sesi: pilihan pengguna bila ada, kalau tidak kartu angka, peta, dan bar pace per segmen (atau dua stiker pertama). */
    fun packSel(ids: List<String>, p: StickerPrefs): List<String> {
        p.pack?.let { saved -> return ids.filter { it in saved } }
        val d = ids.filter { it.startsWith("n-") || it == "map" || it == "pace-segmen" }
        return d.ifEmpty { ids.take(2) }
    }

    /** Nama berkas: `trainingplan-<item>-<tanggal>.png`; [seq] > 0 menambah nomor urut `01-`. */
    fun fileName(id: String, m: StickerModel, seq: Int = 0): String {
        var nm = if (id.startsWith("n-")) (if (id == "n-all") "angka" else id.removePrefix("n-")) else if (id == "wk-all") "angka-minggu" else if (id == "p-angka") "angka-periode" else id
        if (seq > 0) nm = String.format(Locale.ROOT, "%02d-%s", seq, nm)
        return "trainingplan-$nm-${m.date}.png"
    }
}
