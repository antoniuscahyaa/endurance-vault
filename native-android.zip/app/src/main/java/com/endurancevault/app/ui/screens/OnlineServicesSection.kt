package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.i18n.Text
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.Manifest
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.endurancevault.app.domain.WxSnapshot
import org.json.JSONObject
import org.json.JSONArray

@Composable
fun OnlineServicesSection(
    weather: String, weatherBusy: Boolean, weatherLat: String, weatherLon: String,
    onWeather: (Double,Double,String) -> Unit, onSearchCity: (String) -> Unit, onUseLocation: () -> Unit, onWeatherToWatch: (Double,Double,String) -> Unit,
    weatherWatchStatus: String, agpsStatus: String, onAgps: (Boolean,String) -> Unit, onTestAgps: () -> Unit,
    notifyStatus: String, onNotify: (Boolean,Boolean,Int,Int,Boolean,Map<String,Boolean>) -> Unit, onTestNotify: () -> Unit,
    aiStatus: String, onAiKey: (String) -> Unit,
    weatherSnapshot: WxSnapshot? = null, weatherPlaceLabel: String = "", weatherError: String? = null, weatherNotice: String? = null,
    weatherWatchBusy: Boolean = false, weatherWatchNote: String = "", onRefreshWeather: () -> Unit = {},
) {
    var key by remember { mutableStateOf("") }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        WeatherSettingsSection(
            snapshot = weatherSnapshot, placeLabel = weatherPlaceLabel, busy = weatherBusy, error = weatherError, notice = weatherNotice,
            message = weather, lat = weatherLat, lon = weatherLon, watchStatus = weatherWatchStatus, watchBusy = weatherWatchBusy, watchNote = weatherWatchNote,
            onRefresh = onRefreshWeather, onApplyCoords = onWeather, onSearchCity = onSearchCity, onUseLocation = onUseLocation, onWeatherToWatch = onWeatherToWatch,
        )
        HorizontalDivider()
        Text("AI Coach · Online",style=MaterialTheme.typography.titleLarge)
        Text("Chat ada di tombol melayang pada halaman Beranda. Ringkasan latihan yang relevan dikirim ke Groq hanya saat kamu menekan Kirim di chat. API key dienkripsi dengan Android Keystore dan tidak masuk backup.",style=MaterialTheme.typography.bodySmall)
        OutlinedTextField(key,{key=it},label={Text("Groq API key")},modifier=Modifier.fillMaxWidth(),singleLine=true,visualTransformation=PasswordVisualTransformation())
        OutlinedButton(onClick={onAiKey(key)}){Text("Simpan API key")}
        Text(aiStatus,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

