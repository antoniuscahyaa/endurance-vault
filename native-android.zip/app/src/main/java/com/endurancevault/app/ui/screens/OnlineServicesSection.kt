package com.endurancevault.app.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.Manifest
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import org.json.JSONObject
import org.json.JSONArray
import androidx.core.app.NotificationManagerCompat

@Composable
fun OnlineServicesSection(
    weather: String, weatherBusy: Boolean, weatherLat: String, weatherLon: String,
    onWeather: (Double,Double) -> Unit, onSearchCity: (String) -> Unit, onUseLocation: () -> Unit, onWeatherToWatch: (Double,Double,String) -> Unit,
    weatherWatchStatus: String, agpsStatus: String, onAgps: (Boolean,String) -> Unit, onTestAgps: () -> Unit,
    notifyStatus: String, onNotify: (Boolean,Boolean,Int,Int,Boolean,Map<String,Boolean>) -> Unit, onTestNotify: () -> Unit,
    aiStatus: String, aiMessages: List<Pair<String,String>>, onAiKey: (String) -> Unit,
    onAiSend: (String,String,Boolean) -> Unit, aiBusy: Boolean,
) {
    val ctx = LocalContext.current
    var lat by remember(weatherLat) { mutableStateOf(weatherLat) }
    var lon by remember(weatherLon) { mutableStateOf(weatherLon) }
    var place by remember { mutableStateOf("Lokasi latihan") }
    var city by remember { mutableStateOf("") }
    var key by remember { mutableStateOf("") }
    var question by remember { mutableStateOf("") }
    var webSearch by remember { mutableStateOf(true) }
    val w = runCatching { JSONObject(weatherWatchStatus) }.getOrNull()
    val a = runCatching { JSONObject(agpsStatus) }.getOrNull()
    val n = runCatching { JSONObject(notifyStatus) }.getOrNull()
    var mirror by remember(a?.optString("mirrorUrl")) { mutableStateOf(a?.optString("mirrorUrl")?.takeIf{it!="null"} ?: "") }
    var quietStart by remember { mutableStateOf("22:00") }
    var quietEnd by remember { mutableStateOf("06:00") }
    val locationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants[Manifest.permission.ACCESS_FINE_LOCATION] == true || grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true) onUseLocation()
    }
    var agpsOn by remember(a?.optBoolean("enabled") ?: false) { mutableStateOf(a?.optBoolean("enabled") ?: false) }
    var notifyOn by remember(n?.optBoolean("enabled") ?: false) { mutableStateOf(n?.optBoolean("enabled") ?: false) }
    var quietOn by remember(n?.optBoolean("quietEnabled") ?: false) { mutableStateOf(n?.optBoolean("quietEnabled") ?: false) }
    var screenOff by remember(n?.optBoolean("onlyScreenOff") ?: false) { mutableStateOf(n?.optBoolean("onlyScreenOff") ?: false) }
    var appChoices by remember(n?.toString()) { mutableStateOf(buildMap { val apps=n?.optJSONArray("apps") ?: JSONArray(); for(i in 0 until apps.length()){val x=apps.optJSONObject(i)?:continue;put(x.optString("pkg"),x.optBoolean("on"))} }) }
    fun saveNotify(enabled:Boolean=notifyOn, quiet:Boolean=quietOn, screen:Boolean=screenOff) = onNotify(enabled,quiet,quietStart.toMinutesOrDefault(1320),quietEnd.toMinutesOrDefault(360),screen,appChoices)
    val notificationAccess = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    val agpsMessage = a?.optString("lastError")?.takeIf { it != "null" }
        ?: if ((a?.optLong("lastOkAt") ?: 0L) > 0L) "Unduhan terakhir berhasil (${a?.optLong("lastBytes")} byte)" else "Belum diuji"
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Cuaca & kualitas udara", style=MaterialTheme.typography.titleLarge)
        Text("Prakiraan 7 hari, peluang hujan, angin, dan indeks kualitas udara. Sumber: Open-Meteo.", style=MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(lat,{lat=it},label={Text("Latitude")},modifier=Modifier.weight(1f),singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
            OutlinedTextField(lon,{lon=it},label={Text("Longitude")},modifier=Modifier.weight(1f),singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
        }
        OutlinedTextField(place,{place=it},label={Text("Nama lokasi")},modifier=Modifier.fillMaxWidth(),singleLine=true)
        OutlinedTextField(city,{city=it},label={Text("Cari kota / kabupaten")},modifier=Modifier.fillMaxWidth(),singleLine=true)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            Button(enabled=!weatherBusy&&city.isNotBlank(),onClick={onSearchCity(city)}) { Text("Cari lokasi") }
            OutlinedButton(onClick={locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION))}) { Text("Gunakan GPS") }
        }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            Button(enabled=!weatherBusy,onClick={val x=lat.replace(',', '.').toDoubleOrNull();val y=lon.replace(',', '.').toDoubleOrNull();if(x!=null&&y!=null&&x in -90.0..90.0&&y in -180.0..180.0)onWeather(x,y)}) { Text(if(weatherBusy)"Memuat…" else "Perbarui cuaca & AQI") }
            OutlinedButton(onClick={ctx.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))}) { Text("Pengaturan lokasi") }
        }
        if(weather.isNotBlank()) EvPanel(Modifier.fillMaxWidth()){Text(weather,Modifier.padding(14.dp),style=MaterialTheme.typography.bodyMedium)}
        OutlinedButton(enabled=lat.toDoubleOrNull()!=null&&lon.toDoubleOrNull()!=null,onClick={onWeatherToWatch(lat.toDouble(),lon.toDouble(),place)}) { Text("Kirim cuaca ke Huawei Watch") }
        Text("Status cuaca jam: ${w?.optString("lastError")?.takeIf{it!="null"} ?: w?.optString("lastCondition", "Belum ada pengiriman")}",style=MaterialTheme.typography.bodySmall)
        HorizontalDivider()
        Text("A-GPS Huawei Watch",style=MaterialTheme.typography.titleLarge)
        Text("Mengatur pengambilan data orbit satelit. Server mirror opsional; kosong berarti memakai sumber Broadcom bawaan.",style=MaterialTheme.typography.bodySmall)
        OutlinedTextField(mirror,{mirror=it},label={Text("HTTPS mirror URL (opsional)")},modifier=Modifier.fillMaxWidth(),singleLine=true)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { Switch(agpsOn,{agpsOn=it;onAgps(it,mirror)}); Text(if(agpsOn)"A-GPS aktif" else "A-GPS nonaktif") }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { OutlinedButton(onClick={onAgps(agpsOn,mirror)}){Text("Simpan")}; Button(onClick=onTestAgps){Text("Uji unduh A-GPS") } }
        Text("Status: $agpsMessage",style=MaterialTheme.typography.bodySmall)
        HorizontalDivider()
        Text("Notifikasi ponsel ke jam",style=MaterialTheme.typography.titleLarge)
        Text("Akses notifikasi Android harus diaktifkan manual. Isi notifikasi hanya diteruskan saat ada notifikasi baru; aplikasi tidak menyimpan isi pesan.",style=MaterialTheme.typography.bodySmall)
        OutlinedButton(onClick={ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))}){Text(if(notificationAccess)"Akses notifikasi sudah aktif · Kelola" else "Aktifkan akses notifikasi Android")}
        Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){Switch(notifyOn,{notifyOn=it;saveNotify(enabled=it)});Text("Teruskan notifikasi ke jam")}
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(quietStart,{quietStart=it},label={Text("Mulai tenang HH:mm")},modifier=Modifier.weight(1f),singleLine=true)
            OutlinedTextField(quietEnd,{quietEnd=it},label={Text("Selesai tenang HH:mm")},modifier=Modifier.weight(1f),singleLine=true)
        }
        Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){Switch(quietOn,{quietOn=it;saveNotify(quiet=it)});Text("Aktifkan jam tenang")}
        Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){Switch(screenOff,{screenOff=it;saveNotify(screen=it)});Text("Hanya saat layar ponsel mati")}
        Text("Aplikasi yang diteruskan",style=MaterialTheme.typography.titleMedium)
        appChoices.forEach { (pkg,on) ->
            Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically) {
                Switch(checked=on,onCheckedChange={v->appChoices=appChoices.toMutableMap().also{it[pkg]=v};saveNotify()})
                Text(pkg.substringAfterLast('.'),style=MaterialTheme.typography.bodyMedium)
            }
        }
        Button(onClick={saveNotify()}){Text("Simpan pengaturan notifikasi")}
        Button(onClick=onTestNotify){Text("Kirim notifikasi uji")}
        Text("Status: ${n?.optString("lastResult")?.takeIf{it!="null"} ?: "Belum ada pengiriman"} · terkirim ${n?.optInt("sentCount")?:0}",style=MaterialTheme.typography.bodySmall)
        HorizontalDivider()
        Text("AI Coach · Online",style=MaterialTheme.typography.titleLarge)
        Text("Pertanyaan dan ringkasan latihan yang relevan dikirim ke Groq hanya saat kamu menekan Kirim. API key dienkripsi dengan Android Keystore dan tidak masuk backup.",style=MaterialTheme.typography.bodySmall)
        OutlinedTextField(key,{key=it},label={Text("Groq API key")},modifier=Modifier.fillMaxWidth(),singleLine=true,visualTransformation=PasswordVisualTransformation())
        OutlinedButton(onClick={onAiKey(key)}){Text("Simpan API key")}
        if(aiMessages.isNotEmpty()) EvPanel(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) { aiMessages.takeLast(12).forEach{(role,msg)->Text(if(role=="user")"Kamu: $msg" else "Coach: $msg",style=MaterialTheme.typography.bodyMedium)} } }
        Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){Switch(webSearch,{webSearch=it});Text("Izinkan pencarian web untuk info terbaru")}
        OutlinedTextField(question,{question=it},label={Text("Tanyakan tentang latihanmu…")},modifier=Modifier.fillMaxWidth(),minLines=2)
        Button(enabled=!aiBusy&&question.isNotBlank(),onClick={onAiSend(question,key,webSearch);question=""}){Text(if(aiBusy)"Coach sedang menjawab…" else "Kirim ke AI Coach")}
        Text(aiStatus,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private fun String.toMinutesOrDefault(fallback:Int):Int { val p=split(":"); if(p.size!=2)return fallback; val h=p[0].toIntOrNull()?:return fallback;val m=p[1].toIntOrNull()?:return fallback;return if(h in 0..23&&m in 0..59)h*60+m else fallback }
