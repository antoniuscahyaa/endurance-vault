@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.i18n.Text
import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.EventAvailable
import androidx.compose.material.icons.outlined.ExpandLess
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material.icons.outlined.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.endurancevault.app.domain.AdhRow
import com.endurancevault.app.domain.EasyPace
import com.endurancevault.app.domain.Js
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.ProgressAnalytics
import com.endurancevault.app.domain.RecapAnalytics
import com.endurancevault.app.domain.RecapPlanDay
import com.endurancevault.app.domain.RecapPlanWeek
import com.endurancevault.app.domain.RecapPr
import com.endurancevault.app.domain.RecapRun
import com.endurancevault.app.domain.TrainingMetrics
import com.endurancevault.app.domain.WeekBucket
import com.endurancevault.app.domain.WeeklyMetric
import com.endurancevault.app.domain.rcOf
import com.endurancevault.app.ui.UiState
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle as JTextStyle
import java.util.Locale
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlinx.coroutines.launch

/**
 * Tab "Rekap" native, disamakan dengan tab Rekap di rencana lari (web): tujuh kartu
 * (Kepatuhan rencana, Progres, Grafik mingguan, Ulasan mingguan, Log bulanan, Kalender konsistensi, Heatmap tahunan).
 *
 * Layout mengikuti referensi layar:
 * - Mode tutup: kartu berkepala ikon bulat + label mono huruf besar + chevron. Progres, Ulasan mingguan, dan Log bulanan
 *   setengah lebar (dua kolom); kartu lain selebar layar. Isi tutup = ringkasan (angka utama, penanda, visual mini).
 * - Mode buka: kartu menjadi selebar layar (pasangan setengah lebar ikut turun), ringkasan diganti isi, kepala diberi
 *   garis pemisah dan keterangan di kanan, kontrol berupa segmen/lingkaran, dan isi bersarang di panel berbingkai.
 * Logika ada di domain/RecapAnalytics.kt (diuji di JVM).
 */
private val ID_LOC = com.endurancevault.app.ui.i18n.Lang.locale
private val DOW_ID = listOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min")
private val MONO = FontFamily.Monospace
internal val WARN = Color(0xFFB9822B)
private val BIKE_BLUE = Color(0xFF4C8FE0)
private val STRENGTH_RED = Color(0xFFE0605A)
internal val GRAD = SolidColor(Color(0xFFEA5F0A))

private fun monShort(m: Int): String = java.time.Month.of(m).getDisplayName(JTextStyle.SHORT, ID_LOC)
private fun f1(x: Double): String = String.format(Locale.US, "%.1f", x).replace('.', ',')
private fun f2(x: Double): String = String.format(Locale.US, "%.2f", x).replace('.', ',')
private fun fkm(x: Double): String = if (x == floor(x)) x.toLong().toString() else f1(x)
private fun dmy(d: LocalDate) = "${d.dayOfMonth} ${monShort(d.monthValue)}"
private fun durHm(min: Double): String { val t = Js.roundI(min); return if (t >= 60) "${t / 60}j ${t % 60}m" else "${t}m" }
private fun parseGoalMin(s: String): Double? {
    val p = s.trim().split(":").mapNotNull { it.toDoubleOrNull() }
    return when (p.size) { 3 -> p[0] * 60 + p[1] + p[2] / 60; 2 -> p[0] + p[1] / 60; else -> null }?.takeIf { it > 0 }
}

/** Hari libur dadakan, sesi dilewati, dan sesi yang digeser keluar tidak dihitung sebagai sesi jatuh tempo di kepatuhan. */
private fun excludedDates(mv: Map<String, com.endurancevault.app.domain.MvEntry>): Set<LocalDate> =
    mv.filter { (k, e) -> !k.startsWith("sw:") && (e.t == "spread" || e.t == "skip" || e.t == "mv") }
        .keys.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.toSet()

private fun prsAsOf(state: UiState, end: LocalDate): List<RecapPr> {
    val det = state.detailsByActivity.filterValues { d -> runCatching { !LocalDate.parse(d.date).isAfter(end) }.getOrDefault(false) }
    return ProgressAnalytics.personalBests(det).mapNotNull { b ->
        runCatching { RecapPr(b.label, b.distanceKm, b.durationMinutes, LocalDate.parse(b.dateIso)) }.getOrNull()
    }
}

/** True bila kartu Kepatuhan menyarankan geser rencana (penanda cincin amber pada chip Rekap). */
internal fun recapNeedsAttention(state: UiState): Boolean = runCatching {
    val today = LocalDate.now()
    val weeks = (state.plan as? PlanOutcome.Ok)?.weeks.orEmpty().map { w ->
        RecapPlanWeek(w.i, w.start, w.km, w.days.map { RecapPlanDay(it.date, it.kind, it.km, it.bench) }, w.cut)
    }
    val runDates = state.activities.filter { it.type != "bike" && it.km > 0 }.mapNotNull { runCatching { LocalDate.parse(it.dateIso) }.getOrNull() }.toSet()
    RecapAnalytics.adhOffer(RecapAnalytics.adhRows(weeks, runDates, today, excludedDates(state.mv))) != null
}.getOrDefault(false)

@Composable
internal fun RecapTab(state: UiState, onOpen: (Long) -> Unit) {
    val today = LocalDate.now()
    val runs = remember(state.activities, state.detailsByActivity) {
        state.activities.mapNotNull { a ->
            val d = runCatching { LocalDate.parse(a.dateIso) }.getOrNull() ?: return@mapNotNull null
            RecapRun(a.id, d, a.km, a.durationSec / 60.0, a.avgHr, (a.gain ?: 0).toDouble(),
                state.detailsByActivity[a.id]?.loss?.toDouble(), a.type == "bike", a.name)
        }
    }
    val weeks = remember(state.plan) {
        (state.plan as? PlanOutcome.Ok)?.weeks.orEmpty().map { w ->
            RecapPlanWeek(w.i, w.start, w.km, w.days.map { RecapPlanDay(it.date, it.kind, it.km, it.bench) }, w.cut)
        }
    }
    val runDates = remember(runs) { runs.filter { !it.bike && it.km > 0 }.map { it.date }.toSet() }
    val excluded = remember(state.mv) { excludedDates(state.mv) }
    val loadByDate = remember(state.activities, state.daily, state.plan, state.hrHistByActivity) {
        runCatching {
            TrainingMetrics.calculate(state.settings, state.activities, state.daily, state.plan, hrHistByActivity = state.hrHistByActivity)
                .days.associate { it.date to it.load }
        }.getOrDefault(emptyMap())
    }
    val dm = remember(runs) { RecapAnalytics.dayAggregates(runs) }
    val strengthDates = remember(state.strengthWorkouts) {
        state.strengthWorkouts.filter { !it.deleted }.mapNotNull { runCatching { LocalDate.parse(it.dateIso) }.getOrNull() }.toSet()
    }
    var year by rememberSaveable { mutableIntStateOf(today.year) }
    val years = remember(dm) { RecapAnalytics.years(dm, today) }
    if (year !in years) year = years.last()

    // status buka/tutup di-hoist supaya pasangan setengah lebar tahu kapan harus melebar
    var oAdh by rememberSaveable { mutableStateOf(false) }
    var oProg by rememberSaveable { mutableStateOf(false) }
    var oWeek by rememberSaveable { mutableStateOf(false) }
    var oRev by rememberSaveable { mutableStateOf(false) }
    var oMon by rememberSaveable { mutableStateOf(false) }
    var oCons by rememberSaveable { mutableStateOf(false) }
    var oHeat by rememberSaveable { mutableStateOf(false) }

    RecapAdherence(weeks, runDates, excluded, today, oAdh, { oAdh = !oAdh }, Modifier.fillMaxWidth())
    RcPair(oProg, oRev,
        left = { m -> RecapProgress(state, runs, weeks, today, oProg, { oProg = !oProg }, m) },
        right = { m -> RecapReview(state, runs, weeks, runDates, loadByDate, today, oRev, { oRev = !oRev }, m) })
    RecapWeekly(runs, today, onOpen, oWeek, { oWeek = !oWeek }, Modifier.fillMaxWidth())
    RecapMonthly(runs, weeks, strengthDates, today, onOpen, oMon, { oMon = !oMon }, Modifier.fillMaxWidth())
    RecapConsistency(dm, years, year, today, oCons, { oCons = !oCons }, Modifier.fillMaxWidth())
    RecapHeatYear(dm, loadByDate, years, year, today, oHeat, { oHeat = !oHeat }, Modifier.fillMaxWidth()) { year = it }
}

// ===================== tata letak & komponen kartu =====================

/** Dua kartu setengah lebar berdampingan; bila salah satunya terbuka, keduanya ditumpuk selebar layar. */
@Composable
internal fun RcPair(leftOpen: Boolean, rightOpen: Boolean, left: @Composable (Modifier) -> Unit, right: (@Composable (Modifier) -> Unit)?) {
    if (leftOpen || rightOpen) {
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            left(Modifier.fillMaxWidth())
            if (right != null) right(Modifier.fillMaxWidth())
        }
    } else {
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            left(Modifier.weight(1f).fillMaxHeight())
            if (right != null) right(Modifier.weight(1f).fillMaxHeight()) else Spacer(Modifier.weight(1f))
        }
    }
}

@Composable
internal fun monoStyle(size: Float = 10f, spacing: Float = 0.3f): TextStyle =
    MaterialTheme.typography.labelSmall.copy(fontFamily = MONO, fontSize = size.sp, letterSpacing = spacing.sp)

@Composable
internal fun RcCard(
    icon: ImageVector, label: String, open: Boolean, onToggle: () -> Unit, modifier: Modifier = Modifier,
    warn: Boolean = false, headPill: (@Composable () -> Unit)? = null, headText: String? = null, labelLines: Int = 1,
    summary: @Composable ColumnScope.() -> Unit, body: @Composable ColumnScope.() -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    Card(
        modifier = modifier, shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = cs.surfaceVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        border = BorderStroke(if (warn) 1.6.dp else .8.dp, if (warn) WARN else cs.outlineVariant),
    ) {
        // fillMaxHeight: saat dipasangkan di Row (RcPair) kartu yang lebih pendek ikut meregang, sehingga tint tidak berhenti di tengah dan menyisakan putih.
        Column(Modifier.fillMaxWidth().fillMaxHeight().background(SolidColor(Color.Transparent))) {
            Row(
                Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(horizontal = 10.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(24.dp).clip(CircleShape).background(cs.primary.copy(alpha = .14f)), contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, Modifier.size(14.dp), tint = cs.primary)
                }
                Spacer(Modifier.width(7.dp))
                Text(label, Modifier.weight(1f), style = monoStyle(9f, 0f), color = cs.onSurfaceVariant, maxLines = labelLines, softWrap = labelLines > 1)
                if (open && headText != null) {
                    Text(headText, if (labelLines > 1) Modifier.weight(1f, fill = false) else Modifier, style = monoStyle(10f, 0f), color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.width(6.dp))
                }
                if (headPill != null) { headPill(); Spacer(Modifier.width(4.dp)) }
                Icon(if (open) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore,
                    contentDescription = if (open) "Tutup $label" else "Buka $label", modifier = Modifier.size(20.dp), tint = cs.onSurfaceVariant)
            }
            if (open) HorizontalDivider(color = cs.outlineVariant, thickness = .8.dp)
            Column(Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, top = if (open) 12.dp else 2.dp, bottom = 14.dp)) {
                AnimatedVisibility(visible = !open, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp), content = summary)
                }
                AnimatedVisibility(visible = open, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp), content = body)
                }
            }
        }
    }
}

/** Panel bersarang berbingkai untuk tabel, grafik, dan kalender di dalam kartu terbuka. */
@Composable
internal fun RcInner(modifier: Modifier = Modifier, pad: Int = 10, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .7f),
        border = BorderStroke(.8.dp, MaterialTheme.colorScheme.outlineVariant),
    ) { Column(Modifier.padding(pad.dp), verticalArrangement = Arrangement.spacedBy(4.dp), content = content) }
}

/** Bagian bersarang bertajuk (mis. PREDIKSI LOMBA) di dalam kartu Progres. */
@Composable
private fun RcSection(title: String, info: String? = null, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(.8.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title.uppercase(Locale.ROOT), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            content()
            if (info != null) RcInfo(info)
        }
    }
}

/** Tombol "i" bulat; ketuk untuk menampilkan keterangan cara hitung. */
@Composable
internal fun RcInfo(text: String) {
    var show by rememberSaveable(text) { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(
            Modifier.size(30.dp).clip(CircleShape).border(.8.dp, cs.outlineVariant, CircleShape).clickable { show = !show },
            contentAlignment = Alignment.Center,
        ) { Text("i", style = monoStyle(12f, 0f), color = cs.onSurfaceVariant) }
        if (show) RcMuted(text)
    }
}

@Composable
internal fun RcTag(text: String, tone: Int = 0) {
    val cs = MaterialTheme.colorScheme
    val bg = when (tone) { 1 -> cs.primary.copy(alpha = .15f); 2 -> cs.tertiary.copy(alpha = .18f); else -> WARN.copy(alpha = .20f) }
    val fg = when (tone) { 1 -> cs.primary; 2 -> cs.tertiary; else -> cs.onSurface }
    Surface(shape = RoundedCornerShape(99.dp), color = bg) {
        Text(text, Modifier.padding(horizontal = 8.dp, vertical = 3.dp), style = monoStyle(10f, 0f), color = fg, maxLines = 1)
    }
}

@Composable
internal fun RcBig(value: String, sub: String?, pill: String? = null, neg: Boolean = false) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            if (!pill.isNullOrBlank()) RcTag(pill, if (neg) 1 else 2)
        }
        if (!sub.isNullOrBlank()) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Deretan angka berlabel mono huruf besar (ringkasan kartu). */
@Composable
internal fun RcStats(items: List<Pair<String, String>>) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        items.forEach { (l, v) ->
            Column(Modifier.weight(1f)) {
                Text(l.uppercase(Locale.ROOT), style = monoStyle(9f, .4f), color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                Text(v, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/** Kisi statistik 3 kolom untuk isi ulasan mingguan. */
@Composable
internal fun RcStatGrid(items: List<Pair<String, String>>, cols: Int = 3) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items.chunked(cols).forEach { r ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                r.forEach { (l, v) ->
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(l.uppercase(Locale.ROOT), style = monoStyle(9f, .4f), color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                        Text(v, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    }
                }
                repeat(cols - r.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
internal fun RcRing(pct: Int, diameter: Int = 44) {
    val track = MaterialTheme.colorScheme.outlineVariant
    val col = MaterialTheme.colorScheme.primary
    Canvas(Modifier.size(diameter.dp)) {
        val sw = 5.dp.toPx(); val inset = sw / 2
        val tl = Offset(inset, inset); val sz = Size(size.width - sw, size.height - sw)
        drawArc(track, 0f, 360f, false, tl, sz, style = Stroke(sw))
        drawArc(col, -90f, 360f * pct.coerceIn(0, 100) / 100f, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
    }
}

@Composable
private fun RcBars(values: List<Float>, hi: Int, height: Int = 34) {
    val acc = MaterialTheme.colorScheme.primary
    val dim = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = .35f)
    Canvas(Modifier.fillMaxWidth().height(height.dp)) {
        val mx = values.maxOrNull() ?: 0f
        if (mx <= 0f || values.isEmpty()) return@Canvas
        val gap = 4.dp.toPx(); val bw = (size.width - gap * (values.size - 1)) / values.size
        values.forEachIndexed { i, v ->
            val h = if (v > 0f) max(size.height * .08f, v / mx * size.height) else min(4.dp.toPx(), size.height * .08f)
            drawRoundRect(if (i == hi) acc else dim, Offset(i * (bw + gap), size.height - h), Size(bw, h), CornerRadius(3.dp.toPx()))
        }
    }
}

/** Batang lebar per minggu untuk kepatuhan: tinggi = persen (0..100), minggu terakhir beraksen. */
@Composable
private fun RcPctBars(values: List<Int?>, height: Int = 32) {
    val acc = MaterialTheme.colorScheme.primary
    val dim = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = .35f)
    if (values.isEmpty()) return
    Canvas(Modifier.fillMaxWidth().height(height.dp)) {
        val gap = 8.dp.toPx(); val bw = (size.width - gap * (values.size - 1)) / values.size
        values.forEachIndexed { i, v ->
            val h = max(5.dp.toPx(), size.height * ((v ?: 0).coerceIn(0, 100) / 100f))
            drawRoundRect(if (i == values.lastIndex) acc else dim, Offset(i * (bw + gap), size.height - h), Size(bw, h), CornerRadius(4.dp.toPx()))
        }
    }
}

/** Batang pembanding horizontal (bagian 0..100, warna). */
@Composable
internal fun RcCompare(rows: List<Pair<Float, Color>>, h: Int = 6) {
    val line = MaterialTheme.colorScheme.outlineVariant
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        rows.forEach { (p, c) ->
            Canvas(Modifier.fillMaxWidth().height(h.dp)) {
                val r = CornerRadius(size.height / 2)
                drawRoundRect(line, Offset.Zero, size, r)
                drawRoundRect(c, Offset.Zero, Size(size.width * (p.coerceIn(3f, 100f) / 100f), size.height), r)
            }
        }
    }
}

@Composable
internal fun RcLegend(a: String, b: String? = null) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(a.uppercase(Locale.ROOT), style = monoStyle(9f, .4f), color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (b != null) Text(b.uppercase(Locale.ROOT), style = monoStyle(9f, .4f), color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Heatmap mini: nilai berurutan per kolom (minggu) lalu baris (hari). */
@Composable
private fun RcMiniGrid(vals: List<Double>, fut: List<Boolean>, cols: Int, rows: Int, cellH: Int = 8) {
    val acc = MaterialTheme.colorScheme.primary
    val line = MaterialTheme.colorScheme.outlineVariant
    val cut = remember(vals) { RecapAnalytics.levels(vals) }
    val op = floatArrayOf(0f, .3f, .52f, .76f, 1f)
    Canvas(Modifier.fillMaxWidth().height((rows * cellH + (rows - 1) * 2).dp)) {
        val gap = 2.dp.toPx(); val cw = (size.width - gap * (cols - 1)) / cols; val ch = cellH.dp.toPx()
        vals.forEachIndexed { i, v ->
            val c = i / rows; val r = i % rows
            val lv = RecapAnalytics.levelOf(v, cut)
            val col = if (lv > 0) acc.copy(alpha = op[lv]) else line.copy(alpha = if (fut.getOrNull(i) == true) .35f else .9f)
            drawRoundRect(col, Offset(c * (cw + gap), r * (ch + gap)), Size(cw, ch), CornerRadius(1.5.dp.toPx()))
        }
    }
}

@Composable
internal fun RcMuted(text: String) = Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

@Composable
internal fun RcMono(text: String) = Text(text, style = monoStyle(10.5f, 0f), color = MaterialTheme.colorScheme.onSurfaceVariant)

/** Baris tabel bergaya mono; kolom pertama rata kiri, sisanya rata kanan. Kolom pertama boleh dua baris. */
@Composable
internal fun RcTableRow(cells: List<String>, weights: List<Float>, head: Boolean = false, tint: List<Color?> = emptyList(), line: Boolean = true, leftCols: Int = 1) {
    val cs = MaterialTheme.colorScheme
    Column {
        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
            cells.forEachIndexed { i, t ->
                Text(
                    if (head) t.uppercase(Locale.ROOT) else t, Modifier.weight(weights[i]),
                    style = if (head) monoStyle(8.5f, .3f) else monoStyle(10.5f, 0f),
                    color = tint.getOrNull(i) ?: if (head) cs.onSurfaceVariant else cs.onSurface,
                    textAlign = if (i < leftCols) TextAlign.Start else TextAlign.End, maxLines = if (i < leftCols && !head) 2 else 1,
                )
            }
        }
        if (line) HorizontalDivider(color = cs.outlineVariant.copy(alpha = .6f), thickness = .6.dp)
    }
}

/** Segmen berbentuk pil; segmen terpilih berlatar gradasi oranye. */
@Composable
internal fun RcSeg(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(99.dp)
    Row(Modifier.clip(shape).background(cs.surfaceVariant).border(.8.dp, cs.outlineVariant, shape).padding(3.dp)) {
        options.forEachIndexed { i, o ->
            val on = i == selected
            Box(
                Modifier.clip(shape).then(if (on) Modifier.background(GRAD) else Modifier).clickable { onSelect(i) }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(o, style = MaterialTheme.typography.labelLarge, color = if (on) Color.White else cs.onSurfaceVariant,
                    fontWeight = if (on) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
            }
        }
    }
}

@Composable
private fun RcCircle(icon: ImageVector, desc: String, enabled: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.size(36.dp).clip(CircleShape).border(.8.dp, cs.outlineVariant.copy(alpha = if (enabled) 1f else .5f), CircleShape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, desc, Modifier.size(20.dp), tint = if (enabled) cs.onSurface else cs.onSurface.copy(alpha = .3f)) }
}

@Composable
internal fun RcPill(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(99.dp)
    Box(
        Modifier.height(36.dp).clip(shape).border(.8.dp, cs.outlineVariant.copy(alpha = if (enabled) 1f else .5f), shape)
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) { Text(text, style = MaterialTheme.typography.labelLarge, color = if (enabled) cs.onSurface else cs.onSurface.copy(alpha = .4f), maxLines = 1) }
}

/** ‹ label › dengan tombol bulat; `extra` untuk pil tambahan (Minggu lalu, Bulan ini, Bagikan). */
@Composable
private fun RcNav(
    label: String, canPrev: Boolean, canNext: Boolean, onPrev: () -> Unit, onNext: () -> Unit,
    modifier: Modifier = Modifier.fillMaxWidth(), extra: @Composable () -> Unit = {},
) {
    FlowRow(modifier, horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        RcCircle(Icons.Outlined.ChevronLeft, "Sebelumnya", canPrev, onPrev)
        Box(Modifier.height(36.dp).padding(horizontal = 4.dp), contentAlignment = Alignment.Center) {
            Text(label, style = MaterialTheme.typography.titleSmall, maxLines = 1)
        }
        RcCircle(Icons.Outlined.ChevronRight, "Berikutnya", canNext, onNext)
        extra()
    }
}

@Composable
internal fun tickStyle(): TextStyle = monoStyle(9f, 0f).copy(color = MaterialTheme.colorScheme.onSurfaceVariant)

// ===================== 1. Kepatuhan rencana =====================

@Composable
private fun RecapAdherence(
    weeks: List<RecapPlanWeek>, runDates: Set<LocalDate>, excluded: Set<LocalDate>, today: LocalDate,
    open: Boolean, onToggle: () -> Unit, modifier: Modifier,
) {
    val rows = remember(weeks, runDates, excluded) { RecapAnalytics.adhRows(weeks, runDates, today, excluded) }
    val sc = remember(rows) { RecapAnalytics.adhScan(rows) }
    val offer = remember(rows) { RecapAnalytics.adhOffer(rows) }
    val signal = remember(sc, offer) { RecapAnalytics.adhSignal(sc, offer) }
    val sigText = "Jalur · " + when (signal) { 0 -> "Sesuai"; 1 -> "Pantau"; else -> "Waspada" }
    RcCard(Icons.Outlined.TaskAlt, "KEPATUHAN RENCANA", open, onToggle, modifier, warn = offer != null,
        headPill = if (sc.pct != null) ({ RcTag(sigText, if (signal == 2) 1 else 0) }) else null,
        summary = {
            val cur = sc.cur
            if (sc.pct == null || cur == null) RcStats(listOf("Capaian" to "–", "Tren" to "–"))
            else {
                val pill = if (offer != null) "Saran geser" else when (sc.dir) { "up" -> "▲"; "down" -> "▼"; else -> null }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) { RcBig("${sc.pct}%", "${cur.done} dari ${cur.due} sesi", pill, offer != null || sc.dir == "down") }
                    RcRing(sc.pct)
                }
                RcPctBars(sc.trend.map { it.pct })
                RcLegend("4 minggu terakhir", sc.avg?.let { "rata-rata $it%" })
            }
        },
        body = {
            if (sc.trend.isEmpty()) {
                RcMuted("Belum ada sesi yang jatuh tempo di rencana ini.")
            } else {
                RcInner {
                    val w = listOf(1f, 1f, 1f)
                    RcTableRow(listOf("Minggu", "Sesi", "Capaian"), w, head = true)
                    sc.trend.forEach { x: AdhRow -> RcTableRow(listOf("M${x.i + 1}", "${x.done}/${x.due}", "${x.pct}%"), w) }
                }
                if (sc.dir != null && sc.prevAvg != null) {
                    Text(when (sc.dir) {
                        "up" -> "Minggu ini lebih baik dari rata-rata minggu sebelumnya (${sc.prevAvg}%)."
                        "down" -> "Minggu ini di bawah rata-rata minggu sebelumnya (${sc.prevAvg}%)."
                        else -> "Setara dengan rata-rata minggu sebelumnya (${sc.prevAvg}%)."
                    }, style = MaterialTheme.typography.bodyMedium)
                }
                if (offer != null) {
                    Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.errorContainer) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(if (offer.cur) "Minggu ini baru ${offer.pct}% sesi selesai (${offer.miss} terlewat)."
                                else "Dua minggu berturut-turut di bawah ${RecapAnalytics.ADH_LOW2}% (${offer.miss} sesi terlewat).",
                                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onErrorContainer)
                            Text("Pertimbangkan menurunkan beban beberapa minggu ke depan agar kenaikan paling banyak 10% per minggu dari level yang benar-benar tercapai. Penggeseran otomatis belum tersedia di versi native; pakai Libur dadakan atau tukar hari di Jadwal.",
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
                        }
                    }
                }
                RcInfo("Libur, lomba, acara, dan hari libur dadakan tidak dihitung. Sesi dianggap selesai bila ada lari tercatat di tanggal itu. Sinyal jalur: Sesuai bila rata-rata 4 minggu ≥ 80% tanpa saran geser; Pantau bila di bawah itu atau ada saran geser minggu ini; Waspada bila minggu-minggu sebelumnya di bawah ${RecapAnalytics.ADH_LOW}% atau dua minggu berturut-turut di bawah ${RecapAnalytics.ADH_LOW2}%.")
            }
        })
}

// ===================== 2. Progres =====================

@Composable
private fun RecapProgress(
    state: UiState, runs: List<RecapRun>, weeks: List<RecapPlanWeek>, today: LocalDate,
    open: Boolean, onToggle: () -> Unit, modifier: Modifier,
) {
    val rows = remember(weeks, runs) { RecapAnalytics.progressRows(weeks, runs) }
    val curIdx = weeks.firstOrNull { it.start == RecapAnalytics.monday(today) }?.index ?: -1
    val ability = remember(state.settings, state.activities, state.daily) { runCatching { ProgressAnalytics.runningAbility(state.settings, state.activities, state.daily) }.getOrNull() }
    val prs = remember(state.detailsByActivity) { prsAsOf(state, today) }
    val easy = remember(runs, state.settings) { RecapAnalytics.easyWeeks(runs, runCatching { EasyPace.sessHr(state.settings) }.getOrDefault(0)) }
    val vl = remember(runs, today) { RecapAnalytics.verticalLoad(runs, today) }
    val cyc = remember(weeks, runs, today) { RecapAnalytics.cycleSummary(weeks, runs, today) }
    val acc = MaterialTheme.colorScheme.primary
    RcCard(Icons.Outlined.TrendingUp, "PROGRES", open, onToggle, modifier,
        headText = if (rows.isNotEmpty()) "${rows.size} minggu tercatat" else null,
        summary = {
            if (rows.isEmpty()) RcStats(listOf("Minggu" to "–", "Rata-rata" to "–"))
            else {
                val avg = rows.sumOf { it.st.km } / rows.size
                RcBig("${rows.size} minggu", "rata-rata ${Js.roundI(avg)} km")
                RcCompare(listOf((rows.size * 100f / max(1, weeks.size)) to acc))
                RcLegend("${rows.size} / ${weeks.size} mgg")
            }
        },
        body = {
            if (rows.isEmpty()) {
                RcMuted("Belum ada data lari. Catat atau impor lari untuk mengisi evaluasi dan perbandingan antar minggu.")
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    RecapAnalytics.progressEval(rows, curIdx).forEach { Text(it, style = MaterialTheme.typography.bodyMedium) }
                }
                val deltas = RecapAnalytics.paceDeltas(rows)
                val w = listOf(.7f, 1.1f, 1.1f, 1.1f, .9f, 1f)
                RcInner {
                    RcTableRow(listOf("Mgg", "Rencana km", "Catat km", "Pace easy", "HR easy", "Δ pace"), w, head = true)
                    rows.indices.reversed().forEach { i ->
                        val r = rows[i]; val dl = deltas[i]
                        val col = when { dl == null -> null; dl < 0 -> acc; dl > 0 -> MaterialTheme.colorScheme.error; else -> null }
                        RcTableRow(listOf("M${r.week.index + 1}", fkm(r.week.km), fkm(r.st.km), r.st.pace?.let { Js.paceStr(it) } ?: "–",
                            r.st.hr?.let { Js.roundI(it).toString() } ?: "–",
                            dl?.let { (if (it > 0) "+" else if (it < 0) "−" else "") + abs(it) + " dtk" } ?: "–"), w,
                            tint = listOf(null, null, null, null, null, col), line = i != 0)
                    }
                }
            }
            RcPrediction(state, ability)
            RcPrFromPr(prs)
            RcVertical(vl)
            RcEasyHistory(easy, today)
            if (cyc != null) RcCycle(cyc)
        })
}

@Composable
private fun RcPrediction(state: UiState, ability: com.endurancevault.app.domain.RunningAbility?) {
    RcSection("Prediksi lomba",
        info = if (ability != null) "Perkiraan dari pace dan HR lari tercatat. Lari easy cenderung menghasilkan angka konservatif; lari di tanjakan atau cuaca panas memengaruhi hasil." else null) {
        if (ability == null) {
            RcMuted("Butuh minimal 3 lari tercatat dengan jarak ≥ 3 km, durasi, dan HR rata-rata.")
        } else {
            val v = ability.value
            Text("Indeks kemampuan ${f1(v)} (setara VO2max), dari ${ability.runs} lari terakhir.", style = MaterialTheme.typography.bodyMedium)
            if (ability.weekly.size >= 2) {
                val f = ability.weekly[max(0, ability.weekly.size - 5)]; val l = ability.weekly.last()
                val dv = Math.round((l.second - f.second) * 10) / 10.0
                Text("Tren mingguan: " + (if (abs(dv) < 0.3) "stabil" else if (dv > 0) "naik ${f1(dv)}" else "turun ${f1(abs(dv))}") + " sejak ${dmy(f.first)}.", style = MaterialTheme.typography.bodyMedium)
            }
            val rc = rcOf(state.settings); val goal = parseGoalMin(state.settings.goalT)
            if (goal != null && !rc.trail && rc.km > 0) {
                val tp = RecapAnalytics.raceTimeV(v, rc.km * 1000)
                val df = Js.roundI((tp - goal) * 60)
                Text("Target ${rc.nm} ${Js.durStr(goal)}, prediksi saat ini ${Js.durStr(tp)}: " + (if (df <= 0) "target sudah terjangkau." else "selisih ${Js.durStr(df / 60.0)} lagi."), style = MaterialTheme.typography.bodyMedium)
            }
            val w = listOf(1.6f, 1f, 1f)
            RcInner {
                RcTableRow(listOf("Jarak", "Prediksi", "Pace /km"), w, head = true)
                val items = listOf("5K" to 5000.0, "10K" to 10000.0, "Half marathon" to 21097.5, "Marathon" to 42195.0)
                items.forEachIndexed { i, (n, dm) ->
                    val t = RecapAnalytics.raceTimeV(v, dm)
                    RcTableRow(listOf(n, Js.durStr(t), Js.paceStr(t / (dm / 1000))), w, line = i != items.lastIndex)
                }
            }
        }
    }
}

@Composable
private fun RcPrFromPr(prs: List<RecapPr>) {
    RcSection("Prediksi dari PR") {
        val ref = RecapAnalytics.bestPrRef(prs)
        if (ref == null) {
            RcMuted("Belum ada PR 5K, 10K, atau half marathon dari data per kilometer (impor lari GPX/TCX/FIT).")
        } else {
            Text("Patokan: PR ${ref.label} ${Js.durStr(ref.t)} (VDOT ${f1(ref.vdot)}).", style = MaterialTheme.typography.bodyMedium)
            val w = listOf(1.6f, 1f, 1f, 1f)
            RcInner {
                RcTableRow(listOf("Kategori", "Riegel", "VDOT", "Pace /km"), w, head = true)
                val items = listOf("5K" to 5.0, "10K" to 10.0, "Half marathon" to 21.0975, "Marathon" to 42.195)
                items.forEachIndexed { i, (n, d) ->
                    val rg = RecapAnalytics.riegel(ref.t, ref.d, d); val vt = RecapAnalytics.raceTimeV(ref.vdot, d * 1000)
                    RcTableRow(listOf(n, Js.durStr(rg), Js.durStr(vt), Js.paceStr(vt / d)), w, line = i != items.lastIndex)
                }
            }
        }
    }
}

@Composable
private fun RcVertical(vl: com.endurancevault.app.domain.VertLoad?) {
    RcSection("Beban vertikal",
        info = "Naik/turun dijumlah dari lari 7 hari terakhir (sepeda tidak dihitung; turun hanya dari aktivitas yang detailnya sudah dimuat). Akut = rerata harian berbobot eksponensial 7 hari, kronis = 28 hari, dalam meter per hari. Rasio < 0,8 turun, 0,8–1,3 stabil, 1,3–1,5 naik, > 1,5 melonjak.") {
        if (vl == null) RcMuted("Belum ada lari dengan data tanjakan.")
        else Text(
            "7 hari terakhir: +${Js.idn(Js.roundI(vl.up))} m naik, −${Js.idn(Js.roundI(vl.down))} m turun. Akut ${Js.roundI(vl.acute)} · kronis ${Js.roundI(vl.chronic)} m per hari" +
                (vl.ratio?.let { ", rasio ${f2(it)} ${vl.trend}" } ?: "") + ".",
            style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun RcEasyHistory(easy: List<com.endurancevault.app.domain.RecapAnalytics.EasyWeek>, today: LocalDate) {
    RcSection("Riwayat pace easy") {
        if (easy.isEmpty()) { RcMuted("Belum ada data. Pace easy dihitung dari lari tercatat dengan HR di bawah batas easy."); return@RcSection }
        if (easy.size >= 2) {
            val f = easy.first(); val l = easy.last()
            val dt = Js.roundI((l.pace - f.pace) * 60); val dh = Js.roundI(l.hr - f.hr)
            Text("Dari ${Js.paceStr(f.pace)}/km (${dmy(f.week)}) ke ${Js.paceStr(l.pace)}/km: " +
                (if (dt == 0) "sama" else "${abs(dt)} dtk/km ${if (dt < 0) "lebih cepat" else "lebih lambat"}") + ", HR rata-rata " +
                (if (dh == 0) "sama" else "${abs(dh)} bpm ${if (dh < 0) "lebih rendah" else "lebih tinggi"}") + ".", style = MaterialTheme.typography.bodyMedium)
            val h2 = easy.takeLast(16)
            val tm = rememberTextMeasurer(); val tick = tickStyle()
            val acc = MaterialTheme.colorScheme.primary; val grid = MaterialTheme.colorScheme.outlineVariant
            RcInner(pad = 8) {
                Canvas(Modifier.fillMaxWidth().height(132.dp)) {
                    val L = 36.dp.toPx(); val R = 8.dp.toPx(); val T = 8.dp.toPx(); val B = 20.dp.toPx()
                    var pmin = h2.minOf { it.pace * 60 }; var pmax = h2.maxOf { it.pace * 60 }
                    pmin = floor((pmin - 5) / 15) * 15; pmax = kotlin.math.ceil((pmax + 5) / 15) * 15; if (pmax - pmin < 30) pmax = pmin + 30
                    fun xs(i: Int) = L + i * (size.width - L - R) / (h2.size - 1)
                    fun ys(s: Double) = (T + (s - pmin) / (pmax - pmin) * (size.height - T - B)).toFloat()
                    listOf(pmin, (pmin + pmax) / 2, pmax).forEach { s ->
                        drawLine(grid.copy(alpha = .6f), Offset(L, ys(s)), Offset(size.width - R, ys(s)), 1.dp.toPx())
                        val lay = tm.measure(Js.paceStr(s / 60), tick)
                        drawText(lay, topLeft = Offset(L - 4.dp.toPx() - lay.size.width, ys(s) - lay.size.height / 2f))
                    }
                    val p = Path(); h2.forEachIndexed { i, w -> val o = Offset(xs(i), ys(w.pace * 60)); if (i == 0) p.moveTo(o.x, o.y) else p.lineTo(o.x, o.y) }
                    drawPath(p, acc, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
                    h2.forEachIndexed { i, w -> drawCircle(acc, if (i == h2.lastIndex) 4.dp.toPx() else 2.5f.dp.toPx(), Offset(xs(i), ys(w.pace * 60))) }
                    val l0 = tm.measure(dmy(h2.first().week), tick); val l1 = tm.measure(dmy(h2.last().week), tick)
                    drawText(l0, topLeft = Offset(L, size.height - l0.size.height))
                    drawText(l1, topLeft = Offset(size.width - R - l1.size.width, size.height - l1.size.height))
                }
            }
            RcMono("Lebih tinggi berarti lebih cepat.")
        }
        val w = listOf(1.7f, .9f, .6f, .6f, .9f)
        RcInner {
            RcTableRow(listOf("Minggu", "Pace easy", "HR", "Sesi", "Δ pace"), w, head = true)
            var prev: Double? = null
            val rowsOut = easy.map { e ->
                val d = prev?.let { Js.roundI((e.pace - it) * 60) }; prev = e.pace; e to d
            }
            val shown = rowsOut.takeLast(12).reversed()
            val curMon = RecapAnalytics.monday(today)
            shown.forEachIndexed { i, (e, d) ->
                RcTableRow(listOf("${dmy(e.week)} – ${dmy(e.week.plusDays(6))}" + if (e.week == curMon) " (minggu ini)" else "",
                    Js.paceStr(e.pace), Js.roundI(e.hr).toString(), e.n.toString(),
                    d?.let { (if (it > 0) "+" else if (it < 0) "−" else "") + abs(it) + " dtk" } ?: "–"), w, line = i != shown.lastIndex)
            }
        }
    }
}

@Composable
private fun RcCycle(c: com.endurancevault.app.domain.CycleSummary) {
    RcSection("Ringkasan akhir siklus · loop 6,3 km",
        info = "Siklus berakhir di minggu pemulihan. Tes loop dijalankan tanpa pemanasan dari titik awal loop; pace dan HR-nya dibandingkan dengan tes siklus sebelumnya.") {
        Text("Siklus ${c.cycle} · M${c.fromWeek}–M${c.toWeek}" + if (c.recovery) " (pemulihan)" else "", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
        val pct = if (c.planKm > 0) Js.roundI(c.loggedKm / c.planKm * 100) else 0
        RcMono("Jarak siklus: ${f1(c.loggedKm)} dari ${f1(c.planKm)} km ($pct%)")
        var prev: com.endurancevault.app.domain.CycleTest? = null
        c.tests.forEach { t ->
            val dp = if (prev?.pace != null && t.pace != null) Js.roundI((t.pace - prev!!.pace!!) * 60) else null
            val dh = if (prev?.hr != null && t.hr != null) t.hr - prev!!.hr!! else null
            Text("Tes siklus ${t.cycle} (${dmy(t.date)}): ${t.pace?.let { Js.paceStr(it) } ?: "–"}/km" + (t.hr?.let { " · HR $it" } ?: "") +
                (if (dp != null) " · ${if (dp == 0) "pace sama" else "${abs(dp)} dtk/km ${if (dp < 0) "lebih cepat" else "lebih lambat"}"}" else "") +
                (if (dh != null && dh != 0) ", HR ${abs(dh)} bpm ${if (dh < 0) "lebih rendah" else "lebih tinggi"}" else ""),
                style = MaterialTheme.typography.bodyMedium)
            prev = t
        }
        if (c.nextTest != null) RcMono("Tes berikutnya: ${dmy(c.nextTest)}. Mulai langsung dari titik awal loop, tanpa pemanasan.")
    }
}

// ===================== 3. Grafik mingguan =====================

@Composable
private fun RecapWeekly(runs: List<RecapRun>, today: LocalDate, onOpen: (Long) -> Unit, open: Boolean, onToggle: () -> Unit, modifier: Modifier) {
    val b = remember(runs) { RecapAnalytics.weeklyBuckets(runs, today, 16) }
    var metric by rememberSaveable { mutableStateOf(WeeklyMetric.KM) }
    var line by rememberSaveable { mutableStateOf(false) }
    var sel by rememberSaveable { mutableIntStateOf(15) }
    val avg4 = (b[11].km + b[12].km + b[13].km + b[14].km) / 4
    val cur = b[15].km
    val dl = if (avg4 > 0) Js.roundI((cur - avg4) / avg4 * 100) else null
    val sub = when (metric) {
        WeeklyMetric.KM -> "km per minggu"; WeeklyMetric.MIN -> "jam per minggu"; WeeklyMetric.GAIN -> "m Elev. Gain per minggu"
        WeeklyMetric.LOSS -> "m Elev. Loss per minggu"; WeeklyMetric.VAM -> "VAM (m/jam) per minggu"
    }
    val metrics = listOf(WeeklyMetric.KM to "Jarak", WeeklyMetric.MIN to "Waktu", WeeklyMetric.GAIN to "Elev. gain", WeeklyMetric.LOSS to "Elev. loss", WeeklyMetric.VAM to "VAM")
    RcCard(Icons.Outlined.BarChart, "GRAFIK MINGGUAN", open, onToggle, modifier, headText = sub,
        summary = {
            if (b.sumOf { it.km } <= 0) RcStats(listOf("Minggu ini" to "–", "Rata-rata" to "–"))
            else {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Column(Modifier.weight(.45f)) {
                        RcBig("${fkm(cur)} km", "rata-rata ${fkm(avg4)} km", if (dl != null && dl != 0) (if (dl > 0) "▲ " else "▼ ") + abs(dl) + "%" else null, dl != null && dl < 0)
                    }
                    Box(Modifier.weight(.55f)) { RcBars(b.takeLast(8).map { it.km.toFloat() }, 7, 48) }
                }
            }
        },
        body = {
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                RcSeg(metrics.map { it.second }, metrics.indexOfFirst { it.first == metric }) { metric = metrics[it].first }
            }
            RcSeg(listOf("Bar", "Line"), if (line) 1 else 0) { line = it == 1 }
            RcInner(pad = 8) { RcWeeklyChart(b, metric, line, sel) { sel = it } }
            val w = b[sel.coerceIn(0, 15)]
            val vam = w.vam
            RcMono("${dmy(w.start)} – ${dmy(w.end)} · ${fkm(w.km)} km · ${durHm(w.min)} · ${Js.idn(Js.roundI(w.gain))} m" +
                (if (metric == WeeklyMetric.LOSS) " · Elevation Loss ${Js.idn(Js.roundI(w.loss))} m" else "") +
                (if (vam > 0) " · VAM ${Js.idn(vam)} m/j" else "") + " · ${w.n} sesi")
            val sessions = runs.filter { !it.bike && w.ids.contains(it.id) }.sortedBy { it.date }
            sessions.forEach { r ->
                Row(Modifier.fillMaxWidth().clickable { onOpen(r.id) }.padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${dmy(r.date)} · ${r.name.ifBlank { "Lari" }}", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f), maxLines = 1)
                    Text("${fkm(r.km)} km" + if (r.km > 0 && r.min > 0) " · ${Js.paceStr(r.min / r.km)}/km" else "", style = MaterialTheme.typography.bodySmall)
                }
            }
            if (sessions.isNotEmpty()) RcInfo("Ketuk sesi untuk membuka detailnya. Ketuk batang atau titik pada grafik untuk memilih minggu.")
        })
}

@Composable
private fun RcWeeklyChart(b: List<WeekBucket>, metric: WeeklyMetric, line: Boolean, sel: Int, onSel: (Int) -> Unit) {
    val vals = with(RecapAnalytics) { b.map { it.value(metric) } }
    val top = RecapAnalytics.niceMax(vals.maxOrNull() ?: 0.0)
    val spikes = remember(vals, metric) {
        if (metric == WeeklyMetric.LOSS) RecapAnalytics.spikeScan(vals, vals.map { false }, 150.0).associateBy { it.i } else emptyMap()
    }
    val tm = rememberTextMeasurer(); val tick = tickStyle()
    val acc = MaterialTheme.colorScheme.primary; val grid = MaterialTheme.colorScheme.outlineVariant
    val surf = MaterialTheme.colorScheme.surface
    Canvas(Modifier.fillMaxWidth().height(190.dp).pointerInput(Unit) {
        detectTapGestures(onTap = { o ->
            val pl = 32.dp.toPx(); val slot = (size.width - pl - 8.dp.toPx()) / 16f
            onSel(((o.x - pl) / slot).toInt().coerceIn(0, 15))
        })
    }) {
        val PL = 32.dp.toPx(); val R = 8.dp.toPx(); val T = 14.dp.toPx(); val B = 24.dp.toPx()
        val iw = size.width - PL - R; val ih = size.height - T - B; val slot = iw / 16f; val bw = slot * .62f
        fun X(j: Int) = PL + slot * (j + .5f)
        fun Y(v: Double) = (T + ih * (1 - v / top)).toFloat()
        fun tk(v: Double) = if (abs(v - Math.round(v)) < 1e-9) Math.round(v).toString() else f1(v)
        listOf(0.0, .5, 1.0).forEach { f ->
            val y = Y(top * f)
            drawLine(grid.copy(alpha = .6f), Offset(PL, y), Offset(size.width - R, y), 1.dp.toPx())
            val lay = tm.measure(tk(top * f), tick)
            drawText(lay, topLeft = Offset(PL - 4.dp.toPx() - lay.size.width, y - lay.size.height / 2f))
        }
        if (line) {
            val sx = X(sel)
            drawLine(grid, Offset(sx, T), Offset(sx, Y(0.0)), 1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(6.dp.toPx(), 5.dp.toPx())))
            val p = Path(); val area = Path()
            area.moveTo(X(0), Y(0.0))
            vals.forEachIndexed { j, v -> val o = Offset(X(j), Y(v)); if (j == 0) p.moveTo(o.x, o.y) else p.lineTo(o.x, o.y); area.lineTo(o.x, o.y) }
            area.lineTo(X(15), Y(0.0)); area.close()
            drawPath(area, acc.copy(alpha = .16f))
            drawPath(p, acc, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
            vals.forEachIndexed { j, v ->
                if (j == sel) { drawCircle(surf, 6.5f.dp.toPx(), Offset(X(j), Y(v))); drawCircle(acc, 4.5f.dp.toPx(), Offset(X(j), Y(v))) }
                else drawCircle(acc, 2.4f.dp.toPx(), Offset(X(j), Y(v)))
            }
        } else {
            vals.forEachIndexed { j, v ->
                val hh = if (v > 0) max(2.dp.toPx(), Y(0.0) - Y(v)) else 1.5f.dp.toPx()
                drawRoundRect(acc.copy(alpha = if (j == sel) 1f else .5f), Offset(X(j) - bw / 2, Y(0.0) - hh), Size(bw, hh), CornerRadius(3.dp.toPx()))
            }
        }
        b.forEachIndexed { j, w ->
            spikes[j]?.let { s ->
                val lay = tm.measure(if (s.high) "▲▲" else "▲", tick.copy(fontWeight = FontWeight.Bold))
                drawText(lay, topLeft = Offset(X(j) - lay.size.width / 2f, Y(vals[j]) - 5.dp.toPx() - lay.size.height))
            }
            if ((15 - j) % 3 == 0) {
                val lay = tm.measure(dmy(w.start), tick)
                drawText(lay, topLeft = Offset(X(j) - lay.size.width / 2f, size.height - 6.dp.toPx() - lay.size.height))
            }
        }
    }
    if (spikes.isNotEmpty()) RcMuted("▲ = Elev. Loss naik lebih dari 10% dari minggu pembanding (▲▲ ≥ 20%).")
}

// ===================== 4. Ulasan mingguan =====================

@Composable
private fun RecapReview(
    state: UiState, runs: List<RecapRun>, weeks: List<RecapPlanWeek>, runDates: Set<LocalDate>,
    loadByDate: Map<LocalDate, Double>, today: LocalDate, open: Boolean, onToggle: () -> Unit, modifier: Modifier,
) {
    var back by rememberSaveable { mutableIntStateOf(0) }
    val curMon = RecapAnalytics.monday(today)
    val logged = runs.filter { !it.bike && it.km > 0 }
    val first = logged.minOfOrNull { it.date }
    val wks = if (first == null) 0 else java.time.temporal.ChronoUnit.WEEKS.between(RecapAnalytics.monday(first), curMon).toInt()
    val maxBack = max(-1, wks - 1)
    if (back > maxBack) back = maxBack
    if (back < -1) back = -1
    val mon = curMon.minusWeeks((1 + back).toLong())
    val isCur = mon == curMon
    val rv = remember(mon, runs, weeks, loadByDate, state.detailsByActivity) {
        val prs = RecapAnalytics.newPrsIn(mon, prsAsOf(state, mon.plusDays(6)), prsAsOf(state, mon.minusDays(1)))
        RecapAnalytics.weekReview(mon, runs, weeks, runDates, loadByDate, prs)
    }
    val rows = remember(weeks, runs) { RecapAnalytics.progressRows(weeks, runs) }
    val ds = remember(runs, weeks) { RecapAnalytics.dayStreak(runs, weeks.flatMap { it.days }.filter { it.kind == "rest" }.map { it.date }.toSet(), today) }
    val ws = remember(runs, weeks) { RecapAnalytics.weekStreak(runs, weeks, runDates, today) }
    val prs = remember(state.detailsByActivity) { prsAsOf(state, today) }
    val ach = remember(runs, prs, ws) { RecapAnalytics.achievements(runs, prs.size, 4, ws) }
    val pct = rv.planKm?.takeIf { it > 0 }?.let { Js.roundI(rv.km / it * 100) }
    val cs = MaterialTheme.colorScheme
    RcCard(Icons.Outlined.Flag, "ULASAN MINGGUAN", open, onToggle, modifier,
        summary = {
            val l = rows.lastOrNull()
            if (l == null) RcStats(listOf("Capaian" to "–", "Minggu" to "–"))
            else {
                val p = if (l.week.km > 0) Js.roundI(l.st.km / l.week.km * 100) else 0
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) { RcBig("$p%", "M${l.week.index + 1} · ${Js.roundI(l.st.km)} dari ${Js.roundI(l.week.km)} km") }
                    RcRing(p)
                }
            }
        },
        body = {
            if (first == null) {
                RcMuted("Belum ada lari tercatat. Ulasan mingguan muncul setelah ada sesi.")
            } else {
                RcNav(
                    label = "${dmy(mon)} – ${dmy(mon.plusDays(6))}",
                    canPrev = (back < maxBack), canNext = (back > -1),
                    onPrev = { back += 1 }, onNext = { back -= 1 },
                ) { RcPill("Minggu lalu", enabled = back != 0) { back = 0 } }
                if (isCur) RcMono("Minggu berjalan, sejauh ini.")
                if (rv.n == 0) {
                    Text("Tidak ada lari tercatat di minggu ini.", style = MaterialTheme.typography.bodyMedium)
                } else {
                    RcStatGrid(buildList {
                        add("Jarak" to fkm(rv.km) + (rv.planKm?.takeIf { it > 0 }?.let { " / ${fkm(it)}" } ?: "") + " km")
                        add("Sesi lari" to rv.n.toString() + (rv.planN?.let { " / $it" } ?: ""))
                        add("Waktu" to durHm(rv.min))
                        add("Elev. Gain" to "${Js.idn(Js.roundI(rv.gain))} m")
                        if (rv.load > 0) add("Training load" to Js.roundI(rv.load).toString())
                        rv.hr?.let { add("HR rata-rata" to Js.roundI(it).toString()) }
                        rv.cons?.let { add("Konsistensi" to "$it%") }
                    })
                    if (pct != null) RcCompare(listOf(min(100, pct).toFloat() to cs.primary), h = 9)
                    val verdict = when {
                        pct == null -> "Tidak ada rencana km untuk minggu ini, jadi tidak ada perbandingan target."
                        isCur -> "$pct% dari target minggu ini sejauh ini."
                        pct > 115 -> "Di atas target ($pct%). Jaga pemulihan minggu depan."
                        pct >= 90 -> "Sesuai target ($pct%)."
                        pct >= 60 -> "Sedikit di bawah target ($pct%)."
                        else -> "Jauh di bawah target ($pct%)."
                    }
                    Text(verdict, style = MaterialTheme.typography.bodyMedium, color = if (pct != null && !isCur && pct in 90..115) cs.primary else cs.onSurface)
                    if (rv.prevKm > 0 && !isCur) { val dk = rv.km - rv.prevKm; Text("Dibanding minggu sebelumnya: ${if (dk >= 0) "+" else "−"}${fkm(abs(dk))} km", style = MaterialTheme.typography.bodyMedium) }
                    rv.prs.forEach { Text("★ PR baru ${it.first}: ${Js.durStr(it.second)}", style = MaterialTheme.typography.bodyMedium, color = cs.primary) }
                    if (rv.recLong) Text("★ Lari terpanjang sejauh ini: ${fkm(rv.longKm)} km", style = MaterialTheme.typography.bodyMedium, color = cs.primary)
                    if (rv.recWeek) Text("★ Jarak mingguan tertinggi sejauh ini: ${fkm(rv.km)} km", style = MaterialTheme.typography.bodyMedium, color = cs.primary)
                }
                Text("🔥 Streak · $ds hari berturut-turut · $ws minggu beruntun", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    ach.forEach { a ->
                        Surface(shape = RoundedCornerShape(99.dp), color = if (a.on) cs.primary else cs.surfaceVariant,
                            border = if (a.on) null else BorderStroke(.8.dp, cs.outlineVariant)) {
                            Text((if (a.on) "✓ " else "") + a.text, Modifier.padding(horizontal = 11.dp, vertical = 5.dp), style = MaterialTheme.typography.labelMedium,
                                color = if (a.on) cs.onPrimary else cs.onSurfaceVariant)
                        }
                    }
                }
                RcInfo("Streak hari menghitung hari berturut-turut dengan lari tercatat; hari libur dalam rencana tidak memutusnya. Minggu beruntun menghitung minggu dengan jarak minimal 80% rencana (tanpa rencana: minimal satu lari). Setiap Senin, tombol \"Minggu lalu\" menampilkan ringkasan minggu yang baru selesai.")
            }
        })
}

// ===================== 5. Log bulanan =====================

@Composable
private fun RecapMonthly(
    runs: List<RecapRun>, weeks: List<RecapPlanWeek>, strengthDates: Set<LocalDate>, today: LocalDate, onOpen: (Long) -> Unit,
    open: Boolean, onToggle: () -> Unit, modifier: Modifier,
) {
    val ctx = LocalContext.current
    val byDate = remember(runs) { runs.groupBy { it.date } }
    val runKm = remember(runs) { runs.filter { !it.bike }.groupBy { it.date }.mapValues { (_, v) -> v.sumOf { it.km } } }
    val bikeKm = remember(runs) { runs.filter { it.bike }.groupBy { it.date }.mapValues { (_, v) -> v.sumOf { it.km } } }
    val runDay = remember(runs) { runs.filter { !it.bike && (it.km > 0 || it.min > 0) }.map { it.date }.toSet() }
    val months = remember(runs, strengthDates, weeks) {
        RecapAnalytics.monthRange(byDate.keys + strengthDates, weeks.firstOrNull()?.start, today)
    }
    val pager = rememberPagerState(initialPage = months.lastIndex.coerceAtLeast(0)) { months.size }
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var pick by remember { mutableStateOf<LocalDate?>(null) }
    val ym = months.getOrNull(pager.currentPage) ?: YearMonth.from(today)
    fun monthStats(m: YearMonth): Triple<Int, Double, Int> {
        val days = (1..m.lengthOfMonth()).map { m.atDay(it) }
        return Triple(days.count { it in runDay }, days.sumOf { runKm[it] ?: 0.0 }, days.count { it in strengthDates })
    }
    val cs = MaterialTheme.colorScheme
    val line = cs.outlineVariant
    RcCard(Icons.Outlined.CalendarMonth, "LOG BULANAN", open, onToggle, modifier, headText = "geser atau pakai tombol",
        summary = {
            val m = YearMonth.from(today)
            val sess = (1..m.lengthOfMonth()).sumOf { d -> if (m.atDay(d) in runDay) (byDate[m.atDay(d)]?.count { !it.bike } ?: 0) else 0 }
            if (sess == 0) RcStats(listOf("Sesi" to "–", "Jarak" to "–"))
            else {
                RcStats(listOf("Sesi" to sess.toString(), "Jarak" to "${fkm(monthStats(m).second)} km"))
                RcMiniGrid((1..m.lengthOfMonth()).map { runKm[m.atDay(it)] ?: 0.0 }, (1..m.lengthOfMonth()).map { m.atDay(it).isAfter(today) }, m.lengthOfMonth(), 1, 10)
            }
        },
        body = {
            RcNav("${monShort(ym.monthValue)} ${ym.year}", pager.currentPage > 0, pager.currentPage < months.lastIndex,
                { scope.launch { pager.animateScrollToPage(pager.currentPage - 1) } }, { scope.launch { pager.animateScrollToPage(pager.currentPage + 1) } }) {
                RcPill("Bulan ini", enabled = pager.currentPage != months.lastIndex) { scope.launch { pager.animateScrollToPage(months.lastIndex) } }
                RcPill("Bagikan") {
                    val (n2, k2, s2) = monthStats(ym)
                    val msg = "Rekap ${monShort(ym.monthValue)} ${ym.year}: $n2 hari lari · ${fkm(k2)} km" + if (s2 > 0) " · $s2 strength" else ""
                    ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, com.endurancevault.app.ui.i18n.Lang.tr(msg)) }, com.endurancevault.app.ui.i18n.Lang.tr("Bagikan rekap bulan")))
                }
            }
            RcInner(pad = 12) {
                HorizontalPager(state = pager, modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) { page ->
                    val m = months[page]
                    val (nr, km, ns) = monthStats(m)
                    val days = (1..m.lengthOfMonth()).map { m.atDay(it) }
                    val nb = days.count { it in bikeKm }; val kb = days.sumOf { bikeKm[it] ?: 0.0 }
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                            Text("${monShort(m.monthValue)} ${m.year}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Column(horizontalAlignment = Alignment.End) {
                                RcMono("$nr hari lari · ${fkm(km)} km" + if (ns > 0) " · $ns strength" else "")
                                if (nb > 0) RcMono("$nb sepeda · ${fkm(kb)} km")
                            }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                            DOW_ID.forEach { Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant) }
                        }
                        val off = m.atDay(1).dayOfWeek.value - 1
                        val total = off + m.lengthOfMonth()
                        val rowsN = (total + 6) / 7
                        repeat(rowsN) { r ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                repeat(7) { c ->
                                    val idx = r * 7 + c; val dn = idx - off + 1
                                    if (dn < 1 || dn > m.lengthOfMonth()) Box(Modifier.weight(1f).aspectRatio(1f))
                                    else {
                                        val d = m.atDay(dn); val kd = runKm[d] ?: 0.0; val run = d in runDay
                                        val lv = RecapAnalytics.monthDayLevel(kd, run)
                                        val bg = if (run) cs.tertiary.copy(alpha = if (lv == 1) .72f else 1f) else cs.surface
                                        val has = byDate.containsKey(d)
                                        val fg = if (run) cs.onTertiary else cs.onSurfaceVariant
                                        Box(Modifier.weight(1f).aspectRatio(1f).clip(RoundedCornerShape(10.dp)).background(bg)
                                            .border(if (d == today) BorderStroke(2.dp, cs.onSurface) else BorderStroke(.6.dp, line), RoundedCornerShape(10.dp))
                                            .clickable(enabled = has) {
                                                // satu aktivitas: langsung buka detail; lebih dari satu: tampilkan daftar sesi di bawah
                                                val list = byDate[d].orEmpty()
                                                if (list.size == 1) onOpen(list[0].id) else pick = d
                                            }.padding(3.dp)) {
                                            Text(dn.toString(), Modifier.align(Alignment.TopStart), style = monoStyle(9f, 0f), color = fg)
                                            if (kd > 0) Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                                                Text(fkm(kd), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = fg, maxLines = 1)
                                                Text("km", style = monoStyle(8f, 0f), color = fg)
                                            }
                                            if (d in bikeKm) Box(Modifier.align(Alignment.TopEnd).padding(1.dp).size(7.dp).clip(CircleShape).background(BIKE_BLUE))
                                            if (d in strengthDates) Box(Modifier.align(Alignment.BottomCenter).width(12.dp).height(3.dp).clip(RoundedCornerShape(2.dp)).background(STRENGTH_RED))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Box(Modifier.size(10.dp).clip(RoundedCornerShape(3.dp)).background(cs.tertiary)); Text("Lari (km)", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Box(Modifier.size(9.dp).clip(CircleShape).background(BIKE_BLUE)); Text("Sepeda", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Box(Modifier.width(12.dp).height(3.dp).clip(RoundedCornerShape(2.dp)).background(STRENGTH_RED)); Text("Strength", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                }
            }
            val dsel = pick
            if (dsel != null && dsel.year == ym.year && dsel.monthValue == ym.monthValue) {
                Text("${dsel.dayOfMonth} ${monShort(dsel.monthValue)} ${dsel.year}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    byDate[dsel].orEmpty().forEach { r ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(cs.surfaceVariant)
                                .clickable { onOpen(r.id) }.padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text((if (r.bike) "Sepeda · " else "") + r.name.ifBlank { "Lari" }, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, maxLines = 1)
                            Text("${fkm(r.km)} km" + if (r.km > 0 && r.min > 0 && !r.bike) " · ${Js.paceStr(r.min / r.km)}/km" else "", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            RcInfo("Ketuk hari untuk membuka sesinya. \"Bagikan\" mengirim ringkasan bulan sebagai teks; kartu gambar belum tersedia di versi native.")
        })
}

// ===================== 6. Kalender konsistensi =====================

@Composable
private fun RecapConsistency(
    dm: Map<LocalDate, com.endurancevault.app.domain.DayAgg>, years: List<Int>, year: Int, today: LocalDate,
    open: Boolean, onToggle: () -> Unit, modifier: Modifier,
) {
    val a = remember(dm, year) { RecapAnalytics.monthAgg(dm, year) }
    val b = remember(dm, year) { RecapAnalytics.monthAgg(dm, year - 1) }
    val has = a.any { it.days > 0 }
    val cs = MaterialTheme.colorScheme
    val acc = cs.primary
    val up = cs.primary; val dn = cs.error
    RcCard(Icons.Outlined.EventAvailable, "KALENDER KONSISTENSI", open, onToggle, modifier, headText = "$year vs ${year - 1}",
        summary = {
            val ya = RecapAnalytics.ytd(dm, today.year, today).second; val yb = RecapAnalytics.ytd(dm, today.year - 1, today).second
            if (ya == 0 && yb == 0) RcStats(listOf("Tahun ini" to "–", "Tahun lalu" to "–"))
            else {
                val mx = max(1, max(ya, yb)).toFloat()
                RcStats(listOf("${today.year}" to "$ya hari", "${today.year - 1}" to "$yb hari"))
                RcCompare(listOf(ya / mx * 100 to acc, yb / mx * 100 to cs.onSurfaceVariant.copy(alpha = .4f)), h = 7)
            }
        },
        body = {
            if (!has) RcMuted("Belum ada lari di tahun ini.")
            else {
                val w = listOf(.6f, 1f, .8f, 1.1f, .8f)
                var tA = DoubleArray(4); var tB = DoubleArray(4)
                fun vals(m: com.endurancevault.app.domain.MonthAgg) = doubleArrayOf(m.km, m.min, m.gain, m.days.toDouble())
                fun fv(k: Int, v: Double): String = if (v <= 0) "–" else when (k) { 0 -> fkm(Math.round(v * 10) / 10.0); 1 -> f1(Math.round(v / 6.0) / 10.0); else -> Js.idn(Js.roundI(v)) }
                @Composable
                fun ConsRow(label: String, c: DoubleArray, p: DoubleArray, now: Boolean, bold: Boolean) {
                    Column {
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(if (now) cs.primary.copy(alpha = .12f) else Color.Transparent).padding(vertical = 6.dp),
                            verticalAlignment = Alignment.Top,
                        ) {
                            Text(label.uppercase(Locale.ROOT), Modifier.weight(w[0]).padding(start = 4.dp), style = monoStyle(10f, .3f), color = cs.onSurfaceVariant)
                            for (k in 0 until 4) {
                                val d = RecapAnalytics.deltaText(c[k], p[k])
                                Column(Modifier.weight(w[k + 1]), horizontalAlignment = Alignment.End) {
                                    Text(fv(k, c[k]), style = MaterialTheme.typography.bodyMedium, fontWeight = if (bold) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
                                    if (d.isNotEmpty()) Text(d, style = monoStyle(9f, 0f), color = if (d.startsWith("▲")) up else if (d.startsWith("▼")) dn else cs.onSurfaceVariant, maxLines = 1)
                                }
                            }
                        }
                        HorizontalDivider(color = cs.outlineVariant.copy(alpha = .6f), thickness = .6.dp)
                    }
                }
                RcInner(pad = 8) {
                    RcTableRow(listOf("", "Jarak", "Jam", "Elev. gain", "Hari"), w, head = true)
                    a.forEachIndexed { i, m ->
                        val c = vals(m); val p = vals(b[i])
                        for (k in 0 until 4) { tA[k] += c[k]; tB[k] += p[k] }
                        ConsRow(monShort(i + 1), c, p, year == today.year && i == today.monthValue - 1, false)
                    }
                    ConsRow("Total", tA, tB, false, true)
                }
                RcInfo("Jam = waktu lari. Persen di bawah angka membandingkan dengan bulan yang sama tahun lalu. Sesi sepeda tidak dihitung. Tahun diganti dari kartu Heatmap tahunan.")
            }
        })
}

// ===================== 7. Heatmap tahunan =====================

@Composable
private fun RecapHeatYear(
    dm: Map<LocalDate, com.endurancevault.app.domain.DayAgg>, loadByDate: Map<LocalDate, Double>, years: List<Int>, year: Int, today: LocalDate,
    open: Boolean, onToggle: () -> Unit, modifier: Modifier, onYear: (Int) -> Unit,
) {
    var useLoad by rememberSaveable { mutableStateOf(false) }
    var pickDate by remember { mutableStateOf<LocalDate?>(null) }
    val (cells, weeksN) = remember(year) { RecapAnalytics.yearGrid(year) }
    val vals = remember(dm, loadByDate, year, useLoad) {
        cells.filter { it.inYear }.associate { it.date to (if (useLoad) (loadByDate[it.date] ?: 0.0) else (dm[it.date]?.km ?: 0.0)) }
    }
    val cut = remember(vals) { RecapAnalytics.levels(vals.values) }
    val tot = vals.values.sum(); val act = vals.values.count { it > 0 }
    val best = vals.maxByOrNull { it.value }?.takeIf { it.value > 0 }
    val cs = MaterialTheme.colorScheme
    val acc = cs.primary; val line = cs.outlineVariant
    val tm = rememberTextMeasurer(); val tick = tickStyle()
    val op = floatArrayOf(0f, .3f, .52f, .76f, 1f)
    val density = LocalDensity.current
    val CS = 12f; val GP = 3f; val LX = 2f; val TY = 16f
    val wDp = LX + weeksN * (CS + GP); val hDp = TY + 7 * (CS + GP)
    val scroll = rememberScrollState()
    LaunchedEffect(year, scroll.maxValue, open) {
        if (year == today.year) {
            val tw = cells.firstOrNull { it.date == today }?.week ?: weeksN
            val contentPx = with(density) { wDp.dp.toPx() }
            val viewport = contentPx - scroll.maxValue
            val target = with(density) { (LX + (tw + 1) * (CS + GP)).dp.toPx() } - viewport + 8f
            scroll.scrollTo(max(0f, target).toInt())
        } else scroll.scrollTo(0)
    }
    // ringkasan: tahun berjalan, YTD vs tahun lalu
    val ya = RecapAnalytics.ytd(dm, today.year, today); val yb = RecapAnalytics.ytd(dm, today.year - 1, today)
    RcCard(Icons.Outlined.GridView, "HEATMAP TAHUNAN", open, onToggle, modifier,
        headText = "${if (useLoad) Js.idn(Js.roundI(tot)) else fkm(Math.round(tot * 10) / 10.0)} ${if (useLoad) "load" else "km"} · $act hari",
        summary = {
            if (!(ya.first > 0)) RcStats(listOf("Jarak" to "–", "Hari aktif" to "–"))
            else {
                val dl = if (yb.first > 0) Js.roundI((ya.first - yb.first) / yb.first * 100) else null
                RcBig("${fkm(Math.round(ya.first * 10) / 10.0)} km", "${ya.second} hari aktif", if (dl != null && dl != 0) (if (dl > 0) "▲ " else "▼ ") + abs(dl) + "%" else null, dl != null && dl < 0)
                val start = RecapAnalytics.monday(today).minusWeeks(19)
                val days = (0 until 140).map { start.plusDays(it.toLong()) }
                RcMiniGrid(days.map { dm[it]?.km ?: 0.0 }, days.map { it.isAfter(today) }, 20, 7, 7)
            }
        },
        body = {
            FlowRow(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                RcSeg(listOf("Jarak", "Load"), if (useLoad) 1 else 0) { useLoad = it == 1 }
                RcNav("$year", year > years.first(), year < years.last(), { onYear(year - 1) }, { onYear(year + 1) }, modifier = Modifier)
            }
            RcInner(pad = 8) {
                Box(Modifier.fillMaxWidth().horizontalScroll(scroll)) {
                    Canvas(Modifier.width(wDp.dp).height(hDp.dp).pointerInput(year, weeksN) {
                        detectTapGestures(onTap = { o ->
                            val step = (CS + GP).dp.toPx()
                            val c = ((o.x - LX.dp.toPx()) / step).toInt(); val r = ((o.y - TY.dp.toPx()) / step).toInt()
                            pickDate = cells.firstOrNull { it.inYear && it.week == c && it.row == r }?.date
                        })
                    }) {
                        val cs2 = CS.dp.toPx(); val gp = GP.dp.toPx(); val lx = LX.dp.toPx(); val ty = TY.dp.toPx()
                        var lastMo = -1
                        cells.forEach { c ->
                            if (!c.inYear) return@forEach
                            val v = vals[c.date] ?: 0.0; val lv = RecapAnalytics.levelOf(v, cut)
                            val x = lx + c.week * (cs2 + gp); val y = ty + c.row * (cs2 + gp)
                            val col = if (lv > 0) acc.copy(alpha = op[lv]) else line.copy(alpha = if (c.date.isAfter(today)) .35f else .9f)
                            drawRoundRect(col, Offset(x, y), Size(cs2, cs2), CornerRadius(2.5f.dp.toPx()))
                            if (c.date == pickDate) drawRoundRect(acc, Offset(x, y), Size(cs2, cs2), CornerRadius(2.5f.dp.toPx()), style = Stroke(1.5f.dp.toPx()))
                            val mo = c.date.monthValue - 1
                            if (c.date.dayOfMonth <= 7 && mo != lastMo && c.row == 0) { lastMo = mo; drawText(tm.measure(monShort(mo + 1), tick), topLeft = Offset(x, 0f)) }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp, Alignment.End)) {
                    Text("Sedikit", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                    op.forEachIndexed { i, o -> Box(Modifier.size(10.dp).clip(RoundedCornerShape(2.dp)).background(if (i == 0) line.copy(alpha = .9f) else acc.copy(alpha = o))) }
                    Text("Banyak", style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                }
            }
            val pd = pickDate
            if (pd != null) {
                val o = dm[pd]; val ld = loadByDate[pd] ?: 0.0
                RcMono("${pd.dayOfMonth} ${monShort(pd.monthValue)} ${pd.year} · " + (if (o != null) "${fkm(o.km)} km · ${durHm(o.min)}" + (if (o.gain > 0) " · ${Js.idn(Js.roundI(o.gain))} m" else "") else "tidak lari") + (if (ld > 0) " · load ${Js.idn(Js.roundI(ld))}" else ""))
            } else {
                RcMono(if (best != null) "Hari terbaik: ${best.key.dayOfMonth} ${monShort(best.key.monthValue)} · " + (if (useLoad) "${Js.idn(Js.roundI(best.value))} load" else "${fkm(Math.round(best.value * 10) / 10.0)} km") else "Belum ada data di tahun ini.")
            }
        })
}
