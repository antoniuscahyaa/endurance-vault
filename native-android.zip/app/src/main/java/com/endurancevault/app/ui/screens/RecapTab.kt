package com.endurancevault.app.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ExpandLess
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.gestures.detectTapGestures
import com.endurancevault.app.domain.AdhRow
import com.endurancevault.app.domain.Js
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.ProgressAnalytics
import com.endurancevault.app.domain.RecapAnalytics
import com.endurancevault.app.domain.RecapPlanDay
import com.endurancevault.app.domain.RecapPlanWeek
import com.endurancevault.app.domain.RecapPr
import com.endurancevault.app.domain.RecapRun
import com.endurancevault.app.domain.TrainingMetrics
import com.endurancevault.app.domain.WeekBucket
import com.endurancevault.app.domain.WeeklyMetric
import com.endurancevault.app.domain.EasyPace
import com.endurancevault.app.domain.rcOf
import com.endurancevault.app.ui.UiState
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle as JTextStyle
import java.util.Locale
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlinx.coroutines.launch

/**
 * Tab "Rekap" native, disamakan dengan tab Rekap di rencana lari (web): tujuh kartu dengan urutan yang sama
 * (Progres, Grafik mingguan, Kepatuhan rencana, Ulasan mingguan, Log bulanan, Kalender konsistensi, Heatmap tahunan).
 * Tiap kartu punya ringkasan yang selalu terlihat (angka utama, penanda tren, visual mini) dan detail yang dibuka
 * dengan mengetuk kepala kartu. Logika ada di domain/RecapAnalytics.kt (diuji di JVM).
 */
private val ID_LOC = Locale("id", "ID")
private val DOW_ID = listOf("Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min")
private fun monShort(m: Int): String = java.time.Month.of(m).getDisplayName(JTextStyle.SHORT, ID_LOC)
private fun f1(x: Double): String = String.format(Locale.US, "%.1f", x).replace('.', ',')
private fun fkm(x: Double): String = if (x == floor(x)) x.toLong().toString() else f1(x)
private fun dmy(d: LocalDate) = "${d.dayOfMonth}/${d.monthValue}"
private fun durHm(min: Double): String { val t = Js.roundI(min); return if (t >= 60) "${t / 60}j ${t % 60}m" else "${t}m" }
private fun parseGoalMin(s: String): Double? {
    val p = s.trim().split(":").mapNotNull { it.toDoubleOrNull() }
    return when (p.size) { 3 -> p[0] * 60 + p[1] + p[2] / 60; 2 -> p[0] + p[1] / 60; else -> null }?.takeIf { it > 0 }
}

/** Hari libur dadakan, sesi dilewati, dan sesi yang digeser keluar tidak dihitung sebagai sesi jatuh tempo di kepatuhan. */
private fun excludedDates(mv: Map<String, com.endurancevault.app.domain.MvEntry>): Set<LocalDate> =
    mv.filter { (k, e) -> !k.startsWith("sw:") && (e.t == "spread" || e.t == "skip" || e.t == "mv") }
        .keys.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.toSet()

private fun prsAsOf(state: UiState, end: LocalDate): List<RecapPr> {
    val det = state.detailsByActivity.filterValues { d -> runCatching { !LocalDate.parse(d.date).isAfter(end) }.getOrDefault(false) }
    return ProgressAnalytics.personalBests(det).mapNotNull { b ->
        runCatching { RecapPr(b.label, b.distanceKm, b.durationMinutes, LocalDate.parse(b.dateIso)) }.getOrNull()
    }
}

@Composable
internal fun RecapTab(state: UiState, onOpen: (Long) -> Unit) {
    val ctx = LocalContext.current
    val today = LocalDate.now()
    val runs = remember(state.activities, state.detailsByActivity) {
        state.activities.mapNotNull { a ->
            val d = runCatching { LocalDate.parse(a.dateIso) }.getOrNull() ?: return@mapNotNull null
            RecapRun(a.id, d, a.km, a.durationSec / 60.0, a.avgHr, (a.gain ?: 0).toDouble(),
                state.detailsByActivity[a.id]?.loss?.toDouble(), a.type == "bike", a.name)
        }
    }
    val weeks = remember(state.plan) {
        (state.plan as? PlanOutcome.Ok)?.weeks.orEmpty().map { w ->
            RecapPlanWeek(w.i, w.start, w.km, w.days.map { RecapPlanDay(it.date, it.kind, it.km) })
        }
    }
    val runDates = remember(runs) { runs.filter { !it.bike && it.km > 0 }.map { it.date }.toSet() }
    val excluded = remember(state.mv) { excludedDates(state.mv) }
    val loadByDate = remember(state.activities, state.daily, state.plan, state.hrHistByActivity) {
        runCatching {
            TrainingMetrics.calculate(state.settings, state.activities, state.daily, state.plan, hrHistByActivity = state.hrHistByActivity)
                .days.associate { it.date to it.load }
        }.getOrDefault(emptyMap())
    }
    val dm = remember(runs) { RecapAnalytics.dayAggregates(runs) }
    val strengthDates = remember(state.strengthWorkouts) {
        state.strengthWorkouts.filter { !it.deleted }.mapNotNull { runCatching { LocalDate.parse(it.dateIso) }.getOrNull() }.toSet()
    }
    var year by rememberSaveable { mutableIntStateOf(today.year) }
    val years = remember(dm) { RecapAnalytics.years(dm, today) }
    if (year !in years) year = years.last()

    RecapProgress(state, runs, weeks, today)
    RecapWeekly(runs, today, onOpen)
    RecapAdherence(weeks, runDates, excluded, today)
    RecapReview(state, runs, weeks, runDates, loadByDate, today)
    RecapMonthly(runs, weeks, strengthDates, today, onOpen)
    RecapConsistency(dm, years, year, today) { year = it }
    RecapHeatYear(dm, loadByDate, years, year, today) { year = it }
}

// ===================== komponen kartu & visual mini =====================

@Composable
private fun RcCard(title: String, sub: String, summary: @Composable ColumnScope.() -> Unit, body: @Composable ColumnScope.() -> Unit) {
    var open by rememberSaveable(title) { mutableStateOf(false) }
    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth().clickable { open = !open }, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    if (sub.isNotBlank()) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Icon(if (open) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore,
                    contentDescription = if (open) "Tutup $title" else "Buka $title")
            }
            summary()
            AnimatedVisibility(visible = open, enter = expandVertically(), exit = shrinkVertically()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) { body() }
            }
        }
    }
}

@Composable
private fun RcBig(value: String, sub: String?, pill: String? = null, neg: Boolean = false) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            if (!pill.isNullOrBlank()) {
                Surface(shape = RoundedCornerShape(99.dp),
                    color = if (neg) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.secondaryContainer) {
                    Text(pill, Modifier.padding(horizontal = 8.dp, vertical = 3.dp), style = MaterialTheme.typography.labelSmall,
                        color = if (neg) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSecondaryContainer)
                }
            }
        }
        if (!sub.isNullOrBlank()) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun RcStats(items: List<Pair<String, String>>) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        items.forEach { (l, v) ->
            Column(Modifier.weight(1f)) {
                Text(l, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(v, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun RcRing(pct: Int) {
    val track = MaterialTheme.colorScheme.outlineVariant
    val col = MaterialTheme.colorScheme.primary
    Canvas(Modifier.size(46.dp)) {
        val sw = 5.dp.toPx(); val inset = sw / 2
        val tl = Offset(inset, inset); val sz = Size(size.width - sw, size.height - sw)
        drawArc(track, 0f, 360f, false, tl, sz, style = Stroke(sw))
        drawArc(col, -90f, 360f * pct.coerceIn(0, 100) / 100f, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
    }
}

@Composable
private fun RcBars(values: List<Float>, hi: Int, height: Int = 34) {
    val acc = MaterialTheme.colorScheme.primary
    val dim = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = .35f)
    Canvas(Modifier.fillMaxWidth().height(height.dp)) {
        val mx = values.maxOrNull() ?: 0f
        if (mx <= 0f || values.isEmpty()) return@Canvas
        val gap = 3.dp.toPx(); val bw = (size.width - gap * (values.size - 1)) / values.size
        values.forEachIndexed { i, v ->
            val h = if (v > 0f) max(size.height * .08f, v / mx * size.height) else min(4.dp.toPx(), size.height * .08f)
            drawRoundRect(if (i == hi) acc else dim, Offset(i * (bw + gap), size.height - h), Size(bw, h), CornerRadius(2.dp.toPx()))
        }
    }
}

/** Dua batang pembanding horizontal (bagian 0..100, warna). */
@Composable
private fun RcCompare(rows: List<Pair<Float, Color>>) {
    val line = MaterialTheme.colorScheme.outlineVariant
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        rows.forEach { (p, c) ->
            Canvas(Modifier.fillMaxWidth().height(6.dp)) {
                drawRoundRect(line, Offset.Zero, size, CornerRadius(3.dp.toPx()))
                drawRoundRect(c, Offset.Zero, Size(size.width * (p.coerceIn(3f, 100f) / 100f), size.height), CornerRadius(3.dp.toPx()))
            }
        }
    }
}

@Composable
private fun RcLegend(a: String, b: String? = null) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(a, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (b != null) Text(b, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Heatmap mini: nilai berurutan per kolom (minggu) lalu baris (hari). */
@Composable
private fun RcMiniGrid(vals: List<Double>, fut: List<Boolean>, cols: Int, rows: Int, cellH: Int = 8) {
    val acc = MaterialTheme.colorScheme.primary
    val line = MaterialTheme.colorScheme.outlineVariant
    val cut = remember(vals) { RecapAnalytics.levels(vals) }
    val op = floatArrayOf(0f, .3f, .52f, .76f, 1f)
    Canvas(Modifier.fillMaxWidth().height((rows * cellH + (rows - 1) * 2).dp)) {
        val gap = 2.dp.toPx(); val cw = (size.width - gap * (cols - 1)) / cols; val ch = cellH.dp.toPx()
        vals.forEachIndexed { i, v ->
            val c = i / rows; val r = i % rows
            val lv = RecapAnalytics.levelOf(v, cut)
            val col = if (lv > 0) acc.copy(alpha = op[lv]) else line.copy(alpha = if (fut.getOrNull(i) == true) .35f else .9f)
            drawRoundRect(col, Offset(c * (cw + gap), r * (ch + gap)), Size(cw, ch), CornerRadius(1.5.dp.toPx()))
        }
    }
}

@Composable
private fun RcMuted(text: String) = Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

@Composable
private fun RcHeading(text: String) = Text(text, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)

@Composable
private fun RcTableRow(cells: List<String>, weights: List<Float>, head: Boolean = false, tint: List<Color?> = emptyList()) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        cells.forEachIndexed { i, t ->
            Text(t, Modifier.weight(weights[i]),
                style = if (head) MaterialTheme.typography.labelSmall else MaterialTheme.typography.bodySmall,
                color = tint.getOrNull(i) ?: if (head) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                textAlign = if (i == 0) TextAlign.Start else TextAlign.End, maxLines = 1)
        }
    }
}

@Composable
private fun RcNav(label: String, canPrev: Boolean, canNext: Boolean, onPrev: () -> Unit, onNext: () -> Unit, now: String? = null, onNow: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        TextButton(onClick = onPrev, enabled = canPrev) { Text("‹") }
        Text(label, Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.titleSmall)
        TextButton(onClick = onNext, enabled = canNext) { Text("›") }
        if (now != null && onNow != null) OutlinedButton(onClick = onNow) { Text(now) }
    }
}

@Composable
private fun tickStyle(): TextStyle = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

// ===================== 1. Progres =====================

@Composable
private fun RecapProgress(state: UiState, runs: List<RecapRun>, weeks: List<RecapPlanWeek>, today: LocalDate) {
    val rows = remember(weeks, runs) { RecapAnalytics.progressRows(weeks, runs) }
    val curIdx = weeks.firstOrNull { it.start == RecapAnalytics.monday(today) }?.index ?: -1
    val ability = remember(state.settings, state.activities, state.daily) { runCatching { ProgressAnalytics.runningAbility(state.settings, state.activities, state.daily) }.getOrNull() }
    val prs = remember(state.detailsByActivity) { prsAsOf(state, today) }
    val easy = remember(runs, state.settings) { RecapAnalytics.easyWeeks(runs, runCatching { EasyPace.sessHr(state.settings) }.getOrDefault(0)) }
    val acc = MaterialTheme.colorScheme.primary
    RcCard("Progres", if (rows.isNotEmpty()) "${rows.size} minggu tercatat" else "",
        summary = {
            if (rows.isEmpty()) RcStats(listOf("Minggu" to "–", "Rata-rata" to "–"))
            else {
                val avg = rows.sumOf { it.st.km } / rows.size
                RcBig("${rows.size} minggu", "rata-rata ${Js.roundI(avg)} km")
                RcCompare(listOf((rows.size * 100f / max(1, weeks.size)) to acc))
                RcLegend("${rows.size} / ${weeks.size} mgg")
            }
        },
        body = {
            if (rows.isEmpty()) {
                RcMuted("Belum ada data lari. Catat atau impor lari untuk mengisi evaluasi dan perbandingan antar minggu.")
            } else {
                RecapAnalytics.progressEval(rows, curIdx).forEach { Text(it, style = MaterialTheme.typography.bodyMedium) }
                val deltas = RecapAnalytics.paceDeltas(rows)
                val w = listOf(.8f, 1.1f, 1.1f, 1f, .9f, 1f)
                RcTableRow(listOf("Minggu", "Rencana km", "Tercatat km", "Pace easy", "HR easy", "Δ pace"), w, head = true)
                rows.indices.reversed().forEach { i ->
                    val r = rows[i]; val dl = deltas[i]
                    val col = when { dl == null -> null; dl < 0 -> acc; dl > 0 -> MaterialTheme.colorScheme.error; else -> null }
                    RcTableRow(listOf("M${r.week.index + 1}", fkm(r.week.km), fkm(r.st.km), r.st.pace?.let { Js.paceStr(it) } ?: "–",
                        r.st.hr?.let { Js.roundI(it).toString() } ?: "–",
                        dl?.let { (if (it > 0) "+" else if (it < 0) "−" else "") + abs(it) + " dtk" } ?: "–"), w, tint = listOf(null, null, null, null, null, col))
                }
            }
            RcPrediction(state, ability, prs)
            RcEasyHistory(easy)
        })
}

@Composable
private fun RcPrediction(state: UiState, ability: com.endurancevault.app.domain.RunningAbility?, prs: List<RecapPr>) {
    RcHeading("Prediksi lomba")
    if (ability == null) {
        RcMuted("Butuh minimal 3 lari tercatat dengan jarak ≥ 3 km, durasi, dan HR rata-rata.")
    } else {
        val v = ability.value
        Text("Indeks kemampuan ${f1(v)} (setara VO2max), dari ${ability.runs} lari terakhir.", style = MaterialTheme.typography.bodyMedium)
        if (ability.weekly.size >= 2) {
            val f = ability.weekly[max(0, ability.weekly.size - 5)]; val l = ability.weekly.last()
            val dv = Math.round((l.second - f.second) * 10) / 10.0
            Text("Tren mingguan: " + (if (abs(dv) < 0.3) "stabil" else if (dv > 0) "naik ${f1(dv)}" else "turun ${f1(abs(dv))}") + " sejak ${dmy(f.first)}.", style = MaterialTheme.typography.bodyMedium)
        }
        val rc = rcOf(state.settings); val goal = parseGoalMin(state.settings.goalT)
        if (goal != null && !rc.trail && rc.km > 0) {
            val tp = RecapAnalytics.raceTimeV(v, rc.km * 1000)
            val df = Js.roundI((tp - goal) * 60)
            Text("Target ${rc.nm} ${Js.durStr(goal)}, prediksi saat ini ${Js.durStr(tp)}: " + (if (df <= 0) "target sudah terjangkau." else "selisih ${Js.durStr(df / 60.0)} lagi."), style = MaterialTheme.typography.bodyMedium)
        }
        val w = listOf(1.6f, 1f, 1f)
        RcTableRow(listOf("Jarak", "Prediksi", "Pace /km"), w, head = true)
        listOf("5K" to 5000.0, "10K" to 10000.0, "Half marathon" to 21097.5, "Marathon" to 42195.0).forEach { (n, dm) ->
            val t = RecapAnalytics.raceTimeV(v, dm)
            RcTableRow(listOf(n, Js.durStr(t), Js.paceStr(t / (dm / 1000))), w)
        }
        RcMuted("Perkiraan dari pace dan HR lari tercatat. Lari easy cenderung menghasilkan angka konservatif; lari di tanjakan atau cuaca panas memengaruhi hasil.")
    }
    RcHeading("Prediksi dari PR")
    val ref = RecapAnalytics.bestPrRef(prs)
    if (ref == null) {
        RcMuted("Belum ada PR 5K, 10K, atau half marathon dari data per kilometer (impor lari GPX/TCX/FIT).")
    } else {
        Text("Patokan: PR ${ref.label} ${Js.durStr(ref.t)} (VDOT ${f1(ref.vdot)}).", style = MaterialTheme.typography.bodyMedium)
        val w = listOf(1.6f, 1f, 1f, 1f)
        RcTableRow(listOf("Kategori", "Riegel", "VDOT", "Pace /km"), w, head = true)
        listOf("5K" to 5.0, "10K" to 10.0, "Half marathon" to 21.0975, "Marathon" to 42.195).forEach { (n, d) ->
            val rg = RecapAnalytics.riegel(ref.t, ref.d, d); val vt = RecapAnalytics.raceTimeV(ref.vdot, d * 1000)
            RcTableRow(listOf(n, Js.durStr(rg), Js.durStr(vt), Js.paceStr(vt / d)), w)
        }
    }
}

@Composable
private fun RcEasyHistory(easy: List<com.endurancevault.app.domain.RecapAnalytics.EasyWeek>) {
    RcHeading("Riwayat pace easy")
    if (easy.isEmpty()) { RcMuted("Belum ada data. Pace easy dihitung dari lari tercatat dengan HR di bawah batas easy."); return }
    if (easy.size >= 2) {
        val f = easy.first(); val l = easy.last()
        val dt = Js.roundI((l.pace - f.pace) * 60); val dh = Js.roundI(l.hr - f.hr)
        Text("Dari ${Js.paceStr(f.pace)}/km (${dmy(f.week)}) ke ${Js.paceStr(l.pace)}/km: " +
            (if (dt == 0) "sama" else "${abs(dt)} dtk/km ${if (dt < 0) "lebih cepat" else "lebih lambat"}") + ", HR rata-rata " +
            (if (dh == 0) "sama" else "${abs(dh)} bpm ${if (dh < 0) "lebih rendah" else "lebih tinggi"}") + ".", style = MaterialTheme.typography.bodyMedium)
        val h2 = easy.takeLast(16)
        val tm = rememberTextMeasurer(); val tick = tickStyle()
        val acc = MaterialTheme.colorScheme.primary; val grid = MaterialTheme.colorScheme.outlineVariant
        Canvas(Modifier.fillMaxWidth().height(120.dp)) {
            val L = 36.dp.toPx(); val R = 8.dp.toPx(); val T = 8.dp.toPx(); val B = 18.dp.toPx()
            var pmin = h2.minOf { it.pace * 60 }; var pmax = h2.maxOf { it.pace * 60 }
            pmin = floor((pmin - 5) / 5) * 5; pmax = kotlin.math.ceil((pmax + 5) / 5) * 5; if (pmax - pmin < 20) pmax = pmin + 20
            fun xs(i: Int) = L + i * (size.width - L - R) / (h2.size - 1)
            fun ys(s: Double) = (T + (s - pmin) / (pmax - pmin) * (size.height - T - B)).toFloat()
            listOf(pmin, (pmin + pmax) / 2, pmax).forEach { s ->
                drawLine(grid.copy(alpha = .6f), Offset(L, ys(s)), Offset(size.width - R, ys(s)), 1.dp.toPx())
                val lay = tm.measure(Js.paceStr(s / 60), tick)
                drawText(lay, topLeft = Offset(L - 4.dp.toPx() - lay.size.width, ys(s) - lay.size.height / 2f))
            }
            val p = Path(); h2.forEachIndexed { i, w -> val o = Offset(xs(i), ys(w.pace * 60)); if (i == 0) p.moveTo(o.x, o.y) else p.lineTo(o.x, o.y) }
            drawPath(p, acc, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
            h2.forEachIndexed { i, w -> drawCircle(acc, if (i == h2.lastIndex) 4.dp.toPx() else 2.5f.dp.toPx(), Offset(xs(i), ys(w.pace * 60))) }
        }
        RcMuted("Lebih tinggi berarti lebih lambat pada sumbu ini; garis turun = pace membaik.")
    }
    val w = listOf(1.6f, .9f, 1f, .6f, .9f)
    RcTableRow(listOf("Minggu", "Pace easy", "HR rata-rata", "Sesi", "Δ pace"), w, head = true)
    var prev: Double? = null
    val rowsOut = easy.map { e ->
        val d = prev?.let { Js.roundI((e.pace - it) * 60) }; prev = e.pace; e to d
    }
    rowsOut.takeLast(12).reversed().forEach { (e, d) ->
        RcTableRow(listOf("${dmy(e.week)} – ${dmy(e.week.plusDays(6))}", Js.paceStr(e.pace), Js.roundI(e.hr).toString(), e.n.toString(),
            d?.let { (if (it > 0) "+" else if (it < 0) "−" else "") + abs(it) + " dtk" } ?: "–"), w)
    }
}

// ===================== 2. Grafik mingguan =====================

@Composable
private fun RecapWeekly(runs: List<RecapRun>, today: LocalDate, onOpen: (Long) -> Unit) {
    val b = remember(runs) { RecapAnalytics.weeklyBuckets(runs, today, 16) }
    var metric by rememberSaveable { mutableStateOf(WeeklyMetric.KM) }
    var line by rememberSaveable { mutableStateOf(false) }
    var sel by rememberSaveable { mutableIntStateOf(15) }
    val avg4 = (b[11].km + b[12].km + b[13].km + b[14].km) / 4
    val cur = b[15].km
    val dl = if (avg4 > 0) Js.roundI((cur - avg4) / avg4 * 100) else null
    val sub = when (metric) {
        WeeklyMetric.KM -> "km per minggu"; WeeklyMetric.MIN -> "jam per minggu"; WeeklyMetric.GAIN -> "m Elev. Gain per minggu"
        WeeklyMetric.LOSS -> "m Elev. Loss per minggu"; WeeklyMetric.VAM -> "VAM (m/jam) per minggu"
    }
    RcCard("Grafik mingguan", sub,
        summary = {
            if (b.sumOf { it.km } <= 0) RcStats(listOf("Minggu ini" to "–", "Rata-rata" to "–"))
            else {
                RcBig("${fkm(cur)} km", "rata-rata ${fkm(avg4)} km", if (dl != null && dl != 0) (if (dl > 0) "▲ " else "▼ ") + abs(dl) + "%" else null, dl != null && dl < 0)
                RcBars(b.takeLast(8).map { it.km.toFloat() }, 7, 52)
            }
        },
        body = {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(WeeklyMetric.KM to "Jarak", WeeklyMetric.MIN to "Waktu", WeeklyMetric.GAIN to "Elev. Gain", WeeklyMetric.LOSS to "Elev. Loss", WeeklyMetric.VAM to "VAM").forEach { (m, l) ->
                    FilterChip(selected = metric == m, onClick = { metric = m }, label = { Text(l) })
                }
                FilterChip(selected = !line, onClick = { line = false }, label = { Text("Bar") })
                FilterChip(selected = line, onClick = { line = true }, label = { Text("Line") })
            }
            RcWeeklyChart(b, metric, line, sel) { sel = it }
            val w = b[sel.coerceIn(0, 15)]
            val vam = w.vam
            RcMuted("${dmy(w.start)} – ${dmy(w.end)} · ${fkm(w.km)} km · ${durHm(w.min)} · ${Js.idn(Js.roundI(w.gain))} m" +
                (if (metric == WeeklyMetric.LOSS) " · Elevation Loss ${Js.idn(Js.roundI(w.loss))} m" else "") +
                (if (vam > 0) " · VAM ${Js.idn(vam)} m/j" else "") + " · ${w.n} sesi")
            val sessions = runs.filter { !it.bike && w.ids.contains(it.id) }.sortedBy { it.date }
            sessions.forEach { r ->
                Row(Modifier.fillMaxWidth().clickable { onOpen(r.id) }.padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${dmy(r.date)} · ${r.name.ifBlank { "Lari" }}", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f), maxLines = 1)
                    Text("${fkm(r.km)} km" + if (r.km > 0 && r.min > 0) " · ${Js.paceStr(r.min / r.km)}/km" else "", style = MaterialTheme.typography.bodySmall)
                }
            }
            if (sessions.isNotEmpty()) RcMuted("Ketuk sesi untuk membuka detailnya.")
        })
}

@Composable
private fun RcWeeklyChart(b: List<WeekBucket>, metric: WeeklyMetric, line: Boolean, sel: Int, onSel: (Int) -> Unit) {
    val vals = with(RecapAnalytics) { b.map { it.value(metric) } }
    val top = RecapAnalytics.niceMax(vals.maxOrNull() ?: 0.0)
    val spikes = remember(vals, metric) {
        if (metric == WeeklyMetric.LOSS) RecapAnalytics.spikeScan(vals, vals.map { false }, 150.0).associateBy { it.i } else emptyMap()
    }
    val tm = rememberTextMeasurer(); val tick = tickStyle()
    val acc = MaterialTheme.colorScheme.primary; val grid = MaterialTheme.colorScheme.outlineVariant
    val surf = MaterialTheme.colorScheme.surface
    Canvas(Modifier.fillMaxWidth().height(190.dp).pointerInput(Unit) {
        detectTapGestures(onTap = { o ->
            val pl = 32.dp.toPx(); val slot = (size.width - pl - 8.dp.toPx()) / 16f
            onSel(((o.x - pl) / slot).toInt().coerceIn(0, 15))
        })
    }) {
        val PL = 32.dp.toPx(); val R = 8.dp.toPx(); val T = 14.dp.toPx(); val B = 24.dp.toPx()
        val iw = size.width - PL - R; val ih = size.height - T - B; val slot = iw / 16f; val bw = slot * .62f
        fun X(j: Int) = PL + slot * (j + .5f)
        fun Y(v: Double) = (T + ih * (1 - v / top)).toFloat()
        fun tk(v: Double) = if (abs(v - Math.round(v)) < 1e-9) Math.round(v).toString() else f1(v)
        listOf(0.0, .5, 1.0).forEach { f ->
            val y = Y(top * f)
            drawLine(grid.copy(alpha = .6f), Offset(PL, y), Offset(size.width - R, y), 1.dp.toPx())
            val lay = tm.measure(tk(top * f), tick)
            drawText(lay, topLeft = Offset(PL - 4.dp.toPx() - lay.size.width, y - lay.size.height / 2f))
        }
        if (line) {
            val sx = X(sel)
            drawLine(grid, Offset(sx, T), Offset(sx, Y(0.0)), 1.dp.toPx())
            val p = Path(); val area = Path()
            area.moveTo(X(0), Y(0.0))
            vals.forEachIndexed { j, v -> val o = Offset(X(j), Y(v)); if (j == 0) p.moveTo(o.x, o.y) else p.lineTo(o.x, o.y); area.lineTo(o.x, o.y) }
            area.lineTo(X(15), Y(0.0)); area.close()
            drawPath(area, acc.copy(alpha = .16f))
            drawPath(p, acc, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
            vals.forEachIndexed { j, v ->
                if (j == sel) { drawCircle(surf, 6.5f.dp.toPx(), Offset(X(j), Y(v))); drawCircle(acc, 4.5f.dp.toPx(), Offset(X(j), Y(v))) }
                else drawCircle(acc, 2.4f.dp.toPx(), Offset(X(j), Y(v)))
            }
        } else {
            vals.forEachIndexed { j, v ->
                val hh = if (v > 0) max(2.dp.toPx(), Y(0.0) - Y(v)) else 1.5f.dp.toPx()
                drawRoundRect(acc.copy(alpha = if (j == sel) 1f else .5f), Offset(X(j) - bw / 2, Y(0.0) - hh), Size(bw, hh), CornerRadius(3.dp.toPx()))
            }
        }
        b.forEachIndexed { j, w ->
            spikes[j]?.let { s ->
                val lay = tm.measure(if (s.high) "▲▲" else "▲", tick.copy(fontWeight = FontWeight.Bold))
                drawText(lay, topLeft = Offset(X(j) - lay.size.width / 2f, Y(vals[j]) - 5.dp.toPx() - lay.size.height))
            }
            if ((15 - j) % 3 == 0) {
                val lay = tm.measure(dmy(w.start), tick)
                drawText(lay, topLeft = Offset(X(j) - lay.size.width / 2f, size.height - 6.dp.toPx() - lay.size.height))
            }
        }
    }
    if (spikes.isNotEmpty()) RcMuted("▲ = Elev. Loss naik lebih dari 10% dari minggu pembanding (▲▲ ≥ 20%).")
}

// ===================== 3. Kepatuhan rencana =====================

@Composable
private fun RecapAdherence(weeks: List<RecapPlanWeek>, runDates: Set<LocalDate>, excluded: Set<LocalDate>, today: LocalDate) {
    val rows = remember(weeks, runDates, excluded) { RecapAnalytics.adhRows(weeks, runDates, today, excluded) }
    val sc = remember(rows) { RecapAnalytics.adhScan(rows) }
    val offer = remember(rows) { RecapAnalytics.adhOffer(rows) }
    val err = MaterialTheme.colorScheme.error
    RcCard("Kepatuhan rencana", sc.pct?.let { "$it%" } ?: "",
        summary = {
            val cur = sc.cur
            if (sc.pct == null || cur == null) RcStats(listOf("Capaian" to "–", "Tren" to "–"))
            else {
                val pill = if (offer != null) "Saran geser" else when (sc.dir) { "up" -> "▲"; "down" -> "▼"; else -> null }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) { RcBig("${sc.pct}%", "${cur.done} dari ${cur.due} sesi", pill, offer != null || sc.dir == "down") }
                    RcRing(sc.pct)
                }
                RcBars(sc.trend.map { (it.pct ?: 0).toFloat() }, sc.trend.lastIndex, 34)
                RcLegend("4 minggu terakhir", sc.avg?.let { "rata-rata $it%" })
            }
        },
        body = {
            if (sc.trend.isEmpty()) {
                RcMuted("Belum ada sesi yang jatuh tempo di rencana ini.")
            } else {
                RcStats(sc.trend.map { x: AdhRow -> "M${x.i + 1}" to "${x.done}/${x.due} · ${x.pct}%" })
                if (sc.dir != null && sc.prevAvg != null) {
                    RcMuted(when (sc.dir) {
                        "up" -> "Minggu ini lebih baik dari rata-rata minggu sebelumnya (${sc.prevAvg}%)."
                        "down" -> "Minggu ini di bawah rata-rata minggu sebelumnya (${sc.prevAvg}%)."
                        else -> "Setara dengan rata-rata minggu sebelumnya (${sc.prevAvg}%)."
                    })
                }
                if (offer != null) {
                    Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.errorContainer) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(if (offer.cur) "Minggu ini baru ${offer.pct}% sesi selesai (${offer.miss} terlewat)."
                                else "Dua minggu berturut-turut di bawah ${RecapAnalytics.ADH_LOW2}% (${offer.miss} sesi terlewat).",
                                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onErrorContainer)
                            Text("Pertimbangkan menurunkan beban beberapa minggu ke depan agar kenaikan paling banyak 10% per minggu dari level yang benar-benar tercapai. Penggeseran otomatis belum tersedia di versi native; pakai Libur dadakan atau tukar hari di Jadwal.",
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
                        }
                    }
                }
                RcMuted("Libur, lomba, acara, dan hari libur dadakan tidak dihitung. Sesi dianggap selesai bila ada lari tercatat di tanggal itu.")
            }
        })
}

// ===================== 4. Ulasan mingguan =====================

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RecapReview(state: UiState, runs: List<RecapRun>, weeks: List<RecapPlanWeek>, runDates: Set<LocalDate>, loadByDate: Map<LocalDate, Double>, today: LocalDate) {
    var back by rememberSaveable { mutableIntStateOf(0) }
    val curMon = RecapAnalytics.monday(today)
    val logged = runs.filter { !it.bike && it.km > 0 }
    val first = logged.minOfOrNull { it.date }
    val wks = if (first == null) 0 else java.time.temporal.ChronoUnit.WEEKS.between(RecapAnalytics.monday(first), curMon).toInt()
    val maxBack = max(-1, wks - 1)
    if (back > maxBack) back = maxBack
    if (back < -1) back = -1
    val mon = curMon.minusWeeks((1 + back).toLong())
    val isCur = mon == curMon
    val rv = remember(mon, runs, weeks, loadByDate, state.detailsByActivity) {
        val prs = RecapAnalytics.newPrsIn(mon, prsAsOf(state, mon.plusDays(6)), prsAsOf(state, mon.minusDays(1)))
        RecapAnalytics.weekReview(mon, runs, weeks, runDates, loadByDate, prs)
    }
    val rows = remember(weeks, runs) { RecapAnalytics.progressRows(weeks, runs) }
    val ds = remember(runs, weeks) { RecapAnalytics.dayStreak(runs, weeks.flatMap { it.days }.filter { it.kind == "rest" }.map { it.date }.toSet(), today) }
    val ws = remember(runs, weeks) { RecapAnalytics.weekStreak(runs, weeks, runDates, today) }
    val prs = remember(state.detailsByActivity) { prsAsOf(state, today) }
    val ach = remember(runs, prs, ws) { RecapAnalytics.achievements(runs, prs.size, 4, ws) }
    val pct = rv.planKm?.takeIf { it > 0 }?.let { Js.roundI(rv.km / it * 100) }
    RcCard("Ulasan mingguan", if (!isCur && back == 0 && today.dayOfWeek.value == 1) "Ulasan Senin" else "",
        summary = {
            val l = rows.lastOrNull()
            if (l == null) RcStats(listOf("Capaian" to "–", "Minggu" to "–"))
            else {
                val p = if (l.week.km > 0) Js.roundI(l.st.km / l.week.km * 100) else 0
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) { RcBig("$p%", "M${l.week.index + 1} · ${Js.roundI(l.st.km)} dari ${Js.roundI(l.week.km)} km") }
                    RcRing(p)
                }
            }
        },
        body = {
            if (first == null) {
                RcMuted("Belum ada lari tercatat. Ulasan mingguan muncul setelah ada sesi.")
            } else {
                RcNav(
                    label = "${dmy(mon)} – ${dmy(mon.plusDays(6))}" + if (isCur) " · sejauh ini" else "",
                    canPrev = (back < maxBack),
                    canNext = (back > -1),
                    onPrev = { back += 1 },
                    onNext = { back -= 1 },
                    now = "Minggu lalu",
                    onNow = { back = 0 }
                )
                if (rv.n == 0) {
                    Text("Tidak ada lari tercatat di minggu ini.", style = MaterialTheme.typography.bodyMedium)
                } else {
                    val pairs = buildList {
                        add("Jarak" to fkm(rv.km) + (rv.planKm?.takeIf { it > 0 }?.let { " / ${fkm(it)}" } ?: "") + " km")
                        add("Sesi lari" to rv.n.toString() + (rv.planN?.let { " / $it" } ?: ""))
                        add("Waktu" to durHm(rv.min))
                        add("Elev. Gain" to "${Js.idn(Js.roundI(rv.gain))} m")
                        if (rv.load > 0) add("Training load" to Js.roundI(rv.load).toString())
                        rv.hr?.let { add("HR rata-rata" to Js.roundI(it).toString()) }
                        rv.cons?.let { add("Konsistensi" to "$it%") }
                    }
                    pairs.chunked(2).forEach { r -> RcStats(if (r.size == 2) r else r + ("" to "")) }
                    if (pct != null) RcCompare(listOf(min(100, pct).toFloat() to MaterialTheme.colorScheme.primary))
                    val verdict = when {
                        pct == null -> "Tidak ada rencana km untuk minggu ini, jadi tidak ada perbandingan target."
                        isCur -> "$pct% dari target minggu ini sejauh ini."
                        pct > 115 -> "Di atas target ($pct%). Jaga pemulihan minggu depan."
                        pct >= 90 -> "Sesuai target ($pct%)."
                        pct >= 60 -> "Sedikit di bawah target ($pct%)."
                        else -> "Jauh di bawah target ($pct%)."
                    }
                    Text(verdict, style = MaterialTheme.typography.bodyMedium, color = if (pct != null && !isCur && pct in 90..115) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                    rv.prs.forEach { Text("★ PR baru ${it.first}: ${Js.durStr(it.second)}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary) }
                    if (rv.recLong) Text("★ Lari terpanjang sejauh ini: ${fkm(rv.longKm)} km", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                    if (rv.recWeek) Text("★ Jarak mingguan tertinggi sejauh ini: ${fkm(rv.km)} km", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                    if (rv.prevKm > 0 && !isCur) { val dk = rv.km - rv.prevKm; Text("Dibanding minggu sebelumnya: ${if (dk >= 0) "+" else "−"}${fkm(abs(dk))} km", style = MaterialTheme.typography.bodyMedium) }
                }
                Text("🔥 Streak · $ds hari berturut-turut · $ws minggu beruntun", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    ach.forEach { a ->
                        Surface(shape = RoundedCornerShape(99.dp), color = if (a.on) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(.8.dp, MaterialTheme.colorScheme.outlineVariant)) {
                            Text((if (a.on) "✓ " else "") + a.text, Modifier.padding(horizontal = 10.dp, vertical = 4.dp), style = MaterialTheme.typography.labelSmall,
                                color = if (a.on) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                RcMuted("Streak hari menghitung hari berturut-turut dengan lari tercatat; hari libur dalam rencana tidak memutusnya. Minggu beruntun menghitung minggu dengan jarak minimal 80% rencana (tanpa rencana: minimal satu lari). Setiap Senin, tombol \"Minggu lalu\" menampilkan ringkasan minggu yang baru selesai.")
            }
        })
}

// ===================== 5. Log bulanan =====================

@Composable
private fun RecapMonthly(runs: List<RecapRun>, weeks: List<RecapPlanWeek>, strengthDates: Set<LocalDate>, today: LocalDate, onOpen: (Long) -> Unit) {
    val ctx = LocalContext.current
    val byDate = remember(runs) { runs.groupBy { it.date } }
    val runKm = remember(runs) { runs.filter { !it.bike }.groupBy { it.date }.mapValues { (_, v) -> v.sumOf { it.km } } }
    val bikeKm = remember(runs) { runs.filter { it.bike }.groupBy { it.date }.mapValues { (_, v) -> v.sumOf { it.km } } }
    val runDay = remember(runs) { runs.filter { !it.bike && (it.km > 0 || it.min > 0) }.map { it.date }.toSet() }
    val months = remember(runs, strengthDates, weeks) {
        RecapAnalytics.monthRange(byDate.keys + strengthDates, weeks.firstOrNull()?.start, today)
    }
    val pager = rememberPagerState(initialPage = months.lastIndex.coerceAtLeast(0)) { months.size }
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var pick by remember { mutableStateOf<LocalDate?>(null) }
    val ym = months.getOrNull(pager.currentPage) ?: YearMonth.from(today)
    fun monthStats(m: YearMonth): Triple<Int, Double, Int> {
        val days = (1..m.lengthOfMonth()).map { m.atDay(it) }
        return Triple(days.count { it in runDay }, days.sumOf { runKm[it] ?: 0.0 }, days.count { it in strengthDates })
    }
    val acc = MaterialTheme.colorScheme.primary
    val line = MaterialTheme.colorScheme.outlineVariant
    RcCard("Log bulanan", "geser untuk ganti bulan",
        summary = {
            val m = YearMonth.from(today)
            val sess = (1..m.lengthOfMonth()).sumOf { d -> if (m.atDay(d) in runDay) (byDate[m.atDay(d)]?.count { !it.bike } ?: 0) else 0 }
            if (sess == 0) RcStats(listOf("Sesi" to "–", "Jarak" to "–"))
            else {
                RcStats(listOf("Sesi" to sess.toString(), "Jarak" to "${fkm(monthStats(m).second)} km"))
                RcMiniGrid((1..m.lengthOfMonth()).map { runKm[m.atDay(it)] ?: 0.0 }, (1..m.lengthOfMonth()).map { m.atDay(it).isAfter(today) }, m.lengthOfMonth(), 1, 8)
            }
        },
        body = {
            RcNav("${monShort(ym.monthValue)} ${ym.year}", pager.currentPage > 0, pager.currentPage < months.lastIndex,
                { scope.launch { pager.animateScrollToPage(pager.currentPage - 1) } }, { scope.launch { pager.animateScrollToPage(pager.currentPage + 1) } },
                "Bulan ini") { scope.launch { pager.animateScrollToPage(months.lastIndex) } }
            HorizontalPager(state = pager, modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) { page ->
                val m = months[page]
                val (nr, km, ns) = monthStats(m)
                val days = (1..m.lengthOfMonth()).map { m.atDay(it) }
                val nb = days.count { it in bikeKm }; val kb = days.sumOf { bikeKm[it] ?: 0.0 }
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("${monShort(m.monthValue)} ${m.year}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        RcMuted("$nr hari lari · ${fkm(km)} km" + if (ns > 0) " · $ns strength" else "")
                    }
                    if (nb > 0) RcMuted("$nb sepeda · ${fkm(kb)} km")
                    Row(Modifier.fillMaxWidth()) { DOW_ID.forEach { Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
                    val off = m.atDay(1).dayOfWeek.value - 1
                    val total = off + m.lengthOfMonth()
                    val rowsN = (total + 6) / 7
                    repeat(rowsN) { r ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                            repeat(7) { c ->
                                val idx = r * 7 + c; val dn = idx - off + 1
                                if (dn < 1 || dn > m.lengthOfMonth()) Box(Modifier.weight(1f).aspectRatio(.82f))
                                else {
                                    val d = m.atDay(dn); val kd = runKm[d] ?: 0.0; val run = d in runDay
                                    val lv = RecapAnalytics.monthDayLevel(kd, run)
                                    val bg = if (run) acc.copy(alpha = when (lv) { 1 -> .16f; 3 -> .5f; else -> .32f }) else Color.Transparent
                                    val has = byDate.containsKey(d)
                                    Box(Modifier.weight(1f).aspectRatio(.82f).clip(RoundedCornerShape(8.dp)).background(bg)
                                        .border(if (d == today) BorderStroke(1.5.dp, acc) else BorderStroke(.5.dp, line.copy(alpha = .5f)), RoundedCornerShape(8.dp))
                                        .clickable(enabled = has) { pick = d }.padding(2.dp)) {
                                        Text(dn.toString(), Modifier.align(Alignment.TopStart), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        if (kd > 0) Text(fkm(kd), Modifier.align(Alignment.Center), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                        Row(Modifier.align(Alignment.BottomCenter), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                            if (d in bikeKm) Box(Modifier.size(5.dp).clip(RoundedCornerShape(99.dp)).background(MaterialTheme.colorScheme.tertiary))
                                            if (d in strengthDates) Box(Modifier.size(5.dp).clip(RoundedCornerShape(1.dp)).background(MaterialTheme.colorScheme.secondary))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("▇ Lari (km)", style = MaterialTheme.typography.labelSmall, color = acc)
                Text("● Sepeda", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.tertiary)
                Text("■ Strength", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
            }
            val dsel = pick
            if (dsel != null && dsel.year == ym.year && dsel.monthValue == ym.monthValue) {
                RcHeading("${dsel.dayOfMonth} ${monShort(dsel.monthValue)} ${dsel.year}")
                byDate[dsel].orEmpty().forEach { r ->
                    Row(Modifier.fillMaxWidth().clickable { onOpen(r.id) }.padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text((if (r.bike) "Sepeda · " else "") + r.name.ifBlank { "Lari" }, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, maxLines = 1)
                        Text("${fkm(r.km)} km" + if (r.km > 0 && r.min > 0 && !r.bike) " · ${Js.paceStr(r.min / r.km)}/km" else "", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            OutlinedButton(onClick = {
                val (n2, k2, s2) = monthStats(ym)
                val msg = "Rekap ${monShort(ym.monthValue)} ${ym.year}: $n2 hari lari · ${fkm(k2)} km" + if (s2 > 0) " · $s2 strength" else ""
                ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, msg) }, "Bagikan rekap bulan"))
            }) { Text("Bagikan ringkasan") }
        })
}

// ===================== 6. Kalender konsistensi =====================

@Composable
private fun RecapConsistency(dm: Map<LocalDate, com.endurancevault.app.domain.DayAgg>, years: List<Int>, year: Int, today: LocalDate, onYear: (Int) -> Unit) {
    val a = remember(dm, year) { RecapAnalytics.monthAgg(dm, year) }
    val b = remember(dm, year) { RecapAnalytics.monthAgg(dm, year - 1) }
    val has = a.any { it.days > 0 }
    val acc = MaterialTheme.colorScheme.primary
    val up = MaterialTheme.colorScheme.primary; val dn = MaterialTheme.colorScheme.error
    RcCard("Kalender konsistensi", "$year vs ${year - 1}",
        summary = {
            val ya = RecapAnalytics.ytd(dm, today.year, today).second; val yb = RecapAnalytics.ytd(dm, today.year - 1, today).second
            if (ya == 0 && yb == 0) RcStats(listOf("Tahun ini" to "–", "Tahun lalu" to "–"))
            else {
                val mx = max(1, max(ya, yb)).toFloat()
                RcStats(listOf("${today.year}" to "$ya hr", "${today.year - 1}" to "$yb hr"))
                RcCompare(listOf(ya / mx * 100 to acc, yb / mx * 100 to MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = .4f)))
            }
        },
        body = {
            RcNav("$year", year > years.first(), year < years.last(), { onYear(year - 1) }, { onYear(year + 1) })
            if (!has) RcMuted("Belum ada lari di tahun ini.")
            else {
                val w = listOf(.7f, 1f, .9f, 1.2f, .8f)
                RcTableRow(listOf("", "Jarak", "Jam", "Elev. gain", "Hari"), w, head = true)
                var tA = DoubleArray(4); var tB = DoubleArray(4)
                fun vals(m: com.endurancevault.app.domain.MonthAgg) = doubleArrayOf(m.km, m.min, m.gain, m.days.toDouble())
                fun fv(k: Int, v: Double): String = if (v <= 0) "–" else when (k) { 0 -> fkm(Math.round(v * 10) / 10.0); 1 -> f1(Math.round(v / 6.0) / 10.0); else -> Js.idn(Js.roundI(v)) }
                fun cellsOf(c: DoubleArray, p: DoubleArray): Pair<List<String>, List<Color?>> {
                    val txt = (0 until 4).map { k -> val d = RecapAnalytics.deltaText(c[k], p[k]); fv(k, c[k]) + if (d.isNotEmpty()) "  $d" else "" }
                    val tint = (0 until 4).map { k -> val d = RecapAnalytics.deltaText(c[k], p[k]); if (d.startsWith("▲")) up else if (d.startsWith("▼")) dn else null }
                    return txt to tint
                }
                a.forEachIndexed { i, m ->
                    val c = vals(m); val p = vals(b[i])
                    for (k in 0 until 4) { tA[k] += c[k]; tB[k] += p[k] }
                    val (txt, tint) = cellsOf(c, p)
                    val now = year == today.year && i == today.monthValue - 1
                    Surface(color = if (now) MaterialTheme.colorScheme.secondaryContainer.copy(alpha = .45f) else Color.Transparent, shape = RoundedCornerShape(6.dp)) {
                        RcTableRow(listOf(monShort(i + 1)) + txt, w, tint = listOf<Color?>(null) + tint)
                    }
                }
                val (tt, tc) = cellsOf(tA, tB)
                RcTableRow(listOf("Total") + tt, w, tint = listOf<Color?>(null) + tc)
                RcMuted("Jam = waktu lari. Persen di samping angka membandingkan dengan bulan yang sama tahun lalu. Sesi sepeda tidak dihitung.")
            }
        })
}

// ===================== 7. Heatmap tahunan =====================

@Composable
private fun RecapHeatYear(dm: Map<LocalDate, com.endurancevault.app.domain.DayAgg>, loadByDate: Map<LocalDate, Double>, years: List<Int>, year: Int, today: LocalDate, onYear: (Int) -> Unit) {
    var useLoad by rememberSaveable { mutableStateOf(false) }
    var pickDate by remember { mutableStateOf<LocalDate?>(null) }
    val (cells, weeksN) = remember(year) { RecapAnalytics.yearGrid(year) }
    val vals = remember(dm, loadByDate, year, useLoad) {
        cells.filter { it.inYear }.associate { it.date to (if (useLoad) (loadByDate[it.date] ?: 0.0) else (dm[it.date]?.km ?: 0.0)) }
    }
    val cut = remember(vals) { RecapAnalytics.levels(vals.values) }
    val tot = vals.values.sum(); val act = vals.values.count { it > 0 }
    val best = vals.maxByOrNull { it.value }?.takeIf { it.value > 0 }
    val acc = MaterialTheme.colorScheme.primary; val line = MaterialTheme.colorScheme.outlineVariant
    val tm = rememberTextMeasurer(); val tick = tickStyle()
    val op = floatArrayOf(0f, .3f, .52f, .76f, 1f)
    val density = LocalDensity.current
    val CS = 11f; val GP = 3f; val LX = 22f; val TY = 16f
    val wDp = LX + weeksN * (CS + GP); val hDp = TY + 7 * (CS + GP)
    val scroll = rememberScrollState()
    LaunchedEffect(year, scroll.maxValue) {
        if (year == today.year) {
            val tw = cells.firstOrNull { it.date == today }?.week ?: weeksN
            val contentPx = with(density) { wDp.dp.toPx() }
            val viewport = contentPx - scroll.maxValue
            val target = with(density) { (LX + (tw + 1) * (CS + GP)).dp.toPx() } - viewport + 8f
            scroll.scrollTo(max(0f, target).toInt())
        } else scroll.scrollTo(0)
    }
    // ringkasan: tahun berjalan, YTD vs tahun lalu
    val ya = RecapAnalytics.ytd(dm, today.year, today); val yb = RecapAnalytics.ytd(dm, today.year - 1, today)
    RcCard("Heatmap tahunan", "${if (useLoad) Js.idn(Js.roundI(tot)) else fkm(Math.round(tot * 10) / 10.0)} ${if (useLoad) "load" else "km"} · $act hari",
        summary = {
            if (!(ya.first > 0)) RcStats(listOf("Jarak" to "–", "Hari aktif" to "–"))
            else {
                val dl = if (yb.first > 0) Js.roundI((ya.first - yb.first) / yb.first * 100) else null
                RcBig("${fkm(Math.round(ya.first * 10) / 10.0)} km", "${ya.second} hari aktif", if (dl != null && dl != 0) (if (dl > 0) "▲ " else "▼ ") + abs(dl) + "%" else null, dl != null && dl < 0)
                val start = RecapAnalytics.monday(today).minusWeeks(19)
                val days = (0 until 140).map { start.plusDays(it.toLong()) }
                RcMiniGrid(days.map { dm[it]?.km ?: 0.0 }, days.map { it.isAfter(today) }, 20, 7, 7)
            }
        },
        body = {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                FilterChip(selected = !useLoad, onClick = { useLoad = false }, label = { Text("Jarak") })
                FilterChip(selected = useLoad, onClick = { useLoad = true }, label = { Text("Load") })
            }
            RcNav("$year", year > years.first(), year < years.last(), { onYear(year - 1) }, { onYear(year + 1) })
            Box(Modifier.fillMaxWidth().horizontalScroll(scroll)) {
                Canvas(Modifier.width(wDp.dp).height(hDp.dp).pointerInput(year, weeksN) {
                    detectTapGestures(onTap = { o ->
                        val step = (CS + GP).dp.toPx()
                        val c = ((o.x - LX.dp.toPx()) / step).toInt(); val r = ((o.y - TY.dp.toPx()) / step).toInt()
                        pickDate = cells.firstOrNull { it.inYear && it.week == c && it.row == r }?.date
                    })
                }) {
                    val cs = CS.dp.toPx(); val gp = GP.dp.toPx(); val lx = LX.dp.toPx(); val ty = TY.dp.toPx()
                    var lastMo = -1
                    cells.forEach { c ->
                        if (!c.inYear) return@forEach
                        val v = vals[c.date] ?: 0.0; val lv = RecapAnalytics.levelOf(v, cut)
                        val x = lx + c.week * (cs + gp); val y = ty + c.row * (cs + gp)
                        val col = if (lv > 0) acc.copy(alpha = op[lv]) else line.copy(alpha = if (c.date.isAfter(today)) .35f else .9f)
                        drawRoundRect(col, Offset(x, y), Size(cs, cs), CornerRadius(2.5f.dp.toPx()))
                        if (c.date == pickDate) drawRoundRect(acc, Offset(x, y), Size(cs, cs), CornerRadius(2.5f.dp.toPx()), style = Stroke(1.5f.dp.toPx()))
                        val mo = c.date.monthValue - 1
                        if (c.date.dayOfMonth <= 7 && mo != lastMo && c.row == 0) { lastMo = mo; drawText(tm.measure(monShort(mo + 1), tick), topLeft = Offset(x, 0f)) }
                    }
                    listOf(0, 2, 4).forEach { r -> drawText(tm.measure(DOW_ID[r], tick), topLeft = Offset(0f, ty + r * (cs + gp))) }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Sedikit", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                op.forEachIndexed { i, o -> Box(Modifier.size(10.dp).clip(RoundedCornerShape(2.dp)).background(if (i == 0) line.copy(alpha = .9f) else acc.copy(alpha = o))) }
                Text("Banyak", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            val pd = pickDate
            if (pd != null) {
                val o = dm[pd]; val ld = loadByDate[pd] ?: 0.0
                RcMuted("${pd.dayOfMonth} ${monShort(pd.monthValue)} ${pd.year} · " + (if (o != null) "${fkm(o.km)} km · ${durHm(o.min)}" + (if (o.gain > 0) " · ${Js.idn(Js.roundI(o.gain))} m" else "") else "tidak lari") + (if (ld > 0) " · load ${Js.idn(Js.roundI(ld))}" else ""))
            } else {
                RcMuted(if (best != null) "Hari terbaik: ${best.key.dayOfMonth} ${monShort(best.key.monthValue)} · " + (if (useLoad) "${Js.idn(Js.roundI(best.value))} load" else "${fkm(Math.round(best.value * 10) / 10.0)} km") else "Belum ada data di tahun ini.")
            }
        })
}
