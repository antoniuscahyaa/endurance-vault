package com.endurancevault.app.ui.screens

import android.graphics.Bitmap
import android.graphics.Canvas
import android.media.MediaPlayer
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.domain.ActDetail
import com.endurancevault.app.domain.HudPrefs
import com.endurancevault.app.domain.RouteVideoText
import com.endurancevault.app.domain.RouteVideoTrack
import com.endurancevault.app.domain.VideoHud
import com.endurancevault.app.ui.UiState
import com.endurancevault.app.ui.i18n.Text
import com.endurancevault.app.ui.sticker.StickerFontStore
import com.endurancevault.app.ui.sticker.StickerFonts
import com.endurancevault.app.ui.sticker.StickerPrefsStore
import com.endurancevault.app.ui.video.HudEncoder
import com.endurancevault.app.ui.video.HudPainter
import com.endurancevault.app.ui.video.HudPrefsStore
import com.endurancevault.app.ui.video.HudSourceInfo
import com.endurancevault.app.ui.video.HudVideoIo
import com.endurancevault.app.ui.video.RouteVideoIo
import com.endurancevault.app.ui.video.RouteVideoJobs
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Video HUD: pilih video POV dari galeri, sinkronkan waktunya dengan lari (offset detik), lalu tempel data lari yang bergerak
 * (HR, jarak, pace, waktu, elevasi, kemiringan, kecepatan, minimap rute) di atasnya. Suara asli (AAC) ikut. Render di latar belakang.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HudVideoScreen(state: UiState, id: Long, load: suspend (ActivityEntity) -> ActDetail?, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val appCtx = ctx.applicationContext
    val scope = rememberCoroutineScope()
    val store = remember { HudPrefsStore(appCtx) }
    var prefs by remember { mutableStateOf(store.load()) }
    fun update(p: HudPrefs) { prefs = p.sanitized(); store.save(prefs) }
    var bgRender by remember { mutableStateOf(true) }

    val stk = remember { StickerPrefsStore(appCtx).load() }
    val fontStore = remember { StickerFontStore(appCtx) }
    val fonts = remember(stk.fontNum, stk.fontBody) { StickerFonts(fontStore.typeface(stk.fontNum), fontStore.typeface(stk.fontBody)) }

    var uri by remember { mutableStateOf<Uri?>(null) }
    var info by remember { mutableStateOf<HudSourceInfo?>(null) }
    var videoName by remember { mutableStateOf("") }
    var offset by remember { mutableIntStateOf(0) }
    val zoom = remember { PreviewZoom() }
    var tPos by remember { mutableStateOf(0f) }
    var note by remember { mutableStateOf("") }
    var probing by remember { mutableStateOf(false) }
    // Pratinjau hidup: video asli diputar lewat VideoView (muted bawaan) dan HUD digambar ulang tiap bingkai di atasnya sesuai
    // posisi putar. Saat dijeda, kembali ke bingkai diam + slider seperti biasa.
    var playing by remember { mutableStateOf(false) }
    var vReady by remember { mutableStateOf(false) }
    var liveT by remember { mutableStateOf(0f) }
    var overlay by remember { mutableStateOf<Bitmap?>(null) }
    var liveErr by remember { mutableStateOf<String?>(null) }
    var sound by remember { mutableStateOf(false) }
    val player = remember { HudPlayerHolder() }

    val e = state.activities.firstOrNull { it.id == id }
    fun nameOf(a: ActivityEntity) = a.name.ifBlank { if (a.type == "bike") "Gowes" else "Lari" }

    val loaded by produceState<Pair<Boolean, ActDetail?>>(false to null, e?.id, e?.detailFile, e?.km, e?.durationSec, e?.type) {
        value = true to e?.let { load(it) }
    }
    val detail = loaded.second
    val track = remember(detail, e?.name) {
        if (e != null && detail != null) RouteVideoTrack.from(detail, nameOf(e), RouteVideoText.dateId(e.dateIso)) else null
    }
    val span = remember(detail) { detail?.let { VideoHud.span(it) } ?: 60 }
    val vmax = remember(track) { track?.let { VideoHud.vmax(it) } ?: 14.0 }
    val mini = remember(track) { track?.let { VideoHud.miniMap(it) } }

    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) scope.launch {
            probing = true; note = ""
            val r = withContext(Dispatchers.IO) { HudVideoIo.probe(appCtx, u) }
            val inf = r.getOrNull()
            if (inf == null) { note = "Video tidak bisa dibuka: ${r.exceptionOrNull()?.message}"; probing = false; return@launch }
            val dur = inf.durationSec
            val start = detail?.startEpochMs ?: 0L
            val guess = withContext(Dispatchers.IO) {
                val created = HudVideoIo.createdMs(appCtx, u)
                var g = created?.let { VideoHud.guessOffset(start, it + (dur * 1000).toLong(), dur, span) }
                if (g == null) g = HudVideoIo.modifiedMs(appCtx, u)?.let { VideoHud.guessOffset(start, it, dur, span) }
                g
            }
            playing = false; vReady = false
            uri = u; info = inf; videoName = HudVideoIo.displayName(appCtx, u)
            offset = guess ?: 0; tPos = 0f
            note = if (guess != null) "Offset ditebak dari jam rekam video. Cocokkan di pratinjau dan geser bila meleset."
            else "Jam rekam video tidak cocok dengan jam lari. Atur offset secara manual."
            probing = false
        }
    }

    val myKey = "hud-$id"
    val bgRef = rememberUpdatedState(bgRender)
    DisposableEffect(Unit) { onDispose { if (!bgRef.value) RouteVideoJobs.cancelFor(myKey) } }

    val frame by produceState<Bitmap?>(null, uri, info, tPos, offset, prefs, track, playing) {
        if (playing) return@produceState // saat memutar, video asli yang tampil
        val u = uri; val inf = info; val t = track; val mp = mini
        if (u == null || inf == null || t == null || mp == null) { value = null; return@produceState }
        delay(120)
        value = withContext(Dispatchers.IO) {
            val raw = HudVideoIo.frameAt(appCtx, u, tPos.toDouble(), 720) ?: return@withContext null
            val bmp = raw.copy(Bitmap.Config.ARGB_8888, true)
            if (bmp !== raw) raw.recycle()
            val painter = HudPainter(bmp.width, bmp.height, prefs, mp, fonts)
            val st = VideoHud.stateAt(t, tPos.toDouble(), offset)
            painter.draw(Canvas(bmp), VideoHud.values(t, st, vmax))
            bmp
        }
    }

    val startRender = {
        val a = e; val u = uri; val inf = info; val t = track
        if (a != null && u != null && inf != null && t != null) {
            RouteVideoJobs.clearResult()
            val out = File(RouteVideoIo.cacheDir(appCtx), "hud-${a.dateIso.take(10)}-${a.id}.mp4")
            val snap = prefs; val off = offset
            val started = RouteVideoJobs.startTask(appCtx, myKey, nameOf(a), out, bgRender) { active, prog ->
                HudEncoder.encode(appCtx, u, inf, t, snap, off, fonts, out, active, prog)
            }
            note = if (started) "" else "Masih ada render lain yang berjalan."
        }
    }

    val prefsRef = rememberUpdatedState(prefs)
    val offsetRef = rememberUpdatedState(offset)
    val fontsRef = rememberUpdatedState(fonts)
    val maxTime = remember(info) { info?.let { min(it.durationSec, VideoHud.MAX_SEC.toDouble()) } ?: 0.0 }
    // Setelah jeda, bingkai diam lama (posisi sebelum memutar) tidak ditampilkan; spinner sampai bingkai di posisi jeda siap.
    var settleFrom by remember { mutableStateOf<Bitmap?>(null) }
    fun pause() {
        settleFrom = frame
        val t = player.view?.currentPosition?.div(1000f) ?: liveT
        tPos = t.coerceIn(0f, maxTime.toFloat().coerceAtLeast(1f))
        player.view?.pause()
        playing = false; vReady = false
    }
    // Gambar HUD di atas video yang sedang diputar: posisi diambil dari VideoView, nilai dihitung seperti di render akhir.
    LaunchedEffect(playing, vReady) {
        val t = track; val mp = mini; val inf0 = info
        if (!playing || !vReady || t == null || mp == null || inf0 == null) return@LaunchedEffect
        val scale = min(1f, 720f / max(inf0.dispW, inf0.dispH))
        val w = (inf0.dispW * scale).roundToInt().coerceAtLeast(2); val h = (inf0.dispH * scale).roundToInt().coerceAtLeast(2)
        val bufs = Array(3) { Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888) }
        var n = 0
        var painter: HudPainter? = null; var painterPrefs: HudPrefs? = null
        while (isActive) {
            val vv = player.view ?: break
            val sec = vv.currentPosition / 1000.0
            if (maxTime > 0 && sec >= maxTime) { vv.seekTo(0); withFrameNanos { }; continue }
            val p = prefsRef.value
            val cur: HudPainter
            val old = painter
            if (old != null && painterPrefs === p) cur = old
            else { cur = HudPainter(w, h, p, mp, fontsRef.value); painter = cur; painterPrefs = p }
            val buf = bufs[n % bufs.size]; n++
            val off = offsetRef.value
            withContext(Dispatchers.Default) {
                buf.eraseColor(0)
                val st = VideoHud.stateAt(t, sec, off)
                cur.draw(Canvas(buf), VideoHud.values(t, st, vmax))
            }
            overlay = buf; liveT = sec.toFloat()
            withFrameNanos { }
        }
    }
    PauseOnBackground { if (playing) pause() }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton(onClick = onBack) { Text("‹ Kembali") }
            Text("Video HUD", style = MaterialTheme.typography.titleMedium)
        }
        if (e == null) { Text("Aktivitas tidak ditemukan."); return@Column }
        if (!loaded.first) { CircularProgressIndicator(Modifier.size(24.dp)); return@Column }
        if (track == null) {
            Text("Video HUD butuh rute GPS dan data per detik. Aktivitas ini tidak punya keduanya (mis. latihan indoor atau data lama).")
            return@Column
        }
        val inf = info
        if (uri == null || inf == null) {
            Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    "Pilih video dari galeri (mis. rekaman kamera aksi atau ponsel saat lari). Data lari akan ditempel di atasnya dan bergerak " +
                        "mengikuti waktu rekaman. Maksimal ${VideoHud.MAX_SEC / 60} menit pertama yang diproses.",
                    style = MaterialTheme.typography.bodyMedium,
                )
                if (probing) CircularProgressIndicator(Modifier.size(24.dp))
                else OutlinedButton(onClick = { pickVideo.launch("video/*") }) { Text("Pilih video") }
                if (note.isNotEmpty()) VuNote(note)
            }
            return@Column
        }

        BoxWithConstraints(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            val ratio = (inf.dispW.toFloat() / inf.dispH).coerceIn(0.4f, 2.5f)
            val maxH = (LocalConfiguration.current.screenHeightDp * 0.38f).dp
            val w = minOf(maxWidth, maxH * ratio)
            ZoomablePreview(zoom, Modifier.width(w).aspectRatio(ratio)) {
                val u = uri
                if (playing && u != null) {
                    val startMs = remember(u) { (tPos * 1000).toInt() }
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        update = { v -> zoom.applyTo(v) },
                        factory = { c ->
                            android.widget.VideoView(c).apply {
                                player.view = this
                                setVideoURI(u)
                                setOnPreparedListener { mp ->
                                    player.mp = mp
                                    val vol = if (sound) 1f else 0f
                                    mp.setVolume(vol, vol)
                                    if (startMs > 0) seekTo(startMs)
                                    start(); vReady = true
                                }
                                setOnCompletionListener { seekTo(0); start() }
                                setOnErrorListener { _, _, _ ->
                                    liveErr = "Video tidak bisa diputar di pratinjau. Bingkai diam tetap bisa dipakai."
                                    playing = false; vReady = false
                                    true
                                }
                            }
                        },
                        onRelease = { v -> runCatching { v.stopPlayback() }; player.view = null; player.mp = null },
                    )
                }
                val b = frame
                // Bingkai diam menutupi VideoView sampai video siap (kalau tidak, sempat hitam).
                if (!playing || !vReady) {
                    if (b == null || b === settleFrom) CircularProgressIndicator(Modifier.size(28.dp))
                    else Image(b.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxSize().previewZoomLayer(zoom), contentScale = ContentScale.Fit)
                }
                val ov = overlay
                if (playing && vReady && ov != null) {
                    Image(ov.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxSize().previewZoomLayer(zoom), contentScale = ContentScale.FillBounds)
                }
            }
        }
        val maxT = maxTime.toFloat().coerceAtLeast(1f)
        val shownT = (if (playing) liveT else tPos).coerceIn(0f, maxT)
        PreviewControls(
            "Posisi pratinjau", shownT, 0f..maxT, "${shownT.roundToInt()} dtk", playing,
            onToggle = {
                if (playing) pause()
                else { if (tPos >= maxT - 0.5f) tPos = 0f; liveT = tPos; liveErr = null; vReady = false; settleFrom = null; playing = true }
            },
            onSeek = { tPos = it; liveT = it; if (playing) player.view?.seekTo((it * 1000).toInt()) },
        )
        liveErr?.let { VuNote(it) }

        EditorPager(listOf(
            EditorTab("Sinkron") {
            if (note.isNotEmpty()) VuInfo(note)
            if (inf.durationSec > VideoHud.MAX_SEC) VuNote("Video ${(inf.durationSec / 60).roundToInt()} menit. Hanya ${VideoHud.MAX_SEC / 60} menit pertama yang diproses.")
            VuSection("Video", "$videoName · ${inf.dispW}×${inf.dispH} · ${inf.durationSec.roundToInt()} dtk") {
                OutlinedButton(onClick = { pickVideo.launch("video/*") }) { Text("Ganti video") }
            }

            VuSection("Sinkron waktu", "Detik sejak lari dimulai pada awal video. Geser sampai angka HUD cocok dengan yang terjadi di video.") {
                val range = VideoHud.offsetRange(span)
                VuSlider("Offset", offset.toFloat(), range.first.toFloat()..range.last.toFloat(), "${offset} dtk") { offset = it.roundToInt() }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { offset = (offset - 10).coerceIn(range) }) { Text("−10") }
                    OutlinedButton(onClick = { offset = (offset - 1).coerceIn(range) }) { Text("−1") }
                    OutlinedButton(onClick = { offset = (offset + 1).coerceIn(range) }) { Text("+1") }
                    OutlinedButton(onClick = { offset = (offset + 10).coerceIn(range) }) { Text("+10") }
                }
            }

            },
            EditorTab("Tampilan") {
            VuSection("Tampilan HUD", "Dua gaya, minimap rute, gauge kecepatan, dan peredam gelap.") {
                VuChips(listOf("two" to "Dua kolom", "min" to "Minimal"), prefs.style) { update(prefs.copy(style = it)) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    VuToggle("Minimap", prefs.minimap) { update(prefs.copy(minimap = it)) }
                    if (prefs.style == "two") VuToggle("Gauge kecepatan", prefs.gauge) { update(prefs.copy(gauge = it)) }
                }
                VuColorPick("Warna aksen", prefs.accent, HudPrefs.ACCENTS, null) { update(prefs.copy(accent = it)) }
                VuSlider("Peredam gelap", prefs.dim.toFloat(), 0f..60f, "${prefs.dim}%") { update(prefs.copy(dim = it.roundToInt())) }
            }

            VuSection("Suara", null) {
                VuToggle("Bawa suara asli video", prefs.audio) { update(prefs.copy(audio = it)) }
                VuToggle("Dengar suara di pratinjau", sound) { on ->
                    sound = on
                    val vol = if (on) 1f else 0f
                    runCatching { player.mp?.setVolume(vol, vol) }
                }
                if (!inf.hasAudio) VuInfo("Video ini tidak punya suara.")
                else if (!inf.audioAac) VuInfo("Suara video ini bukan AAC, jadi tidak bisa dibawa tanpa di-encode ulang. Video hasil akan tanpa suara.")
            }
            },
            EditorTab("Buat video") {
            VideoRenderPanel(myKey, "Buat video HUD", true, bgRender) { startRender() }
            if (note.isNotEmpty()) VuInfo(note)
            VuToggle("Lanjut di latar belakang (notifikasi)", bgRender) { bgRender = it }

            },
        ))
    }
}

/** Pegangan ke VideoView dan MediaPlayer pratinjau yang sedang hidup (bukan state Compose; hanya dibaca saat dibutuhkan). */
private class HudPlayerHolder {
    var view: android.widget.VideoView? = null
    var mp: MediaPlayer? = null
}
