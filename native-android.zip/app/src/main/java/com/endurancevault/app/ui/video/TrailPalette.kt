package com.endurancevault.app.ui.video

import android.graphics.Color

/** Palet warna video Trail 3D: untuk shader medan (float RGB) dan untuk gambar 2D (ARGB). */
class TrailPalette(
    val accent: Int,
    val low: FloatArray, val mid: FloatArray, val hi: FloatArray, val dk: FloatArray,
    val tn: FloatArray, val acc: FloatArray, val tc: FloatArray,
    val wt: FloatArray, val wb: FloatArray, val wh: FloatArray,
    val skyTop: Int, val skyMid: Int, val skyLow: Int, val sun: Int,
    val ranges: IntArray, val ink: Int, val inkDim: Int, val base: Int,
) {
    companion object {
        private fun rgb(r: Int, g: Int, b: Int) = floatArrayOf(r / 255f, g / 255f, b / 255f)
        private fun f(c: Int) = floatArrayOf(Color.red(c) / 255f, Color.green(c) / 255f, Color.blue(c) / 255f)
        private fun mix(a: FloatArray, b: FloatArray, t: Float) = FloatArray(3) { a[it] + (b[it] - a[it]) * t }
        private val WHITE = floatArrayOf(1f, 1f, 1f)

        fun of(name: String, accentHex: String): TrailPalette {
            val lime = name == "lime"
            val baseAcc = if (lime) 0xFFCBFD00.toInt() else 0xFFFF6A13.toInt()
            val accent = if (accentHex.length == 7) runCatching { Color.parseColor(accentHex) }.getOrDefault(baseAcc) else baseAcc
            val a = f(accent)
            return if (lime) TrailPalette(
                accent, rgb(18, 28, 20), rgb(40, 72, 31), rgb(140, 198, 52), rgb(8, 13, 10),
                mix(a, WHITE, .1f), a, mix(a, WHITE, .35f),
                rgb(36, 66, 31), rgb(10, 20, 13), a,
                0xFF0A1410.toInt(), 0xFF16301C.toInt(), 0xFF4F7A1C.toInt(), 0xFFD8FF4A.toInt(),
                intArrayOf(0xFF1B3A22.toInt(), 0xFF112619.toInt(), 0xFF0A180F.toInt()),
                0xFFF4FFE2.toInt(), 0xB3E4F5C8.toInt(), 0xFF0A1410.toInt(),
            ) else TrailPalette(
                accent, rgb(40, 27, 22), rgb(92, 56, 38), rgb(204, 120, 61), rgb(18, 12, 12),
                mix(a, WHITE, .1f), a, mix(a, WHITE, .35f),
                rgb(77, 51, 38), rgb(23, 15, 13), a,
                0xFF150C10.toInt(), 0xFF5A2418.toInt(), 0xFFB5521F.toInt(), 0xFFFFC27A.toInt(),
                intArrayOf(0xFF4A2019.toInt(), 0xFF2C1311.toInt(), 0xFF170A0B.toInt()),
                0xFFFFF4EA.toInt(), 0xB3FFE9D6.toInt(), 0xFF14100E.toInt(),
            )
        }
    }
}
