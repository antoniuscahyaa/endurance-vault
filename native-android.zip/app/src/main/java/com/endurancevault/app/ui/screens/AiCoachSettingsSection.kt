package com.endurancevault.app.ui.screens

import com.endurancevault.app.ui.i18n.Text
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

/** Pengaturan AI Coach (Pengaturan → AI Coach): API key Groq dan pilihan model, dalam kartu sendiri terpisah dari cuaca. */
@Composable
internal fun AiCoachSettingsSection(
    aiStatus: String,
    onAiKey: (String) -> Unit,
    aiModel: String,
    aiModels: List<Pair<String, String>>,
    onAiModel: (String) -> Unit,
) {
    var key by remember { mutableStateOf("") }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("AI Coach · Online", style = MaterialTheme.typography.titleLarge)
        Text(
            "Chat ada di tombol melayang pada halaman Beranda. Ringkasan latihan yang relevan dikirim ke Groq hanya saat kamu menekan Kirim di chat. API key dienkripsi dengan Android Keystore dan tidak masuk backup.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        EvPanel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("API key", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(key, { key = it }, label = { Text("Groq API key") }, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation())
                OutlinedButton(onClick = { onAiKey(key) }) { Text("Simpan API key") }
                Text(aiStatus, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (aiModels.isNotEmpty()) {
            EvPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    var menuOpen by remember { mutableStateOf(false) }
                    Text("Model AI Coach", style = MaterialTheme.typography.titleMedium)
                    Box(Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { menuOpen = true }, modifier = Modifier.fillMaxWidth()) {
                            androidx.compose.material3.Text(aiModels.firstOrNull { it.first == aiModel }?.second ?: aiModel, modifier = Modifier.weight(1f))
                            Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            aiModels.forEach { (id, label) ->
                                DropdownMenuItem(
                                    text = { androidx.compose.material3.Text(label) },
                                    onClick = { onAiModel(id); menuOpen = false },
                                    trailingIcon = { if (id == aiModel) Icon(Icons.Filled.Check, contentDescription = null) },
                                )
                            }
                        }
                    }
                    Text(
                        "Bila limit model tercapai, tombol refresh muncul di chat untuk pindah ke model berikutnya.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}
