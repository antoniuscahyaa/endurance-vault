package com.endurancevault.app.ui.video

import android.graphics.Bitmap
import android.graphics.Matrix as GMatrix
import android.opengl.GLES20
import android.opengl.GLUtils
import android.opengl.Matrix
import com.endurancevault.app.data.TerrainScene
import com.endurancevault.app.domain.TrailBox
import com.endurancevault.app.domain.TrailCam
import com.endurancevault.app.domain.TrailCircle
import com.endurancevault.app.domain.TrailPrefs
import com.endurancevault.app.domain.TrailGeo
import com.endurancevault.app.domain.TrailLay
import com.endurancevault.app.domain.TrailKeys
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * Medan untuk slab Trail: grid elevasi terhaluskan, bentuk (lingkaran atau poligon) yang melingkupi rute, rute dalam
 * koordinat lokal (meter relatif pusat cakram), dan skala tinggi (eksagerasi) supaya relief setinggi persentase diameter.
 */
class TrailScene(
    val src: TerrainScene, val sides: Int, reliefPct: Int,
    /** Luas cakupan base (persen; 100 = pas rute), dan geser X/Z (persen -100..100 dari ruang gerak). Lihat [TrailPrefs]. */
    coveragePct: Int = 114, offXPct: Int = 0, offZPct: Int = 0,
    /** Ratakan tepi base (persen 0..100); lihat [TrailPrefs.flatEdge]. */
    flatEdgePct: Int = 0,
    /** Dinding tegak sampai dasar rata (blok) bila true; lihat [TrailPrefs.blockCut]. */
    val blockCut: Boolean = false,
) {
    private val n = src.n
    private val smooth: FloatArray = smoothTwice(src.heights, n)
    private val grid: FloatArray

    /** Pusat cakram (koordinat medan) dan apotema (m): rute selalu di dalam bentuk. */
    val cx: Float; val cz: Float; val apothem: Float

    /** Tinggi terendah dan tertinggi (m) di dalam bentuk. */
    val lo: Float; val hi: Float

    /** Pengali tinggi (eksagerasi) dan tinggi puncak relief (satuan dunia). */
    val ex: Float; val reliefTop: Float

    /** Rute lokal: x, z (m relatif pusat), tinggi dunia y, dan bagian jarak. */
    val rx: FloatArray; val rz: FloatArray; val ry: FloatArray; val rf: FloatArray

    /** Interval kontur halus dan tebal (m). */
    val fine: Float; val major: Float

    init {
        val c: TrailCircle = TrailGeo.circle(src.routeX, src.routeZ)
        val maxR = src.sizeM * 0.49f
        val room = (maxR - hypot(c.x, c.y)).coerceAtLeast(src.sizeM * 0.05f)
        // Jari-jari pas rute (tanpa margin 14% milik TrailGeo.circle); cakupan 100% = pas, bawaan 114% = perilaku lama.
        val tight = c.r / 1.14f
        val a = min(tight * coveragePct.coerceIn(TrailPrefs.MIN_COVERAGE, TrailPrefs.MAX_COVERAGE) / 100f, room)
        apothem = a
        // Geser: lingkaran pas rute harus tetap seluruhnya di dalam bentuk, dan bentuk tetap di dalam grid medan.
        val free = (a - tight).coerceAtLeast(0f)
        var dx = offXPct.coerceIn(-100, 100) / 100f * free
        var dz = offZPct.coerceIn(-100, 100) / 100f * free
        val mag = hypot(dx, dz)
        if (mag > free && mag > 1e-6f) { dx *= free / mag; dz *= free / mag }
        var k = 1f
        var tries = 0
        while (tries < 14 && hypot(c.x + dx * k, c.y + dz * k) > maxR - a) { k *= 0.8f; tries++ }
        if (tries >= 14) k = 0f
        cx = c.x + dx * k; cz = c.y + dz * k
        // Ratakan tepi: dekat tepi bentuk, tinggi dicampur ke tinggi rata-rata tepi supaya bibir dan dinding slab tidak bergelombang.
        val flat = flatEdgePct.coerceIn(0, 100) / 100f
        grid = if (flat <= 0f) smooth else flattenEdge(flat)
        var l = Float.MAX_VALUE; var h = -Float.MAX_VALUE
        val step = max(1, n / 80)
        var j = 0
        while (j < n) {
            var i = 0
            while (i < n) {
                val x = (i.toFloat() / (n - 1) - .5f) * src.sizeM - cx
                val z = (j.toFloat() / (n - 1) - .5f) * src.sizeM - cz
                if (TrailGeo.metric(sides, x.toDouble(), z.toDouble()) <= apothem) {
                    val v = grid[j * n + i]
                    if (v < l) l = v
                    if (v > h) h = v
                }
                i += step
            }
            j += step
        }
        if (l > h) { l = grid.minOrNull() ?: 0f; h = grid.maxOrNull() ?: 0f }
        lo = l; hi = h
        val hm = max(hi - lo, 0.5f)
        val dM = 2f * apothem
        ex = (reliefPct / 100f * dM / hm).coerceIn(1f, 14f)
        reliefTop = hm * ex
        fine = TrailGeo.nice(hm / 16.0).toFloat(); major = fine * 5
        val m = src.routeX.size
        rx = FloatArray(m) { src.routeX[it] - cx }
        rz = FloatArray(m) { src.routeZ[it] - cz }
        ry = FloatArray(m) { (heightAt(src.routeX[it], src.routeZ[it]) - lo) * ex }
        rf = src.routeFrac.copyOf()
    }

    /** Tinggi terhaluskan (m) di koordinat medan (x, z), bilinear. */
    fun heightAt(x: Float, z: Float): Float = sampleGrid(grid, x, z)

    private fun sampleGrid(g: FloatArray, x: Float, z: Float): Float {
        val fx = ((x / src.sizeM + .5f) * (n - 1)).coerceIn(0f, n - 1f)
        val fz = ((z / src.sizeM + .5f) * (n - 1)).coerceIn(0f, n - 1f)
        val i0 = fx.toInt().coerceAtMost(n - 2); val j0 = fz.toInt().coerceAtMost(n - 2)
        val tx = fx - i0; val tz = fz - j0
        val a = g[j0 * n + i0]; val b = g[j0 * n + i0 + 1]
        val c = g[(j0 + 1) * n + i0]; val d = g[(j0 + 1) * n + i0 + 1]
        return (a * (1 - tx) + b * tx) * (1 - tz) + (c * (1 - tx) + d * tx) * tz
    }

    /**
     * Salinan [smooth] dengan tepi diratakan sebesar [flat] (0..1). Tinggi acuan = rata-rata tinggi sepanjang tepi bentuk.
     * Zona perataan mulai di jari-jari relatif [start] (di luar rute bila bisa) sampai tepi (1), dengan peralihan halus.
     */
    private fun flattenEdge(flat: Float): FloatArray {
        val a = apothem
        var ref = 0f
        val rimN = 96
        for (q in 0 until rimN) {
            val th = q * 2.0 * Math.PI / rimN
            val rho = a * TrailGeo.edgeR(sides, th).toFloat()
            ref += sampleGrid(smooth, cx + (rho * Math.cos(th)).toFloat(), cz + (rho * Math.sin(th)).toFloat())
        }
        ref /= rimN
        var routeMax = 0f
        for (q in src.routeX.indices) {
            val r = (TrailGeo.metric(sides, (src.routeX[q] - cx).toDouble(), (src.routeZ[q] - cz).toDouble()) / a).toFloat()
            if (r > routeMax) routeMax = r
        }
        val start = (routeMax + 0.02f).coerceIn(0.5f, 0.92f)
        val out = FloatArray(smooth.size)
        for (j in 0 until n) for (i in 0 until n) {
            val x = (i.toFloat() / (n - 1) - .5f) * src.sizeM - cx
            val z = (j.toFloat() / (n - 1) - .5f) * src.sizeM - cz
            val r = (TrailGeo.metric(sides, x.toDouble(), z.toDouble()) / a).toFloat()
            val u = ((r - start) / (1f - start)).coerceIn(0f, 1f)
            val t = u * u * (3f - 2f * u) * flat
            val h = smooth[j * n + i]
            out[j * n + i] = h + (ref - h) * t
        }
        return out
    }

    /** Posisi (x, y dunia, z) pada bagian jarak [f]. */
    fun locate(f: Float): FloatArray {
        val m = rf.size
        val q = f.coerceIn(0f, 1f)
        var a = 0; var b = m - 1
        while (a < b) { val mid = (a + b) ushr 1; if (rf[mid] >= q) b = mid else a = mid + 1 }
        if (a == 0) return floatArrayOf(rx[0], ry[0], rz[0])
        val f0 = rf[a - 1]; val f1 = rf[a]
        val t = if (f1 > f0) ((q - f0) / (f1 - f0)).coerceIn(0f, 1f) else 0f
        return floatArrayOf(rx[a - 1] + (rx[a] - rx[a - 1]) * t, ry[a - 1] + (ry[a] - ry[a - 1]) * t, rz[a - 1] + (rz[a] - rz[a - 1]) * t)
    }

    /** Banyak titik rute yang sudah dilewati pada bagian jarak [f] (indeks pertama dengan rf >= f). */
    fun doneCount(f: Float): Int {
        val q = f.coerceIn(0f, 1f)
        var a = 0; var b = rf.size - 1
        while (a < b) { val mid = (a + b) ushr 1; if (rf[mid] >= q) b = mid else a = mid + 1 }
        return if (q <= 0f) 0 else if (q >= 1f) rf.size else a
    }

    /** Tinggi dunia (satuan tinggi * ex) di koordinat lokal (x, z). */
    fun worldY(lx: Float, lz: Float): Float = (heightAt(cx + lx, cz + lz) - lo) * ex

    companion object {
        /** Dua kali rata-rata kotak 3x3 supaya relief tampak mulus tanpa terasering DEM. */
        fun smoothTwice(src: FloatArray, n: Int): FloatArray {
            var a = src.copyOf()
            repeat(2) {
                val b = FloatArray(a.size)
                for (j in 0 until n) for (i in 0 until n) {
                    var s = 0f; var c = 0
                    for (dj in -1..1) for (di in -1..1) {
                        val ii = i + di; val jj = j + dj
                        if (ii in 0 until n && jj in 0 until n) { s += a[jj * n + ii]; c++ }
                    }
                    b[j * n + i] = s / c
                }
                a = b
            }
            return a
        }
    }
}

private fun tfBuf(n: Int): FloatBuffer = ByteBuffer.allocateDirect(n * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
private fun tfBuf(a: FloatArray): FloatBuffer = tfBuf(a.size).also { it.put(a); it.position(0) }

private fun tfCompile(type: Int, src: String): Int {
    val s = GLES20.glCreateShader(type)
    GLES20.glShaderSource(s, src); GLES20.glCompileShader(s)
    val ok = IntArray(1); GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
    check(ok[0] != 0) { "Shader Trail gagal dikompilasi: ${GLES20.glGetShaderInfoLog(s)}" }
    return s
}

private fun tfProgram(vs: String, fs: String): Int {
    val p = GLES20.glCreateProgram()
    GLES20.glAttachShader(p, tfCompile(GLES20.GL_VERTEX_SHADER, vs)); GLES20.glAttachShader(p, tfCompile(GLES20.GL_FRAGMENT_SHADER, fs))
    GLES20.glLinkProgram(p)
    val ok = IntArray(1); GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
    check(ok[0] != 0) { "Program Trail gagal ditautkan: ${GLES20.glGetProgramInfoLog(p)}" }
    return p
}

/**
 * Penggambar video Trail 3D di satu konteks GL (pbuffer untuk pratinjau, Surface MediaCodec untuk render). Urutan tiap bingkai:
 * lapisan statis (langit, gunung, judul) -> grafik elevasi -> slab medan 3D di kotak adegan -> lapisan atas (label, penanda, data).
 * Semua pemanggilan harus dari satu thread yang memegang konteks.
 */
class TrailGl(private val W: Int, private val H: Int) {
    private var pTerrain = 0; private var pWall = 0; private var pRibbon = 0; private var pQuad = 0
    private val tex = IntArray(3)   // 0 statis, 1 grafik, 2 lapisan atas
    private val texW = IntArray(3); private val texH = IntArray(3)

    private var ts: TrailScene? = null
    private var lay: TrailLay? = null
    private var pal: TrailPalette? = null
    private var terrPos: FloatBuffer? = null; private var terrG: FloatBuffer? = null
    private var terrIdx: ShortBuffer? = null; private var terrIdxCount = 0
    private var wallPos: FloatBuffer? = null; private var wallG: FloatBuffer? = null; private var wallCount = 0
    private var rim: FloatArray = FloatArray(0)
    private var wallDepth = 0f

    private val quad = tfBuf(floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f, 1f, 1f))
    private val ribBuf = tfBuf(1800 * 6)
    private val ribTmp = FloatArray(1800 * 6)

    // Kamera tetap (zoom dan geser dihitung sekali untuk semua sudut putar), sudut putar berubah per bingkai.
    private var dist = 1f; private var ndcShift = 0f; private var mpp = 1f
    private val fov = 22f

    // Kamera dinamis per bingkai (zoom, tambahan kemiringan, ikuti pelari); bawaan = tampilan pas seperti sebelumnya.
    private var camZoom = 1f; private var camTiltD = 0f; private var camFollow = 0f
    private var camFocus = floatArrayOf(0f, 0f, 0f)
    /** Meter per piksel pada zoom saat ini (lebar garis, kontur, dan jarak label ikut zoom). */
    private var mppNow = 1f

    fun init() {
        pTerrain = tfProgram(
            """
            uniform mat4 uMvp;
            attribute vec3 aP; attribute vec2 aG;
            varying vec3 vP; varying vec2 vG; varying float vY;
            void main() { vP = aP; vG = aG; vY = aP.y; gl_Position = uMvp * vec4(aP, 1.0); }
            """.trimIndent(),
            """
            #ifdef GL_FRAGMENT_PRECISION_HIGH
            precision highp float;
            #else
            precision mediump float;
            #endif
            uniform float uA; uniform float uN; uniform float uEx; uniform float uHm; uniform float uFine; uniform float uPx;
            uniform vec3 uL; uniform vec3 uLow; uniform vec3 uMid; uniform vec3 uHi; uniform vec3 uDk; uniform vec3 uTn;
            uniform vec3 uAcc; uniform vec3 uTc;
            varying vec3 vP; varying vec2 vG; varying float vY;
            void main() {
              float m;
              if (uN < 0.5) { m = length(vP.xz); }
              else {
                m = -1.0e9;
                for (int i = 0; i < 8; i++) {
                  if (float(i) >= uN) break;
                  float a = float(i) * 6.2831853 / uN;
                  m = max(m, dot(vP.xz, vec2(cos(a), sin(a))));
                }
              }
              if (m > uA) discard;
              float r = m / uA;
              float hm = vY / uEx;
              float t = clamp(hm / uHm, 0.0, 1.0);
              vec3 n = normalize(vec3(-vG.x * uEx, 1.0, -vG.y * uEx));
              float lit = dot(n, uL);
              float fac = clamp((lit - uL.y) * 4.6, 0.0, 1.0);
              float shd = clamp((uL.y - lit) * 3.0, 0.0, 1.0);
              float sl = clamp(length(vG) * uEx - 0.1, 0.0, 2.0);
              vec3 col = mix(uLow, uMid, clamp(smoothstep(0.03, 0.55, sl) + t * 0.2, 0.0, 1.0));
              col = mix(col, uDk, shd * 0.6);
              col = mix(col, uHi, fac * smoothstep(0.08, 0.5, sl));
              col += uTn * pow(fac, 2.0) * 0.3 * smoothstep(0.2, 1.0, t + sl * 0.4);
              col += uAcc * 0.05 * smoothstep(0.2, 1.0, t);
              float rel = 0.3 + 0.7 * smoothstep(0.0, 0.25, sl + t);
              float g = length(vG);
              float f1 = hm / uFine;
              float w1 = max(uPx * g / uFine, 1.0e-4);
              float l1 = (1.0 - smoothstep(0.0, w1 * 1.3, abs(fract(f1 - 0.5) - 0.5))) * (1.0 - smoothstep(0.35, 0.9, w1));
              float f2 = f1 / 5.0;
              float w2 = max(w1 / 5.0, 1.0e-4);
              float l2 = (1.0 - smoothstep(0.0, w2 * 1.6, abs(fract(f2 - 0.5) - 0.5))) * (1.0 - smoothstep(0.35, 0.9, w2));
              col = mix(col, uTc, clamp((l1 * 0.16 + l2 * 0.30) * rel, 0.0, 0.5));
              col = mix(col, uTc, smoothstep(0.972, 1.0, r) * 0.5);
              gl_FragColor = vec4(col, 1.0);
            }
            """.trimIndent(),
        )
        pWall = tfProgram(
            """
            uniform mat4 uMvp; attribute vec3 aP; attribute vec2 aG; varying vec2 vG;
            void main() { vG = aG; gl_Position = uMvp * vec4(aP, 1.0); }
            """.trimIndent(),
            """
            precision mediump float;
            uniform vec3 uWt; uniform vec3 uWb; uniform vec3 uWh; uniform vec3 uL;
            varying vec2 vG;
            void main() {
              float a = vG.x * 6.2831853;
              float side = clamp(dot(vec2(cos(a), sin(a)), normalize(uL.xz)) * 0.5 + 0.5, 0.0, 1.0);
              vec3 col = mix(uWt, uWb, smoothstep(0.0, 1.0, vG.y));
              col *= mix(0.62, 1.12, side);
              col = mix(col, uWh, (1.0 - smoothstep(0.0, 0.1, vG.y)) * 0.5);
              gl_FragColor = vec4(col, 1.0);
            }
            """.trimIndent(),
        )
        pRibbon = tfProgram(
            "uniform mat4 uMvp; attribute vec3 aP; void main() { gl_Position = uMvp * vec4(aP, 1.0); }",
            "precision mediump float; uniform vec4 uColor; void main() { gl_FragColor = vec4(uColor.rgb * uColor.a, uColor.a); }",
        )
        pQuad = tfProgram(
            """
            uniform vec4 uR; attribute vec2 aUv; varying vec2 vUv;
            void main() { vUv = aUv; gl_Position = vec4(mix(uR.x, uR.z, aUv.x), mix(uR.y, uR.w, aUv.y), 0.0, 1.0); }
            """.trimIndent(),
            "precision mediump float; uniform sampler2D uTex; varying vec2 vUv; void main() { gl_FragColor = texture2D(uTex, vUv); }",
        )
        GLES20.glGenTextures(3, tex, 0)
    }

    /**
     * Siapkan slab: mesh, dinding, dan kamera tetap yang memuat bentuk pada semua sudut di [azimuths] (derajat) dan seluruh relief.
     * [lay] menentukan kotak adegan dan ukuran cakram; [tiltDeg] kemiringan dari atas.
     */
    fun prepare(scene: TrailScene, lay: TrailLay, tiltDeg: Int, palette: TrailPalette, azimuths: DoubleArray) {
        ts = scene; this.lay = lay; pal = palette
        val sides = scene.sides
        val a = scene.apothem
        val R = a * TrailGeo.outer(sides).toFloat()
        val m = 128
        val step = 2f * R / (m - 1)
        val hs = FloatArray(m * m)
        for (j in 0 until m) for (i in 0 until m) hs[j * m + i] = scene.heightAt(scene.cx - R + i * step, scene.cz - R + j * step)
        val pos = FloatArray(m * m * 3); val gr = FloatArray(m * m * 2)
        fun hAt(i: Int, j: Int) = hs[j.coerceIn(0, m - 1) * m + i.coerceIn(0, m - 1)]
        for (j in 0 until m) for (i in 0 until m) {
            val q = j * m + i
            pos[q * 3] = -R + i * step
            pos[q * 3 + 1] = (hs[q] - scene.lo) * scene.ex
            pos[q * 3 + 2] = -R + j * step
            gr[q * 2] = (hAt(i + 1, j) - hAt(i - 1, j)) / (2f * step)
            gr[q * 2 + 1] = (hAt(i, j + 1) - hAt(i, j - 1)) / (2f * step)
        }
        val ind = ShortArray((m - 1) * (m - 1) * 6)
        var k = 0
        for (j in 0 until m - 1) for (i in 0 until m - 1) {
            val p0 = (j * m + i).toShort(); val p1 = (j * m + i + 1).toShort()
            val p2 = ((j + 1) * m + i).toShort(); val p3 = ((j + 1) * m + i + 1).toShort()
            ind[k++] = p0; ind[k++] = p2; ind[k++] = p1
            ind[k++] = p1; ind[k++] = p2; ind[k++] = p3
        }
        terrPos = tfBuf(pos); terrG = tfBuf(gr)
        terrIdx = ByteBuffer.allocateDirect(ind.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer().also { it.put(ind); it.position(0) }
        terrIdxCount = ind.size

        // Kamera: jarak dasar agar lebar bentuk = diameter cakram di layout, lalu perkecil sampai semua sudut dan relief muat.
        val sw = lay.scene.w; val sh = lay.scene.h
        val f = (sh / 2f) / tan(Math.toRadians(fov / 2.0)).toFloat()
        val wallPx = lay.wall
        val base = 2f * a * sqrt(TrailGeo.outer(sides)).toFloat() * f / lay.d
        val rimN = 96
        rim = FloatArray(rimN * 2)
        for (i in 0 until rimN) {
            val th = i * 2.0 * PI / rimN
            val rho = a * TrailGeo.edgeR(sides, th).toFloat()
            rim[i * 2] = (rho * cos(th)).toFloat(); rim[i * 2 + 1] = (rho * sin(th)).toFloat()
        }
        val tilt = Math.toRadians(tiltDeg.toDouble())
        val elev = (PI / 2 - tilt)
        val pad = 0.035f * sw
        val bottomTarget = sh - 4f * lay.k
        val e = TrailEval(sw, sh, elev, fov)
        fun fits(g: Float): Triple<Boolean, Float, Float> {
            val dst = base / g
            val mppT = 2f * dst * tan(Math.toRadians(fov / 2.0)).toFloat() / sh
            val depth = wallPx * mppT / sin(tilt).toFloat().coerceAtLeast(0.2f)
            var maxBottom = -1e9f
            for (az in azimuths) for (i in 0 until rimN) {
                val p = e.px(rim[i * 2], -depth, rim[i * 2 + 1], az, dst)
                if (p[1] > maxBottom) maxBottom = p[1]
            }
            val dy = bottomTarget - maxBottom
            var ok = true
            for (az in azimuths) for (i in 0 until rimN) {
                val b = e.px(rim[i * 2], -depth, rim[i * 2 + 1], az, dst)
                val t = e.px(rim[i * 2], scene.reliefTop, rim[i * 2 + 1], az, dst)
                if (b[0] < pad || b[0] > sw - pad || t[0] < pad || t[0] > sw - pad) ok = false
                if (t[1] + dy < 2f * lay.k) ok = false
            }
            return Triple(ok, dy, depth)
        }
        var lo = 0.3f; var hi = 1.4f
        var best = fits(lo)
        var bestG = lo
        if (fits(hi).first) { bestG = hi; best = fits(hi) } else {
            repeat(18) {
                val mid = (lo + hi) / 2
                val r = fits(mid)
                if (r.first) { lo = mid; bestG = mid; best = r } else hi = mid
            }
        }
        dist = base / bestG
        mpp = 2f * dist * tan(Math.toRadians(fov / 2.0)).toFloat() / sh
        mppNow = mpp; camZoom = 1f; camTiltD = 0f; camFollow = 0f; camFocus = floatArrayOf(0f, 0f, 0f)
        ndcShift = -2f * best.second / sh
        wallDepth = best.third

        // Dinding: pita di sepanjang tepi bentuk. Biasa: tebal tetap di bawah tepi atas. Blok (blockCut): turun tegak ke dasar rata di y = -wallDepth.
        val wn = 360
        val wp = FloatArray((wn + 1) * 2 * 3); val wg = FloatArray((wn + 1) * 2 * 2)
        for (i in 0..wn) {
            val th = i * 2.0 * PI / wn
            val rho = a * TrailGeo.edgeR(sides, th).toFloat()
            val x = (rho * cos(th)).toFloat(); val z = (rho * sin(th)).toFloat()
            val y = scene.worldY(x, z)
            val sh01 = i.toFloat() / wn
            wp[i * 6] = x; wp[i * 6 + 1] = y; wp[i * 6 + 2] = z
            wp[i * 6 + 3] = x; wp[i * 6 + 4] = if (scene.blockCut) -wallDepth else y - wallDepth; wp[i * 6 + 5] = z
            wg[i * 4] = sh01; wg[i * 4 + 1] = 0f; wg[i * 4 + 2] = sh01; wg[i * 4 + 3] = 1f
        }
        wallPos = tfBuf(wp); wallG = tfBuf(wg); wallCount = (wn + 1) * 2
    }

    /** Proyeksi manual (sama dengan matriks GL) untuk uji muat dan penempatan label, tanpa konteks GL. */
    private class TrailEval(val sw: Float, val sh: Float, val elev: Double, val fov: Float) {
        /** Piksel (x, y ke bawah) di kotak adegan untuk titik lokal (x, y, z) pada sudut putar [azDeg] dan jarak [dist], tanpa geser. */
        fun px(x: Float, y: Float, z: Float, azDeg: Double, dist: Float): FloatArray {
            val az = Math.toRadians(azDeg)
            // Putar titik di sekitar sumbu y (kamera tetap di selatan), lalu proyeksikan dengan kamera miring.
            val rx = x * cos(az).toFloat() + z * sin(az).toFloat()
            val rz = -x * sin(az).toFloat() + z * cos(az).toFloat()
            val ce = cos(elev).toFloat(); val se = sin(elev).toFloat()
            // Kamera di (0, dist*se, dist*ce) menatap asal.
            val xc = rx
            val yc = y * ce - rz * se
            val zc = dist - (y * se + rz * ce)
            val f = (sh / 2f) / tan(Math.toRadians(fov / 2.0)).toFloat()
            val zz = max(zc, 1e-3f)
            return floatArrayOf(sw / 2f + xc * f / zz, sh / 2f - yc * f / zz)
        }
    }

    /**
     * Atur kamera untuk bingkai berikutnya: zoom (jarak kamera dibagi zoom), tambahan kemiringan, dan bobot ikuti pelari pada
     * bagian jarak [frac]. Panggil sebelum [project] dan [frame]; tanpa panggilan ini kamera tetap pas seperti bawaan.
     */
    fun setCamera(cam: TrailCam, frac: Float) {
        val s = ts ?: return
        camZoom = cam.zoom.toFloat().coerceIn(0.4f, 4f)
        camTiltD = cam.tiltDeg.toFloat()
        camFollow = cam.follow.toFloat().coerceIn(0f, 1f)
        camFocus = if (camFollow > 0f) s.locate(frac.coerceIn(0f, 1f)) else floatArrayOf(0f, 0f, 0f)
        mppNow = mpp / camZoom
    }

    /**
     * Matriks MVP untuk sudut putar [azDeg]; sama dengan [TrailEval] pada zoom 1 (kamera di selatan, cakram berputar).
     * Zoom mendekatkan kamera, tambahan kemiringan mengubah sudut, dan ikuti pelari menggeser titik pandang ke posisi pelari.
     */
    private fun mvp(azDeg: Double): FloatArray {
        val lay = lay!!
        val tiltDeg = (Math.toDegrees(lay.tiltRad) + camTiltD).coerceIn(5.0, 80.0)
        val elev = Math.toRadians(90.0 - tiltDeg).toFloat()
        val d = dist / camZoom
        val proj = FloatArray(16); val view = FloatArray(16); val model = FloatArray(16); val mv = FloatArray(16); val out = FloatArray(16)
        Matrix.perspectiveM(proj, 0, fov, lay.scene.w / lay.scene.h, min(d, dist) * 0.15f, max(d, dist) * 3f)
        Matrix.setLookAtM(view, 0, 0f, d * sin(elev), d * cos(elev), 0f, 0f, 0f, 0f, 1f, 0f)
        Matrix.setIdentityM(model, 0)
        Matrix.rotateM(model, 0, azDeg.toFloat(), 0f, 1f, 0f)
        if (camFollow > 0f) Matrix.translateM(model, 0, -camFollow * camFocus[0], -camFollow * camFocus[1], -camFollow * camFocus[2])
        Matrix.multiplyMM(mv, 0, view, 0, model, 0)
        Matrix.multiplyMM(out, 0, proj, 0, mv, 0)
        // Geser vertikal pembuat slab muat memudar saat kamera mengikuti pelari, supaya pelari tepat di tengah adegan.
        val shift = FloatArray(16); Matrix.setIdentityM(shift, 0); shift[13] = ndcShift * (1f - camFollow)
        val res = FloatArray(16)
        Matrix.multiplyMM(res, 0, shift, 0, out, 0)
        return res
    }

    /** Titik lokal (x, y dunia, z) -> piksel bingkai penuh pada sudut [azDeg]; null bila di belakang kamera. */
    fun project(x: Float, y: Float, z: Float, azDeg: Double): FloatArray? {
        val l = lay ?: return null
        val r = FloatArray(4)
        Matrix.multiplyMV(r, 0, mvp(azDeg), 0, floatArrayOf(x, y, z, 1f), 0)
        if (r[3] <= 1e-4f) return null
        val nx = r[0] / r[3]; val ny = r[1] / r[3]
        return floatArrayOf(l.scene.x + (nx * .5f + .5f) * l.scene.w, l.scene.y + (1f - (ny * .5f + .5f)) * l.scene.h)
    }

    /**
     * Kedalaman dan keterlihatan titik lokal ([x], [y] dunia, [z]) pada sudut [azDeg] untuk pin nama daerah.
     * Hasil: [0] skala perspektif (1 = jarak kamera ke pusat adegan; jauh < 1) dan [1] keterlihatan 0..1 (turun bila garis
     * pandang tertutup relief). [surface] memberi tinggi dunia permukaan slab di (x, z), atau nilai sangat kecil di luar bentuk.
     */
    fun placeDepth(x: Float, y: Float, z: Float, azDeg: Double, surface: (Float, Float) -> Float): FloatArray {
        val l = lay ?: return floatArrayOf(1f, 1f)
        val tiltDeg = (Math.toDegrees(l.tiltRad) + camTiltD).coerceIn(5.0, 80.0)
        val elev = Math.toRadians(90.0 - tiltDeg)
        val d = dist / camZoom
        val a = Math.toRadians(azDeg)
        val ca = cos(a).toFloat(); val sa = sin(a).toFloat()
        // Kamera di dunia (0, d sin e, d cos e); kebalikan putaran model, lalu geseran ikut pelari, memberi posisinya di ruang lokal.
        val wy = (d * sin(elev)).toFloat(); val wz = (d * cos(elev)).toFloat()
        val ex = -wz * sa + camFollow * camFocus[0]
        val ey = wy + camFollow * camFocus[1]
        val ez = wz * ca + camFollow * camFocus[2]
        val headY = y + d * 0.012f
        var clear = Float.MAX_VALUE
        val steps = 28
        for (k in 1 until steps) {
            val t = k / steps.toFloat() * 0.96f
            val sx = ex + (x - ex) * t; val sy = ey + (headY - ey) * t; val sz = ez + (z - ez) * t
            clear = min(clear, sy - surface(sx, sz))
        }
        val dx = x - ex; val dy = y - ey; val dz = z - ez
        val dd = sqrt(dx * dx + dy * dy + dz * dz).coerceAtLeast(1f)
        return floatArrayOf((d / dd).coerceIn(0.6f, 1.2f), (clear / (d * 0.01f)).coerceIn(0f, 1f))
    }

    /** Meter per piksel di pusat adegan (untuk lebar garis dan jarak label). */
    fun metersPerPixel(): Float = mppNow

    private fun upload(slot: Int, bmp: Bitmap) {
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex[slot])
        if (texW[slot] != bmp.width || texH[slot] != bmp.height) {
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
            texW[slot] = bmp.width; texH[slot] = bmp.height
        } else GLUtils.texSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0, 0, bmp)
    }

    /** Lapisan statis (langit, gunung, judul) penuh bingkai; dipasang sekali per perubahan tampilan. */
    fun setStatic(bmp: Bitmap) { upload(0, bmp) }

    private fun drawQuad(slot: Int, box: TrailBox?, blend: Boolean) {
        GLES20.glUseProgram(pQuad)
        if (blend) { GLES20.glEnable(GLES20.GL_BLEND); GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA) } else GLES20.glDisable(GLES20.GL_BLEND)
        val x0: Float; val x1: Float; val yT: Float; val yB: Float
        if (box == null) { x0 = -1f; x1 = 1f; yT = 1f; yB = -1f } else {
            x0 = box.x / W * 2f - 1f; x1 = (box.x + box.w) / W * 2f - 1f
            yT = 1f - box.y / H * 2f; yB = 1f - (box.y + box.h) / H * 2f
        }
        GLES20.glUniform4f(GLES20.glGetUniformLocation(pQuad, "uR"), x0, yT, x1, yB)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex[slot])
        GLES20.glUniform1i(GLES20.glGetUniformLocation(pQuad, "uTex"), 0)
        val a = GLES20.glGetAttribLocation(pQuad, "aUv")
        quad.position(0)
        GLES20.glEnableVertexAttribArray(a); GLES20.glVertexAttribPointer(a, 2, GLES20.GL_FLOAT, false, 0, quad)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(a)
    }

    /** Isi [ribBuf] dengan pita rute dari titik 0 sampai [count] (+ titik akhir [end] bila ada); mengembalikan jumlah titik. */
    private fun fillRibbon(s: TrailScene, count: Int, end: FloatArray?, hw: Float, lift: Float): Int {
        val m = s.rx.size
        val c = min(count, m)
        val total = c + if (end != null) 1 else 0
        if (total < 2) return 0
        fun px(i: Int) = if (i < c) s.rx[i] else end!![0]
        fun py(i: Int) = if (i < c) s.ry[i] else end!![1]
        fun pz(i: Int) = if (i < c) s.rz[i] else end!![2]
        for (i in 0 until total) {
            val i0 = max(0, i - 1); val i1 = min(total - 1, i + 1)
            var tx = px(i1) - px(i0); var tz = pz(i1) - pz(i0)
            val l = max(sqrt(tx * tx + tz * tz), 1e-3f); tx /= l; tz /= l
            val ox = -tz * hw; val oz = tx * hw
            val y = py(i) + lift
            ribTmp[i * 6] = px(i) + ox; ribTmp[i * 6 + 1] = y; ribTmp[i * 6 + 2] = pz(i) + oz
            ribTmp[i * 6 + 3] = px(i) - ox; ribTmp[i * 6 + 4] = y; ribTmp[i * 6 + 5] = pz(i) - oz
        }
        ribBuf.position(0); ribBuf.put(ribTmp, 0, total * 6); ribBuf.position(0)
        return total
    }

    /**
     * Gambar satu bingkai. [az] sudut putar, [frac] bagian jarak yang sudah ditempuh, [chart] bitmap grafik (di kotak
     * [chartBox]), [over] lapisan atas penuh bingkai.
     */
    fun frame(az: Double, frac: Float, chart: Bitmap?, chartBox: TrailBox?, over: Bitmap?) {
        val s = ts ?: return
        val l = lay ?: return
        val p = pal ?: return
        GLES20.glViewport(0, 0, W, H)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glDepthMask(true)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        if (texW[0] > 0) drawQuad(0, null, false)
        if (chart != null && chartBox != null) { upload(1, chart); drawQuad(1, chartBox, true) }

        // Slab medan di kotak adegan
        val vx = l.scene.x.toInt(); val vw = l.scene.w.toInt(); val vh = l.scene.h.toInt()
        val vy = H - l.scene.y.toInt() - vh
        GLES20.glViewport(vx, vy, vw, vh)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthFunc(GLES20.GL_LEQUAL)
        GLES20.glDisable(GLES20.GL_BLEND)
        val mat = mvp(az)
        val sides = s.sides
        val lx = -0.55f; val ly = 0.70f; val lz = -0.45f
        val ln = sqrt(lx * lx + ly * ly + lz * lz)

        GLES20.glUseProgram(pTerrain)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(pTerrain, "uMvp"), 1, false, mat, 0)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(pTerrain, "uA"), s.apothem)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(pTerrain, "uN"), sides.toFloat())
        GLES20.glUniform1f(GLES20.glGetUniformLocation(pTerrain, "uEx"), s.ex)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(pTerrain, "uHm"), max(s.hi - s.lo, 0.5f))
        GLES20.glUniform1f(GLES20.glGetUniformLocation(pTerrain, "uFine"), s.fine)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(pTerrain, "uPx"), mppNow)
        GLES20.glUniform3f(GLES20.glGetUniformLocation(pTerrain, "uL"), lx / ln, ly / ln, lz / ln)
        fun u3(name: String, v: FloatArray) = GLES20.glUniform3f(GLES20.glGetUniformLocation(pTerrain, name), v[0], v[1], v[2])
        u3("uLow", p.low); u3("uMid", p.mid); u3("uHi", p.hi); u3("uDk", p.dk); u3("uTn", p.tn); u3("uAcc", p.acc); u3("uTc", p.tc)
        val aP = GLES20.glGetAttribLocation(pTerrain, "aP"); val aG = GLES20.glGetAttribLocation(pTerrain, "aG")
        terrPos!!.position(0); terrG!!.position(0); terrIdx!!.position(0)
        GLES20.glEnableVertexAttribArray(aP); GLES20.glVertexAttribPointer(aP, 3, GLES20.GL_FLOAT, false, 0, terrPos)
        GLES20.glEnableVertexAttribArray(aG); GLES20.glVertexAttribPointer(aG, 2, GLES20.GL_FLOAT, false, 0, terrG)
        GLES20.glDrawElements(GLES20.GL_TRIANGLES, terrIdxCount, GLES20.GL_UNSIGNED_SHORT, terrIdx)
        GLES20.glDisableVertexAttribArray(aP); GLES20.glDisableVertexAttribArray(aG)

        // Dinding
        GLES20.glUseProgram(pWall)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(pWall, "uMvp"), 1, false, mat, 0)
        fun w3(name: String, v: FloatArray) = GLES20.glUniform3f(GLES20.glGetUniformLocation(pWall, name), v[0], v[1], v[2])
        w3("uWt", p.wt); w3("uWb", p.wb); w3("uWh", p.wh); w3("uL", floatArrayOf(lx / ln, ly / ln, lz / ln))
        val wP = GLES20.glGetAttribLocation(pWall, "aP"); val wG = GLES20.glGetAttribLocation(pWall, "aG")
        wallPos!!.position(0); wallG!!.position(0)
        GLES20.glEnableVertexAttribArray(wP); GLES20.glVertexAttribPointer(wP, 3, GLES20.GL_FLOAT, false, 0, wallPos)
        GLES20.glEnableVertexAttribArray(wG); GLES20.glVertexAttribPointer(wG, 2, GLES20.GL_FLOAT, false, 0, wallG)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, wallCount)
        GLES20.glDisableVertexAttribArray(wP); GLES20.glDisableVertexAttribArray(wG)

        // Rute: bayangan gelap, jejak redup penuh, lalu bagian tertempuh bersinar
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glDepthMask(false)
        GLES20.glUseProgram(pRibbon)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(pRibbon, "uMvp"), 1, false, mat, 0)
        val rP = GLES20.glGetAttribLocation(pRibbon, "aP"); val rC = GLES20.glGetUniformLocation(pRibbon, "uColor")
        GLES20.glEnableVertexAttribArray(rP)
        val wu = 6.2f * l.k * mppNow
        val lift = mppNow * 3.2f
        val done = s.doneCount(frac)
        val endPos = if (frac > 0f && frac < 1f) s.locate(frac) else null
        fun strip(count: Int, end: FloatArray?, hw: Float, c: FloatArray) {
            val pts = fillRibbon(s, count, end, hw, lift)
            if (pts < 2) return
            GLES20.glVertexAttribPointer(rP, 3, GLES20.GL_FLOAT, false, 0, ribBuf)
            GLES20.glUniform4f(rC, c[0], c[1], c[2], c[3])
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, pts * 2)
        }
        val ac = p.acc
        strip(s.rx.size, null, wu * 1.15f, floatArrayOf(0f, 0f, 0f, 0.45f))
        strip(s.rx.size, null, wu * 0.55f, floatArrayOf(1f, 1f, 1f, 0.38f))
        if (frac > 0f) {
            strip(done, endPos, wu * 2.3f, floatArrayOf(ac[0], ac[1], ac[2], 0.22f))
            strip(done, endPos, wu, floatArrayOf(ac[0], ac[1], ac[2], 1f))
        }
        GLES20.glDisableVertexAttribArray(rP)
        GLES20.glDepthMask(true)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)

        // Lapisan atas
        GLES20.glViewport(0, 0, W, H)
        if (over != null) { upload(2, over); drawQuad(2, null, true) }
    }

    /** Baca piksel bingkai saat ini (pratinjau dan foto). */
    fun readFrame(): Bitmap {
        val buf = ByteBuffer.allocateDirect(W * H * 4).order(ByteOrder.nativeOrder())
        GLES20.glReadPixels(0, 0, W, H, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf)
        val raw = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        raw.copyPixelsFromBuffer(buf)
        val flipped = Bitmap.createBitmap(raw, 0, 0, W, H, GMatrix().apply { postScale(1f, -1f) }, false)
        raw.recycle()
        return flipped
    }

    fun release() {
        runCatching {
            GLES20.glDeleteTextures(3, tex, 0)
            for (p in intArrayOf(pTerrain, pWall, pRibbon, pQuad)) if (p != 0) GLES20.glDeleteProgram(p)
        }
    }
}
