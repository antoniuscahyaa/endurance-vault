package com.endurancevault.app.domain

import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Video rute 3D (peta satelit + medan sesuai elevasi) dengan panel data yang ditempatkan pada grid.
 * File ini murni Kotlin (tanpa Android) supaya bisa dites JUnit biasa. Penggambaran ada di `ui/video/`.
 */

/**
 * Satu panel pada grid: sel kiri atas ([col], [row]) dihitung dari 0, dan ukuran dalam jumlah sel ([colSpan], [rowSpan]).
 * Isi panel diskalakan otomatis agar pas di kotaknya.
 */
data class VideoPanel(val key: String, val col: Int, val row: Int, val colSpan: Int = 1, val rowSpan: Int = 1)

object RouteVideoKeys {
    val STAT = listOf("jarak", "waktu", "pace", "hr", "grad", "elev", "gain", "cad")
    val ALL = listOf("judul") + STAT + listOf("profil", "grafikpace", "grafikhr", "legenda", "ghost")
    val DEFAULT_ON = listOf("judul", "profil", "jarak", "waktu", "pace", "hr")
    val CAMERA_MODES = listOf("orbit", "chase", "top")
    const val DEFAULT_COLS = 2
    const val DEFAULT_ROWS = 12

    fun name(k: String): String = when (k) {
        "judul" -> "Judul"; "jarak" -> "Jarak"; "waktu" -> "Waktu"; "pace" -> "Pace / kecepatan"
        "hr" -> "Detak jantung"; "grad" -> "Gradien"; "elev" -> "Elevasi"; "gain" -> "Total naik"
        "cad" -> "Cadence"; "profil" -> "Grafik elevasi"; "grafikpace" -> "Grafik pace / kecepatan"
        "grafikhr" -> "Grafik detak jantung"; "legenda" -> "Legenda warna garis"
        "ghost" -> "Selisih ghost"; else -> k
    }

    fun cameraName(m: String): String = when (m) { "chase" -> "Ikuti arah lari"; "top" -> "Dari atas"; else -> "Orbit" }

    /** Penempatan bawaan sebagai pecahan grid (kolom, baris, lebar, tinggi) supaya tetap masuk akal di grid berukuran lain. */
    private class Spec(val c: Double, val r: Double, val w: Double, val h: Double)

    private fun spec(k: String): Spec = when (k) {
        "judul" -> Spec(0.0, 0.0, 1.0, 1 / 12.0)
        "legenda" -> Spec(0.0, 1 / 12.0, 0.5, 1 / 12.0)
        "ghost" -> Spec(0.5, 1 / 12.0, 0.5, 1 / 12.0)
        "grafikhr" -> Spec(0.0, 2 / 12.0, 1.0, 2 / 12.0)
        "grafikpace" -> Spec(0.0, 4 / 12.0, 1.0, 2 / 12.0)
        "profil" -> Spec(0.0, 6 / 12.0, 1.0, 2 / 12.0)
        "jarak" -> Spec(0.0, 8 / 12.0, 0.5, 1 / 12.0)
        "waktu" -> Spec(0.5, 8 / 12.0, 0.5, 1 / 12.0)
        "pace" -> Spec(0.0, 9 / 12.0, 0.5, 1 / 12.0)
        "hr" -> Spec(0.5, 9 / 12.0, 0.5, 1 / 12.0)
        "grad" -> Spec(0.0, 10 / 12.0, 0.5, 1 / 12.0)
        "elev" -> Spec(0.5, 10 / 12.0, 0.5, 1 / 12.0)
        "gain" -> Spec(0.0, 11 / 12.0, 0.5, 1 / 12.0)
        "cad" -> Spec(0.5, 11 / 12.0, 0.5, 1 / 12.0)
        else -> Spec(0.0, 0.5, 1.0, 1 / 12.0)
    }

    fun defaultPanel(k: String, cols: Int = DEFAULT_COLS, rows: Int = DEFAULT_ROWS): VideoPanel {
        val s = spec(k)
        val cs = max(1, (s.w * cols).roundToInt()).coerceAtMost(cols)
        val rs = max(1, (s.h * rows).roundToInt()).coerceAtMost(rows)
        val c = (s.c * cols).roundToInt().coerceIn(0, cols - cs)
        val r = (s.r * rows).roundToInt().coerceIn(0, rows - rs)
        return VideoPanel(k, c, r, cs, rs)
    }

    fun defaultLayout(cols: Int = DEFAULT_COLS, rows: Int = DEFAULT_ROWS): List<VideoPanel> =
        RouteVideoGrid.fit(DEFAULT_ON.map { defaultPanel(it, cols, rows) }, cols, rows)
}

/** Aturan grid: ukuran, kotak sel, dan penempatan panel tanpa tumpang tindih. */
object RouteVideoGrid {
    const val MIN_COLS = 1
    const val MAX_COLS = 6
    const val MIN_ROWS = 4
    const val MAX_ROWS = 20

    /** Area grid dalam piksel bingkai (ada margin aman di tepi). */
    class Area(val left: Double, val top: Double, val width: Double, val height: Double)

    fun area(w: Int, h: Int): Area {
        val mx = w * 0.06; val mt = h * 0.05; val mb = h * 0.06
        return Area(mx, mt, w - 2 * mx, h - mt - mb)
    }

    /** Kotak panel dalam piksel bingkai: kiri, atas, kanan, bawah. */
    fun rect(p: VideoPanel, w: Int, h: Int, cols: Int, rows: Int): DoubleArray {
        val a = area(w, h); val cw = a.width / cols; val ch = a.height / rows
        return doubleArrayOf(a.left + p.col * cw, a.top + p.row * ch, a.left + (p.col + p.colSpan) * cw, a.top + (p.row + p.rowSpan) * ch)
    }

    /** Sel (kolom, baris) yang memuat titik (x, y) piksel; di luar area dibatasi ke sel terdekat. */
    fun cellAt(x: Double, y: Double, w: Int, h: Int, cols: Int, rows: Int): Pair<Int, Int> {
        val a = area(w, h)
        val c = floor((x - a.left) / (a.width / cols)).toInt().coerceIn(0, cols - 1)
        val r = floor((y - a.top) / (a.height / rows)).toInt().coerceIn(0, rows - 1)
        return c to r
    }

    fun overlaps(a: VideoPanel, b: VideoPanel): Boolean =
        a.col < b.col + b.colSpan && b.col < a.col + a.colSpan && a.row < b.row + b.rowSpan && b.row < a.row + a.rowSpan

    fun fits(p: VideoPanel, cols: Int, rows: Int): Boolean =
        p.col >= 0 && p.row >= 0 && p.colSpan >= 1 && p.rowSpan >= 1 && p.col + p.colSpan <= cols && p.row + p.rowSpan <= rows

    fun canPlace(others: List<VideoPanel>, p: VideoPanel, cols: Int, rows: Int): Boolean =
        fits(p, cols, rows) && others.none { it.key != p.key && overlaps(it, p) }

    /** Pindahkan/ubah panel; null bila hasilnya keluar grid atau menimpa panel lain. */
    fun place(panels: List<VideoPanel>, p: VideoPanel, cols: Int, rows: Int): List<VideoPanel>? =
        if (canPlace(panels, p, cols, rows)) panels.map { if (it.key == p.key) p else it } else null

    /** Sel kosong pertama (kiri ke kanan, atas ke bawah) untuk panel berukuran [cs] x [rs]. */
    fun firstFree(panels: List<VideoPanel>, key: String, cs: Int, rs: Int, cols: Int, rows: Int): VideoPanel? {
        if (cs > cols || rs > rows) return null
        for (r in 0..rows - rs) for (c in 0..cols - cs) {
            val p = VideoPanel(key, c, r, cs, rs)
            if (panels.none { it.key != key && overlaps(it, p) }) return p
        }
        return null
    }

    /** Tambah panel di posisi bawaannya bila kosong, kalau tidak di sel kosong pertama; null bila grid penuh. */
    fun add(panels: List<VideoPanel>, key: String, cols: Int, rows: Int): List<VideoPanel>? {
        val others = panels.filter { it.key != key }
        val d = RouteVideoKeys.defaultPanel(key, cols, rows)
        val spot = (if (canPlace(others, d, cols, rows)) d else null)
            ?: firstFree(others, key, d.colSpan, d.rowSpan, cols, rows)
            ?: firstFree(others, key, 1, 1, cols, rows)
            ?: return null
        return others + spot
    }

    /** Pastikan semua panel masuk grid [cols] x [rows] dan tidak saling menimpa; yang bentrok dipindah ke sel kosong, yang tak muat dibuang. */
    fun fit(panels: List<VideoPanel>, cols: Int, rows: Int): List<VideoPanel> {
        val out = ArrayList<VideoPanel>()
        for (p0 in panels) {
            val cs = p0.colSpan.coerceIn(1, cols); val rs = p0.rowSpan.coerceIn(1, rows)
            val p = VideoPanel(p0.key, p0.col.coerceIn(0, cols - cs), p0.row.coerceIn(0, rows - rs), cs, rs)
            if (out.none { overlaps(it, p) }) { out += p; continue }
            val free = firstFree(out, p.key, cs, rs, cols, rows) ?: firstFree(out, p.key, 1, 1, cols, rows)
            if (free != null) out += free
        }
        return out
    }
}

/** Pengaturan video rute 3D. Nilai tak valid dibersihkan oleh [sanitized]. */
data class RouteVideoPrefs(
    val panels: List<VideoPanel> = RouteVideoKeys.defaultLayout(),
    /** Jumlah kolom grid (horizontal), 1..6. */
    val gridCols: Int = RouteVideoKeys.DEFAULT_COLS,
    /** Jumlah baris grid (vertikal), 4..20. */
    val gridRows: Int = RouteVideoKeys.DEFAULT_ROWS,
    /** true = angka berjalan mengikuti posisi pelari; false = ringkasan total. */
    val live: Boolean = true,
    val durationSec: Int = 15,
    /** Sudut kamera dari bidang datar, derajat (20..80). */
    val tilt: Int = 52,
    /** Pengali tinggi medan (1..4). */
    val exaggeration: Double = 1.5,
    /** Total putaran kamera sepanjang video, derajat (0..180); dipakai mode orbit. */
    val orbit: Int = 50,
    /** orbit, chase (ikuti arah lari), atau top (dari atas, utara di atas). */
    val cameraMode: String = "orbit",
    /** w = putih, k = hitam, l = lime. */
    val ink: String = "w",
    val lineColor: String = "#C6F432",
    /** Warna garis rute: solid, hr, pace, grade. */
    val lineMode: String = "solid",
    /** Bendera per km (dengan pace km itu) di sepanjang rute. */
    val kmMarkers: Boolean = true,
    /** Bendera start dan finish. */
    val flagEnds: Boolean = true,
    /** Bendera titik tertinggi (puncak). */
    val flagPeak: Boolean = true,
    /** Bendera tanjakan terberat. */
    val flagSteep: Boolean = true,
    /** Bendera 1 km tercepat. */
    val flagFast: Boolean = true,
    /** Bendera titik detak jantung tertinggi. */
    val flagHrMax: Boolean = true,
    /** Bayangan relief (hillshade) pada medan. Mati = medan rata terang. */
    val hillshade: Boolean = true,
    /** Kabut jarak yang meredupkan medan yang jauh. */
    val fog: Boolean = true,
    /** Render lanjut di latar belakang dengan notifikasi. Mati = render berhenti bila layar ditutup. */
    val bgRender: Boolean = true,
    /** Ketebalan garis rute dalam persen dari ukuran bawaan (50..250). */
    val lineWidth: Int = 100,
    /** 9:16, 4:5, 1:1, atau 16:9. */
    val aspect: String = "9:16",
    /** hd (1080 px sisi pendek) atau sd (720 px). */
    val quality: String = "hd",
    /** Judul sendiri; kosong = nama aktivitas. */
    val titleText: String = "",
    /** Baris kedua di bawah judul (mis. lokasi atau nama event); kosong = tidak ada. */
    val subtitle: String = "",
    /** Tampilkan tanggal di bawah judul. */
    val showDate: Boolean = true,
    /** Kartu ringkasan (jarak, waktu, pace, naik) selama beberapa detik di akhir video. */
    val summary: Boolean = true,
    /** Tata letak buatan pengguna (maksimal 12). */
    val presets: List<LayoutPreset> = emptyList(),
) {
    fun sanitized(): RouteVideoPrefs {
        val cols = gridCols.coerceIn(RouteVideoGrid.MIN_COLS, RouteVideoGrid.MAX_COLS)
        val rows = gridRows.coerceIn(RouteVideoGrid.MIN_ROWS, RouteVideoGrid.MAX_ROWS)
        return copy(
            gridCols = cols, gridRows = rows,
            panels = RouteVideoGrid.fit(sanitizePanels(panels), cols, rows),
            cameraMode = if (cameraMode in RouteVideoKeys.CAMERA_MODES) cameraMode else "orbit",
            lineMode = if (lineMode in RouteVideoColors.MODES) lineMode else "solid",
            aspect = if (aspect in RouteVideoFormat.ASPECTS) aspect else "9:16",
            quality = if (quality == "sd") "sd" else "hd",
            presets = presets.filter { it.name.isNotBlank() }.map { it.sanitized() }.distinctBy { it.name }.take(12),
            lineWidth = lineWidth.coerceIn(50, 250),
            durationSec = durationSec.coerceIn(6, 40),
            tilt = tilt.coerceIn(20, 80),
            exaggeration = if (exaggeration.isFinite()) exaggeration.coerceIn(1.0, 4.0) else 1.5,
            orbit = orbit.coerceIn(0, 180),
            ink = if (ink in setOf("w", "k", "l")) ink else "w",
            lineColor = if (HEX.matches(lineColor)) lineColor else "#C6F432",
            titleText = titleText.take(60), subtitle = subtitle.take(80),
        )
    }

    /** Apakah bendera jenis [kind] (start, finish, km, peak, steep, fast, hrmax) ditampilkan. */
    fun showsAnchor(kind: String): Boolean = when (kind) {
        "km" -> kmMarkers
        "start", "finish" -> flagEnds
        "peak" -> flagPeak
        "steep" -> flagSteep
        "fast" -> flagFast
        "hrmax" -> flagHrMax
        else -> false
    }

    fun toJson(): String {
        val o = JsonObject()
        o.add("panels", panelsToJson(panels))
        o.addProperty("gc", gridCols); o.addProperty("gr", gridRows)
        o.addProperty("live", live); o.addProperty("dur", durationSec); o.addProperty("tilt", tilt)
        o.addProperty("ex", exaggeration); o.addProperty("orbit", orbit); o.addProperty("cm", cameraMode)
        o.addProperty("ink", ink); o.addProperty("lc", lineColor)
        o.addProperty("lm", lineMode); o.addProperty("km", kmMarkers)
        o.addProperty("fe", flagEnds); o.addProperty("fp", flagPeak); o.addProperty("fs", flagSteep)
        o.addProperty("ff", flagFast); o.addProperty("fh", flagHrMax)
        o.addProperty("hs", hillshade); o.addProperty("fg", fog); o.addProperty("bgr", bgRender)
        o.addProperty("lw", lineWidth)
        o.addProperty("asp", aspect); o.addProperty("q", quality)
        o.addProperty("tt", titleText); o.addProperty("st", subtitle); o.addProperty("sd", showDate); o.addProperty("sm", summary)
        o.add("presets", JsonArray().also { a -> presets.forEach { a.add(it.toJsonObject()) } })
        return o.toString()
    }

    companion object {
        private val HEX = Regex("#[0-9a-fA-F]{6}")

        internal fun sanitizePanels(list: List<VideoPanel>): List<VideoPanel> =
            list.filter { it.key in RouteVideoKeys.ALL }.distinctBy { it.key }.map {
                VideoPanel(it.key, max(0, it.col), max(0, it.row), max(1, it.colSpan), max(1, it.rowSpan))
            }

        /**
         * Panel dari JSON. Format lama (posisi persen: x, y, s) tidak bisa dipetakan ke grid, jadi hanya daftar panelnya
         * yang dipertahankan dan posisinya memakai bawaan grid.
         */
        internal fun panelsFromJson(arr: JsonArray, cols: Int, rows: Int): List<VideoPanel> {
            val legacy = arr.any { it.isJsonObject && it.asJsonObject.has("x") && !it.asJsonObject.has("c") }
            return arr.mapNotNull { e ->
                val p = e.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null
                val k = p.get("k")?.takeIf { it.isJsonPrimitive }?.asString ?: return@mapNotNull null
                if (k !in RouteVideoKeys.ALL) return@mapNotNull null
                if (legacy) return@mapNotNull RouteVideoKeys.defaultPanel(k, cols, rows)
                fun int(name: String, def: Int?): Int? = p.get(name)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asInt ?: def
                val c = int("c", null) ?: return@mapNotNull null
                val r = int("r", null) ?: return@mapNotNull null
                VideoPanel(k, c, r, int("cs", 1) ?: 1, int("rs", 1) ?: 1)
            }
        }

        internal fun panelsToJson(panels: List<VideoPanel>): JsonArray = JsonArray().also { a ->
            panels.forEach { p ->
                a.add(JsonObject().apply {
                    addProperty("k", p.key); addProperty("c", p.col); addProperty("r", p.row)
                    addProperty("cs", p.colSpan); addProperty("rs", p.rowSpan)
                })
            }
        }

        /** Membaca JSON hasil [toJson]; JSON rusak atau kosong menghasilkan pengaturan bawaan. */
        fun fromJson(json: String?): RouteVideoPrefs {
            val d = RouteVideoPrefs()
            val o = runCatching { JsonParser.parseString(json ?: "").asJsonObject }.getOrNull() ?: return d
            fun num(k: String): Double? = o.get(k)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asDouble
            fun str(k: String, def: String) = o.get(k)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isString }?.asString ?: def
            fun bool(k: String, def: Boolean) = o.get(k)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isBoolean }?.asBoolean ?: def
            val cols = (num("gc")?.toInt() ?: d.gridCols).coerceIn(RouteVideoGrid.MIN_COLS, RouteVideoGrid.MAX_COLS)
            val rows = (num("gr")?.toInt() ?: d.gridRows).coerceIn(RouteVideoGrid.MIN_ROWS, RouteVideoGrid.MAX_ROWS)
            val panels = o.get("panels")?.takeIf { it.isJsonArray }?.asJsonArray?.let { panelsFromJson(it, cols, rows) }
            val legacyFlags = bool("lb", d.flagEnds)   // versi lama: satu sakelar untuk start/finish/puncak/tanjakan
            val presets = o.get("presets")?.takeIf { it.isJsonArray }?.asJsonArray?.mapNotNull { LayoutPreset.fromJson(it) }.orEmpty()
            return RouteVideoPrefs(
                panels = panels ?: RouteVideoKeys.defaultLayout(cols, rows), gridCols = cols, gridRows = rows,
                live = bool("live", d.live),
                durationSec = num("dur")?.toInt() ?: d.durationSec,
                tilt = num("tilt")?.toInt() ?: d.tilt,
                exaggeration = num("ex") ?: d.exaggeration,
                orbit = num("orbit")?.toInt() ?: d.orbit,
                cameraMode = str("cm", d.cameraMode),
                ink = str("ink", d.ink), lineColor = str("lc", d.lineColor),
                lineMode = str("lm", d.lineMode), kmMarkers = bool("km", d.kmMarkers),
                flagEnds = bool("fe", legacyFlags), flagPeak = bool("fp", legacyFlags), flagSteep = bool("fs", legacyFlags),
                flagFast = bool("ff", d.flagFast), flagHrMax = bool("fh", d.flagHrMax),
                hillshade = bool("hs", d.hillshade), fog = bool("fg", d.fog), bgRender = bool("bgr", d.bgRender),
                lineWidth = num("lw")?.toInt() ?: d.lineWidth,
                aspect = str("asp", d.aspect), quality = str("q", d.quality),
                titleText = str("tt", d.titleText), subtitle = str("st", d.subtitle),
                showDate = bool("sd", d.showDate), summary = bool("sm", d.summary),
                presets = presets,
            ).sanitized()
        }
    }
}

/** Data satu frame. [pace] menit/km (null = berhenti/tak ada data), [grade] persen. */
class FrameStats(
    val idx: Int, val frac: Double, val distM: Double, val sec: Int,
    val pace: Double?, val hr: Int?, val grade: Double?, val ele: Double?, val gain: Double, val cad: Int?,
)

/**
 * Jejak aktivitas per sampel (1 Hz): posisi, jarak, waktu gerak, HR, cadence, elevasi, dan gradien.
 * Elevasi dihaluskan; gradien dan total naik diturunkan darinya bila tidak tersedia.
 * [gradeRaw] dan [ele] berisi NaN untuk nilai yang tidak diketahui.
 */
class RouteVideoTrack(
    val lat: DoubleArray, val lon: DoubleArray, val dist: DoubleArray, val sec: IntArray,
    val hr: IntArray, val cad: IntArray, ele: DoubleArray, gradeRaw: DoubleArray,
    val title: String, val dateText: String, val bike: Boolean = false, officialGain: Int? = null,
) {
    val n: Int = dist.size
    val totalM: Double = dist.last()
    val totalSec: Int = sec.last()
    val eleS: DoubleArray = smooth(fillForward(ele), 7)
    val hasEle: Boolean = eleS.any { it.isFinite() }
    val gradeS: DoubleArray
    val gainCum: DoubleArray

    init {
        require(n >= 2 && lat.size == n && lon.size == n && sec.size == n && hr.size == n && cad.size == n && ele.size == n && gradeRaw.size == n)
        val finite = gradeRaw.count { it.isFinite() }
        gradeS = if (finite * 2 >= n) smooth(gradeRaw, 10).map { if (it.isFinite()) it.coerceIn(-45.0, 45.0) else it }.toDoubleArray()
        else computeGrade()
        val cum = DoubleArray(n)
        for (i in 1 until n) {
            val a = eleS[i - 1]; val b = eleS[i]
            cum[i] = cum[i - 1] + if (a.isFinite() && b.isFinite() && b > a) b - a else 0.0
        }
        // Total naik mengikuti angka resmi aktivitas bila ada, supaya sama dengan yang tampil di aplikasi.
        val k = if (officialGain != null && officialGain > 0 && cum.last() > 0.5) officialGain / cum.last() else 1.0
        gainCum = DoubleArray(n) { cum[it] * k }
    }

    private fun computeGrade(): DoubleArray {
        val g = DoubleArray(n) { Double.NaN }
        if (!hasEle) return g
        var k = 0; var j = 0
        for (i in 0 until n) {
            while (k < i && dist[k] < dist[i] - 20.0) k++
            if (j < i) j = i
            while (j < n - 1 && dist[j + 1] <= dist[i] + 20.0) j++
            val dd = dist[j] - dist[k]
            if (dd >= 10.0) g[i] = ((eleS[j] - eleS[k]) / dd * 100.0).coerceIn(-45.0, 45.0)
        }
        return g
    }

    /** Indeks pertama dengan jarak >= [m] (dibatasi ke indeks terakhir). */
    fun indexAtDist(m: Double): Int {
        var lo = 0; var hi = n - 1
        while (lo < hi) { val mid = (lo + hi) ushr 1; if (dist[mid] >= m) hi = mid else lo = mid + 1 }
        return lo
    }

    /** Cache hasil hitung turunan (warna, legenda) per jejak. */
    internal val cache = java.util.concurrent.ConcurrentHashMap<String, Any>()

    /** Bagian jarak (0..1) yang sudah ditempuh pada detik ke-[t] (waktu gerak). */
    fun fracAtTime(t: Double): Double {
        if (t <= 0.0) return 0.0
        if (t >= sec.last()) return 1.0
        var lo = 0; var hi = n - 1
        while (lo < hi) { val mid = (lo + hi) ushr 1; if (sec[mid] >= t) hi = mid else lo = mid + 1 }
        if (lo == 0) return 0.0
        val a = sec[lo - 1].toDouble(); val b = sec[lo].toDouble()
        val f = if (b > a) ((t - a) / (b - a)).coerceIn(0.0, 1.0) else 1.0
        return ((dist[lo - 1] + (dist[lo] - dist[lo - 1]) * f) / totalM).coerceIn(0.0, 1.0)
    }

    /** Detik (waktu gerak) saat jarak [d] tercapai; di luar rute diekstrapolasi dengan kecepatan rata-rata. */
    fun timeAtDist(d: Double): Double {
        if (d <= 0.0) return 0.0
        if (d >= totalM) return totalSec + (d - totalM) / (totalM / totalSec.coerceAtLeast(1))
        val i = indexAtDist(d)
        if (i == 0) return sec[0].toDouble()
        val dd = dist[i] - dist[i - 1]
        val f = if (dd > 0) ((d - dist[i - 1]) / dd).coerceIn(0.0, 1.0) else 1.0
        return sec[i - 1] + (sec[i] - sec[i - 1]) * f
    }

    /** Elevasi tersampel merata sepanjang jarak, untuk grafik profil. NaN bila tidak ada data elevasi. */
    fun profileSamples(count: Int): DoubleArray {
        if (!hasEle) return DoubleArray(count) { Double.NaN }
        return DoubleArray(count) { eleS[indexAtDist(totalM * it / (count - 1).coerceAtLeast(1))] }
    }

    fun statsAt(r: Double, live: Boolean): FrameStats {
        if (!live) {
            val hrs = hr.filter { it >= 30 }; val cads = cad.filter { it > 0 }
            val avgPace = if (totalM > 0 && totalSec > 0) totalSec / 60.0 / (totalM / 1000.0) else null
            return FrameStats(
                n - 1, 1.0, totalM, totalSec, avgPace,
                if (hrs.isEmpty()) null else hrs.average().roundToInt(),
                gradeS.filter { it.isFinite() }.maxOrNull(),
                eleS.filter { it.isFinite() }.maxOrNull(), gainCum.last(),
                if (cads.isEmpty()) null else cads.average().roundToInt(),
            )
        }
        val frac = r.coerceIn(0.0, 1.0)
        val i = indexAtDist(frac * totalM)
        val k = max(0, i - 10); val j = min(n - 1, i + 10)
        val dd = dist[j] - dist[k]; val dt = (sec[j] - sec[k]).toDouble()
        val pace = if (dd >= 8.0 && dt > 0) (dt / 60.0 / (dd / 1000.0)).takeIf { it in 1.0..25.0 } else null
        fun avgPos(a: IntArray, thr: Int): Int? {
            var s = 0; var c = 0
            for (q in max(0, i - 2)..min(n - 1, i + 2)) if (a[q] >= thr) { s += a[q]; c++ }
            return if (c == 0) null else (s.toDouble() / c).roundToInt()
        }
        return FrameStats(
            i, frac, dist[i], sec[i], pace, avgPos(hr, 30),
            gradeS[i].takeIf { it.isFinite() }, eleS[i].takeIf { it.isFinite() }, gainCum[i], avgPos(cad, 1),
        )
    }

    companion object {
        /** Isi NaN dengan nilai valid sebelumnya (dan nilai valid pertama untuk awal deret). */
        internal fun fillForward(a: DoubleArray): DoubleArray {
            val out = a.copyOf()
            val first = out.indexOfFirst { it.isFinite() }
            if (first < 0) return out
            for (i in 0 until first) out[i] = out[first]
            for (i in first + 1 until out.size) if (!out[i].isFinite()) out[i] = out[i - 1]
            return out
        }

        /** Rata-rata bergerak ±[half] sampel yang mengabaikan NaN. */
        internal fun smooth(a: DoubleArray, half: Int): DoubleArray {
            val n = a.size
            val pre = DoubleArray(n + 1); val cnt = IntArray(n + 1)
            for (i in 0 until n) {
                val ok = a[i].isFinite()
                pre[i + 1] = pre[i] + if (ok) a[i] else 0.0
                cnt[i + 1] = cnt[i] + if (ok) 1 else 0
            }
            return DoubleArray(n) { i ->
                val lo = max(0, i - half); val hi = min(n - 1, i + half)
                val c = cnt[hi + 1] - cnt[lo]
                if (c == 0) Double.NaN else (pre[hi + 1] - pre[lo]) / c
            }
        }

        private fun haversine(a: RouteGeo.LatLon, b: RouteGeo.LatLon): Double {
            val r = 6_371_000.0
            val p1 = Math.toRadians(a.lat); val p2 = Math.toRadians(b.lat)
            val dp = p2 - p1; val dl = Math.toRadians(b.lon - a.lon)
            val h = sin(dp / 2) * sin(dp / 2) + cos(p1) * cos(p2) * sin(dl / 2) * sin(dl / 2)
            return 2 * r * atan2(sqrt(h), sqrt(1 - h))
        }

        /**
         * Bangun dari detail aktivitas. Null bila tidak ada deret per detik atau rute GPS.
         * Jejak GPS per detik dipakai bila ada; aktivitas lama jatuh ke rute sederhana (±140 titik) yang diinterpolasi menurut jarak.
         */
        fun from(d: ActDetail, title: String, dateText: String): RouteVideoTrack? {
            val ts = d.timeSeries?.takeIf { it.seconds.size >= 20 && it.distanceMeters.size == it.seconds.size } ?: return null
            val n = ts.seconds.size
            val dist = DoubleArray(n)
            for (i in 0 until n) dist[i] = max(if (i == 0) 0.0 else dist[i - 1], ts.distanceMeters[i].takeIf { it.isFinite() } ?: 0.0)
            if (dist.last() < 100.0) return null
            val lat = DoubleArray(n); val lon = DoubleArray(n)
            val gt = d.gpsTrack?.takeIf { it.size == n }
            if (gt != null) {
                for (i in 0 until n) { lat[i] = gt.lat[i]; lon[i] = gt.lon[i] }
            } else {
                val frame = d.geo ?: return null
                if (!d.hasRoute) return null
                val pts = RouteGeo.toLatLon(frame, d.route)
                val cum = DoubleArray(pts.size)
                for (i in 1 until pts.size) cum[i] = cum[i - 1] + haversine(pts[i - 1], pts[i])
                val total = cum.last()
                if (total <= 0.0) return null
                var k = 0
                for (i in 0 until n) {
                    val target = dist[i] / dist.last() * total
                    while (k < pts.size - 2 && cum[k + 1] < target) k++
                    val seg = cum[k + 1] - cum[k]
                    val f = if (seg > 0) ((target - cum[k]) / seg).coerceIn(0.0, 1.0) else 0.0
                    lat[i] = pts[k].lat + (pts[k + 1].lat - pts[k].lat) * f
                    lon[i] = pts[k].lon + (pts[k + 1].lon - pts[k].lon) * f
                }
            }
            val ele = DoubleArray(n) { ts.elevationMeters.getOrNull(it) ?: Double.NaN }
            if (ele.none { it.isFinite() } && d.profile.size >= 2) {
                // Tanpa elevasi per detik: interpolasi dari profil (km, m) menurut jarak.
                var k = 0
                for (i in 0 until n) {
                    val km = dist[i] / 1000.0
                    while (k < d.profile.size - 2 && d.profile[k + 1].first < km) k++
                    val a = d.profile[k]; val b = d.profile[k + 1]
                    val f = if (b.first > a.first) ((km - a.first) / (b.first - a.first)).coerceIn(0.0, 1.0) else 0.0
                    ele[i] = a.second + (b.second - a.second) * f
                }
            }
            val sec = IntArray(n) { ts.seconds[it] }
            for (i in 1 until n) if (sec[i] < sec[i - 1]) sec[i] = sec[i - 1]
            return RouteVideoTrack(
                lat, lon, dist, sec,
                IntArray(n) { ts.heartRateBpm.getOrElse(it) { 0 } },
                IntArray(n) { ts.cadenceSpm.getOrElse(it) { 0 } },
                ele, DoubleArray(n) { ts.grade.getOrNull(it) ?: Double.NaN },
                title, dateText, d.bike, d.gain,
            )
        }
    }
}

/** Teks panel: label, nilai, satuan (bahasa Indonesia, koma desimal). */
object RouteVideoText {
    class Cell(val label: String, val value: String, val unit: String)

    private fun f(x: Double, dp: Int): String = String.format(Locale.US, "%.${dp}f", x).replace('.', ',')

    fun cell(key: String, st: FrameStats, live: Boolean, bike: Boolean): Cell? = when (key) {
        "jarak" -> Cell("JARAK", f(st.distM / 1000.0, 2), "km")
        "waktu" -> Cell("WAKTU", Js.durStr(st.sec / 60.0), "")
        "pace" ->
            if (bike) Cell(if (live) "KECEPATAN" else "KECEPATAN RATA2", st.pace?.let { f(60.0 / it, 1) } ?: "–", "km/j")
            else Cell(if (live) "PACE" else "PACE RATA2", st.pace?.let { Js.paceStr(it) } ?: "–", "/km")
        "hr" -> Cell(if (live) "DETAK JANTUNG" else "HR RATA2", st.hr?.toString() ?: "–", "bpm")
        "grad" -> Cell(
            if (live) "GRADIEN" else "GRADIEN MAKS",
            st.grade?.let { String.format(Locale.US, "%+.1f", it).replace('.', ',') } ?: "–", "%",
        )
        "elev" -> Cell(if (live) "ELEVASI" else "ELEVASI MAKS", st.ele?.let { it.roundToInt().toString() } ?: "–", "m")
        "gain" -> Cell("TOTAL NAIK", st.gain.roundToInt().toString(), "m")
        "cad" -> Cell(if (live) "CADENCE" else "CADENCE RATA2", st.cad?.toString() ?: "–", "spm")
        else -> null
    }

    /** Label dan keterangan untuk bendera di peta. */
    fun anchorLabel(a: Anchor, t: RouteVideoTrack): Pair<String, String> = when (a.kind) {
        "start" -> "START" to ""
        "finish" -> "FINISH" to "${f(t.totalM / 1000.0, 2)} km"
        "km" -> {
            val p = t.kmPace(a)
            "KM ${a.km}" to when {
                p == null -> ""
                t.bike -> "${f(60.0 / p, 1)} km/j"
                else -> "${Js.paceStr(p)} /km"
            }
        }
        "peak" -> "PUNCAK" to "${a.value.roundToInt()} m"
        "steep" -> "TANJAKAN" to "+${f(a.value, 1)}%"
        "fast" -> "TERCEPAT" to if (t.bike) "${f(60.0 / a.value, 1)} km/j" else "${Js.paceStr(a.value)} /km"
        "hrmax" -> "HR MAKS" to "${a.value.roundToInt()} bpm"
        else -> "" to ""
    }

    /** Panel selisih ghost: "UNGGUL 0:12" atau "TERTINGGAL 0:12". */
    fun ghostCell(g: GhostInfo): Cell {
        val v = Js.durStr(kotlin.math.abs(g.gapSec) / 60.0)
        val unit = if (g.gapSec >= 1.0) "unggul" else if (g.gapSec <= -1.0) "tertinggal" else "sama"
        return Cell("VS " + g.name.uppercase().take(16), if (unit == "sama") "0:00" else v, unit)
    }

    private val MONTHS = listOf("Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des")

    /** "2026-11-10" menjadi "10 Nov 2026"; teks lain dikembalikan apa adanya. */
    fun dateId(iso: String): String {
        val p = iso.take(10).split("-")
        if (p.size != 3) return iso
        val y = p[0].toIntOrNull(); val m = p[1].toIntOrNull(); val d = p[2].toIntOrNull()
        if (y == null || m == null || d == null || m !in 1..12) return iso
        return "$d ${MONTHS[m - 1]} $y"
    }
}

/** Pose kamera pada posisi video [p] (0..1). Murni fungsi supaya pratinjau dan hasil render identik. */
class CameraPose(
    val azimuthDeg: Double, val pitchDeg: Double, val distMul: Double, val follow: Double,
    /** Bagian jarak aktivitas utama (0..1). */
    val routeFrac: Double,
    /** Bagian jarak ghost (0..1) pada saat yang sama, null bila tanpa ghost. */
    val ghostFrac: Double? = null,
    /** Azimut kamera yang berada tepat di belakang pelari (mode chase), berlaku seberat [chaseWeight] (0..1). */
    val chaseAzDeg: Double = 0.0,
    val chaseWeight: Double = 0.0,
)

object RouteVideoCamera {
    /** Bagian awal (pengantar) dan akhir (kamera menjauh) video; di antaranya pelari menempuh rute. */
    const val T_IN = 0.07
    const val T_OUT = 0.90

    private fun smooth(x: Double): Double { val t = x.coerceIn(0.0, 1.0); return t * t * (3 - 2 * t) }

    /**
     * Pose pada posisi video [p]. Mode kamera: orbit (berputar pelan), chase (mengikuti arah lari; butuh [track]),
     * top (dari atas, utara di atas).
     */
    fun at(p: Double, prefs: RouteVideoPrefs, race: RouteVideoRace? = null, track: RouteVideoTrack? = null): CameraPose {
        val q = p.coerceIn(0.0, 1.0)
        val r = ((q - T_IN) / (T_OUT - T_IN)).coerceIn(0.0, 1.0)
        val intro = 1.0 - smooth(q / 0.14)
        val outro = smooth((q - 0.88) / 0.12)
        val frac = if (race == null) r else race.fractions(r).first
        var az = prefs.orbit * (q - 0.3)
        var pitch = prefs.tilt + 22.0 * intro - 6.0 * outro
        var follow = 0.6 * smooth(q / 0.2) * (1.0 - outro)
        var chaseW = 0.0; var chaseAz = 0.0
        when (prefs.cameraMode) {
            "top" -> { az = 0.0; pitch = 85.0; follow = 0.25 * smooth(q / 0.2) * (1.0 - outro) }
            "chase" -> if (track != null) { chaseW = smooth(q / 0.2) * (1.0 - outro); chaseAz = -track.bearingAt(frac) }
        }
        return CameraPose(
            azimuthDeg = az,
            pitchDeg = pitch.coerceIn(15.0, 85.0),
            distMul = 1.0 + 0.5 * intro + 0.4 * outro,
            follow = follow,
            routeFrac = frac,
            ghostFrac = race?.fractions(r)?.second,
            chaseAzDeg = chaseAz, chaseWeight = chaseW,
        )
    }
}
