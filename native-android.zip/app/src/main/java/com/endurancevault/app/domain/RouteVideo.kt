package com.endurancevault.app.domain

import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Video rute 3D (peta satelit + medan sesuai elevasi) dengan susunan tetap: judul dan ringkasan di kiri atas (hanya ukuran
 * dan warna yang bisa diatur), lalu di bagian bawah video grafik dan deretan data. File ini murni Kotlin (tanpa Android)
 * supaya bisa dites JUnit biasa. Penggambaran ada di `ui/video/`.
 */

object RouteVideoKeys {
    /** Data yang bisa ditampilkan di bawah video, dalam urutan tampil. */
    val STAT = listOf("jarak", "waktu", "pace", "hr", "grad", "elev", "gain", "cad")
    /** Grafik yang bisa ditampilkan tepat di samping data: elevasi, pace/kecepatan, detak jantung. */
    val CHARTS = listOf("profil", "grafikpace", "grafikhr")
    val DEFAULT_STATS = listOf("jarak", "waktu", "pace", "hr")
    val CAMERA_MODES = listOf("orbit", "chase", "top")

    fun name(k: String): String = when (k) {
        "jarak" -> "Jarak"; "waktu" -> "Waktu"; "pace" -> "Pace / kecepatan"
        "hr" -> "Detak jantung"; "grad" -> "Gradien"; "elev" -> "Elevasi"; "gain" -> "Total naik"
        "cad" -> "Cadence"; "profil" -> "Grafik elevasi"; "grafikpace" -> "Grafik pace / kecepatan"
        "grafikhr" -> "Grafik detak jantung"; else -> k
    }

    fun cameraName(m: String): String = when (m) { "chase" -> "Ikuti arah lari"; "top" -> "Dari atas"; else -> "Orbit" }
}

/** Hasil tata letak bagian bawah video, semua dalam piksel bingkai: kotak = kiri, atas, kanan, bawah. */
class LayoutPlan(
    val cols: Int, val rows: Int,
    /** Satu kotak per data, urut baris demi baris (kiri ke kanan, atas ke bawah). */
    val stats: List<DoubleArray>,
    val chart: DoubleArray?, val legend: DoubleArray?,
) {
    /** Tepi atas blok bawah (grafik, legenda, atau data yang paling atas); null bila tidak ada isinya. */
    val top: Double? get() = (stats.map { it[1] } + listOfNotNull(chart?.get(1), legend?.get(1))).minOrNull()
}

/**
 * Susunan bagian bawah video: grafik (opsional) dan deretan data. Secara bawaan grafik tepat di atas data; [swap] menukar
 * keduanya. Judul dan ringkasan tidak ikut diatur di sini: posisinya tetap di kiri atas ([titleLeft], [titleTop]); yang bisa
 * diubah hanya ukuran dan warnanya. Satuan jarak/ukuran mengikuti sisi pendek bingkai 1080 px lalu diskalakan, sehingga
 * pratinjau, HD, dan SD tampak sama.
 */
data class RouteVideoLayout(
    /** Data yang tampil, urut. */
    val stats: List<String> = RouteVideoKeys.DEFAULT_STATS,
    /** "rows": data disusun dalam 1–2 baris (cocok video vertikal); "cols": dalam 2–4 kolom (cocok video horizontal). */
    val statMode: String = "rows",
    val statRows: Int = 1,
    val statCols: Int = 2,
    /** Ukuran huruf data, persen dari ukuran bawaan. Mengecil otomatis bila tidak muat di kolomnya. */
    val statSize: Int = 100,
    val statColor: String = "#FFFFFF",
    /** Ukuran huruf judul, ringkasan (baris kedua), dan tanggal, persen dari ukuran bawaan. */
    val titleSize: Int = 100,
    val titleColor: String = "#FFFFFF",
    val showChart: Boolean = true,
    /** profil (elevasi), grafikpace, atau grafikhr. */
    val chartKind: String = "profil",
    /** Lebar grafik, persen dari lebar area isi. */
    val chartW: Int = 100,
    /** Tinggi grafik pada sisi pendek bingkai 1080 px. */
    val chartH: Int = 160,
    /** Legenda warna garis (hanya tampil bila garis diwarnai menurut data); ditaruh di atas blok bawah. */
    val legend: Boolean = false,
    /** false: grafik di atas data. true: data di atas grafik. */
    val swap: Boolean = false,
    /** Margin kiri dan kanan blok bawah dari tepi bingkai. */
    val marginX: Int = 65,
    /** Margin bawah dari tepi bingkai. */
    val marginBottom: Int = 70,
    /** Padding horizontal antar kolom data. */
    val padX: Int = 12,
    /** Padding vertikal antar baris data. */
    val padY: Int = 12,
    /** Jarak antara grafik dan deretan data. */
    val chartGap: Int = 16,
    /** Latar gradasi tipis di belakang blok bawah (transparan di atas, paling pekat di tepi bawah) supaya teks lebih jelas. */
    val scrim: Boolean = true,
    /** Kepekatan gradasi di tepi bawah, persen. */
    val scrimOpacity: Int = 45,
) {
    /** Jumlah (kolom, baris) untuk [count] data menurut mode; (0, 0) bila kosong. */
    fun gridFor(count: Int): Pair<Int, Int> {
        if (count <= 0) return 0 to 0
        return if (statMode == "cols") {
            val c = min(statCols.coerceIn(MIN_COLS, MAX_COLS), count)
            c to ceil(count / c.toDouble()).toInt()
        } else {
            val r = min(statRows.coerceIn(MIN_ROWS, MAX_ROWS), count)
            ceil(count / r.toDouble()).toInt() to r
        }
    }

    fun plan(w: Int, h: Int, statCount: Int, hasChart: Boolean, hasLegend: Boolean): LayoutPlan {
        val u = min(w, h) / 1080.0
        val left = marginX * u
        val width = max(1.0, w - 2 * left)
        val (cols, rows) = gridFor(statCount)
        val gx = padX * u; val gy = padY * u
        val cellW = if (cols > 0) (width - gx * (cols - 1)) / cols else 0.0
        val cellH = STAT_NAT_H * u * statSize / 100.0
        val statsH = if (rows > 0) rows * cellH + (rows - 1) * gy else 0.0
        val chartHpx = chartH * u
        val chartWpx = width * chartW / 100.0
        val gap = chartGap * u

        var bottom = h - marginBottom * u
        var first = true
        var rects: List<DoubleArray> = emptyList()
        var chart: DoubleArray? = null
        // Dari bawah ke atas: bawaan data lalu grafik; saat ditukar, grafik lalu data.
        for (part in if (swap) listOf("chart", "stats") else listOf("stats", "chart")) {
            if (part == "stats" && rows > 0) {
                if (!first) bottom -= gap
                val top = bottom - statsH
                rects = List(statCount) { i ->
                    val r = i / cols; val c = i % cols
                    val l = left + c * (cellW + gx); val t = top + r * (cellH + gy)
                    doubleArrayOf(l, t, l + cellW, t + cellH)
                }
                bottom = top; first = false
            } else if (part == "chart" && hasChart) {
                if (!first) bottom -= gap
                val top = bottom - chartHpx
                chart = doubleArrayOf(left, top, left + chartWpx, bottom)
                bottom = top; first = false
            }
        }
        var legend: DoubleArray? = null
        if (hasLegend) {
            if (!first) bottom -= LEGEND_GAP * u
            legend = doubleArrayOf(left, bottom - LEGEND_H * u, left + width, bottom)
        }
        return LayoutPlan(cols, rows, rects, chart, legend)
    }

    fun sanitized(): RouteVideoLayout = copy(
        stats = stats.filter { it in RouteVideoKeys.STAT }.distinct(),
        statMode = if (statMode == "cols") "cols" else "rows",
        statRows = statRows.coerceIn(MIN_ROWS, MAX_ROWS), statCols = statCols.coerceIn(MIN_COLS, MAX_COLS),
        statSize = statSize.coerceIn(MIN_SIZE, MAX_SIZE), titleSize = titleSize.coerceIn(MIN_SIZE, MAX_SIZE),
        statColor = if (HEX.matches(statColor)) statColor.uppercase() else DEFAULT_COLOR,
        titleColor = if (HEX.matches(titleColor)) titleColor.uppercase() else DEFAULT_COLOR,
        chartKind = if (chartKind in RouteVideoKeys.CHARTS) chartKind else "profil",
        chartW = chartW.coerceIn(MIN_CHART_W, 100), chartH = chartH.coerceIn(MIN_CHART_H, MAX_CHART_H),
        marginX = marginX.coerceIn(0, MAX_MARGIN_X), marginBottom = marginBottom.coerceIn(0, MAX_MARGIN_BOTTOM),
        padX = padX.coerceIn(0, MAX_PAD), padY = padY.coerceIn(0, MAX_PAD), chartGap = chartGap.coerceIn(0, MAX_PAD),
        scrimOpacity = scrimOpacity.coerceIn(0, 100),
    )

    fun toJson(): JsonObject = JsonObject().also { o ->
        o.add("stats", JsonArray().also { a -> stats.forEach { a.add(it) } })
        o.addProperty("sm", statMode); o.addProperty("sr", statRows); o.addProperty("sc", statCols)
        o.addProperty("ss", statSize); o.addProperty("scol", statColor)
        o.addProperty("ts", titleSize); o.addProperty("tcol", titleColor)
        o.addProperty("cs", showChart); o.addProperty("ck", chartKind); o.addProperty("cw", chartW); o.addProperty("ch", chartH)
        o.addProperty("lg", legend); o.addProperty("sw", swap)
        o.addProperty("mx", marginX); o.addProperty("mb", marginBottom)
        o.addProperty("px", padX); o.addProperty("py", padY); o.addProperty("cg", chartGap)
        o.addProperty("sg", scrim); o.addProperty("so", scrimOpacity)
    }

    companion object {
        const val MIN_ROWS = 1
        const val MAX_ROWS = 2
        const val MIN_COLS = 2
        const val MAX_COLS = 4
        const val MIN_SIZE = 50
        const val MAX_SIZE = 200
        const val MIN_CHART_W = 30
        const val MIN_CHART_H = 60
        const val MAX_CHART_H = 500
        const val MAX_MARGIN_X = 200
        const val MAX_MARGIN_BOTTOM = 400
        const val MAX_PAD = 120
        /** Tinggi alami satu sel data pada ukuran 100%, sisi pendek bingkai 1080 px. */
        const val STAT_NAT_H = 90.0
        const val LEGEND_H = 70.0
        const val LEGEND_GAP = 8.0
        const val DEFAULT_COLOR = "#FFFFFF"
        private val HEX = Regex("#[0-9a-fA-F]{6}")

        /** Judul dan ringkasan tidak bisa dipindah: kiri atas, dengan margin aman 6% lebar dan 5% tinggi. */
        fun titleLeft(w: Int): Double = w * 0.06
        fun titleTop(h: Int): Double = h * 0.05
        fun titleMaxWidth(w: Int): Double = w * 0.88

        fun inkColor(ink: String): String = when (ink) { "k" -> "#111111"; "l" -> "#C6F432"; else -> DEFAULT_COLOR }

        fun fromJson(o: JsonObject): RouteVideoLayout {
            val d = RouteVideoLayout()
            fun num(k: String, def: Int) = o.get(k)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asInt ?: def
            fun str(k: String, def: String) = o.get(k)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isString }?.asString ?: def
            fun bool(k: String, def: Boolean) = o.get(k)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isBoolean }?.asBoolean ?: def
            val stats = o.get("stats")?.takeIf { it.isJsonArray }?.asJsonArray
                ?.mapNotNull { e -> e.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isString }?.asString } ?: d.stats
            return RouteVideoLayout(
                stats = stats, statMode = str("sm", d.statMode), statRows = num("sr", d.statRows), statCols = num("sc", d.statCols),
                statSize = num("ss", d.statSize), statColor = str("scol", d.statColor),
                titleSize = num("ts", d.titleSize), titleColor = str("tcol", d.titleColor),
                showChart = bool("cs", d.showChart), chartKind = str("ck", d.chartKind), chartW = num("cw", d.chartW), chartH = num("ch", d.chartH),
                legend = bool("lg", d.legend), swap = bool("sw", d.swap),
                marginX = num("mx", d.marginX), marginBottom = num("mb", d.marginBottom),
                padX = num("px", d.padX), padY = num("py", d.padY), chartGap = num("cg", d.chartGap),
                scrim = bool("sg", d.scrim), scrimOpacity = num("so", d.scrimOpacity),
            ).sanitized()
        }

        /**
         * Pengaturan lama (grid panel, versi sebelum 0.5.92): data dan grafik yang aktif dipertahankan menurut urutan
         * letaknya di grid (baris dulu, lalu kolom); posisi dan ukuran panel tidak bisa dipetakan dan dibuang. [panels] null
         * berarti tidak ada daftar panel (pakai bawaan); [ink] w/k/l menjadi warna.
         */
        fun fromLegacy(panels: JsonArray?, ink: String?): RouteVideoLayout {
            val color = inkColor(ink ?: "w")
            val base = RouteVideoLayout(statColor = color, titleColor = color)
            if (panels == null) return base.sanitized()
            val items = panels.mapNotNull { e ->
                val p = e.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null
                val k = p.get("k")?.takeIf { it.isJsonPrimitive }?.asString ?: return@mapNotNull null
                fun n(name: String) = p.get(name)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asInt ?: 0
                Triple(k, n("r"), n("c"))
            }
            val ordered = items.sortedWith(compareBy({ it.second }, { it.third })).map { it.first }
            val chart = ordered.firstOrNull { it in RouteVideoKeys.CHARTS }
            return base.copy(
                stats = ordered.filter { it in RouteVideoKeys.STAT },
                showChart = chart != null, chartKind = chart ?: "profil",
                legend = "legenda" in ordered,
            ).sanitized()
        }
    }
}

/** Pengaturan video rute 3D. Nilai tak valid dibersihkan oleh [sanitized]. */

/** Pengaturan layout video Trail 3D yang terpisah dari mode peta standar. */
data class TrailVideoPrefs(
    val shape: String = "circle",              // circle, square, hex, oct
    val palette: String = "orange",             // orange, lime
    val statLayout: String = "classic",         // classic, center, tiles, compact
    val durationSec: Int = 20,
    val cardStyle: String = "none",             // none, glass, solid
    val motion: String = "auto",                // auto, diam, reveal, swing, orbit, dive
    val metricMode: String = "auto",
    val metrics: List<String> = listOf("pace", "hr", "gain", "time"),
    val extraMetrics: Boolean = false,
    val showPeak: Boolean = true,
    val showGradePill: Boolean = true,
    val panelEntrance: Boolean = false,
    val background: String = "mountain",        // mountain, plain, solid, photo
    val solidBackground: String = "#14100E",
    val accent: String = "",                    // kosong = ikut palet
    val tilt: Int = 58,
    val reliefPercent: Int = 34,
    val terrainScale: Int = 1,                  // bsx: skala rute relatif terhadap slab
    val zoomPercent: Int = 100,                 // tzm: zoom komposisi terrain
    val baseY: Int = 6,                         // tby: offset dasar terrain
    val centerX: Int = 0,
    val centerY: Int = 0,
    val rotation: Int = 0,
    val contour: Boolean = true,
    val hillshade: Boolean = true,
    val progressBar: Boolean = true,
    val safeStory: Boolean = false,
    val showHeader: Boolean = true,
    val showLocation: Boolean = true,
    val showWeather: Boolean = true,
    val showElevationChart: Boolean = true,
    val showClimbLabels: Boolean = false,
    val showKmMarkers: Boolean = true,
    val showSummary: Boolean = false,
    val darkenPhoto: Int = 40,
    val title: String = "",
    val location: String = "",
    val handle: String = "",
    val photoPath: String = "",
) {
    fun sanitized() = copy(
        shape = shape.takeIf { it in listOf("circle", "square", "hex", "oct") } ?: "circle",
        palette = palette.takeIf { it in listOf("orange", "lime") } ?: "orange",
        statLayout = statLayout.takeIf { it in listOf("classic", "center", "tiles", "compact") } ?: "classic",
        durationSec = durationSec.coerceIn(10, 60),
        cardStyle = cardStyle.takeIf { it in listOf("none", "glass", "solid", "auto") } ?: "none",
        motion = motion.takeIf { it in listOf("auto", "diam", "reveal", "swing", "orbit", "dive") } ?: "auto",
        metricMode = if (metricMode == "custom") "custom" else "auto",
        metrics = metrics.filter { it in listOf("pace", "hr", "gain", "time", "cad", "gap", "vam", "none") }.take(4).let { if (it.isEmpty()) listOf("pace","hr","gain","time") else it },
        background = background.takeIf { it in listOf("mountain", "plain", "solid", "photo") } ?: "mountain",
        solidBackground = solidBackground.takeIf { it.matches(Regex("#[0-9a-fA-F]{6}")) } ?: "#14100E",
        accent = accent.takeIf { it.isBlank() || it.matches(Regex("#[0-9a-fA-F]{6}")) } ?: "",
        tilt = tilt.coerceIn(25, 75), reliefPercent = reliefPercent.coerceIn(5, 60),
        terrainScale = terrainScale.coerceIn(1, 9), zoomPercent = zoomPercent.coerceIn(50, 200),
        baseY = baseY.coerceIn(-40, 40),
        centerX = centerX.coerceIn(-40, 40), centerY = centerY.coerceIn(-40, 40),
        rotation = rotation.coerceIn(-180, 180), darkenPhoto = darkenPhoto.coerceIn(0, 85),
        title = title.take(60), location = location.take(60), handle = handle.take(32), photoPath = photoPath.take(512),
    )

    fun toJson() = JsonObject().also { o ->
        o.addProperty("shape", shape); o.addProperty("palette", palette); o.addProperty("stats", statLayout); o.addProperty("duration", durationSec)
        o.addProperty("card", cardStyle); o.addProperty("motion", motion); o.addProperty("metricMode", metricMode)
        o.add("metrics", JsonArray().also { a -> metrics.forEach { a.add(it) } }); o.addProperty("extraMetrics", extraMetrics); o.addProperty("peak", showPeak)
        o.addProperty("gradePill", showGradePill); o.addProperty("panelEntrance", panelEntrance)
        o.addProperty("bg", background); o.addProperty("bgc", solidBackground); o.addProperty("accent", accent)
        o.addProperty("tilt", tilt); o.addProperty("relief", reliefPercent); o.addProperty("scale", terrainScale)
        o.addProperty("zoom", zoomPercent); o.addProperty("baseY", baseY)
        o.addProperty("cx", centerX); o.addProperty("cy", centerY); o.addProperty("rotation", rotation)
        o.addProperty("contour", contour); o.addProperty("hillshade", hillshade); o.addProperty("bar", progressBar); o.addProperty("safe", safeStory)
        o.addProperty("header", showHeader); o.addProperty("location", showLocation); o.addProperty("weather", showWeather)
        o.addProperty("chart", showElevationChart); o.addProperty("climbs", showClimbLabels)
        o.addProperty("km", showKmMarkers); o.addProperty("summary", showSummary); o.addProperty("photoDim", darkenPhoto)
        o.addProperty("title", title); o.addProperty("place", location); o.addProperty("handle", handle); o.addProperty("photoPath", photoPath)
    }

    companion object {
        fun fromJson(e: JsonObject?): TrailVideoPrefs {
            if (e == null) return TrailVideoPrefs()
            fun s(k: String, d: String) = e.get(k)?.takeIf { it.isJsonPrimitive }?.asString ?: d
            fun n(k: String, d: Int) = e.get(k)?.takeIf { it.isJsonPrimitive }?.asInt ?: d
            fun b(k: String, d: Boolean) = e.get(k)?.takeIf { it.isJsonPrimitive }?.asBoolean ?: d
            return TrailVideoPrefs(
                shape=s("shape","circle"), palette=s("palette","orange"), statLayout=s("stats","classic"), durationSec=n("duration",20),
                cardStyle=s("card","none"), motion=s("motion","auto"), metricMode=s("metricMode","auto"),
                metrics=e.get("metrics")?.takeIf { it.isJsonArray }?.asJsonArray?.mapNotNull { it.takeIf { q -> q.isJsonPrimitive }?.asString } ?: listOf("pace","hr","gain","time"),
                extraMetrics=b("extraMetrics",false), showPeak=b("peak",true),
                showGradePill=b("gradePill",true), panelEntrance=b("panelEntrance",false),
                background=s("bg","mountain"), solidBackground=s("bgc","#14100E"), accent=s("accent",""),
                tilt=n("tilt",58), reliefPercent=n("relief",34), terrainScale=n("scale",1),
                zoomPercent=n("zoom",100), baseY=n("baseY",6),
                centerX=n("cx",0), centerY=n("cy",0), rotation=n("rotation",0),
                contour=b("contour",true), hillshade=b("hillshade",true), progressBar=b("bar",true), safeStory=b("safe",false),
                showHeader=b("header",true), showLocation=b("location",true), showWeather=b("weather",true),
                showElevationChart=b("chart",true), showClimbLabels=b("climbs",false), showKmMarkers=b("km",true),
                showSummary=b("summary",false), darkenPhoto=n("photoDim",40),
                title=s("title",""), location=s("place",""), handle=s("handle",""), photoPath=s("photoPath",""),
            ).sanitized()
        }
    }
}

data class RouteVideoPrefs(
    /** Susunan judul, grafik, dan data (lihat [RouteVideoLayout]). */
    val layout: RouteVideoLayout = RouteVideoLayout(),
    /** true = angka berjalan mengikuti posisi pelari; false = ringkasan total. */
    val live: Boolean = true,
    val durationSec: Int = 15,
    /** Sudut kamera dari bidang datar, derajat (20..80). */
    val tilt: Int = 52,
    /** Pengali tinggi medan (1..4). */
    val exaggeration: Double = 1.5,
    /** Total putaran kamera sepanjang video, derajat (0..180); dipakai mode orbit. */
    val orbit: Int = 50,
    /** orbit, chase (ikuti arah lari), atau top (dari atas, utara di atas). */
    val cameraMode: String = "orbit",
    val lineColor: String = "#C6F432",
    /** Warna garis rute: solid, hr, pace, grade. */
    val lineMode: String = "solid",
    /** Bendera per km (dengan pace km itu) di sepanjang rute. */
    val kmMarkers: Boolean = true,
    /** Bendera start dan finish. */
    val flagEnds: Boolean = true,
    /** Bendera titik tertinggi (puncak). */
    val flagPeak: Boolean = true,
    /** Bendera tanjakan terberat. */
    val flagSteep: Boolean = true,
    /** Bendera 1 km tercepat. */
    val flagFast: Boolean = true,
    /** Bendera titik detak jantung tertinggi. */
    val flagHrMax: Boolean = true,
    /** Bayangan relief (hillshade) pada medan. Mati = medan rata terang. */
    val hillshade: Boolean = true,
    /** Kabut jarak yang meredupkan medan yang jauh. */
    val fog: Boolean = true,
    /** Render lanjut di latar belakang dengan notifikasi. Mati = render berhenti bila layar ditutup. */
    val bgRender: Boolean = true,
    /** Ketebalan garis rute dalam persen dari ukuran bawaan (50..250). */
    val lineWidth: Int = 100,
    /** 9:16, 4:5, 1:1, atau 16:9. */
    val aspect: String = "9:16",
    /** hd (1080 px sisi pendek) atau sd (720 px). */
    val quality: String = "hd",
    /** Judul sendiri; kosong = nama aktivitas. */
    val titleText: String = "",
    /** Baris kedua di bawah judul (mis. lokasi atau nama event); kosong = tidak ada. */
    val subtitle: String = "",
    /** Tampilkan tanggal di bawah judul. */
    val showDate: Boolean = true,
    /** Kartu ringkasan (jarak, waktu, pace, naik) selama beberapa detik di akhir video. */
    val summary: Boolean = true,
    /** Tata letak buatan pengguna (maksimal 12). */
    val presets: List<LayoutPreset> = emptyList(),
    /** Pengaturan khusus mode Trail 3D; tetap tersimpan saat berpindah layout. */
    val trail: TrailVideoPrefs = TrailVideoPrefs(),
    /** standard = peta 3D; trail = komposisi Trail 3D; hud = editor video POV. */
    val videoLayout: String = "standard",
) {
    fun sanitized(): RouteVideoPrefs = copy(
        layout = layout.sanitized(),
        cameraMode = if (cameraMode in RouteVideoKeys.CAMERA_MODES) cameraMode else "orbit",
        lineMode = if (lineMode in RouteVideoColors.MODES) lineMode else "solid",
        aspect = if (aspect in RouteVideoFormat.ASPECTS) aspect else "9:16",
        quality = if (quality == "sd") "sd" else "hd",
        presets = presets.filter { it.name.isNotBlank() }.map { it.sanitized() }.distinctBy { it.name }.take(12),
        lineWidth = lineWidth.coerceIn(50, 250),
        durationSec = durationSec.coerceIn(6, 40),
        tilt = tilt.coerceIn(20, 80),
        exaggeration = if (exaggeration.isFinite()) exaggeration.coerceIn(1.0, 4.0) else 1.5,
        orbit = orbit.coerceIn(0, 180),
        lineColor = if (HEX.matches(lineColor)) lineColor else "#C6F432",
        titleText = titleText.take(60), subtitle = subtitle.take(80), trail = trail.sanitized(),
        videoLayout = if (videoLayout in listOf("standard", "trail", "hud")) videoLayout else "standard",
    )

    /** Ubah susunan lewat [f] (mis. `prefs.withLayout { it.copy(swap = !it.swap) }`). */
    fun withLayout(f: (RouteVideoLayout) -> RouteVideoLayout): RouteVideoPrefs = copy(layout = f(layout))

    /** Apakah bendera jenis [kind] (start, finish, km, peak, steep, fast, hrmax) ditampilkan. */
    fun showsAnchor(kind: String): Boolean = when (kind) {
        "km" -> kmMarkers
        "start", "finish" -> flagEnds
        "peak" -> flagPeak
        "steep" -> flagSteep
        "fast" -> flagFast
        "hrmax" -> flagHrMax
        else -> false
    }

    fun toJson(): String {
        val o = JsonObject()
        o.add("layout", layout.toJson())
        o.addProperty("live", live); o.addProperty("dur", durationSec); o.addProperty("tilt", tilt)
        o.addProperty("ex", exaggeration); o.addProperty("orbit", orbit); o.addProperty("cm", cameraMode)
        o.addProperty("lc", lineColor)
        o.addProperty("lm", lineMode); o.addProperty("km", kmMarkers)
        o.addProperty("fe", flagEnds); o.addProperty("fp", flagPeak); o.addProperty("fs", flagSteep)
        o.addProperty("ff", flagFast); o.addProperty("fh", flagHrMax)
        o.addProperty("hs", hillshade); o.addProperty("fg", fog); o.addProperty("bgr", bgRender)
        o.addProperty("lw", lineWidth)
        o.addProperty("asp", aspect); o.addProperty("q", quality)
        o.addProperty("tt", titleText); o.addProperty("st", subtitle); o.addProperty("sd", showDate); o.addProperty("sm", summary)
        o.add("presets", JsonArray().also { a -> presets.forEach { a.add(it.toJsonObject()) } })
        o.add("trail", trail.toJson()); o.addProperty("videoLayout", videoLayout)
        return o.toString()
    }

    companion object {
        private val HEX = Regex("#[0-9a-fA-F]{6}")

        /** Membaca JSON hasil [toJson]; JSON rusak atau kosong menghasilkan pengaturan bawaan. Format lama (grid panel) dimigrasi. */
        fun fromJson(json: String?): RouteVideoPrefs {
            val d = RouteVideoPrefs()
            val o = runCatching { JsonParser.parseString(json ?: "").asJsonObject }.getOrNull() ?: return d
            fun num(k: String): Double? = o.get(k)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asDouble
            fun str(k: String, def: String) = o.get(k)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isString }?.asString ?: def
            fun bool(k: String, def: Boolean) = o.get(k)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isBoolean }?.asBoolean ?: def
            val layout = o.get("layout")?.takeIf { it.isJsonObject }?.let { RouteVideoLayout.fromJson(it.asJsonObject) }
                ?: if (o.has("panels") || o.has("ink")) {
                    RouteVideoLayout.fromLegacy(o.get("panels")?.takeIf { it.isJsonArray }?.asJsonArray, str("ink", "w"))
                } else d.layout
            val legacyFlags = bool("lb", d.flagEnds)   // versi lama: satu sakelar untuk start/finish/puncak/tanjakan
            val presets = o.get("presets")?.takeIf { it.isJsonArray }?.asJsonArray?.mapNotNull { LayoutPreset.fromJson(it) }.orEmpty()
            return RouteVideoPrefs(
                layout = layout,
                live = bool("live", d.live),
                durationSec = num("dur")?.toInt() ?: d.durationSec,
                tilt = num("tilt")?.toInt() ?: d.tilt,
                exaggeration = num("ex") ?: d.exaggeration,
                orbit = num("orbit")?.toInt() ?: d.orbit,
                cameraMode = str("cm", d.cameraMode),
                lineColor = str("lc", d.lineColor),
                lineMode = str("lm", d.lineMode), kmMarkers = bool("km", d.kmMarkers),
                flagEnds = bool("fe", legacyFlags), flagPeak = bool("fp", legacyFlags), flagSteep = bool("fs", legacyFlags),
                flagFast = bool("ff", d.flagFast), flagHrMax = bool("fh", d.flagHrMax),
                hillshade = bool("hs", d.hillshade), fog = bool("fg", d.fog), bgRender = bool("bgr", d.bgRender),
                lineWidth = num("lw")?.toInt() ?: d.lineWidth,
                aspect = str("asp", d.aspect), quality = str("q", d.quality),
                titleText = str("tt", d.titleText), subtitle = str("st", d.subtitle),
                showDate = bool("sd", d.showDate), summary = bool("sm", d.summary),
                presets = presets,
                trail = TrailVideoPrefs.fromJson(o.get("trail")?.takeIf { it.isJsonObject }?.asJsonObject),
                videoLayout = str("videoLayout", "standard"),
            ).sanitized()
        }
    }
}


/** Data satu frame. [pace] menit/km (null = berhenti/tak ada data), [grade] persen. */
class FrameStats(
    val idx: Int, val frac: Double, val distM: Double, val sec: Int,
    val pace: Double?, val hr: Int?, val grade: Double?, val ele: Double?, val gain: Double, val cad: Int?,
)

/**
 * Jejak aktivitas per sampel (1 Hz): posisi, jarak, waktu gerak, HR, cadence, elevasi, dan gradien.
 * Elevasi dihaluskan; gradien dan total naik diturunkan darinya bila tidak tersedia.
 * [gradeRaw] dan [ele] berisi NaN untuk nilai yang tidak diketahui.
 */
class RouteVideoTrack(
    val lat: DoubleArray, val lon: DoubleArray, val dist: DoubleArray, val sec: IntArray,
    val hr: IntArray, val cad: IntArray, ele: DoubleArray, gradeRaw: DoubleArray,
    val title: String, val dateText: String, val bike: Boolean = false, officialGain: Int? = null,
    val weatherTempC: Double? = null, val weatherCode: Int? = null,
    val gapPace: Double? = null, val vamAvg: Double? = null,
    val hasGpsRoute: Boolean = true,
) {
    val n: Int = dist.size
    val totalM: Double = dist.last()
    val totalSec: Int = sec.last()
    val eleS: DoubleArray = smooth(fillForward(ele), 7)
    val hasEle: Boolean = eleS.any { it.isFinite() }
    val gradeS: DoubleArray
    val gainCum: DoubleArray

    init {
        require(n >= 2 && lat.size == n && lon.size == n && sec.size == n && hr.size == n && cad.size == n && ele.size == n && gradeRaw.size == n)
        val finite = gradeRaw.count { it.isFinite() }
        gradeS = if (finite * 2 >= n) smooth(gradeRaw, 10).map { if (it.isFinite()) it.coerceIn(-45.0, 45.0) else it }.toDoubleArray()
        else computeGrade()
        val cum = DoubleArray(n)
        for (i in 1 until n) {
            val a = eleS[i - 1]; val b = eleS[i]
            cum[i] = cum[i - 1] + if (a.isFinite() && b.isFinite() && b > a) b - a else 0.0
        }
        // Total naik mengikuti angka resmi aktivitas bila ada, supaya sama dengan yang tampil di aplikasi.
        val k = if (officialGain != null && officialGain > 0 && cum.last() > 0.5) officialGain / cum.last() else 1.0
        gainCum = DoubleArray(n) { cum[it] * k }
    }

    private fun computeGrade(): DoubleArray {
        val g = DoubleArray(n) { Double.NaN }
        if (!hasEle) return g
        var k = 0; var j = 0
        for (i in 0 until n) {
            while (k < i && dist[k] < dist[i] - 20.0) k++
            if (j < i) j = i
            while (j < n - 1 && dist[j + 1] <= dist[i] + 20.0) j++
            val dd = dist[j] - dist[k]
            if (dd >= 10.0) g[i] = ((eleS[j] - eleS[k]) / dd * 100.0).coerceIn(-45.0, 45.0)
        }
        return g
    }

    /** Indeks pertama dengan jarak >= [m] (dibatasi ke indeks terakhir). */
    fun indexAtDist(m: Double): Int {
        var lo = 0; var hi = n - 1
        while (lo < hi) { val mid = (lo + hi) ushr 1; if (dist[mid] >= m) hi = mid else lo = mid + 1 }
        return lo
    }

    /** Cache hasil hitung turunan (warna, legenda) per jejak. */
    internal val cache = java.util.concurrent.ConcurrentHashMap<String, Any>()

    /** Bagian jarak (0..1) yang sudah ditempuh pada detik ke-[t] (waktu gerak). */
    fun fracAtTime(t: Double): Double {
        if (t <= 0.0) return 0.0
        if (t >= sec.last()) return 1.0
        var lo = 0; var hi = n - 1
        while (lo < hi) { val mid = (lo + hi) ushr 1; if (sec[mid] >= t) hi = mid else lo = mid + 1 }
        if (lo == 0) return 0.0
        val a = sec[lo - 1].toDouble(); val b = sec[lo].toDouble()
        val f = if (b > a) ((t - a) / (b - a)).coerceIn(0.0, 1.0) else 1.0
        return ((dist[lo - 1] + (dist[lo] - dist[lo - 1]) * f) / totalM).coerceIn(0.0, 1.0)
    }

    /** Detik (waktu gerak) saat jarak [d] tercapai; di luar rute diekstrapolasi dengan kecepatan rata-rata. */
    fun timeAtDist(d: Double): Double {
        if (d <= 0.0) return 0.0
        if (d >= totalM) return totalSec + (d - totalM) / (totalM / totalSec.coerceAtLeast(1))
        val i = indexAtDist(d)
        if (i == 0) return sec[0].toDouble()
        val dd = dist[i] - dist[i - 1]
        val f = if (dd > 0) ((d - dist[i - 1]) / dd).coerceIn(0.0, 1.0) else 1.0
        return sec[i - 1] + (sec[i] - sec[i - 1]) * f
    }

    /** Elevasi tersampel merata sepanjang jarak, untuk grafik profil. NaN bila tidak ada data elevasi. */
    fun profileSamples(count: Int): DoubleArray {
        if (!hasEle) return DoubleArray(count) { Double.NaN }
        return DoubleArray(count) { eleS[indexAtDist(totalM * it / (count - 1).coerceAtLeast(1))] }
    }

    fun statsAt(r: Double, live: Boolean): FrameStats {
        if (!live) {
            val hrs = hr.filter { it >= 30 }; val cads = cad.filter { it > 0 }
            val avgPace = if (totalM > 0 && totalSec > 0) totalSec / 60.0 / (totalM / 1000.0) else null
            return FrameStats(
                n - 1, 1.0, totalM, totalSec, avgPace,
                if (hrs.isEmpty()) null else hrs.average().roundToInt(),
                gradeS.filter { it.isFinite() }.maxOrNull(),
                eleS.filter { it.isFinite() }.maxOrNull(), gainCum.last(),
                if (cads.isEmpty()) null else cads.average().roundToInt(),
            )
        }
        val frac = r.coerceIn(0.0, 1.0)
        val i = indexAtDist(frac * totalM)
        val k = max(0, i - 10); val j = min(n - 1, i + 10)
        val dd = dist[j] - dist[k]; val dt = (sec[j] - sec[k]).toDouble()
        val pace = if (dd >= 8.0 && dt > 0) (dt / 60.0 / (dd / 1000.0)).takeIf { it in 1.0..25.0 } else null
        fun avgPos(a: IntArray, thr: Int): Int? {
            var s = 0; var c = 0
            for (q in max(0, i - 2)..min(n - 1, i + 2)) if (a[q] >= thr) { s += a[q]; c++ }
            return if (c == 0) null else (s.toDouble() / c).roundToInt()
        }
        return FrameStats(
            i, frac, dist[i], sec[i], pace, avgPos(hr, 30),
            gradeS[i].takeIf { it.isFinite() }, eleS[i].takeIf { it.isFinite() }, gainCum[i], avgPos(cad, 1),
        )
    }

    companion object {
        /** Isi NaN dengan nilai valid sebelumnya (dan nilai valid pertama untuk awal deret). */
        internal fun fillForward(a: DoubleArray): DoubleArray {
            val out = a.copyOf()
            val first = out.indexOfFirst { it.isFinite() }
            if (first < 0) return out
            for (i in 0 until first) out[i] = out[first]
            for (i in first + 1 until out.size) if (!out[i].isFinite()) out[i] = out[i - 1]
            return out
        }

        /** Rata-rata bergerak ±[half] sampel yang mengabaikan NaN. */
        internal fun smooth(a: DoubleArray, half: Int): DoubleArray {
            val n = a.size
            val pre = DoubleArray(n + 1); val cnt = IntArray(n + 1)
            for (i in 0 until n) {
                val ok = a[i].isFinite()
                pre[i + 1] = pre[i] + if (ok) a[i] else 0.0
                cnt[i + 1] = cnt[i] + if (ok) 1 else 0
            }
            return DoubleArray(n) { i ->
                val lo = max(0, i - half); val hi = min(n - 1, i + half)
                val c = cnt[hi + 1] - cnt[lo]
                if (c == 0) Double.NaN else (pre[hi + 1] - pre[lo]) / c
            }
        }

        private fun haversine(a: RouteGeo.LatLon, b: RouteGeo.LatLon): Double {
            val r = 6_371_000.0
            val p1 = Math.toRadians(a.lat); val p2 = Math.toRadians(b.lat)
            val dp = p2 - p1; val dl = Math.toRadians(b.lon - a.lon)
            val h = sin(dp / 2) * sin(dp / 2) + cos(p1) * cos(p2) * sin(dl / 2) * sin(dl / 2)
            return 2 * r * atan2(sqrt(h), sqrt(1 - h))
        }

        /**
         * Bangun dari detail aktivitas. Null bila tidak ada deret per detik atau rute GPS.
         * Jejak GPS per detik dipakai bila ada; aktivitas lama jatuh ke rute sederhana (±140 titik) yang diinterpolasi menurut jarak.
         */
        fun from(d: ActDetail, title: String, dateText: String): RouteVideoTrack? {
            val ts = d.timeSeries?.takeIf { it.seconds.size >= 20 && it.distanceMeters.size == it.seconds.size } ?: return null
            val n = ts.seconds.size
            val dist = DoubleArray(n)
            for (i in 0 until n) dist[i] = max(if (i == 0) 0.0 else dist[i - 1], ts.distanceMeters[i].takeIf { it.isFinite() } ?: 0.0)
            if (dist.last() < 100.0) return null
            val lat = DoubleArray(n); val lon = DoubleArray(n)
            val gt = d.gpsTrack?.takeIf { it.size == n }
            if (gt != null) {
                for (i in 0 until n) { lat[i] = gt.lat[i]; lon[i] = gt.lon[i] }
            } else {
                val frame = d.geo ?: return null
                if (!d.hasRoute) return null
                val pts = RouteGeo.toLatLon(frame, d.route)
                val cum = DoubleArray(pts.size)
                for (i in 1 until pts.size) cum[i] = cum[i - 1] + haversine(pts[i - 1], pts[i])
                val total = cum.last()
                if (total <= 0.0) return null
                var k = 0
                for (i in 0 until n) {
                    val target = dist[i] / dist.last() * total
                    while (k < pts.size - 2 && cum[k + 1] < target) k++
                    val seg = cum[k + 1] - cum[k]
                    val f = if (seg > 0) ((target - cum[k]) / seg).coerceIn(0.0, 1.0) else 0.0
                    lat[i] = pts[k].lat + (pts[k + 1].lat - pts[k].lat) * f
                    lon[i] = pts[k].lon + (pts[k + 1].lon - pts[k].lon) * f
                }
            }
            val ele = DoubleArray(n) { ts.elevationMeters.getOrNull(it) ?: Double.NaN }
            if (ele.none { it.isFinite() } && d.profile.size >= 2) {
                // Tanpa elevasi per detik: interpolasi dari profil (km, m) menurut jarak.
                var k = 0
                for (i in 0 until n) {
                    val km = dist[i] / 1000.0
                    while (k < d.profile.size - 2 && d.profile[k + 1].first < km) k++
                    val a = d.profile[k]; val b = d.profile[k + 1]
                    val f = if (b.first > a.first) ((km - a.first) / (b.first - a.first)).coerceIn(0.0, 1.0) else 0.0
                    ele[i] = a.second + (b.second - a.second) * f
                }
            }
            val sec = IntArray(n) { ts.seconds[it] }
            for (i in 1 until n) if (sec[i] < sec[i - 1]) sec[i] = sec[i - 1]
            return RouteVideoTrack(
                lat, lon, dist, sec,
                IntArray(n) { ts.heartRateBpm.getOrElse(it) { 0 } },
                IntArray(n) { ts.cadenceSpm.getOrElse(it) { 0 } },
                ele, DoubleArray(n) { ts.grade.getOrNull(it) ?: Double.NaN },
                title, dateText, d.bike, d.gain, d.weatherTempC ?: d.weather?.tempC, d.weather?.code, d.gapPace, d.vam?.avg?.toDouble(),
            )
        }

        /** Build activity metrics for POV HUD even when an indoor activity has no GPS route. */
        fun fromHud(d: ActDetail, title: String, dateText: String): RouteVideoTrack? {
            val ts = d.timeSeries?.takeIf { it.seconds.size >= 20 && it.distanceMeters.size == it.seconds.size } ?: return null
            val n = ts.seconds.size
            val dist = DoubleArray(n)
            for (i in 0 until n) dist[i] = max(if (i == 0) 0.0 else dist[i - 1], ts.distanceMeters[i].takeIf { it.isFinite() } ?: 0.0)
            val sec = IntArray(n) { ts.seconds[it] }
            for (i in 1 until n) if (sec[i] < sec[i - 1]) sec[i] = sec[i - 1]
            val ele = DoubleArray(n) { ts.elevationMeters.getOrNull(it) ?: Double.NaN }
            if (ele.none { it.isFinite() } && d.profile.size >= 2) {
                var k = 0
                for (i in 0 until n) {
                    val km = dist[i] / 1000.0
                    while (k < d.profile.size - 2 && d.profile[k + 1].first < km) k++
                    val a = d.profile[k]; val b = d.profile[k + 1]
                    val f = if (b.first > a.first) ((km - a.first) / (b.first - a.first)).coerceIn(0.0, 1.0) else 0.0
                    ele[i] = a.second + (b.second - a.second) * f
                }
            }
            return RouteVideoTrack(
                DoubleArray(n), DoubleArray(n), dist, sec,
                IntArray(n) { ts.heartRateBpm.getOrElse(it) { 0 } },
                IntArray(n) { ts.cadenceSpm.getOrElse(it) { 0 } },
                ele, DoubleArray(n) { ts.grade.getOrNull(it) ?: Double.NaN },
                title, dateText, d.bike, d.gain, d.weatherTempC ?: d.weather?.tempC, d.weather?.code,
                d.gapPace, d.vam?.avg?.toDouble(), false,
            )
        }
    }
}

/** Teks panel: label, nilai, satuan (bahasa Indonesia, koma desimal). */
object RouteVideoText {
    class Cell(val label: String, val value: String, val unit: String)

    private fun f(x: Double, dp: Int): String = String.format(Locale.US, "%.${dp}f", x).replace('.', ',')

    fun cell(key: String, st: FrameStats, live: Boolean, bike: Boolean): Cell? = when (key) {
        "jarak" -> Cell("JARAK", f(st.distM / 1000.0, 2), "km")
        "waktu" -> Cell("WAKTU", Js.durStr(st.sec / 60.0), "")
        "pace" ->
            if (bike) Cell(if (live) "KECEPATAN" else "KECEPATAN RATA2", st.pace?.let { f(60.0 / it, 1) } ?: "–", "km/j")
            else Cell(if (live) "PACE" else "PACE RATA2", st.pace?.let { Js.paceStr(it) } ?: "–", "/km")
        "hr" -> Cell(if (live) "DETAK JANTUNG" else "HR RATA2", st.hr?.toString() ?: "–", "bpm")
        "grad" -> Cell(
            if (live) "GRADIEN" else "GRADIEN MAKS",
            st.grade?.let { String.format(Locale.US, "%+.1f", it).replace('.', ',') } ?: "–", "%",
        )
        "elev" -> Cell(if (live) "ELEVASI" else "ELEVASI MAKS", st.ele?.let { it.roundToInt().toString() } ?: "–", "m")
        "gain" -> Cell("TOTAL NAIK", st.gain.roundToInt().toString(), "m")
        "cad" -> Cell(if (live) "CADENCE" else "CADENCE RATA2", st.cad?.toString() ?: "–", "spm")
        else -> null
    }

    /** Label dan keterangan untuk bendera di peta. */
    fun anchorLabel(a: Anchor, t: RouteVideoTrack): Pair<String, String> = when (a.kind) {
        "start" -> "START" to ""
        "finish" -> "FINISH" to "${f(t.totalM / 1000.0, 2)} km"
        "km" -> {
            val p = t.kmPace(a)
            "KM ${a.km}" to when {
                p == null -> ""
                t.bike -> "${f(60.0 / p, 1)} km/j"
                else -> "${Js.paceStr(p)} /km"
            }
        }
        "peak" -> "PUNCAK" to "${a.value.roundToInt()} m"
        "steep" -> "TANJAKAN" to "+${f(a.value, 1)}%"
        "fast" -> "TERCEPAT" to if (t.bike) "${f(60.0 / a.value, 1)} km/j" else "${Js.paceStr(a.value)} /km"
        "hrmax" -> "HR MAKS" to "${a.value.roundToInt()} bpm"
        else -> "" to ""
    }

    /** Panel selisih ghost: "UNGGUL 0:12" atau "TERTINGGAL 0:12". */
    fun ghostCell(g: GhostInfo): Cell {
        val v = Js.durStr(kotlin.math.abs(g.gapSec) / 60.0)
        val unit = if (g.gapSec >= 1.0) "unggul" else if (g.gapSec <= -1.0) "tertinggal" else "sama"
        return Cell("VS " + g.name.uppercase().take(16), if (unit == "sama") "0:00" else v, unit)
    }

    private val MONTHS = listOf("Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des")

    /** "2026-11-10" menjadi "10 Nov 2026"; teks lain dikembalikan apa adanya. */
    fun dateId(iso: String): String {
        val p = iso.take(10).split("-")
        if (p.size != 3) return iso
        val y = p[0].toIntOrNull(); val m = p[1].toIntOrNull(); val d = p[2].toIntOrNull()
        if (y == null || m == null || d == null || m !in 1..12) return iso
        return "$d ${MONTHS[m - 1]} $y"
    }
}

/** Pose kamera pada posisi video [p] (0..1). Murni fungsi supaya pratinjau dan hasil render identik. */
class CameraPose(
    val azimuthDeg: Double, val pitchDeg: Double, val distMul: Double, val follow: Double,
    /** Bagian jarak aktivitas utama (0..1). */
    val routeFrac: Double,
    /** Bagian jarak ghost (0..1) pada saat yang sama, null bila tanpa ghost. */
    val ghostFrac: Double? = null,
    /** Azimut kamera yang berada tepat di belakang pelari (mode chase), berlaku seberat [chaseWeight] (0..1). */
    val chaseAzDeg: Double = 0.0,
    val chaseWeight: Double = 0.0,
)

object RouteVideoCamera {
    /** Bagian awal (pengantar) dan akhir (kamera menjauh) video; di antaranya pelari menempuh rute. */
    const val T_IN = 0.07
    const val T_OUT = 0.90

    private fun smooth(x: Double): Double { val t = x.coerceIn(0.0, 1.0); return t * t * (3 - 2 * t) }

    /**
     * Pose pada posisi video [p]. Mode kamera: orbit (berputar pelan), chase (mengikuti arah lari; butuh [track]),
     * top (dari atas, utara di atas).
     */
    fun at(p: Double, prefs: RouteVideoPrefs, race: RouteVideoRace? = null, track: RouteVideoTrack? = null): CameraPose {
        val q = p.coerceIn(0.0, 1.0)
        val r = ((q - T_IN) / (T_OUT - T_IN)).coerceIn(0.0, 1.0)
        val intro = 1.0 - smooth(q / 0.14)
        val outro = smooth((q - 0.88) / 0.12)
        val frac = if (race == null) r else race.fractions(r).first
        var az = prefs.orbit * (q - 0.3)
        var pitch = prefs.tilt + 22.0 * intro - 6.0 * outro
        var follow = 0.6 * smooth(q / 0.2) * (1.0 - outro)
        var chaseW = 0.0; var chaseAz = 0.0
        when (prefs.cameraMode) {
            "top" -> { az = 0.0; pitch = 85.0; follow = 0.25 * smooth(q / 0.2) * (1.0 - outro) }
            "chase" -> if (track != null) { chaseW = smooth(q / 0.2) * (1.0 - outro); chaseAz = -track.bearingAt(frac) }
        }
        return CameraPose(
            azimuthDeg = az,
            pitchDeg = pitch.coerceIn(15.0, 85.0),
            distMul = 1.0 + 0.5 * intro + 0.4 * outro,
            follow = follow,
            routeFrac = frac,
            ghostFrac = race?.fractions(r)?.second,
            chaseAzDeg = chaseAz, chaseWeight = chaseW,
        )
    }
}
