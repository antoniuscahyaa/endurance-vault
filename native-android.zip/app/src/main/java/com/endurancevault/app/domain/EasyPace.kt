package com.endurancevault.app.domain

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters

/**
 * Pace easy dari lari tercatat (padanan easyWeeks dan easyPaceEst di 03-perencana-gear-statistik.js).
 * Hanya lari dengan HR rata-rata di bawah batas easy (zona 2 atas) yang dihitung, tanpa sepeda dan tanpa
 * lari yang terlalu menanjak (lebih dari 20 m D+ per km). Pace per pekan dibobot jarak.
 */
object EasyPace {
    class Run(val dateIso: String, val km: Double, val min: Double, val hr: Int?, val type: String = "run", val gain: Int? = null)
    class Week(val week: String, val pace: Double, val hr: Double, val n: Int, val km: Double)
    class Est(val pace: Double, val week: String, val n: Int)

    fun mondayKey(dateIso: String): String =
        LocalDate.parse(dateIso.take(10)).with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).toString()

    /** Batas HR easy: zona 2 atas, sama dengan zoneSessFor(S).hr di web. */
    fun sessHr(s: PlanSettings): Int = Zones.cuts(s).lo[2] - 1

    fun weeks(runs: List<Run>, sessHr: Int): List<Week> {
        class Acc(var km: Double = 0.0, var min: Double = 0.0, var n: Int = 0, var hw: Double = 0.0)
        val wk = HashMap<String, Acc>()
        for (l in runs) {
            val hr = l.hr ?: continue
            if (l.type == "bike" || !(l.km > 0 && l.min > 0 && hr > 0 && hr <= sessHr)) continue
            val g = l.gain
            if (g != null && g / l.km > 20) continue
            val o = wk.getOrPut(mondayKey(l.dateIso)) { Acc() }
            o.km += l.km; o.min += l.min; o.n++; o.hw += hr * l.min
        }
        return wk.keys.sorted().map { m -> val o = wk.getValue(m); Week(m, o.min / o.km, o.hw / o.min, o.n, o.km) }
    }

    /** Pekan terakhir sebelum pekan berjalan; null bila belum ada data. */
    fun estimate(runs: List<Run>, sessHr: Int, today: LocalDate = LocalDate.now()): Est? {
        val thisMon = mondayKey(today.toString())
        val b = weeks(runs, sessHr).lastOrNull { it.week < thisMon } ?: return null
        return Est(b.pace, b.week, b.n)
    }

    /** Rata-rata beberapa lari easy terakhir (bukan per pekan). */
    class Recent(val pace: Double, val n: Int, val firstDate: String, val lastDate: String, val km: Double)

    private fun qualifies(l: Run, sessHr: Int): Boolean {
        val hr = l.hr ?: return false
        if (l.type == "bike" || !(l.km > 0 && l.min > 0 && hr > 0 && hr <= sessHr)) return false
        val g = l.gain
        return !(g != null && g / l.km > 20)
    }

    /**
     * Pace easy dari [n] lari easy terakhir (kriteria sama dengan [weeks]: HR rata-rata di bawah batas easy,
     * bukan sepeda, tidak terlalu menanjak). Dibobot jarak (total menit / total km). Null bila belum ada data.
     */
    fun recentAverage(runs: List<Run>, sessHr: Int, n: Int = 5): Recent? {
        val pick = runs.filter { qualifies(it, sessHr) }.sortedByDescending { it.dateIso }.take(n)
        if (pick.isEmpty()) return null
        val km = pick.sumOf { it.km }
        val min = pick.sumOf { it.min }
        return Recent(min / km, pick.size, pick.last().dateIso.take(10), pick.first().dateIso.take(10), km)
    }
}
