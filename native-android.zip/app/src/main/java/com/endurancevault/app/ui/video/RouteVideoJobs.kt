package com.endurancevault.app.ui.video

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.endurancevault.app.data.TerrainScene
import com.endurancevault.app.domain.RouteVideoPrefs
import com.endurancevault.app.domain.RouteVideoTrack
import com.endurancevault.app.ui.sticker.StickerFonts
import java.io.File
import java.util.concurrent.CancellationException
import java.util.concurrent.Executors
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Keadaan render video; [key] mengidentifikasi aktivitas yang dirender. */
sealed class RenderState {
    object Idle : RenderState()
    class Running(val key: String, val label: String, val progress: Float) : RenderState()
    class Done(val key: String, val label: String, val file: File) : RenderState()
    class Failed(val key: String, val label: String, val message: String) : RenderState()
}

/**
 * Render video yang tetap jalan walau layar ditutup: pekerjaan hidup di cakupan aplikasi, sementara
 * [RouteVideoService] menampilkan notifikasi progres dan menjaga proses tetap hidup. Satu render pada satu waktu.
 * Bila proses aplikasi dimatikan sistem, render hilang dan harus diulang.
 */
object RouteVideoJobs {
    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "route-video-render") }
    private val scope = CoroutineScope(SupervisorJob() + executor.asCoroutineDispatcher())
    private val _state = MutableStateFlow<RenderState>(RenderState.Idle)
    private var job: Job? = null

    val state: StateFlow<RenderState> get() = _state

    fun isRunning(): Boolean = _state.value is RenderState.Running

    /** Mulai render; mengembalikan false bila render lain masih berjalan. */
    @Synchronized
    fun start(
        ctx: Context, key: String, label: String, scene: TerrainScene, track: RouteVideoTrack, ghost: RouteVideoTrack?,
        prefs: RouteVideoPrefs, fonts: StickerFonts, out: File, foreground: Boolean = true,
    ): Boolean {
        if (isRunning()) return false
        val app = ctx.applicationContext
        _state.value = RenderState.Running(key, label, 0f)
        if (foreground) runCatching { ContextCompat.startForegroundService(app, Intent(app, RouteVideoService::class.java)) }
        job = scope.launch {
            val self = this
            val r = RouteVideoEncoder.encode(
                scene, track, ghost, prefs, fonts, out, { self.isActive },
                { _state.value = RenderState.Running(key, label, it) },
            )
            _state.value = r.fold(
                onSuccess = { RenderState.Done(key, label, out) as RenderState },
                onFailure = { if (it is CancellationException) RenderState.Idle else RenderState.Failed(key, label, it.message ?: "Render gagal.") },
            )
        }
        return true
    }

    fun cancel() { job?.cancel() }

    /** Batalkan hanya bila yang sedang berjalan adalah render untuk [key]. */
    fun cancelFor(key: String) { (_state.value as? RenderState.Running)?.takeIf { it.key == key }?.let { job?.cancel() } }

    /** Hapus hasil/galat terakhir (kembali ke Idle) bila tidak sedang berjalan. */
    fun clearResult() { if (!isRunning()) _state.value = RenderState.Idle }
}
