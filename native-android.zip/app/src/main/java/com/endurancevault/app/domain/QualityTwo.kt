package com.endurancevault.app.domain

import kotlin.math.max

/**
 * Sesi quality kedua (padanan q2Slot, q2Allowed, q2Stage, q2Pool, q2Make, q2Apply di 05-lomba-tema-prediksi.js).
 *
 * Dosis naik bertahap dalam 3 tahap sepanjang build sampai puncak: tahap 1 ringan (±40% menit keras sesi pertama),
 * tahap 2 sedang (±65%), tahap 3 penuh (±100%). Sesi kedua melengkapi sesi pertama. Menit keras dua sesi dibatasi
 * ±20% waktu lari mingguan; bila terlewat, sesi kedua diturunkan satu tahap. Hanya 5K, 10K, HM, FM, dan Performance
 * Build dengan 6 hari lari, dan hanya bila hari short jatuh dua hari sebelum long run.
 */

private val Q2_TYPES = setOf("5k", "10k", "hm", "fm", "pb")
private const val Q2_CAP = .2
private val Q2_FRAC = doubleArrayOf(0.0, .4, .65, 1.0)

internal val Q2_NOTE = listOf(
    "",
    " Sesi quality kedua, tahap 1 (ringan): dosis dijaga kecil supaya tubuh beradaptasi. Bila kaki berat, nyeri, atau tidur buruk, ganti dengan easy.",
    " Sesi quality kedua, tahap 2 (sedang): dosis naik bertahap. Bila kaki berat, nyeri, atau tidur buruk, ganti dengan easy.",
    " Sesi quality kedua, tahap 3 (penuh): intensitas sesuai tuntutan lomba. Bila kaki berat, nyeri, atau tidur buruk, ganti dengan easy.",
)

private fun q2Slot(s: PlanSettings): Boolean {
    val c = PlanEngine.restCfgOf(s)
    val roles = PlanEngine.weekRoles(s)
    for (d in 0 until 7) if (roles[d] == "short") return ((c.L - d) % 7 + 7) % 7 == 2
    return false
}

internal fun q2Allowed(s: PlanSettings): Boolean =
    s.qSess == "2" && s.rtype in Q2_TYPES && s.days == 6 && q2Slot(s)

/** @return tahap 0 (tidak ada sesi kedua) sampai 3 */
internal fun q2Stage(s: PlanSettings, phase: String, cut: Boolean, i: Int, q: Int, pb: Boolean, pbL: Int, bd: Int): Int {
    if (cut || (phase != Phases.BUILD && phase != Phases.PEAK) || !q2Allowed(s)) return 0
    if (pb) { val j = i - pbL; return if (j < pbL) 1 else if (j < 2 * pbL) 2 else 3 }
    val b0 = max(Js.roundI((q - 3) * 0.4), bd)
    val p = (i - b0).toDouble() / max(1, q - 1 - b0)
    return if (p < 1.0 / 3) 1 else if (p < 2.0 / 3) 2 else 3
}

internal class Q2Opt(val k: String, val min: Double, val band: List<Int>, val title: String, val detail: String)

/** Daftar sesi kedua yang mungkin untuk satu minggu, diurut dari menit keras terkecil. */
internal fun q2Pool(s: PlanSettings, rc: RC, wantHard: Boolean): List<Q2Opt> {
    val t = s.rtype
    val rp = racePaces(s)
    val b = thrBand(s) ?: listOf(164, 172)
    val mx = hrMaxEst(s)
    val ep = Js.parsePaceStr(s.pace)
    val wu = " Pemanasan 15 mnt easy, pendinginan 10 mnt easy."
    val th = "(HR ${s.thr}), jog 2 mnt antar set"
    val rb = RBAND[t] ?: RBAND.getValue("pb")
    val rband = if (mx in 140..240) listOf(Js.roundI(rb[0] * mx), Js.roundI(rb[1] * mx)) else emptyList()
    val w5 = rp?.p5 ?: (ep * .78); val w10 = rp?.p10 ?: (ep * .82)
    val wh = rp?.phm ?: (ep * .86); val wm = rp?.pfm ?: (ep * .9)
    val out = mutableListOf<Q2Opt>()

    fun thr(reps: Int, m: Int) {
        out.add(Q2Opt("thr", (reps * m).toDouble(), b, "Threshold",
            "Threshold $reps×$m mnt $th." + (if (rp != null) " Pace sekitar ${Js.paceStr(rp.thr)}/km." else "") + wu))
    }
    fun tempo(m: Int) {
        val lo = b[0] - 4; val hi = b[1] - 2
        out.add(Q2Opt("thr", m.toDouble(), listOf(lo, hi), "Tempo",
            "Tempo $m mnt tanpa henti di HR $lo–$hi (sedikit di bawah threshold)." +
                (if (rp != null) " Pace sekitar ${Js.paceStr((rp.thr + wh) / 2)}/km." else "") + wu))
    }
    fun vo2(txt: String, reps: Int, work: Double) {
        out.add(Q2Opt("vo2", Js.round(reps * work), if (mx in 140..240) listOf(Js.roundI(.9 * mx), 999) else emptyList(), "Interval VO2max",
            "$txt, jog 2–3 mnt antar repetisi." +
                (if (rp != null) " Pace sekitar ${Js.paceStr(rp.p5)}/km (usaha 3K–5K)." else " Usaha keras tapi terkendali (8–9 dari 10).") +
                " HR baru naik di repetisi ke-2 dan seterusnya, itu normal." + wu))
    }
    fun fart(n: Int) {
        out.add(Q2Opt("vo2", n.toDouble(), if (mx in 140..240) listOf(Js.roundI(.9 * mx), 999) else emptyList(), "Fartlek",
            "Fartlek $n×1 mnt kencang di usaha 10K–5K, jog 1 mnt antar repetisi. Usaha keras tapi terkendali (8–9 dari 10).$wu"))
    }
    fun rps(txt: String, reps: Int, work: Double, p: Double?) {
        out.add(Q2Opt("rp", Js.round(reps * work), rband, "Pace lomba ${rc.nm}",
            txt + (if (rp != null && p != null && p != 0.0) " Pace sekitar ${Js.paceStr(p)}/km." else " Usaha sesuai target lomba.") +
                " Jog 2–3 mnt antar repetisi." + wu))
    }

    if (!wantHard) {
        tempo(10); tempo(15); tempo(20); thr(2, 10); thr(3, 8); tempo(25); thr(3, 10); tempo(30); thr(3, 12); tempo(40)
    } else if (t == "5k") {
        fart(6); fart(8); vo2("4×3 mnt di usaha 3K–5K", 4, 3.0); vo2("5×3 mnt di usaha 3K–5K", 5, 3.0)
        rps("6×800 m di pace 5K", 6, .8 * w5, rp?.p5); rps("5×1000 m di pace 5K", 5, w5, rp?.p5)
    } else if (t == "10k") {
        fart(6); fart(8); vo2("4×4 mnt di usaha 3K–5K", 4, 4.0); vo2("5×4 mnt di usaha 3K–5K", 5, 4.0)
        rps("3×2 km di pace 10K", 3, 2 * w10, rp?.p10); rps("4×1,6 km di pace 10K", 4, 1.6 * w10, rp?.p10)
    } else if (t == "hm") {
        fart(6); rps("2×8 mnt di pace half marathon", 2, 8.0, rp?.phm); rps("2×12 mnt di pace half marathon", 2, 12.0, rp?.phm)
        rps("2×15 mnt di pace half marathon", 2, 15.0, rp?.phm); rps("2×20 mnt di pace half marathon", 2, 20.0, rp?.phm)
    } else if (t == "fm") {
        rps("2×8 mnt di pace maraton", 2, 8.0, rp?.pfm); rps("2×12 mnt di pace maraton", 2, 12.0, rp?.pfm)
        rps("2×4 km di pace maraton", 2, 4 * wm, rp?.pfm); rps("2×6 km di pace maraton", 2, 6 * wm, rp?.pfm)
    } else {
        fart(6); fart(8); vo2("4×3 mnt di usaha 3K–5K", 4, 3.0); vo2("5×3 mnt di usaha 3K–5K", 5, 3.0)
        vo2("5×4 mnt di usaha 3K–5K", 5, 4.0); vo2("6×3 mnt di usaha 3K–5K", 6, 3.0)
    }
    return out.sortedBy { it.min }
}

/** Pilih sesi kedua: pasangan komplementer sesi pertama, takaran menurut tahap, dibatasi menit keras mingguan. */
internal fun q2Make(s: PlanSettings, rc: RC, stage: Int, q1: PDay?, capMin: Double, fits: ((Q2Opt) -> Boolean)?): Q2Opt? {
    val t = s.rtype
    val q1min = if (q1 != null && (q1.qMin ?: 0.0) > 0) q1.qMin!! else 30.0
    var wantHard = !(q1 != null && (q1.qk == "vo2" || q1.qk == "rp"))
    if (t == "pb") {
        val pf = pbFocusOf(s)
        wantHard = if (pf == "vo2") true else if (pf == "thr" || pf == "vol") false else wantHard
    }
    val pool = q2Pool(s, rc, wantHard)
    if (pool.isEmpty()) return null
    val target = Q2_FRAC[stage] * q1min
    var idx = 0
    for (x in pool.indices) if (pool[x].min <= target * 1.15) idx = x
    fun ok(o: Q2Opt) = q1min + o.min <= capMin && (fits == null || fits(o))
    while (idx > 0 && !ok(pool[idx])) idx--
    return if (ok(pool[idx])) pool[idx] else null
}

/**
 * Mengubah hari short menjadi sesi quality kedua. Dipanggil sebelum qualBalance, jadi km sesi ikut diperkirakan dari
 * isinya dan selisihnya dibagi ke easy/medium (total km mingguan tidak naik).
 */
internal fun q2Apply(days: List<PDay>, s: PlanSettings, rc: RC, stage: Int, easyPace: Double? = null): Boolean {
    var q1: PDay? = null; var sd: PDay? = null; var tot = 0.0
    days.forEach { d ->
        tot += d.km
        if (d.role == "quality" && !d.bench && q1 == null) q1 = d
        if (d.role == "short" && sd == null) sd = d
    }
    val a = q1 ?: return false
    val z = sd ?: return false
    val ep = easyPace?.takeIf { it > 0 } ?: Js.parsePaceStr(s.pace)
    val cap = Q2_CAP * tot * ep
    // Muat tanpa menaikkan total km: selisih km sesi quality terhadap jatahnya harus bisa diserap easy/medium
    var slack = 0.0
    days.forEach { d ->
        if ((d.role == "easy" || d.role == "medium") && !d.bench && d.altMins == null && d.km > 0) {
            slack += max(0.0, d.km - max(3.0, Js.round(d.km * .7)))
        }
    }
    val e1 = qualEst(a, ep)
    val need1 = if (e1 != null) e1.km - a.km else 0.0
    val fits = { o: Q2Opt ->
        val probe = PDay(z.date, z.d, Kinds.QUALITY, "quality", "", 0.0, o.detail).also { it.qk = o.k }
        val e = qualEst(probe, ep)
        if (e == null) true else {
            val add = e.km - z.km
            add <= 0 || add + max(0.0, need1) <= slack
        }
    }
    val o = q2Make(s, rc, stage, a, cap, fits) ?: return false
    z.role = "quality"; z.kind = Kinds.QUALITY; z.grp = "quality"
    z.title = "Sesi kedua · " + o.title; z.detail = o.detail + Q2_NOTE[stage]
    z.qk = o.k; z.qMin = o.min; z.qBand = o.band; z.q2 = stage
    return true
}
