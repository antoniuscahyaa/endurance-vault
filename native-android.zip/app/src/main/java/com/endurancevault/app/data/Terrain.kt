package com.endurancevault.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Rect
import com.endurancevault.app.domain.Anchor
import com.endurancevault.app.domain.RouteGeo
import com.endurancevault.app.domain.RouteVideoTrack
import com.endurancevault.app.domain.allAnchors
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

/** Posisi bendera di medan: meter relatif pusat (x ke timur, z ke selatan). */
class SceneAnchor(val anchor: Anchor, val x: Float, val z: Float)

/**
 * Medan 3D di sekitar rute: grid tinggi persegi ([sizeM] meter per sisi, pusat di titik tengah rute), citra satelit yang
 * menutupi persis grid itu, dan titik rute dalam meter relatif terhadap pusat (x ke timur, z ke selatan).
 * [ghostX]/[ghostZ]/[ghostFrac] terisi bila ada aktivitas ghost.
 */
class TerrainScene(
    val n: Int,
    /** Tinggi medan (m), baris demi baris dari utara; ukuran n*n. */
    val heights: FloatArray,
    val sizeM: Float,
    val satellite: Bitmap?,
    val routeX: FloatArray,
    val routeZ: FloatArray,
    /** Bagian jarak aktivitas (0..1) di tiap titik rute. */
    val routeFrac: FloatArray,
    val anchors: List<SceneAnchor>,
    val ghostX: FloatArray?,
    val ghostZ: FloatArray?,
    val ghostFrac: FloatArray?,
    val demOk: Boolean,
) {
    val minH: Float = heights.minOrNull() ?: 0f
    val maxH: Float = heights.maxOrNull() ?: 0f

    /** Tinggi medan (m) di (x, z) meter relatif pusat, interpolasi bilinear. */
    fun heightAt(x: Float, z: Float): Float {
        val fx = ((x / sizeM + .5f) * (n - 1)).coerceIn(0f, n - 1f)
        val fz = ((z / sizeM + .5f) * (n - 1)).coerceIn(0f, n - 1f)
        val i0 = fx.toInt().coerceAtMost(n - 2); val j0 = fz.toInt().coerceAtMost(n - 2)
        val tx = fx - i0; val tz = fz - j0
        val a = heights[j0 * n + i0]; val b = heights[j0 * n + i0 + 1]
        val c = heights[(j0 + 1) * n + i0]; val d = heights[(j0 + 1) * n + i0 + 1]
        return (a * (1 - tx) + b * tx) * (1 - tz) + (c * (1 - tx) + d * tx) * tz
    }

    val routeY: FloatArray = FloatArray(routeX.size) { heightAt(routeX[it], routeZ[it]) }
    val ghostY: FloatArray? = if (ghostX != null && ghostZ != null) FloatArray(ghostX.size) { heightAt(ghostX[it], ghostZ[it]) } else null
}

/** Ubin elevasi Terrarium (AWS Open Data, tanpa kunci API): tinggi (m) = R*256 + G + B/256 - 32768. */
/** Tekstur peta di atas relief 3D: citra satelit (default) atau peta kontur. Diatur dari layar video rute. */
object TerrainTexture {
    @Volatile var style: MapStyle = MapStyle.SATELLITE
}

internal object TerrariumTiles {
    private const val USER_AGENT = "EnduranceVault/0.5.51 (Android; personal fitness log)"
    private const val MAX_AGE_MS = 60L * 24 * 60 * 60 * 1000

    /** Piksel ARGB 256x256, atau null bila tidak ada di cache dan unduhan gagal. */
    fun load(ctx: Context, z: Int, x: Int, y: Int): IntArray? {
        val file = File(ctx.applicationContext.cacheDir, "tiles-terrarium/$z/$x/$y.png")
        val fresh = file.isFile && System.currentTimeMillis() - file.lastModified() < MAX_AGE_MS
        if (fresh) decode(file)?.let { return it }
        val bytes = download(z, x, y)
        if (bytes != null) {
            runCatching { file.parentFile?.mkdirs(); file.writeBytes(bytes) }
            pixels(BitmapFactory.decodeByteArray(bytes, 0, bytes.size))?.let { return it }
        }
        return if (file.isFile) decode(file) else null
    }

    private fun decode(file: File): IntArray? = pixels(runCatching { BitmapFactory.decodeFile(file.absolutePath) }.getOrNull())

    private fun pixels(b: Bitmap?): IntArray? {
        if (b == null || b.width != 256 || b.height != 256) return null
        val px = IntArray(256 * 256)
        b.getPixels(px, 0, 256, 0, 0, 256, 256)
        b.recycle()
        return px
    }

    private fun download(z: Int, x: Int, y: Int): ByteArray? {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL("https://s3.amazonaws.com/elevation-tiles-prod/terrarium/$z/$x/$y.png").openConnection() as HttpURLConnection).apply {
                connectTimeout = 8_000; readTimeout = 8_000
                setRequestProperty("User-Agent", USER_AGENT)
            }
            if (conn.responseCode != 200) null else conn.inputStream.use { it.readBytes() }
        } catch (_: Exception) { null } finally { conn?.disconnect() }
    }
}


object TerrainBuilder {
    private const val GRID = 160
    private const val M_PER_DEG = 111_320.0
    private const val MAX_ROUTE_POINTS = 700

    private fun zoomFor(dLon: Double, targetPx: Double, minZ: Int, maxZ: Int): Int =
        floor(ln(targetPx * 360.0 / (256.0 * dLon)) / ln(2.0)).toInt().coerceIn(minZ, maxZ)

    /** Bingkai medan dan rentang ubin (satelit pada [zs], elevasi pada [zt]) untuk satu atau dua jejak. */
    private class Plan(lat: DoubleArray, lon: DoubleArray, sideMul: Double = 1.6) {
        val side: Double
        val latN: Double; val latS: Double; val lonW: Double; val lonE: Double
        val zs: Int; val sx0: Double; val sx1: Double; val sy0: Double; val sy1: Double
        val tx0: Int; val tx1: Int; val ty0: Int; val ty1: Int
        val zt: Int; val ex0: Double; val ex1: Double; val ey0: Double; val ey1: Double
        val dx0: Int; val dx1: Int; val dy0: Int; val dy1: Int

        init {
            val latMin = lat.min(); val latMax = lat.max(); val lonMin = lon.min(); val lonMax = lon.max()
            val cLat = (latMin + latMax) / 2; val cLon = (lonMin + lonMax) / 2
            val cosL = cos(Math.toRadians(cLat)).coerceAtLeast(0.05)
            val wM = (lonMax - lonMin) * M_PER_DEG * cosL; val hM = (latMax - latMin) * M_PER_DEG
            side = max(max(wM, hM) * sideMul, 1200.0).coerceAtMost(60_000.0)
            val dLat = side / 2 / M_PER_DEG; val dLon = side / 2 / (M_PER_DEG * cosL)
            latN = cLat + dLat; latS = cLat - dLat; lonW = cLon - dLon; lonE = cLon + dLon
            zs = zoomFor(lonE - lonW, 1536.0, 8, 17)
            sx0 = RouteGeo.worldX(lonW, zs); sx1 = RouteGeo.worldX(lonE, zs)
            sy0 = RouteGeo.worldY(latN, zs); sy1 = RouteGeo.worldY(latS, zs)
            tx0 = floor(sx0 / 256).toInt(); tx1 = floor((sx1 - 1e-6) / 256).toInt()
            ty0 = floor(sy0 / 256).toInt(); ty1 = floor((sy1 - 1e-6) / 256).toInt()
            zt = zoomFor(lonE - lonW, 768.0, 5, 14)
            ex0 = RouteGeo.worldX(lonW, zt); ex1 = RouteGeo.worldX(lonE, zt)
            ey0 = RouteGeo.worldY(latN, zt); ey1 = RouteGeo.worldY(latS, zt)
            dx0 = floor(ex0 / 256).toInt(); dx1 = floor((ex1 - 1e-6) / 256).toInt()
            dy0 = floor(ey0 / 256).toInt(); dy1 = floor((ey1 - 1e-6) / 256).toInt()
        }

        val satCols get() = tx1 - tx0 + 1
        val satRows get() = ty1 - ty0 + 1
        val demCols get() = dx1 - dx0 + 1
        val demRows get() = dy1 - dy0 + 1
    }

    private fun planOf(vararg tracks: RouteVideoTrack?): Plan = planOfMul(1.6, *tracks)

    private fun planOfMul(sideMul: Double, vararg tracks: RouteVideoTrack?): Plan {
        val ts = tracks.filterNotNull()
        return Plan(ts.flatMap { it.lat.asList() }.toDoubleArray(), ts.flatMap { it.lon.asList() }.toDoubleArray(), sideMul)
    }

    /** Jalankan [f] untuk 0 until [count] dengan paling banyak 6 pekerjaan bersamaan. */
    private suspend fun <T> fetchAll(count: Int, onDone: (Int) -> Unit, f: suspend (Int) -> T): List<T> = coroutineScope {
        val sem = Semaphore(6); val done = AtomicInteger(0)
        (0 until count).map { i ->
            async(Dispatchers.IO) { sem.withPermit { f(i) }.also { onDone(done.incrementAndGet()) } }
        }.awaitAll()
    }

    private suspend fun satTiles(ctx: Context, p: Plan, onStatus: (String) -> Unit): List<Bitmap?> {
        val total = p.satCols * p.satRows; val world = 1 shl p.zs
        return fetchAll(total, { onStatus("Mengunduh peta satelit $it/$total…") }) { q ->
            val tx = p.tx0 + q % p.satCols; val ty = p.ty0 + q / p.satCols
            if (ty !in 0 until world) null else MapTiles.load(ctx, RouteGeo.TileId(p.zs, Math.floorMod(tx, world), ty), TerrainTexture.style)
        }
    }

    private suspend fun demTiles(ctx: Context, p: Plan, onStatus: (String) -> Unit): List<IntArray?> {
        val total = p.demCols * p.demRows; val world = 1 shl p.zt
        return fetchAll(total, { onStatus("Mengunduh data elevasi $it/$total…") }) { q ->
            val tx = p.dx0 + q % p.demCols; val ty = p.dy0 + q / p.demCols
            if (ty !in 0 until world) null else TerrariumTiles.load(ctx, p.zt, Math.floorMod(tx, world), ty)
        }
    }

    /**
     * Unduh (atau baca dari cache) citra satelit dan elevasi lalu susun [TerrainScene]. Null bila rute kosong atau terjadi galat.
     * Tanpa jaringan dan tanpa cache, medan jadi datar ([TerrainScene.demOk] false) dan/atau tanpa citra.
     * Dengan [ghost], medan menutupi kedua rute.
     */
    suspend fun build(
        ctx: Context, track: RouteVideoTrack, ghost: RouteVideoTrack? = null, onStatus: (String) -> Unit = {},
    ): TerrainScene? = withContext(Dispatchers.IO) {
        runCatching { buildInternal(ctx, track, ghost, onStatus, false) }.getOrNull()
    }

    /**
     * Medan untuk video Trail 3D: tanpa citra satelit (relief bergaya, jadi lebih cepat dan hemat data) dan dengan bingkai
     * lebih lebar supaya cakram pelingkup rute selalu muat di dalam grid.
     */
    suspend fun buildTrail(
        ctx: Context, track: RouteVideoTrack, onStatus: (String) -> Unit = {},
    ): TerrainScene? = withContext(Dispatchers.IO) {
        runCatching { buildInternal(ctx, track, null, onStatus, true) }.getOrNull()
    }

    /**
     * Pemanasan cache: unduh ubin satelit dan elevasi untuk [tracks] tanpa menyusun medan.
     * Mengembalikan jumlah ubin yang gagal diunduh (0 = semua tersimpan untuk dipakai offline).
     */
    suspend fun prefetch(ctx: Context, tracks: List<RouteVideoTrack>, onStatus: (String) -> Unit = {}): Int = withContext(Dispatchers.IO) {
        var failed = 0
        tracks.forEachIndexed { i, t ->
            val label = "Aktivitas ${i + 1}/${tracks.size}: "
            val p = planOf(t)
            runCatching {
                failed += satTiles(ctx, p) { onStatus(label + "satelit $it") }.count { it == null }
                failed += demTiles(ctx, p) { onStatus(label + "elevasi $it") }.count { it == null }
            }.onFailure { failed += 1 }
        }
        failed
    }

    private suspend fun buildInternal(ctx: Context, track: RouteVideoTrack, ghost: RouteVideoTrack?, onStatus: (String) -> Unit, trail: Boolean): TerrainScene? {
        if (track.n < 2) return null
        val p = if (trail) planOfMul(2.0, track) else planOf(track, ghost)

        // ---- Citra satelit (dilewati untuk Trail 3D) ----
        val tiles: List<Bitmap?> = if (trail) emptyList() else satTiles(ctx, p, onStatus)
        val mosaic = Bitmap.createBitmap(if (trail) 2 else p.satCols * 256, if (trail) 2 else p.satRows * 256, Bitmap.Config.ARGB_8888)
        val mc = Canvas(mosaic); mc.drawColor(0xFF20262A.toInt())
        var okTiles = 0
        tiles.forEachIndexed { q, bmp ->
            if (bmp != null) {
                val l = (q % p.satCols) * 256; val t = (q / p.satCols) * 256
                mc.drawBitmap(bmp, null, Rect(l, t, l + 256, t + 256), null); okTiles++
            }
        }
        var sat: Bitmap? = null
        if (okTiles > 0) {
            val cx = (p.sx0 - p.tx0 * 256).roundToInt().coerceIn(0, mosaic.width - 2)
            val cy = (p.sy0 - p.ty0 * 256).roundToInt().coerceIn(0, mosaic.height - 2)
            val cw = (p.sx1 - p.sx0).roundToInt().coerceIn(2, mosaic.width - cx)
            val ch = (p.sy1 - p.sy0).roundToInt().coerceIn(2, mosaic.height - cy)
            sat = Bitmap.createBitmap(mosaic, cx, cy, cw, ch)
        }
        if (sat !== mosaic) mosaic.recycle()

        // ---- Elevasi ----
        val dem = demTiles(ctx, p, onStatus)
        val demOkTiles = dem.count { it != null }
        fun pixelH(ix: Int, iy: Int): Float {
            val col = Math.floorDiv(ix, 256) - p.dx0; val row = Math.floorDiv(iy, 256) - p.dy0
            if (col !in 0 until p.demCols || row !in 0 until p.demRows) return Float.NaN
            val t = dem[row * p.demCols + col] ?: return Float.NaN
            val px = t[Math.floorMod(iy, 256) * 256 + Math.floorMod(ix, 256)]
            return ((px shr 16) and 255) * 256f + ((px shr 8) and 255) + (px and 255) / 256f - 32768f
        }
        fun demAt(wx: Double, wy: Double): Float {
            val fx = wx - 0.5; val fy = wy - 0.5
            val ix = floor(fx).toInt(); val iy = floor(fy).toInt()
            val tx = (fx - ix).toFloat(); val ty = (fy - iy).toFloat()
            val h = floatArrayOf(pixelH(ix, iy), pixelH(ix + 1, iy), pixelH(ix, iy + 1), pixelH(ix + 1, iy + 1))
            val w = floatArrayOf((1 - tx) * (1 - ty), tx * (1 - ty), (1 - tx) * ty, tx * ty)
            var s = 0f; var ws = 0f
            for (q in 0..3) if (!h[q].isNaN()) { s += h[q] * w[q]; ws += w[q] }
            return if (ws <= 1e-6f) Float.NaN else s / ws
        }

        val g = GRID
        val heights = FloatArray(g * g)
        var sum = 0.0; var good = 0
        for (j in 0 until g) for (i in 0 until g) {
            val v = if (demOkTiles == 0) Float.NaN else
                demAt(p.ex0 + (p.ex1 - p.ex0) * i / (g - 1), p.ey0 + (p.ey1 - p.ey0) * j / (g - 1))
            heights[j * g + i] = v
            if (!v.isNaN()) { sum += v; good++ }
        }
        val demOk = good > 0
        val fill = if (demOk) (sum / good).toFloat() else 0f
        for (q in heights.indices) if (heights[q].isNaN()) heights[q] = fill

        // ---- Rute dan bendera dalam meter relatif pusat ----
        val side = p.side
        fun xOf(lon: Double) = (((RouteGeo.worldX(lon, p.zt) - p.ex0) / (p.ex1 - p.ex0) - .5) * side).toFloat()
        fun zOf(lat: Double) = (((RouteGeo.worldY(lat, p.zt) - p.ey0) / (p.ey1 - p.ey0) - .5) * side).toFloat()

        class Sampled(val x: FloatArray, val z: FloatArray, val frac: FloatArray)
        fun sample(t: RouteVideoTrack): Sampled {
            val step = max(1, t.n / MAX_ROUTE_POINTS)
            val xs = ArrayList<Float>(); val zs = ArrayList<Float>(); val fr = ArrayList<Float>()
            val total = t.totalM.coerceAtLeast(1.0)
            fun add(i: Int, force: Boolean) {
                val x = xOf(t.lon[i]); val z = zOf(t.lat[i])
                if (!force && xs.isNotEmpty()) {
                    val dx = x - xs.last(); val dz = z - zs.last()
                    if (dx * dx + dz * dz < 4f) return   // titik diam: hindari arah garis yang tidak terdefinisi
                }
                xs.add(x); zs.add(z); fr.add((t.dist[i] / total).toFloat())
            }
            var i = 0
            while (i < t.n - 1) { add(i, false); i += step }
            add(t.n - 1, true)
            return Sampled(xs.toFloatArray(), zs.toFloatArray(), fr.toFloatArray())
        }

        val main = sample(track)
        if (main.x.size < 2) return null
        val gh = ghost?.let { sample(it) }?.takeIf { it.x.size >= 2 }
        val anchors = track.allAnchors().map { SceneAnchor(it, xOf(track.lon[it.idx]), zOf(track.lat[it.idx])) }

        return TerrainScene(
            g, heights, side.toFloat(), sat, main.x, main.z, main.frac, anchors,
            gh?.x, gh?.z, gh?.frac, demOk,
        )
    }
}
