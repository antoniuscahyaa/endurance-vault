package com.monetra.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView web;

    class Bridge {
        SharedPreferences sp() { return getSharedPreferences("monetra_inbox", MODE_PRIVATE); }

        @JavascriptInterface public String inbox() { return sp().getString("a", "[]"); }

        @JavascriptInterface public boolean enabled() {
            String s = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
            return s != null && s.contains(getPackageName());
        }

        @JavascriptInterface public void openAccess() {
            Intent i = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        }

        @JavascriptInterface public void setDark(final boolean d) { runOnUiThread(() -> applyBars(d)); }

        @JavascriptInterface public String getPkg(String app) { return sp().getString("pkg_" + app, ""); }

        @JavascriptInterface public void setPkg(String app, String v) { sp().edit().putString("pkg_" + app, v == null ? "" : v.trim()).apply(); }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        applyBars(false);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setTextZoom(100);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        setContentView(web);

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl("file:///android_asset/index.html");
        }
    }

    void applyBars(boolean dark) {
        int bg = Color.parseColor(dark ? "#101418" : "#f8fafd");
        int nav = Color.parseColor(dark ? "#1a1f26" : "#ffffff");
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(nav);
        View dv = getWindow().getDecorView();
        int f = dv.getSystemUiVisibility();
        int light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        dv.setSystemUiVisibility(dark ? (f & ~light) : (f | light));
        web.setBackgroundColor(bg);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.evaluateJavascript("window.onResume && window.onResume()", null);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.onBack ? window.onBack() : false", value -> {
            if (!"true".equals(value)) {
                finish();
            }
        });
    }
}
