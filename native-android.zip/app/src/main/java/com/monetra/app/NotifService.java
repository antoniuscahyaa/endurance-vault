package com.monetra.app;

import android.app.Notification;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import org.json.JSONArray;
import org.json.JSONObject;

public class NotifService extends NotificationListenerService {
    static final Object LOCK = new Object();

    // Hanya Shopee Driver & SeaBank. Paket bisa diisi manual dari Pengaturan; ShopeePay sengaja tidak dibaca.
    static String match(String pkg, SharedPreferences sp) {
        String p = pkg.toLowerCase();
        String cs = sp.getString("pkg_sea", "").trim().toLowerCase();
        String cd = sp.getString("pkg_shopee", "").trim().toLowerCase();
        if (!cs.isEmpty() && p.equals(cs)) return "sea";
        if (!cd.isEmpty() && p.equals(cd)) return "shopee";
        if (p.contains("seabank") || p.contains("bankbkemobile")) return "sea";
        if (p.contains("shopee") && (p.contains("driver") || p.contains("foody") || p.contains("partner"))) return "shopee";
        return null;
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            SharedPreferences sp = getSharedPreferences("monetra_inbox", MODE_PRIVATE);
            String pkg = sbn.getPackageName();
            String app = match(pkg, sp);
            if (app == null) return;
            Notification n = sbn.getNotification();
            if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
            Bundle e = n.extras;
            CharSequence t = e.getCharSequence(Notification.EXTRA_TITLE);
            CharSequence x = e.getCharSequence(Notification.EXTRA_BIG_TEXT);
            if (x == null) x = e.getCharSequence(Notification.EXTRA_TEXT);
            String title = t == null ? "" : t.toString();
            String text = x == null ? "" : x.toString();
            if (title.isEmpty() && text.isEmpty()) return;
            long now = System.currentTimeMillis();
            synchronized (LOCK) {
                JSONArray old = new JSONArray(sp.getString("a", "[]"));
                for (int i = Math.max(0, old.length() - 8); i < old.length(); i++) {
                    JSONObject o = old.getJSONObject(i);
                    if (o.getString("pkg").equals(pkg) && o.getString("title").equals(title)
                            && o.getString("text").equals(text) && now - o.getLong("ts") < 60000) return;
                }
                JSONObject o = new JSONObject();
                o.put("id", now + "_" + Math.abs((pkg + title + text).hashCode()));
                o.put("pkg", pkg);
                o.put("app", app);
                o.put("title", title);
                o.put("text", text);
                o.put("ts", now);
                JSONArray out = new JSONArray();
                for (int i = Math.max(0, old.length() - 49); i < old.length(); i++) out.put(old.get(i));
                out.put(o);
                sp.edit().putString("a", out.toString()).apply();
            }
        } catch (Exception ex) {
            // abaikan
        }
    }
}
