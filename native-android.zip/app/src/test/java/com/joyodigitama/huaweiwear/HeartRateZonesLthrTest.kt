package com.joyodigitama.huaweiwear

import com.joyodigitama.huaweiwear.HeartRateZonesCalc.Method
import com.joyodigitama.huaweiwear.HeartRateZonesCalc.Posture
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HeartRateZonesLthrTest {
  private val lower = listOf(95, 150, 160, 170, 180)

  private fun lthr(lthr: Int = 175, maxHr: Int = 190, rest: Int = 50, bounds: List<Int> = lower) =
    HeartRateZonesCalc.CustomZones(Method.LTHR, bounds, maxHr, rest, lthr)

  /** Sama dengan TrackZonesService.configs: postur lain bawaan umur, postur tegak diganti zona kustom. */
  private fun trackTlv(c: HeartRateZonesCalc.CustomZones): Map<Int, Int> {
    val defaults = HeartRateZonesCalc.deviceConfig(35, track = true, simpleCommand = false, extended = false)
    val mine = HeartRateZonesCalc.customConfig(c)
    val merged = defaults.map { base ->
      if (base.posture != Posture.UPRIGHT) base else {
        val d = base.byMethod(Method.LTHR)
        mine.copy(zones = if (d != null && mine.byMethod(Method.LTHR) == null) mine.zones + d else mine.zones)
      }
    }
    return HeartRateZonesCalc.trackTlv(merged)!!.toMap()
  }

  @Test fun lthrZonesAreValid() = assertNull(lthr().error())

  @Test fun lthrNeedsAThreshold() {
    assertNotNull(lthr(lthr = 0).error())
    assertNotNull(lthr(lthr = 99).error())
    assertNotNull(lthr(lthr = 191).error()) // di atas HR maks
    assertNotNull(lthr(lthr = 95).error())
  }

  @Test fun lthrZoneOneMustStartBelowLthr() {
    assertNotNull(lthr(lthr = 140, bounds = listOf(150, 151, 152, 153, 154)).error())
  }

  @Test fun lthrChoiceMakesLthrTheCurrentMethodAndKeepsDefaultsForTheRest() {
    val cfg = HeartRateZonesCalc.customConfig(lthr())
    assertEquals(Method.LTHR, cfg.currentMethod)
    val z = cfg.byMethod(Method.LTHR)!!
    assertEquals(175, z.threshold)
    assertEquals(lower, listOf(z.zone1, z.zone2, z.zone3, z.zone4, z.zone5))
    assertNotNull(cfg.byMethod(Method.MHR))
    assertNotNull(cfg.byMethod(Method.HRR))
  }

  @Test fun trackPacketCarriesLthrMethodAndZonesInGbOrder() {
    val t = trackTlv(lthr())
    assertEquals(3, t[0xa]) // metode saat ini = LTHR
    assertEquals(175, t[0x3f]) // ambang LTHR
    assertEquals(180, t[0x40]) // zone5
    assertEquals(170, t[0x41])
    assertEquals(160, t[0x42])
    assertEquals(150, t[0x43])
    assertEquals(95, t[0x44]) // zone1
  }

  @Test fun mhrChoiceStillSendsMhrMethodAndDefaultLthr() {
    val t = trackTlv(HeartRateZonesCalc.CustomZones(Method.MHR, lower, 190, 50))
    assertEquals(0, t[0xa])
    val d = HeartRateZonesCalc.zones(Method.LTHR, 220 - 35 - 0).threshold // LTHR bawaan menurut umur, bukan LTHR pengguna
    assertEquals(d, t[0x3f])
  }

  @Test fun hrrChoiceStillSendsHrrMethod() {
    val t = trackTlv(HeartRateZonesCalc.CustomZones(Method.HRR, listOf(100, 120, 140, 150, 170), 190, 50))
    assertEquals(1, t[0xa])
  }

  @Test fun lthrZoneFiveAbove219IsRefusedNotWrapped() {
    // 102% dari LTHR tidak dipakai untuk zona kustom; batas pengguna dibatasi < 220 oleh error()
    assertTrue(lthr(lthr = 219, maxHr = 219, bounds = listOf(95, 150, 160, 170, 220)).error() != null)
  }
}
