package com.endurancevault.app

import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.domain.ActivityDuplicates
import org.junit.Assert.*
import org.junit.Test

class ActivityDuplicatesTest {
    private fun act(id: Long, km: Double, sec: Int, st: String? = null, detail: String? = null, date: String = "2026-11-01", type: String = "run") =
        ActivityEntity(id = id, dateIso = date, km = km, durationSec = sec, startTime = st, detailFile = detail, type = type)

    @Test fun sameStartTimeWithinOneMinuteIsCandidate() {
        assertTrue(ActivityDuplicates.sameActivity(act(1, 26.3, 9000, "05:30"), act(2, 26.3, 9000, "05:31")))
        assertFalse(ActivityDuplicates.sameActivity(act(1, 26.3, 9000, "05:30"), act(2, 26.3, 9000, "05:33")))
    }

    @Test fun differentDateOrTypeIsNeverDuplicate() {
        assertFalse(ActivityDuplicates.sameActivity(act(1, 10.0, 3600, "05:30"), act(2, 10.0, 3600, "05:30", date = "2026-11-02")))
        assertFalse(ActivityDuplicates.sameActivity(act(1, 10.0, 3600, "05:30"), act(2, 10.0, 3600, "05:30", type = "bike")))
    }

    @Test fun withoutStartTimeUsesKmAndDuration() {
        assertTrue(ActivityDuplicates.sameActivity(act(1, 10.0, 3600), act(2, 10.2, 3700)))
        assertFalse(ActivityDuplicates.sameActivity(act(1, 10.0, 3600), act(2, 6.0, 2300)))
    }

    @Test fun findPairsIncludesTwoRowsWithoutDetail() {
        val pairs = ActivityDuplicates.findPairs(listOf(act(1, 10.0, 3600), act(2, 10.0, 3610)))
        assertEquals(1, pairs.size)
    }

    @Test fun findPairsPutsRowWithDetailFirst() {
        val pairs = ActivityDuplicates.findPairs(listOf(act(1, 10.0, 3600, "06:00"), act(2, 10.0, 3600, "06:00", detail = "act_2.json")))
        assertEquals(2L, pairs.single().first.id)
    }

    @Test fun highConfidenceNeedsBothStartTimesAndTightMatch() {
        assertTrue(ActivityDuplicates.highConfidence(act(1, 26.3, 9000, "05:30"), act(2, 26.32, 9020, "05:30", detail = "d")))
        assertFalse("tanpa jam mulai harus konfirmasi", ActivityDuplicates.highConfidence(act(1, 26.3, 9000), act(2, 26.3, 9000)))
        assertFalse("jarak beda 0,2 km harus konfirmasi", ActivityDuplicates.highConfidence(act(1, 26.3, 9000, "05:30"), act(2, 26.5, 9000, "05:30")))
        assertFalse("dua-duanya punya detail harus konfirmasi", ActivityDuplicates.highConfidence(act(1, 10.0, 3600, "05:30", "a"), act(2, 10.0, 3600, "05:30", "b")))
    }

    @Test fun importUsesSameCriteriaAsScanner() {
        val manual = act(1, 10.0, 3600) // catatan manual tanpa jam mulai
        assertTrue(ActivityDuplicates.matchesImport(manual, "2026-11-01", "06:00", 10.2, 3650, "run"))
        assertFalse(ActivityDuplicates.matchesImport(manual, "2026-11-01", "06:00", 10.6, 3650, "run"))
        val tracked = act(2, 10.0, 3600, "06:00")
        assertFalse("jam mulai beda jauh = lari berbeda", ActivityDuplicates.matchesImport(tracked, "2026-11-01", "17:00", 10.0, 3600, "run"))
    }
}
