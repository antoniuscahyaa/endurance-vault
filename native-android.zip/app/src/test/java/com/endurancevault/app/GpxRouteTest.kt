package com.endurancevault.app

import com.endurancevault.app.domain.CourseStrategy.Pt
import com.endurancevault.app.domain.GpxRoute
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class GpxRouteTest {
    private fun gpx(name: String?, pts: List<Triple<Double, Double, Double?>>, tag: String = "trkpt") =
        "<?xml version=\"1.0\"?><gpx xmlns=\"http://www.topografix.com/GPX/1/1\">" +
            (if (name != null) "<metadata><name>$name</name></metadata>" else "") +
            (if (tag == "trkpt") "<trk><trkseg>" else "<rte>") +
            pts.joinToString("") { (la, lo, e) -> "<$tag lat=\"$la\" lon=\"$lo\">" + (if (e != null) "<ele>$e</ele>" else "") + "</$tag>" } +
            (if (tag == "trkpt") "</trkseg></trk>" else "</rte>") + "</gpx>"

    private val line = (0..40).map { Triple(-6.0 + it * 0.001, 106.0, 100.0 + it * 2.0) }

    @Test fun parseTrkptDanNamaDariMetadata() {
        val p = GpxRoute.preview(gpx("Bukit Cinta", line), "x.gpx")
        assertEquals("Bukit Cinta", p.name)
        assertEquals(41, p.total)
        assertTrue(p.km > 4.3 && p.km < 4.6)
        assertTrue(p.stats.hasEle)
        assertEquals(80, p.stats.up)
    }

    @Test fun rteptDipakaiBilaTidakAdaTrkptDanNamaDariBerkas() {
        val p = GpxRoute.preview(gpx(null, line, "rtept"), "rute-pagi.gpx")
        assertEquals("rute-pagi", p.name)
        assertEquals(41, p.total)
    }

    @Test fun kurangDariDuaTitikDitolak() {
        try { GpxRoute.preview(gpx("A", listOf(Triple(-6.0, 106.0, 1.0))), "a.gpx"); fail() } catch (e: GpxRoute.Err) { assertTrue(e.message!!.contains("minimal 2 titik")) }
        try { GpxRoute.preview("bukan xml", "a.gpx"); fail() } catch (e: GpxRoute.Err) { assertTrue(e.message!!.contains("tidak bisa dibaca")) }
    }

    @Test fun doctypeDitolakAgarAmanDariXxe() {
        val evil = "<?xml version=\"1.0\"?><!DOCTYPE gpx [<!ENTITY x SYSTEM \"file:///etc/passwd\">]><gpx><trk><trkseg></trkseg></trk></gpx>"
        try { GpxRoute.preview(evil, "e.gpx"); fail() } catch (e: GpxRoute.Err) { }
    }

    @Test fun payloadMembuangTitikKembarDanMenjarangkan() {
        val dup = listOf(Pt(-6.0, 106.0, 1.0), Pt(-6.0, 106.0, 1.0), Pt(-6.001, 106.0, null))
        val (json, n) = GpxRoute.payload("R", dup)!!
        assertEquals(2, n)
        val pts = JSONObject(json).getJSONArray("points")
        assertTrue(pts.getJSONArray(1).isNull(2))
        val many = (0 until 3000).map { Pt(-6.0 + it * 0.0001, 106.0, 10.0) }
        assertEquals(1000, GpxRoute.payload("R", many)!!.second)
        assertNull(GpxRoute.payload("R", listOf(Pt(-6.0, 106.0, 1.0), Pt(-6.0, 106.0, 2.0))))
    }

    @Test fun namaDipotongSampai60Byte() {
        val n = GpxRoute.routeName("é".repeat(50))
        assertTrue(n.toByteArray(Charsets.UTF_8).size <= 60)
        assertEquals("Rute", GpxRoute.routeName("   "))
    }

    @Test fun statistikAbaikanDerauKurangDari3m() {
        val pts = (0..10).map { Pt(-6.0 + it * 0.0005, 106.0, 100.0 + (if (it % 2 == 0) 0.0 else 2.0)) }
        val st = GpxRoute.stats(pts)
        assertEquals(0, st.up); assertEquals(0, st.down)
        assertFalse(GpxRoute.stats(listOf(Pt(0.0, 0.0, null), Pt(0.0, 0.01, null))).hasEle)
    }
}
