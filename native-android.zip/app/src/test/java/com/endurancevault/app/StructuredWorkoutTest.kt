package com.endurancevault.app

import com.endurancevault.app.domain.StepIntensity
import com.endurancevault.app.domain.StepTarget
import com.endurancevault.app.domain.StructuredWorkout
import com.endurancevault.app.domain.WorkoutTargets
import org.junit.Assert.*
import org.junit.Test

class StructuredWorkoutTest {
    private val none = WorkoutTargets()

    private fun steps(payload: org.json.JSONObject, block: Int) =
        payload.getJSONArray("courses").getJSONObject(0).getJSONArray("blocks").getJSONObject(block).getJSONArray("steps")

    @Test fun parsePaceAcceptsMinuteSecondOnly() {
        assertEquals(330, StructuredWorkout.parsePace("5:30")); assertEquals(270, StructuredWorkout.parsePace(" 4:30 "))
        assertNull(StructuredWorkout.parsePace("5.30")); assertNull(StructuredWorkout.parsePace("5:75")); assertNull(StructuredWorkout.parsePace(""))
        assertEquals("5:05", StructuredWorkout.formatPace(305))
    }

    @Test fun targetSortsBoundsAndKeepsInvalidAsZero() {
        assertEquals(StepTarget(StepIntensity.PACE, 270, 300), StructuredWorkout.target(StepIntensity.PACE, 300, 270))
        assertEquals(StepTarget(StepIntensity.HR_PERCENT, 0, 0), StructuredWorkout.target(StepIntensity.HR_PERCENT, null, 90))
        assertEquals(StepTarget(), StructuredWorkout.target(StepIntensity.NONE, 1, 2))
    }

    @Test fun payloadWithoutTargetsMatchesOldShape() {
        val p = StructuredWorkout.buildPayload("ev-1", "Interval", 10, 4, 4, 2, 10, none)
        val blocks = p.getJSONArray("courses").getJSONObject(0).getJSONArray("blocks")
        assertEquals(3, blocks.length())
        assertEquals(4, blocks.getJSONObject(1).optInt("repeat"))
        val loop = steps(p, 1)
        assertEquals(2, loop.length()); assertEquals("run", loop.getJSONObject(0).getString("kind")); assertEquals(240, loop.getJSONObject(0).optInt("value"))
        assertEquals("none", loop.getJSONObject(0).getString("intensity")); assertFalse(loop.getJSONObject(0).has("low"))
        assertEquals("rest", loop.getJSONObject(1).getString("kind")); assertEquals(120, loop.getJSONObject(1).optInt("value"))
    }

    @Test fun zeroDurationStepsAreSkipped() {
        val p = StructuredWorkout.buildPayload("ev-1", "", 0, 3, 5, 0, 0, none)
        val course = p.getJSONArray("courses").getJSONObject(0)
        assertEquals("EnduranceVault Workout", course.getString("name"))
        assertEquals(1, course.getJSONArray("blocks").length()); assertEquals(1, steps(p, 0).length())
    }

    @Test fun targetsAreWrittenPerStep() {
        val t = WorkoutTargets(
            warmup = StepTarget(StepIntensity.HR_PERCENT, 60, 70),
            run = StepTarget(StepIntensity.PACE, 270, 285),
            recovery = StepTarget(StepIntensity.HR_PERCENT, 55, 70),
            cooldown = StepTarget(StepIntensity.CADENCE, 150, 170),
        )
        val p = StructuredWorkout.buildPayload("ev-1", "x", 10, 4, 4, 2, 10, t)
        val run = steps(p, 1).getJSONObject(0)
        assertEquals("pace", run.getString("intensity")); assertEquals(270, run.optInt("low")); assertEquals(285, run.optInt("high"))
        val warm = steps(p, 0).getJSONObject(0)
        assertEquals("hrPercent", warm.getString("intensity")); assertEquals(60, warm.optInt("low"))
        assertEquals("cadence", steps(p, 2).getJSONObject(0).getString("intensity"))
        assertEquals("hrPercent", steps(p, 1).getJSONObject(1).getString("intensity"))
    }

    @Test fun validateChecksRangesPerStepAndNamesTheStep() {
        fun v(t: WorkoutTargets, w: Int = 10, r: Int = 4, run: Int = 4, rec: Int = 2, c: Int = 10) = StructuredWorkout.validate(w, r, run, rec, c, t)
        assertNull(v(none))
        assertNull(v(WorkoutTargets(run = StepTarget(StepIntensity.PACE, 270, 285))))
        assertTrue(v(WorkoutTargets(run = StepTarget(StepIntensity.PACE, 30, 285)))!!.startsWith("Lari"))
        assertTrue(v(WorkoutTargets(run = StepTarget(StepIntensity.PACE, 300, 270)))!!.contains("tercepat"))
        assertTrue(v(WorkoutTargets(run = StepTarget(StepIntensity.PACE, 0, 0)))!!.startsWith("Lari"))
        assertTrue(v(WorkoutTargets(warmup = StepTarget(StepIntensity.HR_PERCENT, 10, 70)))!!.startsWith("Pemanasan"))
        assertTrue(v(WorkoutTargets(cooldown = StepTarget(StepIntensity.CADENCE, 90, 170)))!!.startsWith("Pendinginan"))
        assertTrue(v(WorkoutTargets(recovery = StepTarget(StepIntensity.HR_PERCENT, 60, 120)))!!.startsWith("Recovery"))
        // target pada langkah yang durasinya 0 tidak ikut dikirim, jadi tidak divalidasi
        assertNull(v(WorkoutTargets(recovery = StepTarget(StepIntensity.HR_PERCENT, 0, 0)), rec = 0))
        assertNotNull(v(none, r = 0)); assertNotNull(v(none, run = 0)); assertNotNull(v(none, w = 61))
    }

    @Test fun watchLowerBoundsMatchesWhatIsSentToWatch() {
        // LTHR: Z1 = min(50% HR maks, awal Z2 - 1); Z2..Z5 apa adanya
        assertEquals(listOf(95, 150, 160, 170, 180), StructuredWorkout.watchLowerBounds("lthr", listOf(0, 150, 160, 170, 180), 190))
        assertEquals(listOf(70, 150, 160, 170, 180), StructuredWorkout.watchLowerBounds("lthr", listOf(0, 150, 160, 170, 180), 140))
        // HRR: lima batas apa adanya
        assertEquals(listOf(100, 120, 140, 150, 170), StructuredWorkout.watchLowerBounds("hrr", listOf(100, 120, 140, 150, 170), 190))
    }

    @Test fun zoneBpmCoversWholeRangeUpToMax() {
        val lower = listOf(95, 150, 160, 170, 180)
        assertEquals(95..149, StructuredWorkout.zoneBpm(1, lower, 190))
        assertEquals(160..169, StructuredWorkout.zoneBpm(3, lower, 190))
        assertEquals(180..190, StructuredWorkout.zoneBpm(5, lower, 190))
    }

    @Test fun zoneTargetConvertsToPercentOfMax() {
        val lower = listOf(95, 150, 160, 170, 180)
        assertEquals(StepTarget(StepIntensity.HR_PERCENT, 50, 78), StructuredWorkout.zoneTarget(1, lower, 190))
        assertEquals(StepTarget(StepIntensity.HR_PERCENT, 84, 89), StructuredWorkout.zoneTarget(3, lower, 190))
        assertEquals(StepTarget(StepIntensity.HR_PERCENT, 95, 100), StructuredWorkout.zoneTarget(5, lower, 190))
        // zona tidak dipilih atau data zona rusak -> 0,0 supaya validate() menolak dengan pesan jelas
        assertEquals(StepTarget(StepIntensity.HR_PERCENT, 0, 0), StructuredWorkout.zoneTarget(0, lower, 190))
        assertEquals(StepTarget(StepIntensity.HR_PERCENT, 0, 0), StructuredWorkout.zoneTarget(2, listOf(1, 2), 190))
        assertEquals("Lari: pilih zona HR", StructuredWorkout.validate(10, 4, 4, 2, 10, WorkoutTargets(run = StepTarget(StepIntensity.HR_PERCENT, 0, 0))))
        assertNull(StructuredWorkout.validate(10, 4, 4, 2, 10, WorkoutTargets(run = StructuredWorkout.zoneTarget(4, lower, 190))))
    }
}
