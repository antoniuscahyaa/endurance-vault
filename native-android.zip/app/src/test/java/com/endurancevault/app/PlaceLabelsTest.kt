package com.endurancevault.app

import com.endurancevault.app.data.PlaceLabels
import com.endurancevault.app.data.ScenePlace
import com.endurancevault.app.domain.RouteVideoPrefs
import com.endurancevault.app.domain.TrailPrefs
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PlaceLabelsTest {
    private fun p(name: String, x: Float, z: Float, score: Float = 3f, frac: Float = 0.5f) = ScenePlace(name, "village", x, z, score, frac)

    @Test
    fun selectKeepsScoreOrderAndSpacing() {
        val all = listOf(p("A", 0f, 0f, 5f), p("B", 50f, 0f, 4f), p("C", 600f, 0f, 3f), p("D", 0f, 700f, 2f))
        val out = PlaceLabels.select(all, 3, 300f) { true }
        // B terlalu dekat dengan A (50 m < 300 m) sehingga dilewati.
        assertEquals(listOf("A", "C", "D"), out.map { it.name })
    }

    @Test
    fun selectHonoursCountAndInsideFilter() {
        val all = listOf(p("A", 0f, 0f, 5f), p("B", 1000f, 0f, 4f), p("C", 2000f, 0f, 3f))
        assertEquals(listOf("B"), PlaceLabels.select(all, 1, 100f) { it.x >= 1000f }.map { it.name })
        assertEquals(2, PlaceLabels.select(all, 2, 100f) { true }.size)
    }

    @Test
    fun revealFollowsRunnerOnlyInLiveMode() {
        assertEquals(1f, PlaceLabels.reveal(false, 0.0, 0.9f), 1e-6f)
        // Nama dekat start sudah tampak sejak awal; nama di ujung rute baru muncul menjelang pelari tiba.
        assertEquals(1f, PlaceLabels.reveal(true, 0.0, 0.05f), 1e-6f)
        assertEquals(0f, PlaceLabels.reveal(true, 0.2, 0.9f), 1e-6f)
        assertEquals(1f, PlaceLabels.reveal(true, 0.9, 0.9f), 1e-6f)
        val mid = PlaceLabels.reveal(true, 0.82, 0.9f)
        assertTrue(mid > 0f && mid < 1f)
    }

    @Test
    fun placePrefsAreSanitizedAndSaved() {
        val r = RouteVideoPrefs(showPlaces = false, placeCount = 99).sanitized()
        assertEquals(8, r.placeCount)
        val r2 = RouteVideoPrefs.fromJson(r.toJson())
        assertFalse(r2.showPlaces); assertEquals(8, r2.placeCount)
        val t = TrailPrefs(showPlaces = true, placeCount = 0).sanitized()
        assertEquals(1, t.placeCount)
        val t2 = TrailPrefs.fromJson(TrailPrefs(placeCount = 6).toJson())
        assertTrue(t2.showPlaces); assertEquals(6, t2.placeCount)
        // Pengaturan lama tanpa kunci nama daerah memakai bawaan.
        assertTrue(RouteVideoPrefs.fromJson("{}").showPlaces)
        assertEquals(4, TrailPrefs.fromJson("{}").placeCount)
    }
}
