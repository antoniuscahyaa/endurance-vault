package com.endurancevault.app

import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.domain.PeriodStats
import com.endurancevault.app.domain.SharePeriod
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class PeriodStatsTest {
    private fun act(date: String, km: Double, sec: Int, hr: Int? = null, gain: Int? = null, type: String = "run") =
        ActivityEntity(dateIso = date, km = km, durationSec = sec, avgHr = hr, gain = gain, type = type)

    @Test fun weekStartsOnMondayAndEndsOnSunday() {
        // 11 Nov 2026 = Rabu; minggunya 9 Nov (Senin) sampai 15 Nov (Minggu)
        val (s, e) = PeriodStats.range(SharePeriod.WEEK, LocalDate.of(2026, 11, 11))
        assertEquals(LocalDate.of(2026, 11, 9), s)
        assertEquals(LocalDate.of(2026, 11, 15), e)
        // Minggu 15 Nov tetap masuk minggu yang sama, Senin 16 Nov minggu berikutnya
        assertEquals(LocalDate.of(2026, 11, 9), PeriodStats.range(SharePeriod.WEEK, LocalDate.of(2026, 11, 15)).first)
        assertEquals(LocalDate.of(2026, 11, 16), PeriodStats.range(SharePeriod.WEEK, LocalDate.of(2026, 11, 16)).first)
    }

    @Test fun monthRunsFromFirstToLastDay() {
        val (s, e) = PeriodStats.range(SharePeriod.MONTH, LocalDate.of(2026, 2, 17))
        assertEquals(LocalDate.of(2026, 2, 1), s)
        assertEquals(LocalDate.of(2026, 2, 28), e)
        assertEquals(31, PeriodStats.summarize(emptyList(), SharePeriod.MONTH, LocalDate.of(2026, 10, 5)).dailyKm.size)
    }

    @Test fun weekSumsOnlyRunsInsideTheWeek() {
        val acts = listOf(
            act("2026-11-08", 20.0, 7200),                 // Minggu sebelumnya: tidak dihitung
            act("2026-11-09", 8.0, 2800, hr = 140, gain = 50),
            act("2026-11-11", 10.0, 3400, hr = 150, gain = 100),
            act("2026-11-15", 16.0, 5600, hr = 148, gain = 300),
            act("2026-11-16", 5.0, 1700),                  // Senin berikutnya: tidak dihitung
            act("2026-11-12", 30.0, 3600, type = "bike"),  // sepeda: tidak dihitung
        )
        val sm = PeriodStats.summarize(acts, SharePeriod.WEEK, LocalDate.of(2026, 11, 11))
        assertEquals(34.0, sm.km, 1e-9)
        assertEquals(11800, sm.durationSec)
        assertEquals(450, sm.gain)
        assertEquals(3, sm.sessions)
        assertEquals(16.0, sm.longestKm, 1e-9)
        assertEquals(listOf(8.0, 0.0, 10.0, 0.0, 0.0, 0.0, 16.0), sm.dailyKm)
        assertEquals(3, sm.activeDays)
    }

    @Test fun averageHrIsWeightedByDuration() {
        val acts = listOf(act("2026-11-09", 5.0, 1000, hr = 140), act("2026-11-10", 5.0, 3000, hr = 160))
        val sm = PeriodStats.summarize(acts, SharePeriod.WEEK, LocalDate.of(2026, 11, 9))
        assertEquals(155, sm.avgHr)   // (140*1000 + 160*3000) / 4000
    }

    @Test fun emptyPeriodHasNoPaceOrHr() {
        val sm = PeriodStats.summarize(emptyList(), SharePeriod.WEEK, LocalDate.of(2026, 11, 11))
        assertNull(sm.avgPace); assertNull(sm.avgHr); assertEquals(0, sm.sessions)
    }
}
