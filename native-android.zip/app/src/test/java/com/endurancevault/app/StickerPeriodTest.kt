package com.endurancevault.app

import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.domain.PeriodData
import com.endurancevault.app.domain.PeriodStats
import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.domain.SharePeriod
import com.endurancevault.app.domain.StickerPreset
import com.endurancevault.app.domain.StickerModel
import com.endurancevault.app.domain.StickerPrefs
import com.endurancevault.app.domain.Stickers
import com.endurancevault.app.domain.Zones
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class StickerPeriodTest {
    private val zc = Zones.cuts(PlanSettings(thr = "164–172"))

    private fun act(date: String, km: Double, sec: Int, hr: Int? = null, gain: Int? = null) =
        ActivityEntity(dateIso = date, km = km, durationSec = sec, avgHr = hr, gain = gain, type = "run")

    // 11 Nov 2026 = Rabu; minggunya 9..15 Nov, minggu lalu 2..8 Nov.
    private val acts = listOf(act("2026-11-09", 10.0, 3000, 150, 80), act("2026-11-11", 5.0, 1700, 140, 20), act("2026-11-02", 8.0, 2600))

    private fun model(): StickerModel {
        val e = acts[1]
        val p = PeriodData.of(acts, e, LocalDate.of(2026, 11, 11), emptyList(), LocalDate.of(2026, 11, 20))
        return Stickers.forActivity(e, null, emptyMap(), zc, null, p)!!
    }

    @Test fun weekNumbersUseWeekTotalsAndSuffixedLabels() {
        val m = model()
        assertEquals("15,0", m.numPer("jarak", "week")!!.value)
        assertEquals("Jarak minggu", m.numPer("jarak", "week")!!.label)
        assertEquals("2", m.numPer("hari", "week")!!.value)
        assertEquals("2", m.numPer("sesi", "week")!!.value)
    }

    @Test fun dayUsesOnlyTheOpenedSession() {
        val m = model()
        assertEquals("5,00", m.numPer("jarak", "day")!!.value)
        assertEquals("Jarak", m.numPer("jarak", "day")!!.label)
        assertNull(m.numPer("hari", "day"))
    }

    @Test fun calendarAndCurveOnlyForWeekAndMonth() {
        val m = model()
        assertNotNull(m.graphWhy("p-kalender", 8, "day"))
        assertNotNull(m.graphWhy("p-kurva", 8, "day"))
        assertNull(m.graphWhy("p-kalender", 8, "week"))
        assertNull(m.graphWhy("p-kurva", 8, "month"))
    }

    @Test fun ringNeedsPlanTargetAndCompareNeedsPrevious() {
        val m = model()
        assertNotNull(m.graphWhy("p-cincin", 8, "week"))
        assertNull(m.graphWhy("p-banding", 8, "week"))
    }

    @Test fun periodStickersAppearInIdsAndLabels() {
        val m = model()
        val ids = Stickers.allIds(m, StickerPrefs(per = "week"))
        assertTrue("p-angka" in ids)
        assertTrue("p-hero" in ids)
        assertFalse("p-cincin" in ids)
        assertEquals("Angka periode", Stickers.idLabel("p-angka", m))
        assertEquals("Kalender periode", Stickers.idLabel("p-kalender", m))
    }

    @Test fun prefsRoundTripAndSanitizePeriod() {
        val p = StickerPrefs.fromJson(StickerPrefs(per = "month", pf = listOf("jarak", "sesi", "x")).toJson())
        assertEquals("month", p.per)
        assertEquals(listOf("jarak", "sesi"), p.pf)
        assertEquals("week", StickerPrefs(per = "tahun").sanitized().per)
    }

    @Test fun runningWeekComparesSameElapsedDays() {
        val a = listOf(act("2026-11-02", 8.0, 2600), act("2026-11-07", 20.0, 6000), act("2026-11-09", 10.0, 3000))
        val running = PeriodStats.previous(a, SharePeriod.WEEK, LocalDate.of(2026, 11, 9), LocalDate.of(2026, 11, 11))!!
        assertEquals(8.0, running.km, 1e-9)
        assertEquals(3, running.dailyKm.size)
        val done = PeriodStats.previous(a, SharePeriod.WEEK, LocalDate.of(2026, 11, 9), LocalDate.of(2026, 11, 20))!!
        assertEquals(28.0, done.km, 1e-9)
        assertEquals(7, done.dailyKm.size)
        assertEquals(28.0, PeriodStats.previous(a, SharePeriod.WEEK, LocalDate.of(2026, 11, 9))!!.km, 1e-9)
    }

    @Test fun runningMonthCutsPreviousMonthAtSameDay() {
        val a = listOf(act("2026-10-03", 5.0, 1500), act("2026-10-20", 30.0, 9000), act("2026-11-04", 6.0, 1800))
        val p = PeriodStats.previous(a, SharePeriod.MONTH, LocalDate.of(2026, 11, 4), LocalDate.of(2026, 11, 10))!!
        assertEquals(5.0, p.km, 1e-9)
        assertEquals(10, p.dailyKm.size)
    }

    @Test fun stylePresetsRoundTripAndSanitize() {
        val q = StickerPreset("Malam", "k", "#112233", "#ff8800", "soft", 150, "", "", "sport")
        val p = StickerPrefs(presets = listOf(q, q.copy(name = "  "), q.copy(name = "Malam"))).sanitized()
        assertEquals(listOf("Malam"), p.presets.map { it.name })
        val back = StickerPrefs.fromJson(StickerPrefs(numStyle = "sport", presets = listOf(q)).toJson())
        assertEquals("sport", back.numStyle)
        assertEquals(listOf(q), back.presets)
        val applied = StickerPrefs().withPreset(q)
        assertEquals("k", applied.ink); assertEquals("sport", applied.numStyle); assertEquals(150, applied.scale)
        assertTrue(applied.matches(q))
        assertEquals("std", StickerPrefs(numStyle = "x").sanitized().numStyle)
    }
}
