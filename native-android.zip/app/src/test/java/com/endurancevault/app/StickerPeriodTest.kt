package com.endurancevault.app

import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.domain.PeriodData
import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.domain.StickerModel
import com.endurancevault.app.domain.StickerPrefs
import com.endurancevault.app.domain.Stickers
import com.endurancevault.app.domain.Zones
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class StickerPeriodTest {
    private val zc = Zones.cuts(PlanSettings(thr = "164–172"))

    private fun act(date: String, km: Double, sec: Int, hr: Int? = null, gain: Int? = null) =
        ActivityEntity(dateIso = date, km = km, durationSec = sec, avgHr = hr, gain = gain, type = "run")

    // 11 Nov 2026 = Rabu; minggunya 9..15 Nov, minggu lalu 2..8 Nov.
    private val acts = listOf(act("2026-11-09", 10.0, 3000, 150, 80), act("2026-11-11", 5.0, 1700, 140, 20), act("2026-11-02", 8.0, 2600))

    private fun model(): StickerModel {
        val e = acts[1]
        val p = PeriodData.of(acts, e, LocalDate.of(2026, 11, 11), emptyList())
        return Stickers.forActivity(e, null, emptyMap(), zc, null, p)!!
    }

    @Test fun weekNumbersUseWeekTotalsAndSuffixedLabels() {
        val m = model()
        assertEquals("15,0", m.numPer("jarak", "week")!!.value)
        assertEquals("Jarak minggu", m.numPer("jarak", "week")!!.label)
        assertEquals("2", m.numPer("hari", "week")!!.value)
        assertEquals("2", m.numPer("sesi", "week")!!.value)
    }

    @Test fun dayUsesOnlyTheOpenedSession() {
        val m = model()
        assertEquals("5,00", m.numPer("jarak", "day")!!.value)
        assertEquals("Jarak", m.numPer("jarak", "day")!!.label)
        assertNull(m.numPer("hari", "day"))
    }

    @Test fun calendarAndCurveOnlyForWeekAndMonth() {
        val m = model()
        assertNotNull(m.graphWhy("p-kalender", 8, "day"))
        assertNotNull(m.graphWhy("p-kurva", 8, "day"))
        assertNull(m.graphWhy("p-kalender", 8, "week"))
        assertNull(m.graphWhy("p-kurva", 8, "month"))
    }

    @Test fun ringNeedsPlanTargetAndCompareNeedsPrevious() {
        val m = model()
        assertNotNull(m.graphWhy("p-cincin", 8, "week"))
        assertNull(m.graphWhy("p-banding", 8, "week"))
    }

    @Test fun periodStickersAppearInIdsAndLabels() {
        val m = model()
        val ids = Stickers.allIds(m, StickerPrefs(per = "week"))
        assertTrue("p-angka" in ids)
        assertTrue("p-hero" in ids)
        assertFalse("p-cincin" in ids)
        assertEquals("Angka periode", Stickers.idLabel("p-angka", m))
        assertEquals("Kalender periode", Stickers.idLabel("p-kalender", m))
    }

    @Test fun prefsRoundTripAndSanitizePeriod() {
        val p = StickerPrefs.fromJson(StickerPrefs(per = "month", pf = listOf("jarak", "sesi", "x")).toJson())
        assertEquals("month", p.per)
        assertEquals(listOf("jarak", "sesi"), p.pf)
        assertEquals("week", StickerPrefs(per = "tahun").sanitized().per)
    }
}
