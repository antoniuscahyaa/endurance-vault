package com.endurancevault.app

import com.endurancevault.app.domain.QualityWorkout
import com.endurancevault.app.domain.StepIntensity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class QualityWorkoutTest {
    private val wu = " Pemanasan 15 mnt easy, pendinginan 10 mnt easy."

    @Test fun thresholdJalan() {
        val s = QualityWorkout.parse("Threshold 3×10 mnt (HR 164–172), jog 2 mnt antar set. Pace sekitar 5:10/km.$wu", 30.0, listOf(164, 172), "thr")!!
        assertEquals(15, s.warmupMin); assertEquals(3, s.repeats); assertEquals(10, s.runMin)
        assertEquals(2, s.recoveryMin); assertEquals(10, s.cooldownMin)
        assertEquals(listOf(164, 172), s.runBand); assertTrue(s.assumed.isEmpty())
        assertEquals(15 + 3 * 12 + 10, s.totalMin)
    }

    @Test fun tempoSatuBlok() {
        val s = QualityWorkout.parse("Tempo 30 mnt tanpa henti di HR 160–170 (sedikit di bawah threshold).$wu", 30.0, listOf(160, 170), "thr")!!
        assertEquals(1, s.repeats); assertEquals(30, s.runMin); assertEquals(0, s.recoveryMin)
    }

    @Test fun trailTanpaMenitPemanasanMemakaiAsumsi() {
        val s = QualityWorkout.parse("Threshold 3×10 mnt (HR 164–172), jog 2 mnt antar set. Pemanasan dan pendinginan easy.", 30.0, listOf(164, 172), "thr")!!
        assertEquals(QualityWorkout.DEFAULT_WARMUP_MIN, s.warmupMin)
        assertEquals(QualityWorkout.DEFAULT_COOLDOWN_MIN, s.cooldownMin)
        assertEquals(1, s.assumed.size)
    }

    @Test fun baseTrailUrutanPemanasanDulu() {
        val s = QualityWorkout.parse("Pemanasan easy 15 mnt, 3×8 mnt (HR 164–172), jog 2 mnt antar set, pendinginan easy. Bila HR easy naik...", 24.0, listOf(164, 172), "thr")!!
        assertEquals(15, s.warmupMin); assertEquals(3, s.repeats); assertEquals(8, s.runMin)
    }

    @Test fun vo2TanpaTargetHr() {
        val s = QualityWorkout.parse("5×3 mnt di usaha 3K–5K, jog 2–3 mnt antar repetisi. Pace sekitar 4:20/km (usaha 3K–5K).$wu", 15.0, listOf(172, 999), "vo2")!!
        assertEquals(5, s.repeats); assertEquals(3, s.runMin); assertEquals(2, s.recoveryMin)
        assertNull(s.runBand)
    }

    @Test fun repetisiJarakDikonversiKeWaktu() {
        val s = QualityWorkout.parse("6×800 m di pace 5K. Pace sekitar 4:30/km. Jog 2–3 mnt antar repetisi.$wu", 21.6, listOf(150, 170), "rp")!!
        assertEquals(6, s.repeats); assertEquals(4, s.runMin) // 0,8 km x 4:30 = 3,6 mnt -> 4
        assertEquals(2, s.recoveryMin) // "Jog 2–3 mnt" berhuruf besar
        assertTrue(s.assumed.any { it.contains("dikonversi") })
    }

    @Test fun fartlekPotongAtauQ2() {
        val a = QualityWorkout.parse("Fartlek ringan 8×1 mnt kencang, 1 mnt easy.$wu", 0.0, null, "none")!!
        assertEquals(8, a.repeats); assertEquals(1, a.runMin); assertEquals(1, a.recoveryMin)
        val b = QualityWorkout.parse("Fartlek 6×1 mnt kencang di usaha 10K–5K, jog 1 mnt antar repetisi.$wu", 6.0, listOf(172, 999), "vo2")!!
        assertEquals(6, b.repeats); assertEquals(1, b.recoveryMin)
    }

    @Test fun mendakiPanjang() {
        val s = QualityWorkout.parse("Mendaki panjang 60–75 mnt naik terus, power hike. Pemanasan dan pendinginan easy.", 75.0, null, "hike")!!
        assertEquals(1, s.repeats); assertEquals(75, s.runMin)
    }

    @Test fun stridesTanpaStrukturMengembalikanNull() {
        assertNull(QualityWorkout.parse("Strides 4×20 dtk, sisanya easy.", 0.0, null, "none"))
        assertNull(QualityWorkout.parse("Easy dengan strides 4×20 dtk.", 0.0, null, "none"))
    }

    @Test fun targetHrDikonversiKePersenHrMaks() {
        val s = QualityWorkout.parse("Threshold 3×10 mnt (HR 164–172), jog 2 mnt antar set.$wu", 30.0, listOf(164, 172), "thr")!!
        val t = QualityWorkout.targets(s, easyHr = 150, maxHr = 190)
        assertEquals(StepIntensity.HR_PERCENT, t.run.type)
        assertEquals(86, t.run.low); assertEquals(91, t.run.high) // 164/190, 172/190
        assertEquals(50, t.warmup.low); assertEquals(79, t.warmup.high)
        assertEquals(StepIntensity.NONE, t.recovery.type)
        assertNotNull(t.cooldown)
    }

    @Test fun namaJamTidakMelebihiBatas() {
        val n = QualityWorkout.watchName("Tue 12", "Interval VO2max dengan judul yang sangat sangat panjang sekali")
        assertTrue(n.toByteArray(Charsets.UTF_8).size <= 64)
    }
}
