package com.endurancevault.app

import com.endurancevault.app.data.ActStore
import com.endurancevault.app.data.BackupParser
import com.endurancevault.app.data.TrackParsers
import com.endurancevault.app.domain.ActBuilder
import com.endurancevault.app.domain.ActImportException
import com.endurancevault.app.domain.Pt
import java.io.File
import java.time.Instant
import java.time.ZoneOffset
import java.util.Base64
import kotlin.math.abs
import kotlin.math.max
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

/**
 * Mencocokkan ActBuilder / FitParser / pembaca GPX-TCX dengan hasil buildAct() dan parseFit() versi web
 * (tools/golden-act.mjs, zona waktu UTC). Bagian yang belum dikerjakan diabaikan: sg, tl, hz, vz, zs, vam, vs. `gt` (jejak GPS per detik) hanya ada di versi native.
 */
class ActGoldenTest {
    private val unsupported = setOf("sg", "tl", "hz", "vz", "zs", "vam", "vs", "gt")
    private val golden: JSONObject by lazy {
        JSONObject(javaClass.getResourceAsStream("/golden/act-golden.json")!!.bufferedReader().readText())
    }

    private fun pts(a: JSONArray): List<Pt> = (0 until a.length()).map { i ->
        val r = a.getJSONArray(i)
        fun v(k: Int) = if (r.isNull(k)) Double.NaN else r.getDouble(k)
        Pt(la = v(0), lo = v(1), t = v(2), e = v(3), h = v(4), c = v(5), d = v(6))
    }

    private fun cmp(path: String, exp: Any?, act: Any?, errs: MutableList<String>, ignore: Set<String> = emptySet()) {
        if (errs.size > 30) return
        when {
            exp == null || exp == JSONObject.NULL -> if (act != null) errs.add("$path: web=null kotlin=$act")
            exp is JSONObject -> {
                val m = act as? Map<*, *> ?: run { errs.add("$path: web=objek kotlin=$act"); return }
                exp.keys().forEach { k -> if (k !in unsupported && k !in ignore) {
                    if (!m.containsKey(k)) errs.add("$path.$k: ada di web, tidak ada di Kotlin") else cmp("$path.$k", exp.get(k), m[k], errs)
                } }
                m.keys.forEach { k -> if (!exp.has(k.toString()) && k.toString() !in ignore && k.toString() !in unsupported) errs.add("$path.$k: ada di Kotlin, tidak ada di web (${m[k]})") }
            }
            exp is JSONArray -> {
                val l = act as? List<*> ?: run { errs.add("$path: web=larik kotlin=$act"); return }
                if (l.size != exp.length()) { errs.add("$path: panjang web=${exp.length()} kotlin=${l.size}"); return }
                for (i in 0 until exp.length()) cmp("$path[$i]", exp.get(i), l[i], errs)
            }
            exp is Number -> {
                val a = (act as? Number)?.toDouble() ?: run { errs.add("$path: web=$exp kotlin=$act"); return }
                val tol = if (path.startsWith(".ge") || path == "ge" || path.startsWith("ge")) 2e-4 else 1e-6 * max(1.0, abs(exp.toDouble()))
                if (abs(exp.toDouble() - a) > tol) errs.add("$path: web=$exp kotlin=$a")
            }
            else -> if (exp.toString() != act.toString()) errs.add("$path: web=$exp kotlin=$act")
        }
    }

    private fun report(errs: List<String>) = fail("${errs.size} ketidakcocokan:\n" + errs.take(25).joinToString("\n"))

    @Test fun buildActCocokDenganWeb() {
        val errs = mutableListOf<String>()
        val acts = golden.getJSONObject("acts")
        acts.keys().forEach { name ->
            val sc = acts.getJSONObject(name); val exp = sc.getJSONObject("expected")
            if (exp.has("error")) {
                try { ActBuilder.build(pts(sc.getJSONArray("pts")), sc.getString("sport"), sc.getString("nm"), ZoneOffset.UTC); errs.add("[$name] seharusnya galat: ${exp.getString("error")}") }
                catch (e: ActImportException) { if (e.message != exp.getString("error")) errs.add("[$name] pesan galat web=${exp.getString("error")} kotlin=${e.message}") }
                return@forEach
            }
            val out = ActBuilder.build(pts(sc.getJSONArray("pts")), sc.getString("sport"), sc.getString("nm"), ZoneOffset.UTC)
            val e2 = mutableListOf<String>(); cmp("", exp, out, e2)
            e2.forEach { errs.add("[$name] $it") }
        }
        if (errs.isNotEmpty()) report(errs)
    }

    @Test fun fitCocokDenganWeb() {
        val errs = mutableListOf<String>()
        val fits = golden.getJSONObject("fit")
        fits.keys().forEach { name ->
            val sc = fits.getJSONObject(name)
            val bytes = Base64.getDecoder().decode(sc.getString("b64"))
            val t = TrackParsers.parse(bytes)
            val out = ActBuilder.build(t.pts, t.sport, t.name, ZoneOffset.UTC)
            val e2 = mutableListOf<String>(); cmp("", sc.getJSONObject("expected"), out, e2)
            e2.forEach { errs.add("[$name] $it") }
        }
        if (errs.isNotEmpty()) report(errs)
    }

    private fun gpx(p: List<Pt>, name: String, type: String): String = buildString {
        append("""<?xml version="1.0" encoding="UTF-8"?><gpx xmlns="http://www.topografix.com/GPX/1/1" xmlns:gpxtpx="http://www.garmin.com/xmlschemas/TrackPointExtension/v1"><metadata><name>$name</name></metadata><trk><name>$name</name><type>$type</type><trkseg>""")
        p.forEach { q ->
            append("""<trkpt lat="${q.la}" lon="${q.lo}">""")
            if (!q.e.isNaN()) append("<ele>${q.e}</ele>")
            append("<time>${Instant.ofEpochMilli(q.t.toLong())}</time>")
            if (!q.h.isNaN() || !q.c.isNaN()) {
                append("<extensions><gpxtpx:TrackPointExtension>")
                if (!q.h.isNaN()) append("<gpxtpx:hr>${q.h.toInt()}</gpxtpx:hr>")
                if (!q.c.isNaN()) append("<gpxtpx:cad>${q.c.toInt()}</gpxtpx:cad>")
                append("</gpxtpx:TrackPointExtension></extensions>")
            }
            append("</trkpt>")
        }
        append("</trkseg></trk></gpx>")
    }

    private fun tcx(p: List<Pt>, sport: String): String = buildString {
        append("""<?xml version="1.0"?><TrainingCenterDatabase xmlns="http://www.garmin.com/xmlschemas/TrainingCenterDatabase/v2"><Activities><Activity Sport="$sport"><Id>x</Id><Lap StartTime="x"><Track>""")
        p.forEach { q ->
            append("<Trackpoint><Time>${Instant.ofEpochMilli(q.t.toLong())}</Time>")
            if (!q.la.isNaN()) append("<Position><LatitudeDegrees>${q.la}</LatitudeDegrees><LongitudeDegrees>${q.lo}</LongitudeDegrees></Position>")
            if (!q.e.isNaN()) append("<AltitudeMeters>${q.e}</AltitudeMeters>")
            if (!q.d.isNaN()) append("<DistanceMeters>${q.d}</DistanceMeters>")
            if (!q.h.isNaN()) append("<HeartRateBpm><Value>${q.h.toInt()}</Value></HeartRateBpm>")
            if (!q.c.isNaN()) append("<Cadence>${q.c.toInt()}</Cadence>")
            append("</Trackpoint>")
        }
        append("</Track></Lap></Activity></Activities></TrainingCenterDatabase>")
    }

    @Test fun gpxMenghasilkanAktivitasSamaDenganWeb() {
        val sc = golden.getJSONObject("acts").getJSONObject("lari")
        val xml = gpx(pts(sc.getJSONArray("pts")), "Lari pagi", "running")
        val t = TrackParsers.parse(xml.toByteArray())
        assertEquals("Lari pagi", t.name); assertEquals("running", t.sport)
        val errs = mutableListOf<String>()
        cmp("", sc.getJSONObject("expected"), ActBuilder.build(t.pts, t.sport, t.name, ZoneOffset.UTC), errs)
        if (errs.isNotEmpty()) report(errs)
    }

    @Test fun tcxMenghasilkanAktivitasSamaDenganWeb() {
        val sc = golden.getJSONObject("acts").getJSONObject("lari_jarak_perangkat")
        val t = TrackParsers.parse(tcx(pts(sc.getJSONArray("pts")), "Running").toByteArray())
        assertEquals("Running", t.sport)
        val errs = mutableListOf<String>()
        cmp("", sc.getJSONObject("expected"), ActBuilder.build(t.pts, t.sport, t.name, ZoneOffset.UTC), errs, ignore = setOf("nm"))
        if (errs.isNotEmpty()) report(errs)
    }

    @Test fun deretWaktuDibangunPadaResolusiSatuDetik() {
        val sc = golden.getJSONObject("acts").getJSONObject("lari")
        val out = ActBuilder.build(pts(sc.getJSONArray("pts")), "running", "Lari 1 Hz", ZoneOffset.UTC)
        val tl = out["tl"] as? Map<*, *> ?: error("tl 1 Hz tidak dibuat")
        assertEquals(1, (tl["r"] as Number).toInt())
        val seconds = tl["s"] as List<*>
        val hr = tl["h"] as List<*>
        val gap = tl["v"] as List<*>
        val elevation = tl["e"] as List<*>
        assertTrue(seconds.size >= 60)
        assertEquals(seconds.size, hr.size)
        assertEquals(seconds.size, gap.size)
        assertEquals(seconds.size, elevation.size)
        assertEquals(0, (seconds.first() as Number).toInt())
        assertEquals(1, (seconds[1] as Number).toInt())
    }

    @Test fun berkasBukanXmlAtauFitDitolak() {
        try { TrackParsers.parse("halo dunia".toByteArray()); fail() } catch (e: ActImportException) { }
        try { TrackParsers.parse(ByteArray(40) { 7 }); fail() } catch (e: ActImportException) { }
    }

    @Test fun fitTerpotongDitolakTanpaCrash() {
        val b = Base64.getDecoder().decode(golden.getJSONObject("fit").getJSONObject("fit_lari").getString("b64"))
        try { TrackParsers.parse(b.copyOf(b.size / 2)).let { ActBuilder.build(it.pts, it.sport, it.name) }; } catch (e: ActImportException) { }
    }

    @Test fun cadanganActsDiekstrakDanDibacaKembali() {
        val act = golden.getJSONObject("acts").getJSONObject("lari").getJSONObject("expected")
        val backup = """{"app":"rencana-lari","v":1,"s":{},"log":{},"acts":{"2026-11-03":$act,"2026-11-05~f1":{"nm":"Free","km":3.2}}}"""
        val dir = java.nio.file.Files.createTempDirectory("acts").toFile()
        try {
            val keys = BackupParser.extractActs(backup.byteInputStream(), dir)
            assertEquals(listOf("2026-11-03", "2026-11-05~f1"), keys)
            val f = File(dir, ActStore.backupFileName("2026-11-03"))
            assertTrue(f.exists())
            val d = ActStore(dir).read(ActStore.backupFileName("2026-11-03"))
            assertNotNull(d)
            assertEquals(act.getDouble("km"), d!!.km, 1e-9)
            assertEquals(act.getJSONArray("sp").length(), d.splits.size)
            assertEquals(act.getJSONArray("rt").length(), d.route.size)
            assertEquals(act.getJSONObject("h").length(), d.hrHist.size)
            assertTrue(d.hasRoute)
            assertEquals("Free", ActStore(dir).read(ActStore.backupFileName("2026-11-05~f1"))!!.name)
        } finally { dir.deleteRecursively() }
    }

    @Test fun aktivitasHasilBuildBisaDisimpanDanDibaca() {
        val sc = golden.getJSONObject("acts").getJSONObject("lari")
        val map = ActBuilder.build(pts(sc.getJSONArray("pts")), "running", "Lari pagi", ZoneOffset.UTC)
        val dir = java.nio.file.Files.createTempDirectory("acts").toFile()
        try {
            val store = ActStore(dir)
            store.write("f_1.json", map)
            val d = store.read("f_1.json")!!
            assertEquals(map["km"] as Double, d.km, 1e-9)
            assertEquals("Lari pagi", d.name)
            assertEquals((map["sp"] as List<*>).size, d.splits.size)
            assertTrue(d.splits.last().partial)
            assertNotNull(d.timeSeries)
            assertEquals((map["tl"] as Map<*, *>)["s"].let { (it as List<*>).size }, d.timeSeries!!.seconds.size)
            assertEquals(d.timeSeries!!.seconds.size, d.timeSeries!!.gapSpeedCmPerSec.size)
        } finally { dir.deleteRecursively() }
    }
}
