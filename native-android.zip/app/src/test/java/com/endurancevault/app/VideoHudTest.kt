package com.endurancevault.app

import com.endurancevault.app.domain.HudPrefs
import com.endurancevault.app.domain.RouteVideoTrack
import com.endurancevault.app.domain.VideoHud
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class VideoHudTest {
    /** Lari lurus 3 km ke timur, 1 sampel/detik (1080 detik), pace tetap 6:00/km, HR 150. */
    private fun track(): RouteVideoTrack {
        val n = 1080
        val dist = DoubleArray(n) { it * 3000.0 / (n - 1) }
        return RouteVideoTrack(
            lat = DoubleArray(n) { -6.2 }, lon = DoubleArray(n) { 106.8 + dist[it] / 111_320.0 },
            dist = dist, sec = IntArray(n) { it }, hr = IntArray(n) { 150 }, cad = IntArray(n) { 170 },
            ele = DoubleArray(n) { 100.0 + 30.0 * it / (n - 1) }, gradeRaw = DoubleArray(n) { Double.NaN },
            title = "Lari pagi", dateText = "10 Nov 2026",
        )
    }

    @Test fun prefsRoundTrip() {
        val p = HudPrefs(style = "min", accent = "#cbfd00", minimap = false, gauge = false, dim = 40, audio = false)
        val b = HudPrefs.fromJson(p.toJson())
        assertEquals("min", b.style); assertEquals("#CBFD00", b.accent); assertEquals(false, b.minimap)
        assertEquals(false, b.gauge); assertEquals(40, b.dim); assertEquals(false, b.audio)
        assertEquals(HudPrefs(style = "two", accent = "#FF6A13", dim = 60), HudPrefs(style = "zzz", accent = "merah", dim = 500).sanitized())
        assertEquals(HudPrefs(), HudPrefs.fromJson("rusak"))
    }

    @Test fun guessOffsetFromFileTime() {
        val start = 1_800_000_000_000L
        assertEquals(600, VideoHud.guessOffset(start, start + 660_000L, 60.0, 3600))
        assertNull(VideoHud.guessOffset(start, start + 9_000_000L, 60.0, 3600))
        assertNull(VideoHud.guessOffset(0L, start, 60.0, 3600))
        assertNull(VideoHud.guessOffset(start, start, 0.0, 3600))
        assertEquals(-30, VideoHud.guessOffset(start, start + 30_000L, 60.0, 3600))
        assertTrue(VideoHud.offsetRange(3600).contains(3600) && VideoHud.offsetRange(3600).contains(-120))
    }

    @Test fun vmaxFromFastestStretch() {
        val v = VideoHud.vmax(track())
        assertEquals(10.0 * 1.15, v, 0.3)
    }

    @Test fun stateFollowsTimeAndOffset() {
        val t = track()
        assertEquals(0.0, VideoHud.stateAt(t, 0.0, 0).frac, 1e-9)
        assertEquals(0.5, VideoHud.stateAt(t, 270.0, 270).frac, 0.01)
        assertEquals(0.0, VideoHud.stateAt(t, 5.0, -100).frac, 1e-9)
        assertEquals(1.0, VideoHud.stateAt(t, 5000.0, 0).frac, 1e-9)
        val half = VideoHud.stateAt(t, 540.0, 0)
        assertEquals(1500.0, half.distM, 20.0)
    }

    @Test fun valuesAreFormatted() {
        val t = track()
        val st = VideoHud.stateAt(t, 540.0, 0)
        val v = VideoHud.values(t, st, VideoHud.vmax(t))
        assertEquals("6:00", v.pace); assertEquals("150", v.hr); assertTrue(v.time == "9:00" || v.time == "9:01")
        assertEquals("1,50", v.km); assertEquals("10,0", v.speed)
        assertTrue(v.speedFrac in 0.7f..1f)
        assertTrue(v.kmOfTotal.endsWith("3,0"))
        assertEquals(1f, VideoHud.values(t, st, 5.0).speedFrac, 1e-6f)
    }

    @Test fun miniMapIsNormalized() {
        val m = VideoHud.miniMap(track())
        assertTrue(m.x.all { it in 0f..1f } && m.y.all { it in 0f..1f })
        assertEquals(1f, m.w, 1e-3f); assertTrue(m.h < 0.01f)
        val (i0, t0) = VideoHud.miniPos(m, 0.0)
        assertEquals(0, i0); assertEquals(0f, t0, 1e-6f)
        val (i1, _) = VideoHud.miniPos(m, 1.0)
        assertTrue(i1 in 0 until m.x.size - 1)
        assertNotNull(m)
    }
}
