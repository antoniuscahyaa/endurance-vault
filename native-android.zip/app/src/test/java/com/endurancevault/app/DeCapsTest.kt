package com.endurancevault.app

import com.endurancevault.app.ui.i18n.DeCaps
import org.junit.Assert.assertEquals
import org.junit.Test

class DeCapsTest {
    private fun d(s: String) = DeCaps.apply(s)

    @Test fun singkatanMetrikTetapKapital() {
        for (s in listOf("ACWR", "RAI", "VDOT", "VAM", "REM", "OSRM", "HRV", "GPS", "TSS")) assertEquals(s, d(s))
    }

    @Test fun singkatanDiDalamJudulTetapKapital() {
        assertEquals("ACWR, monotony & strain", d("ACWR, MONOTONY & STRAIN"))
        assertEquals("Zona pace dari RAI", d("ZONA PACE DARI RAI"))
        assertEquals("Fitness RAI", d("FITNESS RAI"))
        assertEquals("Base · REC", d("BASE · REC"))
        assertEquals("ACWR 1.25", d("ACWR 1.25"))
    }

    @Test fun tokenGabunganDiprosesPerBagian() {
        assertEquals("A-GPS", d("A-GPS"))
        assertEquals("GPT-OSS 120B", d("GPT-OSS 120B"))
        assertEquals("Δ B−A", d("Δ B−A"))
        assertEquals("HR/pace", d("HR/PACE"))
    }

    @Test fun vsDanKmHurufKecil() {
        assertEquals("Temp vs HR · Each dot is one run", d("TEMP VS HR · EACH DOT IS ONE RUN"))
        assertEquals("km per week", d("KM PER WEEK"))
    }

    @Test fun spo2TidakMenggagalkanKonversi() {
        assertEquals("Sleep SpO₂", d("SLEEP SpO₂"))
        assertEquals("Sleep SpO2", d("SLEEP SpO2"))
    }

    @Test fun kataBiasaMenjadiSentenceCase() {
        assertEquals("Training load", d("TRAINING LOAD"))
        assertEquals("Total minggu ini", d("TOTAL MINGGU INI"))
        assertEquals("HR zones", d("HR ZONES"))
        assertEquals("Zona HR", d("ZONA HR"))
        assertEquals("Tidur", d("TIDUR"))
        assertEquals("Good afternoon", d("GOOD AFTERNOON"))
    }

    @Test fun hariDanBulanTitleCase() {
        assertEquals("Fri 14", d("FRI 14"))
        assertEquals("Mon 12 Nov", d("MON 12 NOV"))
    }

    @Test fun teksCampuranDanPendekDibiarkan() {
        assertEquals("Sleep", d("Sleep"))
        assertEquals("ACWR 1.25 · Waspada", d("ACWR 1.25 · Waspada"))
        assertEquals("HR", d("HR"))
    }
}
