package com.endurancevault.app

import com.endurancevault.app.domain.RouteVideoPrefs
import com.endurancevault.app.domain.HudVideoPrefs
import com.endurancevault.app.domain.TrailVideoPrefs
import org.junit.Assert.assertEquals
import org.junit.Test

class VideoStudioTest {
    @Test fun trailEditorSettingsRoundTrip() {
        val prefs = RouteVideoPrefs(
            videoLayout = "trail",
            trail = TrailVideoPrefs(
                shape = "hex",
                palette = "lime",
                statLayout = "tiles",
                durationSec = 24,
                cardStyle = "solid",
                motion = "orbit",
                metricMode = "custom",
                metrics = listOf("cad", "hr", "none", "time"),
                extraMetrics = true,
                showPeak = false,
                showGradePill = false,
                panelEntrance = true,
                hillshade = false,
                background = "solid",
                solidBackground = "#123456",
                accent = "#27D3FF",
                tilt = 63,
                reliefPercent = 32,
                terrainScale = 8,
                zoomPercent = 125,
                baseY = 11,
                centerX = 12,
                centerY = -8,
                rotation = 45,
                contour = false,
                progressBar = false,
                safeStory = false,
                showHeader = true,
                showLocation = false,
                showWeather = false,
                showElevationChart = false,
                showClimbLabels = false,
                showKmMarkers = false,
                showSummary = false,
                darkenPhoto = 35,
                title = "Merbabu",
                location = "Selo",
                handle = "@runner",
                photoPath = "/data/user/0/app/files/trail.jpg",
            ),
        )
        assertEquals(prefs.sanitized(), RouteVideoPrefs.fromJson(prefs.toJson()))
    }

    @Test fun invalidVideoLayoutFallsBackToStandard() {
        assertEquals("standard", RouteVideoPrefs(videoLayout = "invalid").sanitized().videoLayout)
    }

    @Test fun hudLayoutIsPersisted() {
        val prefs = RouteVideoPrefs(videoLayout = "hud")
        assertEquals("hud", RouteVideoPrefs.fromJson(prefs.toJson()).videoLayout)
    }

    @Test fun hudExportFormatAndCustomAccentAreSanitized() {
        val prefs = HudVideoPrefs(format = "rec", style = "min", accent = "#4CC3FF", dim = 60, keepAudio = false).sanitized()
        assertEquals("rec", prefs.format)
        assertEquals("min", prefs.style)
        assertEquals("#4CC3FF", prefs.accent)
        assertEquals(60, prefs.dim)
        assertEquals(false, prefs.keepAudio)
    }
}
