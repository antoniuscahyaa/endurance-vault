package com.endurancevault.app

import com.endurancevault.app.domain.RouteVideoTrack
import com.endurancevault.app.domain.TrailBox
import com.endurancevault.app.domain.TrailData
import com.endurancevault.app.domain.TrailGeo
import com.endurancevault.app.domain.TrailLayout
import com.endurancevault.app.domain.TrailPrefs
import com.endurancevault.app.domain.TrailProfile
import com.endurancevault.app.domain.TrailRect
import com.endurancevault.app.domain.TrailText
import com.endurancevault.app.domain.TrailTimeline
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import com.endurancevault.app.domain.TrailKeys
import org.junit.Test

class TrailVideoTest {
    /** Lari lurus 3 km ke timur, 1 sampel/detik, pace tetap 6:00/km, naik 30 m. */
    private fun track(n: Int = 1080): RouteVideoTrack {
        val dist = DoubleArray(n) { it * 3000.0 / (n - 1) }
        return RouteVideoTrack(
            lat = DoubleArray(n) { -6.2 }, lon = DoubleArray(n) { 106.8 + dist[it] / 111_320.0 },
            dist = dist, sec = IntArray(n) { it }, hr = IntArray(n) { 150 }, cad = IntArray(n) { 170 },
            ele = DoubleArray(n) { 100.0 + 30.0 * it / (n - 1) }, gradeRaw = DoubleArray(n) { Double.NaN },
            title = "Lari pagi", dateText = "10 Nov 2026",
        )
    }

    @Test fun prefsRoundTripAndSanitize() {
        val p = TrailPrefs(
            layout = "tiles", shape = "hex", palette = "lime", accent = "#abcdef", tilt = 60, relief = 30, spin = 120,
            metrics = listOf("pace", "gap", "vam"), card = "glass", showClimbs = false, extraRow = true, location = "Bromo",
        )
        val back = TrailPrefs.fromJson(p.toJson())
        assertEquals("tiles", back.layout); assertEquals("hex", back.shape); assertEquals("lime", back.palette)
        assertEquals("#ABCDEF", back.accent); assertEquals(60, back.tilt); assertEquals(120, back.spin)
        assertEquals(listOf("pace", "gap", "vam"), back.metrics); assertEquals("glass", back.card)
        assertFalse(back.showClimbs); assertTrue(back.extraRow); assertEquals("Bromo", back.location)
        val bad = TrailPrefs(aspect = "7:3", shape = "star", layout = "x", tilt = 999, relief = -5, durationSec = 1, metrics = listOf("zzz")).sanitized()
        assertEquals("9:16", bad.aspect); assertEquals("circle", bad.shape); assertEquals("classic", bad.layout)
        assertEquals(75, bad.tilt); assertEquals(5, bad.relief); assertEquals(6, bad.durationSec)
        assertEquals(listOf("pace", "hr", "gain", "time"), bad.metrics)
        assertEquals(TrailPrefs(), TrailPrefs.fromJson("bukan json"))
        assertEquals(TrailPrefs(), TrailPrefs.fromJson(null))
    }

    private fun inside(inner: TrailBox, w: Int, h: Int) =
        inner.x >= 0f && inner.y >= 0f && inner.x + inner.w <= w + 1f && inner.y + inner.h <= h + 1f

    @Test fun layoutFitsEveryAspectAndLayout() {
        val sizes = listOf(1080 to 1920, 1080 to 1350, 1080 to 1080, 1920 to 1080)
        for ((w, h) in sizes) for (lay in listOf("classic", "center", "tiles", "compact")) for (extra in listOf(false, true)) {
            val p = TrailPrefs(layout = lay, extraRow = extra)
            val l = TrailLayout.compute(w, h, p)
            assertTrue("scene $w x $h $lay", inside(l.scene, w, h) && l.scene.w > 100f && l.scene.h > 100f)
            assertTrue("stats $w x $h $lay", inside(l.stats, w, h))
            assertTrue("chart $w x $h $lay", inside(l.chart, w, h))
            assertTrue(l.d > 40f && l.d <= l.scene.w)
            assertTrue("cakram di dalam adegan", l.cy + l.d * 0.5f * Math.cos(l.tiltRad).toFloat() <= l.scene.h + 1f)
            if (w <= h) assertTrue("data di bawah adegan", l.scene.y + l.scene.h <= l.stats.y + 1f)
        }
    }

    @Test fun noBarShortensPanel() {
        val a = TrailLayout.compute(1080, 1920, TrailPrefs(showBar = true))
        val b = TrailLayout.compute(1080, 1920, TrailPrefs(showBar = false))
        assertTrue(b.stats.h < a.stats.h)
        assertEquals(170, TrailLayout.slH("classic", false)); assertEquals(140, TrailLayout.slH("classic", true))
    }

    @Test fun niceKmStepAndCircle() {
        assertEquals(1.0, TrailGeo.nice(0.7), 1e-9); assertEquals(2.0, TrailGeo.nice(1.8), 1e-9)
        assertEquals(5.0, TrailGeo.nice(3.2), 1e-9); assertEquals(20.0, TrailGeo.nice(12.0), 1e-9)
        assertEquals(1, TrailGeo.kmStep(8.0)); assertEquals(2, TrailGeo.kmStep(15.0)); assertEquals(5, TrailGeo.kmStep(42.2))
        val xs = FloatArray(200) { (it * 10).toFloat() }; val ys = FloatArray(200) { (Math.sin(it / 20.0) * 300).toFloat() }
        val c = TrailGeo.circle(xs, ys)
        for (i in xs.indices) assertTrue(Math.hypot((xs[i] - c.x).toDouble(), (ys[i] - c.y).toDouble()) <= c.r + 1e-3)
        assertTrue(c.r >= 995f * 1.0f)
    }

    @Test fun polygonMetric() {
        assertEquals(5.0, TrailGeo.metric(0, 3.0, 4.0), 1e-9)
        assertEquals(3.0, TrailGeo.metric(4, 3.0, 0.0), 1e-9)
        assertEquals(1.0 / Math.cos(Math.PI / 6), TrailGeo.outer(6), 1e-9)
        assertEquals(1.0, TrailGeo.edgeR(0, 1.0), 1e-9)
    }

    @Test fun placeAvoidsOverlap() {
        val placed = ArrayList<TrailRect>()
        placed.add(TrailRect(100f, 100f, 80f, 30f))
        val pick = TrailGeo.place(placed, listOf(TrailRect(105f, 105f, 80f, 30f), TrailRect(300f, 100f, 80f, 30f)), 4f)
        assertNotNull(pick); assertEquals(300f, pick!!.x, 1e-3f)
        assertEquals(2, placed.size)
    }

    @Test fun detectsASingleClimb() {
        val n = 240; val tk = 5.0
        val ele = DoubleArray(n) { i ->
            val km = tk * i / (n - 1)
            when { km < 1.5 -> 100.0; km < 3.5 -> 100.0 + (km - 1.5) / 2.0 * 100.0; else -> 200.0 }
        }
        val cl = TrailGeo.climbs(TrailProfile(ele, tk))
        assertEquals(1, cl.size)
        assertEquals(100.0, cl[0].gain, 8.0); assertEquals(5.0, cl[0].avg, 0.8)
        assertTrue(cl[0].k0 in 1.3..1.8 && cl[0].k1 in 3.2..3.7)
        assertTrue(TrailGeo.climbs(TrailProfile(DoubleArray(n) { 100.0 }, tk)).isEmpty())
        assertTrue(TrailGeo.climbs(null).isEmpty())
    }

    @Test fun profilePeak() {
        val p = TrailProfile(doubleArrayOf(10.0, 30.0, 20.0, 5.0), 3.0)
        assertEquals(30.0, p.hi, 1e-9); assertEquals(5.0, p.lo, 1e-9); assertEquals(1.0, p.kHi, 1e-9)
        assertEquals(20.0, p.interp(0.5), 1e-9)
    }

    @Test fun fadeIsSmoothAndBounded() {
        assertEquals(0.0, TrailGeo.fade(0.0, 1.0, 2.0, 0.2), 1e-9)
        assertEquals(1.0, TrailGeo.fade(1.5, 1.0, 2.0, 0.2), 1e-9)
        assertEquals(0.0, TrailGeo.fade(2.5, 1.0, 2.0, 0.2), 1e-9)
    }

    @Test fun timelinePhases() {
        val p = TrailPrefs(durationSec = 20)
        assertEquals(0.8, TrailTimeline.lead(p), 1e-9)
        assertEquals(0.0, TrailTimeline.at(0.3, p).frac, 1e-9)
        assertEquals(0.5, TrailTimeline.at(0.8 + 10.0, p).frac, 1e-9)
        val end = TrailTimeline.at(0.8 + 20.0 + 1.0, p)
        assertEquals(1.0, end.frac, 1e-9); assertEquals(1.0, end.summaryMix, 1e-9)
        assertEquals(0.0, TrailTimeline.at(5.0, p).summaryMix, 1e-9)
        assertEquals(1.0, TrailTimeline.at(1.0, p).panelIn, 1e-9)
        assertTrue(TrailTimeline.at(0.2, p).panelIn < 1.0)
        val noIntro = p.copy(intro = false, summary = false)
        assertEquals(0.0, TrailTimeline.lead(noIntro), 1e-9)
        assertEquals(1.0, TrailTimeline.at(0.0, noIntro).panelIn, 1e-9)
        assertEquals(0.0, TrailTimeline.at(25.0, noIntro).summaryMix, 1e-9)
        assertTrue(TrailTimeline.frames(p) >= (TrailTimeline.total(p) * TrailTimeline.FPS).toInt())
        val spin = p.copy(rotation = 10, spin = 90)
        assertEquals(10.0, TrailTimeline.at(0.0, spin).azimuth, 1e-9)
        assertEquals(100.0, TrailTimeline.at(100.0, spin).azimuth, 1e-9)
    }

    @Test fun timeFormatting() {
        assertEquals("01:02" to "JAM", TrailText.time(3725)); assertEquals("02:05" to "MNT", TrailText.time(125))
        assertEquals("1,50", TrailText.f(1.5, 2))
    }

    @Test fun dataAndColumns() {
        val t = track()
        val d = TrailData(t, null, null)
        assertNotNull(d.profile); assertTrue(d.hasHr); assertNull(d.weatherText())
        val st = t.statsAt(0.5, true)
        val auto = TrailText.columns(TrailPrefs(), st, d, true)
        assertEquals(listOf("PACE", "DENYUT", "NAIK", "WAKTU"), auto.map { it.label })
        assertEquals("6:00", auto[0].value); assertEquals("150", auto[1].value)
        val custom = TrailText.columns(TrailPrefs(autoMetrics = false, metrics = listOf("time", "cad")), st, d, true)
        assertEquals(2, custom.size); assertEquals("CADENCE", custom[1].label); assertEquals("170", custom[1].value)
        val sum = TrailText.columns(TrailPrefs(), t.statsAt(1.0, false), d, false)
        assertEquals("PACE RATA2", sum[0].label)
    }

    @Test fun gapPaceIsFasterThanPaceOnClimb() {
        val t = track(); val d = TrailData(t, null, null)
        val st = t.statsAt(0.9, true)
        val gap = d.gapPace(st)
        assertNotNull(gap)
        assertTrue(gap!! < 6.0 && gap > 4.5)
        assertNull(d.gapPace(t.statsAt(0.0, true)))
        assertNotNull(d.vam(st))
    }

    @Test fun zonesNeedBoundaries() {
        val d = TrailData(track(), null, null)
        assertNull(d.zone(150))
        val z = TrailData(track(), null, listOf(100, 120, 140, 160, 180))
        assertNotNull(z.zone(150))
    }

    // ---------------------------------------------------------------- zoom dan gerak kamera

    private fun prefsWith(f: (TrailPrefs) -> TrailPrefs) = f(TrailPrefs(durationSec = 20, intro = true, summary = true)).sanitized()

    @Test fun defaultTrailCameraIsUnchanged() {
        val p = TrailPrefs(rotation = 30, spin = 90)
        for (t in listOf(0.0, 1.5, 10.0, 21.0, 25.0)) {
            val pt = TrailTimeline.at(t, p)
            assertEquals(1.0, pt.cam.zoom, 1e-12); assertEquals(0.0, pt.cam.tiltDeg, 1e-12)
            assertEquals(0.0, pt.cam.follow, 1e-12); assertEquals(0.0, pt.cam.azDeg, 1e-12)
            assertEquals(30 + 90 * pt.frac, pt.azimuth, 1e-9)   // sama seperti sebelum ada gerak kamera
        }
    }

    @Test fun trailCameraOptionsAreSanitizedAndSaved() {
        val bad = TrailPrefs(zoom = 10, camMove = "terbang", camAmount = 999, shake = -3).sanitized()
        assertEquals(TrailPrefs.MIN_ZOOM, bad.zoom); assertEquals("static", bad.camMove); assertEquals(100, bad.camAmount); assertEquals(0, bad.shake)
        assertEquals(TrailPrefs.MAX_ZOOM, TrailPrefs(zoom = 900).sanitized().zoom)
        val p = TrailPrefs(zoom = 140, camMove = "follow", camAmount = 75, shake = 30)
        val q = TrailPrefs.fromJson(p.toJson())
        assertEquals(140, q.zoom); assertEquals("follow", q.camMove); assertEquals(75, q.camAmount); assertEquals(30, q.shake)
        val old = TrailPrefs.fromJson("{\"tilt\":40}")
        assertEquals(100, old.zoom); assertEquals("static", old.camMove); assertEquals(60, old.camAmount); assertEquals(0, old.shake)
    }

    @Test fun baseZoomAppliesEverywhere() {
        val p = prefsWith { it.copy(zoom = 150) }
        for (t in listOf(0.0, 5.0, 20.8, 30.0)) assertEquals(1.5, TrailTimeline.at(t, p).cam.zoom, 1e-12)
    }

    @Test fun dollyAndPullbackMoveOppositeWays() {
        val dolly = prefsWith { it.copy(camMove = "dolly") }
        val endOfRun = TrailTimeline.lead(dolly) + dolly.durationSec
        assertEquals(1.0, TrailTimeline.at(0.0, dolly).cam.zoom, 1e-9)
        assertEquals(1.0 + 0.9 * 0.6, TrailTimeline.at(endOfRun, dolly).cam.zoom, 1e-9)
        val back = prefsWith { it.copy(camMove = "pullback") }
        assertEquals(1.0 + 0.9 * 0.6, TrailTimeline.at(0.0, back).cam.zoom, 1e-9)
        assertEquals(1.0, TrailTimeline.at(endOfRun, back).cam.zoom, 1e-9)
    }

    @Test fun cameraReturnsToFullViewForTheSummary() {
        for (m in listOf("dolly", "follow", "spiral")) {
            val p = prefsWith { it.copy(camMove = m, camAmount = 100) }
            val last = TrailTimeline.at(TrailTimeline.total(p), p).cam
            assertEquals(m, 1.0, last.zoom, 1e-9); assertEquals(m, 0.0, last.follow, 1e-9)
        }
    }

    @Test fun followZoomsToTheRunnerQuickly() {
        val p = prefsWith { it.copy(camMove = "follow") }
        val mid = TrailTimeline.at(TrailTimeline.lead(p) + p.durationSec * 0.5, p).cam
        assertEquals(1.0 + 1.1 * 0.6, mid.zoom, 1e-9); assertEquals(0.6, mid.follow, 1e-9)
        assertEquals(0.0, TrailTimeline.at(0.0, p).cam.follow, 1e-9)
    }

    @Test fun craneStartsLowAndSpiralAddsRotation() {
        val crane = prefsWith { it.copy(camMove = "crane") }
        assertEquals(28.0 * 0.6, TrailTimeline.at(0.0, crane).cam.tiltDeg, 1e-9)
        assertEquals(0.0, TrailTimeline.at(TrailTimeline.lead(crane) + crane.durationSec, crane).cam.tiltDeg, 1e-9)
        val spiral = prefsWith { it.copy(camMove = "spiral", rotation = 10, spin = 0) }
        val endOfRun = TrailTimeline.lead(spiral) + spiral.durationSec
        assertEquals(10.0 + 160.0 * 0.6, TrailTimeline.at(endOfRun, spiral).azimuth, 1e-9)
    }

    @Test fun trailCameraStaysInSafeBounds() {
        for (m in TrailKeys.CAMERA_MOVES) for (amt in listOf(0, 50, 100)) for (z in listOf(60, 100, 250)) {
            val p = prefsWith { it.copy(camMove = m, camAmount = amt, zoom = z, shake = 100) }
            val frames = TrailTimeline.frames(p)
            for (f in 0 until frames step 7) {
                val c = TrailTimeline.at(f.toDouble() / TrailTimeline.FPS, p).cam
                assertTrue("$m $amt $z zoom ${c.zoom}", c.zoom in 0.4..4.0)
                assertTrue("$m follow ${c.follow}", c.follow in 0.0..1.0)
                assertTrue("$m tilt ${c.tiltDeg}", Math.abs(c.tiltDeg) <= 28.0 + 1.0)
            }
        }
        TrailKeys.CAMERA_MOVES.filter { it != "static" }.forEach { assertTrue(TrailKeys.cameraMoveHint(it).isNotBlank()) }
    }

    @Test fun trailCoverageAndOffsetAreSanitizedAndSaved() {
        val d = TrailPrefs()
        assertEquals(114, d.coverage); assertEquals(0, d.offX); assertEquals(0, d.offZ); assertEquals(0, d.flatEdge); assertFalse(d.blockCut)
        val bad = TrailPrefs(coverage = 10, offX = -500, offZ = 500).sanitized()
        assertEquals(TrailPrefs.MIN_COVERAGE, bad.coverage); assertEquals(-100, bad.offX); assertEquals(100, bad.offZ)
        assertEquals(TrailPrefs.MAX_COVERAGE, TrailPrefs(coverage = 9999).sanitized().coverage)
        assertEquals(100, TrailPrefs(flatEdge = 900).sanitized().flatEdge); assertEquals(0, TrailPrefs(flatEdge = -5).sanitized().flatEdge)
        val q = TrailPrefs.fromJson(TrailPrefs(coverage = 180, offX = -40, offZ = 25, flatEdge = 60, blockCut = true).toJson())
        assertTrue(q.blockCut)
        assertEquals(60, q.flatEdge)
        assertEquals(180, q.coverage); assertEquals(-40, q.offX); assertEquals(25, q.offZ)
        // Pengaturan lama tanpa kolom baru tetap memakai bawaan (tampilan tidak berubah).
        val old = TrailPrefs.fromJson("{\"tilt\":40}")
        assertEquals(114, old.coverage); assertEquals(0, old.offX); assertEquals(0, old.offZ); assertEquals(0, old.flatEdge); assertFalse(old.blockCut)
    }
}
