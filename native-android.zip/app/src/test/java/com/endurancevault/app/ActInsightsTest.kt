package com.endurancevault.app

import com.endurancevault.app.data.ActStore
import com.endurancevault.app.domain.ActInsights
import com.endurancevault.app.domain.ActInsights.SeriesKey
import com.endurancevault.app.domain.ActivityTimeSeries
import com.endurancevault.app.domain.ActDetail
import com.endurancevault.app.domain.PDay
import com.endurancevault.app.domain.Segment
import com.endurancevault.app.domain.Split
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class ActInsightsTest {
    /** 12 km penuh + 0,4 km parsial; nilai acuan dihitung dengan fungsi JS asli (driftOf, gapAct, gapSplit). */
    private fun sampleSplits(): List<Split> =
        (1..12).map { i -> Split(i.toDouble(), 5.8 + 0.03 * i + (i % 3) * 0.05, 140 + i, (i * 3) % 11, (i * 5) % 9, 170, null, false) } +
            Split(12.4, 6.1, 160, 2, 1, 168, null, true)

    @Test fun driftAndGapMatchWebReference() {
        val sp = sampleSplits()
        val d = ActInsights.drift(sp, 12.4, bike = false, skip = false)!!
        assertEquals(6.7, d.pct, 1e-9)
        assertEquals(12.4, d.km, 1e-9)
        assertEquals(6.01712354220327, ActInsights.gapOfActivity(null, sp, hasGain = true, bike = false)!!, 1e-9)
        assertEquals(5.795159750199404, ActInsights.gapOfSplit(sp[2], hasGain = true)!!, 1e-9)
    }

    @Test fun driftIsSkippedForQualityBikeAndShortRuns() {
        val sp = sampleSplits()
        assertNull(ActInsights.drift(sp, 12.4, bike = false, skip = true))
        assertNull(ActInsights.drift(sp, 12.4, bike = true, skip = false))
        assertNull(ActInsights.drift(sp.take(6), 6.0, bike = false, skip = false))
    }

    @Test fun strideTimeAndFastestKm() {
        assertEquals(0.9688162276718136, ActInsights.strideLength(8.8, 55.05, 165)!!, 1e-9)
        assertNull(ActInsights.strideLength(8.8, 55.05, null))
        assertNull(ActInsights.strideLength(8.8, 55.05, 20))
        val t = ActInsights.timeInfo(55.05, 58.5)
        assertEquals("55:03", t.moving); assertEquals("58:30", t.elapsed); assertEquals("3:27", t.pause)
        assertNull(ActInsights.timeInfo(55.0, 55.05).elapsed)
        val fk = ActInsights.fastestKm(sampleSplits(), bike = false)!!
        assertEquals(1.0, fk.k, 1e-9)
        // km parsial pendek (< 0,5 km) tidak boleh jadi juara
        val short = listOf(Split(1.0, 6.0, null, 0, 0, null, null, false), Split(1.2, 3.0, null, 0, 0, null, null, true))
        assertEquals(1.0, ActInsights.fastestKm(short, bike = false)!!.k, 1e-9)
    }

    @Test fun recoveryHeartRateSpreadsValuesOverTwoMinutes() {
        val r = ActInsights.recoveryHr(listOf(160, 150, 144, 140, 137, 135, 133, 132, 131))!!
        assertEquals(160, r.base)
        assertEquals(15.0, r.stepSec, 1e-9)
        assertEquals(137, r.h1)
        assertEquals(23, r.d1)
        assertEquals(29, r.d2)
        assertEquals(131, r.h2)
        assertNull(ActInsights.recoveryHr(listOf(0, 0)))
        assertNull(ActInsights.recoveryHr(listOf(150))!!.d1)
    }

    @Test fun recoveryDurationSwitchesToDaysAfter48Hours() {
        assertEquals("28 jam", ActInsights.recoveryDuration(28.0))
        assertEquals("2,5 hari", ActInsights.recoveryDuration(60.0))
        assertEquals("Meningkatkan", ActInsights.teLabel(3.4))
        assertEquals("Overreaching", ActInsights.teLabel(4.9))
        assertEquals("Hujan", ActInsights.weatherLabel(63))
        assertNull(ActInsights.weatherLabel(7))
    }

    @Test fun commentsCoverIntensityPaceConsistencyDriftAndLoad() {
        val c = ActInsights.comments(
            ActInsights.CommentInput(
                12.4, 76.0, 154, 168, "easy", false, sampleSplits(), 20, null, false,
                sessionLoad = 120.0, previousAvgLoad = 90.0, previousCount = 6, aerobicEffect = 3.4,
            ),
        )
        assertTrue(c.any { it.text.startsWith("HR rata-rata 154 bpm (92% dari LTHR)") && it.level == "ok" })
        assertTrue(c.any { it.text.startsWith("Pace rata-rata 6:08/km, GAP 6:01/km") })
        assertTrue(c.any { it.text.startsWith("Efisiensi turun 6,7%") && it.level == "warn" })
        assertTrue(c.any { it.text.startsWith("Load sesi 120, TE 3,4 (Meningkatkan).") && it.text.contains("1,3×") })
        // sepeda tidak diberi komentar
        assertTrue(ActInsights.comments(ActInsights.CommentInput(30.0, 90.0, 140, 168, null, false, emptyList(), null, null, true, null, null, 0, null)).isEmpty())
    }

    @Test fun complianceFlagsDistanceHrAndQualityBand() {
        val easy = PDay(LocalDate.parse("2026-11-05"), 3, "easy", "run", "Easy", 10.0, "")
        val hist = mapOf(140 to 1800.0, 165 to 600.0)
        val ok = ActInsights.compliance(easy, 9.8, 150, hist, null, easyCap = 150, bike = false)!!
        assertEquals("bad", ok.items.first { it.text.startsWith("HR rata-rata") }.level) // 25% waktu di atas batas easy
        assertEquals("ok", ok.items.first { it.text.startsWith("Jarak") }.level)
        assertEquals("Perlu perhatian", ok.label)
        assertNull(ActInsights.compliance(easy, 9.8, 150, hist, null, 150, bike = true))
        assertNull(ActInsights.compliance(null, 9.8, 150, hist, null, 150, bike = false))
        val q = PDay(LocalDate.parse("2026-11-06"), 4, "quality", "run", "Tempo", 8.0, "").also { it.qk = "thr"; it.qMin = 20.0; it.qBand = listOf(164, 172) }
        val c = ActInsights.compliance(q, 8.0, 160, mapOf(168 to 1200.0, 140 to 600.0), null, 150, bike = false)!!
        assertTrue(c.items.any { it.text.startsWith("20 mnt di zona threshold (164–172)") && it.level == "ok" })
    }

    @Test fun chartModelUsesTimeAxisForOneHertzData() {
        val n = 1200
        val ts = ActivityTimeSeries(
            seconds = (0 until n).toList(), distanceMeters = (0 until n).map { it * 2.8 },
            heartRateBpm = (0 until n).map { 140 + it / 40 }, cadenceSpm = (0 until n).map { if (it < 10) 0 else 168 },
            elevationMeters = (0 until n).map { 100.0 + it * 0.02 }, gapSpeedCmPerSec = (0 until n).map { 280 }, grade = (0 until n).map { 0.0 },
        )
        val d = detail(ts)
        val m = ActInsights.chartModel(d)!!
        assertTrue(m.xIsTime)
        assertEquals(1199.0, m.xMax, 1e-9)
        listOf(SeriesKey.HR, SeriesKey.CAD, SeriesKey.ELEV, SeriesKey.PACE, SeriesKey.VERT).forEach { assertNotNull(it.name, m.get(it)) }
        assertTrue(m.get(SeriesKey.HR)!!.points.size <= 480)
        // 2,8 m/dtk = 5:57/km
        assertEquals(1000.0 / 2.8 / 60, m.get(SeriesKey.PACE)!!.at(600.0), 1e-6)
        val bike = ActInsights.chartModel(d.copyAsBike())!!
        assertNull(bike.get(SeriesKey.PACE))
    }

    @Test fun chartModelFallsBackToDistanceSeries() {
        val d = detail(null, hr = listOf(0.0 to 140.0, 5.0 to 150.0, 10.0 to 155.0), prof = listOf(0.0 to 100.0, 10.0 to 130.0))
        val m = ActInsights.chartModel(d)!!
        assertEquals(false, m.xIsTime)
        assertEquals(10.0, m.xMax, 1e-9)
        assertEquals(145.0, m.get(SeriesKey.HR)!!.at(2.5), 1e-9)
        assertNull(ActInsights.chartModel(detail(null)))
    }

    @Test fun storeParsesWeatherVamBatteryAndVerticalSpeed() {
        val m = mapOf<String, Any?>(
            "date" to "2026-11-05", "st" to "06:14", "nm" to "Running", "km" to 8.8, "min" to 55.05,
            "wx" to mapOf("t" to 26.5, "fl" to 29.0, "h" to 78.0, "w" to 6.0, "r" to 0.0, "c" to 2.0, "dv" to 31.0),
            "vam" to mapOf("a" to 310.0, "b" to 520.0, "w" to 5.0),
            "bat" to mapOf("s" to 60.0, "e" to 55.0, "used" to 5.0, "ap" to 1.0, "ph" to 5.4),
            "vs" to listOf(listOf(0.0, 10.0), listOf(1.0, 320.0)), "t0" to 1.7e12,
        )
        val d = ActStore.fromMap(m)
        assertEquals(26.5, d.weather!!.tempC, 1e-9)
        assertEquals(29.0, d.weather!!.feelsLikeC!!, 1e-9)
        assertEquals(78, d.weather!!.humidityPct)
        assertEquals(2, d.weather!!.code)
        assertEquals(31.0, d.weather!!.watchTempC!!, 1e-9)
        assertEquals(26.5, d.weatherTempC!!, 1e-9)
        assertEquals(310, d.vam!!.avg); assertEquals(520, d.vam!!.best); assertEquals(5, d.vam!!.windowMin)
        assertEquals(5, d.battery!!.usedPct); assertEquals(true, d.battery!!.approx)
        assertEquals(2, d.vertSpeedSeries.size)
        assertEquals(1700000000000L, d.startEpochMs)
        val bare = ActStore.fromMap(mapOf("date" to "2026-11-05", "km" to 5.0, "min" to 30.0))
        assertNull(bare.weather); assertNull(bare.vam); assertNull(bare.battery)
    }

    @Test fun verticalSpeedFallsBackToGainPerHour() {
        assertEquals(300, ActInsights.verticalSpeed(null, 150, 30.0)!!.avg)
        assertNull(ActInsights.verticalSpeed(null, 5, 30.0))
        assertEquals(400, ActInsights.verticalSpeed(com.endurancevault.app.domain.ActVam(400, 600, 5), 150, 30.0)!!.avg)
    }

    @Test fun fastestSegmentIgnoresVeryShortSegments() {
        val segs = listOf(
            Segment(0.0, 0.05, 0.2, 3.0, null, 0, 0, null, "1", null),
            Segment(0.0, 1.0, 5.0, 5.0, null, 0, 0, null, "2", null),
            Segment(0.0, 1.0, 6.0, 6.0, null, 0, 0, null, "3", null),
        )
        assertEquals("2", ActInsights.fastestSegment(segs, bike = false)!!.name)
        assertNull(ActInsights.fastestSegment(segs.take(1), bike = false))
    }

    // ---- util ----
    private fun detail(ts: ActivityTimeSeries?, hr: List<Pair<Double, Double>> = emptyList(), prof: List<Pair<Double, Double>> = emptyList(), bike: Boolean = false) = ActDetail(
        date = "2026-11-05", startTime = "06:14", name = "Run", bike = bike, kind = null, km = 3.0, movingMin = 20.0, elapsedMin = 20.0,
        gain = null, loss = null, hr = null, hrMax = null, cad = null, gapPace = null, splits = emptyList(), segments = emptyList(),
        route = emptyList(), routeW = 0, routeH = 0, profile = prof, paceSeries = emptyList(), hrSeries = hr, cadSeries = emptyList(),
        hrHist = emptyMap(), timeSeries = ts,
    )

    private fun ActDetail.copyAsBike() = detail(timeSeries, hrSeries, profile, bike = true)
}
