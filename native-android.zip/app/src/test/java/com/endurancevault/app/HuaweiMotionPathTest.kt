package com.endurancevault.app

import com.endurancevault.app.data.HuaweiHealthZip
import com.endurancevault.app.data.HuaweiMotionPath
import com.endurancevault.app.domain.ActBuilder
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class HuaweiMotionPathTest {
    private val start = 1_791_711_150_000L

    /** Rekaman sintetis berbentuk seperti ekspor asli: 1 Hz ke utara (~4,4 m/detik), titik penutup tak valid 90,-80. */
    private fun record(sportType: Int = 258, seconds: Int = 120, withHr: Boolean = true): JsonObject {
        val sb = StringBuilder()
        for (k in 0..seconds) {
            val tSec = (start / 1000 + 1 + k).toDouble()
            sb.append("tp=lbs;k=$k;lat=${-7.2664 + k * 0.00004};lon=110.4132;alt=0.0;t=${tSec / 1e9}E9;\n")
        }
        sb.append("tp=lbs;k=${seconds + 1};lat=90.0;lon=-80.0;alt=0.0;t=${(start / 1000 + seconds + 2) / 1e9}E9;\n")
        if (withHr) {
            var k = start + 10_000
            var v = 100
            while (k < start + seconds * 1000) {
                sb.append("tp=h-r;k=$k;v=$v;\n"); k += 5000; v += 1
            }
            sb.append("tp=h-r;k=${start + 5000};v=-1;\n")
        }
        var k = start + 5000
        while (k < start + seconds * 1000) { sb.append("tp=alti;k=$k;v=${480.0 + (k - start) / 5000 * 0.5};\n"); k += 5000 }
        sb.append("tp=cad;k=${start + 5000};v=0;\n")
        val summary = """{"sportType":$sportType,"totalDistance":${seconds * 4},"totalTime":${seconds * 1000}}"""
        val o = JsonObject()
        o.addProperty("startTime", start)
        o.addProperty("endTime", start + seconds * 1000)
        o.addProperty("subType", if (sportType == 258) 4 else 3)
        o.addProperty("timeZone", "+0700")
        o.addProperty("summaryData", summary)
        o.addProperty("detailData", sb.toString())
        return o
    }

    @Test fun titikTakValidDibuangDanSeriDigabungPerDetik() {
        val c = HuaweiMotionPath.convert(record())
        val pts = c.track.pts
        assertEquals("running", c.track.sport)
        assertEquals(121, pts.size)                       // 0..120; penanda 90,-80 tidak ikut
        assertTrue(pts.all { Math.abs(it.la) < 90.0 })
        assertEquals(start + 1000, pts.first().t.toLong())
        assertTrue(pts.first().h.isNaN())                  // sebelum sampel HR pertama (v=-1 dibuang)
        assertEquals(100.0, pts.first { it.t >= start + 10_000 }.h, 0.0)
        assertEquals(480.5, pts.first { it.t >= start + 5000 }.e, 0.0)
        assertTrue(pts.all { it.c.isNaN() })               // kadens 0 pada sepeda tanpa sensor dibuang
        assertEquals(7 * 3600 * 1000, c.zone.rules.getOffset(java.time.Instant.ofEpochMilli(start)).totalSeconds * 1000)
    }

    @Test fun hasilBisaDibangunActBuilder() {
        val c = HuaweiMotionPath.convert(record(seconds = 180))
        val act = ActBuilder.build(c.track.pts, c.track.sport, c.track.name, c.zone, cadScale = 1)
        assertEquals(false, act["bike"])
        val km = act["km"] as Double
        assertTrue("km=$km", km in 0.7..0.85)
        assertNotNull(act["date"])
        // 1791711150 detik epoch + 7 jam = jam setempat di +07:00
        assertEquals(c.zone.rules.getOffset(java.time.Instant.ofEpochMilli(start)).totalSeconds, 7 * 3600)
    }

    @Test fun sepedaDipetakanKeBiking() {
        assertEquals("biking", HuaweiMotionPath.convert(record(sportType = 259)).track.sport)
        assertEquals("hiking", HuaweiMotionPath.sportOf(282))
        assertEquals("running", HuaweiMotionPath.sportOf(4))
    }

    @Test fun jenisTakDidukungDilewati() {
        val r = record(sportType = 140)                    // strength training
        r.addProperty("subType", 140)
        try { HuaweiMotionPath.convert(r); fail("seharusnya Skip") } catch (e: HuaweiMotionPath.Skip) {
            assertTrue(e.reason.contains("140"))
        }
    }

    @Test fun tanpaGpsDilewati() {
        val r = record()
        r.addProperty("detailData", "tp=h-r;k=${start + 5000};v=90;\n")
        try { HuaweiMotionPath.convert(r); fail("seharusnya Skip") } catch (e: HuaweiMotionPath.Skip) {
            assertEquals("tanpa titik GPS", e.reason)
        }
    }

    @Test fun namaEntriJsonJalurGerak() {
        assertTrue(HuaweiHealthZip.isMotionJson("Motion path detail data & description/motion_path_detail_data1792156044304_0.json"))
        assertTrue(HuaweiHealthZip.isMotionJson("Motion path detail data & description\\Motion_path_detail_data1_1.JSON"))
        assertFalse(HuaweiHealthZip.isMotionJson("Motion path detail data & description/Motion_path_detail_data-Data_Field_Description.xlsx"))
        assertFalse(HuaweiHealthZip.isMotionJson("Health detail data & description/health_detail_data1_0.json"))
        assertFalse(HuaweiHealthZip.isMotionJson("SportsHealth data & description/SportsHealth-Data.xls"))
        // pastikan JSON valid juga lolos parser Gson yang dipakai pembaca zip
        assertTrue(JsonParser.parseString("[{\"a\":1}]").isJsonArray)
    }
}
