package com.endurancevault.app

import com.endurancevault.app.domain.FrameStats
import com.endurancevault.app.domain.GhostInfo
import com.endurancevault.app.domain.RouteVideoColors
import com.endurancevault.app.domain.RouteVideoFormat
import com.endurancevault.app.domain.RouteVideoPresets
import com.endurancevault.app.domain.RouteVideoRace
import com.endurancevault.app.domain.allAnchors
import com.endurancevault.app.domain.asPreset
import com.endurancevault.app.domain.kmPace
import com.endurancevault.app.domain.withPreset
import com.endurancevault.app.domain.RouteVideoCamera
import com.endurancevault.app.domain.RouteVideoKeys
import com.endurancevault.app.domain.RouteVideoPrefs
import com.endurancevault.app.domain.seriesSamples
import com.endurancevault.app.domain.bearingAt
import com.endurancevault.app.domain.RouteVideoTimeline
import com.endurancevault.app.domain.RouteVideoGrid
import com.endurancevault.app.domain.RouteVideoText
import com.endurancevault.app.domain.RouteVideoTrack
import com.endurancevault.app.domain.VideoPanel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RouteVideoTest {
    /** Lari lurus 3 km ke timur, 1 sampel/detik, pace tetap 6:00/km, naik 30 m. */
    private fun track(n: Int = 1080, gain: Int? = null, secScale: Double = 1.0, hrRise: Boolean = false): RouteVideoTrack {
        val dist = DoubleArray(n) { it * 3000.0 / (n - 1) }
        return RouteVideoTrack(
            lat = DoubleArray(n) { -6.2 }, lon = DoubleArray(n) { 106.8 + dist[it] / 111_320.0 },
            dist = dist, sec = IntArray(n) { (it * secScale).toInt() },
            hr = IntArray(n) { if (hrRise) 120 + (60.0 * it / (n - 1)).toInt() else 150 }, cad = IntArray(n) { 170 },
            ele = DoubleArray(n) { 100.0 + 30.0 * it / (n - 1) }, gradeRaw = DoubleArray(n) { Double.NaN },
            title = "Lari pagi", dateText = "10 Nov 2026", officialGain = gain,
        )
    }

    @Test fun prefsRoundTripKeepsGridPlacement() {
        val p = RouteVideoPrefs(
            panels = listOf(VideoPanel("pace", 1, 1, 1, 2), VideoPanel("hr", 0, 3, 2, 1)),
            gridCols = 3, gridRows = 4, gridGapX = 24, gridGapY = 48,
            live = false, tilt = 61, exaggeration = 2.5, orbit = 90, ink = "k", durationSec = 20,
        )
        val q = RouteVideoPrefs.fromJson(p.toJson())
        assertEquals(p.panels, q.panels)
        assertEquals(3, q.gridCols); assertEquals(4, q.gridRows); assertEquals(24, q.gridGapX); assertEquals(48, q.gridGapY)
        assertEquals(false, q.live)
        assertEquals(61, q.tilt)
        assertEquals(2.5, q.exaggeration, 1e-9)
        assertEquals("k", q.ink)
        assertEquals(20, q.durationSec)
    }

    @Test fun brokenJsonFallsBackToDefaults() {
        assertEquals(RouteVideoPrefs(), RouteVideoPrefs.fromJson(null))
        assertEquals(RouteVideoPrefs(), RouteVideoPrefs.fromJson("{bukan json"))
    }

    @Test fun sanitizeClampsAndDropsUnknownPanels() {
        val p = RouteVideoPrefs(
            panels = listOf(VideoPanel("pace", -5, 140, 999, 0), VideoPanel("pace", 1, 1, 1, 1), VideoPanel("ngawur", 1, 1, 1, 1)),
            tilt = 5, exaggeration = 99.0, orbit = -3, durationSec = 1, ink = "?", lineColor = "merah", cameraMode = "terbang",
        ).sanitized()
        assertEquals(listOf(VideoPanel("pace", 0, 11, 2, 1)), p.panels)   // melebar penuh, baris dibatasi ke grid 2 x 12
        assertEquals(20, p.tilt); assertEquals(4.0, p.exaggeration, 1e-9); assertEquals(0, p.orbit)
        assertEquals(6, p.durationSec); assertEquals("w", p.ink); assertEquals("#C6F432", p.lineColor)
        assertEquals("orbit", p.cameraMode)
    }

    @Test fun defaultPanelsFitEveryGridSize() {
        for ((cols, rows) in listOf(4 to 4, 1 to 1, 6 to 4, 3 to 2, 2 to 3, 1 to 4)) {
            RouteVideoKeys.ALL.forEach { k ->
                val d = RouteVideoKeys.defaultPanel(k, cols, rows)
                assertEquals(k, d.key)
                assertTrue("$k di grid $cols x $rows", RouteVideoGrid.fits(d, cols, rows))
            }
            val layout = RouteVideoKeys.defaultLayout(cols, rows)
            assertTrue(layout.isNotEmpty())
            for (a in layout) for (b in layout) if (a !== b) assertTrue(!RouteVideoGrid.overlaps(a, b))
        }
    }

    @Test fun cameraTimelineStartsAtZeroAndEndsAtOne() {
        val prefs = RouteVideoPrefs()
        assertEquals(0.0, RouteVideoCamera.at(0.0, prefs).routeFrac, 1e-9)
        assertEquals(0.0, RouteVideoCamera.at(RouteVideoCamera.T_IN, prefs).routeFrac, 1e-9)
        assertEquals(1.0, RouteVideoCamera.at(RouteVideoCamera.T_OUT, prefs).routeFrac, 1e-9)
        assertEquals(1.0, RouteVideoCamera.at(1.0, prefs).routeFrac, 1e-9)
        // Bagian lari: kemajuan rute naik terus.
        var last = -1.0
        for (i in 0..100) { val r = RouteVideoCamera.at(i / 100.0, prefs).routeFrac; assertTrue(r >= last); last = r }
    }

    @Test fun cameraPitchFollowsTiltInTheMiddle() {
        val c = RouteVideoCamera.at(0.5, RouteVideoPrefs(tilt = 40))
        assertEquals(40.0, c.pitchDeg, 1e-6)
        assertEquals(1.0, c.distMul, 1e-6)
    }

    @Test fun liveStatsFollowRunnerPosition() {
        val t = track()
        val half = t.statsAt(0.5, live = true)
        assertEquals(1500.0, half.distM, 5.0)
        assertEquals(540.0, half.sec.toDouble(), 3.0)
        assertEquals(6.0, half.pace!!, 0.05)
        assertEquals(150, half.hr)
        assertEquals(170, half.cad)
        val start = t.statsAt(0.0, live = true)
        assertEquals(0.0, start.distM, 1e-9)
        assertEquals(0.0, start.gain, 1e-9)
    }

    @Test fun totalStatsSummariseWholeRun() {
        val s = track().statsAt(0.2, live = false)
        assertEquals(3000.0, s.distM, 1e-6)
        assertEquals(1079, s.sec)
        assertEquals(6.0, s.pace!!, 0.05)
        assertEquals(150, s.hr)
        assertTrue(s.gain > 20.0)
    }

    @Test fun gainCanBeAlignedToOfficialValue() {
        val s = track(gain = 55).statsAt(1.0, live = true)
        assertEquals(55.0, s.gain, 0.5)
    }

    @Test fun gradeIsDerivedFromElevationWhenMissing() {
        // 30 m naik dalam 3000 m = 1%
        val g = track().statsAt(0.5, live = true).grade
        assertNotNull(g)
        assertEquals(1.0, g!!, 0.1)
    }

    @Test fun profileSamplesRiseMonotonically() {
        val p = track().profileSamples(50)
        assertEquals(50, p.size)
        for (i in 1 until p.size) assertTrue(p[i] >= p[i - 1] - 1e-9)
    }

    @Test fun missingHeartRateShowsDash() {
        val st = FrameStats(0, 0.0, 0.0, 0, null, null, null, null, 0.0, null)
        assertEquals("–", RouteVideoText.cell("hr", st, true, false)!!.value)
        assertEquals("–", RouteVideoText.cell("pace", st, true, false)!!.value)
        assertEquals("–", RouteVideoText.cell("grad", st, true, false)!!.value)
        assertNull(RouteVideoText.cell("judul", st, true, false))
    }

    @Test fun cellsUseIndonesianFormatting() {
        val st = FrameStats(1, .5, 5234.0, 1830, 5.5, 152, 3.24, 123.4, 85.0, 172)
        assertEquals("5,23", RouteVideoText.cell("jarak", st, true, false)!!.value)
        assertEquals("30:30", RouteVideoText.cell("waktu", st, true, false)!!.value)
        assertEquals("5:30", RouteVideoText.cell("pace", st, true, false)!!.value)
        assertEquals("+3,2", RouteVideoText.cell("grad", st, true, false)!!.value)
        assertEquals("123", RouteVideoText.cell("elev", st, true, false)!!.value)
        assertEquals("10,9", RouteVideoText.cell("pace", st, true, true)!!.value)   // sepeda: km/j
        assertEquals("10 Nov 2026", RouteVideoText.dateId("2026-11-10"))
    }

    // ---- Preset, format, warna, bendera, ghost ----

    @Test fun newPrefsFieldsRoundTrip() {
        val custom = RouteVideoPrefs().asPreset("Favorit")
        val p = RouteVideoPrefs(lineMode = "pace", kmMarkers = false, flagEnds = false, flagPeak = true, flagSteep = false,
            hillshade = false, fog = false, bgRender = false, aspect = "4:5", quality = "sd", presets = listOf(custom),
        )
        val q = RouteVideoPrefs.fromJson(p.toJson())
        assertEquals("pace", q.lineMode); assertEquals(false, q.kmMarkers)
        assertEquals(false, q.flagEnds); assertEquals(true, q.flagPeak); assertEquals(false, q.flagSteep)
        assertEquals(false, q.hillshade); assertEquals(false, q.fog); assertEquals(false, q.bgRender)
        assertEquals("4:5", q.aspect); assertEquals("sd", q.quality)
        assertEquals(listOf(custom), q.presets)
    }

    @Test fun invalidNewFieldsFallBack() {
        val p = RouteVideoPrefs(lineMode = "ngawur", aspect = "3:2", quality = "uhd").sanitized()
        assertEquals("solid", p.lineMode); assertEquals("9:16", p.aspect); assertEquals("hd", p.quality)
    }

    @Test fun builtInPresetsAreValidAndApplyCleanly() {
        RouteVideoPresets.BUILT_IN.forEach { pr ->
            assertEquals(pr, pr.sanitized())
            val applied = RouteVideoPrefs().withPreset(pr)
            assertEquals(pr.panels, applied.panels)
            assertEquals(pr.lineMode, applied.lineMode)
            assertEquals(pr, applied.asPreset(pr.name))
        }
        assertTrue(RouteVideoPresets.isBuiltIn("Minimal"))
    }

    @Test fun userPresetsAreCappedAndDeduplicated() {
        val many = (1..20).map { RouteVideoPrefs().asPreset("P$it") } + RouteVideoPrefs().asPreset("P1")
        val p = RouteVideoPrefs(presets = many).sanitized()
        assertEquals(12, p.presets.size)
        assertEquals(p.presets.map { it.name }.distinct(), p.presets.map { it.name })
    }

    @Test fun outputSizesAreEvenAndMatchAspect() {
        RouteVideoFormat.ASPECTS.forEach { a ->
            listOf("hd", "sd").forEach { q ->
                val (w, h) = RouteVideoFormat.size(a, q)
                assertTrue(w % 2 == 0 && h % 2 == 0)
            }
            val (pw, ph) = RouteVideoFormat.previewSize(a)
            assertEquals(RouteVideoFormat.ratio(a).toDouble(), pw.toDouble() / ph, 0.01)
        }
        assertEquals(1080 to 1920, RouteVideoFormat.size("9:16", "hd"))
        assertEquals(1280 to 720, RouteVideoFormat.size("16:9", "sd"))
    }

    @Test fun rampEndpointsAndSolidMode() {
        assertEquals(0xFF2F80ED.toInt(), RouteVideoColors.ramp(0.0))
        assertEquals(0xFFEB4D4B.toInt(), RouteVideoColors.ramp(1.0))
        val t = track()
        val accent = 0xFFC6F432.toInt()
        assertEquals(listOf(accent, accent), RouteVideoColors.colors(t, "solid", accent, floatArrayOf(0.1f, 0.9f)).toList())
    }

    @Test fun heartRateModeGetsWarmerAsHrRises() {
        val t = track(hrRise = true)
        val c = RouteVideoColors.colors(t, "hr", 0, floatArrayOf(0.05f, 0.95f))
        val redLow = (c[0] shr 16) and 255; val redHigh = (c[1] shr 16) and 255
        val blueLow = c[0] and 255; val blueHigh = c[1] and 255
        assertTrue(redHigh > redLow)
        assertTrue(blueLow > blueHigh)
        assertNotNull(RouteVideoColors.info(t, "hr"))
    }

    @Test fun anchorsContainStartFinishAndKmFlags() {
        val a = track().allAnchors()
        assertEquals(1, a.count { it.kind == "start" })
        assertEquals(1, a.count { it.kind == "finish" })
        assertEquals(listOf(1, 2), a.filter { it.kind == "km" }.map { it.km })
        assertTrue(a.none { it.kind == "steep" })       // tanjakan 1% tidak layak diberi bendera
        assertTrue(a.any { it.kind == "peak" })         // naik 30 m >= ambang 15 m
        val km1 = a.first { it.kind == "km" }
        assertEquals(6.0, track().kmPace(km1)!!, 0.05)
        assertEquals("6:00 /km", RouteVideoText.anchorLabel(km1, track()).second)
        assertEquals("KM 1", RouteVideoText.anchorLabel(km1, track()).first)
    }

    @Test fun timeAndDistanceAreConsistent() {
        val t = track()
        assertEquals(540.0, t.timeAtDist(1500.0), 3.0)
        assertEquals(0.5, t.fracAtTime(540.0), 0.01)
        assertEquals(0.0, t.fracAtTime(-5.0), 1e-9)
        assertEquals(1.0, t.fracAtTime(99999.0), 1e-9)
    }

    @Test fun raceUsesSameClockForBothRunners() {
        val main = track()
        val ghost = track(secScale = 1.2)   // 20% lebih lambat
        val race = RouteVideoRace(main, ghost)
        val (m, g) = race.fractions(0.5)
        assertTrue(m > g)
        assertEquals(1.0, race.fractions(1.0).first, 1e-9)
        assertEquals(1.0, race.fractions(1.0).second, 1e-9)
        assertEquals(108.0, race.gapSeconds(0.5), 6.0)    // ghost tiba ±108 dtk lebih lambat di km 1,5
        val cam = RouteVideoCamera.at(RouteVideoCamera.T_OUT, RouteVideoPrefs(), race)
        assertEquals(1.0, cam.routeFrac, 1e-9)
        assertEquals(1.0, cam.ghostFrac!!, 1e-9)
        assertNull(RouteVideoCamera.at(0.5, RouteVideoPrefs()).ghostFrac)
    }

    @Test fun ghostGapTextSaysAheadOrBehind() {
        assertEquals("0:12", RouteVideoText.ghostCell(GhostInfo("Budi", 12.0)).value)
        assertEquals("unggul", RouteVideoText.ghostCell(GhostInfo("Budi", 12.0)).unit)
        assertEquals("tertinggal", RouteVideoText.ghostCell(GhostInfo("Budi", -30.0)).unit)
        assertEquals("sama", RouteVideoText.ghostCell(GhostInfo("Budi", 0.4)).unit)
        assertEquals("VS BUDI", RouteVideoText.ghostCell(GhostInfo("Budi", 1.0)).label)
    }

    // ---- Sakelar per fitur ----

    @Test fun everyFeatureSwitchDefaultsToOn() {
        val p = RouteVideoPrefs()
        assertTrue(p.kmMarkers && p.flagEnds && p.flagPeak && p.flagSteep && p.flagFast && p.flagHrMax)
        assertTrue(p.hillshade && p.fog && p.bgRender && p.summary && p.showDate)
        assertEquals("solid", p.lineMode)   // warna garis berdasarkan data adalah pilihan, bukan bawaan
        assertEquals("orbit", p.cameraMode)
        assertEquals(4, p.gridCols); assertEquals(4, p.gridRows); assertEquals(12, p.gridGapX); assertEquals(12, p.gridGapY)
    }

    @Test fun lineWidthRoundTripsAndIsClamped() {
        assertEquals(100, RouteVideoPrefs().lineWidth)
        assertEquals(180, RouteVideoPrefs.fromJson(RouteVideoPrefs(lineWidth = 180).toJson()).lineWidth)
        assertEquals(50, RouteVideoPrefs(lineWidth = 5).sanitized().lineWidth)
        assertEquals(250, RouteVideoPrefs(lineWidth = 900).sanitized().lineWidth)
        assertEquals(100, RouteVideoPrefs.fromJson("""{"tilt":50}""").lineWidth)   // pengaturan lama tanpa ketebalan
    }

    @Test fun anchorFlagsAreIndependent() {
        val p = RouteVideoPrefs(kmMarkers = true, flagEnds = false, flagPeak = true, flagSteep = false)
        assertTrue(p.showsAnchor("km"))
        assertTrue(!p.showsAnchor("start") && !p.showsAnchor("finish"))
        assertTrue(p.showsAnchor("peak"))
        assertTrue(!p.showsAnchor("steep"))
        assertTrue(!p.showsAnchor("tidak-dikenal"))
        val all = RouteVideoPrefs(flagEnds = true)
        assertTrue(all.showsAnchor("start") && all.showsAnchor("finish"))
    }

    @Test fun oldSingleLabelSwitchFansOutToThreeFlags() {
        val off = RouteVideoPrefs.fromJson("""{"lb":false,"km":true}""")
        assertTrue(!off.flagEnds && !off.flagPeak && !off.flagSteep && off.kmMarkers)
        val on = RouteVideoPrefs.fromJson("""{"lb":true}""")
        assertTrue(on.flagEnds && on.flagPeak && on.flagSteep)
        // sakelar baru menang atas yang lama
        val mixed = RouteVideoPrefs.fromJson("""{"lb":false,"fp":true}""")
        assertTrue(mixed.flagPeak && !mixed.flagEnds && !mixed.flagSteep)
    }

    @Test fun presetsKeepFlagsAndReadOldFormat() {
        val p = RouteVideoPrefs(flagEnds = false, flagPeak = true, flagSteep = false).asPreset("Uji")
        val back = RouteVideoPrefs.fromJson(RouteVideoPrefs(presets = listOf(p)).toJson()).presets.single()
        assertEquals(p, back)
        val applied = RouteVideoPrefs().withPreset(back)
        assertTrue(!applied.flagEnds && applied.flagPeak && !applied.flagSteep)
        val old = RouteVideoPrefs.fromJson("""{"presets":[{"n":"Lama","p":[],"lb":false}]}""").presets.single()
        assertTrue(!old.flagEnds && !old.flagPeak && !old.flagSteep)
        assertTrue(RouteVideoPresets.BUILT_IN.first { it.name == "Minimal" }.let { !it.flagEnds && !it.kmMarkers })
        assertTrue(RouteVideoPresets.BUILT_IN.first { it.name == "Lengkap" }.let { it.flagEnds && it.flagPeak && it.flagSteep && it.kmMarkers })
    }

    // ---- Grid ----

    @Test fun gridGeometryMatchesFrame() {
        // Area: kiri 64.8, atas 96, lebar 950.4, tinggi 1708.8 -> sel 2 x 4 berukuran 475.2 x 427.2
        val r = RouteVideoGrid.rect(VideoPanel("x", 1, 2, 1, 1), 1080, 1920, 2, 4)
        assertEquals(540.0, r[0], 0.1); assertEquals(950.4, r[1], 0.1)
        assertEquals(1015.2, r[2], 0.1); assertEquals(1377.6, r[3], 0.1)
        assertEquals(0 to 0, RouteVideoGrid.cellAt(100.0, 100.0, 1080, 1920, 2, 4))
        assertEquals(1 to 3, RouteVideoGrid.cellAt(700.0, 1900.0, 1080, 1920, 2, 4))
        assertEquals(0 to 0, RouteVideoGrid.cellAt(-50.0, -50.0, 1080, 1920, 2, 4))   // di luar area dibatasi ke sel terdekat
    }

    @Test fun gapInsetsEachPanelSoNeighboursAreSeparatedByTheFullGap() {
        // jarak horizontal dan vertikal diatur terpisah
        val a = RouteVideoGrid.rect(VideoPanel("a", 0, 0), 1080, 1920, 2, 4, gapX = 40, gapY = 100)
        val b = RouteVideoGrid.rect(VideoPanel("b", 1, 0), 1080, 1920, 2, 4, gapX = 40, gapY = 100)
        val c = RouteVideoGrid.rect(VideoPanel("c", 0, 1), 1080, 1920, 2, 4, gapX = 40, gapY = 100)
        assertEquals(40.0, b[0] - a[2], 0.01)                  // antar kolom = gapX
        assertEquals(100.0, c[1] - a[3], 0.01)                 // antar baris = gapY
        // hanya satu arah yang diubah: arah lain tidak ikut
        val a0 = RouteVideoGrid.rect(VideoPanel("a", 0, 0), 1080, 1920, 2, 4, gapX = 0, gapY = 100)
        val b0 = RouteVideoGrid.rect(VideoPanel("b", 1, 0), 1080, 1920, 2, 4, gapX = 0, gapY = 100)
        assertEquals(0.0, b0[0] - a0[2], 0.01)
        // panel yang memakai dua sel tidak punya jarak di dalamnya
        val wide = RouteVideoGrid.rect(VideoPanel("w", 0, 0, 2, 1), 1080, 1920, 2, 4, gapX = 40, gapY = 100)
        assertEquals(a[0], wide[0], 1e-9); assertEquals(b[2], wide[2], 1e-9)
        // gap 0 = tanpa jarak; jarak ikut diskalakan menurut sisi pendek bingkai (720 px = 2/3 dari 1080)
        val z = RouteVideoGrid.rect(VideoPanel("z", 0, 0), 1080, 1920, 2, 4)
        assertEquals(64.8, z[0], 0.01)
        assertEquals(40.0 * 720 / 1080, RouteVideoGrid.gapPx(40, 720, 1280), 1e-9)
        // jarak sangat besar tidak membuat panel terbalik
        val huge = RouteVideoGrid.rect(VideoPanel("h", 0, 0), 1080, 1920, 6, 4, gapX = 120, gapY = 120)
        assertTrue(huge[2] > huge[0] && huge[3] > huge[1])
    }

    @Test fun gapRoundTripsAndIsClamped() {
        val q = RouteVideoPrefs.fromJson(RouteVideoPrefs(gridGapX = 30, gridGapY = 70).toJson())
        assertEquals(30, q.gridGapX); assertEquals(70, q.gridGapY)
        assertEquals(120, RouteVideoPrefs(gridGapX = 999, gridGapY = 999).sanitized().gridGapY)
        assertEquals(0, RouteVideoPrefs(gridGapX = -5).sanitized().gridGapX)
        val pr = RouteVideoPrefs(gridGapX = 20, gridGapY = 50).asPreset("Renggang")
        assertEquals(20, pr.gridGapX); assertEquals(50, pr.gridGapY)
        val applied = RouteVideoPrefs().withPreset(pr)
        assertEquals(20, applied.gridGapX); assertEquals(50, applied.gridGapY)
        assertEquals(pr, RouteVideoPrefs.fromJson(RouteVideoPrefs(presets = listOf(pr)).toJson()).presets.single())
    }

    @Test fun oldSingleGapSettingFillsBothDirections() {
        val q = RouteVideoPrefs.fromJson("""{"gg":33}""")
        assertEquals(33, q.gridGapX); assertEquals(33, q.gridGapY)
        val pr = LayoutPreset.fromJson(com.google.gson.JsonParser.parseString("""{"n":"Lama","p":[],"gg":18}"""))!!
        assertEquals(18, pr.gridGapX); assertEquals(18, pr.gridGapY)
    }

    @Test fun gridDefaultsAreWiderThanTall() {
        assertTrue(RouteVideoKeys.DEFAULT_COLS >= RouteVideoKeys.DEFAULT_ROWS)
        assertEquals(1, RouteVideoGrid.MIN_ROWS); assertEquals(4, RouteVideoGrid.MAX_ROWS)
        val d = RouteVideoKeys.defaultLayout()
        assertEquals(setOf("judul", "profil", "jarak", "waktu", "pace", "hr"), d.map { it.key }.toSet())
        // empat angka utama berdampingan di baris terakhir
        assertEquals(listOf(3), d.filter { it.key in setOf("jarak", "waktu", "pace", "hr") }.map { it.row }.distinct())
    }

    @Test fun oldTwentyRowGridIsRescaledToTheCurrentRows() {
        val json = """{"gc":2,"gr":12,"panels":[{"k":"judul","c":0,"r":0,"cs":2,"rs":1},{"k":"profil","c":0,"r":6,"cs":2,"rs":2},{"k":"jarak","c":0,"r":8,"cs":1,"rs":1},{"k":"waktu","c":1,"r":8,"cs":1,"rs":1}]}"""
        val q = RouteVideoPrefs.fromJson(json)
        assertEquals(2, q.gridCols); assertEquals(4, q.gridRows)
        assertEquals(setOf("judul", "profil", "jarak", "waktu"), q.panels.map { it.key }.toSet())
        q.panels.forEach { assertTrue(RouteVideoGrid.fits(it, q.gridCols, q.gridRows)) }
        for (a in q.panels) for (b in q.panels) if (a !== b) assertTrue(!RouteVideoGrid.overlaps(a, b))
        val rs = RouteVideoGrid.rescaleRows(listOf(VideoPanel("a", 0, 11), VideoPanel("b", 0, 0, 1, 12)), 12, 4)
        assertEquals(listOf(VideoPanel("a", 0, 3, 1, 1), VideoPanel("b", 0, 0, 1, 4)), rs)
    }

    @Test fun placementRefusesOverlapAndOutOfBounds() {
        val a = VideoPanel("a", 0, 0, 2, 1); val b = VideoPanel("b", 0, 1)
        val list = listOf(a, b)
        assertTrue(RouteVideoGrid.overlaps(a, VideoPanel("c", 1, 0)))
        assertTrue(!RouteVideoGrid.overlaps(a, b))
        assertNull(RouteVideoGrid.place(list, b.copy(row = 0), 2, 4))        // menimpa a
        assertNull(RouteVideoGrid.place(list, b.copy(col = 2), 2, 4))        // keluar kolom
        assertNull(RouteVideoGrid.place(list, b.copy(row = 4), 2, 4))        // keluar baris
        assertEquals(listOf(a, b.copy(col = 1, row = 3)), RouteVideoGrid.place(list, b.copy(col = 1, row = 3), 2, 4))
    }

    @Test fun addUsesDefaultSpotElseFirstFreeCellElseNull() {
        val onlyJudul = listOf(RouteVideoKeys.defaultPanel("judul"))
        val withJarak = RouteVideoGrid.add(onlyJudul, "jarak", 4, 4)!!
        assertEquals(RouteVideoKeys.defaultPanel("jarak"), withJarak.first { it.key == "jarak" })
        // posisi bawaan sudah dipakai panel lain: pindah ke sel kosong pertama
        val blocker = VideoPanel("x", 0, 3)   // tepat di posisi bawaan "jarak"
        val moved = RouteVideoGrid.add(listOf(blocker), "jarak", 4, 4)!!.first { it.key == "jarak" }
        assertTrue(!RouteVideoGrid.overlaps(blocker, moved))
        // grid penuh
        val full = (0 until 4).map { VideoPanel("p$it", 0, it) }
        assertNull(RouteVideoGrid.add(full, "jarak", 1, 4))
        assertEquals(VideoPanel("p3", 0, 3, 1, 1), RouteVideoGrid.firstFree(full.take(3), "p3", 1, 1, 1, 4))
    }

    @Test fun fitResolvesConflictsAndDropsWhatCannotFit() {
        val fixed = RouteVideoGrid.fit(listOf(VideoPanel("a", 0, 0), VideoPanel("b", 0, 0)), 2, 4)
        assertEquals(listOf(VideoPanel("a", 0, 0), VideoPanel("b", 1, 0)), fixed)
        val tiny = RouteVideoGrid.fit(listOf(VideoPanel("a", 0, 0), VideoPanel("b", 0, 0)), 1, 1)
        assertEquals(listOf(VideoPanel("a", 0, 0)), tiny)
    }

    @Test fun changingGridSizeKeepsAValidLayout() {
        val p = RouteVideoPrefs(gridCols = 99, gridRows = 0).sanitized()
        assertEquals(6, p.gridCols); assertEquals(1, p.gridRows)
        assertEquals(4, RouteVideoPrefs(gridRows = 20).sanitized().gridRows)
        p.panels.forEach { assertTrue(RouteVideoGrid.fits(it, 6, 1)) }
        for (a in p.panels) for (b in p.panels) if (a !== b) assertTrue(!RouteVideoGrid.overlaps(a, b))
    }

    @Test fun oldPercentPanelsKeepTheirKeysButMoveToGridDefaults() {
        val q = RouteVideoPrefs.fromJson("""{"panels":[{"k":"pace","x":10.0,"y":50.0,"s":100},{"k":"hr","x":60.0,"y":50.0,"s":100},{"k":"ngawur","x":1,"y":1,"s":1}]}""")
        assertEquals(setOf("pace", "hr"), q.panels.map { it.key }.toSet())
        q.panels.forEach { assertTrue(RouteVideoGrid.fits(it, q.gridCols, q.gridRows)) }
    }

    @Test fun presetsRememberGridSize() {
        val p = RouteVideoPrefs(gridCols = 4, gridRows = 3, panels = listOf(VideoPanel("jarak", 3, 2))).asPreset("Empat")
        assertEquals(4, p.gridCols); assertEquals(3, p.gridRows)
        val applied = RouteVideoPrefs().withPreset(p)
        assertEquals(4, applied.gridCols); assertEquals(listOf(VideoPanel("jarak", 3, 2)), applied.panels)
        val back = RouteVideoPrefs.fromJson(RouteVideoPrefs(presets = listOf(p)).toJson()).presets.single()
        assertEquals(p, back)
    }

    // ---- Judul, ringkasan, kamera, linimasa ----

    @Test fun titleAndSummarySettingsRoundTrip() {
        val p = RouteVideoPrefs(titleText = "Lari Pagi ", subtitle = "Gunung Pancar", showDate = false, summary = false, cameraMode = "chase")
        val q = RouteVideoPrefs.fromJson(p.toJson())
        assertEquals("Lari Pagi ", q.titleText)          // spasi di akhir tidak dibuang saat mengetik
        assertEquals("Gunung Pancar", q.subtitle)
        assertEquals(false, q.showDate); assertEquals(false, q.summary); assertEquals("chase", q.cameraMode)
        assertEquals(60, RouteVideoPrefs(titleText = "x".repeat(100)).sanitized().titleText.length)
        assertEquals(80, RouteVideoPrefs(subtitle = "y".repeat(100)).sanitized().subtitle.length)
    }

    @Test fun bearingFollowsTheRouteDirection() {
        assertEquals(90.0, track().bearingAt(0.5), 1.0)   // rute lurus ke timur
    }

    @Test fun cameraModesBehaveDifferently() {
        val t = track()
        val orbit = RouteVideoCamera.at(0.5, RouteVideoPrefs(), null, t)
        assertEquals(0.0, orbit.chaseWeight, 1e-9)
        val chase = RouteVideoCamera.at(0.5, RouteVideoPrefs(cameraMode = "chase"), null, t)
        assertEquals(1.0, chase.chaseWeight, 1e-9)
        assertEquals(-90.0, chase.chaseAzDeg, 1.0)       // kamera di belakang pelari yang menuju timur = di sisi barat
        assertEquals(0.0, RouteVideoCamera.at(0.5, RouteVideoPrefs(cameraMode = "chase"), null, null).chaseWeight, 1e-9)
        assertEquals(0.0, RouteVideoCamera.at(0.0, RouteVideoPrefs(cameraMode = "chase"), null, t).chaseWeight, 1e-9)   // pengantar: gambaran umum
        val top = RouteVideoCamera.at(0.5, RouteVideoPrefs(cameraMode = "top", orbit = 120), null, t)
        assertEquals(85.0, top.pitchDeg, 1e-9); assertEquals(0.0, top.azimuthDeg, 1e-9)
    }

    @Test fun timelineAppendsSummarySegment() {
        val on = RouteVideoPrefs(durationSec = 15, summary = true)
        assertEquals(18.0, RouteVideoTimeline.totalSec(on), 1e-9)
        assertEquals(540, RouteVideoTimeline.frames(on, 30))
        assertEquals(0.6, RouteVideoTimeline.at(0.5, on).p, 1e-9)        // 9 dtk dari 15
        assertEquals(0.0, RouteVideoTimeline.at(0.5, on).summaryAlpha, 1e-9)
        assertEquals(1.0, RouteVideoTimeline.at(15.0 / 18.0, on).p, 1e-9)
        assertEquals(0.0, RouteVideoTimeline.at(15.0 / 18.0, on).summaryAlpha, 1e-9)
        assertEquals(1.0, RouteVideoTimeline.at(1.0, on).summaryAlpha, 1e-9)
        val off = RouteVideoPrefs(durationSec = 15, summary = false)
        assertEquals(15.0, RouteVideoTimeline.totalSec(off), 1e-9)
        assertEquals(0.0, RouteVideoTimeline.at(1.0, off).summaryAlpha, 1e-9)
    }

    // ---- Sorotan otomatis ----

    /** 3 km: km pertama 6:00/km, km kedua 4:00/km, km ketiga 6:00/km. */
    private fun trackWithFastMiddleKm(): RouteVideoTrack {
        val n = 1080
        val dist = DoubleArray(n) { it * 3000.0 / (n - 1) }
        val sec = IntArray(n)
        var t = 0.0
        for (i in 1 until n) {
            val rate = if (dist[i] in 1000.0..2000.0) 0.24 else 0.36   // detik per meter
            t += (dist[i] - dist[i - 1]) * rate
            sec[i] = t.toInt()
        }
        return RouteVideoTrack(
            lat = DoubleArray(n) { -6.2 }, lon = DoubleArray(n) { 106.8 + dist[it] / 111_320.0 },
            dist = dist, sec = sec, hr = IntArray(n) { 150 }, cad = IntArray(n) { 170 },
            ele = DoubleArray(n) { 100.0 }, gradeRaw = DoubleArray(n) { Double.NaN }, title = "Uji", dateText = "",
        )
    }

    @Test fun fastestKmAnchorMarksTheQuickestThousandMetres() {
        val t = trackWithFastMiddleKm()
        val a = t.allAnchors().first { it.kind == "fast" }
        assertEquals(4.0, a.value, 0.1)
        assertEquals(2000.0, t.dist[t.indexAtDist(a.frac * t.totalM)], 15.0)   // ujung jendela di sekitar km 2
        assertEquals("TERCEPAT", RouteVideoText.anchorLabel(a, t).first)
        assertEquals("4:00 /km", RouteVideoText.anchorLabel(a, t).second)
    }

    @Test fun maxHeartRateAnchorSitsAtThePeak() {
        val t = track(hrRise = true)
        val a = t.allAnchors().first { it.kind == "hrmax" }
        assertTrue(a.value in 170.0..181.0)
        assertTrue(a.frac > 0.9)
        assertEquals("HR MAKS", RouteVideoText.anchorLabel(a, t).first)
        // tanpa data HR tidak ada bendera HR
        val noHr = RouteVideoTrack(
            lat = DoubleArray(100) { -6.2 }, lon = DoubleArray(100) { 106.8 + it * 0.0001 }, dist = DoubleArray(100) { it * 30.0 },
            sec = IntArray(100) { it * 10 }, hr = IntArray(100) { 0 }, cad = IntArray(100) { 0 },
            ele = DoubleArray(100) { Double.NaN }, gradeRaw = DoubleArray(100) { Double.NaN }, title = "", dateText = "",
        )
        assertTrue(noHr.allAnchors().none { it.kind == "hrmax" })
    }

    @Test fun highlightFlagsFollowTheirSwitches() {
        val p = RouteVideoPrefs(flagFast = false, flagHrMax = true)
        assertTrue(!p.showsAnchor("fast")); assertTrue(p.showsAnchor("hrmax"))
    }

    @Test fun seriesSamplesAreCachedAndFilled() {
        val t = track()
        val vals = DoubleArray(t.n) { if (it < 10) Double.NaN else it.toDouble() }
        val a = t.seriesSamples("uji", vals, 50)
        assertEquals(50, a.size)
        assertTrue(a.all { it.isFinite() })
        assertTrue(a === t.seriesSamples("uji", vals, 50))
        for (i in 1 until a.size) assertTrue(a[i] >= a[i - 1])
    }
}
