package com.endurancevault.app

import com.endurancevault.app.domain.FrameStats
import com.endurancevault.app.domain.GhostInfo
import com.endurancevault.app.domain.RouteVideoColors
import com.endurancevault.app.domain.RouteVideoFormat
import com.endurancevault.app.domain.RouteVideoPresets
import com.endurancevault.app.domain.RouteVideoRace
import com.endurancevault.app.domain.allAnchors
import com.endurancevault.app.domain.asPreset
import com.endurancevault.app.domain.kmPace
import com.endurancevault.app.domain.withPreset
import com.endurancevault.app.domain.RouteVideoCamera
import com.endurancevault.app.domain.RouteVideoKeys
import com.endurancevault.app.domain.RouteVideoPrefs
import com.endurancevault.app.domain.seriesSamples
import com.endurancevault.app.domain.bearingAt
import com.endurancevault.app.domain.RouteVideoTimeline
import com.endurancevault.app.domain.RouteVideoLayout
import com.endurancevault.app.domain.RouteVideoText
import com.endurancevault.app.domain.RouteVideoTrack
import com.endurancevault.app.domain.LayoutPreset
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RouteVideoTest {
    /** Lari lurus 3 km ke timur, 1 sampel/detik, pace tetap 6:00/km, naik 30 m. */
    private fun track(n: Int = 1080, gain: Int? = null, secScale: Double = 1.0, hrRise: Boolean = false): RouteVideoTrack {
        val dist = DoubleArray(n) { it * 3000.0 / (n - 1) }
        return RouteVideoTrack(
            lat = DoubleArray(n) { -6.2 }, lon = DoubleArray(n) { 106.8 + dist[it] / 111_320.0 },
            dist = dist, sec = IntArray(n) { (it * secScale).toInt() },
            hr = IntArray(n) { if (hrRise) 120 + (60.0 * it / (n - 1)).toInt() else 150 }, cad = IntArray(n) { 170 },
            ele = DoubleArray(n) { 100.0 + 30.0 * it / (n - 1) }, gradeRaw = DoubleArray(n) { Double.NaN },
            title = "Lari pagi", dateText = "10 Nov 2026", officialGain = gain,
        )
    }

    @Test fun prefsRoundTripKeepsLayout() {
        val lay = RouteVideoLayout(
            stats = listOf("pace", "hr", "gain"), statMode = "cols", statRows = 2, statCols = 3, statSize = 140, statColor = "#FF7A1A",
            titleSize = 80, titleColor = "#111111", showChart = true, chartKind = "grafikhr", chartW = 70, chartH = 220,
            legend = true, swap = true, marginX = 30, marginBottom = 120, padX = 24, padY = 48, chartGap = 8,
            scrim = false, scrimOpacity = 70,
        )
        val p = RouteVideoPrefs(layout = lay, live = false, tilt = 61, exaggeration = 2.5, orbit = 90, durationSec = 20)
        val q = RouteVideoPrefs.fromJson(p.toJson())
        assertEquals(lay, q.layout)
        assertEquals(false, q.live)
        assertEquals(61, q.tilt)
        assertEquals(2.5, q.exaggeration, 1e-9)
        assertEquals(20, q.durationSec)
    }

    @Test fun brokenJsonFallsBackToDefaults() {
        assertEquals(RouteVideoPrefs(), RouteVideoPrefs.fromJson(null))
        assertEquals(RouteVideoPrefs(), RouteVideoPrefs.fromJson("{bukan json"))
    }

    @Test fun sanitizeClampsLayoutAndOtherFields() {
        val p = RouteVideoPrefs(
            layout = RouteVideoLayout(
                stats = listOf("pace", "ngawur", "pace", "hr"), statMode = "melayang", statRows = 9, statCols = 0, statSize = 5, titleSize = 999,
                statColor = "merah", titleColor = "#abc", chartKind = "?", chartW = 1, chartH = 9999,
                marginX = -4, marginBottom = 9999, padX = 999, padY = -1, chartGap = 500,
            ),
            tilt = 5, exaggeration = 99.0, orbit = -3, durationSec = 1, lineColor = "merah", cameraMode = "terbang",
        ).sanitized()
        val l = p.layout
        assertEquals(listOf("pace", "hr"), l.stats)                   // kunci tak dikenal dan ganda dibuang
        assertEquals("rows", l.statMode)
        assertEquals(2, l.statRows); assertEquals(2, l.statCols)       // baris 1..2, kolom 2..4
        assertEquals(50, l.statSize); assertEquals(200, l.titleSize)
        assertEquals("#FFFFFF", l.statColor); assertEquals("#FFFFFF", l.titleColor)
        assertEquals("profil", l.chartKind)
        assertEquals(30, l.chartW); assertEquals(500, l.chartH)
        assertEquals(0, l.marginX); assertEquals(400, l.marginBottom)
        assertEquals(120, l.padX); assertEquals(0, l.padY); assertEquals(120, l.chartGap)
        assertEquals(20, p.tilt); assertEquals(4.0, p.exaggeration, 1e-9); assertEquals(0, p.orbit)
        assertEquals(6, p.durationSec); assertEquals("#C6F432", p.lineColor)
        assertEquals("orbit", p.cameraMode)
        assertEquals("#FF7A1A", RouteVideoLayout(statColor = "#ff7a1a").sanitized().statColor)   // hex huruf kecil diterima
    }

    @Test fun cameraTimelineStartsAtZeroAndEndsAtOne() {
        val prefs = RouteVideoPrefs()
        assertEquals(0.0, RouteVideoCamera.at(0.0, prefs).routeFrac, 1e-9)
        assertEquals(0.0, RouteVideoCamera.at(RouteVideoCamera.T_IN, prefs).routeFrac, 1e-9)
        assertEquals(1.0, RouteVideoCamera.at(RouteVideoCamera.T_OUT, prefs).routeFrac, 1e-9)
        assertEquals(1.0, RouteVideoCamera.at(1.0, prefs).routeFrac, 1e-9)
        // Bagian lari: kemajuan rute naik terus.
        var last = -1.0
        for (i in 0..100) { val r = RouteVideoCamera.at(i / 100.0, prefs).routeFrac; assertTrue(r >= last); last = r }
    }

    @Test fun cameraPitchFollowsTiltInTheMiddle() {
        val c = RouteVideoCamera.at(0.5, RouteVideoPrefs(tilt = 40))
        assertEquals(40.0, c.pitchDeg, 1e-6)
        assertEquals(1.0, c.distMul, 1e-6)
    }

    @Test fun liveStatsFollowRunnerPosition() {
        val t = track()
        val half = t.statsAt(0.5, live = true)
        assertEquals(1500.0, half.distM, 5.0)
        assertEquals(540.0, half.sec.toDouble(), 3.0)
        assertEquals(6.0, half.pace!!, 0.05)
        assertEquals(150, half.hr)
        assertEquals(170, half.cad)
        val start = t.statsAt(0.0, live = true)
        assertEquals(0.0, start.distM, 1e-9)
        assertEquals(0.0, start.gain, 1e-9)
    }

    @Test fun totalStatsSummariseWholeRun() {
        val s = track().statsAt(0.2, live = false)
        assertEquals(3000.0, s.distM, 1e-6)
        assertEquals(1079, s.sec)
        assertEquals(6.0, s.pace!!, 0.05)
        assertEquals(150, s.hr)
        assertTrue(s.gain > 20.0)
    }

    @Test fun gainCanBeAlignedToOfficialValue() {
        val s = track(gain = 55).statsAt(1.0, live = true)
        assertEquals(55.0, s.gain, 0.5)
    }

    @Test fun gradeIsDerivedFromElevationWhenMissing() {
        // 30 m naik dalam 3000 m = 1%
        val g = track().statsAt(0.5, live = true).grade
        assertNotNull(g)
        assertEquals(1.0, g!!, 0.1)
    }

    @Test fun profileSamplesRiseMonotonically() {
        val p = track().profileSamples(50)
        assertEquals(50, p.size)
        for (i in 1 until p.size) assertTrue(p[i] >= p[i - 1] - 1e-9)
    }

    @Test fun missingHeartRateShowsDash() {
        val st = FrameStats(0, 0.0, 0.0, 0, null, null, null, null, 0.0, null)
        assertEquals("–", RouteVideoText.cell("hr", st, true, false)!!.value)
        assertEquals("–", RouteVideoText.cell("pace", st, true, false)!!.value)
        assertEquals("–", RouteVideoText.cell("grad", st, true, false)!!.value)
        assertNull(RouteVideoText.cell("judul", st, true, false))
    }

    @Test fun cellsUseIndonesianFormatting() {
        val st = FrameStats(1, .5, 5234.0, 1830, 5.5, 152, 3.24, 123.4, 85.0, 172)
        assertEquals("5,23", RouteVideoText.cell("jarak", st, true, false)!!.value)
        assertEquals("30:30", RouteVideoText.cell("waktu", st, true, false)!!.value)
        assertEquals("5:30", RouteVideoText.cell("pace", st, true, false)!!.value)
        assertEquals("+3,2", RouteVideoText.cell("grad", st, true, false)!!.value)
        assertEquals("123", RouteVideoText.cell("elev", st, true, false)!!.value)
        assertEquals("10,9", RouteVideoText.cell("pace", st, true, true)!!.value)   // sepeda: km/j
        assertEquals("10 Nov 2026", RouteVideoText.dateId("2026-11-10"))
    }

    // ---- Preset, format, warna, bendera, ghost ----

    @Test fun newPrefsFieldsRoundTrip() {
        val custom = RouteVideoPrefs().asPreset("Favorit")
        val p = RouteVideoPrefs(lineMode = "pace", kmMarkers = false, flagEnds = false, flagPeak = true, flagSteep = false,
            hillshade = false, fog = false, bgRender = false, aspect = "4:5", quality = "sd", presets = listOf(custom),
        )
        val q = RouteVideoPrefs.fromJson(p.toJson())
        assertEquals("pace", q.lineMode); assertEquals(false, q.kmMarkers)
        assertEquals(false, q.flagEnds); assertEquals(true, q.flagPeak); assertEquals(false, q.flagSteep)
        assertEquals(false, q.hillshade); assertEquals(false, q.fog); assertEquals(false, q.bgRender)
        assertEquals("4:5", q.aspect); assertEquals("sd", q.quality)
        assertEquals(listOf(custom), q.presets)
    }

    @Test fun invalidNewFieldsFallBack() {
        val p = RouteVideoPrefs(lineMode = "ngawur", aspect = "3:2", quality = "uhd").sanitized()
        assertEquals("solid", p.lineMode); assertEquals("9:16", p.aspect); assertEquals("hd", p.quality)
    }

    @Test fun builtInPresetsAreValidAndApplyCleanly() {
        RouteVideoPresets.BUILT_IN.forEach { pr ->
            assertEquals(pr, pr.sanitized())
            val applied = RouteVideoPrefs().withPreset(pr)
            assertEquals(pr.layout, applied.layout)
            assertEquals(pr.lineMode, applied.lineMode)
            assertEquals(pr, applied.asPreset(pr.name))
        }
        assertTrue(RouteVideoPresets.isBuiltIn("Minimal"))
    }

    @Test fun userPresetsAreCappedAndDeduplicated() {
        val many = (1..20).map { RouteVideoPrefs().asPreset("P$it") } + RouteVideoPrefs().asPreset("P1")
        val p = RouteVideoPrefs(presets = many).sanitized()
        assertEquals(12, p.presets.size)
        assertEquals(p.presets.map { it.name }.distinct(), p.presets.map { it.name })
    }

    @Test fun outputSizesAreEvenAndMatchAspect() {
        RouteVideoFormat.ASPECTS.forEach { a ->
            listOf("hd", "sd").forEach { q ->
                val (w, h) = RouteVideoFormat.size(a, q)
                assertTrue(w % 2 == 0 && h % 2 == 0)
            }
            val (pw, ph) = RouteVideoFormat.previewSize(a)
            assertEquals(RouteVideoFormat.ratio(a).toDouble(), pw.toDouble() / ph, 0.01)
        }
        assertEquals(1080 to 1920, RouteVideoFormat.size("9:16", "hd"))
        assertEquals(1280 to 720, RouteVideoFormat.size("16:9", "sd"))
    }

    @Test fun rampEndpointsAndSolidMode() {
        assertEquals(0xFF2F80ED.toInt(), RouteVideoColors.ramp(0.0))
        assertEquals(0xFFEB4D4B.toInt(), RouteVideoColors.ramp(1.0))
        val t = track()
        val accent = 0xFFC6F432.toInt()
        assertEquals(listOf(accent, accent), RouteVideoColors.colors(t, "solid", accent, floatArrayOf(0.1f, 0.9f)).toList())
    }

    @Test fun heartRateModeGetsWarmerAsHrRises() {
        val t = track(hrRise = true)
        val c = RouteVideoColors.colors(t, "hr", 0, floatArrayOf(0.05f, 0.95f))
        val redLow = (c[0] shr 16) and 255; val redHigh = (c[1] shr 16) and 255
        val blueLow = c[0] and 255; val blueHigh = c[1] and 255
        assertTrue(redHigh > redLow)
        assertTrue(blueLow > blueHigh)
        assertNotNull(RouteVideoColors.info(t, "hr"))
    }

    @Test fun anchorsContainStartFinishAndKmFlags() {
        val a = track().allAnchors()
        assertEquals(1, a.count { it.kind == "start" })
        assertEquals(1, a.count { it.kind == "finish" })
        assertEquals(listOf(1, 2), a.filter { it.kind == "km" }.map { it.km })
        assertTrue(a.none { it.kind == "steep" })       // tanjakan 1% tidak layak diberi bendera
        assertTrue(a.any { it.kind == "peak" })         // naik 30 m >= ambang 15 m
        val km1 = a.first { it.kind == "km" }
        assertEquals(6.0, track().kmPace(km1)!!, 0.05)
        assertEquals("6:00 /km", RouteVideoText.anchorLabel(km1, track()).second)
        assertEquals("KM 1", RouteVideoText.anchorLabel(km1, track()).first)
    }

    @Test fun timeAndDistanceAreConsistent() {
        val t = track()
        assertEquals(540.0, t.timeAtDist(1500.0), 3.0)
        assertEquals(0.5, t.fracAtTime(540.0), 0.01)
        assertEquals(0.0, t.fracAtTime(-5.0), 1e-9)
        assertEquals(1.0, t.fracAtTime(99999.0), 1e-9)
    }

    @Test fun raceUsesSameClockForBothRunners() {
        val main = track()
        val ghost = track(secScale = 1.2)   // 20% lebih lambat
        val race = RouteVideoRace(main, ghost)
        val (m, g) = race.fractions(0.5)
        assertTrue(m > g)
        assertEquals(1.0, race.fractions(1.0).first, 1e-9)
        assertEquals(1.0, race.fractions(1.0).second, 1e-9)
        assertEquals(108.0, race.gapSeconds(0.5), 6.0)    // ghost tiba ±108 dtk lebih lambat di km 1,5
        val cam = RouteVideoCamera.at(RouteVideoCamera.T_OUT, RouteVideoPrefs(), race)
        assertEquals(1.0, cam.routeFrac, 1e-9)
        assertEquals(1.0, cam.ghostFrac!!, 1e-9)
        assertNull(RouteVideoCamera.at(0.5, RouteVideoPrefs()).ghostFrac)
    }

    @Test fun ghostGapTextSaysAheadOrBehind() {
        assertEquals("0:12", RouteVideoText.ghostCell(GhostInfo("Budi", 12.0)).value)
        assertEquals("unggul", RouteVideoText.ghostCell(GhostInfo("Budi", 12.0)).unit)
        assertEquals("tertinggal", RouteVideoText.ghostCell(GhostInfo("Budi", -30.0)).unit)
        assertEquals("sama", RouteVideoText.ghostCell(GhostInfo("Budi", 0.4)).unit)
        assertEquals("VS BUDI", RouteVideoText.ghostCell(GhostInfo("Budi", 1.0)).label)
    }

    // ---- Sakelar per fitur ----

    @Test fun everyFeatureSwitchDefaultsToOn() {
        val p = RouteVideoPrefs()
        assertTrue(p.kmMarkers && p.flagEnds && p.flagPeak && p.flagSteep && p.flagFast && p.flagHrMax)
        assertTrue(p.hillshade && p.fog && p.bgRender && p.summary && p.showDate)
        assertEquals("solid", p.lineMode)   // warna garis berdasarkan data adalah pilihan, bukan bawaan
        assertEquals("orbit", p.cameraMode)
        assertEquals(RouteVideoLayout(), p.layout)
        assertEquals(listOf("jarak", "waktu", "pace", "hr"), p.layout.stats)
        assertTrue(p.layout.showChart && !p.layout.swap)
    }

    @Test fun lineWidthRoundTripsAndIsClamped() {
        assertEquals(100, RouteVideoPrefs().lineWidth)
        assertEquals(180, RouteVideoPrefs.fromJson(RouteVideoPrefs(lineWidth = 180).toJson()).lineWidth)
        assertEquals(50, RouteVideoPrefs(lineWidth = 5).sanitized().lineWidth)
        assertEquals(250, RouteVideoPrefs(lineWidth = 900).sanitized().lineWidth)
        assertEquals(100, RouteVideoPrefs.fromJson("""{"tilt":50}""").lineWidth)   // pengaturan lama tanpa ketebalan
    }

    @Test fun anchorFlagsAreIndependent() {
        val p = RouteVideoPrefs(kmMarkers = true, flagEnds = false, flagPeak = true, flagSteep = false)
        assertTrue(p.showsAnchor("km"))
        assertTrue(!p.showsAnchor("start") && !p.showsAnchor("finish"))
        assertTrue(p.showsAnchor("peak"))
        assertTrue(!p.showsAnchor("steep"))
        assertTrue(!p.showsAnchor("tidak-dikenal"))
        val all = RouteVideoPrefs(flagEnds = true)
        assertTrue(all.showsAnchor("start") && all.showsAnchor("finish"))
    }

    @Test fun oldSingleLabelSwitchFansOutToThreeFlags() {
        val off = RouteVideoPrefs.fromJson("""{"lb":false,"km":true}""")
        assertTrue(!off.flagEnds && !off.flagPeak && !off.flagSteep && off.kmMarkers)
        val on = RouteVideoPrefs.fromJson("""{"lb":true}""")
        assertTrue(on.flagEnds && on.flagPeak && on.flagSteep)
        // sakelar baru menang atas yang lama
        val mixed = RouteVideoPrefs.fromJson("""{"lb":false,"fp":true}""")
        assertTrue(mixed.flagPeak && !mixed.flagEnds && !mixed.flagSteep)
    }

    @Test fun presetsKeepFlagsAndReadOldFormat() {
        val p = RouteVideoPrefs(flagEnds = false, flagPeak = true, flagSteep = false).asPreset("Uji")
        val back = RouteVideoPrefs.fromJson(RouteVideoPrefs(presets = listOf(p)).toJson()).presets.single()
        assertEquals(p, back)
        val applied = RouteVideoPrefs().withPreset(back)
        assertTrue(!applied.flagEnds && applied.flagPeak && !applied.flagSteep)
        val old = RouteVideoPrefs.fromJson("""{"presets":[{"n":"Lama","p":[],"lb":false}]}""").presets.single()
        assertTrue(!old.flagEnds && !old.flagPeak && !old.flagSteep)
        assertTrue(RouteVideoPresets.BUILT_IN.first { it.name == "Minimal" }.let { !it.flagEnds && !it.kmMarkers })
        assertTrue(RouteVideoPresets.BUILT_IN.first { it.name == "Lengkap" }.let { it.flagEnds && it.flagPeak && it.flagSteep && it.kmMarkers })
    }

    // ---- Susunan judul, grafik, dan data ----

    @Test fun defaultPutsChartDirectlyAboveStatsAtTheBottom() {
        val pl = RouteVideoLayout().plan(1080, 1920, 4, hasChart = true, hasLegend = false)
        assertEquals(4, pl.cols); assertEquals(1, pl.rows)
        val chart = pl.chart!!
        pl.stats.forEach {
            assertEquals(1850.0, it[3], 1e-6)            // margin bawah 70
            assertEquals(90.0, it[3] - it[1], 1e-6)       // tinggi sel bawaan
            assertEquals(16.0, it[1] - chart[3], 1e-6)    // grafik tepat di atas data, berjarak chartGap
        }
        assertEquals(160.0, chart[3] - chart[1], 1e-6)
        assertEquals(65.0, chart[0], 1e-6); assertEquals(1015.0, chart[2], 1e-6)   // lebar penuh area isi
    }

    @Test fun swapPutsStatsAboveTheChart() {
        val pl = RouteVideoLayout(swap = true).plan(1080, 1920, 4, hasChart = true, hasLegend = false)
        val chart = pl.chart!!
        assertEquals(1850.0, chart[3], 1e-6)              // grafik kini yang paling bawah
        pl.stats.forEach { assertEquals(16.0, chart[1] - it[3], 1e-6) }
        // menukar dua kali kembali ke susunan semula
        assertEquals(RouteVideoLayout(), RouteVideoLayout(swap = true).copy(swap = false))
    }

    @Test fun rowsModeUsesOneOrTwoRowsAndColsModeUsesTwoToFourColumns() {
        val rows = RouteVideoLayout(statMode = "rows", statRows = 2)
        assertEquals(3 to 2, rows.gridFor(6)); assertEquals(2 to 2, rows.gridFor(4)); assertEquals(1 to 1, rows.gridFor(1))
        assertEquals(6 to 1, RouteVideoLayout(statMode = "rows", statRows = 1).sanitized().gridFor(6))
        val cols = RouteVideoLayout(statMode = "cols", statCols = 3)
        assertEquals(3 to 2, cols.gridFor(6)); assertEquals(3 to 1, cols.gridFor(3)); assertEquals(2 to 1, cols.gridFor(2))
        assertEquals(4 to 2, RouteVideoLayout(statMode = "cols", statCols = 4).gridFor(8))
        assertEquals(0 to 0, rows.gridFor(0))
        // sel urut baris demi baris
        val pl = cols.plan(1080, 1920, 5, false, false)
        assertEquals(5, pl.stats.size)
        assertTrue(pl.stats[3][1] > pl.stats[0][1])            // data ke-4 turun ke baris kedua
        assertEquals(pl.stats[0][0], pl.stats[3][0], 1e-9)     // dan kembali ke kolom pertama
    }

    @Test fun marginAndPaddingMoveTheBlock() {
        val lay = RouteVideoLayout(marginX = 100, marginBottom = 200, padX = 40, padY = 30, statRows = 2, stats = RouteVideoKeys.STAT.take(4))
        val pl = lay.plan(1080, 1920, 4, hasChart = false, hasLegend = false)
        assertEquals(100.0, pl.stats[0][0], 1e-6)                          // margin kiri
        assertEquals(980.0, pl.stats[1][2], 1e-6)                          // margin kanan: 1080 - 100
        assertEquals(40.0, pl.stats[1][0] - pl.stats[0][2], 1e-6)          // padding horizontal
        assertEquals(30.0, pl.stats[2][1] - pl.stats[0][3], 1e-6)          // padding vertikal
        assertEquals(1720.0, pl.stats[2][3], 1e-6)                         // margin bawah 200
        assertNull(pl.chart)
    }

    @Test fun chartSizeIsAdjustableAndFontSizeScalesCellHeight() {
        val pl = RouteVideoLayout(chartW = 50, chartH = 300, statSize = 200).plan(1080, 1920, 4, true, false)
        val chart = pl.chart!!
        assertEquals(475.0, chart[2] - chart[0], 1e-6)                     // 50% dari lebar isi 950
        assertEquals(300.0, chart[3] - chart[1], 1e-6)
        assertEquals(180.0, pl.stats[0][3] - pl.stats[0][1], 1e-6)         // huruf 200% -> sel dua kali lebih tinggi
        assertEquals(65.0, chart[0], 1e-6)                                 // rata kiri
    }

    @Test fun layoutScalesWithShortSideSoSdMatchesHd() {
        val hd = RouteVideoLayout().plan(1080, 1920, 4, true, false)
        val sd = RouteVideoLayout().plan(720, 1280, 4, true, false)
        val k = 720.0 / 1080.0
        assertEquals(hd.chart!![1] * k, sd.chart!![1], 1e-6)
        assertEquals(hd.stats[2][0] * k, sd.stats[2][0], 1e-6)
    }

    @Test fun legendSitsAboveTheTopmostBlockAndEmptyLayoutIsEmpty() {
        val pl = RouteVideoLayout().plan(1080, 1920, 4, hasChart = true, hasLegend = true)
        assertTrue(pl.legend!![3] <= pl.chart!![1])
        val none = RouteVideoLayout(stats = emptyList()).plan(1080, 1920, 0, hasChart = false, hasLegend = false)
        assertTrue(none.stats.isEmpty()); assertNull(none.chart); assertNull(none.legend)
        // tanpa data: grafik turun ke margin bawah
        assertEquals(1850.0, RouteVideoLayout().plan(1080, 1920, 0, true, false).chart!![3], 1e-6)
    }

    @Test fun scrimDefaultsOnAndTopIsTheHighestBlock() {
        val l = RouteVideoLayout()
        assertTrue(l.scrim); assertEquals(45, l.scrimOpacity)
        assertEquals(100, RouteVideoLayout(scrimOpacity = 500).sanitized().scrimOpacity)
        val pl = l.plan(1080, 1920, 4, true, false)
        assertEquals(pl.chart!![1], pl.top!!, 1e-9)
        assertNull(l.plan(1080, 1920, 0, false, false).top)
    }

    @Test fun titleIsPinnedToTheTopLeft() {
        assertEquals(64.8, RouteVideoLayout.titleLeft(1080), 1e-9)
        assertEquals(96.0, RouteVideoLayout.titleTop(1920), 1e-9)
        assertEquals(950.4, RouteVideoLayout.titleMaxWidth(1080), 1e-9)
    }

    @Test fun oldGridSettingsAreMigrated() {
        val json = """{"gc":4,"gr":4,"ink":"l","panels":[{"k":"judul","c":0,"r":0,"cs":4,"rs":1},{"k":"profil","c":0,"r":2,"cs":4,"rs":1},""" +
            """{"k":"hr","c":1,"r":3},{"k":"jarak","c":0,"r":3},{"k":"legenda","c":0,"r":1},{"k":"waktu","c":2,"r":3}]}"""
        val l = RouteVideoPrefs.fromJson(json).layout
        assertEquals(listOf("jarak", "hr", "waktu"), l.stats)          // urutan letak di grid, judul/legenda bukan data
        assertTrue(l.showChart); assertEquals("profil", l.chartKind); assertTrue(l.legend)
        assertEquals("#C6F432", l.statColor); assertEquals("#C6F432", l.titleColor)
        // tanpa grafik di grid lama = grafik mati
        assertEquals(false, RouteVideoPrefs.fromJson("""{"panels":[{"k":"jarak","c":0,"r":0}]}""").layout.showChart)
        // JSON lama tanpa tata letak sama sekali = bawaan baru
        assertEquals(RouteVideoLayout(), RouteVideoPrefs.fromJson("""{"tilt":50}""").layout)
    }

    @Test fun presetsRememberLayoutAndReadOldFormat() {
        val lay = RouteVideoLayout(stats = listOf("hr"), swap = true, marginX = 10, statColor = "#27D3FF").sanitized()
        val p = RouteVideoPrefs(layout = lay).asPreset("Biru")
        assertEquals(lay, p.layout)
        assertEquals(lay, RouteVideoPrefs().withPreset(p).layout)
        assertEquals(p, RouteVideoPrefs.fromJson(RouteVideoPrefs(presets = listOf(p)).toJson()).presets.single())
        val old = LayoutPreset.fromJson(com.google.gson.JsonParser.parseString(
            """{"n":"Lama","ink":"k","p":[{"k":"pace","c":0,"r":3},{"k":"profil","c":0,"r":2}],"gc":4,"gr":4,"gg":18}""",
        ))!!
        assertEquals(listOf("pace"), old.layout.stats); assertEquals("#111111", old.layout.statColor); assertTrue(old.layout.showChart)
        assertNull(LayoutPreset.fromJson(com.google.gson.JsonParser.parseString("""{"n":"Rusak"}""")))
    }

    // ---- Judul, ringkasan, kamera, linimasa ----

    @Test fun titleAndSummarySettingsRoundTrip() {
        val p = RouteVideoPrefs(titleText = "Lari Pagi ", subtitle = "Gunung Pancar", showDate = false, summary = false, cameraMode = "chase")
        val q = RouteVideoPrefs.fromJson(p.toJson())
        assertEquals("Lari Pagi ", q.titleText)          // spasi di akhir tidak dibuang saat mengetik
        assertEquals("Gunung Pancar", q.subtitle)
        assertEquals(false, q.showDate); assertEquals(false, q.summary); assertEquals("chase", q.cameraMode)
        assertEquals(60, RouteVideoPrefs(titleText = "x".repeat(100)).sanitized().titleText.length)
        assertEquals(80, RouteVideoPrefs(subtitle = "y".repeat(100)).sanitized().subtitle.length)
    }

    @Test fun bearingFollowsTheRouteDirection() {
        assertEquals(90.0, track().bearingAt(0.5), 1.0)   // rute lurus ke timur
    }

    @Test fun cameraModesBehaveDifferently() {
        val t = track()
        val orbit = RouteVideoCamera.at(0.5, RouteVideoPrefs(), null, t)
        assertEquals(0.0, orbit.chaseWeight, 1e-9)
        val chase = RouteVideoCamera.at(0.5, RouteVideoPrefs(cameraMode = "chase"), null, t)
        assertEquals(1.0, chase.chaseWeight, 1e-9)
        assertEquals(-90.0, chase.chaseAzDeg, 1.0)       // kamera di belakang pelari yang menuju timur = di sisi barat
        assertEquals(0.0, RouteVideoCamera.at(0.5, RouteVideoPrefs(cameraMode = "chase"), null, null).chaseWeight, 1e-9)
        assertEquals(0.0, RouteVideoCamera.at(0.0, RouteVideoPrefs(cameraMode = "chase"), null, t).chaseWeight, 1e-9)   // pengantar: gambaran umum
        val top = RouteVideoCamera.at(0.5, RouteVideoPrefs(cameraMode = "top", orbit = 120), null, t)
        assertEquals(85.0, top.pitchDeg, 1e-9); assertEquals(0.0, top.azimuthDeg, 1e-9)
    }

    @Test fun timelineAppendsSummarySegment() {
        val on = RouteVideoPrefs(durationSec = 15, summary = true)
        assertEquals(18.0, RouteVideoTimeline.totalSec(on), 1e-9)
        assertEquals(540, RouteVideoTimeline.frames(on, 30))
        assertEquals(0.6, RouteVideoTimeline.at(0.5, on).p, 1e-9)        // 9 dtk dari 15
        assertEquals(0.0, RouteVideoTimeline.at(0.5, on).summaryAlpha, 1e-9)
        assertEquals(1.0, RouteVideoTimeline.at(15.0 / 18.0, on).p, 1e-9)
        assertEquals(0.0, RouteVideoTimeline.at(15.0 / 18.0, on).summaryAlpha, 1e-9)
        assertEquals(1.0, RouteVideoTimeline.at(1.0, on).summaryAlpha, 1e-9)
        val off = RouteVideoPrefs(durationSec = 15, summary = false)
        assertEquals(15.0, RouteVideoTimeline.totalSec(off), 1e-9)
        assertEquals(0.0, RouteVideoTimeline.at(1.0, off).summaryAlpha, 1e-9)
    }

    // ---- Sorotan otomatis ----

    /** 3 km: km pertama 6:00/km, km kedua 4:00/km, km ketiga 6:00/km. */
    private fun trackWithFastMiddleKm(): RouteVideoTrack {
        val n = 1080
        val dist = DoubleArray(n) { it * 3000.0 / (n - 1) }
        val sec = IntArray(n)
        var t = 0.0
        for (i in 1 until n) {
            val rate = if (dist[i] in 1000.0..2000.0) 0.24 else 0.36   // detik per meter
            t += (dist[i] - dist[i - 1]) * rate
            sec[i] = t.toInt()
        }
        return RouteVideoTrack(
            lat = DoubleArray(n) { -6.2 }, lon = DoubleArray(n) { 106.8 + dist[it] / 111_320.0 },
            dist = dist, sec = sec, hr = IntArray(n) { 150 }, cad = IntArray(n) { 170 },
            ele = DoubleArray(n) { 100.0 }, gradeRaw = DoubleArray(n) { Double.NaN }, title = "Uji", dateText = "",
        )
    }

    @Test fun fastestKmAnchorMarksTheQuickestThousandMetres() {
        val t = trackWithFastMiddleKm()
        val a = t.allAnchors().first { it.kind == "fast" }
        assertEquals(4.0, a.value, 0.1)
        assertEquals(2000.0, t.dist[t.indexAtDist(a.frac * t.totalM)], 15.0)   // ujung jendela di sekitar km 2
        assertEquals("TERCEPAT", RouteVideoText.anchorLabel(a, t).first)
        assertEquals("4:00 /km", RouteVideoText.anchorLabel(a, t).second)
    }

    @Test fun maxHeartRateAnchorSitsAtThePeak() {
        val t = track(hrRise = true)
        val a = t.allAnchors().first { it.kind == "hrmax" }
        assertTrue(a.value in 170.0..181.0)
        assertTrue(a.frac > 0.9)
        assertEquals("HR MAKS", RouteVideoText.anchorLabel(a, t).first)
        // tanpa data HR tidak ada bendera HR
        val noHr = RouteVideoTrack(
            lat = DoubleArray(100) { -6.2 }, lon = DoubleArray(100) { 106.8 + it * 0.0001 }, dist = DoubleArray(100) { it * 30.0 },
            sec = IntArray(100) { it * 10 }, hr = IntArray(100) { 0 }, cad = IntArray(100) { 0 },
            ele = DoubleArray(100) { Double.NaN }, gradeRaw = DoubleArray(100) { Double.NaN }, title = "", dateText = "",
        )
        assertTrue(noHr.allAnchors().none { it.kind == "hrmax" })
    }

    @Test fun highlightFlagsFollowTheirSwitches() {
        val p = RouteVideoPrefs(flagFast = false, flagHrMax = true)
        assertTrue(!p.showsAnchor("fast")); assertTrue(p.showsAnchor("hrmax"))
    }

    @Test fun seriesSamplesAreCachedAndFilled() {
        val t = track()
        val vals = DoubleArray(t.n) { if (it < 10) Double.NaN else it.toDouble() }
        val a = t.seriesSamples("uji", vals, 50)
        assertEquals(50, a.size)
        assertTrue(a.all { it.isFinite() })
        assertTrue(a === t.seriesSamples("uji", vals, 50))
        for (i in 1 until a.size) assertTrue(a[i] >= a[i - 1])
    }

    // ---------------------------------------------------------------- zoom dan kamera sinematik

    @Test fun defaultCameraIsUnchangedByZoomAndShakeOptions() {
        val c = RouteVideoCamera.at(0.5, RouteVideoPrefs())
        assertEquals(1.0, c.zoom, 1e-12)
        assertEquals(10.0, c.azimuthDeg, 1e-9)          // orbit 50 * (0,5 - 0,3)
        assertEquals(52.0, c.pitchDeg, 1e-9)
        assertEquals(1.0, c.distMul, 1e-9)
    }

    @Test fun zoomAndCinematicOptionsAreSanitizedAndSaved() {
        val bad = RouteVideoPrefs(zoom = 10, camAmount = 500, shake = -5).sanitized()
        assertEquals(RouteVideoPrefs.MIN_ZOOM, bad.zoom); assertEquals(100, bad.camAmount); assertEquals(0, bad.shake)
        assertEquals(RouteVideoPrefs.MAX_ZOOM, RouteVideoPrefs(zoom = 999).sanitized().zoom)
        val p = RouteVideoPrefs(cameraMode = "crane", zoom = 170, camAmount = 80, shake = 25)
        val q = RouteVideoPrefs.fromJson(p.toJson())
        assertEquals("crane", q.cameraMode); assertEquals(170, q.zoom); assertEquals(80, q.camAmount); assertEquals(25, q.shake)
        // Pengaturan lama tanpa kunci baru memakai bawaan
        val old = RouteVideoPrefs.fromJson("{\"tilt\":45,\"cm\":\"chase\"}")
        assertEquals(100, old.zoom); assertEquals(60, old.camAmount); assertEquals(0, old.shake); assertEquals("chase", old.cameraMode)
        assertEquals("orbit", RouteVideoPrefs(cameraMode = "terbang").sanitized().cameraMode)
    }

    @Test fun zoomMultipliesIntoThePose() {
        assertEquals(1.5, RouteVideoCamera.at(0.5, RouteVideoPrefs(zoom = 150)).zoom, 1e-12)
        assertEquals(0.5, RouteVideoCamera.at(0.5, RouteVideoPrefs(zoom = 50)).zoom, 1e-12)
        // Zoom berlaku di semua mode, juga di intro dan penutup
        for (m in RouteVideoKeys.CAMERA_MODES) for (q in listOf(0.0, 0.5, 1.0)) {
            assertEquals(2.0, RouteVideoCamera.at(q, RouteVideoPrefs(cameraMode = m, zoom = 200), null, track()).zoom, 1e-12)
        }
    }

    @Test fun cinematicModesAreListedAndNamed() {
        assertTrue(RouteVideoKeys.CAMERA_MODES.containsAll(RouteVideoKeys.CINEMATIC_MODES))
        val names = RouteVideoKeys.CAMERA_MODES.map { RouteVideoKeys.cameraName(it) }
        assertEquals(names.size, names.toSet().size)
        RouteVideoKeys.CINEMATIC_MODES.forEach { assertTrue(RouteVideoKeys.cameraHint(it).isNotBlank()) }
    }

    @Test fun cinematicModesMoveTheCameraAsDescribed() {
        val dolly = RouteVideoPrefs(cameraMode = "dolly")
        assertTrue(RouteVideoCamera.at(0.8, dolly).distMul < RouteVideoCamera.at(0.2, dolly).distMul - 0.2)   // mendekat selama lari
        val crane = RouteVideoPrefs(cameraMode = "crane")
        assertTrue(RouteVideoCamera.at(0.8, crane).pitchDeg > RouteVideoCamera.at(0.2, crane).pitchDeg + 15)    // naik
        val spiral = RouteVideoPrefs(cameraMode = "spiral")
        val sweep = RouteVideoCamera.at(0.8, spiral).azimuthDeg - RouteVideoCamera.at(0.2, spiral).azimuthDeg
        assertTrue(sweep > 100)                                                                                 // lebih lebar dari orbit bawaan (30°)
        val fly = RouteVideoPrefs(cameraMode = "flyby")
        assertTrue(RouteVideoCamera.at(0.1, fly).azimuthDeg < 0 && RouteVideoCamera.at(0.9, fly).azimuthDeg > 0)  // menyapu kiri ke kanan
        // Kekuatan 0 = hampir diam
        val still = RouteVideoPrefs(cameraMode = "dolly", camAmount = 0)
        assertEquals(1.0, RouteVideoCamera.at(0.5, still).distMul, 1e-9)
        assertEquals(0.0, RouteVideoCamera.at(0.5, still).azimuthDeg, 1e-9)
    }

    @Test fun cinematicPosesStayInsideSafeBounds() {
        for (m in RouteVideoKeys.CINEMATIC_MODES) for (amt in listOf(0, 50, 100)) for (tilt in listOf(20, 52, 80)) {
            val p = RouteVideoPrefs(cameraMode = m, camAmount = amt, tilt = tilt, shake = 100)
            for (i in 0..200) {
                val c = RouteVideoCamera.at(i / 200.0, p)
                assertTrue("$m $amt pitch ${c.pitchDeg}", c.pitchDeg in 15.0..85.0)
                assertTrue("$m $amt dist ${c.distMul}", c.distMul in 0.3..2.0)
                assertTrue("$m $amt follow ${c.follow}", c.follow in 0.0..1.0)
            }
        }
    }

    @Test fun handheldShakeIsDeterministicAndSmall() {
        val off = RouteVideoCamera.handheld(3.7, 0.0)
        assertEquals(0.0, off.first, 0.0); assertEquals(0.0, off.second, 0.0); assertEquals(0.0, off.third, 0.0)
        for (i in 0..300) {
            val (az, pitch, zoom) = RouteVideoCamera.handheld(i * 0.1, 1.0)
            assertTrue(Math.abs(az) <= 0.45 * 1.5 + 1e-9 && Math.abs(pitch) <= 0.35 * 1.5 + 1e-9 && Math.abs(zoom) <= 0.006 + 1e-9)
            assertEquals(az, RouteVideoCamera.handheld(i * 0.1, 1.0).first, 0.0)
        }
        val plain = RouteVideoCamera.at(0.5, RouteVideoPrefs())
        val shaky = RouteVideoCamera.at(0.5, RouteVideoPrefs(shake = 100))
        assertTrue(Math.abs(shaky.azimuthDeg - plain.azimuthDeg) > 1e-3)
        assertTrue(Math.abs(shaky.azimuthDeg - plain.azimuthDeg) < 1.0)
    }
}
