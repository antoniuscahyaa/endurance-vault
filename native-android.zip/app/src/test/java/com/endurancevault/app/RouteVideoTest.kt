package com.endurancevault.app

import com.endurancevault.app.domain.FrameStats
import com.endurancevault.app.domain.GhostInfo
import com.endurancevault.app.domain.RouteVideoColors
import com.endurancevault.app.domain.RouteVideoFormat
import com.endurancevault.app.domain.RouteVideoPresets
import com.endurancevault.app.domain.RouteVideoRace
import com.endurancevault.app.domain.allAnchors
import com.endurancevault.app.domain.asPreset
import com.endurancevault.app.domain.kmPace
import com.endurancevault.app.domain.withPreset
import com.endurancevault.app.domain.RouteVideoCamera
import com.endurancevault.app.domain.RouteVideoKeys
import com.endurancevault.app.domain.RouteVideoPrefs
import com.endurancevault.app.domain.RouteVideoText
import com.endurancevault.app.domain.RouteVideoTrack
import com.endurancevault.app.domain.VideoPanel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RouteVideoTest {
    /** Lari lurus 3 km ke timur, 1 sampel/detik, pace tetap 6:00/km, naik 30 m. */
    private fun track(n: Int = 1080, gain: Int? = null, secScale: Double = 1.0, hrRise: Boolean = false): RouteVideoTrack {
        val dist = DoubleArray(n) { it * 3000.0 / (n - 1) }
        return RouteVideoTrack(
            lat = DoubleArray(n) { -6.2 }, lon = DoubleArray(n) { 106.8 + dist[it] / 111_320.0 },
            dist = dist, sec = IntArray(n) { (it * secScale).toInt() },
            hr = IntArray(n) { if (hrRise) 120 + (60.0 * it / (n - 1)).toInt() else 150 }, cad = IntArray(n) { 170 },
            ele = DoubleArray(n) { 100.0 + 30.0 * it / (n - 1) }, gradeRaw = DoubleArray(n) { Double.NaN },
            title = "Lari pagi", dateText = "10 Nov 2026", officialGain = gain,
        )
    }

    @Test fun prefsRoundTripKeepsPositionAndSize() {
        val p = RouteVideoPrefs(
            panels = listOf(VideoPanel("pace", 12.5, 40.0, 150), VideoPanel("hr", 60.0, 80.0, 70)),
            live = false, tilt = 61, exaggeration = 2.5, orbit = 90, ink = "k", panelBg = "soft", durationSec = 20,
        )
        val q = RouteVideoPrefs.fromJson(p.toJson())
        assertEquals(p.panels, q.panels)
        assertEquals(false, q.live)
        assertEquals(61, q.tilt)
        assertEquals(2.5, q.exaggeration, 1e-9)
        assertEquals("k", q.ink)
        assertEquals(20, q.durationSec)
    }

    @Test fun brokenJsonFallsBackToDefaults() {
        assertEquals(RouteVideoPrefs(), RouteVideoPrefs.fromJson(null))
        assertEquals(RouteVideoPrefs(), RouteVideoPrefs.fromJson("{bukan json"))
    }

    @Test fun sanitizeClampsAndDropsUnknownPanels() {
        val p = RouteVideoPrefs(
            panels = listOf(VideoPanel("pace", -5.0, 140.0, 999), VideoPanel("pace", 1.0, 1.0, 100), VideoPanel("ngawur", 1.0, 1.0, 100)),
            tilt = 5, exaggeration = 99.0, orbit = -3, durationSec = 1, ink = "?", lineColor = "merah",
        ).sanitized()
        assertEquals(listOf(VideoPanel("pace", 0.0, 100.0, RouteVideoKeys.MAX_SIZE)), p.panels)
        assertEquals(20, p.tilt); assertEquals(4.0, p.exaggeration, 1e-9); assertEquals(0, p.orbit)
        assertEquals(6, p.durationSec); assertEquals("w", p.ink); assertEquals("#C6F432", p.lineColor)
    }

    @Test fun defaultLayoutCoversEveryKeyInsideTheFrame() {
        RouteVideoKeys.ALL.forEach { k ->
            val d = RouteVideoKeys.defaultPanel(k)
            assertEquals(k, d.key)
            assertTrue(d.x in 0.0..100.0 && d.y in 0.0..100.0)
        }
    }

    @Test fun cameraTimelineStartsAtZeroAndEndsAtOne() {
        val prefs = RouteVideoPrefs()
        assertEquals(0.0, RouteVideoCamera.at(0.0, prefs).routeFrac, 1e-9)
        assertEquals(0.0, RouteVideoCamera.at(RouteVideoCamera.T_IN, prefs).routeFrac, 1e-9)
        assertEquals(1.0, RouteVideoCamera.at(RouteVideoCamera.T_OUT, prefs).routeFrac, 1e-9)
        assertEquals(1.0, RouteVideoCamera.at(1.0, prefs).routeFrac, 1e-9)
        // Bagian lari: kemajuan rute naik terus.
        var last = -1.0
        for (i in 0..100) { val r = RouteVideoCamera.at(i / 100.0, prefs).routeFrac; assertTrue(r >= last); last = r }
    }

    @Test fun cameraPitchFollowsTiltInTheMiddle() {
        val c = RouteVideoCamera.at(0.5, RouteVideoPrefs(tilt = 40))
        assertEquals(40.0, c.pitchDeg, 1e-6)
        assertEquals(1.0, c.distMul, 1e-6)
    }

    @Test fun liveStatsFollowRunnerPosition() {
        val t = track()
        val half = t.statsAt(0.5, live = true)
        assertEquals(1500.0, half.distM, 5.0)
        assertEquals(540.0, half.sec.toDouble(), 3.0)
        assertEquals(6.0, half.pace!!, 0.05)
        assertEquals(150, half.hr)
        assertEquals(170, half.cad)
        val start = t.statsAt(0.0, live = true)
        assertEquals(0.0, start.distM, 1e-9)
        assertEquals(0.0, start.gain, 1e-9)
    }

    @Test fun totalStatsSummariseWholeRun() {
        val s = track().statsAt(0.2, live = false)
        assertEquals(3000.0, s.distM, 1e-6)
        assertEquals(1079, s.sec)
        assertEquals(6.0, s.pace!!, 0.05)
        assertEquals(150, s.hr)
        assertTrue(s.gain > 20.0)
    }

    @Test fun gainCanBeAlignedToOfficialValue() {
        val s = track(gain = 55).statsAt(1.0, live = true)
        assertEquals(55.0, s.gain, 0.5)
    }

    @Test fun gradeIsDerivedFromElevationWhenMissing() {
        // 30 m naik dalam 3000 m = 1%
        val g = track().statsAt(0.5, live = true).grade
        assertNotNull(g)
        assertEquals(1.0, g!!, 0.1)
    }

    @Test fun profileSamplesRiseMonotonically() {
        val p = track().profileSamples(50)
        assertEquals(50, p.size)
        for (i in 1 until p.size) assertTrue(p[i] >= p[i - 1] - 1e-9)
    }

    @Test fun missingHeartRateShowsDash() {
        val st = FrameStats(0, 0.0, 0.0, 0, null, null, null, null, 0.0, null)
        assertEquals("–", RouteVideoText.cell("hr", st, true, false)!!.value)
        assertEquals("–", RouteVideoText.cell("pace", st, true, false)!!.value)
        assertEquals("–", RouteVideoText.cell("grad", st, true, false)!!.value)
        assertNull(RouteVideoText.cell("judul", st, true, false))
    }

    @Test fun cellsUseIndonesianFormatting() {
        val st = FrameStats(1, .5, 5234.0, 1830, 5.5, 152, 3.24, 123.4, 85.0, 172)
        assertEquals("5,23", RouteVideoText.cell("jarak", st, true, false)!!.value)
        assertEquals("30:30", RouteVideoText.cell("waktu", st, true, false)!!.value)
        assertEquals("5:30", RouteVideoText.cell("pace", st, true, false)!!.value)
        assertEquals("+3,2", RouteVideoText.cell("grad", st, true, false)!!.value)
        assertEquals("123", RouteVideoText.cell("elev", st, true, false)!!.value)
        assertEquals("10,9", RouteVideoText.cell("pace", st, true, true)!!.value)   // sepeda: km/j
        assertEquals("10 Nov 2026", RouteVideoText.dateId("2026-11-10"))
    }

    // ---- Preset, format, warna, bendera, ghost ----

    @Test fun newPrefsFieldsRoundTrip() {
        val custom = RouteVideoPrefs().asPreset("Favorit")
        val p = RouteVideoPrefs(lineMode = "pace", kmMarkers = false, flagEnds = false, flagPeak = true, flagSteep = false,
            hillshade = false, fog = false, bgRender = false, aspect = "4:5", quality = "sd", presets = listOf(custom),
        )
        val q = RouteVideoPrefs.fromJson(p.toJson())
        assertEquals("pace", q.lineMode); assertEquals(false, q.kmMarkers)
        assertEquals(false, q.flagEnds); assertEquals(true, q.flagPeak); assertEquals(false, q.flagSteep)
        assertEquals(false, q.hillshade); assertEquals(false, q.fog); assertEquals(false, q.bgRender)
        assertEquals("4:5", q.aspect); assertEquals("sd", q.quality)
        assertEquals(listOf(custom), q.presets)
    }

    @Test fun invalidNewFieldsFallBack() {
        val p = RouteVideoPrefs(lineMode = "ngawur", aspect = "3:2", quality = "uhd").sanitized()
        assertEquals("solid", p.lineMode); assertEquals("9:16", p.aspect); assertEquals("hd", p.quality)
    }

    @Test fun builtInPresetsAreValidAndApplyCleanly() {
        RouteVideoPresets.BUILT_IN.forEach { pr ->
            assertEquals(pr, pr.sanitized())
            val applied = RouteVideoPrefs().withPreset(pr)
            assertEquals(pr.panels, applied.panels)
            assertEquals(pr.lineMode, applied.lineMode)
            assertEquals(pr, applied.asPreset(pr.name))
        }
        assertTrue(RouteVideoPresets.isBuiltIn("Minimal"))
    }

    @Test fun userPresetsAreCappedAndDeduplicated() {
        val many = (1..20).map { RouteVideoPrefs().asPreset("P$it") } + RouteVideoPrefs().asPreset("P1")
        val p = RouteVideoPrefs(presets = many).sanitized()
        assertEquals(12, p.presets.size)
        assertEquals(p.presets.map { it.name }.distinct(), p.presets.map { it.name })
    }

    @Test fun outputSizesAreEvenAndMatchAspect() {
        RouteVideoFormat.ASPECTS.forEach { a ->
            listOf("hd", "sd").forEach { q ->
                val (w, h) = RouteVideoFormat.size(a, q)
                assertTrue(w % 2 == 0 && h % 2 == 0)
            }
            val (pw, ph) = RouteVideoFormat.previewSize(a)
            assertEquals(RouteVideoFormat.ratio(a).toDouble(), pw.toDouble() / ph, 0.01)
        }
        assertEquals(1080 to 1920, RouteVideoFormat.size("9:16", "hd"))
        assertEquals(1280 to 720, RouteVideoFormat.size("16:9", "sd"))
    }

    @Test fun rampEndpointsAndSolidMode() {
        assertEquals(0xFF2F80ED.toInt(), RouteVideoColors.ramp(0.0))
        assertEquals(0xFFEB4D4B.toInt(), RouteVideoColors.ramp(1.0))
        val t = track()
        val accent = 0xFFC6F432.toInt()
        assertEquals(listOf(accent, accent), RouteVideoColors.colors(t, "solid", accent, floatArrayOf(0.1f, 0.9f)).toList())
    }

    @Test fun heartRateModeGetsWarmerAsHrRises() {
        val t = track(hrRise = true)
        val c = RouteVideoColors.colors(t, "hr", 0, floatArrayOf(0.05f, 0.95f))
        val redLow = (c[0] shr 16) and 255; val redHigh = (c[1] shr 16) and 255
        val blueLow = c[0] and 255; val blueHigh = c[1] and 255
        assertTrue(redHigh > redLow)
        assertTrue(blueLow > blueHigh)
        assertNotNull(RouteVideoColors.info(t, "hr"))
    }

    @Test fun anchorsContainStartFinishAndKmFlags() {
        val a = track().allAnchors()
        assertEquals(1, a.count { it.kind == "start" })
        assertEquals(1, a.count { it.kind == "finish" })
        assertEquals(listOf(1, 2), a.filter { it.kind == "km" }.map { it.km })
        assertTrue(a.none { it.kind == "steep" })       // tanjakan 1% tidak layak diberi bendera
        assertTrue(a.any { it.kind == "peak" })         // naik 30 m >= ambang 15 m
        val km1 = a.first { it.kind == "km" }
        assertEquals(6.0, track().kmPace(km1)!!, 0.05)
        assertEquals("6:00 /km", RouteVideoText.anchorLabel(km1, track()).second)
        assertEquals("KM 1", RouteVideoText.anchorLabel(km1, track()).first)
    }

    @Test fun timeAndDistanceAreConsistent() {
        val t = track()
        assertEquals(540.0, t.timeAtDist(1500.0), 3.0)
        assertEquals(0.5, t.fracAtTime(540.0), 0.01)
        assertEquals(0.0, t.fracAtTime(-5.0), 1e-9)
        assertEquals(1.0, t.fracAtTime(99999.0), 1e-9)
    }

    @Test fun raceUsesSameClockForBothRunners() {
        val main = track()
        val ghost = track(secScale = 1.2)   // 20% lebih lambat
        val race = RouteVideoRace(main, ghost)
        val (m, g) = race.fractions(0.5)
        assertTrue(m > g)
        assertEquals(1.0, race.fractions(1.0).first, 1e-9)
        assertEquals(1.0, race.fractions(1.0).second, 1e-9)
        assertEquals(108.0, race.gapSeconds(0.5), 6.0)    // ghost tiba ±108 dtk lebih lambat di km 1,5
        val cam = RouteVideoCamera.at(RouteVideoCamera.T_OUT, RouteVideoPrefs(), race)
        assertEquals(1.0, cam.routeFrac, 1e-9)
        assertEquals(1.0, cam.ghostFrac!!, 1e-9)
        assertNull(RouteVideoCamera.at(0.5, RouteVideoPrefs()).ghostFrac)
    }

    @Test fun ghostGapTextSaysAheadOrBehind() {
        assertEquals("0:12", RouteVideoText.ghostCell(GhostInfo("Budi", 12.0)).value)
        assertEquals("unggul", RouteVideoText.ghostCell(GhostInfo("Budi", 12.0)).unit)
        assertEquals("tertinggal", RouteVideoText.ghostCell(GhostInfo("Budi", -30.0)).unit)
        assertEquals("sama", RouteVideoText.ghostCell(GhostInfo("Budi", 0.4)).unit)
        assertEquals("VS BUDI", RouteVideoText.ghostCell(GhostInfo("Budi", 1.0)).label)
    }

    // ---- Sakelar per fitur ----

    @Test fun everyFeatureSwitchDefaultsToOn() {
        val p = RouteVideoPrefs()
        assertTrue(p.kmMarkers && p.flagEnds && p.flagPeak && p.flagSteep && p.hillshade && p.fog && p.bgRender)
        assertEquals("solid", p.lineMode)   // warna garis berdasarkan data adalah pilihan, bukan bawaan
    }

    @Test fun lineWidthRoundTripsAndIsClamped() {
        assertEquals(100, RouteVideoPrefs().lineWidth)
        assertEquals(180, RouteVideoPrefs.fromJson(RouteVideoPrefs(lineWidth = 180).toJson()).lineWidth)
        assertEquals(50, RouteVideoPrefs(lineWidth = 5).sanitized().lineWidth)
        assertEquals(250, RouteVideoPrefs(lineWidth = 900).sanitized().lineWidth)
        assertEquals(100, RouteVideoPrefs.fromJson("""{"tilt":50}""").lineWidth)   // pengaturan lama tanpa ketebalan
    }

    @Test fun anchorFlagsAreIndependent() {
        val p = RouteVideoPrefs(kmMarkers = true, flagEnds = false, flagPeak = true, flagSteep = false)
        assertTrue(p.showsAnchor("km"))
        assertTrue(!p.showsAnchor("start") && !p.showsAnchor("finish"))
        assertTrue(p.showsAnchor("peak"))
        assertTrue(!p.showsAnchor("steep"))
        assertTrue(!p.showsAnchor("tidak-dikenal"))
        val all = RouteVideoPrefs(flagEnds = true)
        assertTrue(all.showsAnchor("start") && all.showsAnchor("finish"))
    }

    @Test fun oldSingleLabelSwitchFansOutToThreeFlags() {
        val off = RouteVideoPrefs.fromJson("""{"lb":false,"km":true}""")
        assertTrue(!off.flagEnds && !off.flagPeak && !off.flagSteep && off.kmMarkers)
        val on = RouteVideoPrefs.fromJson("""{"lb":true}""")
        assertTrue(on.flagEnds && on.flagPeak && on.flagSteep)
        // sakelar baru menang atas yang lama
        val mixed = RouteVideoPrefs.fromJson("""{"lb":false,"fp":true}""")
        assertTrue(mixed.flagPeak && !mixed.flagEnds && !mixed.flagSteep)
    }

    @Test fun presetsKeepFlagsAndReadOldFormat() {
        val p = RouteVideoPrefs(flagEnds = false, flagPeak = true, flagSteep = false).asPreset("Uji")
        val back = RouteVideoPrefs.fromJson(RouteVideoPrefs(presets = listOf(p)).toJson()).presets.single()
        assertEquals(p, back)
        val applied = RouteVideoPrefs().withPreset(back)
        assertTrue(!applied.flagEnds && applied.flagPeak && !applied.flagSteep)
        val old = RouteVideoPrefs.fromJson("""{"presets":[{"n":"Lama","p":[],"lb":false}]}""").presets.single()
        assertTrue(!old.flagEnds && !old.flagPeak && !old.flagSteep)
        assertTrue(RouteVideoPresets.BUILT_IN.first { it.name == "Minimal" }.let { !it.flagEnds && !it.kmMarkers })
        assertTrue(RouteVideoPresets.BUILT_IN.first { it.name == "Lengkap" }.let { it.flagEnds && it.flagPeak && it.flagSteep && it.kmMarkers })
    }
}
