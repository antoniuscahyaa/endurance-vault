package com.endurancevault.app

import com.endurancevault.app.domain.CourseStrategy
import com.endurancevault.app.domain.CourseStrategy.Pt
import com.endurancevault.app.domain.GpxRoute
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CourseStrategyTest {
    /** Jalur lurus ke utara sepanjang ±[km] km dengan profil elevasi dari [ele] (km → m). */
    private fun route(km: Double, ele: (Double) -> Double?): List<Pt> {
        val n = (km * 20).toInt() // titik tiap ~50 m
        return (0..n).map { i ->
            val d = km * i / n
            Pt(-6.0 + d / 111.19, 106.0, ele(d))
        }
    }

    /** Naik 300 m di km 3-6, datar, turun 300 m di km 10-13, datar sampai km 16. */
    private val hilly: (Double) -> Double? = { d ->
        when {
            d < 3 -> 100.0
            d < 6 -> 100.0 + (d - 3) / 3 * 300
            d < 10 -> 400.0
            d < 13 -> 400.0 - (d - 10) / 3 * 300
            else -> 100.0
        }
    }

    @Test fun waktuSegmenDijumlahkanKeTarget() {
        val o = CourseStrategy.pacing(route(16.0, hilly), "2:00:00", "even", "dry")
        val r = o.result
        assertNotNull(r)
        assertEquals(120.0, r!!.segs.sumOf { it.min }, 0.01)
        assertEquals(120.0, r.segs.last().eta, 0.01)
        assertEquals(16.0, r.segs.last().to, 0.05)
    }

    @Test fun tanjakanLebihLambatDariDatar() {
        val r = CourseStrategy.pacing(route(16.0, hilly), "2:00:00", "even", "dry").result!!
        val up = r.segs.filter { it.type == "up" }
        val flat = r.segs.filter { it.type == "flat" }
        assertTrue(up.isNotEmpty() && flat.isNotEmpty())
        assertTrue(up.maxOf { it.pace } > flat.minOf { it.pace })
        assertNotNull(r.big)
        assertTrue(r.big!!.gain > 200)
    }

    @Test fun permukaanLicinMemperlambatTurunanTapiTotalTetap() {
        val dry = CourseStrategy.pacing(route(16.0, hilly), "2:00:00", "even", "dry").result!!
        val slip = CourseStrategy.pacing(route(16.0, hilly), "2:00:00", "even", "slip").result!!
        assertEquals(120.0, slip.segs.last().eta, 0.01)
        val d1 = dry.segs.filter { it.type == "down" }.maxOf { it.loss }
        assertTrue(d1 > 100)
        // total sama, jadi turunan yang lebih lambat berarti bagian lain lebih cepat
        val dnDry = dry.segs.filter { it.type == "down" }.sumOf { it.min }
        val dnSlip = slip.segs.filter { it.type == "down" }.sumOf { it.min }
        assertTrue(dnSlip > dnDry)
    }

    @Test fun negativeSplitMembuatAwalLebihLambat() {
        val flatRoute = route(10.0) { d -> if (d < 1) 100.0 else if (d < 2) 100.0 + (d - 1) * 80 else if (d < 5) 180.0 else if (d < 6) 180.0 - (d - 5) * 80 else 100.0 }
        val even = CourseStrategy.pacing(flatRoute, "1:00:00", "even", "norm").result!!
        val neg = CourseStrategy.pacing(flatRoute, "1:00:00", "neg", "norm").result!!
        assertTrue(neg.segs.first().pace > even.segs.first().pace)
        assertTrue(neg.segs.last().pace < even.segs.last().pace)
        assertEquals(60.0, neg.segs.last().eta, 0.01)
    }

    @Test fun galatMasukanDanData() {
        val pts = route(16.0, hilly)
        assertEquals("waktu", CourseStrategy.pacing(pts, "", "even", "dry").err)
        assertEquals("waktu", CourseStrategy.pacing(pts, "abc", "even", "dry").err)
        assertEquals("elevasi", CourseStrategy.pacing(route(16.0) { null }, "2:00:00", "even", "dry").err)
        assertEquals("pendek", CourseStrategy.pacing(route(0.3, hilly), "0:10:00", "even", "dry").err)
        assertNull(CourseStrategy.pacing(pts, "2:00:00", "even", "dry").err)
    }

    @Test fun rutaDatarTidakDipecahMenjadiTanjakan() {
        val r = CourseStrategy.pacing(route(10.0) { 50.0 }, "1:00:00", "even", "dry")
        // semua datar: satu ruas datar, atau tidak ada ruas medan; tidak boleh ada tanjakan/turunan
        r.result?.let { res -> assertTrue(res.segs.all { it.type == "flat" }) }
    }

    @Test fun ringkasanDanTipTidakKosong() {
        val r = CourseStrategy.pacing(route(16.0, hilly), "2:00:00", "even", "norm").result!!
        assertTrue(CourseStrategy.summary(r).first().startsWith("Komposisi jalur"))
        r.segs.forEach { assertTrue(CourseStrategy.tip(it, r).isNotBlank()) }
        assertTrue(CourseStrategy.plainText(r).size > r.segs.size)
    }

    @Test fun gradeCostTurunanDibatasiLantai() {
        // Minetti murni pada -15% sekitar 0,6; dengan permukaan kering lantainya 0,72 dan turunan curam dihukum
        assertTrue(CourseStrategy.gradeCost(-0.05, "dry") >= 0.72)
        assertTrue(CourseStrategy.gradeCost(-0.25, "slip") > CourseStrategy.gradeCost(-0.25, "dry"))
        assertEquals(1.0, CourseStrategy.gradeCost(0.0, "dry"), 0.001)
    }

    @Test fun inputWaktuGayaStopwatch() {
        assertEquals("3:00:00", GpxRoute.timeFmt("30000"))
        assertEquals("30:00", GpxRoute.timeFmt("3000"))
        assertEquals("5:30:00", GpxRoute.timeFmt("5:30:00"))
        assertEquals("5", GpxRoute.timeFmt("5"))
        assertEquals("", GpxRoute.timeFmt("abc"))
    }
}
