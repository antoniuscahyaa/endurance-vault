package com.endurancevault.app

import com.endurancevault.app.domain.CoachAction
import com.endurancevault.app.domain.CoachActions
import com.endurancevault.app.domain.PlanSettings
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

/** Uji validasi tool call AI Coach -> CoachAction. Hari uji: 11 Nov 2026. */
class CoachActionsTest {
    private val today = LocalDate.of(2026, 11, 11)

    private fun call(name: String, args: JSONObject) =
        JSONObject().put("type", "function").put("function", JSONObject().put("name", name).put("arguments", args.toString()))

    private fun parse(vararg calls: JSONObject) = CoachActions.parse(JSONArray().also { a -> calls.forEach { a.put(it) } }, today)

    @Test fun nullToolCallsGivesNothing() {
        val p = CoachActions.parse(null, today)
        assertTrue(p.actions.isEmpty()); assertTrue(p.rejected.isEmpty())
    }

    @Test fun addActivityParsesAndConvertsMinutes() {
        val p = parse(call("add_activity", JSONObject().put("date", "2026-11-10").put("km", 10.5).put("duration_min", 62.5).put("avg_hr", 148).put("name", "Easy pagi")))
        val a = p.actions.single() as CoachAction.AddActivity
        assertEquals("2026-11-10", a.dateIso); assertEquals(10.5, a.km, 0.0); assertEquals(3750, a.durationSec)
        assertEquals(148, a.avgHr); assertEquals("run", a.type); assertEquals("Easy pagi", a.name)
    }

    @Test fun addActivityRejectsFutureDateAndBadValues() {
        assertTrue(parse(call("add_activity", JSONObject().put("date", "2026-11-20").put("km", 5).put("duration_min", 30))).actions.isEmpty())
        assertTrue(parse(call("add_activity", JSONObject().put("date", "11/10/2026").put("km", 5).put("duration_min", 30))).actions.isEmpty())
        assertTrue(parse(call("add_activity", JSONObject().put("date", "2026-11-10").put("km", 0).put("duration_min", 30))).actions.isEmpty())
        assertTrue(parse(call("add_activity", JSONObject().put("date", "2026-11-10").put("km", 5))).actions.isEmpty())
        assertTrue(parse(call("add_activity", JSONObject().put("date", "2026-11-10").put("km", 5).put("duration_min", 30).put("type", "swim"))).actions.isEmpty())
        assertTrue(parse(call("add_activity", JSONObject().put("date", "2026-11-10").put("km", 5).put("duration_min", 30).put("avg_hr", 400))).actions.isEmpty())
        assertTrue(parse(call("add_activity", JSONObject().put("date", "2026-11-10").put("km", 5).put("duration_min", 30).put("start_time", "25:00"))).actions.isEmpty())
    }

    @Test fun rejectionReasonIsReported() {
        val p = parse(call("add_activity", JSONObject().put("date", "2026-12-31").put("km", 5).put("duration_min", 30)))
        assertEquals(1, p.rejected.size); assertTrue(p.rejected[0].startsWith("add_activity"))
    }

    @Test fun invalidJsonArgumentsAndUnknownToolRejected() {
        val bad = JSONObject().put("function", JSONObject().put("name", "add_activity").put("arguments", "{nope"))
        val unknown = call("format_disk", JSONObject())
        val p = parse(bad, unknown)
        assertTrue(p.actions.isEmpty()); assertEquals(2, p.rejected.size)
    }

    @Test fun editRequiresAtLeastOneChange() {
        assertTrue(parse(call("edit_activity", JSONObject().put("id", 5))).actions.isEmpty())
        val a = parse(call("edit_activity", JSONObject().put("id", 5).put("name", "Long run"))).actions.single() as CoachAction.EditActivity
        assertEquals(5L, a.id); assertEquals("Long run", a.name); assertNull(a.dateIso)
        assertTrue(parse(call("edit_activity", JSONObject().put("id", 0).put("name", "x"))).actions.isEmpty())
    }

    @Test fun deleteIsMarkedDestructive() {
        val a = parse(call("delete_activity", JSONObject().put("id", 9))).actions.single()
        assertTrue(a.destructive); assertFalse(parse(call("set_activity_feel", JSONObject().put("id", 9).put("feel10", 7))).actions.single().destructive)
    }

    @Test fun saveDailyNeedsAValueAndChecksRanges() {
        assertTrue(parse(call("save_daily", JSONObject().put("date", "2026-11-11"))).actions.isEmpty())
        assertTrue(parse(call("save_daily", JSONObject().put("date", "2026-11-11").put("leg", 6))).actions.isEmpty())
        val a = parse(call("save_daily", JSONObject().put("date", "2026-11-11").put("sleep_h", 7.5).put("leg", 2))).actions.single() as CoachAction.SaveDaily
        assertEquals(7.5, a.sleepH!!, 0.0); assertEquals(2, a.leg); assertNull(a.rhr)
    }

    @Test fun sessionActionsAllowFutureDates() {
        assertTrue(parse(call("skip_session", JSONObject().put("date", "2026-11-14"))).actions.single() is CoachAction.SkipSession)
        val d = parse(call("set_session_done", JSONObject().put("date", "2026-11-10").put("done", true))).actions.single() as CoachAction.SetSessionDone
        assertTrue(d.done)
        assertTrue(parse(call("set_session_done", JSONObject().put("date", "2026-11-10"))).actions.isEmpty())
    }

    @Test fun updateSettingsValidatesAndApplies() {
        val p = parse(call("update_settings", JSONObject().put("pace", "6:10").put("hr_max", 188).put("race_date", "2027-03-14").put("run_days", 6).put("base_km", 40).put("peak_km", 70)))
        val u = p.actions.single() as CoachAction.UpdateSettings
        val s = CoachActions.applySettings(PlanSettings(start = today), u.changes)
        assertEquals("6:10", s.pace); assertEquals(188, s.hrMax); assertEquals(LocalDate.of(2027, 3, 14), s.race); assertEquals(6, s.days)
        assertEquals(40.0, s.base, 0.0); assertEquals(70.0, s.peak, 0.0)
    }

    @Test fun updateSettingsRejectsBadInput() {
        assertTrue(parse(call("update_settings", JSONObject().put("pace", "fast"))).actions.isEmpty())
        assertTrue(parse(call("update_settings", JSONObject().put("run_days", 3))).actions.isEmpty())
        assertTrue(parse(call("update_settings", JSONObject().put("base_km", 60).put("peak_km", 40))).actions.isEmpty())
        assertTrue(parse(call("update_settings", JSONObject())).actions.isEmpty())
        assertTrue(parse(call("update_settings", JSONObject().put("race_date", "kapan-kapan"))).actions.isEmpty())
    }

    @Test fun updateSettingsLeavesOtherFieldsAlone() {
        val before = PlanSettings(start = today, pace = "6:30", hr = 150, zm = "hrr")
        val after = CoachActions.applySettings(before, mapOf("pace" to "6:00"))
        assertEquals("6:00", after.pace); assertEquals(150, after.hr); assertEquals("hrr", after.zm)
    }

    @Test fun capsActionsPerReply() {
        val many = (1..8).map { call("delete_activity", JSONObject().put("id", it)) }.toTypedArray()
        val p = parse(*many)
        assertEquals(CoachActions.MAX_ACTIONS_PER_REPLY, p.actions.size); assertEquals(1, p.rejected.size)
    }

    @Test fun toolDefinitionsAreWellFormed() {
        val defs = CoachActions.toolDefinitions()
        val names = (0 until defs.length()).map { defs.getJSONObject(it).getJSONObject("function").getString("name") }
        assertEquals(names.size, names.toSet().size)
        assertTrue(names.containsAll(listOf("add_activity", "edit_activity", "delete_activity", "save_daily", "add_gear", "send_workout_to_watch", "set_session_done", "skip_session", "update_settings")))
    }

    @Test fun logPainValidatesAndDefaults() {
        val a = parse(call("log_pain", JSONObject().put("area", "achilles").put("side", "k").put("severity", 3))).actions.single() as CoachAction.LogPain
        assertEquals("sl", a.moment); assertEquals("2026-11-11", a.dateIso); assertEquals(3, a.severity)
        assertEquals("Catat nyeri Achilles (Kiri) 2026-11-11: 3/5, saat lari", a.summary)
        assertTrue(parse(call("log_pain", JSONObject().put("area", "kepala").put("side", "k").put("severity", 3))).actions.isEmpty())
        assertTrue(parse(call("log_pain", JSONObject().put("area", "lutut").put("side", "x").put("severity", 3))).actions.isEmpty())
        assertTrue(parse(call("log_pain", JSONObject().put("area", "lutut").put("side", "r").put("severity", 6))).actions.isEmpty())
        assertTrue(parse(call("log_pain", JSONObject().put("area", "lutut").put("side", "r").put("severity", 2).put("moment", "malam"))).actions.isEmpty())
        assertTrue(parse(call("log_pain", JSONObject().put("area", "lutut").put("side", "r").put("severity", 2).put("date", "2026-11-12"))).actions.isEmpty())
    }

    @Test fun setActivityGearDefaultsToLatestRun() {
        val a = parse(call("set_activity_gear", JSONObject().put("gear_name", "Pegasus 41"))).actions.single() as CoachAction.SetActivityGear
        assertNull(a.activityId); assertEquals("Pegasus 41", a.gearName)
        assertEquals(7L, (parse(call("set_activity_gear", JSONObject().put("gear_name", "X").put("activity_id", 7))).actions.single() as CoachAction.SetActivityGear).activityId)
        assertTrue(parse(call("set_activity_gear", JSONObject().put("activity_id", 7))).actions.isEmpty())
        assertTrue(parse(call("set_activity_gear", JSONObject().put("gear_name", "X").put("activity_id", -3))).actions.isEmpty())
    }

    @Test fun sendWorkoutParsesZoneAndPace() {
        val a = parse(call("send_workout_to_watch", JSONObject().put("name", "Threshold 3x10").put("warmup_min", 15).put("repeats", 3)
            .put("run_min", 10).put("recovery_min", 2).put("cooldown_min", 10).put("run_zone", 4))).actions.single() as CoachAction.SendWorkout
        assertEquals(3, a.repeats); assertEquals(4, a.runZone); assertNull(a.runPaceFast)
        assertEquals("Kirim workout \"Threshold 3x10\" ke jam: pemanasan 15 mnt, 3 × 10 mnt lari (Z4), recovery 2 mnt, pendinginan 10 mnt", a.summary)
        val b = parse(call("send_workout_to_watch", JSONObject().put("name", "Tempo").put("repeats", 1).put("run_min", 30)
            .put("run_pace_slow", "5:20").put("run_pace_fast", "5:00"))).actions.single() as CoachAction.SendWorkout
        assertEquals(300, b.runPaceFast); assertEquals(320, b.runPaceSlow)
    }

    @Test fun sendWorkoutRejectsInvalid() {
        fun w(vararg kv: Pair<String, Any>) = parse(call("send_workout_to_watch", JSONObject().also { o -> kv.forEach { (k, v) -> o.put(k, v) } })).actions
        assertTrue(w("name" to "X", "run_min" to 10).isEmpty())                       // repeats wajib
        assertTrue(w("name" to "X", "repeats" to 0, "run_min" to 10).isEmpty())
        assertTrue(w("name" to "X", "repeats" to 3, "run_min" to 200).isEmpty())
        assertTrue(w("name" to "X", "repeats" to 3, "run_min" to 5, "run_zone" to 6).isEmpty())
        assertTrue(w("name" to "X", "repeats" to 3, "run_min" to 5, "run_zone" to 4, "run_pace_fast" to "5:00", "run_pace_slow" to "5:20").isEmpty())
        assertTrue(w("name" to "X", "repeats" to 3, "run_min" to 5, "run_pace_fast" to "5:00").isEmpty())
        assertTrue(w("name" to "X", "repeats" to 3, "run_min" to 5, "run_pace_fast" to "0:30", "run_pace_slow" to "5:00").isEmpty())
        assertTrue(w("repeats" to 3, "run_min" to 5).isEmpty())                         // nama wajib
    }

    @Test fun sendWorkoutZoneDikonversiAplikasi() {
        val w = CoachAction.SendWorkout("T", 10, 3, 10, 2, 10, runZone = 4, warmupZone = 2)
        val lower = listOf(95, 143, 151, 160, 168)
        val t = CoachActions.workoutTargets(w, lower, 190)
        assertEquals(com.endurancevault.app.domain.StepIntensity.HR_PERCENT, t.run.type)
        assertEquals(84, t.run.low); assertEquals(88, t.run.high) // 160..167 bpm dari 190
        assertEquals(com.endurancevault.app.domain.StepIntensity.NONE, t.recovery.type)
    }

    @Test fun summariesAreReadable() {
        val a = parse(call("add_activity", JSONObject().put("date", "2026-11-10").put("km", 10).put("duration_min", 60))).actions.single()
        assertEquals("Tambah lari 2026-11-10: 10 km, 60 mnt", a.summary)
    }
}
