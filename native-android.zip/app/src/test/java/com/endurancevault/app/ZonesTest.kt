package com.endurancevault.app

import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.domain.Zones
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test

class ZonesTest {
    @Test fun zonaLthrBawaan() {
        val zc = Zones.cuts(PlanSettings(thr = "164–172"))
        assertEquals("lthr", zc.mode)
        assertEquals(168, zc.lthr)
        assertEquals(listOf(0, 143, 151, 160, 168), zc.lo)
        assertEquals(listOf("< 143", "143–150", "151–159", "160–167", "≥ 168"), zc.bands())
        assertEquals(191, zc.maxHr)
    }

    @Test fun zonaHrr() {
        val zc = Zones.cuts(PlanSettings(thr = "164–172", zm = "hrr"))
        assertEquals(listOf(123, 137, 150, 164, 177), zc.lo)
        assertEquals(55, zc.rest)
    }

    @Test fun zonaHrrMemakaiHrMaksIsianSendiri() {
        val zc = Zones.cuts(PlanSettings(thr = "164–172", zm = "hrr", hrMax = 185, rhr = 55.0))
        assertEquals(185, zc.maxHr)
        assertEquals(listOf(120, 133, 146, 159, 172), zc.lo)
    }

    @Test fun persenTidakBerurutanKembaliKeBawaan() {
        val zc = Zones.cuts(PlanSettings(thr = "164–172", zl = listOf(90.0, 85.0, 95.0, 100.0)))
        assertEquals(listOf(0, 143, 151, 160, 168), zc.lo)
    }

    @Test fun detikPerZona() {
        val zc = Zones.cuts(PlanSettings(thr = "164–172"))
        val s = Zones.secs(mapOf(130 to 10.0, 143 to 20.0, 150 to 5.0, 170 to 30.0, 200 to 1.0), zc)
        assertArrayEquals(doubleArrayOf(10.0, 25.0, 0.0, 0.0, 31.0), s, 1e-9)
    }

    @Test fun patokanSesiDariZona() {
        val (easy, thr) = Zones.sessionRefs(Zones.cuts(PlanSettings(thr = "164–172")))
        assertEquals(150, easy)
        assertEquals(160..167, thr)
    }
}
