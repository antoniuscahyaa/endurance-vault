package com.endurancevault.app

import com.endurancevault.app.domain.FreeRunRecommender
import com.endurancevault.app.domain.FreeRunRecommender.Run
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

/** Uji rekomendasi lari mode No Race: entri ganda tidak boleh menggelembungkan acuan long run. */
class FreeRunRecommenderTest {
    private val today = LocalDate.of(2026, 11, 12)

    private fun run(daysAgo: Int, km: Double, minPerKm: Double = 6.5) =
        Run(today.minusDays(daysAgo.toLong()), km, km * minPerKm, 140)

    /** Pola 4 pekan: lari easy 10–14 km dan long run 30 km, long run terakhir 11 hari lalu. */
    private fun history(extra: List<Run> = emptyList()): List<Run> =
        listOf(2 to 12.0, 3 to 10.0, 5 to 14.0, 6 to 10.0, 9 to 12.0, 11 to 30.0, 13 to 10.0, 14 to 12.0, 16 to 10.0, 18 to 30.0,
            20 to 12.0, 21 to 10.0, 23 to 14.0, 25 to 10.0, 27 to 12.0).map { run(it.first, it.second) } + extra

    @Test fun dropNearDuplicatesRemovesSameFileImportedTwice() {
        val a = run(11, 30.0)
        val b = Run(a.date, 30.05, a.minutes + 0.5, 141)
        assertEquals(1, FreeRunRecommender.dropNearDuplicates(listOf(a, b)).size)
    }

    @Test fun dropNearDuplicatesKeepsTwoDifferentRunsOnSameDay() {
        val am = Run(today.minusDays(3), 10.0, 65.0, 140)
        val pm = Run(today.minusDays(3), 6.0, 40.0, 138)
        assertEquals(2, FreeRunRecommender.dropNearDuplicates(listOf(am, pm)).size)
    }

    @Test fun duplicateLongRunDoesNotInflateReference() {
        val clean = FreeRunRecommender.recommend(FreeRunRecommender.Input(history(), today))
        val doubled = FreeRunRecommender.recommend(FreeRunRecommender.Input(history(listOf(run(11, 30.0))), today))
        assertEquals(clean.kind, doubled.kind)
        assertEquals(clean.km, doubled.km, 0.001)
        if (doubled.kind == FreeRunRecommender.Kind.LONG) assertTrue("jarak ${doubled.km} melebihi long run + 10%", doubled.km <= 33.0)
    }

    @Test fun twoRunsSameDayUseLongestSingleRunAsReference() {
        // 30 km + 22 km di hari yang sama (berbeda jauh, bukan duplikat) = 52 km per hari, tetapi acuan long run hanya 30 km.
        val runs = history(listOf(run(11, 22.0, 6.0)))
        val rec = FreeRunRecommender.recommend(FreeRunRecommender.Input(runs, today))
        if (rec.kind == FreeRunRecommender.Kind.LONG) assertTrue("jarak ${rec.km} terlalu jauh dari lari tunggal terpanjang", rec.km <= 33.0)
    }
}
