package com.endurancevault.app

import com.endurancevault.app.ui.sticker.ShareBrand
import com.endurancevault.app.ui.sticker.ShareStatsPrefs
import org.junit.Assert.assertEquals
import org.junit.Test

class ShareTitleTest {
    @Test fun emptyOrBlankTitleFallsBackToDefault() {
        assertEquals("EnduranceVault", ShareStatsPrefs.effectiveTitle(""))
        assertEquals("EnduranceVault", ShareStatsPrefs.effectiveTitle("   "))
    }

    @Test fun titleIsTrimmedAndCapped() {
        assertEquals("Tim Lari Pagi", ShareStatsPrefs.effectiveTitle("  Tim Lari Pagi  "))
        assertEquals(ShareBrand.MAX_LEN, ShareStatsPrefs.effectiveTitle("x".repeat(60)).length)
    }
}
