package com.endurancevault.app

import com.endurancevault.app.ui.screens.shortPlaceName
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ShortPlaceNameTest {
    @Test fun cutsAtFirstComma() {
        assertEquals("Ambarawa", shortPlaceName("Ambarawa, Kab. Semarang"))
        assertEquals("Ungaran", shortPlaceName("Ungaran, Indonesia"))
    }

    @Test fun keepsNameWithoutComma() = assertEquals("Bandungan", shortPlaceName("  Bandungan "))

    @Test fun genericOrBlankHidesPlace() {
        assertNull(shortPlaceName(""))
        assertNull(shortPlaceName("Lokasi saya"))
        assertNull(shortPlaceName("Lokasi latihan"))
        assertNull(shortPlaceName(", Kab. Semarang"))
    }
}
