package com.endurancevault.app

import com.endurancevault.app.domain.ActivityTimeSeries
import com.endurancevault.app.domain.SessionBuilder
import com.endurancevault.app.domain.SessionBuilder.Amount
import com.endurancevault.app.domain.SessionBuilder.Block
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SessionBuilderTest {
    /** 0..[total] dtk, 3 m/dtk konstan. */
    private fun ts(total: Int): ActivityTimeSeries {
        val sec = (0..total).toList()
        return ActivityTimeSeries(
            seconds = sec, distanceMeters = sec.map { it * 3.0 },
            heartRateBpm = sec.map { 150 }, cadenceSpm = sec.map { 170 },
            elevationMeters = sec.map { 10.0 }, gapSpeedCmPerSec = sec.map { 0 }, grade = sec.map { null },
        )
    }

    private fun t(sec: Int) = Amount(sec.toDouble(), false)
    private fun m(meters: Int) = Amount(meters.toDouble(), true)

    /** Susunan contoh: 15:00 + 3 x (8:00 / 2:00) + 10:00 = 55:00 */
    private fun standard() = listOf(
        Block.Plain("Pemanasan", t(900)),
        Block.Repeat("Ulangi", 3, t(480), t(120), true),
        Block.Plain("Pendinginan", t(600)),
    )

    @Test fun standardLayoutGivesEightUnlabeledSegments() {
        val p = SessionBuilder.resolve(ts(3300), standard())
        assertNull(p.error)
        assertEquals(8, p.drafts.size)
        // 1 pemanasan + 3 x (kerja + istirahat) + 1 pendinginan = 8 segmen (istirahat terakhir ikut)
        assertEquals(listOf(900, 1380, 1500, 1980, 2100, 2580, 2700, 3300), p.drafts.map { it.endSec })
        assertTrue(p.drafts.all { it.kind == null })
        assertEquals(listOf(false, true, false, true, false, true, false, false), p.isWork)
        assertEquals(1..1, p.segments[0]); assertEquals(2..7, p.segments[1]); assertEquals(8..8, p.segments[2])
        assertEquals(3300, p.composedSec); assertEquals(0, p.extraSec)
    }

    @Test fun noRestAfterLastDropsFinalRest() {
        val b = listOf(Block.Repeat("Ulangi", 3, t(60), t(30), false))
        val p = SessionBuilder.resolve(ts(400), b)
        assertNull(p.error)
        assertEquals(5, p.drafts.size)
        assertEquals(listOf(true, false, true, false, true), p.isWork)
    }

    @Test fun zeroRestMeansNoRestSegments() {
        val p = SessionBuilder.resolve(ts(400), listOf(Block.Repeat("Ulangi", 4, t(60), Amount(0.0, false), true)))
        assertNull(p.error)
        assertEquals(4, p.drafts.size)
    }

    @Test fun remainderGoesToLastSegment() {
        val p = SessionBuilder.resolve(ts(3312), standard())
        assertNull(p.error)
        assertEquals(12, p.extraSec); assertEquals(3300, p.composedSec)
        assertEquals(3312, p.drafts.last().endSec)
        assertEquals(612, p.drafts.last().endSec - p.drafts[p.drafts.lastIndex - 1].endSec)
        assertEquals(10 * 60 + 12, p.blockSec[2])
    }

    @Test fun tooLongIsRejected() {
        val p = SessionBuilder.resolve(ts(3000), standard())
        assertNotNull(p.error); assertTrue(p.drafts.isEmpty())
        // rentang blok tetap ada untuk ditampilkan
        assertEquals(2..7, p.segments[1])
    }

    @Test fun distanceAmountsMapThroughTimeAxis() {
        // 3 m/dtk: 900 m = 300 dtk, jeda 60 dtk
        val b = listOf(Block.Repeat("Ulangi", 2, m(900), t(60), false), Block.Plain("Pendinginan", t(120)))
        val p = SessionBuilder.resolve(ts(900), b)
        assertNull(p.error)
        assertEquals(listOf(300, 360, 660, 900), p.drafts.map { it.endSec })
        assertEquals(listOf(true, false, true, false), p.drafts.map { it.byDistance })
    }

    @Test fun distanceBeyondSessionIsRejected() {
        val p = SessionBuilder.resolve(ts(300), listOf(Block.Plain("Segmen", m(5000))))
        assertNotNull(p.error)
    }

    @Test fun invalidInputsAreReported() {
        assertNotNull(SessionBuilder.resolve(ts(300), emptyList()).error)
        assertNotNull(SessionBuilder.resolve(ts(300), listOf(Block.Plain("x", null))).error)
        assertNotNull(SessionBuilder.resolve(ts(300), listOf(Block.Repeat("x", 0, t(30), t(30), true))).error)
        assertNotNull(SessionBuilder.resolve(ts(300), listOf(Block.Repeat("x", null, t(30), t(30), true))).error)
        assertNotNull(SessionBuilder.resolve(ts(300), listOf(Block.Repeat("x", 100, t(1), t(1), true))).error)
    }

    @Test fun tooShortSegmentIsRejected() {
        val p = SessionBuilder.resolve(ts(300), listOf(Block.Plain("a", t(298)), Block.Plain("b", t(2))))
        // segmen terakhir menyerap selisih 2 dtk saja, di bawah minimum
        assertNotNull(p.error)
    }

    @Test fun singlePlainBlockIsOneSegment() {
        val p = SessionBuilder.resolve(ts(300), listOf(Block.Plain("a", t(100))))
        assertNull(p.error)
        assertEquals(1, p.drafts.size); assertEquals(300, p.drafts[0].endSec)
    }
}
