package com.endurancevault.app

import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.domain.PeriodStats
import com.endurancevault.app.domain.SharePeriod
import com.endurancevault.app.domain.SwDay
import com.endurancevault.app.domain.SwWeek
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class PeriodCompareTest {
    private fun act(date: String, km: Double, sec: Int, type: String = "run") =
        ActivityEntity(dateIso = date, km = km, durationSec = sec, type = type)

    @Test fun previousWeekIsTheMondayToSundayBefore() {
        val acts = listOf(act("2026-11-02", 10.0, 3600), act("2026-11-08", 5.0, 1800), act("2026-11-09", 8.0, 2800))
        val prev = PeriodStats.previous(acts, SharePeriod.WEEK, LocalDate.of(2026, 11, 11))
        assertNotNull(prev)
        assertEquals(15.0, prev!!.km, 1e-9)
        assertEquals(LocalDate.of(2026, 11, 2), prev.start)
    }

    @Test fun previousMonthStartsOnTheFirst() {
        val acts = listOf(act("2026-10-31", 10.0, 3600), act("2026-11-01", 4.0, 1500), act("2026-09-30", 7.0, 2400))
        val prev = PeriodStats.previous(acts, SharePeriod.MONTH, LocalDate.of(2026, 11, 20))
        assertEquals(10.0, prev!!.km, 1e-9)
        assertEquals(LocalDate.of(2026, 10, 1), prev.start)
    }

    @Test fun previousIsNullWhenEmpty() {
        assertNull(PeriodStats.previous(emptyList(), SharePeriod.WEEK, LocalDate.of(2026, 11, 11)))
    }

    @Test fun dayBaselineIsAveragePerRunOverTheLast28DaysExcludingToday() {
        val day = LocalDate.of(2026, 11, 11)
        val acts = listOf(
            act("2026-11-11", 20.0, 7200),                  // hari ini: tidak dihitung
            act("2026-11-10", 6.0, 2100),
            act("2026-10-15", 10.0, 3900),                  // 27 hari sebelumnya: dihitung
            act("2026-10-13", 30.0, 9000),                  // 29 hari sebelumnya: tidak dihitung
            act("2026-11-05", 50.0, 3600, type = "bike"),   // sepeda: tidak dihitung
        )
        val b = PeriodStats.baseline28(acts, day)!!
        assertEquals(2, b.sessions)
        assertEquals(8.0, b.km, 1e-9)
        assertEquals(3000, b.durationSec)
    }

    @Test fun planTargetSumsPlannedKmInsideTheRange() {
        val w = SwWeek(1, listOf(
            SwDay(LocalDate.of(2026, 11, 9), "easy", 8.0),
            SwDay(LocalDate.of(2026, 11, 11), "tempo", 10.0),
            SwDay(LocalDate.of(2026, 11, 16), "long", 18.0),
        ), 36.0)
        assertEquals(18.0, PeriodStats.planTarget(listOf(w), LocalDate.of(2026, 11, 9), LocalDate.of(2026, 11, 15))!!, 1e-9)
        assertNull(PeriodStats.planTarget(listOf(w), LocalDate.of(2026, 12, 1), LocalDate.of(2026, 12, 7)))
    }
}
