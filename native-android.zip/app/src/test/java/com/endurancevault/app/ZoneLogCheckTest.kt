package com.endurancevault.app

import com.endurancevault.app.domain.ZoneLogCheck
import org.junit.Assert.assertTrue
import org.junit.Test

class ZoneLogCheckTest {
    private val lower = listOf(95, 150, 160, 170, 180)
    private fun line(method: String, lthr: String = "95/150/160/170/180 of 175") =
        "HR zones: sent via hw.unitedevice.track for custom $method, upright MHR 95/114/133/152/171 of 190, LTHR $lthr (current method $method), HRR 1/2/3/4/5 resting 50, warning 190, 80 bytes"

    @Test fun sameAsApp() =
        assertTrue(ZoneLogCheck.report(listOf(line("LTHR")), 175, lower, true).contains("✓ Sama dengan app"))

    @Test fun differentThreshold() =
        assertTrue(ZoneLogCheck.report(listOf(line("LTHR", "95/150/160/170/180 of 170")), 175, lower, true).contains("✗ Berbeda"))

    @Test fun usesTheLatestLine() {
        val r = ZoneLogCheck.report(listOf(line("LTHR", "90/140/150/160/170 of 165"), line("LTHR")), 175, lower, true)
        assertTrue(r.contains("✓ Sama dengan app"))
    }

    @Test fun mhrMethodIsNotCountedAsLthr() =
        assertTrue(ZoneLogCheck.report(listOf(line("MHR")), 175, lower, false).contains("bukan LTHR"))

    @Test fun fitnessDataBranchExplained() =
        assertTrue(ZoneLogCheck.report(listOf("HR zones: sent 07/21 for custom MHR, MHR 1/2/3/4/5 of 190"), 175, lower, true).contains("FitnessData"))

    @Test fun noLogYet() =
        assertTrue(ZoneLogCheck.report(emptyList(), 175, lower, true).contains("Belum ada log"))
}
