package com.endurancevault.app

import com.endurancevault.app.domain.CoachActions
import com.endurancevault.app.domain.CoachContext
import com.endurancevault.app.domain.CoachContext.RunPoint
import com.endurancevault.app.domain.Kinds
import com.endurancevault.app.domain.LoadDay
import com.endurancevault.app.domain.MvEntry
import com.endurancevault.app.domain.PDay
import com.endurancevault.app.domain.PWeek
import com.endurancevault.app.domain.Phases
import com.endurancevault.app.domain.PlanEngine
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.domain.ReadinessMetric
import com.endurancevault.app.domain.ReadinessPart
import com.endurancevault.app.domain.TrainingMetricsResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class CoachContextTest {
    // 2026-11-11 adalah hari Rabu.
    private val today = LocalDate.of(2026, 11, 11)

    private fun planWith(kind: String, km: Double): PlanOutcome.Ok {
        val day = PDay(today, 2, kind, kind, "Sesi", km, "")
        val week = PWeek(0, today.minusDays(2), today.plusDays(4), Phases.BUILD, false, false, false, mutableListOf(day), km)
        return PlanOutcome.Ok(listOf(week), today.minusDays(2), today.plusDays(60), 9, false, false, true, 0, 0)
    }

    private fun toolNames(planActive: Boolean): List<String> {
        val defs = CoachActions.toolDefinitions(planActive)
        return (0 until defs.length()).map { defs.getJSONObject(it).getJSONObject("function").getString("name") }
    }

    // ---------- mode No plan ----------

    @Test fun noPlanModeYieldsPlanWithAllRestAndNoneFlag() {
        val p = PlanEngine.plan(PlanSettings(rtype = "none", start = today), today) as PlanOutcome.Ok
        assertTrue("flag none harus true agar konteks AI tidak membaca 'Libur' sebagai jadwal", p.none)
        assertFalse(CoachContext.planActive(p))
    }

    @Test fun noPlanNoteUsesWebStatusAndDoesNotTreatTodayAsRest() {
        assertTrue(CoachContext.NO_PLAN_NOTE.startsWith(CoachContext.NO_SESSION_STATUS))
        assertTrue(CoachContext.NO_PLAN_NOTE.contains("jangan menganggap hari ini"))
        assertFalse(CoachContext.NO_PLAN_NOTE.contains("Libur, 0"))
    }

    // ---------- aksi sesi rencana ----------

    @Test fun hasSessionOnOnlyForActivePlanWithNonRestDay() {
        val withSession = planWith(Kinds.QUALITY, 10.0)
        assertTrue(CoachContext.hasSessionOn(withSession, "2026-11-11"))
        assertFalse("tanggal lain tanpa sesi", CoachContext.hasSessionOn(withSession, "2026-11-12"))
        assertFalse("hari REST bukan sesi", CoachContext.hasSessionOn(planWith(Kinds.REST, 0.0), "2026-11-11"))
        val none = PlanEngine.plan(PlanSettings(rtype = "none", start = today), today) as PlanOutcome.Ok
        assertFalse("mode No plan tidak punya sesi", CoachContext.hasSessionOn(none, "2026-11-11"))
        assertFalse("plan error tidak punya sesi", CoachContext.hasSessionOn(PlanOutcome.Err("x"), "2026-11-11"))
        assertTrue(CoachContext.planActive(withSession))
        assertFalse(CoachContext.planActive(PlanOutcome.Err("x")))
    }

    @Test fun planOnlyToolsAreHiddenWithoutActivePlan() {
        val all = toolNames(true)
        val noPlan = toolNames(false)
        assertTrue(all.containsAll(CoachActions.PLAN_ONLY_TOOLS))
        assertTrue(noPlan.none { it in CoachActions.PLAN_ONLY_TOOLS })
        assertEquals(all.size - CoachActions.PLAN_ONLY_TOOLS.size, noPlan.size)
        assertTrue(noPlan.containsAll(listOf("add_activity", "save_daily", "update_settings", "send_workout_to_watch")))
    }

    // ---------- tren 4 minggu ----------

    @Test fun trendSummaryBuildsRollingWeekWindows() {
        val runs = listOf(
            RunPoint(today, 10.0, 60.0, 150),
            RunPoint(today.minusDays(3), 5.0, 30.0, 140),
            RunPoint(today.minusDays(15), 8.0, 48.0, null),
            RunPoint(today.minusDays(28), 12.0, 70.0, 150),   // di luar 28 hari
            RunPoint(today.minusDays(2), 0.0, 20.0, 150),     // km 0 diabaikan
            RunPoint(today.plusDays(1), 6.0, 36.0, 150),      // masa depan diabaikan
        )
        val s = CoachContext.trendSummary(runs, today)
        assertTrue(s, s.contains("- 0-6 hari lalu: 2 sesi, 15.0 km, 90 menit, pace 6:00 /km, HR rata-rata 147"))
        assertTrue(s, s.contains("- 7-13 hari lalu: tidak ada lari"))
        assertTrue(s, s.contains("- 14-20 hari lalu: 1 sesi, 8.0 km, 48 menit, pace 6:00 /km"))
        assertFalse("tanpa HR tidak menulis HR", s.lines().first { it.contains("14-20") }.contains("HR"))
        assertTrue(s, s.contains("- 21-27 hari lalu: tidak ada lari"))
    }

    // ---------- readiness dan beban ----------

    @Test fun recoverySummaryHandlesMissingAndPresentReadiness() {
        assertTrue(CoachContext.recoverySummary(null).contains("belum tersedia"))
        val readiness = ReadinessMetric(72, "Siap", "Lanjutkan sesuai rencana.", listOf(
            ReadinessPart("sl", "Tidur", 80, "7,5 jam", 1.0), ReadinessPart("hrv", "HRV", null, "–", 1.0),
        ), 5)
        val m = TrainingMetricsResult(
            listOf(LoadDay(today, 50.0, 40.0, 50.0, -10.0, 1)), emptyList(), 120, 40, 50, -10, 1.2, 0..0,
            "Beban optimal", "Seimbang.", readiness, 12, 2.7, 165, 190,
        )
        val s = CoachContext.recoverySummary(m)
        assertTrue(s, s.contains("Readiness hari ini 72/100 (Siap)"))
        assertTrue(s, s.contains("Tidur 80/100 (7,5 jam)"))
        assertFalse("faktor tanpa skor dilewati", s.contains("HRV"))
        assertTrue(s, s.contains("fitness 40, fatigue 50, form -10"))
        assertTrue(s, s.contains("Sisa pemulihan sekitar 12 jam"))
    }

    @Test fun unplannedRestsSummaryListsSpreadEntries() {
        assertEquals("tidak ada", CoachContext.unplannedRestsSummary(emptyList()))
        val e = MvEntry("spread", km = 6.0, spread = listOf("2026-11-12" to 3.0, "2026-11-13" to 3.0))
        val s = CoachContext.unplannedRestsSummary(listOf("2026-11-10" to e))
        assertTrue(s, s.contains("2026-11-10: libur dadakan, 6.0 km dibagi ke 2 hari"))
    }

    // ---------- kebiasaan ----------

    @Test fun dayNameIsIndonesian() {
        assertEquals("Rabu", CoachContext.dayName(today))
        assertEquals("Senin", CoachContext.dayName(LocalDate.of(2026, 11, 9)))
    }

    @Test fun habitCountsRunsPerWeekdayInWindow() {
        // Rabu 4 minggu terakhir (4x), Sabtu 2x, plus satu lari di luar jendela (30 hari lalu) yang harus diabaikan.
        val runs = listOf(
            today.minusDays(7), today.minusDays(14), today.minusDays(21), today.minusDays(28),
            today.minusDays(4), today.minusDays(11), today.minusDays(30),
        )
        val s = CoachContext.habitSummary(runs, today)
        assertTrue(s, s.contains("Rabu 4x"))
        assertTrue(s, s.contains("Sabtu 2x"))
        assertTrue(s, s.contains("Selasa 0x"))
        assertTrue(s, s.contains("Rata-rata 1.5 lari/pekan"))
        assertTrue(s, s.contains("Hari ini Rabu"))
        assertTrue(s, s.contains("belum ada lari tercatat"))
        assertTrue(s, s.contains("Lari terakhir 4 hari lalu (Sabtu)"))
    }

    @Test fun habitReportsTodayRunAndEmptyHistory() {
        assertTrue(CoachContext.habitSummary(listOf(today), today).contains("sudah ada lari tercatat"))
        assertTrue(CoachContext.habitSummary(emptyList(), today).contains("belum ada lari tercatat"))
    }
}
