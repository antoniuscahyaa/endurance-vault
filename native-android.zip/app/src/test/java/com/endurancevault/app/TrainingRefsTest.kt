package com.endurancevault.app

import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.domain.FitnessAnalytics
import com.endurancevault.app.domain.Js
import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.domain.ProgressAnalytics
import com.endurancevault.app.domain.TrainingRefs
import com.endurancevault.app.domain.TrainingRefs.Refs
import com.endurancevault.app.domain.TrainingRefs.Source
import com.endurancevault.app.domain.ZoneChecks
import com.endurancevault.app.domain.Zones
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

/** Acuan latihan otomatis: HR easy dan threshold dari zona, pace easy dari RAI atau lari easy terakhir, serta batas simpan. */
class TrainingRefsTest {
    private val s = PlanSettings()
    private val easyHr = Zones.sessionRefs(Zones.cuts(s, 55)).first
    private val thrZ = Zones.sessionRefs(Zones.cuts(s, 55)).second

    @Test fun tanpaDataHrDariZonaDanPaceKosong() {
        val r = TrainingRefs.compute(s, emptyList(), emptyList(), 55)
        assertEquals(Source.NONE, r.source)
        assertNull(r.paceMid)
        assertNull(r.paceRange)
        assertEquals(easyHr, r.easyHr)
        assertEquals("${thrZ.first}–${thrZ.last}", r.thr)
        assertNull(ZoneChecks.thrRange(r.thr))
        assertNull(ZoneChecks.easyHr(r.easyHr.toString()))
    }

    @Test fun satuLariEasyMemakaiFallbackPlusMinusSepuluhDetik() {
        // Satu lari saja: RAI butuh minimal tiga lari, jadi jalur cadangan dipakai. 70 menit / 10 km = 7:00/km.
        val run = ActivityEntity(dateIso = LocalDate.now().minusDays(2).toString(), km = 10.0, durationSec = 4200, avgHr = easyHr - 5)
        val r = TrainingRefs.compute(s, listOf(run), emptyList(), 55)
        assertEquals(Source.EASY_RUNS, r.source)
        assertEquals("7:00", r.paceMid)
        assertEquals("7:10–6:50", r.paceRange)
    }

    @Test fun lariDiAtasBatasEasyTidakDipakaiFallback() {
        val run = ActivityEntity(dateIso = LocalDate.now().minusDays(2).toString(), km = 10.0, durationSec = 4200, avgHr = easyHr + 15)
        val r = TrainingRefs.compute(s, listOf(run), emptyList(), 55)
        assertEquals(Source.NONE, r.source)
        assertNull(r.paceMid)
    }

    @Test fun cukupLariMemakaiZonaEasyRai() {
        val runs = (1..4).map {
            ActivityEntity(dateIso = LocalDate.now().minusDays(it.toLong()).toString(), km = 10.0, durationSec = 3600, avgHr = 150)
        }
        val rai = ProgressAnalytics.runningAbility(s, runs, emptyList())
        assertNotNull(rai)
        val easy = FitnessAnalytics.PACE_ZONES.first { it.name == "Easy" }
        val slow = FitnessAnalytics.paceAtFrac(rai!!.value, easy.lo)
        val fast = FitnessAnalytics.paceAtFrac(rai.value, easy.hi)

        val r = TrainingRefs.compute(s, runs, emptyList(), 55)
        assertEquals(Source.RAI, r.source)
        assertEquals("${Js.paceStr(slow)}–${Js.paceStr(fast)}", r.paceRange)
        assertEquals(Js.paceStr((slow + fast) / 2), r.paceMid)
        assertNull(ZoneChecks.pace(r.paceMid!!))
        // Urutan sama dengan kartu Fitness: lambat dulu, cepat kemudian.
        assertTrue(slow > fast)
    }

    // ---- batas simpan ----

    private fun refs(hr: Int = 154, thr: String = "164–172", pace: String? = "6:40") =
        Refs(hr, thr, pace, pace?.let { "$it–$it" }, if (pace == null) Source.NONE else Source.RAI)

    private val saved = PlanSettings(hr = 154, thr = "164–172", pace = "6:37")

    @Test fun selisihPaceKecilTidakDisimpan() {
        assertNull(TrainingRefs.update(saved, refs(pace = "6:40")))   // 3 detik
        assertNull(TrainingRefs.update(saved, refs(pace = "6:33")))   // 4 detik
    }

    @Test fun selisihPaceLimaDetikAtauLebihDisimpan() {
        assertEquals("6:42", TrainingRefs.update(saved, refs(pace = "6:42"))!!.pace)
        assertEquals("6:30", TrainingRefs.update(saved, refs(pace = "6:30"))!!.pace)
    }

    @Test fun hrBerubahDisimpanTanpaMenggeserPaceKecil() {
        val n = TrainingRefs.update(saved, refs(hr = 155, pace = "6:40"))!!
        assertEquals(155, n.hr)
        assertEquals("6:37", n.pace)
    }

    @Test fun thresholdBerubahDisimpan() {
        assertEquals("165–173", TrainingRefs.update(saved, refs(thr = "165–173"))!!.thr)
    }

    @Test fun paceTersimpanTidakValidSelaluDiganti() {
        assertEquals("6:40", TrainingRefs.update(saved.copy(pace = ""), refs(pace = "6:40"))!!.pace)
    }

    @Test fun tanpaDataPaceNilaiTersimpanDipertahankan() {
        assertNull(TrainingRefs.update(saved, refs(pace = null)))
        assertEquals("6:37", TrainingRefs.update(saved, refs(hr = 156, pace = null))!!.pace)
    }
}
