package com.endurancevault.app

import com.endurancevault.app.domain.IvRep
import com.endurancevault.app.domain.SegKind
import com.endurancevault.app.domain.SegRole
import com.endurancevault.app.domain.Segment
import com.endurancevault.app.domain.ShareSegments
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ShareSegmentsTest {
    private fun seg(endKm: Double, d: Double, pace: Double, type: String? = null, label: String? = null) =
        Segment(k = endKm, d = d, min = d * pace, pace = pace, hr = null, gain = 0, loss = 0, cad = null, name = "", type = type, label = label)

    @Test fun typedSegmentsKeepTheirRoleAndLabel() {
        val sg = listOf(
            seg(1.0, 1.0, 6.0, label = "Pemanasan"),
            seg(1.4, 0.4, 4.0, type = SegKind.REPETITION),
            seg(1.6, 0.2, 7.0),
            seg(2.0, 0.4, 4.1, type = SegKind.REPETITION),
        )
        val r = ShareSegments.build(sg, null)
        assertEquals(listOf(SegRole.CUSTOM, SegRole.REP, SegRole.OTHER, SegRole.REP), r.map { it.role })
        assertEquals("Pemanasan", r[0].label)
        assertEquals("Repetisi", r[1].label)
        assertEquals(1.0, r[1].startKm, 1e-9)
    }

    @Test fun unlabeledLapsAreSplitIntoWarmupRepsRestAndCooldown() {
        val sg = listOf(
            seg(1.0, 1.0, 6.0),      // 0 pemanasan
            seg(1.4, 0.4, 4.0),      // 1 rep
            seg(1.6, 0.2, 7.0),      // 2 istirahat
            seg(2.0, 0.4, 4.1),      // 3 rep
            seg(2.2, 0.2, 7.0),      // 4 istirahat
            seg(2.6, 0.4, 4.0),      // 5 rep
            seg(3.6, 1.0, 6.2),      // 6 pendinginan
        )
        val laps = listOf(IvRep(0.4, 1.6, 4.0, null, 1, 1), IvRep(0.4, 1.64, 4.1, null, 3, 3), IvRep(0.4, 1.6, 4.0, null, 5, 5))
        val r = ShareSegments.build(sg, laps)
        assertEquals(
            listOf(SegRole.WARMUP, SegRole.REP, SegRole.REST, SegRole.REP, SegRole.REST, SegRole.REP, SegRole.COOLDOWN),
            r.map { it.role },
        )
        assertEquals("Pendinginan", r.last().label)
    }

    @Test fun userLabelIsNotOverriddenByDetection() {
        val sg = listOf(seg(1.0, 1.0, 6.0, type = SegKind.STRIDE), seg(2.0, 1.0, 5.0), seg(3.0, 1.0, 5.0))
        val laps = listOf(IvRep(1.0, 5.0, 5.0, null, 1, 2))
        val r = ShareSegments.build(sg, laps)
        assertEquals(SegRole.STRIDE, r[0].role)
        assertEquals(SegRole.REP, r[1].role)
    }

    @Test fun fewerThanTwoValidSegmentsGivesEmpty() {
        assertTrue(ShareSegments.build(listOf(seg(5.0, 5.0, 5.5)), null).isEmpty())
        assertTrue(ShareSegments.build(listOf(seg(1.0, 0.0, 5.5), seg(2.0, 1.0, 0.0)), null).isEmpty())
    }
}
