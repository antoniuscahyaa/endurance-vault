package com.endurancevault.app

import com.endurancevault.app.domain.RouteGeo
import kotlin.math.abs
import kotlin.math.cos
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RouteGeoTest {
    @Test fun pemulihanKoordinatSesuaiRumusActBuilder() {
        // Rute kecil di sekitar Jakarta, dinormalkan seperti ActBuilder (x = lon*cos, y terbalik).
        val lats = listOf(-6.2000, -6.2010, -6.2025, -6.2040)
        val lons = listOf(106.8000, 106.8015, 106.8020, 106.8040)
        val cs = cos(lats.average() * Math.PI / 180)
        val xs = lons.map { it * cs }
        val mnx = xs.min(); val mxy = lats.max()
        val sc = 1000 / maxOf(xs.max() - mnx, mxy - lats.min())
        val rt = lats.indices.map { Math.round((xs[it] - mnx) * sc).toInt() to Math.round((mxy - lats[it]) * sc).toInt() }
        val frame = RouteGeo.frameOf(listOf(mnx / cs, mxy, sc, cs))
        assertNotNull(frame)
        val back = RouteGeo.toLatLon(frame!!, rt)
        for (i in lats.indices) {
            assertEquals(lats[i], back[i].lat, 0.00005) // ±~5 m: kuantisasi 0..1000
            assertEquals(lons[i], back[i].lon, 0.00005)
        }
    }

    @Test fun bingkaiTidakValidDitolak() {
        assertNull(RouteGeo.frameOf(null))
        assertNull(RouteGeo.frameOf(listOf(106.8, -6.2, 100.0)))
        assertNull(RouteGeo.frameOf(listOf(106.8, -6.2, 0.0, 0.99)))
        assertNull(RouteGeo.frameOf(listOf(106.8, -6.2, 100.0, 1.5)))
        assertNull(RouteGeo.frameOf(listOf(999.0, -6.2, 100.0, 0.99)))
    }

    @Test fun mercatorBolakBalik() {
        for (z in listOf(0, 8, 15)) {
            val x = RouteGeo.worldX(106.8272, z); val y = RouteGeo.worldY(-6.1754, z)
            assertEquals(106.8272, RouteGeo.lonOfWorldX(x, z), 1e-7)
            assertEquals(-6.1754, RouteGeo.latOfWorldY(y, z), 1e-7)
        }
        // Titik (0,0) ada di tengah dunia
        assertEquals(128.0, RouteGeo.worldX(0.0, 0), 1e-9)
        assertEquals(128.0, RouteGeo.worldY(0.0, 0), 1e-6)
    }

    @Test fun kameraMemuatSeluruhRuteDanUbinMenutupKanvas() {
        val pts = listOf(RouteGeo.LatLon(-6.2000, 106.8000), RouteGeo.LatLon(-6.2100, 106.8120))
        val w = 1000.0; val h = 800.0
        val cam = RouteGeo.fit(pts, w, h)!!
        for (p in pts) {
            val sx = w / 2 + (RouteGeo.worldX(p.lon, cam.zoom) - cam.centerX) * cam.scale
            val sy = h / 2 + (RouteGeo.worldY(p.lat, cam.zoom) - cam.centerY) * cam.scale
            assertTrue("x $sx", sx in 0.0..w); assertTrue("y $sy", sy in 0.0..h)
        }
        assertTrue(cam.scale >= 1.0 && cam.scale < 2.0 + 1e-9)
        val tiles = RouteGeo.tilesFor(cam, w, h)
        assertTrue(tiles.isNotEmpty())
        val n = 1 shl cam.zoom
        assertTrue(tiles.all { it.id.x in 0 until n && it.id.y in 0 until n && it.id.z == cam.zoom })
    }

    @Test fun titikTunggalDibatasiZoom17() {
        val cam = RouteGeo.fit(listOf(RouteGeo.LatLon(-6.2, 106.8)), 800.0, 600.0)!!
        assertEquals(17, cam.zoom)
        assertTrue(abs(cam.scale - 1.0) < 2.0)
    }

    private val v0 = RouteGeo.View(zoomF = 14.0, cx0 = 150.0, cy0 = 120.0)

    @Test fun cubitMenjagaTitikDiBawahJari() {
        val w = 1000.0; val h = 800.0; val fx = 700.0; val fy = 300.0
        val before = 2.0.let { Math.pow(it, v0.zoomF) }
        val wx0 = v0.cx0 + (fx - w / 2) / before; val wy0 = v0.cy0 + (fy - h / 2) / before
        val v1 = RouteGeo.transform(v0, w, h, fx, fy, 0.0, 0.0, 2.0, minZoom = 10.0)
        assertEquals(15.0, v1.zoomF, 1e-9)
        val k1 = Math.pow(2.0, v1.zoomF)
        assertEquals(wx0, v1.cx0 + (fx - w / 2) / k1, 1e-9)
        assertEquals(wy0, v1.cy0 + (fy - h / 2) / k1, 1e-9)
    }

    @Test fun geserMenggerakkanPusatBerlawananArahJari() {
        val v1 = RouteGeo.transform(v0, 1000.0, 800.0, 500.0, 400.0, 100.0, -50.0, 1.0, minZoom = 10.0)
        val k = Math.pow(2.0, 14.0)
        assertEquals(v0.cx0 - 100.0 / k, v1.cx0, 1e-9)
        assertEquals(v0.cy0 + 50.0 / k, v1.cy0, 1e-9)
        assertEquals(14.0, v1.zoomF, 1e-9)
    }

    @Test fun zoomDibatasiBatasBawahDanAtas() {
        assertEquals(12.5, RouteGeo.transform(v0, 1000.0, 800.0, 500.0, 400.0, 0.0, 0.0, 0.001, minZoom = 12.5).zoomF, 1e-9)
        assertEquals(RouteGeo.MAX_ZOOM, RouteGeo.transform(v0, 1000.0, 800.0, 500.0, 400.0, 0.0, 0.0, 10.0, minZoom = 10.0)
            .let { RouteGeo.transform(it, 1000.0, 800.0, 500.0, 400.0, 0.0, 0.0, 10.0, minZoom = 10.0) }
            .let { RouteGeo.transform(it, 1000.0, 800.0, 500.0, 400.0, 0.0, 0.0, 10.0, minZoom = 10.0) }.zoomF, 1e-9)
    }
}
