package com.endurancevault.app

import com.endurancevault.app.data.ActStore
import com.endurancevault.app.domain.ActivityTimeSeries
import com.endurancevault.app.domain.SegKind
import com.endurancevault.app.domain.Segment
import com.endurancevault.app.domain.SegmentSplit
import com.endurancevault.app.domain.SegmentSplit.Draft
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SegmentSplitTest {
    /** 0..600 dtk. Detik 0-299 lari 3 m/dtk (5:33/km), detik 300-599 lari 5 m/dtk (3:20/km). HR 140 lalu 170. Elevasi naik 0,1 m/dtk. */
    private fun ts(): ActivityTimeSeries {
        val sec = (0..600).toList()
        val dist = ArrayList<Double>(); var d = 0.0
        sec.forEach { s -> dist += d; d += if (s < 300) 3.0 else 5.0 }
        return ActivityTimeSeries(
            seconds = sec, distanceMeters = dist,
            heartRateBpm = sec.map { if (it < 300) 140 else 170 }, cadenceSpm = sec.map { if (it < 300) 160 else 180 },
            elevationMeters = sec.map { 10.0 + it * 0.1 }, gapSpeedCmPerSec = sec.map { 0 }, grade = sec.map { null },
        )
    }

    @Test fun statsPerSegment() {
        val t = ts()
        val st = SegmentSplit.stats(t, listOf(Draft(300, null), Draft(600, SegKind.REPETITION)))
        assertEquals(900.0, st[0].meters, 0.5); assertEquals(300, st[0].seconds)
        assertEquals(1500.0, st[1].meters, 0.5); assertEquals(300, st[1].seconds)
        assertEquals(140, st[0].avgHr); assertEquals(170, st[1].avgHr)
        assertEquals(5.55, st[0].pace!!, 0.02); assertEquals(3.33, st[1].pace!!, 0.02)
        // 300 dtk x 0,1 m = 30 m naik per segmen
        assertEquals(30.0, st[0].gain.toDouble(), 2.0); assertEquals(0, st[0].loss)
        // jumlah jarak segmen = total sesi
        assertEquals(t.distanceMeters.last(), st.sumOf { it.meters }, 0.5)
    }

    @Test fun distanceAndTimeAxesAreConsistent() {
        val t = ts()
        val sec = SegmentSplit.secAtMeters(t, 900.0)
        assertEquals(300, sec)
        assertEquals(900.0, SegmentSplit.metersAt(t, sec), 0.5)
        // lewat total jarak: jatuh ke ujung sesi
        assertEquals(600, SegmentSplit.secAtMeters(t, 99_999.0))
    }

    @Test fun validateRejectsShortOrUnfinishedSegments() {
        val t = ts()
        assertNull(SegmentSplit.validate(t, emptyList()))
        assertNull(SegmentSplit.validate(t, listOf(Draft(120, null), Draft(600, null))))
        assertTrue(SegmentSplit.validate(t, listOf(Draft(3, null), Draft(600, null)))!!.contains("minimal"))
        assertTrue(SegmentSplit.validate(t, listOf(Draft(300, null), Draft(300, null), Draft(600, null))) != null)
        assertTrue(SegmentSplit.validate(t, listOf(Draft(300, null)))!!.contains("akhir sesi"))
    }

    @Test fun storedMapsRoundTripThroughActStore() {
        val t = ts()
        val segs = SegmentSplit.toSegments(t, listOf(Draft(120, SegKind.STRIDE), Draft(600, null)))
        val act: Map<String, Any?> = mapOf("sg" to SegmentSplit.toMaps(segs))
        val back = ActStore.fromMap(act).segments
        assertEquals(2, back.size)
        assertEquals("1", back[0].name); assertEquals(SegKind.STRIDE, back[0].type); assertNull(back[1].type)
        assertEquals(segs[0].d, back[0].d, 0.001); assertEquals(segs[1].pace, back[1].pace, 0.001)
        assertEquals(segs.sumOf { it.d }, t.distanceMeters.last() / 1000.0, 0.001)
    }

    @Test fun withKindChangesOnlyTheTargetSegment() {
        val t = ts()
        val act: Map<String, Any?> = mapOf("sg" to SegmentSplit.toMaps(SegmentSplit.toSegments(t, listOf(Draft(300, null), Draft(600, null)))), "km" to 2.4)
        val out = SegmentSplit.withKind(act, 1, SegKind.PROGRESSIVE)!!
        val segs = ActStore.fromMap(out).segments
        assertNull(segs[0].type); assertEquals(SegKind.PROGRESSIVE, segs[1].type)
        assertEquals(2.4, out["km"])
        val cleared = ActStore.fromMap(SegmentSplit.withKind(out, 1, null)!!).segments
        assertNull(cleared[1].type)
        assertNull(SegmentSplit.withKind(act, 5, SegKind.STRIDE))
        assertNull(SegmentSplit.withKind(mapOf("km" to 1.0), 0, SegKind.STRIDE))
    }

    @Test fun existingLapsBecomeDraftsByCumulativeDistance() {
        val t = ts()
        val laps = listOf(
            Segment(0.9, 0.9, 5.0, 5.5, 140, 0, 0, null, "1", "w"),   // `ty` lama dari FIT dianggap tanpa label
            Segment(2.4, 1.5, 5.0, 3.3, 170, 0, 0, null, "2", SegKind.REPETITION),
        )
        val drafts = SegmentSplit.draftsFromSegments(t, laps)!!
        assertEquals(listOf(300, 600), drafts.map { it.endSec })
        assertNull(drafts[0].kind); assertEquals(SegKind.REPETITION, drafts[1].kind)
        // total jarak lap jauh dari deret: tidak ditebak
        assertNull(SegmentSplit.draftsFromSegments(t, listOf(Segment(1.0, 1.0, 5.0, 5.0, null, 0, 0, null, "1", null))))
    }

    @Test fun mixedUnitsShareOneSecondAxis() {
        val t = ts()
        val r1 = SegmentSplit.secAtMeters(t, 400.0)
        val d = listOf(
            Draft(r1, SegKind.REPETITION, true),
            Draft(r1 + 60, null, false),
            Draft(SegmentSplit.secAtMeters(t, SegmentSplit.metersAt(t, r1 + 60) + 400.0), SegKind.REPETITION, true),
            Draft(600, null, false),
        )
        assertNull(SegmentSplit.validate(t, d))
        val st = SegmentSplit.stats(t, d)
        assertEquals(400.0, st[0].meters, 4.0); assertEquals(60, st[1].seconds); assertEquals(400.0, st[2].meters, 6.0)
        assertEquals(t.distanceMeters.last(), st.sumOf { it.meters }, 0.5)
        assertEquals(true, d[0].byDistance); assertEquals(false, Draft(10, null).byDistance)
        assertEquals(400.0, SegmentSplit.parseMeters("400")!!, 1e-9); assertNull(SegmentSplit.parseMeters("0"))
    }

    @Test fun parsing() {
        assertEquals(90, SegmentSplit.parseSeconds("1:30")); assertEquals(3725, SegmentSplit.parseSeconds("1:02:05"))
        assertEquals(45, SegmentSplit.parseSeconds("45")); assertNull(SegmentSplit.parseSeconds("1:75")); assertNull(SegmentSplit.parseSeconds("abc"))
        assertEquals(1.25, SegmentSplit.parseKm("1,25")!!, 1e-9); assertNull(SegmentSplit.parseKm("-1")); assertNull(SegmentSplit.parseKm(""))
        assertEquals("1:30", SegmentSplit.fmtSeconds(90)); assertEquals("1:02:05", SegmentSplit.fmtSeconds(3725))
        assertNotNull(SegKind.label(null)); assertNull(SegKind.normalize("w"))
    }
}
