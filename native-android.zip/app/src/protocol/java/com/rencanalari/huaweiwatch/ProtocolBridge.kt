package com.rencanalari.huaweiwatch

import android.content.Context
import com.endurancevault.app.data.HuaweiSleepParity
import com.joyodigitama.huaweiwear.AgpsFetchException
import com.joyodigitama.huaweiwear.AgpsSource
import com.joyodigitama.huaweiwear.ErrorCodes
import com.joyodigitama.huaweiwear.EphemerisLink
import com.joyodigitama.huaweiwear.EphemerisNet
import com.joyodigitama.huaweiwear.LinkState
import com.joyodigitama.huaweiwear.HeartRateZonesSync
import com.joyodigitama.huaweiwear.LogDirection
import com.joyodigitama.huaweiwear.SyncStore
import com.joyodigitama.huaweiwear.SyncSummary
import com.joyodigitama.huaweiwear.WearEvents
import com.joyodigitama.huaweiwear.WearException
import com.joyodigitama.huaweiwear.WearLink
import com.joyodigitama.huaweiwear.WearSettings
import com.joyodigitama.huaweiwear.WeatherController
import com.joyodigitama.huaweiwear.WeatherLocationMode
import com.joyodigitama.huaweiwear.WeatherPlace
import com.joyodigitama.huaweiwear.WeatherSettings
import com.joyodigitama.huaweiwear.TemperatureUnit
import java.util.ArrayDeque
import java.time.Instant
import java.time.ZoneOffset
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/**
 * Jembatan ramping dari plugin Capacitor ke inti protokol JoyoFit (WearLink: RFCOMM, autentikasi HiChain, inisialisasi,
 * sinkron aktivitas/tidur/workout ke SQLite). Berbeda dengan WearRuntime milik JoyoFit, jembatan ini TIDAK memakai
 * layanan latar, notifikasi, Health Connect, panggilan, SMS, maupun P2P: hanya yang dibutuhkan tahap
 * "hubungkan, sinkron, baca", ditambah pengiriman cuaca ke jam (WeatherController).
 *
 * Satu proses = satu tautan. Alamat Bluetooth tidak ditulis ke log yang dikembalikan ke JS.
 */
class ProtocolBridge private constructor(context: Context) : ProtocolGateway {
  private val appContext = context.applicationContext
  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
  private val settings = WearSettings(appContext)
  private val syncStore = SyncStore(appContext)

  @Volatile private var lastState: LinkState = LinkState.DISCONNECTED
  @Volatile private var lastError: String? = null
  @Volatile private var battery: Int? = null

  /** Kapan (ms) [battery] benar-benar dibaca dari jam; 0 = belum ada. Supaya nilai basi tidak tampak sebagai bacaan baru. */
  @Volatile private var batteryAtMs: Long = 0L
  @Volatile private var lastSummary: SyncSummary? = null

  /** Waktu (ms) sinkron terakhir yang selesai, dari aplikasi maupun layanan latar. 0 = belum pernah sejak proses ini mulai. */
  @Volatile var lastSyncAtMs: Long = 0L
    private set
  @Volatile private var lastSyncError: String? = null
  @Volatile private var lastFrameStats: String? = null

  /** Dipanggil tiap keadaan tautan, baterai, atau sinkron berubah; dipakai layanan latar untuk menyegarkan notifikasi. */
  private val listeners = java.util.concurrent.CopyOnWriteArrayList<() -> Unit>()

  fun addListener(listener: () -> Unit) {
    listeners.addIfAbsent(listener)
  }

  fun removeListener(listener: () -> Unit) {
    listeners.remove(listener)
  }

  private fun fire() {
    for (l in listeners) {
      try {
        l()
      } catch (_: Throwable) {
      }
    }
  }

  private val logLock = Any()
  private val logLines = ArrayDeque<Pair<Int, String>>()
  private var logSeq = 0

  private val events: WearEvents = object : WearEvents {
    override fun state(state: LinkState, error: String?) {
      lastState = state
      lastError = error
      // Tautan putus: level terakhir tidak lagi mewakili jam (mis. selama lari, saat jam mode olahraga), jadi dibuang.
      if (state == LinkState.DISCONNECTED) {
        battery = null
        batteryAtMs = 0L
      }
      try {
        track.onLinkState(state)
      } catch (e: Exception) {
        addLog("P2P gagal: ${e.message ?: e.javaClass.simpleName}")
      }
      try {
        weather.onLinkState(state)
      } catch (e: Exception) {
        addLog("Cuaca gagal: ${e.message ?: e.javaClass.simpleName}")
      }
      try {
        liveHr.onLinkState(state)
      } catch (e: Exception) {
        addLog("HR live gagal: ${e.message ?: e.javaClass.simpleName}")
      }
      try {
        // Saat dimatikan, tautan baru tidak dipasangi pendengar A-GPS; putus tetap dilepas.
        if (agpsConfig.enabled || state == LinkState.DISCONNECTED) agps.onLinkState(state)
      } catch (e: Exception) {
        addLog("A-GPS gagal: ${e.message ?: e.javaClass.simpleName}")
      }
      addLog("STATE ${state.wire}" + if (error != null) ": $error" else "")
      fire()
    }

    override fun battery(level: Int) {
      battery = level
      batteryAtMs = System.currentTimeMillis()
      fire()
    }

    override fun syncComplete(summary: SyncSummary) {
      lastSummary = summary
      lastSyncAtMs = System.currentTimeMillis()
      lastSyncError = null
      fire()
      addLog("SYNC selesai: ${summary.samples} sampel, ${summary.sleep} segmen tidur, ${summary.workouts} workout")
    }

    override fun log(direction: LogDirection, serviceId: Int?, commandId: Int?, hex: String?, message: String) {
      // Tanpa hex bingkai: terenkripsi dengan kunci ponsel ini dan tidak berguna bagi pembaca log.
      val ids = if (serviceId != null) " svc=%02x cmd=%02x".format(serviceId, commandId ?: 0) else ""
      // Isi bingkai langkah per sinkron (berapa yang membawa HR, SpO2, HR istirahat): tampil di rincian data tab Jam.
      if (message.startsWith("Sync HR:") && message.contains("step subcontainers")) lastFrameStats = message.removePrefix("Sync HR:").trim()
      addLog("${direction.wire.uppercase()}$ids $message")
    }
  }

  private val link: WearLink = WearLink(appContext, events, settings, syncStore)

  /** Zona HR untuk jam jalur "track" (P2P); jam lain tidak memakainya. */
  private val track: TrackZonesController = TrackZonesController(link, settings, events)

  /** Kursus lari (sesi terstruktur) ke aplikasi kebugaran jam lewat P2P; eksperimental. */
  private val courses: CoursePusher = CoursePusher(link, events) { track.manager() }

  /** Rute GPX ke jam lewat P2P (alur Gadgetbridge); eksperimental. */
  private val routes: RoutePusher = RoutePusher(link, events) { track.manager() }

  /** Cuaca ke jam: Open-Meteo dari titik pilihan app, dikirim saat tersambung, saat jam memintanya, dan berkala selama tautan hidup. */
  /** HR live dari jam untuk layar Live sepeda (tampilan saja, tidak disimpan). */
  private val liveHr: LiveHeartRateFeed = LiveHeartRateFeed(link, settings, events, scope)

  /** A-GPS (update satelit): jam yang meminta data orbit dilayani lewat mirror pengguna, cadangannya Broadcom. */
  private val agpsConfig = AgpsConfig(appContext).also { it.apply() }
  private val agps: EphemerisLink = EphemerisLink(appContext, link, events, scope)

  private val weatherSettings = WeatherSettings(appContext)
  private val weather: WeatherController = WeatherController(appContext, weatherSettings, link, events, scope)

  /** Notifikasi ponsel ke jam (WhatsApp dan aplikasi lain yang dipilih); EKSPERIMENTAL. */
  private val notifySettings = NotifySettings(appContext)
  private val notifier: NotificationForwarder = NotificationForwarder(link, settings, notifySettings, events)

  private fun addLog(raw: String) {
    val line = MAC.replace(raw, "xx:xx:xx:xx:xx:xx")
    synchronized(logLock) {
      logSeq++
      logLines.addLast(logSeq to line)
      while (logLines.size > MAX_LOG_LINES) logLines.removeFirst()
    }
  }

  override fun status(): JSONObject {
    val out = JSONObject()
    out.put("protocolReady", true)
    out.put("state", lastState.wire)
    out.put("error", lastError ?: JSONObject.NULL)
    out.put("battery", battery ?: JSONObject.NULL)
    out.put("batteryAt", if (battery != null && batteryAtMs > 0L) batteryAtMs / 1000 else JSONObject.NULL)
    out.put("device", publicInfo(link.deviceInfo()) ?: JSONObject.NULL)
    out.put("lastSummary", toJson(lastSummary?.toJs()))
    out.put("keepAlive", KeepAliveConfig.wanted(appContext))
    out.put("lastSyncAt", if (lastSyncAtMs > 0L) lastSyncAtMs / 1000 else JSONObject.NULL)
    out.put("lastSyncError", lastSyncError ?: JSONObject.NULL)
    out.put("frameStats", lastFrameStats ?: JSONObject.NULL)
    return out
  }

  // ---- Dipakai WatchKeepAliveService: sambung ulang, sinkron berkala, dan uji tautan tanpa JS ----

  internal class KeepSnapshot(
    val state: LinkState,
    val battery: Int?,
    val name: String?,
    val error: String?,
    val lastSyncMs: Long,
    val syncError: String?,
  )

  internal fun snapshot(): KeepSnapshot {
    val name = (link.deviceInfo()?.get("name") as? String) ?: settings.watchName
    return KeepSnapshot(lastState, battery, name, lastError, lastSyncAtMs, lastSyncError)
  }

  fun watchAddress(): String? = settings.watchAddress

  /**
   * Menyambung ke jam yang diingat. Jam yang belum pernah terikat TIDAK disambung otomatis: ikatan pertama butuh
   * konfirmasi di layar jam dan harus dimulai pengguna dari aplikasi. Mengembalikan null bila berhasil, atau alasan gagal.
   */
  internal suspend fun keepConnect(): String? {
    val address = settings.watchAddress ?: return "no-watch"
    if (link.needsBind(address)) return "needs-bind"
    return try {
      link.connect(address)
      lastError = null
      null
    } catch (e: CancellationException) {
      throw e
    } catch (e: WearException) {
      if (e.errorCode == ErrorCodes.BUSY) null else (e.message ?: e.errorCode)
    } catch (e: Throwable) {
      e.message ?: e.javaClass.simpleName
    }
  }

  /** Sinkron bertahap; mengembalikan true bila berhasil atau sinkron lain sedang berjalan (bukan kegagalan). */
  internal suspend fun keepSync(): Boolean = try {
    link.syncActivity(false)
    true
  } catch (e: CancellationException) {
    throw e
  } catch (e: WearException) {
    if (e.errorCode == ErrorCodes.BUSY) {
      true
    } else {
      lastSyncError = e.message ?: e.errorCode
      addLog("AUTOSYNC gagal [${e.errorCode}]: ${e.message}")
      fire()
      false
    }
  } catch (e: Throwable) {
    lastSyncError = e.message ?: e.javaClass.simpleName
    addLog("AUTOSYNC gagal: ${lastSyncError}")
    fire()
    false
  }

  /** Uji tautan dengan membaca baterai jam; gagal berarti tautan setengah mati dan perlu disambung ulang. */
  internal suspend fun keepPing(): Boolean = try {
    link.refreshBattery()
    true
  } catch (e: CancellationException) {
    throw e
  } catch (e: WearException) {
    e.errorCode == ErrorCodes.BUSY
  } catch (e: Throwable) {
    false
  }

  /** Tutup tautan yang mati agar keadaan kembali ke disconnected dan layanan menyambung ulang. */
  internal fun keepDrop() {
    addLog("Tautan tidak menjawab; ditutup untuk disambung ulang")
    link.disconnect()
  }

  override fun log(since: Int): JSONObject {
    val arr = JSONArray()
    var last = since
    synchronized(logLock) {
      for ((seq, text) in logLines) {
        if (seq > since) {
          val row = JSONObject()
          row.put("seq", seq)
          row.put("text", text)
          arr.put(row)
        }
        last = maxOf(last, seq)
      }
    }
    return JSONObject().put("lines", arr).put("last", last)
  }

  override fun connect(address: String, callback: ProtocolGateway.Callback) {
    scope.launch {
      try {
        callback.ok(publicInfo(link.connect(address)) ?: JSONObject())
      } catch (e: CancellationException) {
        throw e
      } catch (e: WearException) {
        callback.error(e.errorCode, e.message ?: e.errorCode)
      } catch (e: Throwable) {
        callback.error("ERR_UNKNOWN", e.message ?: e.javaClass.simpleName)
      }
    }
  }

  override fun refreshBattery(callback: ProtocolGateway.Callback) {
    scope.launch {
      try {
        val level = link.refreshBattery()
        callback.ok(JSONObject().put("battery", level).put("batteryAt", System.currentTimeMillis() / 1000))
      } catch (e: CancellationException) {
        throw e
      } catch (e: WearException) {
        callback.error(e.errorCode, e.message ?: e.errorCode)
      } catch (e: Throwable) {
        callback.error("ERR_UNKNOWN", e.message ?: e.javaClass.simpleName)
      }
    }
  }

  override fun disconnect() {
    link.disconnect()
  }

  override fun sync(fullHistory: Boolean, callback: ProtocolGateway.Callback) {
    scope.launch {
      try {
        val summary = link.syncActivity(fullHistory)
        callback.ok(toJson(summary.toJs()) as JSONObject)
      } catch (e: CancellationException) {
        throw e
      } catch (e: WearException) {
        callback.error(e.errorCode, e.message ?: e.errorCode)
      } catch (e: Throwable) {
        callback.error("ERR_UNKNOWN", e.message ?: e.javaClass.simpleName)
      }
    }
  }

  override fun setHuaweiAccount(account: String) {
    val clean = account.trim()
    require(clean.isEmpty() || ACCOUNT_ID.matches(clean)) { "ID akun Huawei harus 17-19 angka" }
    settings.huaweiAccount = clean
    addLog(if (clean.isEmpty()) "ID akun Huawei dihapus" else "ID akun Huawei disimpan (…${clean.takeLast(4)})")
  }

  override fun huaweiAccountInfo(): JSONObject {
    val id = settings.huaweiAccount
    return JSONObject().put("set", id.isNotEmpty()).put("hint", if (id.isEmpty()) JSONObject.NULL else id.takeLast(4))
  }

  override fun setHrZones(json: String, callback: ProtocolGateway.Callback) {
    val clean = json.trim()
    if (clean.isNotEmpty()) {
      val parsed = HeartRateZonesSync.parseCustom(clean)
      val problem = if (parsed == null) "zona HR tidak terbaca" else parsed.error()
      if (problem != null) {
        callback.error("BAD_ZONES", problem)
        return
      }
    }
    settings.customHrZones = if (clean.isEmpty()) null else clean
    addLog(if (clean.isEmpty()) "Zona HR kembali ke bawaan" else "Zona HR dari app disimpan")
    scope.launch {
      try {
        var sent = link.sendHeartRateZones()
        // Jam jalur track menerima zona lewat P2P, bukan FitnessData: kirim ulang lewat tumpukan P2P yang terpasang di sesi ini.
        if (sent["sent"] != true && sent["branch"] == "track" && track.resend()) sent = sent + ("sent" to true)
        callback.ok(toJson(sent + ("saved" to true)) as JSONObject)
      } catch (e: CancellationException) {
        throw e
      } catch (e: WearException) {
        if (e.errorCode == ErrorCodes.NOT_CONNECTED) {
          callback.ok(JSONObject().put("saved", true).put("connected", false).put("sent", false))
        } else {
          callback.error(e.errorCode, e.message ?: e.errorCode)
        }
      } catch (e: Throwable) {
        callback.error("ERR_UNKNOWN", e.message ?: e.javaClass.simpleName)
      }
    }
  }

  override fun hrZonesInfo(): JSONObject {
    val c = HeartRateZonesSync.parseCustom(settings.customHrZones)
    val ok = c != null && c.error() == null
    val connected = lastState == LinkState.CONNECTED || lastState == LinkState.SYNCING
    return JSONObject()
      .put("saved", ok)
      .put("method", if (ok) c!!.method.name.lowercase() else JSONObject.NULL)
      .put("lower", if (ok) JSONArray(c!!.lower) else JSONObject.NULL)
      .put("connected", connected)
      .put("branch", if (connected) HeartRateZonesSync.branch() else JSONObject.NULL)
  }

  override fun pushCourses(json: String, callback: ProtocolGateway.Callback) {
    val list = try {
      courses.parse(json)
    } catch (e: WearException) {
      callback.error(e.errorCode, e.message ?: e.errorCode)
      return
    }
    addLog("Kursus: mengirim ${list.size} sesi ke jam")
    scope.launch {
      try {
        callback.ok(courses.pushAll(list))
      } catch (e: CancellationException) {
        throw e
      } catch (e: WearException) {
        callback.error(e.errorCode, e.message ?: e.errorCode)
      } catch (e: Throwable) {
        callback.error("ERR_UNKNOWN", e.message ?: e.javaClass.simpleName)
      }
    }
  }

  override fun pushRoute(json: String, callback: ProtocolGateway.Callback) {
    val spec = try {
      routes.parse(json)
    } catch (e: WearException) {
      callback.error(e.errorCode, e.message ?: e.errorCode)
      return
    }
    addLog("Rute: mengirim '${spec.name}' (${spec.points.size} titik) ke jam")
    scope.launch {
      try {
        callback.ok(routes.push(spec))
      } catch (e: CancellationException) {
        throw e
      } catch (e: WearException) {
        callback.error(e.errorCode, e.message ?: e.errorCode)
      } catch (e: Throwable) {
        callback.error("ERR_UNKNOWN", e.message ?: e.javaClass.simpleName)
      }
    }
  }

  override fun setLiveHeartRate(active: Boolean) = liveHr.setActive(active)

  override fun liveHeartRate(): JSONObject = liveHr.status()

  override fun setWeather(json: String, callback: ProtocolGateway.Callback) {
    val o = try {
      JSONObject(json.ifBlank { "{}" })
    } catch (e: Exception) {
      callback.error(ErrorCodes.INVALID_ARGUMENT, "Pengaturan cuaca tidak terbaca")
      return
    }
    try {
      if (o.has("lat") && o.has("lon") && !o.isNull("lat") && !o.isNull("lon")) {
        val lat = o.getDouble("lat")
        val lon = o.getDouble("lon")
        require(lat in -90.0..90.0 && lon in -180.0..180.0) { "Koordinat cuaca tidak valid" }
        weatherSettings.city = WeatherPlace(o.optString("name", "").trim().ifEmpty { null }, lat, lon, null)
        weatherSettings.locationMode = WeatherLocationMode.CITY
      }
      if (o.has("unit")) {
        weatherSettings.unit = TemperatureUnit.fromWire(o.getString("unit")) ?: throw IllegalArgumentException("Satuan suhu harus celsius atau fahrenheit")
      }
      if (o.has("intervalMinutes")) {
        val minutes = o.getInt("intervalMinutes")
        require(minutes in WeatherSettings.MIN_INTERVAL_MIN..WeatherSettings.MAX_INTERVAL_MIN) {
          "Interval cuaca harus ${WeatherSettings.MIN_INTERVAL_MIN} sampai ${WeatherSettings.MAX_INTERVAL_MIN} menit"
        }
        weatherSettings.intervalMinutes = minutes
      }
      if (o.has("enabled")) weatherSettings.enabled = o.getBoolean("enabled")
    } catch (e: IllegalArgumentException) {
      callback.error(ErrorCodes.INVALID_ARGUMENT, e.message ?: "Pengaturan cuaca salah")
      return
    } catch (e: org.json.JSONException) {
      callback.error(ErrorCodes.INVALID_ARGUMENT, "Pengaturan cuaca salah: ${e.message}")
      return
    }
    addLog("Cuaca ke jam: ${if (weatherSettings.enabled) "aktif" else "mati"}")
    // Satu kali: kosongkan cache, kirim sekarang bila jam terhubung (atau hentikan pewaktu bila dimatikan).
    weather.onSettingsChanged()
    callback.ok(weatherStatus())
  }

  override fun setAgps(json: String, callback: ProtocolGateway.Callback) {
    val o = try {
      JSONObject(json.ifBlank { "{}" })
    } catch (e: Exception) {
      callback.error(ErrorCodes.INVALID_ARGUMENT, "Pengaturan A-GPS tidak terbaca")
      return
    }
    val wasOn = agpsConfig.enabled
    try {
      if (o.has("mirrorUrl")) {
        val url = o.optString("mirrorUrl", "").trim()
        require(url.isEmpty() || (url.startsWith("https://") && url.length <= 300 && !url.any { it.isWhitespace() })) {
          "Alamat server harus diawali https:// dan tanpa spasi"
        }
        agpsConfig.mirrorUrl = url
      }
      if (o.has("enabled")) agpsConfig.enabled = o.getBoolean("enabled")
    } catch (e: IllegalArgumentException) {
      callback.error(ErrorCodes.INVALID_ARGUMENT, e.message ?: "Pengaturan A-GPS salah")
      return
    } catch (e: org.json.JSONException) {
      callback.error(ErrorCodes.INVALID_ARGUMENT, "Pengaturan A-GPS salah: ${e.message}")
      return
    }
    agpsConfig.apply()
    if (agpsConfig.enabled != wasOn) {
      try {
        agps.onLinkState(if (agpsConfig.enabled) lastState else LinkState.DISCONNECTED)
      } catch (e: Exception) {
        addLog("A-GPS gagal: ${e.message ?: e.javaClass.simpleName}")
      }
    }
    addLog("A-GPS ke jam: ${if (agpsConfig.enabled) "aktif" else "mati"}, ${if (agpsConfig.mirrorUrl.isBlank()) "langsung ke Broadcom" else "lewat server sendiri"}")
    callback.ok(agpsStatus())
  }

  override fun agpsStatus(): JSONObject = JSONObject()
    .put("enabled", agpsConfig.enabled)
    .put("mirrorUrl", agpsConfig.mirrorUrl)
    .put("lastOkAt", AgpsSource.lastOkAtMs)
    .put("lastBytes", AgpsSource.lastBytes)
    .put("lastFrom", AgpsSource.lastFrom ?: JSONObject.NULL)
    .put("lastError", AgpsSource.lastError ?: JSONObject.NULL)
    .put("lastDoneAt", AgpsSource.lastDoneAtMs)
    .put("lastDoneResult", AgpsSource.lastDoneResult ?: JSONObject.NULL)

  /** Coba unduh sekarang tanpa cache dan tanpa jam: mirror dulu, lalu Broadcom bila mirror gagal. */
  override fun testAgps(callback: ProtocolGateway.Callback) {
    scope.launch(Dispatchers.IO) {
      val results = JSONArray()
      var ok = false
      var firstError: String? = null
      for (url in AgpsSource.candidates()) {
        val isBroadcom = url == AgpsSource.broadcomUrl
        val row = JSONObject().put("source", if (isBroadcom) "broadcom" else "mirror")
        val started = System.currentTimeMillis()
        try {
          val body = EphemerisNet.get(url)
          if (body.isEmpty()) throw AgpsFetchException("empty response")
          if (body[0] == '<'.code.toByte()) throw AgpsFetchException("response is not an LTO file")
          row.put("ok", true).put("bytes", body.size)
          ok = true
          AgpsSource.lastOkAtMs = System.currentTimeMillis()
          AgpsSource.lastBytes = body.size
          AgpsSource.lastFrom = if (isBroadcom) "broadcom" else "mirror"
        } catch (e: CancellationException) {
          throw e
        } catch (e: Exception) {
          row.put("ok", false).put("error", e.message ?: e.javaClass.simpleName)
          if (firstError == null) firstError = "${if (isBroadcom) "LTO" else "LTO mirror"}: ${e.message ?: e.javaClass.simpleName}"
        }
        row.put("ms", System.currentTimeMillis() - started)
        results.put(row)
        if (ok) break
      }
      // Simpan hasil uji ke status supaya agpsStatus() tetap lengkap (enabled, mirrorUrl, dst.).
      AgpsSource.lastError = firstError
      callback.ok(JSONObject().put("ok", ok).put("results", results))
    }
  }

  override fun weatherStatus(): JSONObject = toJson(weather.status()) as JSONObject

  override fun refreshWeather(callback: ProtocolGateway.Callback) {
    scope.launch {
      try {
        callback.ok(toJson(weather.refreshNow()) as JSONObject)
      } catch (e: CancellationException) {
        throw e
      } catch (e: WearException) {
        callback.error(e.errorCode, e.message ?: e.errorCode)
      } catch (e: Throwable) {
        callback.error("ERR_UNKNOWN", e.message ?: e.javaClass.simpleName)
      }
    }
  }

  override fun forget(address: String) {
    link.forget(address)
  }

  override fun readDaily(sinceSec: Long, tzOffsetMin: Int): JSONObject = syncStore.read { db ->
    // Offset zona waktu disisipkan sebagai bilangan bulat (Int dari JS), bukan teks: tidak ada injeksi SQL.
    val off = tzOffsetMin * 60
    val days = JSONArray()
    db.rawQuery(
      """SELECT date(timestamp + $off, 'unixepoch') AS d,
                SUM(steps), SUM(calories), SUM(distance),
                AVG(CASE WHEN resting_heart_rate > 0 THEN resting_heart_rate END),
                MIN(CASE WHEN resting_heart_rate > 0 THEN resting_heart_rate END),
                COUNT(CASE WHEN resting_heart_rate > 0 THEN 1 END),
                MAX(CASE WHEN resting_heart_rate > 0 THEN timestamp END),
                AVG(CASE WHEN heart_rate BETWEEN 30 AND 230 THEN heart_rate END),
                MIN(CASE WHEN heart_rate BETWEEN 30 AND 230 THEN heart_rate END),
                MAX(CASE WHEN heart_rate BETWEEN 30 AND 230 THEN heart_rate END),
                COUNT(CASE WHEN heart_rate BETWEEN 30 AND 230 THEN 1 END),
                AVG(CASE WHEN spo2 BETWEEN 70 AND 100 THEN spo2 END),
                MIN(CASE WHEN spo2 BETWEEN 70 AND 100 THEN spo2 END),
                COUNT(CASE WHEN spo2 BETWEEN 70 AND 100 THEN 1 END),
                MAX(CASE WHEN spo2 BETWEEN 70 AND 100 THEN spo2 END)
           FROM step_samples WHERE timestamp >= ? GROUP BY d ORDER BY d""",
      arrayOf(sinceSec.toString()),
    ).use { c ->
      while (c.moveToNext()) {
        val row = JSONObject()
        row.put("day", c.getString(0))
        row.put("steps", c.getLong(1))
        row.put("calories", c.getLong(2)) // kalori kecil (cal), bagi 1000 untuk kkal
        row.put("distance", c.getLong(3))
        row.put("rhrAvg", if (c.isNull(4)) JSONObject.NULL else c.getDouble(4))
        row.put("rhrMin", if (c.isNull(5)) JSONObject.NULL else c.getInt(5))
        row.put("rhrN", c.getInt(6))
        // HR istirahat terbaru hari itu (yang jam laporkan paling akhir), bukan rata-rata sepanjang hari.
        var last: Any = JSONObject.NULL
        if (!c.isNull(7)) {
          db.rawQuery("SELECT resting_heart_rate FROM step_samples WHERE timestamp = ?", arrayOf(c.getLong(7).toString())).use { q ->
            if (q.moveToFirst() && !q.isNull(0)) last = q.getInt(0)
          }
        }
        row.put("rhrLast", last)
        // Ringkasan HR dan SpO2 harian untuk panel rinci (rentang, rata-rata); null bila tak ada sampel.
        row.put("hrAvg", if (c.isNull(8)) JSONObject.NULL else c.getDouble(8))
        row.put("hrMin", if (c.isNull(9)) JSONObject.NULL else c.getInt(9))
        row.put("hrMax", if (c.isNull(10)) JSONObject.NULL else c.getInt(10))
        row.put("hrN", c.getInt(11))
        row.put("spo2Avg", if (c.isNull(12)) JSONObject.NULL else c.getDouble(12))
        row.put("spo2Min", if (c.isNull(13)) JSONObject.NULL else c.getInt(13))
        row.put("spo2N", c.getInt(14))
        row.put("spo2Max", if (c.isNull(15)) JSONObject.NULL else c.getInt(15))
        days.put(row)
      }
    }
    val sleep = JSONArray()
    db.rawQuery(
      "SELECT start, end, type, stage FROM sleep_segments WHERE end >= ? ORDER BY start",
      arrayOf(sinceSec.toString()),
    ).use { c ->
      while (c.moveToNext()) {
        val row = JSONObject()
        row.put("start", c.getLong(0))
        row.put("end", c.getLong(1))
        row.put("type", c.getInt(2))
        row.put("stage", if (c.isNull(3)) JSONObject.NULL else c.getString(3))
        sleep.put(row)
      }
    }
    // Workout windows (widened by 2 min) are cut out of the sleep records, exactly like the legacy readWatchWorkouts -> hwBusyOf path.
    val workoutRows = JSONArray()
    try {
      db.rawQuery("SELECT start, end, duration FROM workouts WHERE start >= ?", arrayOf((sinceSec - 86400L).toString())).use { c ->
        while (c.moveToNext()) workoutRows.put(JSONObject().put("start", c.getLong(0)).put("end", c.getLong(1)).put("duration", c.getInt(2)))
      }
    } catch (e: Exception) {
      // Tabel workout belum ada: tidur tetap diproses tanpa pemotongan jam latihan.
    }
    val busy = HuaweiSleepParity.busyOf(workoutRows)
    val busyJson = JSONArray()
    busy.forEach { busyJson.put(JSONObject().put("s", it.start).put("e", it.end)) }

    // Sleep HR uses exactly the selected main-night window (fragments, naps and secondary sessions excluded).
    // `off` is already in seconds: the zone must be built from it directly (it used to be multiplied by 60 again,
    // which threw and silently fell back to UTC, shifting the night/day split by the local UTC offset).
    val sleepHr = JSONArray()
    val watchZone = runCatching { ZoneOffset.ofTotalSeconds(off) }.getOrDefault(ZoneOffset.UTC)
    HuaweiSleepParity.parse(sleep, watchZone, busy).forEach { night ->
      db.rawQuery(
        "SELECT AVG(heart_rate), COUNT(heart_rate) FROM step_samples WHERE timestamp >= ? AND timestamp <= ? AND heart_rate BETWEEN 30 AND 230",
        arrayOf(night.start.toString(), night.end.toString()),
      ).use { q ->
        if (q.moveToFirst() && !q.isNull(0) && q.getInt(1) >= 10) {
          sleepHr.put(JSONObject().put("day", night.date).put("avg", q.getDouble(0)).put("n", q.getInt(1)))
        }
      }
    }

    // Batas malam menurut jam sendiri (mulai tidur dan bangun), dipakai untuk memisahkan malam dari tidur siang/sore.
    val scores = JSONArray()
    // avgSpo2 (%) dan avgResp (napas per menit) = "Avg SpO2" dan "Avg respiratory rate" di layar Sleep health jam; null bila jam tak mengirimnya.
    db.rawQuery("SELECT start, end, score, efficiency, avg_spo2, avg_resp FROM sleep_scores WHERE end >= ? ORDER BY start", arrayOf(sinceSec.toString())).use { c ->
      while (c.moveToNext()) {
        scores.put(
          JSONObject().put("start", c.getLong(0)).put("end", c.getLong(1)).put("score", c.getInt(2))
            .put("efficiency", if (c.isNull(3)) JSONObject.NULL else c.getInt(3))
            .put("avgSpo2", if (c.isNull(4)) JSONObject.NULL else c.getInt(4))
            .put("avgResp", if (c.isNull(5)) JSONObject.NULL else c.getInt(5)),
        )
      }
    }
    // HRV malam (RMSSD rata-rata selama tidur) dari catatan stres otomatis jam; diisi NightHrvSync saat sinkron. Kosong bila jam tak menyimpannya.
    val hrv = JSONArray()
    try {
      db.rawQuery(
        "SELECT start, end, rmssd FROM hrv_readings h WHERE rmssd IS NOT NULL AND end >= ? AND (source = 'watch' OR (source = 'night' AND NOT EXISTS (SELECT 1 FROM hrv_readings w WHERE w.source = 'watch' AND w.start <= h.end AND w.end >= h.start))) ORDER BY end",
        arrayOf(sinceSec.toString()),
      ).use { c ->
        while (c.moveToNext()) {
          hrv.put(JSONObject().put("start", c.getLong(0)).put("end", c.getLong(1)).put("rmssd", c.getDouble(2)))
        }
      }
    } catch (e: Exception) {
      // Tabel belum ada di basis data lama: HRV dibiarkan kosong, data lain tetap terbaca.
    }
    JSONObject().put("days", days).put("sleep", sleep).put("sleepScores", scores).put("sleepHr", sleepHr).put("hrv", hrv).put("busy", busyJson)
  }

  override fun readHrWindow(startSec: Long, endSec: Long): JSONObject = syncStore.read { db ->
    db.rawQuery(
      """SELECT AVG(heart_rate), MIN(heart_rate), COUNT(heart_rate)
           FROM step_samples WHERE timestamp >= ? AND timestamp <= ? AND heart_rate > 0""",
      arrayOf(startSec.toString(), endSec.toString()),
    ).use { c ->
      c.moveToFirst()
      JSONObject()
        .put("avg", if (c.isNull(0)) JSONObject.NULL else c.getDouble(0))
        .put("min", if (c.isNull(1)) JSONObject.NULL else c.getInt(1))
        .put("n", c.getInt(2))
    }
  }

  override fun readLive(startSec: Long, endSec: Long, bucketSec: Int): JSONObject = syncStore.read { db ->
    // Semua angka disisipkan sebagai Long/Int dari JS (bukan teks): tidak ada injeksi SQL.
    val bucket = bucketSec.coerceIn(60, 3600)
    val out = JSONObject()
    db.rawQuery(
      """SELECT SUM(steps), SUM(calories), SUM(distance),
                AVG(CASE WHEN heart_rate BETWEEN 30 AND 230 THEN heart_rate END),
                MIN(CASE WHEN heart_rate BETWEEN 30 AND 230 THEN heart_rate END),
                MAX(CASE WHEN heart_rate BETWEEN 30 AND 230 THEN heart_rate END),
                COUNT(CASE WHEN heart_rate BETWEEN 30 AND 230 THEN 1 END),
                AVG(CASE WHEN spo2 BETWEEN 70 AND 100 THEN spo2 END),
                MIN(CASE WHEN spo2 BETWEEN 70 AND 100 THEN spo2 END),
                COUNT(CASE WHEN spo2 BETWEEN 70 AND 100 THEN 1 END),
                MAX(timestamp),
                MAX(CASE WHEN spo2 BETWEEN 70 AND 100 THEN spo2 END)
           FROM step_samples WHERE timestamp >= $startSec AND timestamp <= $endSec""",
      null,
    ).use { c ->
      val today = JSONObject()
      if (c.moveToFirst()) {
        today.put("steps", c.getLong(0))
        today.put("calories", c.getLong(1)) // kalori kecil (cal), bagi 1000 untuk kkal
        today.put("distance", c.getLong(2))
        today.put("hrAvg", if (c.isNull(3)) JSONObject.NULL else c.getDouble(3))
        today.put("hrMin", if (c.isNull(4)) JSONObject.NULL else c.getInt(4))
        today.put("hrMax", if (c.isNull(5)) JSONObject.NULL else c.getInt(5))
        today.put("hrN", c.getInt(6))
        today.put("spo2Avg", if (c.isNull(7)) JSONObject.NULL else c.getDouble(7))
        today.put("spo2Min", if (c.isNull(8)) JSONObject.NULL else c.getInt(8))
        today.put("spo2N", c.getInt(9))
        today.put("lastTs", if (c.isNull(10)) JSONObject.NULL else c.getLong(10))
        today.put("spo2Max", if (c.isNull(11)) JSONObject.NULL else c.getInt(11))
      }
      out.put("today", today)
    }
    // Sampel terbaru (tanpa batas hari): HR dan SpO2 terakhir yang benar-benar terukur.
    val latest = JSONObject()
    db.rawQuery(
      "SELECT timestamp, heart_rate FROM step_samples WHERE heart_rate BETWEEN 30 AND 230 ORDER BY timestamp DESC LIMIT 1", null,
    ).use { c -> if (c.moveToFirst()) { latest.put("hrTs", c.getLong(0)); latest.put("hr", c.getInt(1)) } }
    db.rawQuery(
      "SELECT timestamp, spo2 FROM step_samples WHERE spo2 BETWEEN 70 AND 100 ORDER BY timestamp DESC LIMIT 1", null,
    ).use { c -> if (c.moveToFirst()) { latest.put("spo2Ts", c.getLong(0)); latest.put("spo2", c.getInt(1)) } }
    db.rawQuery("SELECT MAX(timestamp) FROM step_samples", null).use { c ->
      if (c.moveToFirst() && !c.isNull(0)) latest.put("sampleTs", c.getLong(0))
    }
    out.put("latest", latest)
    // Total harian resmi dari jam (hasil FitnessTotals saat sinkron); kalori kkal, jarak meter.
    db.rawQuery("SELECT steps, calories, distance, updated_at FROM day_totals WHERE midnight = $startSec", null).use { c ->
      if (c.moveToFirst()) {
        out.put(
          "totals",
          JSONObject().put("steps", c.getLong(0)).put("calories", c.getLong(1)).put("distance", c.getLong(2)).put("updatedAt", c.getLong(3)),
        )
      }
    }
    val series = JSONArray()
    db.rawQuery(
      """SELECT (timestamp - $startSec) / $bucket AS b,
                AVG(CASE WHEN heart_rate BETWEEN 30 AND 230 THEN heart_rate END),
                MIN(CASE WHEN heart_rate BETWEEN 30 AND 230 THEN heart_rate END),
                MAX(CASE WHEN heart_rate BETWEEN 30 AND 230 THEN heart_rate END),
                SUM(steps),
                SUM(calories),
                SUM(distance),
                AVG(CASE WHEN spo2 BETWEEN 70 AND 100 THEN spo2 END),
                MIN(CASE WHEN spo2 BETWEEN 70 AND 100 THEN spo2 END)
           FROM step_samples WHERE timestamp >= $startSec AND timestamp <= $endSec GROUP BY b ORDER BY b""",
      null,
    ).use { c ->
      while (c.moveToNext()) {
        val row = JSONObject()
        row.put("t", startSec + c.getLong(0) * bucket)
        row.put("hr", if (c.isNull(1)) JSONObject.NULL else c.getDouble(1))
        row.put("hrMin", if (c.isNull(2)) JSONObject.NULL else c.getInt(2))
        row.put("hrMax", if (c.isNull(3)) JSONObject.NULL else c.getInt(3))
        row.put("steps", c.getLong(4))
        row.put("cal", c.getLong(5)) // kalori kecil (cal), bagi 1000 untuk kkal
        row.put("dist", c.getLong(6))
        row.put("spo2", if (c.isNull(7)) JSONObject.NULL else c.getDouble(7))
        row.put("spo2Min", if (c.isNull(8)) JSONObject.NULL else c.getInt(8))
        series.put(row)
      }
    }
    out.put("series", series).put("bucketSec", bucket)
  }

  override fun readWorkouts(sinceSec: Long, limit: Int): JSONObject = syncStore.read { db ->
    val list = JSONArray()
    db.rawQuery(
      """SELECT w.start, w.end, w.sport_type, w.sport_name, w.duration, w.distance, w.calories, w.avg_hr, w.max_hr,
                w.steps, w.complete,
                (SELECT COUNT(*) FROM workout_points p WHERE p.workout_id = w.id AND p.lat IS NOT NULL),
                w.summary_json
           FROM workouts w WHERE w.start >= ? ORDER BY w.start DESC LIMIT ?""",
      arrayOf(sinceSec.toString(), limit.coerceIn(1, 100).toString()),
    ).use { c ->
      while (c.moveToNext()) {
        val row = JSONObject()
        row.put("start", c.getLong(0))
        row.put("end", c.getLong(1))
        row.put("sportType", c.getInt(2))
        row.put("sportName", c.getString(3))
        row.put("duration", c.getInt(4)) // detik
        row.put("distance", c.getInt(5)) // meter
        row.put("calories", c.getInt(6))
        row.put("avgHr", if (c.isNull(7)) JSONObject.NULL else c.getInt(7))
        row.put("maxHr", if (c.isNull(8)) JSONObject.NULL else c.getInt(8))
        row.put("steps", c.getInt(9))
        row.put("complete", c.getInt(10) == 1)
        row.put("gpsPoints", c.getInt(11))
        // Recovery dari jam (jam dan deret HR pasca-latihan) ada di summary_json; gagal baca tidak menggagalkan daftar.
        try {
          if (!c.isNull(12)) {
            val sj = JSONObject(c.getString(12))
            if (sj.has("recoveryHours")) row.put("recoveryHours", sj.getDouble("recoveryHours"))
            // Rata-rata kadens dari sampel jam (lari/sepeda: avgCadence; jalan dengan algoritma langkah baru: avgStepRate).
            sj.optJSONObject("samples")?.let { smp ->
              val cad = if (smp.has("avgCadence")) smp.getDouble("avgCadence") else if (smp.has("avgStepRate")) smp.getDouble("avgStepRate") else null
              if (cad != null) row.put("avgCadence", cad)
            }
            sj.optJSONObject("sampleFields")?.let { row.put("sampleFields", it) }
            // Blok dari jam (per km, atau per lap/interval); nomor, waktu, jarak, pace, HR, kadens, dan jenis interval diteruskan.
            sj.optJSONArray("sections")?.let { arr ->
              val secs = JSONArray()
              for (i in 0 until arr.length()) {
                val b = arr.optJSONObject(i) ?: continue
                secs.put(
                  JSONObject().put("num", b.optInt("num", -1)).put("time", b.optLong("time", -1L)).put("distance", b.optLong("distance", -1L))
                    .put("pace", b.optInt("pace", -1)).put("heartRate", b.optInt("heartRate", -1)).put("cadence", b.optInt("cadence", -1))
                    .put("intervalTrainingType", b.optInt("intervalTrainingType", -1)),
                )
              }
              if (secs.length() > 0) row.put("sections", secs)
            }
            sj.optJSONArray("recoveryHeartRates")?.let { row.put("recoveryHr", it) }
            // Ringkasan elevasi resmi dari jam (meter); dipakai sebagai cadangan D+/D− bila rute tidak punya altitude.
            for (key in listOf("elevationGain", "elevationLoss", "minAltitude", "maxAltitude", "avgAltitude")) {
              if (sj.has(key)) row.put(key, sj.getDouble(key))
            }
            for (key in listOf("elevationGainSource", "elevationLossSource")) {
              if (sj.has(key)) row.put(key, sj.getString(key))
            }
            if (sj.has("workoutLoad")) row.put("workoutLoad", sj.getInt("workoutLoad"))
            if (sj.has("aerobicEffect")) row.put("aerobicEffect", sj.getDouble("aerobicEffect"))
            if (sj.has("anaerobicEffect")) row.put("anaerobicEffect", sj.getDouble("anaerobicEffect"))
          }
        } catch (_: Exception) {
        }
        list.put(row)
      }
    }
    JSONObject().put("workouts", list)
  }

  /**
   * Menandai lari/sepeda luar ruang tanpa titik GPS sejak [sinceSec] sebagai belum lengkap, supaya sinkron berikutnya
   * mengunduh ulang berkas GPS-nya dari jam (WorkoutStore.syncStart mulai dari workout belum lengkap tertua).
   */
  override fun markWorkoutsForGpsRedownload(sinceSec: Long): JSONObject = syncStore.read { db ->
    val stmt = db.compileStatement(
      """UPDATE workouts SET complete = 0
           WHERE start >= ? AND imported = 0 AND sport_type IN (1, 2, 3, 4, 8, 11, 14)
             AND id NOT IN (SELECT DISTINCT workout_id FROM workout_points WHERE lat IS NOT NULL)""",
    )
    val n = try {
      stmt.bindLong(1, sinceSec)
      stmt.executeUpdateDelete()
    } finally {
      stmt.close()
    }
    JSONObject().put("marked", n)
  }

  override fun readWorkoutPoints(startSec: Long): JSONObject = syncStore.read { db ->
    val points = JSONArray()
    db.rawQuery(
      """SELECT p.ts, p.lat, p.lon, p.alt, p.hr, p.cad FROM workout_points p
           JOIN workouts w ON w.id = p.workout_id WHERE w.start = CAST(? AS INTEGER) ORDER BY p.ts""",
      arrayOf(startSec.toString()),
    ).use { c ->
      while (c.moveToNext()) {
        val row = JSONObject()
        row.put("ts", c.getLong(0))
        row.put("lat", if (c.isNull(1)) JSONObject.NULL else c.getDouble(1))
        row.put("lon", if (c.isNull(2)) JSONObject.NULL else c.getDouble(2))
        row.put("alt", if (c.isNull(3)) JSONObject.NULL else c.getDouble(3))
        row.put("hr", if (c.isNull(4)) JSONObject.NULL else c.getInt(4))
        row.put("cad", if (c.isNull(5)) JSONObject.NULL else c.getInt(5))
        points.put(row)
      }
    }
    addLog("INFO readWorkoutPoints start=$startSec rows=${points.length()}")
    JSONObject().put("points", points)
  }

  /** Info jam untuk JS: tanpa alamat Bluetooth dan nomor seri (tidak perlu tampil, tidak boleh bocor ke log atau cadangan). */
  private fun publicInfo(info: Map<String, Any?>?): JSONObject? {
    if (info == null) return null
    val copy = HashMap(info)
    copy.remove("address")
    copy.remove("serialNumber")
    return toJson(copy) as JSONObject
  }

  private fun toJson(value: Any?): Any? = when (value) {
    null -> JSONObject.NULL
    is Map<*, *> -> JSONObject().also { o -> value.forEach { (k, v) -> o.put(k.toString(), toJson(v)) } }
    is Iterable<*> -> JSONArray().also { a -> value.forEach { a.put(toJson(it)) } }
    is Number, is Boolean, is String -> value
    else -> value.toString()
  }


  // ---- Notifikasi ponsel ke jam ----

  override fun notifyStatus(): JSONObject {
    val o = JSONObject()
    val handle = link.handle()
    o.put("enabled", settings.notificationsEnabled)
    o.put("connected", handle != null)
    o.put("supported", if (handle == null) JSONObject.NULL else handle.notificationState.supportsNotificationAlert)
    o.put("quietEnabled", notifySettings.quietEnabled)
    o.put("quietStart", notifySettings.quietStartMin)
    o.put("quietEnd", notifySettings.quietEndMin)
    o.put("onlyScreenOff", notifySettings.onlyScreenOff)
    o.put("lastResult", notifier.lastResult ?: JSONObject.NULL)
    o.put("lastPackage", notifier.lastPackage ?: JSONObject.NULL)
    o.put("lastAt", if (notifier.lastAtMs > 0L) notifier.lastAtMs / 1000 else JSONObject.NULL)
    o.put("sentCount", notifier.sentCount)
    o.put("lastError", notifier.lastError ?: JSONObject.NULL)
    val apps = JSONArray()
    val seen = LinkedHashMap<String, String>()
    KNOWN_APPS.forEach { (pkg, label) -> seen[pkg] = label }
    notifySettings.seenApps().forEach { (pkg, label) -> if (!seen.containsKey(pkg)) seen[pkg] = label }
    seen.forEach { (pkg, label) ->
      val choice = settings.appChoice(pkg)
      apps.put(JSONObject().put("pkg", pkg).put("label", label).put("on", choice ?: notifier.defaultAllowed(pkg)).put("explicit", choice != null))
    }
    o.put("apps", apps)
    return o
  }

  override fun setNotify(json: String, callback: ProtocolGateway.Callback) {
    val o = try {
      JSONObject(json.ifBlank { "{}" })
    } catch (e: Exception) {
      callback.error(ErrorCodes.INVALID_ARGUMENT, "Pengaturan notifikasi tidak terbaca")
      return
    }
    try {
      if (o.has("quietStart")) notifySettings.quietStartMin = o.getInt("quietStart")
      if (o.has("quietEnd")) notifySettings.quietEndMin = o.getInt("quietEnd")
      if (o.has("quietEnabled")) notifySettings.quietEnabled = o.getBoolean("quietEnabled")
      if (o.has("onlyScreenOff")) notifySettings.onlyScreenOff = o.getBoolean("onlyScreenOff")
      val apps = o.optJSONObject("apps")
      if (apps != null) {
        val keys = apps.keys()
        while (keys.hasNext()) {
          val pkg = keys.next()
          require(pkg.length in 3..200 && pkg.all { c -> c.isLetterOrDigit() || c == '.' || c == '_' }) { "Nama paket tidak valid" }
          settings.setAppChoice(pkg, apps.getBoolean(pkg))
        }
      }
      if (o.has("enabled")) {
        val on = o.getBoolean("enabled")
        val changed = on != settings.notificationsEnabled
        settings.notificationsEnabled = on
        // Saklar di sisi jam diikuti sekarang bila terhubung; bila tidak, ia dikirim saat inisialisasi tautan berikutnya.
        if (changed) scope.launch { notifier.applySwitch(on) }
        addLog("Notifikasi ke jam: ${if (on) "aktif" else "mati"}")
      }
    } catch (e: IllegalArgumentException) {
      callback.error(ErrorCodes.INVALID_ARGUMENT, e.message ?: "Pengaturan notifikasi salah")
      return
    } catch (e: org.json.JSONException) {
      callback.error(ErrorCodes.INVALID_ARGUMENT, "Pengaturan notifikasi salah: ${e.message}")
      return
    }
    callback.ok(notifyStatus())
  }

  override fun testNotify(callback: ProtocolGateway.Callback) {
    scope.launch {
      try {
        val r = notifier.sendTest("TrainingPlan")
        callback.ok(notifyStatus().put("result", r.wire))
      } catch (e: CancellationException) {
        throw e
      } catch (e: Throwable) {
        callback.error(ErrorCodes.INVALID_ARGUMENT, e.message ?: e.javaClass.simpleName)
      }
    }
  }

  override fun forwardNotification(
    packageName: String,
    appLabel: String,
    key: String,
    id: Int,
    channelId: String,
    title: String,
    text: String,
    postedAtMs: Long,
    screenOn: Boolean,
  ) {
    if (!settings.notificationsEnabled) return
    try {
      notifySettings.noteSeenApp(packageName, appLabel)
    } catch (_: Throwable) {
    }
    scope.launch {
      notifier.forward(PhoneNotification(packageName, appLabel, key, id, channelId, title, text, postedAtMs, screenOn))
    }
  }

  companion object {
    private const val MAX_LOG_LINES = 400
    private val KNOWN_APPS = linkedMapOf(
      "com.whatsapp" to "WhatsApp",
      "com.whatsapp.w4b" to "WhatsApp Business",
      "org.telegram.messenger" to "Telegram",
      "org.thoughtcrime.securesms" to "Signal",
      "com.google.android.apps.messaging" to "Google Messages",
      "com.samsung.android.messaging" to "Samsung Messages",
      "com.google.android.gm" to "Gmail",
      "com.microsoft.office.outlook" to "Outlook",
    )
    /** Gadgetbridge menerima 17 sampai 19 angka (commit dba6e899fe memperpanjang dari 17). */
    private val ACCOUNT_ID = Regex("[0-9]{17,19}")
    private val MAC = Regex("(?i)(?:[0-9a-f]{2}[:-]){5}[0-9a-f]{2}")

    @Volatile
    private var instance: ProtocolBridge? = null

    /** Dipanggil lewat refleksi oleh HuaweiWatchPlugin; aman dipanggil berulang. */
    @JvmStatic
    fun get(context: Context): ProtocolBridge =
      instance ?: synchronized(this) {
        instance ?: ProtocolBridge(context).also { instance = it }
      }
  }
}
