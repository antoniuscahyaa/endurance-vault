package com.rencanalari.huaweiwatch

import com.joyodigitama.huaweiwear.DeviceCaps
import com.joyodigitama.huaweiwear.ErrorCodes
import com.joyodigitama.huaweiwear.HeartRateZonesCalc
import com.joyodigitama.huaweiwear.HeartRateZonesSync
import com.joyodigitama.huaweiwear.HuaweiSession
import com.joyodigitama.huaweiwear.LinkState
import com.joyodigitama.huaweiwear.LogDirection
import com.joyodigitama.huaweiwear.TrackService
import com.joyodigitama.huaweiwear.WearEvents
import com.joyodigitama.huaweiwear.WearException
import com.joyodigitama.huaweiwear.WearLink
import com.joyodigitama.huaweiwear.WearSettings
import com.joyodigitama.huaweiwear.hex2
import com.joyodigitama.huaweiwear.toHex
import java.io.IOException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import nodomain.freeyourgadget.gadgetbridge.devices.huawei.HuaweiPacket
import nodomain.freeyourgadget.gadgetbridge.devices.huawei.HuaweiTLV
import nodomain.freeyourgadget.gadgetbridge.devices.huawei.packets.P2P
import nodomain.freeyourgadget.gadgetbridge.service.devices.huawei.HuaweiP2PManager
import nodomain.freeyourgadget.gadgetbridge.service.devices.huawei.p2p.HuaweiBaseP2PService
import nodomain.freeyourgadget.gadgetbridge.service.devices.huawei.p2p.utils.HuaweiP2PSubMsg

/*
 * Zona HR untuk jam jalur "track" (P2P, ExpandCapability 0x36). Berkas milik proyek TrainingPlan, bukan salinan JoyoFit.
 *
 * Inti JoyoFit sudah punya TrackService (HeartRateZonesSync.kt), tetapi hanya mengirim zona bawaan menurut usia dan pemilik
 * P2P-nya (P2pController/P2pStack) membawa Healthy Living serta sinkron kamus kesehatan, yang tidak dipakai plugin ini.
 * Di sini ada dua hal saja: TrackZonesService (sama dengan TrackService, tetapi memakai zona kustom dari app bila ada) dan
 * TrackZonesController (menyambung P2P ke sesi saat tautan CONNECTED, meniru P2pStack tanpa kamus dan Healthy Living).
 */

/** Seperti TrackService: kirim TLV zona lewat modul hw.unitedevice.track saat terdaftar, tetapi dengan zona kustom bila valid. */
internal class TrackZonesService(
  manager: HuaweiP2PManager,
  private val events: WearEvents,
  private val age: () -> Int,
  private val custom: () -> HeartRateZonesCalc.CustomZones?,
) : HuaweiBaseP2PService(manager) {
  override fun getModule(): String = TrackService.MODULE

  override fun getPackage(): String = TrackService.PACKAGE

  override fun getFingerprint(): String = TrackService.FINGERPRINT

  override fun registered() = resend()

  override fun unregister() = Unit

  override fun handleData(data: ByteArray) {
    log("HR zones: track service data, ${data.size} bytes: ${data.toHex()}")
  }

  /** Semua postur memakai zona bawaan menurut usia; postur tegak (yang tampil di layar latihan) diganti zona kustom bila ada. */
  private fun configs(years: Int): Pair<List<HeartRateZonesCalc.Config>, Boolean> {
    val defaults = HeartRateZonesCalc.deviceConfig(years, track = true, simpleCommand = false, extended = false)
    val chosen = custom()
    if (chosen == null) return defaults to false
    val problem = chosen.error()
    if (problem != null) {
      events.log(LogDirection.ERROR, 0x34, 0x01, null, "HR zones: custom zones ignored, $problem")
      return defaults to false
    }
    val mine = HeartRateZonesCalc.customConfig(chosen)
    val merged = defaults.map { base ->
      if (base.posture != HeartRateZonesCalc.Posture.UPRIGHT) {
        base
      } else {
        // Paket track wajib membawa LTHR tegak. Bila pilihan app LTHR, mine sudah memuat LTHR pilihan itu (dan currentMethod = LTHR,
        // yang membuat jam memakai nama zona LTHR); selain itu LTHR bawaan menurut usia ikut.
        val lthr = base.byMethod(HeartRateZonesCalc.Method.LTHR)
        mine.copy(zones = if (lthr != null && mine.byMethod(HeartRateZonesCalc.Method.LTHR) == null) mine.zones + lthr else mine.zones)
      }
    }
    return merged to true
  }

  /** GB sendHeartZoneConfig. */
  fun resend() {
    val years = age()
    val (configs, isCustom) = configs(years)
    val pairs = HeartRateZonesCalc.trackTlv(configs)
    if (pairs == null) {
      events.log(LogDirection.ERROR, 0x34, 0x01, null, "HR zones: not sent, the zones for age $years are not valid")
      return
    }
    val tlv = HuaweiTLV()
    for ((tag, value) in pairs) tlv.put(tag, value.toByte())
    val packet = HuaweiP2PSubMsg(2, HuaweiP2PSubMsg.getNext(), tlv.serialize())
    sendCommand(packet.bytes, null)
    val upright = configs.first { it.posture == HeartRateZonesCalc.Posture.UPRIGHT }
    val mhr = upright.byMethod(HeartRateZonesCalc.Method.MHR)!!
    val hrr = upright.byMethod(HeartRateZonesCalc.Method.HRR)!!
    val lthr = upright.byMethod(HeartRateZonesCalc.Method.LTHR)
    log(
      "HR zones: sent via ${TrackService.MODULE} for ${if (isCustom) "custom ${upright.currentMethod}" else "age $years"}, upright MHR " +
        "${mhr.zone1}/${mhr.zone2}/${mhr.zone3}/${mhr.zone4}/${mhr.zone5} of ${mhr.threshold}, " +
        (lthr?.let { "LTHR ${it.zone1}/${it.zone2}/${it.zone3}/${it.zone4}/${it.zone5} of ${it.threshold} (current method ${upright.currentMethod}), " } ?: "") +
        "HRR ${hrr.zone1}/${hrr.zone2}/${hrr.zone3}/${hrr.zone4}/${hrr.zone5} resting ${hrr.resting}, warning ${upright.warningHRLimit}, ${packet.bytes.size} bytes",
    )
  }

  private fun log(message: String) {
    events.log(LogDirection.INFO, 0x34, 0x01, null, message)
  }
}

/**
 * Pemilik P2P untuk zona HR di satu sesi. Dipanggil dari keadaan tautan: saat CONNECTED (sesi baru) membangun tumpukan P2P dan,
 * bila jam menyatakan jalur track, mendaftarkan [TrackZonesService] (yang langsung mengirim zona tersimpan); saat DISCONNECTED menutupnya.
 */
internal class TrackZonesController(
  private val link: WearLink,
  private val settings: WearSettings,
  private val events: WearEvents,
) {
  @Volatile
  private var stack: Stack? = null
  private var attached: HuaweiSession? = null

  @Synchronized
  fun onLinkState(state: LinkState) {
    when (state) {
      LinkState.CONNECTED, LinkState.SYNCING -> {
        val handle = link.handle() ?: return
        if (handle.session === attached) return
        detach()
        attached = handle.session
        val created = Stack(handle.session, events, settings)
        stack = created
        created.start()
        created.registerServices()
      }
      LinkState.DISCONNECTED -> detach()
      else -> Unit
    }
  }

  private fun detach() {
    stack?.close()
    stack = null
    attached = null
  }

  /** Pengelola P2P sesi ini, null bila jam tidak terhubung. Dipakai pengirim kursus lari. */
  fun manager(): HuaweiP2PManager? = stack?.manager

  /** Kirim ulang zona tersimpan lewat P2P; false bila jam tidak memakai jalur ini atau belum terhubung. */
  @Synchronized
  fun resend(): Boolean {
    val service = stack?.track ?: return false
    service.resend()
    return true
  }

  /** Tumpukan P2P satu sesi: GB HuaweiP2PManager di atas HuaweiSession, satu korutin membaca dan satu menulis berurutan. */
  private class Stack(
    private val session: HuaweiSession,
    private val events: WearEvents,
    private val settings: WearSettings,
  ) : HuaweiP2PManager.Transport {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val inbound = Channel<HuaweiPacket>(Channel.UNLIMITED)
    private val outbound = Channel<HuaweiPacket>(Channel.UNLIMITED)
    private var subscription: AutoCloseable? = null
    val manager: HuaweiP2PManager = HuaweiP2PManager(this)

    @Volatile
    var track: TrackZonesService? = null
      private set

    fun start() {
      subscription = session.subscribe(P2P.id, P2P.P2PCommand.id, "P2P") { inbound.trySend(it) }
      scope.launch {
        for (packet in inbound) {
          try {
            dispatch(packet)
          } catch (e: CancellationException) {
            throw e
          } catch (e: Exception) {
            log("P2P: handling a packet failed: ${e.message ?: e.javaClass.simpleName}", error = true)
          }
        }
      }
      scope.launch {
        for (packet in outbound) {
          try {
            session.send(packet, "P2P")
          } catch (e: CancellationException) {
            throw e
          } catch (e: WearException) {
            if (e.errorCode != ErrorCodes.DISCONNECTED) log("P2P send failed: ${e.message}", error = true)
          }
        }
      }
    }

    private fun dispatch(packet: HuaweiPacket) {
      packet.parseTlv()
      val response = packet as? P2P.P2PCommand.Response
      if (response == null) {
        log("P2P packet could not be decoded (service ${packet.serviceId.hex2()} command ${packet.commandId.hex2()})", error = true)
        return
      }
      manager.handlePacket(response)
    }

    /** Hanya jalur track: jam yang menerima zona lewat FitnessData 07/13 atau 07/21 tidak memerlukan P2P sama sekali. */
    fun registerServices() {
      log(HeartRateZonesSync.capsLine(), error = false)
      if (!DeviceCaps.supports(0x34, 0x01)) {
        log("P2P: the watch does not list the P2P service (34/01), no P2P service registered", error = false)
        return
      }
      if (!HeartRateZonesSync.supportsTrack) return
      val service = TrackZonesService(
        manager,
        events,
        { HeartRateZonesSync.age(settings.profile) },
        { HeartRateZonesSync.parseCustom(settings.customHrZones) },
      )
      track = service
      service.register()
    }

    fun close() {
      subscription?.close()
      subscription = null
      manager.unregisterAllService()
      inbound.close()
      outbound.close()
      scope.cancel()
    }

    // HuaweiP2PManager.Transport

    @Throws(IOException::class)
    override fun sendP2P(
      cmdId: Byte,
      sequence: Short,
      srcPackage: String?,
      dstPackage: String?,
      srcFingerprint: String?,
      dstFingerprint: String?,
      sendData: ByteArray?,
      sendCode: Int,
    ) {
      val packet = try {
        P2P.P2PCommand.Request(session.params, cmdId, sequence, srcPackage, dstPackage, srcFingerprint, dstFingerprint, sendData, sendCode)
      } catch (e: Exception) {
        throw IOException("P2P request could not be built: ${e.message}", e)
      }
      outbound.trySend(packet)
    }

    override fun supportsExpandCapability(which: Int): Boolean = DeviceCaps.expandCapability(which)

    override fun log(message: String) {
      log(message, error = false)
    }

    private fun log(message: String, error: Boolean) {
      events.log(if (error) LogDirection.ERROR else LogDirection.INFO, P2P.id.toInt(), P2P.P2PCommand.id.toInt(), null, message)
    }
  }
}
