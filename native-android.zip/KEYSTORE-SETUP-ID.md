# Penandatanganan APK EnduranceVault

Workflow memakai satu persistent keystore. Jangan pernah commit file keystore, password, atau file Base64 ke repository.

Tambahkan empat GitHub Actions Secrets di Settings → Secrets and variables → Actions:

- `KEYSTORE_BASE64`: seluruh isi file keystore yang di-encode Base64 (satu baris, `base64 -w0 file.keystore`).
- `KEYSTORE_PASSWORD`: password keystore.
- `KEY_ALIAS`: alias key di dalam keystore.
- `KEY_PASSWORD`: password key (untuk PKCS12, sama dengan password keystore).

Jika tiga secret terakhir kosong, workflow memakai nilai default lama (`android`, `androiddebugkey`, `android`) dan menampilkan peringatan.

Untuk beberapa aplikasi yang saling terkoneksi, pakai keystore yang sama dan isi keempat secret dengan nilai yang sama di setiap repo (atau pakai Organization secrets).

Mengganti password atau alias pada salinan keystore lama tidak mengubah signature, selama SHA256 sertifikat sama (cek dengan `keytool -list -v`). Membuat keystore baru dari nol mengubah signature, sehingga aplikasi terpasang harus di-uninstall dulu.

Simpan keystore dan password secara offline di tempat aman dan buat backup terenkripsi. Kehilangan keystore berarti tidak bisa menandatangani update yang kompatibel. Jangan bagikan keystore atau password.

Setiap rilis harus memakai keystore yang sama dan `versionCode` yang lebih besar.
