EnduranceVault Native Stage 6.5.1
Package: com.endurancevault.app
Version: 0.4.9 (versionCode 13)

Replace the previous project ZIP in the repository with this ZIP and run GitHub Actions.
Keep the existing KEYSTORE_BASE64 secret. Install the resulting signed APK as an update; do not uninstall the current app.

This package completes the previously missing weather/AQI, weather-to-Huawei-watch, A-GPS, phone-notification-forwarding, and online AI Coach workflows. Fueling/hydration features have been removed as requested.

The Groq API key is entered by the user in Profile > AI Coach. It is encrypted with Android Keystore and excluded from Android backup. Location and Notification Access require explicit user permission.

Gradle build and physical watch validation have not been performed in this environment.
