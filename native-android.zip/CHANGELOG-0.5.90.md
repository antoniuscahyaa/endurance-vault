# Video rute 3D: grid, tanpa latar, dan enam fitur baru

Tata letak
- Panel data kini ditempatkan pada grid, bukan bebas dipindah per piksel. Jumlah kolom (1-6) dan baris (4-20) bisa diatur. Panel pindah antar sel dengan menggeser di pratinjau (saat panel dipilih, garis grid tampil), atau dengan tombol panah; lebar dan tinggi panel dalam jumlah sel. Isi panel otomatis diskalakan agar pas di kotaknya, dan panel tidak bisa saling menimpa.
- Mengubah ukuran grid menyusun ulang panel yang ada; yang bentrok dipindah ke sel kosong, yang tidak muat dihapus.
- Latar kartu pada panel data dihapus: panel kini transparan penuh. Pilihan "Latar panel" ikut dihapus. Bendera di peta tetap memakai kapsul berwarna supaya terbaca.
- Preset tata letak (bawaan dan buatanmu) menyimpan ukuran grid.
- Pengaturan lama dengan posisi persen tidak bisa dipetakan ke grid: daftar panel yang aktif dipertahankan, posisinya kembali ke bawaan grid.

Fitur baru
- Grafik pace/kecepatan dan grafik detak jantung (panel, dengan penanda posisi yang bergerak).
- Kartu ringkasan 3 detik di akhir video (jarak, waktu, pace rata-rata, total naik, HR dan cadence bila ada) di atas bingkai terakhir yang diredupkan; panel memudar saat kartu muncul. Bisa dimatikan; durasi video utama tidak berubah.
- Mode kamera: Orbit (seperti sebelumnya), Ikuti arah lari (kamera di belakang pelari), Dari atas (utara di atas).
- Judul sendiri, baris kedua bebas (mis. lokasi atau event), dan sakelar tanggal. Berlaku juga di kartu ringkasan.
- Tombol "Foto bingkai ini": menyimpan tampilan di posisi pratinjau sebagai JPEG resolusi penuh (ke galeri atau dibagikan).
- Bendera sorotan: 1 km tercepat dan titik HR tertinggi, masing-masing punya sakelar sendiri.

Berkas baru: tidak ada. Berubah: `RouteVideo.kt`, `RouteVideoExtras.kt`, `RouteVideoOverlay.kt`, `RouteVideoEncoder.kt`, `TerrainGl.kt`, `RouteVideoScreen.kt`, `RouteVideoTest.kt`, `en.tsv`.
