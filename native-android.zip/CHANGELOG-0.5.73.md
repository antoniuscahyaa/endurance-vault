# Pil status jam di header: hanya informasi

Menggantikan perilaku pil di CHANGELOG-0.5.67 (bagian "Pil status di header").

- Mengetuk pil (titik status dan baterai di samping pill Recovery) tidak lagi menyinkron atau membuka halaman apa pun.
- Yang muncul adalah balon kecil mengambang tepat di bawah pil: "Sinkron terakhir" dengan jam dan waktu relatif, mis. "13:49 · 3 mnt lalu". Format sama dengan baris "Sinkron terakhir" di halaman Jam.
- Selama sinkron berjalan balon menampilkan "Sedang menyinkron…", dan "Belum pernah sinkron" bila belum ada riwayat. Bila jam terputus ada baris merah "Jam sedang terputus".
- Balon hilang sendiri setelah 4 detik, atau saat layar disentuh di luar balon.
- Sinkron manual tetap lewat titik status di kartu Jam di Pengaturan.

Berkas berubah:
- app/src/main/java/com/endurancevault/app/ui/screens/WatchStatus.kt (`WatchBadge` menyimpan waktu sinkron mentah, `WatchHeaderPill` memakai balon)
- app/src/main/java/com/endurancevault/app/ui/AppRoot.kt (parameter `onWatchTap` dihapus)
