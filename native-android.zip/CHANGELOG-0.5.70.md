# Halaman Profil: HR, target, rekor, dan gear pindah ke sini

Kartu profil di Pengaturan sekarang membuka halaman Profil (sebelumnya hanya dialog edit). Foto dan nama diubah dari halaman itu.

## Kartu profil di Pengaturan
- Ketuk kartu = buka halaman Profil. Tanda panah di kanan menggantikan edit langsung.
- Ikon pensil di atas foto dihapus. Di halaman Profil, ketuk foto untuk ganti foto, ketuk nama atau ikon pensil di sebelah nama untuk ganti nama.

## Isi halaman Profil
- Total keseluruhan: jumlah lari, jarak, waktu, dan lari terpanjang (hanya aktivitas `run`), plus "Mencatat sejak".
- Detak jantung: HR maks, HR istirahat, LTHR, metode zona, dan bar Z1 sampai Z5. Ketuk untuk membuka isian zona dan kirim zona ke jam (komponen lama dari Pengaturan > Zona HR, tidak ditulis ulang).
- Target: hitung mundur hari, nama lomba, tanggal, target waktu, pace target, dan fase rencana. Ketuk kartu untuk menampilkan grafik batang tiap pekan (Build, Recovery, Taper; pekan berjalan diberi garis tepi, pekan mendatang dipudarkan). Kartu disembunyikan bila rencana tanpa lomba.
- Rekor pribadi: 1 km, 5K, 10K, dan Half, salinan ringkas dari Fitness. Ketuk untuk membuka tab Fitness.
- Gear aktif: sepatu aktif dengan bar km terpakai. Ketuk untuk membuka form tambah gear dan daftar lengkap (termasuk yang dipensiunkan).

## Pengaturan
- Ubin "Zona HR" dihapus (dipindah ke Profil).
- Ubin "Kondisi & gear" menjadi "Kondisi" dan hanya berisi catatan Leg feel dan Mood. Gear dipindah ke Profil.

Berkas berubah:
- app/src/main/java/com/endurancevault/app/ui/screens/ProfilePage.kt (baru)
- app/src/main/java/com/endurancevault/app/ui/screens/ProfileIdentityCard.kt (kartu membuka Profil, pensil di foto dihapus)
- app/src/main/java/com/endurancevault/app/ui/screens/ProfileScreen.kt (cabang "Profil", ubin Zona HR dihapus, "Kondisi")
- app/src/main/java/com/endurancevault/app/ui/screens/CompanionDataSection.kt (blok gear dikeluarkan)
- app/src/main/java/com/endurancevault/app/ui/screens/SettingsHomeGrid.kt (ikon "Kondisi")
- app/src/main/java/com/endurancevault/app/ui/AppRoot.kt (`onOpenProgressDock` untuk Pengaturan)
