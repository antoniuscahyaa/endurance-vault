# Ikon aplikasi & splash screen baru (flat, minimalis)

Logo EV disederhanakan menjadi flat (tanpa gradien/efek 3D) dengan tone warna yang sama.
Sebelumnya aplikasi native belum punya ikon launcher maupun splash.

## Ikon launcher
- Adaptive icon: latar gelap `#0B0C0F`, E putih, V + garis tren oranye `#FC6808`, bar/gunung abu-abu.
- Ikon bertema Android 13+ (monokrom) ikut tersedia.
- minSdk 26, jadi cukup `mipmap-anydpi-v26` (tanpa PNG cadangan).

## Splash
- Tahap 1 (splash sistem Android, lewat `androidx.core:core-splashscreen`): latar murni warna aksen Ember `#EA5F0A` + logo di tengah. Berlaku untuk Android 8–15.
- Tahap 2 (`SplashOverlay`, Compose): siluet grafik berbentuk sama dengan logo naik dari dasar layar (warna gelap), bertahan singkat, lalu memudar. Tidak diputar ulang saat rotasi layar.
- Tinggi siluet diatur lewat `SIL_HEIGHT_SCALE` di `SplashOverlay.kt` (default 0.8; 1.0 = proporsi asli logo). Lama tampil: `HOLD_MS`.
- Tulisan "EnduranceVault" tidak ditampilkan (splash sistem Android 12+ hanya mendukung ikon).

Berkas berubah:
- app/build.gradle.kts (dependensi `core-splashscreen:1.0.1`)
- app/src/main/AndroidManifest.xml (android:icon, android:roundIcon, tema activity = Theme.EnduranceVault.Splash)
- app/src/main/java/com/endurancevault/app/MainActivity.kt (installSplashScreen, SplashOverlay di atas AppRoot)
- app/src/main/java/com/endurancevault/app/ui/SplashOverlay.kt (baru)
- app/src/main/res/values/themes.xml (style Theme.EnduranceVault.Splash)
- app/src/main/res/values/colors.xml (baru: ic_launcher_background, splash_bg)
- app/src/main/res/drawable/ic_launcher_foreground.xml, ic_launcher_monochrome.xml, ic_splash_logo.xml (baru)
- app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml, ic_launcher_round.xml (baru)
