# Peta di tab Rute mengikuti gaya peta pilihan

- Peta statis di tab Rute (peta rute dan heatmap) tidak lagi terkunci di peta default: ia mengikuti gaya yang terakhir dipilih di peta aktivitas atau pratinjau GPX (default, satelit, topografi, atau kontur). Pilihan belum punya tombol sendiri di tab Rute.
- Pemeriksaan zip 0.5.86: semua bagian Explore 0.5.80–0.5.82 (Kontur, jalur, rencana mendaki) ada, dan impor gestur di `ExploreScreen.kt` sudah benar.
Belum dikompilasi di sini.
