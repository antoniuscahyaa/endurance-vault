# Video rute 3D

Menu baru "Video rute 3D" di detail aktivitas, tepat di bawah "Stiker data".

Video
- MP4 9:16 (1080×1920, 30 fps, H.264) dibuat di perangkat lewat OpenGL ES 2.0 + MediaCodec/MediaMuxer, tanpa dependensi baru.
- Peta satelit (Esri, via `MapTiles`) ditempel pada relief 3D dari elevasi Terrarium (AWS Terrain Tiles, tanpa kunci API). Skala elevasi 1×–4× (1× = sesuai aslinya).
- Rute tergambar bertahap dengan penanda posisi; kamera mengikuti pelari, berputar pelan, lalu menjauh di akhir. Kemiringan, putaran, dan durasi (6–40 dtk) bisa diatur.
- Jejak GPS per detik dipakai bila ada; aktivitas lama jatuh ke rute sederhana (lebih kasar).

Panel data
- Judul, jarak, waktu, pace (kecepatan untuk sepeda), detak jantung, gradien, elevasi, total naik, cadence, dan grafik elevasi.
- Posisi dan ukuran tiap panel diatur dengan menggeser di pratinjau, slider ukuran, dan tombol geser halus. Tersimpan antar sesi.
- Mode angka berjalan (mengikuti posisi pelari) atau total/rata-rata. Warna teks, latar panel, dan warna garis rute bisa dipilih. Huruf mengikuti pengaturan Stiker data.

Berkas baru: `domain/RouteVideo.kt`, `data/Terrain.kt`, `ui/video/*`, `ui/screens/RouteVideoScreen.kt`, `RouteVideoTest.kt`. `file_paths.xml` bertambah `videos/`.
Butuh internet saat pertama kali membuka area baru (ubin satelit dan elevasi di-cache sesudahnya).
