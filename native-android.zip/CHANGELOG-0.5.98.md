# 0.5.98

## Video Trail 3D: luas cakupan, geser, dan perataan tepi base
Di bagian **Bentuk dan kamera** (layar Video Trail 3D) ada pengaturan baru:
- **Luas cakupan base** 100–250%. 100% = base pas melingkupi rute, **114% = bawaan** (sama dengan sebelumnya). Makin besar, makin banyak medan di sekitar rute yang ikut tampil; rute mengecil di layar karena base selalu dipas ke kotak adegan. Base tidak bisa lebih kecil dari rute supaya rute tidak terpotong.
- **Geser base ke timur/barat** dan **utara/selatan** (-100..100% dari ruang gerak). Aktif bila cakupan di atas 100%; rute selalu tetap di dalam base. Tombol **Pusatkan base** mengembalikan ke tengah.
- **Ratakan tepi base** 0–100%. Bila medan di pinggir tinggi, bibir dan dinding slab ikut bergelombang. Slider ini mencampur tinggi medan di dekat tepi ke tinggi rata-rata tepi: 0% = alami (seperti sebelumnya), 100% = tepi benar-benar rata sehingga bentuk lingkaran/poligon asli terlihat bersih. Zona perataan dimulai di luar rute bila ada ruang (paling rapi dengan cakupan di atas 114%); bila rute menyentuh tepi, tinggi rute di dekat tepi ikut sedikit diratakan.
- **Potong vertikal (blok)**: dinding base turun tegak dari tepi medan ke dasar yang rata, sehingga base tampak seperti blok yang dipotong mengikuti bentuknya (lingkaran/poligon). Mati = pita dinding setebal tetap seperti sebelumnya. Bisa digabung dengan Ratakan tepi: blok dengan tepi atas rata, atau tepi atas mengikuti profil medan asli.
- Semuanya ikut tersimpan dan ikut masuk video hasil render, foto bingkai, dan pratinjau hidup. Pengaturan lama otomatis memakai bawaan.

### Teknis
- `TrailPrefs`: `coverage`, `offX`, `offZ`, `flatEdge`, `blockCut` (+ sanitasi, JSON, `MIN_COVERAGE`/`MAX_COVERAGE`).
- `TrailScene`: apotema = jari-jari pas rute × cakupan (dibatasi grid); pusat digeser dalam ruang `apotema - jari-jari rute`, lalu diturunkan bila keluar grid.
- `TerrainBuilder.buildTrail`: bingkai medan 3× rute (sebelumnya 2×), minimal 1,8 km, grid 240 (sebelumnya 160) dan ubin elevasi sebanding supaya kerapatan sel tetap sama. Unduhan elevasi sedikit lebih banyak pada pembuatan pertama; sesudahnya dari cache.
- `TrailScene.flattenEdge`: grid terhaluskan dicampur ke tinggi rata-rata tepi dengan smoothstep antara jari-jari relatif `start` dan 1; `lo`/`hi`, rute, dan dinding memakai grid hasil perataan.
- `TrailGl.prepare`: pada `blockCut` titik bawah dinding di y = -wallDepth (rata); kecocokan kamera tidak berubah karena sudah memakai dasar itu.
- Uji baru: `trailCoverageAndOffsetAreSanitizedAndSaved`.
- Belum dijalankan di lingkungan ini: build Gradle, uji unit, dan render di perangkat. Jalankan CI dan coba di HP, terutama rute lurus panjang dan rute melingkar kecil.
