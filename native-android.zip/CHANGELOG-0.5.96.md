# 0.5.96

## Impor zip ekspor Huawei Health (Setelan, tab Cadangan)
- Tombol baru **"Impor zip Huawei Health"** di bawah "Impor FIT / GPX / TCX". Pilih langsung `HUAWEI_HEALTH_<tanggal>.zip` (dari Pusat Privasi Huawei), tidak perlu diekstrak.
- Zip yang dienkripsi (ikon gembok) membuka dialog **kata sandi**. Kosongkan untuk zip tanpa kata sandi. Bila salah, muncul tombol "Coba kata sandi lain" tanpa harus memilih zip lagi.
- Yang dibaca hanya folder **Motion path detail data** (`motion_path_detail_data*.json`). Folder besar lain (Health detail, Sample sequence, Sport per minute) tidak disentuh.
  Pembacaan memakai jalur cepat (`ZipFile` lewat `/proc/self/fd`, langsung ke daftar isi zip) dan jatuh ke pembacaan berurutan bila penyedia berkas tidak mendukungnya (lebih lambat untuk zip ~1 GB).
- Setiap rekaman GPS (lari, sepeda, hiking) menjadi aktivitas lewat jalur yang sama dengan impor FIT/GPX/TCX (`ActBuilder`): tanggal dan jam asli (zona waktu dari rekaman), rute, HR, ketinggian, split, pace.
- Kode jenis olahraga yang didukung: lari 4/258, trail 118/280, track 221, marathon 227; sepeda 3/259; hiking/mendaki 2/260/282. Jenis lain (strength, renang, indoor, dll.) dan rekaman tanpa GPS dilewati dan dihitung di ringkasan hasil.
- Detail format yang ditangani:
  - Baris `tp=lbs` memakai `t` dalam detik (notasi ilmiah `1.791626734E9`). Titik penutup `lat=90, lon=-80` adalah penanda tak valid dan dibuang (tanpa ini jarak sepeda 1,6 km menjadi 10.800 km).
  - Ketinggian diambil dari `tp=alti` (barometer, tiap 5 dtk), bukan `alt` di baris `lbs` yang selalu 0. HR dari `tp=h-r` (nilai -1 dibuang). Kadens dari `tp=cad` (0 dibuang), dianggap sudah spm.
  - Catatan satuan di ringkasan Huawei: `creepingWave` dan `mTotalDescent` dalam desimeter (bukan meter), `totalCalories` dalam kal.
- Rekaman yang cocok dengan aktivitas yang sudah ada (tanggal, jam mulai, jarak) dilewati atau melengkapi detailnya. Rekaman kembar di dalam zip yang sama dihitung sekali.
- Koordinat dipakai apa adanya (GCJ-02 hanya berbeda dari WGS-84 di daratan Tiongkok).

## Yang tidak ikut (sengaja)
- `SportsHealth-Data.xls` hanya berisi agregat harian, profil, perangkat, dan lomba, bukan latihan per sesi, jadi belum dibaca. Bisa jadi tahap berikutnya (tinggi/berat badan, daftar lomba).
- `HUAWEI_HEALTH-Agreement Signing-Data.xlsx` adalah catatan persetujuan privasi, tidak relevan.

## Teknis
- `MainViewModel`: logika simpan aktivitas dipindah dari `importTracks` ke `ingestBuiltAct` (perilaku `importTracks` tidak berubah), dipakai bersama `importHuaweiZip`.
- Dependensi baru: `net.lingala.zip4j:zip4j:2.11.5` (java.util.zip tidak bisa membuka zip berkata sandi).
- Berkas baru: `data/HuaweiHealthZip.kt` (`HuaweiHealthZip`, `HuaweiMotionPath`), tes `HuaweiMotionPathTest`.
- Berubah: `app/build.gradle.kts`, `MainViewModel.kt`, `ProfileScreen.kt`, `AppRoot.kt`, `i18n/en.tsv`.
Kode belum dikompilasi di sini. Mohon rebuild dan kirim log CI bila ada error.

## Perbaikan memori setelah impor besar
- Penyebab aplikasi berat lalu force close setelah impor banyak aktivitas: tiap perubahan tabel aktivitas membuat `state` mem-parse ulang semua berkas detail. Saat impor ini terjadi di setiap aktivitas yang disimpan, dan saat dibuka semuanya dimuat sekaligus.
- `MainViewModel`: cache detail per berkas (`detailCache`, kunci waktu ubah + ukuran), berkas yang tak lagi dipakai dibuang dari cache.
- `AndroidManifest.xml`: `android:largeHeap="true"`.
- Belum ditangani: seluruh detail tetap dimuat ke memori (dipakai PR, Rekap, Rute). Bila masih kehabisan memori, langkah berikutnya memuat detail hanya untuk aktivitas terbaru.
