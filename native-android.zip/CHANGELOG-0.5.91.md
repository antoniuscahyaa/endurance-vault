# 0.5.91

## Video rute 3D: grid lebih lebar daripada tinggi + jarak antar panel
- **Baris grid (vertikal) kini 1–4** (sebelumnya 4–20, bawaan 12). **Kolom (horizontal) tetap 1–6**, bawaan kini **4** (sebelumnya 2).
  Bawaan 4×4: judul di baris 1, grafik elevasi di baris 3, empat angka utama (jarak, waktu, pace, HR) berdampingan di baris 4.
  Sel kini kira-kira persegi pada video 9:16, bukan strip tipis.
- **Jarak antar panel diatur manual per arah**: dua slider baru di bagian "Data di video", **Jarak horizontal** (antar kolom) dan
  **Jarak vertikal** (antar baris), masing-masing 0–120 (bawaan 12). Tiap panel dirapatkan setengah jarak di sisinya, sehingga dua panel
  bertetangga berjarak penuh sebesar nilai itu; panel yang memakai beberapa sel tidak punya jarak di dalamnya.
  Satuannya mengikuti sisi pendek bingkai 1080 px, jadi tampilan sama di HD dan SD. Kedua jarak ikut tersimpan di preset tata letak.
  Pengaturan sebelumnya dengan satu nilai jarak dipakai untuk kedua arah.
- Preset bawaan (Minimal, Lengkap, Gaya Coros) disusun ulang untuk grid 4 baris.
- **Pengaturan dan preset lama** (grid >4 baris, mis. 12) dipetakan proporsional ke 4 baris: tiap panel mempertahankan rentang vertikalnya
  (minimal 1 baris), yang bentrok dipindah ke sel kosong. Posisi bisa sedikit bergeser; cek pratinjau.

## Pratinjau disematkan
- Pratinjau video dan slider "Posisi pratinjau" kini tetap di atas layar; hanya menu pengaturan di bawahnya yang menggulir, jadi hasil edit langsung terlihat tanpa perlu menggulir naik.
- Ukuran pratinjau disesuaikan: tinggi dibatasi ±38% tinggi layar dan lebar mengikuti rasio video (9:16, 4:5, 1:1, 16:9), sehingga menu tetap punya ruang. Header "Kembali" dan judul dibuat lebih ringkas.
- Peringatan (data elevasi/citra peta belum terunduh, ghost dimuat, pratinjau gagal) pindah ke area yang menggulir.

Berubah: `RouteVideo.kt`, `RouteVideoExtras.kt`, `RouteVideoOverlay.kt`, `RouteVideoScreen.kt`, `RouteVideoTest.kt`, `en.tsv`.
Kode belum dikompilasi di sini. Mohon rebuild dan kirim log CI bila ada error.
