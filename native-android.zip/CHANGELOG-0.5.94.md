# 0.5.94

## Huruf kapital: singkatan tidak lagi berubah jadi kata biasa (`DeCaps`)
- Penyebab "ACWR" tampil "Acwr": singkatan hanya dipertahankan bila ada di daftar atau tanpa vokal, dan ACWR punya huruf A.
  Daftar singkatan ditambah: **ACWR, RAI, VDOT, VAM, MAF, REM, REC, SL, TE, AQI, US, EU, UV, OSM, OSRM, OSS**.
- **Token gabungan** dengan `-`, `/`, `−`, `–` kini diproses per bagian: "A-GPS" tetap "A-GPS" (bukan "A-gps"),
  "GPT-OSS 120B" tetap, "Δ B−A" tetap, "HR/PACE" menjadi "HR/pace".
- **"VS" dan "KM"** selalu huruf kecil ("vs", "km"), juga di awal teks. "TEMP VS HR" kini "Temp vs HR", bukan "Temp VS HR".
- **"SpO₂" / "SpO2"** tidak lagi dianggap huruf kecil yang menggagalkan konversi, jadi "SLEEP SpO₂" tampil "Sleep SpO₂" seperti label lain.
- Tes baru `DeCapsTest` (sebelumnya `DeCaps` belum punya tes).

## Tab Hari ini
- Judul "Hari ini" dihapus. **Hari dan tanggal** pindah ke posisinya (rata kiri), margin atas disesuaikan; jarak ke kartu sapaan tetap 14dp seperti jarak antar kartu lain.
- Teks sapaan ("Good afternoon") dibesarkan **11sp → 13sp** (letter-spacing 2sp, satu baris dengan elipsis). Lebar kartu tidak berubah karena padding kanan 44dp untuk tombol refresh dipertahankan.

## Kartu Tidur, Kesiapan, dan Zona HR
- Bentuk baru: **kartu utama vertikal** dengan judul rata tengah, berisi **kartu persegi** (tinggi = lebar) yang memuat cincin.
  Tinggi kartu mengikuti lebar, jadi ketiganya selalu sama tinggi (`IntrinsicSize.Min` dan `fillMaxHeight` di baris kartu dihapus).
- Cincin kini 75% sisi kartu persegi (sekitar 80dp, sebelumnya tetap 76dp) dan ikut menyesuaikan lebar layar.
- **Teks detail di bawah angka utama 8sp** (durasi tidur, tingkat kesiapan, total durasi zona HR); sebelumnya 12sp (9sp untuk kesiapan).
- Sudut kartu utama 18dp dan kartu dalam 14dp. `EvPanel` mendapat parameter `shape` opsional (bawaan tetap 16dp), jadi kartu lain tidak berubah.

## Nama jam
- `WatchDock.devName()` tidak lagi merusak akhiran model: "HUAWEI WATCH GT 4" kini "Watch GT 4" (sebelumnya "Watch Gt 4"), "GT5" dan "D2" tetap kapital.
  Kata lain tetap Title Case ("Watch Fit 4"). Tes baru di `WatchDockTest`.

Berubah: `DeCaps.kt`, `DeCapsTest.kt`, `EvUi.kt`, `TodayScreen.kt`, `TodayInfoCards.kt`, `GreetingWeatherCard.kt`, `WatchDock.kt`, `WatchDockTest.kt`.
Kode belum dikompilasi di sini. Mohon rebuild dan kirim log CI bila ada error.
