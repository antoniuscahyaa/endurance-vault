# 0.5.89

## Sesi trail: loop Ungaran diganti target jarak + D+
- Logika loop Ungaran dihapus (`UNG_KM`/`UNG_GAIN`, `PDay.trail`/`lk`/`mkLong`, jatah loop di `GainSpread`). Long run trail (fase puncak, dan fase build pada pekan genap) kini berjudul **"Long run · Trail"** dengan kalimat awal
  `Target trail: ±{km} km dan +{D+} m.` Rute bebas; jarak sesi sama dengan jatah mingguan (tidak lagi dibulatkan ke kelipatan 7 km) dan D+ mengikuti penghalus D+ mingguan.
- Sesi jalan (Ambarawa) dan semua jenis lomba non-trail tidak berubah. Ultra road (`ultrar`) tetap identik dengan sebelumnya.

## Cek GPX terhadap target (baru)
- Tombol **Cek GPX** di kartu sesi trail (tab Minggu). Pilih berkas GPX, aplikasi menghitung jarak dan D+ (ambang 3 m, sama dengan pratinjau rute) lalu membandingkannya dengan target.
- Toleransi (`TrailTarget.kt`): jarak ±10% (min 1 km); D+ ±15% (min 50 m). Di luar toleransi tetapi dalam 1,5× toleransi = "Hampir sesuai"; lebih jauh = "Belum sesuai". Hasil akhir mengikuti ukuran terburuk.
  D+ dibuat lebih longgar karena elevasi beda antar perangkat (barometer vs GPS) dan sumber data (rute rencana vs rekaman) bisa selisih 10–15% untuk rute yang sama.
- GPX tanpa elevasi: hanya jarak yang dinilai, dengan catatan.

## Perbaikan logika yang ditemukan saat pemeriksaan
- Sebelumnya, bila D+ mingguan terlalu kecil untuk memuat satu loop (batas 55% dari D+ pekan dibagi 750 m), long run yang seharusnya trail berubah menjadi "Ambarawa (jalan)" lewat penghalus D+ (`mkLong` dengan 0 loop). Sekarang label trail dipertahankan.
- Penyesuaian beban pekan dari Profil (pekan lebih ringan / mode sakit) menurunkan km sesi tetapi tidak D+, sehingga kerapatan tanjakan naik diam-diam. Untuk sesi trail bertarget, D+ kini ikut turun sebanding (`TrailTarget.scaleGain`).
- Teks target kini diselaraskan dengan km/D+ terkini setelah penyesuaian jadwal (libur dadakan bagi km, beban Profil) lewat `TrailTarget.sync`, dipanggil di akhir `ProfilePlanAdjustments.apply`. Sebelumnya teks detail (mis. "total ±X km") tertinggal pada angka lama.

## Tes
- Baru: `TrailTargetTest` (toleransi, review dari statistik dan dari teks GPX, target di rencana, sync, scaleGain, tidak ada lagi "Ungaran"/"loop" di rencana ultra).
- `PlanGoldenTest`: skenario `rtype=ultra` kini hanya membandingkan kerangka hari (tanggal, jenis, peran, grup), karena acuan web masih memakai loop Ungaran. Skenario lain tidak berubah.
  Untuk mengembalikan perbandingan penuh, ekspor ulang golden ultra dari keluaran Kotlin ini.

## Catatan
- Kode belum dikompilasi di sini. Mohon rebuild dan kirim log CI bila ada error.
- Terjemahan Inggris ditambahkan/diganti di `assets/i18n/en.tsv`.
