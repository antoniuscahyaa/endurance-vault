# Video rute 3D: ketebalan garis

- Slider "Ketebalan garis" (50-250%) di bagian Garis rute. Berlaku untuk garis rute, garis ghost, dan ukuran penanda posisi; 100% = ukuran sebelumnya.
- Pengaturan lama otomatis memakai 100%.
