# 0.5.39 — Halaman pengaturan jam

- Roda gigi di dock Jam kini membuka halaman penuh "Pengaturan jam" (route `watchsettings`); panel pengaturan inline di bawah kartu jam dihapus.
- Halaman berisi: kartu "Huawei Watch · Bluetooth langsung" (status, sinkron, langkah 1–3, "Catatan dan batasan" bisa dibuka), kartu "Koneksi latar belakang" (saklar + interval + ambang baterai + Simpan), lalu dua kartu kecil Zona HR dan Structured workout yang membuka kartu fiturnya saat diketuk.
- Live Heart Rate dihapus dari UI pengaturan jam (fungsi live HR untuk sesi strength tidak diubah).
- Rute GPX dipindah ke ikon di dock utama jam; ikon panah ke bawah diganti ikon peta.
