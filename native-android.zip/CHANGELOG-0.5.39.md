# 0.5.39 — Halaman pengaturan jam

- Roda gigi di dock Jam kini membuka halaman penuh "Pengaturan jam" (route `watchsettings`); panel pengaturan inline di bawah kartu jam dihapus.
- Halaman berisi: kartu "Huawei Watch · Bluetooth langsung" (status, sinkron, langkah 1–3, "Catatan dan batasan" bisa dibuka), kartu "Koneksi latar belakang" (saklar + interval + ambang baterai + Simpan), lalu dua kartu kecil Zona HR dan Structured workout yang membuka kartu fiturnya saat diketuk.
- Live Heart Rate dihapus dari UI pengaturan jam (fungsi live HR untuk sesi strength tidak diubah).
- Rute GPX dipindah ke ikon di dock utama jam; ikon panah ke bawah diganti ikon peta.
- Kartu Huawei Watch: saat jam sudah terhubung, bagian "Hubungkan jam baru" (langkah 1–3) dan catatan pairing disembunyikan; tampil status, Sinkronkan, Putuskan, dan Sinkron riwayat penuh. Status koneksi dibaca ulang tiap 4 detik.
- Koneksi latar belakang: teks keterangan diganti ikon info kecil yang membuka kartu melayang.
- Tab Jam: header "PERANGKAT / Jam / Koneksi dan sinkronisasi perangkat" dihapus; kartu pembungkus tambahan di sekitar kartu jam dihapus sehingga kartu utama langsung berisi konten jam.
- Halaman Pengaturan jam: header dan ikon kembali di atas dihapus; diganti ikon kembali bulat mengambang di pojok kanan bawah (padding 18 dp, pudaran tipis di dasar, ruang kosong di akhir daftar agar tidak tertutup).
- Tab Jam: padding kanan-kiri dikecilkan (10 dp) dan disamakan untuk semua blok; ubin data berukuran seragam (tinggi 100 dp); latar/border kartu "Latihan hari ini" dihapus (kartu tiap latihan tetap).
- A-GPS dan Notifikasi ponsel ke jam dipindah dari Pengaturan > Layanan ke halaman Pengaturan jam sebagai dua kartu kecil (ketuk untuk membuka). Kartu Cuaca dan AI Coach tetap di Layanan.
- Tab Jam: tiga ikon di kartu jam (peta/GPX, pengaturan, titik sinkron) disusun vertikal di sisi kanan, rata dengan tepi kanan konten kartu.
