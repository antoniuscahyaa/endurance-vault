# EnduranceVault Native 0.5.39: tab Jadwal mengikuti layout baru

## Perubahan
- Tab Jadwal (`PlanOverviewScreen`) ditulis ulang: kartu hero gelap (PERFORMANCE BUILD, panjang rencana, total volume, pilihan Km/Hours/Climb/Descent), grafik batang per minggu (isi = sudah dilakukan, segitiga = lonjakan >10%), ringkasan lonjakan, legenda.
- ALL WEEKS dikelompokkan per fase (BASE 1/2, BUILD 1/3, ... maks. 4 minggu per blok) dengan total tiap blok. Ketuk minggu untuk membuka kartu hari (Logged, Detail, On plan / Needs attention / Missed) dan blok strength.
- Dock fase Base/Build/Peak/Taper di bawah: ketuk untuk lompat ke fase, aktif mengikuti posisi gulir, titik menandai fase berjalan.
- `AppRoot.kt`: `PlanOverviewScreen` menerima `onOpenActivity` agar tombol Detail membuka aktivitas.

## Catatan
- Rencana hanya menyimpan D+; Descent memakai angka yang sama dengan Climb. Hours = km rencana × pace pengaturan.
- Belum dikompilasi di lingkungan ini; jalankan CI / Gradle dan cek di perangkat.
