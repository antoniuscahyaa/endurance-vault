# EnduranceVault Native 0.5.39: layar detail aktivitas baru

Versi 0.5.39, version code 53.

## Perubahan
- Layar detail aktivitas mengikuti desain baru: header "EASY · 4 NOV" dengan subjudul monospace, tab pil di atas, hero jarak besar dengan chip rencana, waktu gerak dan pace di kanan.
- Kartu 2×2: Speed (GAP pace, Effort pace), Heart (Avg HR, Max HR), Elevation (gain, loss), Form. Est. VO2max sengaja tidak dicantumkan.
- Kartu panjang baterai jam (terpakai, awal → akhir, %/jam) dengan total waktu aktivitas termasuk jeda di kanan. Di bawahnya kartu panjang berukuran sama berisi Fastest km dan Vertical speed, tepat di atas "How it felt". Gear ada di bawah "How it felt". "How it felt" (skala 1–10, tanpa teks "light/hard", disimpan ke aktivitas, ketuk lagi untuk menghapus) ada di tab Summary. Rute tampil setelahnya.
- Effort pace baru: GAP × (1 − k × (suhu terasa − 15 °C)). k adalah sensitivitas panasmu, dihitung dari riwayat lari (kecepatan GAP per HR relatif LTHR terhadap suhu). Butuh minimal 8 lari dengan rentang suhu 4 °C; sebelum itu dipakai 0,13% per °C. Tampil dengan awalan "~".
- Cek HR vs rasa: rasa 1–2 = Z1, 3–4 = Z2, 5–6 = Z3, 7–8 = Z4, 9–10 = Z5 dari Zones.cuts pribadi.
- Kolom baru `feel10` (migrasi DB 4→5). Kolom lama `feel` (1..5) tetap diisi (n+1)/2 agar kalibrasi readiness, evaluasi sepeda, dan cadangan web tetap berjalan. Data lama (hanya `feel`) ditampilkan sebagai 2n−1 sampai dipilih ulang. Cadangan native menyimpan `feel10`.
- Tab 2 dan 3 tidak lagi menampilkan hero dan kartu di atasnya.
- Teks bagian yang diubah memakai bahasa Inggris seperti desain; semua ada di `DL` (ActivityDetailHeader.kt).

## Kode
- Baru: `domain/EffortPace.kt`, `domain/FeelCheck.kt`, `ui/screens/ActivityDetailHeader.kt`, `EffortPaceTest.kt`.
- `ActivityDao.setFeel`, `MainViewModel.setActivityFeel`; `ActivityDetailScreen` menerima `onSetFeel`.

## Validasi
- Gradle dan uji di perangkat belum dijalankan di lingkungan ini (tanpa kompiler). Jalankan CI lalu cek tampilan.
- Peta dasar OSM seperti di desain belum ada; rute masih digambar sebagai garis tanpa peta.

- Vertical speed hanya tampil bila gain/100 melebihi 15% jarak (100 m naik ≈ 1 km datar); 10 km → di atas 150 m. Bila tidak, kartu hanya berisi Fastest km, tanpa switch.
