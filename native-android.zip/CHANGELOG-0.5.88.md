# 0.5.88

## Cuaca di detail aktivitas (halaman Ringkasan)
- Cuaca kini diambil **otomatis** dari Open-Meteo untuk setiap sesi yang punya GPS (titik awal + jam lari), lalu disimpan ke berkas detail sehingga berikutnya tidak perlu internet. Sesi > 85 hari memakai arsip reanalisis, sesi baru memakai model terkini.
- Rincian baru: arah angin, hembusan, tutupan awan, tekanan, titik embun, dan **deret per jam** (jam lari disorot; jam memakai zona waktu lokasi sesi).
- Sesi lama yang sudah punya cuaca tetapi tanpa rincian per jam diperbarui sekali otomatis; suhu sensor jam (`dv`) dipertahankan.
- Bila gagal (offline / tanpa GPS), tampil pesan dan tombol **Ambil cuaca / Coba lagi**; tidak ada loop otomatis.
- Efek samping baik: Effort pace yang memakai suhu/cuaca kini ikut terisi.

## Kartu baterai (WATCH BATTERY USED)
- Penyebab kartu tidak pernah muncul: kunci `bat` di berkas detail tidak pernah ditulis oleh kode native. Sekarang dihitung dari log baterai jam (`WatchDock.batSession`) memakai waktu mulai sesi (`watchStart`) dan lama sesi, lalu disimpan ke berkas detail (log hanya menyimpan 60 hari).
- Kartu hanya muncul untuk sesi dari jam yang belum dipangkas (crop) dan bila ada cuplikan baterai ≤ 90 menit dari awal dan akhir sesi, tanpa tanda pengisian daya. Cuplikan dicatat saat aplikasi membaca status jam, jadi sesi yang tidak ada bacaannya di sekitar waktu itu memang tidak punya kartu.

## Catatan
- Kode belum dikompilasi di sini. Mohon rebuild dan kirim log CI bila ada error.
- Terjemahan Inggris ditambahkan di `assets/i18n/en.tsv`.

## Perbaikan build (dari log CI)
- `WxHour` bentrok dengan kelas bernama sama di WeatherModel.kt (Redeclaration); kelas cuaca per jam sesi diganti nama menjadi `RunWxHour`.
- Impor `androidx.compose.ui.input.nestedScroll.*` di AppRoot.kt dan AiChatFab.kt salah huruf besar; paket yang benar `nestedscroll` (semua huruf kecil).
