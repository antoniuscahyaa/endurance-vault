# Tema: kartu abu muda di semua tempat

Tampilan
- Latar utama tetap putih, aksen tetap orange (#EA5F0A). Palet netral kembali seperti semula.
- Semua kartu memakai abu muda (`surfaceVariant`): panel umum (`EvPanel`), layar Huawei Watch (panel, kartu perangkat, FeatureTile), detail jam, kartu Recap/Fitness/Load/Routes, tile pengaturan, kartu rencana (Plan), kartu Training Load, dan kartu di dialog Readiness. Sebelumnya sebagian berwarna putih dengan garis atau orange transparan.
- Kartu greeting (`GreetingWeatherCard`) dan kartu grafik plan (ringkasan Training Plan di `PlanOverviewScreen` dan `PlanSettingsPanel`) tetap memakai orange transparan (`cardTint`). Di layar Jadwal, kartu ringkasan rencana minggu (`WkPlanCard`) dan statistik minggu (`WkStatsCard`) juga orange transparan lewat parameter `tinted` di `WkCard`; kartu hari tetap abu.
- Kartu yang dipilih (bahasa, mode tema, tile jam) tetap abu muda; penandanya garis orange dan teks orange.
- Bayangan kartu profil dihapus agar konsisten flat.

Berkas: `ui/theme/Theme.kt`, `EvUi.kt`, `HuaweiWatchSection.kt`, `WatchDockScreen.kt`, `ProfileScreen.kt`, `RecapTab.kt`, `FitnessTab.kt`, `RoutesTab.kt`, `LoadTab.kt`, `PlanOverviewScreen.kt`, `PlanSettingsPanel.kt`, `TrainingLoadSection.kt`, `ReadinessDetailDialog.kt`, `SettingsHomeGrid.kt`, `ExploreScreen.kt`, `AppRoot.kt`, `themes.xml`.
