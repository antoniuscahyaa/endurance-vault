# Pratinjau hidup (setelah 0.5.97)

## Pratinjau hidup di Video rute 3D, Video Trail 3D, dan Video HUD
Tombol **putar/jeda** di kiri slider posisi pratinjau. Sebelumnya pratinjau hanya bingkai diam yang digeser dengan slider.

- **Video rute 3D dan Video Trail 3D**: pratinjau diputar sesuai waktu nyata (lama video mengikuti slider durasi) dan berulang dari awal. Bingkai dirender terus-menerus di thread GL pratinjau; bila perangkat tidak sanggup 30 fps, bingkai dilewati dan waktu tidak melambat. Pengaturan dibaca ulang tiap bingkai, jadi mengubah kemiringan, warna, tata letak, dan sebagainya terlihat langsung saat memutar.
- **Video HUD**: video asli diputar lewat `VideoView` dan HUD digambar ulang tiap bingkai di atasnya menurut posisi putar, memakai `HudPainter` dan nilai yang sama dengan render akhir. Offset dan gaya HUD bisa diubah saat memutar. Suara pratinjau mati secara bawaan (chip **Dengar suara di pratinjau** di bagian Suara). Menggeser slider saat memutar melompat ke posisi itu tanpa berhenti.
- Menjeda (atau menggeser slider pada Video rute/Trail, atau meninggalkan aplikasi) kembali ke bingkai diam di posisi terakhir; slider dan tombol Foto bingkai bekerja seperti sebelumnya.
- Tidak ada izin atau dependensi baru.

### Teknis
- Berubah: `ui/screens/{RouteVideoScreen,TrailVideoScreen,HudVideoScreen,VideoUiParts}.kt`, `i18n/en.tsv` (dua string baru).
- Baru di `VideoUiParts.kt`: `PreviewControls`, `PauseOnBackground`, `runPreviewLoop`.
- `RouteVideoScreen`: penyusunan bingkai + panel data dipindah ke fungsi `routeCompose` yang dipakai bingkai diam dan loop hidup.

### Catatan
- Kode **belum dikompilasi dan belum dijalankan di perangkat** (sama seperti 0.5.97). Mohon rebuild dan kirim log CI atau tangkapan layar bila ada error.
- Pratinjau HUD memakai `VideoView`; bila video tidak bisa diputar di perangkat, muncul catatan dan bingkai diam tetap bisa dipakai. Video HDR/10-bit belum diuji.
