# 0.5.100

## Editor video berkategori (Video rute 3D, Video Trail 3D, Video HUD)
Pengaturan tidak lagi satu daftar panjang ke bawah. Di bawah pratinjau ada **baris tab**; **geser kiri/kanan** (atau ketuk tab) untuk pindah kategori. Tiap kategori punya gulir vertikalnya sendiri yang pendek.
- **Video rute 3D**: Tata letak · Data · Rute · Peta 3D · Format · Buat video
- **Video Trail 3D**: Teks & data · Penanda · Bentuk · Kamera · Gaya · Waktu & format · Buat video
- **Video HUD**: Sinkron · Tampilan · Buat video
Peringatan (mis. data elevasi belum terunduh) tetap tampil di atas tab.

## Zoom pratinjau
Pratinjau di ketiga layar bisa di-zoom hanya untuk memeriksa detail (tidak mengubah hasil video): **cubit** untuk zoom, **seret** untuk menggeser, **ketuk dua kali** untuk 2,5× / kembali. Tombol kecil **− 1.0× +** di pojok kanan bawah pratinjau; ketuk angkanya untuk kembali ke 1×. Berfungsi juga saat pratinjau hidup diputar, termasuk video HUD.

## Nama daerah dengan pin (Video rute 3D dan Video Trail 3D)
Pin kecil bernama desa, kelurahan, kota kecil, atau puncak di sekitar rute (OpenStreetMap lewat Overpass, dicache 30 hari). Supaya tidak terlihat seperti tempelan:
- Pin **menempel di permukaan medan** pada ketinggian aslinya, bergerak bersama kamera, dan punya bayangan lonjong di tanah serta kepala pin berkilau (tampak 3D).
- **Mengecil bila jauh**, **memudar bila tertutup bukit/relief**, dan memudar di tepi bingkai.
- Pada angka berjalan, pin **muncul menjelang pelari tiba** di dekatnya (nama dekat start sudah tampak dari awal).
- Pemilihan: jenis penting dan dekat rute lebih dulu, saling berjauhan; menghindari bendera, judul, grafik, dan data. Yang tidak mendapat tempat dilewati, tidak ditumpuk.
- Huruf kecil (lebih kecil dari label bendera), halo tipis tanpa kotak.
- Pengaturan: **Nama daerah** (tab Peta 3D / Penanda): sakelar dan jumlah maksimal. Offline dan tanpa cache = tanpa nama, video tetap jadi.

### Teknis
- Baru: `data/PlaceLabels.kt`, `ui/video/PlacePins.kt`, uji `PlaceLabelsTest`.
- `TerrainScene.places`; `TerrainBuilder` mengambil nama sesudah elevasi (batas waktu 9 dtk, gagal = kosong).
- `TerrainGl.projectPlaces` (proyeksi + uji garis pandang ke grid tinggi), `PreviewFrame.places`; `TrailGl.placeDepth`; `TrailPainter.placePins`.
- `RouteVideoPrefs`/`TrailPrefs`: `showPlaces`, `placeCount` (pengaturan lama memakai bawaan).
- `VideoUiParts.kt`: `EditorPager`, `EditorTab`, `PreviewZoom`, `ZoomablePreview`.

### Catatan
- Kode **belum dikompilasi dan belum dijalankan di perangkat**. Mohon rebuild lewat CI dan kirim log bila ada error.
- Zoom pratinjau memperbesar bingkai pratinjau yang ada (bukan merender ulang lebih tajam), jadi detail halus tampak sedikit lunak di zoom tinggi.
