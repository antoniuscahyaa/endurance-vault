# EnduranceVault Native 0.5.2

- Package: `com.endurancevault.app`
- Version code: 16
- UI parity: permukaan logam bergradasi, dock kapsul dengan ikon web, kartu induk, hero Hari ini dan Jadwal, baris hari bergaya web, tombol api, pil fase.
- Tidak ada perubahan rumus latihan atau model data.
