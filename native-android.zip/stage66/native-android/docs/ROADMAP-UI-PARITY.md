# UI parity roadmap

1. Stage 6.6.1: palette, typography scale, shapes and initial floating dock.
2. Stage 6.6.2: consistent native dock, reusable panels/groups/metric tiles, screen grouping and volume chart.
3. Stage 6.6.3 (selesai, belum diverifikasi di perangkat): permukaan logam, dock, kartu induk, hero Hari ini/Jadwal, baris hari, hero Profil.
4. Next pass: restore the old app's distinct Dashboard / Profile / Watch / Week / Schedule information architecture, profile subgroups, progress horizontal pager, schedule phase grouping, and skin selector. Requires full behavior mapping rather than duplicating the four existing routes.
5. Visual regression: capture old and native screens at matching viewport sizes and compare spacing, hierarchy, typography, chart styles, panel density, and dock placement.
6. Only after UI parity is accepted: Stage 6.7 Share, Media & Video.
