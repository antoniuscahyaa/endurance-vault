# Stage 6.6.3 — Native UI parity (permukaan logam, dock, hero, baris hari)

Version: 0.5.2 (versionCode 16)

## Sumber acuan
`src/styles/ev-skin.css` (token `--metal`, `--metal-soft`, `--metal-deep`, `--fire`, hero Jadwal/Atur, `.day`, `details.wk`, `.pill`, `.seg`, dock),
`src/styles/dock.css`, `src/styles/compact/10-jadwal-hero.css`, markup `#v-jadwal` dan `.tabs` di `src/index.template.html`.
Tetap Jetpack Compose; tidak ada WebView.

## Yang diubah
- **Token gradien** (`ui/theme/Theme.kt`): `EvPalette` menyimpan gradien logam, api, hero, pil fase, dan strip jenis sesi untuk mode terang dan gelap (`Ev.palette`).
- **Primitif** (`ui/screens/EvUi.kt`): `EvPanel` (logam + sorot tepi atas + bayangan; nada Metal/Soft/Deep/Hero), `EvPill`, `EvHeroChip`, `EvSegmented`, `EvProgressBar`, `EvDayRow` (strip warna kiri, blok tanggal, km kanan, cincin hari ini), `EvFormGroup`, `EvPageHeader`.
  `Button`, `OutlinedButton`, dan `FilterChip` didefinisikan ulang di package `screens` sehingga seluruh pemanggil lama otomatis memakai tombol oranye api / logam / chip api tanpa mengubah logika.
- **Dock** (`AppRoot.kt`): kapsul logam melayang, "Hari ini" sebagai blok sendiri (aktif = api penuh) dengan pembatas tipis, tab lain aktif = aksen + ikon pil cekung + garis api di bawah label, label selalu tampil. Ikon diambil dari path SVG web (`ui/theme/EvIcons.kt`).
- **Kartu induk**: semua halaman duduk di satu kartu logam besar (radius 26) yang berhenti di atas dock, di atas latar `#0B0C0F` dengan sorot kiri-atas, seperti `.content-card`.
- **Hari ini**: hero gelap + cahaya api (pil fase, minggu ke-N, angka km besar), tombol api "Catat lari", panel target minggu, daftar "Minggu ini" bergaya `.day`.
- **Jadwal**: hero beban mingguan (chip jenis rencana, rata-rata, panjang rencana, total jarak, grafik batang per fase dengan penanda minggu berjalan, bisa diketuk untuk melompat ke minggu), filter fase segmented, akordeon minggu (lencana M#, rentang tanggal, pil fase, strength count, km) dengan baris hari bergaya web.
- **Progres**: tile metrik, bar progres api, grafik volume bergradasi, riwayat sebagai baris hari.
- **Profil**: hero rencana, grup formulir dalam panel logam, switch dan chip bergaya EV.
- Training Load, Companion, Huawei Watch, Online Services: kartu Material diganti `EvPanel`.

## Tidak diubah
Perhitungan latihan, model data, alur Huawei/cuaca/A-GPS/notifikasi/AI Coach, dan golden test.

## Batasan yang disengaja
- Belum diverifikasi lewat kompilasi Gradle atau perangkat fisik di lingkungan penyusunan ini; jalankan CI/build lalu bandingkan screenshot.
- Font Poppins belum dibundel (aset dan lisensi belum ada); tetap sans-serif sistem.
- Skin pilihan lain (Trail, Grafit, Pulse, Puncak, Soft Clay) belum tersedia di native.
- Tab "Jam" dan "Minggu" milik web tidak dibuat sebagai tujuan terpisah; fitur jam tetap di Profil, jadi dock native tetap empat tujuan.
- Fitur web yang belum punya data native (mode grafik Jam/Tanjakan/Turunan, peringatan lonjakan beban, pager Progres, riwayat per minggu) belum ditampilkan.
