package com.endurancevault.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.navArgument
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.endurancevault.app.ui.screens.ActivityDetailScreen
import com.endurancevault.app.ui.screens.ProfileScreen
import com.endurancevault.app.ui.screens.ProgressScreen
import com.endurancevault.app.ui.screens.ScheduleScreen
import com.endurancevault.app.ui.screens.TodayScreen
import com.endurancevault.app.ui.theme.Ev
import com.endurancevault.app.ui.theme.EvIcons

/** Empat tujuan fungsional native. Ikon dan urutan mengikuti dock web (Hari ini di kiri, dipisah garis tipis). */
private enum class Tab(val route: String, val label: String, val icon: ImageVector, val iconOn: ImageVector) {
    Today("today", "Hari ini", EvIcons.Home, EvIcons.HomeOn),
    Profile("profile", "Profil", EvIcons.Runner, EvIcons.RunnerOn),
    Progress("progress", "Progres", EvIcons.Trend, EvIcons.TrendOn),
    Schedule("schedule", "Jadwal", EvIcons.Calendar, EvIcons.CalendarOn),
}

/** Kapsul dock logam melayang: Hari ini = blok sendiri (aktif = api penuh), tab lain aktif = aksen + garis bawah label. */
@Composable
private fun EvDock(current: String?, onSelect: (Tab) -> Unit) {
    val ev = Ev.palette
    val shape = RoundedCornerShape(26.dp)
    Box(Modifier.fillMaxWidth().padding(horizontal = 12.dp).padding(top = 4.dp, bottom = 6.dp)) {
        Row(
            Modifier.fillMaxWidth().height(58.dp)
                .shadow(14.dp, shape, clip = false)
                .clip(shape).background(ev.metal, shape)
                .drawBehind {
                    val inset = 18.dp.toPx()
                    drawLine(ev.highlight, Offset(inset, 0.5f), Offset(size.width - inset, 0.5f), 1.dp.toPx())
                }
                .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant), shape)
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Tab.entries.forEachIndexed { index, t ->
                val selected = current == t.route
                val home = index == 0
                DockItem(t, selected, home, Modifier.weight(if (home) 1.2f else 1f).fillMaxHeight()) { onSelect(t) }
                if (home) Box(Modifier.width(1.dp).height(30.dp).background(Brush.verticalGradient(listOf(Color.Transparent, MaterialTheme.colorScheme.outlineVariant, Color.Transparent))))
            }
        }
    }
}

@Composable
private fun DockItem(t: Tab, selected: Boolean, home: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val ev = Ev.palette
    val shape = RoundedCornerShape(20.dp)
    val accent = MaterialTheme.colorScheme.primary
    val tint = when {
        home && selected -> Color.White
        selected -> accent
        home -> accent
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    var m = modifier.clip(shape)
    m = when {
        home && selected -> m.background(ev.fire, shape).border(1.dp, ev.fireEdge, shape)
        home -> m.background(ev.metal, shape).border(1.dp, MaterialTheme.colorScheme.outlineVariant, shape)
        else -> m
    }
    Column(
        m.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, role = Role.Tab, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            Modifier.width(38.dp).height(28.dp)
                .then(if (selected && !home) Modifier.clip(RoundedCornerShape(99.dp)).background(ev.metalDeep) else Modifier),
            contentAlignment = Alignment.Center,
        ) { Icon(if (selected) t.iconOn else t.icon, contentDescription = t.label, tint = tint, modifier = Modifier.width(20.dp).height(20.dp)) }
        Text(t.label, style = MaterialTheme.typography.labelMedium, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, color = tint, maxLines = 1)
        Box(
            Modifier.padding(top = 2.dp).width(if (selected && !home) 22.dp else 0.dp).height(2.dp)
                .clip(RoundedCornerShape(2.dp)).background(ev.fire),
        )
    }
}

@Composable
fun AppRoot(vm: MainViewModel = viewModel()) {
    val nav = rememberNavController()
    val state by vm.state.collectAsState()
    val current = nav.currentBackStackEntryAsState().value?.destination?.route

    val bg = MaterialTheme.colorScheme.background
    val hi = if (Ev.palette.dark) Color(0xFF3B3F47) else Color(0xFFFFFFFF)
    Box(
        Modifier.fillMaxSize().background(bg).drawBehind {
            // sorot lembut kiri-atas seperti `body` di ev-skin.css
            drawRect(Brush.radialGradient(listOf(hi.copy(alpha = .55f), Color.Transparent), center = Offset(size.width * .15f, -size.height * .1f), radius = size.width * 1.1f))
        },
    ) {
    Scaffold(
        containerColor = Color.Transparent,
        contentColor = MaterialTheme.colorScheme.onBackground,
        bottomBar = {
            EvDock(current) { t ->
                nav.navigate(t.route) {
                    popUpTo(Tab.Today.route) { saveState = true }
                    launchSingleTop = true
                    restoreState = true
                }
            }
        },
    ) { pad ->
        // Kartu induk (`.content-card`): semua halaman duduk di dalam satu kartu logam besar yang berhenti tepat di atas dock.
        Box(
            Modifier.padding(pad).padding(horizontal = 12.dp).fillMaxSize()
                .shadow(8.dp, RoundedCornerShape(26.dp), clip = false)
                .clip(RoundedCornerShape(26.dp)).background(Ev.palette.metalSoft, RoundedCornerShape(26.dp))
                .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant), RoundedCornerShape(26.dp)),
        ) {
        NavHost(nav, startDestination = Tab.Today.route, modifier = Modifier.fillMaxSize()) {
            composable(Tab.Today.route) { TodayScreen(state, vm::addActivity) }
            composable(Tab.Schedule.route) { ScheduleScreen(state) }
            composable(Tab.Progress.route) {
                val msg by vm.trackMsg.collectAsState()
                ProgressScreen(state, vm::deleteActivity, { id -> nav.navigate("activity/$id") }, vm::importTracks, msg)
            }
            composable("activity/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
                ActivityDetailScreen(state, e.arguments?.getLong("id") ?: -1L, vm::detailOf) { nav.popBackStack() }
            }
            composable(Tab.Profile.route) {
                val imp by vm.importState.collectAsState()
                val watchMsg by vm.watchMessage.collectAsState()
                val watchSyncing by vm.watchSyncing.collectAsState()
                val watchAdvancedMessage by vm.watchAdvancedMessage.collectAsState()
                val liveHr by vm.liveHrJson.collectAsState()
                val weather by vm.weatherMessage.collectAsState()
                val weatherBusy by vm.weatherBusy.collectAsState()
                val weatherLat by vm.weatherLat.collectAsState()
                val weatherLon by vm.weatherLon.collectAsState()
                val weatherWatchStatus by vm.weatherWatchStatus.collectAsState()
                val agpsStatus by vm.agpsStatus.collectAsState()
                val notifyStatus by vm.notifyStatus.collectAsState()
                val aiStatus by vm.aiStatus.collectAsState()
                val aiMessages by vm.aiMessages.collectAsState()
                val aiBusy by vm.aiBusy.collectAsState()
                ProfileScreen(
                    state, vm::saveSettings, imp, vm::startImport, vm::confirmImport, vm::dismissImport,
                    vm::saveDaily, vm::saveGear, vm::deleteGear,
                    watchMsg, vm::connectWatch, vm::disconnectWatch, vm::forgetAndReconnectWatch, vm::syncWatch, watchSyncing,
                    watchAdvancedMessage, liveHr, vm::refreshLiveHr, vm::setLiveHr, vm::syncWatchHrZones,
                    vm::pushStructuredWorkout, vm::pushGpxRoute,
                    weather, weatherBusy, weatherLat, weatherLon, { lat, lon -> vm.fetchWeather(lat, lon) }, { q -> vm.searchWeatherCity(q) }, vm::useCurrentLocation, { lat, lon, name -> vm.sendWeatherToWatch(lat, lon, name) },
                    weatherWatchStatus, agpsStatus, { enabled, mirror -> vm.setAgps(enabled, mirror) }, { vm.testAgps() },
                    notifyStatus, { enabled, quiet, start, end, screenOff, apps -> vm.setWatchNotifications(enabled, quiet, start, end, screenOff, apps) }, { vm.testWatchNotification() },
                    aiStatus, aiMessages, vm::saveAiKey, vm::sendAiQuestion, aiBusy,
                )
            }
        }
        }
    }
    }
}
