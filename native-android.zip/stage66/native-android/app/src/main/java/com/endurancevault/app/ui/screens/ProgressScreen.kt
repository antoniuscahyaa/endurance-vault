package com.endurancevault.app.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.Canvas
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.endurancevault.app.domain.ActivityAnalytics
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.ui.UiState
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import com.endurancevault.app.domain.Kinds
import com.endurancevault.app.ui.theme.Ev
import java.time.LocalDate
import java.time.DayOfWeek

@Composable
fun ProgressScreen(
    state: UiState, onDelete: (Long) -> Unit, onOpen: (Long) -> Unit,
    onImportTracks: (List<Uri>) -> Unit, trackMsg: String?,
) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> if (uris.isNotEmpty()) onImportTracks(uris) }
    val summary = ActivityAnalytics.summarize(state.activities)
    val weeks = (state.plan as? PlanOutcome.Ok)?.weeks.orEmpty()
    val thisWeek = weeks.firstOrNull { !LocalDate.now().isBefore(it.start) && LocalDate.now().isBefore(it.start.plusDays(7)) }
    val done = thisWeek?.let { w ->
        state.activities.filter {
            if (it.type == "bike") return@filter false
            val d = LocalDate.parse(it.dateIso); !d.isBefore(w.start) && d.isBefore(w.start.plusDays(7))
        }.sumOf { it.km }
    } ?: 0.0

    LazyColumn(Modifier.padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { EvPageHeader("PERFORMA", "Progres", Modifier.padding(top = 14.dp)) }
        item { TrainingLoadSection(state) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                EvGroupTitle("Ringkasan performa", "Rekap aktivitas yang tersimpan")
                EvMetricRow(
                    listOf(
                        "Total lari" to "${summary.runCount} sesi",
                        "Total jarak" to "${fmtKmUi(summary.totalKm)} km",
                        "Terjauh" to (summary.longestKm?.let { "${fmtKmUi(it)} km" } ?: "–"),
                    ),
                )
                EvMetricRow(
                    listOf(
                        "Pace rata-rata terbaik" to (summary.fastestAvgPace?.let { com.endurancevault.app.domain.Js.paceStr(it) } ?: "–"),
                        "28 hari terakhir" to "${fmtKmUi(summary.last28Km)} km · ${summary.last28Runs} sesi",
                    ),
                )
                Text("Statistik dihitung dari aktivitas lari yang tersimpan; bukan prediksi PR lomba.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (thisWeek != null) item {
            EvPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    EvGroupTitle("Target minggu ini", "Realisasi terhadap rencana latihan")
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
                        Text("%.1f".format(done).replace('.', ','), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text(" dari ${fmtKmUi(thisWeek.km)} km", Modifier.padding(bottom = 3.dp), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    EvProgressBar(if (thisWeek.km > 0) (done / thisWeek.km).toFloat() else 0f)
                }
            }
        }
        item {
            EvPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    EvGroupTitle("Volume lari", "Jarak mingguan · 8 pekan terakhir")
                    ActivityVolumeChart(state.activities)
                }
            }
        }
        item {
            OutlinedButton(
                onClick = { picker.launch(arrayOf("application/octet-stream", "application/gpx+xml", "application/vnd.garmin.tcx+xml", "text/xml", "application/xml", "*/*")) },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Impor FIT / GPX / TCX") }
            trackMsg?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp)) }
        }
        item { EvGroupTitle("Riwayat aktivitas", "Pilih aktivitas untuk melihat detail dan grafik") }
        items(state.activities, key = { it.id }) { a ->
            val date = runCatching { LocalDate.parse(a.dateIso) }.getOrNull()
            val bike = a.type == "bike"
            EvDayRow(
                dow = date?.dayOfWeek?.getDisplayName(java.time.format.TextStyle.SHORT, java.util.Locale("id", "ID")) ?: "–",
                dayNum = date?.dayOfMonth ?: 0,
                title = a.name.ifBlank { if (bike) "Sepeda" else "Lari" } + (if (a.detailFile != null) " · rute" else ""),
                km = "%.1f".format(a.km).replace('.', ','),
                kind = if (bike) Kinds.EASY else Kinds.QUALITY,
                detail = "${a.dateIso} · ${a.durationSec / 60} menit" + (a.avgHr?.let { " · HR $it" } ?: "") + (if (bike) " · sepeda" else ""),
                modifier = Modifier.clickable { onOpen(a.id) },
            ) {
                TextButton(onClick = { onDelete(a.id) }, contentPadding = PaddingValues(horizontal = 0.dp, vertical = 0.dp)) {
                    Text("Hapus", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.error)
                }
            }
        }
        item { Spacer(Modifier.height(14.dp)) }
    }
}


@Composable
private fun ActivityVolumeChart(activities: List<com.endurancevault.app.data.ActivityEntity>) {
    val today = LocalDate.now()
    val currentMonday = today.with(DayOfWeek.MONDAY)
    val starts = (7 downTo 0).map { currentMonday.minusWeeks(it.toLong()) }
    val values = starts.map { start ->
        activities.filter { a ->
            if (a.type == "bike") return@filter false
            val date = runCatching { LocalDate.parse(a.dateIso) }.getOrNull() ?: return@filter false
            !date.isBefore(start) && date.isBefore(start.plusDays(7))
        }.sumOf { it.km }
    }
    val maxValue = (values.maxOrNull() ?: 0.0).coerceAtLeast(1.0)
    val dyBar = Ev.palette.dyBar
    val muted = MaterialTheme.colorScheme.outlineVariant
    Canvas(Modifier.fillMaxWidth().height(116.dp)) {
        val left = 4.dp.toPx(); val right = 4.dp.toPx()
        val top = 8.dp.toPx(); val bottom = 8.dp.toPx()
        val usableW = size.width - left - right
        val usableH = size.height - top - bottom
        repeat(3) { i ->
            val y = top + usableH * (i / 2f)
            drawLine(muted.copy(alpha = .55f), Offset(left, y), Offset(size.width-right, y), 1.dp.toPx())
        }
        val slot = usableW / values.size
        values.forEachIndexed { i, value ->
            val h = (value / maxValue).toFloat() * usableH
            val barW = slot * .54f
            val x = left + slot * i + (slot - barW) / 2f
            val bh = h.coerceAtLeast(2.dp.toPx())
            val y0 = top + usableH - bh
            drawRoundRect(
                brush = if (i == values.lastIndex) Brush.verticalGradient(listOf(Color(0xFFFBA81B), Color(0xFFF2500A)), startY = y0, endY = y0 + bh)
                else Brush.verticalGradient(listOf(dyBar.copy(alpha = .75f), dyBar), startY = y0, endY = y0 + bh),
                topLeft = Offset(x, y0),
                size = androidx.compose.ui.geometry.Size(barW, bh),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(5.dp.toPx()),
            )
        }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text("8 pekan lalu", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("Pekan ini", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
    }
    Text("${fmtKmUi(values.last())} km pekan ini", style = MaterialTheme.typography.titleSmall)
}
