package com.endurancevault.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.endurancevault.app.domain.Kinds
import com.endurancevault.app.domain.PWeek
import com.endurancevault.app.domain.Phases
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.ui.UiState
import com.endurancevault.app.ui.theme.Ev
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

private val ID = Locale("id", "ID")

internal fun phaseLabel(p: String, rec: Boolean) = when {
    rec -> "Pemulihan"
    p == Phases.BASE -> "Fondasi"
    p == Phases.BUILD -> "Bangun"
    p == Phases.PEAK -> "Puncak"
    else -> "Taper"
}

private fun typeLabel(r: String) = when (r) {
    "5k" -> "5K"; "10k" -> "10K"; "hm" -> "Half marathon"; "fm" -> "Marathon"
    "ultra", "ultrar" -> "Ultra / trail"; "pb" -> "Siklus PB"; else -> "Tanpa lomba"
}

private fun fmtD(d: LocalDate) = "${d.dayOfMonth} ${d.month.getDisplayName(TextStyle.SHORT, ID)}"
private fun strCount(w: PWeek) = w.days.sumOf { listOfNotNull(it.str, it.ank, it.up).size }

private val PHASE_FILTERS = listOf("Semua", "Fondasi", "Bangun", "Puncak", "Taper")
private val PHASE_KEYS = listOf(null, Phases.BASE, Phases.BUILD, Phases.PEAK, Phases.TAPER)

/** Header halaman + hero beban mingguan + filter fase + akordeon minggu, mengikuti `#v-jadwal` di versi web. */
@Composable
fun ScheduleScreen(state: UiState) {
    when (val p = state.plan) {
        is PlanOutcome.Err -> Text(p.message, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.error)
        is PlanOutcome.Ok -> {
            val today = LocalDate.now()
            val weeks = p.weeks
            val cur = weeks.indexOfFirst { !today.isBefore(it.start) && !today.isAfter(it.end) }
            val openWeeks = remember { mutableStateListOf<Int>().apply { if (cur >= 0) add(weeks[cur].i) } }
            var filter by remember { mutableIntStateOf(0) }
            var target by remember { mutableIntStateOf(-1) }
            val listState = rememberLazyListState()
            val shown = PHASE_KEYS[filter].let { k -> if (k == null) weeks else weeks.filter { it.phase == k } }

            LaunchedEffect(target) {
                if (target >= 0) {
                    val pos = weeks.indexOfFirst { it.i == target }
                    if (pos >= 0) listState.animateScrollToItem(HEADER_ITEMS + pos)
                    target = -1
                }
            }

            LazyColumn(Modifier.padding(horizontal = 14.dp), state = listState, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item { EvPageHeader("PERENCANAAN", "Jadwal latihan", Modifier.padding(top = 14.dp)) }
                item {
                    ScheduleHero(state, weeks, cur) { idx ->
                        filter = 0
                        if (idx !in openWeeks) openWeeks.add(idx)
                        target = idx
                    }
                }
                item { EvSegmented(PHASE_FILTERS, filter, { filter = it }) }
                item {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
                        Box(Modifier.weight(1f)) { EvGroupTitle("Semua minggu") }
                        Text("${shown.size} minggu", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                itemsIndexed(shown, key = { _, w -> w.i }) { _, w ->
                    WeekCard(w, isNow = w.i == weeks.getOrNull(cur)?.i, today = today, open = w.i in openWeeks) {
                        if (w.i in openWeeks) openWeeks.remove(w.i) else openWeeks.add(w.i)
                    }
                }
                item { Spacer(Modifier.height(14.dp)) }
            }
        }
    }
}

private const val HEADER_ITEMS = 4

@Composable
private fun ScheduleHero(state: UiState, weeks: List<PWeek>, cur: Int, onPick: (Int) -> Unit) {
    val ev = Ev.palette
    val fg = ev.heroText
    val total = weeks.sumOf { it.km }
    val avg = if (weeks.isNotEmpty()) total / weeks.size else 0.0
    EvPanel(Modifier.fillMaxWidth(), tone = EvTone.Hero, shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                EvHeroChip(typeLabel(state.settings.rtype))
                EvHeroChip("${state.settings.days} hari lari", outlined = true)
                Spacer(Modifier.weight(1f))
                Text("rata-rata ${fmtKmUi(Math.round(avg * 10) / 10.0)} km/mgg", style = MaterialTheme.typography.labelSmall, color = fg.copy(alpha = .9f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                HeroNum("PANJANG RENCANA", "${weeks.size}", " minggu")
                HeroNum("TOTAL JARAK", fmtKmUi(Math.round(total).toDouble()), " km")
            }
            Text("KM PER MINGGU", style = MaterialTheme.typography.labelSmall, letterSpacing = 1.2.sp, color = fg.copy(alpha = .85f), modifier = Modifier.padding(top = 4.dp))
            WeekBars(weeks, cur, onPick)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Legend("Fondasi", fg.copy(alpha = .55f)); Legend("Bangun", fg.copy(alpha = .8f)); Legend("Puncak", fg); Legend("Taper", Color(0xFFFFC9A5))
            }
        }
    }
}

@Composable
private fun HeroNum(label: String, value: String, unit: String) {
    Column {
        Text(label, style = MaterialTheme.typography.labelSmall, letterSpacing = 1.2.sp, modifier = Modifier.alpha(.85f))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(value, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text(unit, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(bottom = 5.dp).alpha(.85f))
        }
    }
}

@Composable
private fun Legend(text: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(Modifier.size(8.dp).clip(RoundedCornerShape(2.dp)).background(color))
        Text(text, style = MaterialTheme.typography.labelSmall, modifier = Modifier.alpha(.95f))
    }
}

/** Grafik batang beban mingguan (`.jd-bars`): warna per fase di atas hero, titik penanda minggu berjalan, bisa diketuk. */
@Composable
private fun WeekBars(weeks: List<PWeek>, cur: Int, onPick: (Int) -> Unit) {
    val fg = Ev.palette.heroText
    val maxKm = (weeks.maxOfOrNull { it.km } ?: 0.0).coerceAtLeast(1.0)
    Canvas(
        Modifier.fillMaxWidth().height(98.dp).pointerInput(weeks) {
            detectTapGestures { o ->
                if (weeks.isEmpty()) return@detectTapGestures
                val slot = size.width.toFloat() / weeks.size
                onPick(weeks[(o.x / slot).toInt().coerceIn(0, weeks.lastIndex)].i)
            }
        },
    ) {
        if (weeks.isEmpty()) return@Canvas
        val gap = if (weeks.size > 26) 1.dp.toPx() else 3.dp.toPx()
        val slot = size.width / weeks.size
        val barW = (slot - gap).coerceAtLeast(1f)
        val areaH = size.height - 10.dp.toPx()
        weeks.forEachIndexed { i, w ->
            val base = when (w.phase) {
                Phases.BASE -> fg.copy(alpha = .55f)
                Phases.BUILD -> fg.copy(alpha = .8f)
                Phases.PEAK -> fg
                else -> Color(0xFFFFC9A5)
            }
            val h = ((w.km / maxKm).toFloat() * areaH).coerceAtLeast(3.dp.toPx())
            drawRoundRect(
                color = if (w.cut || w.rec) base.copy(alpha = base.alpha * .6f) else base,
                topLeft = Offset(slot * i + gap / 2f, areaH - h),
                size = Size(barW, h),
                cornerRadius = CornerRadius(3.dp.toPx()),
            )
            if (i == cur) drawCircle(fg, 2.dp.toPx(), Offset(slot * i + slot / 2f, areaH + 6.dp.toPx()))
        }
    }
}

/** Satu minggu (`details.wk`): lencana M#, rentang tanggal + pil fase, jarak; terbuka = daftar hari bergaya `.day`. */
@Composable
private fun WeekCard(w: PWeek, isNow: Boolean, today: LocalDate, open: Boolean, onToggle: () -> Unit) {
    val ev = Ev.palette
    val shape = RoundedCornerShape(18.dp)
    val sc = strCount(w)
    val note = listOfNotNull(
        when { w.race -> "Minggu lomba"; w.rec -> "Pemulihan pasca-lomba"; w.cut -> "Minggu pemulihan"; else -> null },
        if (sc > 0) "$sc× strength" else null,
    ).joinToString(" · ")
    EvPanel(
        Modifier.fillMaxWidth().then(if (isNow) Modifier.border(1.5.dp, MaterialTheme.colorScheme.primary, shape) else Modifier),
        tone = if (open) EvTone.Deep else EvTone.Metal, shape = shape,
    ) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(horizontal = 12.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Box(
                Modifier.width(42.dp).clip(RoundedCornerShape(99.dp)).background(ev.metalDeep).padding(vertical = 5.dp),
                contentAlignment = Alignment.Center,
            ) { Text("M${w.i + 1}", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, color = if (isNow) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface) }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${fmtD(w.start)} – ${fmtD(w.end)}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    EvPill(phaseLabel(w.phase, false), w.phase)
                }
                if (note.isNotBlank()) Text(note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(fmtKmUi(w.km), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("KM", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (open) {
            Column(Modifier.padding(start = 10.dp, end = 10.dp, bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                w.days.forEach { d ->
                    EvDayRow(
                        dow = d.date.dayOfWeek.getDisplayName(TextStyle.SHORT, ID), dayNum = d.date.dayOfMonth,
                        title = if (d.kind == Kinds.REST) "Libur" else d.title,
                        km = if (d.kind != Kinds.REST && d.km > 0) fmtKmUi(d.km) else null,
                        kind = d.kind, detail = d.detail.takeIf { it.isNotBlank() && d.kind != Kinds.REST },
                        today = d.date == today, dim = d.date.isBefore(today),
                    ) { SupportBlocks(d, expanded = true) }
                }
            }
        }
    }
}
