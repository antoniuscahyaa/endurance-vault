package com.endurancevault.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.domain.PDay
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.ui.UiState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.endurancevault.app.domain.Kinds
import com.endurancevault.app.domain.PWeek
import java.time.LocalDate
import java.time.format.TextStyle as JTextStyle
import java.util.Locale

private val ID_LOCALE = Locale("id", "ID")

private fun shortDow(d: LocalDate) = d.dayOfWeek.getDisplayName(JTextStyle.SHORT, ID_LOCALE)
private fun shortDate(d: LocalDate) = "${d.dayOfMonth} ${d.month.getDisplayName(JTextStyle.SHORT, ID_LOCALE)}"

@Composable
fun TodayScreen(state: UiState, onAdd: (ActivityEntity) -> Unit) {
    var dialog by remember { mutableStateOf(false) }
    val today = LocalDate.now()
    val plan = state.plan

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        EvPageHeader("ENDURANCEVAULT", "Hari ini") {
            Text("${shortDow(today)}, ${shortDate(today)}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        when (plan) {
            is PlanOutcome.Err -> Text(plan.message, color = MaterialTheme.colorScheme.error)
            is PlanOutcome.Ok -> {
                val week = plan.weeks.firstOrNull { !today.isBefore(it.start) && !today.isAfter(it.end) }
                val d: PDay? = plan.weeks.flatMap { it.days }.firstOrNull { it.date == today }
                if (d == null) {
                    EvPanel(Modifier.fillMaxWidth()) {
                        Text("Tidak ada sesi terjadwal hari ini.", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    TodayHero(d, week, plan.n)
                }
                Button(onClick = { dialog = true }, Modifier.fillMaxWidth()) { Text("Catat lari") }

                if (d != null && (d.str != null || d.ank != null || d.up != null || d.tm != null)) {
                    EvGroupTitle("Detail sesi", "Penunjang dan metode latihan hari ini")
                    SupportBlocks(d, expanded = true)
                }

                if (week != null) {
                    WeekProgressPanel(week, state)
                    EvGroupTitle("Minggu ini", "${shortDate(week.start)} – ${shortDate(week.end)}")
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        week.days.forEach { day ->
                            EvDayRow(
                                dow = shortDow(day.date), dayNum = day.date.dayOfMonth,
                                title = if (day.kind == Kinds.REST) "Libur" else day.title,
                                km = if (day.kind != Kinds.REST && day.km > 0) fmtKmUi(day.km) else null,
                                kind = day.kind, today = day.date == today, dim = day.date.isBefore(today),
                            ) { SupportBlocks(day, expanded = false) }
                        }
                    }
                }
            }
        }
    }

    if (dialog) LogRunDialog(onDismiss = { dialog = false }) { km, min, hr ->
        onAdd(ActivityEntity(dateIso = today.toString(), km = km, durationSec = min * 60, avgHr = hr))
        dialog = false
    }
}

/** Kartu hero logam gelap + cahaya api (padanan `.pf-hero`): fase, angka jarak besar, judul dan rincian sesi hari ini. */
@Composable
private fun TodayHero(d: PDay, week: PWeek?, totalWeeks: Int) {
    EvPanel(Modifier.fillMaxWidth(), tone = EvTone.Hero, shape = RoundedCornerShape(24.dp)) {
        Column(Modifier.padding(horizontal = 18.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                if (week != null) {
                    EvPill(phaseLabel(week.phase, week.rec), week.phase)
                    EvHeroChip("Minggu ${week.i + 1} / $totalWeeks", outlined = true)
                }
            }
            if (d.kind == Kinds.REST) {
                Text("Libur", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
                Text("Pemulihan adalah bagian dari latihan.", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.alpha(.8f))
            } else {
                Row(verticalAlignment = Alignment.Bottom, modifier = Modifier.padding(top = 2.dp)) {
                    Text(
                        if (d.km > 0) fmtKmUi(d.km) else "–",
                        style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold, letterSpacing = (-1).sp,
                    )
                    if (d.km > 0) Text(" km", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(bottom = 10.dp).alpha(.85f))
                }
                Text(d.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                if (d.detail.isNotBlank()) Text(d.detail, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.alpha(.85f))
            }
        }
    }
}

/** Target minggu ini: realisasi lari tersimpan terhadap rencana, tanpa data buatan. */
@Composable
private fun WeekProgressPanel(week: PWeek, state: UiState) {
    val done = state.activities.filter {
        if (it.type == "bike") return@filter false
        val dt = runCatching { LocalDate.parse(it.dateIso) }.getOrNull() ?: return@filter false
        !dt.isBefore(week.start) && !dt.isAfter(week.end)
    }.sumOf { it.km }
    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
                Text("TARGET MINGGU INI", Modifier.weight(1f), style = MaterialTheme.typography.labelMedium, letterSpacing = 1.2.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("${fmtKmUi(Math.round(done * 10) / 10.0)} / ${fmtKmUi(week.km)} km", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            EvProgressBar(if (week.km > 0) (done / week.km).toFloat() else 0f)
        }
    }
}

@Composable
private fun LogRunDialog(onDismiss: () -> Unit, onSave: (Double, Int, Int?) -> Unit) {
    var km by remember { mutableStateOf("") }
    var min by remember { mutableStateOf("") }
    var hr by remember { mutableStateOf("") }
    val num = KeyboardOptions(keyboardType = KeyboardType.Number)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Catat lari") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(km, { km = it }, label = { Text("Jarak (km)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                Row { OutlinedTextField(min, { min = it }, label = { Text("Durasi (menit)") }, keyboardOptions = num, singleLine = true) }
                OutlinedTextField(hr, { hr = it }, label = { Text("HR rata-rata (opsional)") }, keyboardOptions = num, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val k = km.replace(',', '.').toDoubleOrNull()
                val m = min.toIntOrNull()
                if (k != null && k > 0 && m != null && m > 0) onSave(k, m, hr.toIntOrNull())
            }) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
    )
}

internal fun fmtKmUi(x: Double): String =
    if (x == Math.floor(x)) x.toLong().toString() else "%.1f".format(x).replace('.', ',')
