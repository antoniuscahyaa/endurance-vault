package com.endurancevault.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.endurancevault.app.domain.Kinds
import com.endurancevault.app.domain.Phases
import com.endurancevault.app.ui.theme.Ev

/*
 * Primitif UI EnduranceVault (padanan ev-skin.css): permukaan logam bergradasi dengan sorot tepi atas,
 * tombol oranye api, pil fase, strip warna jenis sesi, bar progres, dan kontrol segmented.
 * Semua layar memakai komponen ini supaya kerapatan, bentuk, dan warna sama dengan versi web.
 */

enum class EvTone { Metal, Soft, Deep, Hero }

private val PanelShape = RoundedCornerShape(22.dp)

/** Panel logam semi-3D. `containerColor` (opsional) memaksa warna datar, dipakai blok bersarang. */
@Composable
internal fun EvPanel(
    modifier: Modifier = Modifier,
    containerColor: Color? = null,
    tone: EvTone = EvTone.Metal,
    shape: Shape = PanelShape,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val ev = Ev.palette
    val edge = if (tone == EvTone.Hero) ev.heroEdge else MaterialTheme.colorScheme.outlineVariant
    var m = modifier
    if (tone != EvTone.Deep) m = m.shadow(if (tone == EvTone.Soft) 6.dp else 3.dp, shape, clip = false)
    m = m.clip(shape)
    m = when {
        containerColor != null -> m.background(containerColor, shape)
        tone == EvTone.Metal -> m.background(ev.metal, shape)
        tone == EvTone.Soft -> m.background(ev.metalSoft, shape)
        tone == EvTone.Deep -> m.background(ev.metalDeep, shape)
        else -> m.background(ev.heroLinear, shape).drawBehind {
            drawRect(
                Brush.radialGradient(
                    listOf(ev.heroGlow, Color.Transparent),
                    center = Offset(size.width, 0f),
                    radius = size.width * 0.95f,
                ),
            )
        }
    }
    if (tone != EvTone.Deep) {
        val hi = if (tone == EvTone.Hero) Color(0x2EFFFFFF) else ev.highlight
        m = m.drawBehind {
            val inset = 14.dp.toPx()
            drawLine(hi, Offset(inset, 0.5f), Offset(size.width - inset, 0.5f), 1.dp.toPx())
        }
    }
    m = m.border(BorderStroke(1.dp, edge), shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    if (tone == EvTone.Hero) {
        CompositionLocalProvider(LocalContentColor provides ev.heroText) { Column(m, content = content) }
    } else {
        Column(m, content = content)
    }
}

/** Kepala halaman: eyebrow oranye kecil + judul, opsional aksi di kanan. */
@Composable
internal fun EvPageHeader(eyebrow: String, title: String, modifier: Modifier = Modifier, trailing: (@Composable () -> Unit)? = null) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(eyebrow, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, letterSpacing = 1.4.sp)
            Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }
        trailing?.invoke()
    }
}

/** Judul bagian bergaya h2 web: huruf kapital renggang, warna muted. */
@Composable
internal fun EvGroupTitle(title: String, subtitle: String? = null, modifier: Modifier = Modifier) {
    Column(modifier.padding(top = 8.dp, bottom = 2.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(
            title.uppercase(),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 1.4.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (!subtitle.isNullOrBlank()) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
internal fun EvMetricTile(label: String, value: String, modifier: Modifier = Modifier, accent: Boolean = false) {
    EvPanel(modifier, shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(
                value, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = if (accent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
            )
            Text(label.uppercase(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
        }
    }
}

@Composable
internal fun EvMetricRow(items: List<Pair<String, String>>, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth().height(IntrinsicSize.Max), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { (label, value) -> EvMetricTile(label, value, Modifier.weight(1f).fillMaxHeight()) }
    }
}

/** Pil fase (Fondasi, Bangun, Puncak, Taper) dengan gradien yang sama dengan `.pill.*` di web. */
@Composable
internal fun EvPill(text: String, phase: String?, modifier: Modifier = Modifier) {
    val ev = Ev.palette
    val brush = when (phase) {
        Phases.BASE -> ev.phaseBase
        Phases.BUILD -> ev.phaseBuild
        Phases.PEAK -> ev.phasePeak
        Phases.TAPER -> ev.phaseTaper
        else -> ev.metalDeep
    }
    val fg = if (phase == null) MaterialTheme.colorScheme.onSurfaceVariant else Color.White
    Text(
        text.uppercase(),
        modifier = modifier.clip(RoundedCornerShape(99.dp)).background(brush).padding(horizontal = 9.dp, vertical = 3.dp),
        style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = fg, maxLines = 1,
    )
}

/** Chip transparan di atas hero gelap (`.jd-chip`). */
@Composable
internal fun EvHeroChip(text: String, outlined: Boolean = false, modifier: Modifier = Modifier) {
    val fg = Ev.palette.heroText
    val m = if (outlined) modifier.border(1.dp, fg.copy(alpha = .55f), RoundedCornerShape(99.dp)) else modifier.background(fg.copy(alpha = .2f), RoundedCornerShape(99.dp))
    Text(text.uppercase(), modifier = m.padding(horizontal = 10.dp, vertical = 5.dp), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold, color = fg, maxLines = 1)
}

/** Tombol utama: oranye api mengkilap. Nama sengaja sama dengan Material `Button` agar semua pemanggil ikut. */
@Composable
internal fun Button(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    content: @Composable RowScope.() -> Unit,
) {
    val ev = Ev.palette
    val shape = RoundedCornerShape(16.dp)
    val glow = Color(0xFFF2500A)
    Box(
        modifier
            .heightIn(min = 46.dp)
            .alpha(if (enabled) 1f else .45f)
            .shadow(if (enabled) 6.dp else 0.dp, shape, clip = false, ambientColor = glow, spotColor = glow)
            .clip(shape)
            .background(ev.fire, shape)
            .border(1.dp, ev.fireEdge, shape)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center,
    ) {
        CompositionLocalProvider(LocalContentColor provides Color.White) {
            ProvideTextStyle(MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically, content = content)
            }
        }
    }
}

/** Tombol biasa: logam. Menggantikan OutlinedButton Material. */
@Composable
internal fun OutlinedButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    content: @Composable RowScope.() -> Unit,
) {
    val ev = Ev.palette
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier
            .heightIn(min = 46.dp)
            .alpha(if (enabled) 1f else .45f)
            .shadow(if (enabled) 3.dp else 0.dp, shape, clip = false)
            .clip(shape)
            .background(ev.metal, shape)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, shape)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center,
    ) {
        CompositionLocalProvider(LocalContentColor provides MaterialTheme.colorScheme.onSurface) {
            ProvideTextStyle(MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically, content = content)
            }
        }
    }
}

/** Bar progres: alur logam cekung, isian api bergradasi. */
@Composable
internal fun EvProgressBar(fraction: Float, modifier: Modifier = Modifier, height: Int = 9) {
    val ev = Ev.palette
    val f = fraction.coerceIn(0f, 1f)
    Box(modifier.fillMaxWidth().height(height.dp).clip(RoundedCornerShape(99.dp)).background(ev.metalDeep)) {
        if (f > 0f) Box(Modifier.fillMaxWidth(f).fillMaxHeight().clip(RoundedCornerShape(99.dp)).background(Brush.horizontalGradient(listOf(Color(0xFFFBA81B), Color(0xFFF2500A)))))
    }
}

/** Kontrol segmented (`.seg`): alur cekung, pilihan aktif oranye api. */
@Composable
internal fun EvSegmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val ev = Ev.palette
    Row(modifier.fillMaxWidth().clip(RoundedCornerShape(99.dp)).background(ev.metalDeep).padding(3.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            Box(
                Modifier.weight(1f).heightIn(min = 34.dp).clip(RoundedCornerShape(99.dp))
                    .then(if (on) Modifier.background(ev.fire) else Modifier)
                    .clickable(role = Role.Tab) { onSelect(i) }
                    .padding(horizontal = 6.dp, vertical = 7.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, maxLines = 1,
                    color = if (on) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

/** Strip warna kiri per jenis sesi (`.day.k-*`). */
@Composable
internal fun stripBrush(kind: String): Brush {
    val ev = Ev.palette
    return when (kind) {
        Kinds.QUALITY, Kinds.RACE, Kinds.EVENT -> ev.fire
        Kinds.LONG -> ev.stripLong
        Kinds.REST -> ev.stripRest
        else -> ev.stripEasy
    }
}

/**
 * Baris hari bergaya `.day`: strip warna kiri, blok tanggal, judul + detail, jarak di kanan.
 * Hari ini diberi cincin oranye; sesi yang sudah lewat dibuat lebih redup.
 */
@Composable
internal fun EvDayRow(
    dow: String,
    dayNum: Int,
    title: String,
    km: String?,
    kind: String,
    modifier: Modifier = Modifier,
    detail: String? = null,
    today: Boolean = false,
    dim: Boolean = false,
    extra: @Composable ColumnScope.() -> Unit = {},
) {
    val shape = RoundedCornerShape(16.dp)
    val ring = if (today) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
    val ev = Ev.palette
    Row(
        modifier.fillMaxWidth().alpha(if (dim) .72f else 1f)
            .shadow(if (today) 5.dp else 2.dp, shape, clip = false)
            .clip(shape).background(ev.metal, shape).border(if (today) 1.5.dp else 1.dp, ring, shape)
            .height(IntrinsicSize.Min),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.width(4.dp).fillMaxHeight().background(stripBrush(kind)))
        Column(Modifier.width(46.dp).padding(start = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(dow.uppercase(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(dayNum.toString(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = if (today) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
        }
        Column(Modifier.weight(1f).padding(horizontal = 8.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (!detail.isNullOrBlank()) Text(detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            extra()
        }
        if (km != null) {
            Column(Modifier.padding(end = 12.dp), horizontalAlignment = Alignment.End) {
                Text(km, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                Text("KM", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            Spacer(Modifier.width(12.dp))
        }
    }
}

/** Chip pilihan: aktif = oranye api (padanan `.sldo.on`). Nama sama dengan Material `FilterChip` agar pemanggil lama ikut. */
@Composable
internal fun FilterChip(selected: Boolean, onClick: () -> Unit, label: @Composable () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    androidx.compose.material3.FilterChip(
        selected = selected, onClick = onClick, label = label, modifier = modifier, enabled = enabled,
        shape = RoundedCornerShape(99.dp),
        colors = androidx.compose.material3.FilterChipDefaults.filterChipColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            labelColor = MaterialTheme.colorScheme.onSurfaceVariant,
            selectedContainerColor = MaterialTheme.colorScheme.primary,
            selectedLabelColor = Color.White,
        ),
        border = androidx.compose.material3.FilterChipDefaults.filterChipBorder(
            enabled = enabled, selected = selected,
            borderColor = MaterialTheme.colorScheme.outlineVariant,
            selectedBorderColor = Ev.palette.fireEdge,
        ),
    )
}

/** Switch logam: trek api saat aktif, kenop perak (`input[role=switch]`). */
@Composable
internal fun evSwitchColors() = androidx.compose.material3.SwitchDefaults.colors(
    checkedThumbColor = Color(0xFFF4F5F7),
    checkedTrackColor = Color(0xFFFA7A0C),
    checkedBorderColor = Ev.palette.fireEdge,
    uncheckedThumbColor = Color(0xFFE3E5E9),
    uncheckedTrackColor = MaterialTheme.colorScheme.surfaceVariant,
    uncheckedBorderColor = MaterialTheme.colorScheme.outline,
)

/** Grup formulir: satu panel logam dengan judul bagian di dalamnya. */
@Composable
internal fun EvFormGroup(title: String, subtitle: String? = null, content: @Composable ColumnScope.() -> Unit) {
    EvPanel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            EvGroupTitle(title, subtitle, Modifier.padding(top = 0.dp))
            content()
        }
    }
}
