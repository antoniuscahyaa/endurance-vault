package com.endurancevault.app.ui.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.dp

/**
 * Ikon dock yang sama dengan versi web (garis 24×24, ujung bulat). Path disalin dari index.template.html
 * sehingga bentuknya identik, bukan ikon Material pengganti.
 */
private fun strokeIcon(name: String, width: Float, vararg paths: String): ImageVector {
    val b = ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f)
    paths.forEach { d ->
        b.addPath(
            pathData = PathParser().parsePathString(d).toNodes(),
            fill = null,
            stroke = SolidColor(Color.Black),
            strokeLineWidth = width,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round,
        )
    }
    return b.build()
}

object EvIcons {
    private val homeD = arrayOf("M4 4h6v8h-6z", "M4 16h6v4h-6z", "M14 12h6v8h-6z", "M14 4h6v4h-6z")
    private val runnerD = arrayOf(
        "M13 4m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0", "M4 17l5 1l.75 -1.5", "M15 21l0 -4l-4 -3l1 -6", "M7 12l0 -3l5 -1l3 3l3 1",
    )
    private val trendD = arrayOf(
        "M4 16l6 -7l5 5l5 -6", "M14 14m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0", "M10 9m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0",
        "M4 16m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0", "M20 8m-1 0a1 1 0 1 0 2 0a1 1 0 1 0 -2 0",
    )
    private val calendarD = arrayOf(
        "M4 7a2 2 0 0 1 2 -2h12a2 2 0 0 1 2 2v12a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2v-12z", "M16 3v4", "M8 3v4", "M4 11h16",
        "M7 14h.013", "M10.01 14h.005", "M13.01 14h.005", "M16.015 14h.005", "M13.015 17h.005", "M7.01 17h.005", "M10.01 17h.005",
    )

    val Home = strokeIcon("evHome", 1.8f, *homeD)
    val HomeOn = strokeIcon("evHomeOn", 2.1f, *homeD)
    val Runner = strokeIcon("evRunner", 1.8f, *runnerD)
    val RunnerOn = strokeIcon("evRunnerOn", 2.1f, *runnerD)
    val Trend = strokeIcon("evTrend", 1.8f, *trendD)
    val TrendOn = strokeIcon("evTrendOn", 2.1f, *trendD)
    val Calendar = strokeIcon("evCalendar", 1.8f, *calendarD)
    val CalendarOn = strokeIcon("evCalendarOn", 2.1f, *calendarD)
}
