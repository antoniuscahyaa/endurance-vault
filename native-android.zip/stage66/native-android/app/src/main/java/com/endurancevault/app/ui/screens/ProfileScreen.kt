package com.endurancevault.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.alpha
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import com.endurancevault.app.domain.PlanSettings
import com.endurancevault.app.domain.TrainingMethod
import com.endurancevault.app.ui.ImportUi
import com.endurancevault.app.ui.UiState
import com.endurancevault.app.data.DailyEntity
import com.endurancevault.app.data.GearEntity
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import java.time.LocalDate

private val TYPES = listOf(
    "5k" to "5K", "10k" to "10K", "hm" to "Half marathon", "fm" to "Marathon",
    "ultra" to "Trail", "ultrar" to "Ultra road", "pb" to "Performance Build", "none" to "No Race",
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileScreen(
    state: UiState,
    onSave: (PlanSettings) -> Unit,
    importUi: ImportUi,
    onImport: (Uri) -> Unit,
    onConfirmImport: () -> Unit,
    onDismissImport: () -> Unit,
    onSaveDaily: (DailyEntity) -> Unit,
    onSaveGear: (GearEntity) -> Unit,
    onDeleteGear: (String) -> Unit,
    watchMessage: String,
    onConnectWatch: (String) -> Unit,
    onDisconnectWatch: () -> Unit,
    onForgetAndReconnectWatch: (String) -> Unit,
    onSyncWatch: (Boolean) -> Unit,
    watchSyncing: Boolean,
    watchAdvancedMessage: String,
    liveHr: org.json.JSONObject,
    onRefreshLiveHr: () -> Unit,
    onSetLiveHr: (Boolean) -> Unit,
    onSyncHrZones: (PlanSettings) -> Unit,
    onPushWorkout: (String, Int, Int, Int, Int, Int) -> Unit,
    onPushRoute: (Uri) -> Unit,
    weatherMessage: String, weatherBusy: Boolean, weatherLat: String, weatherLon: String,
    onFetchWeather: (Double,Double) -> Unit, onSearchWeatherCity: (String) -> Unit, onUseWeatherLocation: () -> Unit, onWeatherToWatch: (Double,Double,String) -> Unit,
    weatherWatchStatus: String, agpsStatus: String, onAgps: (Boolean,String) -> Unit, onTestAgps: () -> Unit,
    notifyStatus: String, onNotify: (Boolean,Boolean,Int,Int,Boolean,Map<String,Boolean>) -> Unit, onTestNotify: () -> Unit,
    aiStatus: String, aiMessages: List<Pair<String,String>>, onAiKey: (String) -> Unit,
    onAiSend: (String,String,Boolean) -> Unit, aiBusy: Boolean,
) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) onImport(uri) }
    val s = state.settings
    var rtype by remember(s) { mutableStateOf(s.rtype) }
    var name by remember(s) { mutableStateOf(s.name) }
    var start by remember(s) { mutableStateOf(s.start.toString()) }
    var race by remember(s) { mutableStateOf(s.race?.toString() ?: "") }
    var raceKm by remember(s) { mutableStateOf(s.raceKm?.let { fmtKmUi(it) } ?: "") }
    var raceGain by remember(s) { mutableStateOf(s.raceGain?.let { fmtKmUi(it) } ?: "") }
    var goal by remember(s) { mutableStateOf(s.goalT) }
    var base by remember(s) { mutableStateOf(fmtKmUi(s.base)) }
    var peak by remember(s) { mutableStateOf(fmtKmUi(s.peak)) }
    var days by remember(s) { mutableStateOf(s.days) }
    var longDay by remember(s) { mutableStateOf(s.longDay.toString()) }
    var hr by remember(s) { mutableStateOf(s.hr.toString()) }
    var thr by remember(s) { mutableStateOf(s.thr) }
    var pace by remember(s) { mutableStateOf(s.pace) }
    var method by remember(s) { mutableStateOf(s.method) }
    var qSess by remember(s) { mutableStateOf(s.qSess) }
    var sLeg by remember(s) { mutableStateOf(s.sLeg) }
    var sAnk by remember(s) { mutableStateOf(s.sAnk) }
    var sUp by remember(s) { mutableStateOf(s.sUp) }
    var err by remember { mutableStateOf<String?>(null) }
    val num = KeyboardOptions(keyboardType = KeyboardType.Number)
    val full = Modifier.fillMaxWidth()

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        EvPageHeader("PENGATURAN", "Profil dan rencana")
        EvPanel(full, tone = EvTone.Hero, shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    EvHeroChip(TYPES.firstOrNull { it.first == s.rtype }?.second ?: "Rencana")
                    EvHeroChip("${s.days} hari lari", outlined = true)
                }
                Text(s.name.ifBlank { "Rencana latihan" }, style = MaterialTheme.typography.headlineSmall, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                Text(
                    (s.race?.let { "Lomba $it · " } ?: "") + "${fmtKmUi(s.base)} → ${fmtKmUi(s.peak)} km per minggu",
                    style = MaterialTheme.typography.bodyMedium, modifier = Modifier.alpha(.85f),
                )
            }
        }
        EvFormGroup("Target latihan", "Jenis sasaran, tanggal, dan target performa") {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TYPES.forEach { (k, label) -> FilterChip(selected = rtype == k, onClick = { rtype = k }, label = { Text(label) }) }
            }
            OutlinedTextField(name, { name = it }, label = { Text("Nama lomba") }, singleLine = true, modifier = full)
            OutlinedTextField(start, { start = it }, label = { Text("Mulai (yyyy-MM-dd)") }, singleLine = true, modifier = full)
            if (rtype != "pb" && rtype != "none") {
                OutlinedTextField(race, { race = it }, label = { Text("Tanggal lomba (yyyy-MM-dd)") }, singleLine = true, modifier = full)
                OutlinedTextField(goal, { goal = it }, label = { Text("Target waktu (h:mm:ss, opsional)") }, singleLine = true, modifier = full)
            }
            if (rtype == "ultra" || rtype == "ultrar") {
                OutlinedTextField(raceKm, { raceKm = it }, label = { Text("Jarak lomba (km)") }, keyboardOptions = num, singleLine = true, modifier = full)
                OutlinedTextField(raceGain, { raceGain = it }, label = { Text("Elevasi lomba D+ (m)") }, keyboardOptions = num, singleLine = true, modifier = full)
            }
        }
        EvFormGroup("Volume latihan", "Atur perkembangan jarak dan distribusi hari lari") {
            OutlinedTextField(base, { base = it }, label = { Text("Km mingguan awal") }, keyboardOptions = num, singleLine = true, modifier = full)
            OutlinedTextField(peak, { peak = it }, label = { Text("Km mingguan puncak") }, keyboardOptions = num, singleLine = true, modifier = full)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = days == 5, onClick = { days = 5 }, label = { Text("5 hari lari") })
                FilterChip(selected = days == 6, onClick = { days = 6 }, label = { Text("6 hari lari") })
            }
            OutlinedTextField(longDay, { longDay = it }, label = { Text("Hari long run (0=Sen … 6=Min)") }, keyboardOptions = num, singleLine = true, modifier = full)
        }
        EvFormGroup("Zona intensitas", "Parameter untuk panduan latihan berbasis detak jantung dan pace") {
            OutlinedTextField(hr, { hr = it }, label = { Text("Batas HR easy") }, keyboardOptions = num, singleLine = true, modifier = full)
            OutlinedTextField(thr, { thr = it }, label = { Text("Rentang HR threshold (mis. 164–172)") }, singleLine = true, modifier = full)
            OutlinedTextField(pace, { pace = it }, label = { Text("Pace easy (m:ss)") }, singleLine = true, modifier = full)
        }
        EvFormGroup("Metode latihan", "Pilih pendekatan periodisasi yang digunakan") {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TrainingMethod.KEYS.forEach { k ->
                    FilterChip(selected = method == k, onClick = { method = k }, label = { Text(TrainingMethod.name(k)) })
                }
            }
            Text(TrainingMethod.info(method), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        EvFormGroup("Distribusi sesi", "Frekuensi sesi kualitas dalam satu pekan") {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = qSess == "1", onClick = { qSess = "1" }, label = { Text("1 sesi") })
                FilterChip(selected = qSess == "2", onClick = { qSess = "2" }, label = { Text("2 sesi") })
            }
            if (qSess == "2") {
                Text(
                    "Sesi kedua hanya muncul di fase Bangun dan Puncak untuk 5K, 10K, Half, Marathon, dan Performance Build dengan 6 hari lari, " +
                        "saat hari easy pendek jatuh dua hari sebelum long run. Dosisnya naik bertahap dan dibatasi sekitar 20% waktu lari mingguan.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        EvFormGroup("Strength & stabilitas", "Pengaturan latihan pendukung") {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Switch(checked = sLeg, onCheckedChange = { sLeg = it }, colors = evSwitchColors()); Text("Kaki dan panggul (Strength A dan B)")
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Switch(checked = sAnk, onCheckedChange = { sAnk = it }, colors = evSwitchColors()); Text("Ankle dan stabilitas")
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("auto" to "Upper otomatis", "off" to "Upper mati", "1" to "Upper 1×", "2" to "Upper 2×").forEach { (k, label) ->
                    FilterChip(selected = sUp == k, onClick = { sUp = k }, label = { Text(label) })
                }
            }
        }
        err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(modifier = full, onClick = {
            fun d(t: String) = runCatching { LocalDate.parse(t) }.getOrNull()
            fun n(t: String) = t.replace(',', '.').toDoubleOrNull()
            val st = d(start)
            val rc = if (race.isBlank()) null else d(race)
            val b = n(base); val p = n(peak); val h = hr.toIntOrNull(); val ld = longDay.toIntOrNull()
            if (st == null || (race.isNotBlank() && rc == null) || b == null || p == null || h == null || ld == null) {
                err = "Periksa format tanggal dan angka."
            } else {
                err = null
                onSave(
                    s.copy(
                        name = name.trim(), rtype = rtype, start = st, race = if (rtype == "pb" || rtype == "none") null else rc,
                        raceKm = n(raceKm), raceGain = n(raceGain), goalT = goal.trim(),
                        base = b, peak = p, days = days, longDay = ld, hr = h, thr = thr.trim(), pace = pace.trim(),
                        method = method, qSess = qSess, sLeg = sLeg, sAnk = sAnk, sUp = sUp,
                    ),
                )
            }
        }) { Text("Simpan dan hitung ulang rencana") }

        HuaweiWatchSection(
            message = watchMessage,
            onConnect = onConnectWatch,
            onDisconnect = onDisconnectWatch,
            onForgetAndReconnect = onForgetAndReconnectWatch,
            onSync = onSyncWatch,
            isSyncing = watchSyncing,
            settings = state.settings,
            advancedMessage = watchAdvancedMessage,
            liveHr = liveHr,
            onRefreshLiveHr = onRefreshLiveHr,
            onSetLiveHr = onSetLiveHr,
            onSyncHrZones = onSyncHrZones,
            onPushWorkout = onPushWorkout,
            onPushRoute = onPushRoute,
        )

        OnlineServicesSection(
            weather = weatherMessage, weatherBusy = weatherBusy, weatherLat = weatherLat, weatherLon = weatherLon,
            onWeather = onFetchWeather, onSearchCity = onSearchWeatherCity, onUseLocation = onUseWeatherLocation, onWeatherToWatch = onWeatherToWatch, weatherWatchStatus = weatherWatchStatus,
            agpsStatus = agpsStatus, onAgps = onAgps, onTestAgps = onTestAgps,
            notifyStatus = notifyStatus, onNotify = onNotify, onTestNotify = onTestNotify,
            aiStatus = aiStatus, aiMessages = aiMessages, onAiKey = onAiKey, onAiSend = onAiSend, aiBusy = aiBusy,
        )

        CompanionDataSection(
            daily = state.daily,
            gear = state.gear,
            activities = state.activities,
            onSaveDaily = onSaveDaily,
            onSaveGear = onSaveGear,
            onDeleteGear = onDeleteGear,
        )

        EvGroupTitle("Cadangan", "Impor berkas cadangan dari versi web (.json) untuk memulihkan pengaturan rencana dan catatan lari.", Modifier.padding(top = 8.dp))
        OutlinedButton(
            modifier = full,
            enabled = importUi !is ImportUi.Working,
            onClick = { picker.launch(arrayOf("application/json", "text/plain", "application/octet-stream")) },
        ) { Text(if (importUi is ImportUi.Working) "Membaca berkas…" else "Impor cadangan web") }
        when (importUi) {
            is ImportUi.Done -> Text(importUi.message, color = MaterialTheme.colorScheme.primary)
            is ImportUi.Failed -> Text(importUi.message, color = MaterialTheme.colorScheme.error)
            else -> {}
        }
    }

    if (importUi is ImportUi.Confirm) {
        val b = importUi.backup
        AlertDialog(
            onDismissRequest = onDismissImport,
            title = { Text("Pulihkan cadangan?") },
            text = {
                Text(
                    "Ditemukan ${b.activities.size} catatan lari, ${b.doneDays} hari selesai, ${b.daily.size} catatan harian, ${b.gear.size} gear, dan pengaturan rencana" +
                        (if (b.settings.name.isNotBlank()) " \"${b.settings.name}\"" else "") + ".\n\n" +
                        "Pengaturan rencana saat ini akan ditimpa, begitu juga catatan hasil impor sebelumnya. " +
                        "Catatan yang Anda buat di aplikasi ini tidak diubah." +
                        (if (b.detailCount > 0) "\n\n${b.detailCount} detail aktivitas (rute GPS) ikut tersimpan di berkas dan akan dibaca pada tahap berikutnya." else ""),
                )
            },
            confirmButton = { TextButton(onClick = onConfirmImport) { Text("Pulihkan") } },
            dismissButton = { TextButton(onClick = onDismissImport) { Text("Batal") } },
        )
    }
}
