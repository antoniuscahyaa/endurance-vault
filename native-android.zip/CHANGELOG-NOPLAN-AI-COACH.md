# AI Coach: mode No plan dan aksi sesi rencana

## Masalah
Saat memilih No plan (`rtype = "none"`), `PlanEngine.plan()` menghasilkan minggu yang semua harinya `REST` ("Libur", 0 km).
Konteks AI Coach mengirim itu sebagai "Rencana mendatang", sehingga model menganggap hari ini jadwal libur dan menyarankan rest.
Selain itu konteks native tidak memuat readiness, beban latihan, dan tren yang dikirim aplikasi web (`18b-ai-coach.js`).

## Perubahan
- `domain/CoachContext.kt` (baru): potongan konteks murni Kotlin.
  - Mode No plan mengirim status web "Tidak ada sesi terjadwal hari ini." plus catatan agar hari ini tidak dianggap libur.
  - Tren 4 minggu bergulir (sesi, km, menit, pace, HR), setara `aiTrendContext()`.
  - Readiness (skor, faktor, saran) dan beban latihan (fitness/fatigue/form), setara `aiReadinessContext()`.
  - Libur dadakan 28 hari (`unplannedRests`) dari `SessionAdjust.spHistory`.
  - Ringkasan kebiasaan lari per hari dalam seminggu (khusus native) dan nama hari ini.
  - Panduan keputusan latihan dari prompt web.
  - `hasSessionOn()` / `planActive()` untuk aksi sesi rencana.
- `ui/MainViewModel.kt`: system prompt memakai blok di atas; aktivitas = 28 hari terakhir (minimal 12) dengan nama hari dan jenis.
- `data/ReadinessPrefs.kt` (baru): pemuatan `ReadinessConfig` dari prefs, dipakai bersama oleh `TodayScreen` dan AI Coach
  agar skor readiness untuk AI sama dengan yang tampil di aplikasi. `TodayScreen` hanya mengganti blok pemuatan, tanpa perubahan perilaku.
- Aksi sesi rencana:
  - `skip_session` dan `set_session_done` tidak dikirim ke model bila tidak ada rencana aktif (No plan atau plan error).
  - `SkipSession` dan `SetSessionDone(done = true)` ditolak bila tanggalnya tidak punya sesi di rencana aktif.
    Plan error sebelumnya malah mengizinkan skip. Membatalkan tanda selesai tetap selalu boleh.
  - Pesan penolakan membedakan "tidak ada rencana aktif" dari "tidak ada sesi pada tanggal itu".
- `domain/CoachActions.kt`: `toolDefinitions(planActive = true)` dan `PLAN_ONLY_TOOLS`.

## Tidak diubah
Rumus readiness, CTL/ATL/TSB, Training Effect, PlanEngine, skema database. Perilaku mode dengan rencana aktif sama seperti sebelumnya.

## Belum dikerjakan
- Drift HR lari panjang (`recentHrDrift` di web) belum dikirim ke AI.
- Toggle berbagi data pemulihan/catatan (`aiShareOn` di web) belum ada di native.

## Verifikasi
Build dan unit test (`CoachContextTest`) belum dijalankan; Gradle tidak tersedia di lingkungan penyusunan.
