# 0.5.93 – HRR, Plan, Activity Detail, Timeline & Map controls

- Stabilize the HRR Max HR draft field so unrelated settings updates do not reset an in-progress manual entry. LTHR behavior is unchanged.
- Restore manual rest-day selection in Plan > Week (one rest day for 6 run days, two for 5 run days) and persist it through the existing PlanSettings fields; prevent rest-day/long-run conflicts when building the draft.
- Open Activity Detail on Map overview by default.
- Consolidate the six activity-map controls into an expandable/collapsible FAB; shared map view means the same control applies in Activity Detail and Profile > Timeline.
- Refine Profile > Timeline activity cards: sentence-case metric labels, smaller metric values, readable full dates, and compact historical weather beside the time when available.
- Convert Explore route-mode rail to a Run-primary expandable FAB with Bike, Manual, and Location choices.
