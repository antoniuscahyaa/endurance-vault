# Progres › Routes & conditions: tata letak mengikuti rencana lari

Tampilan
- Ringkasan kartu berbentuk grid: Rute serupa + Bandingkan aktivitas (berpasangan), Heatmap rute + Ridgeline elevasi 3D (berpasangan), Dampak cuaca selebar layar. Kartu Fuelling sengaja tidak dibuat. Badge sub-tab kini 5.
- Rute serupa: sakelar Peta/Polos, daftar akordeon "8,2 km · 13 lari · terbaru 29 Okt" (urut tanggal terbaru), isi berupa peta OSM (rute terbaru di depan, lari lain samar) dan tabel Tanggal/Waktu/Pace/HR/D+.
- Bandingkan aktivitas: dua dropdown A/B dari semua aktivitas (lari dan sepeda), tabel jarak, waktu gerak, pace, GAP, pace usaha, HR, kadens, panjang langkah, elevasi, beban latihan, efek aerobik, est. VO2max dengan kolom selisih B−A.
- Heatmap rute: sakelar Area utama/Semua dan Peta/Polos; latar gelap, garis berpendar makin terang bila makin sering dilewati; keterangan lebar area.
- Ridgeline elevasi 3D: pilihan 4/6/8/12 lari, Relatif/Absolut, label tanggal · jarak · D+ di kanan, titik ketinggian awal, chip tanggal untuk menyorot satu lari.
- Dampak cuaca: sakelar Pace/HR, Aktual/Terasa, Semua/Easy; scatter bersumbu dengan garis tren putus-putus dan kalimat ringkasan (mis. "Setiap +5°C, pace melambat 12 dtk/km").

Logika
- `ProgressTabs.mainAreaFlags`, `ProgressTabs.corrLabel`, `ProgressAnalytics.abilityBasis` dan `activityAbility` (estimasi VO2max per lari, rumus sama dengan indeks kemampuan). Tes baru di `ProgressTabsTest`.
- Terjemahan Inggris untuk string baru ada di `assets/i18n/en.tsv`.
