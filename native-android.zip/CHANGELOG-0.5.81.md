# Explore: untuk pendakian gunung

- Overlay "Jalur pendakian" (Waymarked Trails, data OSM) di atas peta apa pun, termasuk Kontur. Dinyalakan dari lapisan peta di Explore atau tombol di peta detail rute; pilihan diingat. Ubin disimpan di cache.
- "Peta offline seluruh area (±3 km)" di detail rute: unduh semua ubin zoom 11–15 di kotak sekitar rute untuk gaya peta terpilih (maks. 2.500 ubin; zoom tertinggi dikurangi bila lebih). Untuk Kontur, data elevasinya ikut tersimpan.
- Estimasi waktu mendaki (rumus Tobler, kemiringan per jendela 25 m) di detail rute yang naik ≥ 150 m.
- Perbaikan galat kompilasi 0.5.80: `detectTapGestures` dan `detectDragGesturesAfterLongPress` di `ExploreScreen.kt` kini di-import.

Belum dikerjakan: penanda puncak dan sumber air dari OSM (butuh layanan Overpass).
Kode belum dikompilasi di sini; mohon rebuild.
