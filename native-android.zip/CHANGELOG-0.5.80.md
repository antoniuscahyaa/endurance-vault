# Explore: 12 peningkatan + peta Kontur untuk mendaki

Peta Kontur (jenis peta baru, di semua peta)
- Gaya baru `Kontur`: garis kontur tipis (interval menurut zoom: 200/100/50/25/12,5 m), garis indeks tebal tiap 5 interval bertuliskan ketinggian, bayangan relief, dan tinta ketinggian. Laut berwarna biru muda.
- Dirender di perangkat dari ubin elevasi Terrarium (AWS Terrain Tiles, tanpa kunci API), disimpan di cache disk, dan ikut unduhan peta offline. Berkas baru: `data/ContourTiles.kt`.
- Topografi (OpenTopoMap) tetap ada; Kontur adalah opsi tambahan.
- Tersedia di: Explore (lapisan peta), detail rute Explore, peta rute aktivitas, pratinjau GPX/kirim ke jam, dan tekstur relief video rute 3D (pilihan "Tekstur satelit / kontur").
- Keterbatasan: hanya data elevasi (tanpa sungai, jalan, nama puncak). Kualitas mengikuti data SRTM ±30 m.

Explore
1. Rute dipasang ke sesi latihan: tampil di kartu Hari ini (bandingkan km rute dengan target sesi); tombol "Pasang rute dari Explore".
2. Status "dikirim ke jam" di detail rute (diisi otomatis setelah rute terkirim).
3. Ringkasan tanjakan utama di detail rute.
4. Peta offline: unduh ubin di sepanjang rute (±1 ubin, zoom 12–16, maks 1.200 ubin).
5. Profil elevasi bisa ditelusuri (ketuk/tekan lama lalu geser): km, elevasi, kemiringan, dengan penanda di peta; tanjakan ≥ 10% ditandai di peta.
6. "Simpan jejak sebagai rute" di detail aktivitas.
7. "Lari di rute ini": aktivitas serupa, jejaknya bisa ditampilkan di peta.
8. Hapus bagian tengah rute (dua pegangan) dengan penyambungan otomatis.
9. Tombol Tutup loop dan Pulang-pergi.
10. Kartu bagikan rute 4:5 (Minimalis, Sporty, Elegan), hanya garis rute tanpa ubin peta.
11. Pilihan routing OSRM atau BRouter (cadangan bergantian, lalu garis lurus).
12. Kalibrasi elevasi: total naik/turun disesuaikan dari rasio median jam ÷ model elevasi pada lari serupa.

Catatan: kode belum dikompilasi di lingkungan ini (tidak ada Android SDK); mohon rebuild dan laporkan bila ada galat.
