# 0.5.95

## Log bulanan (tab Rekap)
- **Tombol i** pindah ke pojok kanan atas, tepat di sebelah tombol Bagikan. Teks penjelasnya muncul tepat di bawah baris tombol.
- **Bagikan** kini membuat **gambar PNG** kartu kalender bulan yang sedang tampil (judul bulan, ringkasan, grid, legenda).
  Tata letaknya sama dengan di aplikasi dan berlatar solid. Gambar disimpan ke galeri (album TrainingPlan) lalu lembar berbagi sistem terbuka (`StickerIo.saveToGallery` dan `StickerIo.share`).
  Tombol navigasi, Bagikan, i, dan sakelar tidak ikut masuk gambar.
- **Sakelar "Tampilkan sesi strength"** di bawah kalender. Saat dimatikan: garis merah strength di sel, item legenda Strength, dan teks "· N strength" di ringkasan bulan ikut hilang, termasuk di gambar yang dibagikan.
  Sakelar tidak disimpan: selalu menyala lagi saat aplikasi dibuka ulang.
- Legenda dipindah ke dalam kartu yang direkam, supaya ikut tampil di PNG.

Berubah (Log bulanan): `RecapTab.kt` (`RecapMonthly`), `i18n/en.tsv`.
Kode belum dikompilasi di sini. Mohon rebuild dan kirim log CI bila ada error.

## Efisiensi aerobik (tab Fitness)
- **HR target tidak lagi kembali ke 140.** Nilai HR dan rentang waktu (3 bln / 6 bln / 1 th / Semua) kini disimpan permanen (`SharedPreferences` "fitness_aero"), tidak hanya di `rememberSaveable`. Tombol "Pakai N bpm" juga ikut tersimpan.
Berubah: `FitnessTab.kt` (`FitnessAero`).

## Heatmap tahunan (tab Rekap)
- Kartu selalu tampil dalam mode **expand** dan tidak bisa diciutkan: header tidak lagi bisa diketuk dan ikon panah dihapus. `RcCard` mendapat parameter `locked` (bawaan `false`, kartu lain tidak berubah). Variabel `oHeat` dihapus.
Berubah: `RecapTab.kt`.

## Impor aktivitas lama dari berkas (Setelan, tab Cadangan)
- Bagian baru **"Impor aktivitas dari berkas"** dengan tombol "Impor FIT / GPX / TCX": bisa memilih banyak berkas sekaligus. Memakai `MainViewModel.importTracks` yang sudah ada (parser FIT/GPX/TCX, `ActBuilder`).
- Tanggal dan jam diambil dari isi berkas, jadi aktivitas lama masuk ke tanggal aslinya dengan rute dan grafik. Berkas yang cocok dengan aktivitas yang sudah ada dilewati atau melengkapi detailnya. Hasil impor tampil di bawah tombol.
- GPX tanpa cap waktu pada titiknya ditolak ("tidak ada titik lintasan dengan waktu").
Berubah: `ProfileScreen.kt`, `i18n/en.tsv`.
