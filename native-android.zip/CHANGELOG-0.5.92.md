# 0.5.92

## Video rute 3D: susunan tetap (judul kiri atas, grafik, data di bawah)
Sistem grid-panel (geser panel antar sel) diganti susunan tetap yang lebih sederhana:

- **Judul dan ringkasan** selalu di **kiri atas**, posisinya tidak bisa diubah. Hanya **ukuran huruf** (50–200%) dan **warna huruf** (palet + kode hex) yang bisa diatur.
  Judul = judul sendiri/nama aktivitas, ringkasan = baris kedua (lokasi, nama event), lalu tanggal.
- **Data** (jarak, waktu, pace/kecepatan, HR, gradien, elevasi, total naik, cadence; selisih ghost otomatis bila ada ghost) ditempatkan di **bagian bawah video**.
  - Susunan **Baris**: 1–2 baris (cocok video vertikal), atau **Kolom**: 2–4 kolom (cocok video horizontal).
  - **Ukuran huruf** (50–200%) dan **warna huruf** (palet + kode hex) bisa diatur. Huruf mengecil otomatis bila tidak muat di kolomnya.
  - **Padding** horizontal (antar kolom) dan vertikal (antar baris), masing-masing 0–120.
- **Grafik** (elevasi; bisa juga pace atau HR) ditempatkan **tepat di atas data**. **Lebar** (30–100% dari lebar isi) dan **tinggi** (60–500) bisa diatur, begitu juga jarak grafik ke data.
- **Margin** blok grafik + data: kiri/kanan (0–200) dan bawah (0–400).
- **Tombol "Tukar posisi grafik dan data"**: grafik di atas data (bawaan) atau data di atas grafik.
- Legenda warna garis tetap ada sebagai pilihan (ditaruh di atas blok bawah). Semua ukuran memakai sisi pendek bingkai 1080 px sebagai acuan, jadi HD, SD, dan pratinjau tampak sama.
- Kartu ringkasan di akhir video memakai warna judul untuk judulnya dan warna data untuk angkanya.
- Preset bawaan (Minimal, Lengkap, Gaya Coros) disusun ulang; preset buatan sendiri menyimpan seluruh susunan baru.

## Latar gradasi tipis di bawah
- Di belakang blok grafik + data ada **gradasi tipis**: transparan di atas, paling pekat di tepi bawah video, supaya teks lebih jelas di atas peta.
  Hitam untuk huruf terang, putih bila warna huruf data gelap. Bisa dimatikan, dan **kepekatannya** (0–100%, bawaan 45%) bisa diatur di bagian "Margin dan latar".
  Ikut memudar saat kartu ringkasan muncul di akhir video; tersimpan di preset.

## Migrasi pengaturan lama
- Pengaturan dan preset lama (grid panel) dibaca otomatis: data yang aktif dipertahankan menurut urutan letaknya di grid, grafik yang aktif jadi grafik, "legenda" tetap, dan warna teks lama (putih/hitam/lime) jadi warna huruf judul dan data.
  Posisi dan ukuran panel lama tidak bisa dipetakan dan tidak dipakai lagi.
- Pratinjau tidak lagi memakai ketuk/geser panel (tidak ada panel yang bisa dipindah).

## Test
- `RouteVideoTest.kt`: tes grid dihapus, diganti tes susunan baru (grafik di atas data, tukar, mode baris/kolom, margin/padding, lebar-tinggi grafik, skala SD/HD, judul tetap, migrasi pengaturan dan preset lama).
- Perbaikan: tes lama memakai `LayoutPreset` tanpa import sehingga tidak bisa dikompilasi; sekarang diimpor.
- Diketahui gagal sebelum perubahan ini dan tidak disentuh: `fastestKmAnchorMarksTheQuickestThousandMetres` (pace 4:01 vs harapan 4:00).

Berubah: `RouteVideo.kt`, `RouteVideoExtras.kt`, `RouteVideoOverlay.kt`, `RouteVideoEncoder.kt`, `RouteVideoScreen.kt`, `RouteVideoTest.kt`, `en.tsv`.
Dikompilasi di sini: `RouteVideo.kt`, `RouteVideoExtras.kt`, `RouteVideoOverlay.kt` (dengan stub Android) dan seluruh `RouteVideoTest`. `RouteVideoScreen.kt` (Compose) belum dikompilasi; mohon rebuild dan kirim log CI bila ada error.
