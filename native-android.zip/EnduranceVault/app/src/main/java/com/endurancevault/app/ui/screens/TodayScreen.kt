package com.endurancevault.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.endurancevault.app.data.ActivityEntity
import com.endurancevault.app.domain.PDay
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.ui.UiState
import java.time.LocalDate

@Composable
fun TodayScreen(state: UiState, onAdd: (ActivityEntity) -> Unit) {
    var dialog by remember { mutableStateOf(false) }
    val today = LocalDate.now()
    val plan = state.plan

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) { Text("ENDURANCEVAULT", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary); Text("Hari ini", style = MaterialTheme.typography.headlineMedium) }
        when (plan) {
            is PlanOutcome.Err -> Text(plan.message, color = MaterialTheme.colorScheme.error)
            is PlanOutcome.Ok -> {
                val d: PDay? = plan.weeks.flatMap { it.days }.firstOrNull { it.date == today }
                if (d == null) {
                    Text("Tidak ada sesi terjadwal hari ini.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    EvPanel(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Text("SESI HARI INI", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            Text(d.title, style = MaterialTheme.typography.titleLarge)
                            if (d.km > 0) Text("${fmtKmUi(d.km)} km", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
                            if (d.detail.isNotBlank()) Text(d.detail, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    EvGroupTitle("Detail sesi", d.detail.takeIf { it.isNotBlank() } ?: "Rincian latihan hari ini")
                    SupportBlocks(d, expanded = true)
                }
            }
        }
        Button(onClick = { dialog = true }, Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.medium) { Text("Catat lari") }
    }

    if (dialog) LogRunDialog(onDismiss = { dialog = false }) { km, min, hr ->
        onAdd(ActivityEntity(dateIso = today.toString(), km = km, durationSec = min * 60, avgHr = hr))
        dialog = false
    }
}

@Composable
private fun LogRunDialog(onDismiss: () -> Unit, onSave: (Double, Int, Int?) -> Unit) {
    var km by remember { mutableStateOf("") }
    var min by remember { mutableStateOf("") }
    var hr by remember { mutableStateOf("") }
    val num = KeyboardOptions(keyboardType = KeyboardType.Number)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Catat lari") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(km, { km = it }, label = { Text("Jarak (km)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                Row { OutlinedTextField(min, { min = it }, label = { Text("Durasi (menit)") }, keyboardOptions = num, singleLine = true) }
                OutlinedTextField(hr, { hr = it }, label = { Text("HR rata-rata (opsional)") }, keyboardOptions = num, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val k = km.replace(',', '.').toDoubleOrNull()
                val m = min.toIntOrNull()
                if (k != null && k > 0 && m != null && m > 0) onSave(k, m, hr.toIntOrNull())
            }) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
    )
}

internal fun fmtKmUi(x: Double): String =
    if (x == Math.floor(x)) x.toLong().toString() else "%.1f".format(x).replace('.', ',')
