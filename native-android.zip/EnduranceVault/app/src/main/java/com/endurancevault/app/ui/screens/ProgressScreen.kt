package com.endurancevault.app.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.material3.OutlinedButton
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.Canvas
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.endurancevault.app.domain.ActivityAnalytics
import com.endurancevault.app.domain.PlanOutcome
import com.endurancevault.app.ui.UiState
import java.time.LocalDate
import java.time.DayOfWeek

@Composable
fun ProgressScreen(
    state: UiState, onDelete: (Long) -> Unit, onOpen: (Long) -> Unit,
    onImportTracks: (List<Uri>) -> Unit, trackMsg: String?,
) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> if (uris.isNotEmpty()) onImportTracks(uris) }
    val summary = ActivityAnalytics.summarize(state.activities)
    val weeks = (state.plan as? PlanOutcome.Ok)?.weeks.orEmpty()
    val thisWeek = weeks.firstOrNull { !LocalDate.now().isBefore(it.start) && LocalDate.now().isBefore(it.start.plusDays(7)) }
    val done = thisWeek?.let { w ->
        state.activities.filter {
            if (it.type == "bike") return@filter false
            val d = LocalDate.parse(it.dateIso); !d.isBefore(w.start) && d.isBefore(w.start.plusDays(7))
        }.sumOf { it.km }
    } ?: 0.0

    LazyColumn(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 12.dp, bottom = 24.dp)) {
        item { Column(verticalArrangement = Arrangement.spacedBy(2.dp)) { Text("PERFORMA", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary); Text("Progres", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(top = 2.dp)) } }
        item { TrainingLoadSection(state) }
        item {
            EvPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    EvGroupTitle("Ringkasan performa", "Rekap aktivitas yang tersimpan")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column { Text("Total lari", style = MaterialTheme.typography.labelSmall); Text("${summary.runCount} sesi", style = MaterialTheme.typography.titleMedium) }
                        Column { Text("Total jarak", style = MaterialTheme.typography.labelSmall); Text("${fmtKmUi(summary.totalKm)} km", style = MaterialTheme.typography.titleMedium) }
                        Column { Text("Terjauh", style = MaterialTheme.typography.labelSmall); Text(summary.longestKm?.let { "${fmtKmUi(it)} km" } ?: "–", style = MaterialTheme.typography.titleMedium) }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column { Text("Pace rata-rata terbaik", style = MaterialTheme.typography.labelSmall); Text(summary.fastestAvgPace?.let { com.endurancevault.app.domain.Js.paceStr(it) } ?: "–", style = MaterialTheme.typography.titleMedium) }
                        Column { Text("28 hari terakhir", style = MaterialTheme.typography.labelSmall); Text("${fmtKmUi(summary.last28Km)} km · ${summary.last28Runs} sesi", style = MaterialTheme.typography.titleMedium) }
                    }
                    Text("Statistik dihitung dari aktivitas lari yang tersimpan; bukan prediksi PR lomba.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        if (thisWeek != null) item {
            EvPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    EvGroupTitle("Target minggu ini", "Realisasi terhadap rencana latihan")
                    Text("%.1f dari %s km".format(done, fmtKmUi(thisWeek.km)))
                    LinearProgressIndicator(
                        progress = { if (thisWeek.km > 0) (done / thisWeek.km).toFloat().coerceIn(0f, 1f) else 0f },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }
        item {
            EvPanel(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    EvGroupTitle("Volume lari", "Jarak mingguan · 8 pekan terakhir")
                    ActivityVolumeChart(state.activities)
                }
            }
        }
        item {
            OutlinedButton(
                onClick = { picker.launch(arrayOf("application/octet-stream", "application/gpx+xml", "application/vnd.garmin.tcx+xml", "text/xml", "application/xml", "*/*")) },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Impor FIT / GPX / TCX") }
            trackMsg?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp)) }
        }
        item { EvGroupTitle("Riwayat aktivitas", "Pilih aktivitas untuk melihat detail dan grafik") }
        items(state.activities, key = { it.id }) { a ->
            EvPanel(Modifier.fillMaxWidth().clickable { onOpen(a.id) }) {
                Row(Modifier.padding(14.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("${a.dateIso} · %.1f km".format(a.km) + (if (a.type == "bike") " · sepeda" else "") + (if (a.name.isNotBlank()) " · ${a.name}" else "") + (if (a.detailFile != null) " · rute" else ""))
                        Text(
                            "${a.durationSec / 60} menit" + (a.avgHr?.let { " · HR $it" } ?: ""),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    TextButton(onClick = { onDelete(a.id) }) { Text("Hapus") }
                }
            }
        }
    }
}


@Composable
private fun ActivityVolumeChart(activities: List<com.endurancevault.app.data.ActivityEntity>) {
    val today = LocalDate.now()
    val currentMonday = today.with(DayOfWeek.MONDAY)
    val starts = (7 downTo 0).map { currentMonday.minusWeeks(it.toLong()) }
    val values = starts.map { start ->
        activities.filter { a ->
            if (a.type == "bike") return@filter false
            val date = runCatching { LocalDate.parse(a.dateIso) }.getOrNull() ?: return@filter false
            !date.isBefore(start) && date.isBefore(start.plusDays(7))
        }.sumOf { it.km }
    }
    val maxValue = (values.maxOrNull() ?: 0.0).coerceAtLeast(1.0)
    val accent = MaterialTheme.colorScheme.primary
    val muted = MaterialTheme.colorScheme.outlineVariant
    Canvas(Modifier.fillMaxWidth().height(116.dp)) {
        val left = 4.dp.toPx(); val right = 4.dp.toPx()
        val top = 8.dp.toPx(); val bottom = 8.dp.toPx()
        val usableW = size.width - left - right
        val usableH = size.height - top - bottom
        repeat(3) { i ->
            val y = top + usableH * (i / 2f)
            drawLine(muted.copy(alpha = .55f), Offset(left, y), Offset(size.width-right, y), 1.dp.toPx())
        }
        val slot = usableW / values.size
        values.forEachIndexed { i, value ->
            val h = (value / maxValue).toFloat() * usableH
            val barW = slot * .54f
            val x = left + slot * i + (slot - barW) / 2f
            drawRoundRect(
                color = if (i == values.lastIndex) accent else accent.copy(alpha = .48f),
                topLeft = Offset(x, top + usableH - h),
                size = androidx.compose.ui.geometry.Size(barW, h.coerceAtLeast(2.dp.toPx())),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(5.dp.toPx()),
            )
        }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text("8 pekan lalu", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("Pekan ini", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
    }
    Text("${fmtKmUi(values.last())} km pekan ini", style = MaterialTheme.typography.titleSmall)
}
