# 0.5.103

## Explore: peta dalam kartu rounded sendiri
- Peta kini berada di kartu rounded (sudut 28 dp, garis tepi tipis) di bawah header "Explore" (judul, Cari, Koleksiku), dengan margin 12 dp kiri/kanan dan 8 dp bawah.
- Penyebab bug: `Canvas` peta menggambar tile tanpa dipotong, jadi saat peta digeser/dicubit tile menimpa baris header. Sekarang dipotong di dua tempat: `clipToBounds()` pada akar `ExploreMapCanvas` dan `clip(RoundedCornerShape(28.dp))` pada kartu di `ExploreScreen`.
- Semua kontrol di atas peta (FAB Lari, lapisan, lokasi, kartu rute bawah) ikut berada di dalam kartu.
- Berkas: `ui/screens/ExploreScreen.kt`, `ui/screens/ExploreMap.kt`.
- Belum dikompilasi/dijalankan di sini. Cek di HP: header terlihat penuh, tepi peta membulat, pinch/pan tidak keluar kartu.

## Edit aktivitas: isian gear sepatu
- Dialog **Edit aktivitas** kini selalu menampilkan isian **Gear sepatu** untuk tipe Lari (sebelumnya disembunyikan bila belum ada sepatu terdaftar, jadi tampak tidak ada). Tampilannya isian bergaya sama dengan Nama/Tanggal, ketuk untuk memilih sepatu atau "Tanpa gear".
- Bila belum ada sepatu, isian tampil nonaktif dengan teks "Belum ada sepatu (tambahkan di Profil)". Sepatu pensiun tetap muncul hanya bila itu gear aktivitas ini.
- Gear tersimpan setelah data lain; pilih Sepeda melepas gear (perilaku lama).
- Berkas: `ui/screens/ActivityEditUi.kt`, `assets/i18n/en.tsv` (4 terjemahan baru).

## Logika rasa lari (How it felt) untuk sesi threshold/interval
- Masalah: rasa dibandingkan dengan HR rata-rata seluruh sesi, yang ikut menghitung pemanasan, jeda jogging, dan pendinginan. Sesi threshold dengan rata-rata di Zona 2 tampak "terlalu berat untuk HR-nya" (peringatan palsu "HR: Zone 2 only, yet it felt 6").
- Sekarang `FeelCheck.workEffort` mencari HR bagian kerja: (1) rata-rata HR repetisi yang terdeteksi `IntervalAnalysis` (berbobot waktu, minimal 3 repetisi; dari kurva pace perlu 4); (2) bila tidak ada repetisi tetapi hari rencana kualitas (kind quality, qk thr/vo2/rp), rata-rata 35% waktu dengan HR tertinggi dari histogram.
- Rasa lalu dinilai terhadap zona HR kerja: sama dengan zona kerja atau satu zona di bawahnya = cocok (rasa sesi merata-ratakan kerja dan jeda); lebih berat dari zona kerja = peringatan; jauh lebih ringan = info. Teks menyebut HR kerja dan bahwa rata-rata sesi termasuk pemanasan dan jeda.
- Tanpa bagian kerja (lari biasa) aturan lama tidak berubah. Bila HR kerja lebih rendah dari rata-rata (data janggal) aturan lama dipakai.

## Komentar otomatis lebih pintar
- **Sesi interval dikenali walau tanpa rencana** (≥ 3 repetisi dari lap/segmen). Untuk sesi ini:
  - Intensitas dinilai dari segmen kerja ("Segmen kerja (N repetisi): HR … % LTHR"), rata-rata sesi hanya dicatat. Peringatan bila rencana easy tetapi ada repetisi cepat; info bila usaha kerja < 88% LTHR.
  - Komentar baru per repetisi: jumlah × durasi, pace rata-rata, konsistensi (selisih terbaik-terburuk), fade (melambat atau makin cepat dtk/km), dan HR naik pada pace setara.
  - "Pace stabil dari awal sampai akhir", "HR drift wajar untuk lari panjang", dan "Km tercepat" tidak lagi muncul untuk sesi interval (menyesatkan karena jeda ikut dihitung).
- **Konteks panas:** bila suhu terasa ≥ 29°C ada komentar panas (peringatan di ≥ 33°C), dan pada sesi easy yang HR-nya tinggi disebut bahwa panas ikut menaikkan HR.
- **Halaman Per km:** kartu "Perbandingan paruh" dan "HR drift" disembunyikan untuk sesi interval dengan keterangan singkat.
- Berkas: `domain/FeelCheck.kt`, `domain/ActInsights.kt` (`CommentInput` bertambah `interval`, `workHr`, `feelsLikeC`, `humidityPct`, semuanya berstandar null), `ui/screens/ActivityDetailScreen.kt`.
- Tes baru di `EffortPaceTest` (5): rasa vs HR kerja (cocok, lebih berat, lebih ringan), fallback data janggal, HR kerja dari histogram.
- Teks komentar baru berbahasa Indonesia; terjemahan EN belum ditambahkan untuk kalimat dinamis ini (kalimat feel memang berbahasa Inggris sejak awal).
- Belum dikompilasi/dijalankan di sini. Cek di HP dengan sesi interval 3 × 8 menit tadi: rasa 6 harus "cocok", komentar tidak lagi menyebut "Steady pace", dan muncul komentar repetisi dan panas (terasa 30°C).
