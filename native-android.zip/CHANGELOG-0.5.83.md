# Cuaca: tombol Perbarui, sinkron ke jam, halaman pengaturan baru

Perbaikan tombol Perbarui di kartu sapaan
- Pencarian GPS kini menyalakan status sibuk: ikon berputar dan ketukan berikutnya tidak menumpuk permintaan GPS.
- Bila GPS tidak mendapat lokasi, cuaca tetap dimuat dari lokasi tersimpan (dengan catatan di halaman Layanan), tidak lagi diam saja.
- Penanda kirim-ke-jam (`pushWeatherAfterFetch`) tidak bisa tertinggal aktif setelah GPS gagal.
- Galat saat menyusun ringkasan teks tidak lagi menampilkan "Data belum bisa diambil" padahal data cuaca sudah masuk.
- Pesan galat lama dihapus saat percobaan ulang dimulai.
- Tombol dikecilkan: lingkaran 26 dp, ikon 14 dp, area ketuk 40 dp, dengan peran Button dan label untuk pembaca layar.

Tombol Perbarui ikut menyegarkan jam
- Ketuk Perbarui: ambil lokasi terbaru, muat cuaca, lalu kirim lokasi + cuaca ke jam bila kirim otomatis aktif ATAU jam sedang tersambung.
- Titik GPS dikirim ke jam dengan nama tempat hasil reverse geocoding, bukan "Lokasi saya".
- Hasil kirim tampil singkat di kartu ("Lokasi & cuaca terkirim ke jam."). Status ini tidak lagi menimpa teks status AI Coach.

Halaman Pengaturan > Layanan > Cuaca ditata ulang jadi tiga kartu
- Cuaca saat ini: tempat, jam pembaruan, suhu, kondisi, kelembapan, angin, terbit/terbenam, US AQI berwarna + kategori, PM2.5, prakiraan 7 hari. Menggantikan kotak teks mentah.
- Lokasi: cari kota (ikon cari di dalam kolom), Gunakan GPS, Pengaturan lokasi; koordinat manual + nama lokasi dilipat.
- Cuaca di jam: status, lokasi di jam, waktu kirim terakhir, kirim otomatis, tombol "Kirim lokasi & cuaca ke jam".
- Isian "Nama lokasi" kini ikut tersimpan saat koordinat manual diterapkan.

Kartu sapaan lebih ringkas (opsi 2)
- Header satu baris: sapaan + tombol Perbarui. Suhu "25°" di kiri, di kanannya "Berawan sebagian di Ambarawa" + "Terasa 30°C".
- Nama tempat dipotong di koma pertama ("Ambarawa, Kab. Semarang" jadi "Ambarawa"). Nama generik ("Lokasi saya", "Lokasi latihan") tidak ditampilkan di kalimat kondisi.
- Kutipan maksimal 2 baris; ketuk baris kutipan (panah ▾) membuka kutipan penuh dan Detail cuaca. Isi Detail cuaca tidak berubah.
- Tes unit baru: `ShortPlaceNameTest`.

Berkas: `ui/MainViewModel.kt`, `ui/AppRoot.kt`, `ui/screens/GreetingWeatherCard.kt`, `TodayScreen.kt`, `ProfileScreen.kt`, `OnlineServicesSection.kt`, `WeatherSettingsSection.kt` (baru), `assets/i18n/en.tsv`, `test/.../ShortPlaceNameTest.kt` (baru).
Kode belum dikompilasi di sini; mohon rebuild.
