# Build fix for 0.5.99

## Cause
GitHub Actions failed during Kotlin compilation in `FloatingBlur.kt`.
The wrapper passed `windowInsets` to `androidx.compose.material3.ModalBottomSheet`,
but the Material 3 API version resolved by this project does not expose that
named parameter. This caused the primary unresolved-parameter error and cascading
Composable-context diagnostics on the sheet content lambda.

## Change
Removed the unsupported `windowInsets` parameter from the local wrapper and
removed the unsupported argument from the Material 3 call. The existing
ModalBottomSheet defaults now control window insets.

## Validation
Source-level patch verified. A local Gradle build could not be run in this
environment because the project archive does not include the Gradle wrapper
and no system Gradle installation is available. Run the GitHub Actions workflow
to confirm compilation on the configured Android build environment.
