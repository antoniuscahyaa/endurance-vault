# Native Video Studio — 3D Trail + HUD Video

Status: first native implementation integrated into the project. This document remains the parity contract; visual/device verification is still pending. Do not treat this first pass as a pixel-identical, production-verified port.

## Product decision

EnduranceVault keeps the existing standard Route Video mode. Two additional native modes are added:

1. **3D Trail** — output composition must match the Rencana Lari `21e-video-peta-trail.js` result: cinematic mountain background, route elevation chart, floating circular/polygon terrain slab with visible side wall, terrain relief, contour lines, glowing route ribbon, animated route progress, peak/climb labels, and bottom activity-stat panel with animated live-to-total summary.
2. **HUD Video** — use a selected POV video as the background and render activity metrics in sync with the video timeline. Output must be a flattened MP4, with optional source-audio preservation.

The editor may be reorganized for native Android usability, but every source control listed below must remain available. The output composition is not redesigned.

## 3D Trail parity inventory

### Composition
- Header: activity/location title, optional athlete handle, optional weather chip.
- Elevation chart: full profile, completed portion, current-position marker, peak marker, climb markers, grade marker, HR-zone tint where HR-zone series exists, elevation min/max/average labels.
- Terrain slab: circular, square, hexagonal, or octagonal footprint; visible side wall; terrain relief; contour lines; hill shading; route ribbon; route progress; route marker; start/finish and optional kilometer markers.
- Background: procedural mountain scenery, plain, solid color, or user photo; configurable darkening for photo background.
- Bottom panel: classic, center, tiles, or compact layout; optional progress bar; optional card background; automatic/custom statistic slots; optional extended metrics; animated entrance; live-to-summary transition.

### Trail controls that must be retained
- Footprint shape: circle / square / hexagon / octagon.
- Terrain scale and horizontal placement: scale, X offset, Y offset.
- Relief exaggeration / peak-height target.
- Camera tilt and terrain rotation / overview behavior.
- Terrain palette: Orange Neon / Lime Neon; custom accent color.
- Background: mountain / plain / solid / photo; solid color; photo darkening.
- Data layout: classic / center / tiles / compact.
- Card background: none / glass / solid / auto-contrast.
- Progress bar on/off.
- Statistic mode: automatic / custom; four independently configurable slots, including empty slots.
- Extended metrics: GAP, climb, grade, and supported activity-specific metrics.
- Chart annotations: peak, climbs, grade; HR-zone coloring when source data exists.
- Animation: panel entrance and final total-summary transition.
- Story safe-area option.

### Rendering/data rules
- Use activity GPS/elevation/HR samples; do not synthesize missing values.
- Smooth DEM/elevation before mesh and slope derivation.
- Compute the route's enclosing circle with margin and apply configured center offsets and scale.
- Terrain height exaggeration is auto-normalized against local elevation range, bounded to avoid degenerate geometry.
- Kilometer, peak, climb and grade annotations must be collision-aware.
- Live metrics follow the current animation distance; the final card transitions to total activity values.
- If DEM data or GL extensions are unavailable, render a deterministic flat-disc fallback without dropping the route, chart, labels or stats.

## HUD Video parity inventory

### Source selection and synchronization
- Select/change POV video through Android Photo Picker / SAF.
- Read duration, dimensions, rotation and file modification timestamp.
- Guess video-start offset from file timestamp minus video duration relative to activity start time.
- Keep manual sync slider, bounded to -120 seconds through activity elapsed duration.
- Keep exact nudges: -10s, -1s, +1s, +10s.
- Keep explicit "guess from file time" action and a visible sync label showing elapsed run time and corresponding kilometer.
- Seek/play/pause preview; show current video time and mapped run time/km.
- Respect the source 15-minute export cap (900 seconds) unless deliberately expanded as a separately approved product change.

### HUD values
- Heart rate (bpm), cumulative distance (km), pace (/km), elapsed run time, elevation (m), slope (%), speed (km/h), speed gauge, route minimap and current position.
- Derive speed from pace only when pace is valid.
- Show unavailable values as `--` / em dash, never fabricate a value.
- Map video time + sync offset to elapsed activity time, then interpolate cumulative distance and all metrics at that point. A video beginning mid-run must immediately show the correct mid-run values.

### HUD styles and controls
- Styles: Two Columns and Minimal.
- Accent: Orange / Lime / White / Blue (plus persisted custom hex if supported by source prefs).
- Route minimap on/off (two-column style).
- Speed gauge on/off (two-column style).
- Top/bottom gradient darkening 0–60%.
- Export format: MP4 H.264 (primary) and device-supported real-time recorder fallback.
- Preserve original source audio toggle.
- Preserve all user choices between sessions.

### Export requirements
- Flatten video and HUD into one MP4 H.264 output.
- Preserve original audio when selected; do not silently discard it when audio extraction/muxing fails—report the failure and offer export without audio.
- Maintain source orientation/aspect ratio, with dimensions capped consistently with source behavior.
- Report progress, allow cancellation, clean temporary files, and save/share through Android MediaStore / FileProvider.
- Handle unsupported input codecs and devices without crashing.

## Recommended native editor information architecture

Use one **Video Studio** screen with two mode tabs: `3D Trail` and `HUD Video`. Each mode has a persistent preview area and a bottom editor sheet with grouped, collapsible sections:

- 3D Trail: Scene & Shape; Terrain & Camera; Route & Elevation; Data Panel; Labels & Metrics; Animation; Output.
- HUD Video: Video & Sync; HUD Layout; Metrics & Map; Appearance; Audio & Export.

Controls should be native Compose controls. Use chips for small enumerations, sliders for continuous values, color swatches for palettes, reorderable/slot selectors for statistics, and direct preview updates. Include reset-to-default and save-preset actions. Do not remove advanced controls merely to simplify the editor; advanced controls may live in a collapsed section.

## Suggested native architecture

- `TrailVideoPrefs` / `TrailVideoPrefsStore`: versioned, persisted settings.
- `TrailVideoLayout`: pure layout calculations and aspect/safe-area handling.
- `TrailTerrainMesh`: DEM smoothing, disc/polygon clipping, side-wall mesh and contour geometry.
- `TrailVideoRenderer`: dedicated GL renderer plus Canvas overlay; existing standard `TerrainGl` route renderer remains untouched.
- `HudVideoPrefs` / `HudVideoPrefsStore`: persisted HUD settings.
- `HudTimeline`: timestamp/offset mapping and interpolation, independently unit-tested.
- `HudOverlayRenderer`: native Canvas drawing for both HUD styles, minimap and gauge.
- `HudVideoPreview`: Media3/ExoPlayer or platform decoder preview.
- `HudVideoExporter`: frame-accurate composition, H.264 encoding, optional source-audio muxing, cancellation and progress.
- `VideoStudioScreen`: native Compose editor and preview coordinator.

## Acceptance criteria

- Standard Route Video output remains unchanged.
- Trail output matches the source composition at portrait, square and landscape aspect ratios, including the same chart/terrain/stats hierarchy and end-card transition.
- All Trail controls above are represented in the editor and affect rendered output.
- HUD preview and export show the same metric values at the same video timestamps.
- Auto-sync, manual offset and four nudges work as specified.
- Both HUD styles and all appearance/audio/export toggles affect the exported MP4.
- Audio is retained when selected and supported, or the user receives an explicit actionable error.
- Preferences survive app restart; cancellation leaves no partial output.
- Unit tests cover offset guessing, interpolation, invalid/missing metrics, layout geometry, and progress-to-summary transition.


## First implementation delivered in this project snapshot

### Integrated files
- `domain/RouteVideo.kt`: persisted Trail settings, video layout mode (`standard`, `trail`, `hud`), weather/GAP/VAM metadata and GPS-independent HUD track builder.
- `domain/HudVideo.kt`: HUD preference model including MP4 / recorder format selection.
- `ui/video/TrailVideoOverlay.kt`: native Canvas Trail composition using the existing DEM `TerrainScene`; terrain slab, side wall, relief, hillshade, contours, route ribbon/progress, markers, elevation profile, stats panel, photo/mountain/plain/solid backgrounds, live-to-summary transition.
- `ui/video/HudVideoOverlay.kt`: timestamp-to-activity interpolation and per-frame HUD drawing, including minimap and speed gauge.
- `ui/video/HudVideoEncoder.kt`: H.264 MediaCodec exporter, MediaRecorder device fallback, AAC source-audio passthrough/remux, rotation handling, cancellation and progress.
- `ui/screens/HudVideoEditor.kt`: native POV picker, VideoView preview, manual/automatic sync, nudges, style/metric controls, appearance/audio settings, export and share.
- `ui/screens/RouteVideoScreen.kt`: three-mode selector and Trail editor controls; existing standard Route Video controls remain in place.
- `test/.../VideoStudioTest.kt`: preference persistence/sanitization tests.

### Current known gaps / verification items
- The Trail slab is a Canvas-projected DEM mesh, not yet a dedicated perspective OpenGL mesh. Its overall composition proportions are adapted from the source layout, but pixel-level terrain shading, scenery noise, HR-zone profile tinting and collision-aware annotation placement still require comparison against reference renders.
- The HR-zone profile tint is not rendered yet because the current route-video track does not carry a per-sample HR-zone classification. Raw HR is retained; no synthetic zones are invented.
- `GAP` and `VAM` display values only when the activity model provides them; otherwise the editor/output shows `--`.
- The HUD preview uses the native `VideoView` plus a Compose overlay approximation; the flattened export uses the dedicated Canvas frame renderer. Preview/export parity must be verified on-device.
- Original audio passthrough/remux currently supports AAC. When source audio is requested but no compatible AAC track exists, export fails with an actionable message rather than silently producing a muted file.
- Recorder fallback uses the device's MediaRecorder video encoder and then remuxes original AAC audio when selected. Codec/container support varies by handset.
- The first implementation is limited to 15 minutes per source video and caps the output's longest dimension at 1280 pixels.
- A full Android Gradle build and device export test could not be run in this environment: the uploaded project archive does not contain `gradlew`, and no Gradle/Android SDK toolchain is available here. The new unit tests are included but have not been executed.

### Required next verification pass
1. Build with the project's normal Android/CI toolchain and resolve any Kotlin/API-level errors.
2. Render the same sample activity in Rencana Lari and EnduranceVault at portrait, square and landscape aspect ratios; compare chart, slab diameter/position, wall depth, header, stats panel and summary transition.
3. Test HUD with a GPS run and an indoor time-series activity; compare auto-sync and manual offsets at the start, middle and end of a POV video.
4. Test AAC-present, AAC-absent, rotated, variable-frame-rate and unsupported-source videos on Android 10 and a current Android release.
5. Confirm cancellation removes temporary files and the saved MP4 opens in Gallery and external players.


### CI log follow-up (Build 43121593065)
- Fixed `HudVideoOverlay.kt`: the HUD metric-unit alignment measured text using the renderer's actual `paint` instance instead of an undefined `p` identifier.
- Fixed `TrailVideoOverlay.kt`: explicitly converted elevation-profile values and terrain ridge arithmetic from `Double` to `Float` at Canvas drawing boundaries.
- These fixes directly address the Kotlin compiler diagnostics in the supplied Actions log. A fresh CI run is still required to confirm compilation and execute the tests; the supplied run itself remains failed.


## Live preview editor refinement (2026-11-12)

- HUD POV editor now composites its preview using `HudVideoOverlay.drawOverlay`, the same Canvas renderer used by MP4 frame rendering, rather than a separately approximated Compose HUD.
- HUD preview has play/pause, a seekable timeline, ±1-second controls, live elapsed/distance readout, and updates the overlay while playback or scrubbing changes the video timestamp.
- Trail / 3D route studio preview now has play/pause and ±1-second timeline stepping; the preview frame is regenerated as the playhead advances.
- The shared HUD Canvas renderer is synchronized because it is now used by both the UI preview and export rendering.
- Device playback, seek accuracy, SurfaceView overlay stacking, and preview/export pixel parity still require a real Android build and device verification.
